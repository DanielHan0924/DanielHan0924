-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 16, 2020 at 03:21 AM
-- Server version: 10.2.33-MariaDB-log
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ezmort5_ezmm`
--

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_ancestry`
--

CREATE TABLE `dropdown_ancestry` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_cemetery`
--

CREATE TABLE `dropdown_cemetery` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_citizenship`
--

CREATE TABLE `dropdown_citizenship` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_citizenship`
--

INSERT INTO `dropdown_citizenship` (`id`, `name`) VALUES
(4, 'American');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_city`
--

CREATE TABLE `dropdown_city` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_city`
--

INSERT INTO `dropdown_city` (`id`, `name`) VALUES
(1, 'Sioux Falls'),
(2, 'Rapid City'),
(3, 'Mitchell');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_college`
--

CREATE TABLE `dropdown_college` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_college`
--

INSERT INTO `dropdown_college` (`id`, `name`) VALUES
(1, 'Augustana'),
(2, 'Sioux Falls');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_country`
--

CREATE TABLE `dropdown_country` (
  `countryID` int(3) NOT NULL,
  `Country` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dropdown_country`
--

INSERT INTO `dropdown_country` (`countryID`, `Country`) VALUES
(1, 'United States'),
(2, 'Canada');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_county`
--

CREATE TABLE `dropdown_county` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_county`
--

INSERT INTO `dropdown_county` (`id`, `name`) VALUES
(1, 'Minnehaha'),
(2, 'Lincoln');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_funeralmemorial`
--

CREATE TABLE `dropdown_funeralmemorial` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_funeralmemorial`
--

INSERT INTO `dropdown_funeralmemorial` (`id`, `name`) VALUES
(1, 'funeralmemorial_1');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_funstatus`
--

CREATE TABLE `dropdown_funstatus` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_funstatus`
--

INSERT INTO `dropdown_funstatus` (`id`, `name`) VALUES
(2, 'Paid'),
(3, 'Demo');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_graduatename`
--

CREATE TABLE `dropdown_graduatename` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_graduatename`
--

INSERT INTO `dropdown_graduatename` (`id`, `name`) VALUES
(1, 'stepone'),
(2, 'step2');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_highschool`
--

CREATE TABLE `dropdown_highschool` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_highschool`
--

INSERT INTO `dropdown_highschool` (`id`, `name`) VALUES
(1, 'Roosevelt High');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_honorific`
--

CREATE TABLE `dropdown_honorific` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_honorific`
--

INSERT INTO `dropdown_honorific` (`id`, `name`) VALUES
(21, 'Dr'),
(22, 'Ms'),
(23, 'Mrs'),
(24, 'Mr');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_lastname`
--

CREATE TABLE `dropdown_lastname` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_lastname`
--

INSERT INTO `dropdown_lastname` (`id`, `name`) VALUES
(1, 'Smith'),
(2, 'Johnson'),
(3, 'William'),
(4, 'Jones'),
(5, 'Johnson'),
(7, 'Stevens');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_militarybranch`
--

CREATE TABLE `dropdown_militarybranch` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_militarybranch`
--

INSERT INTO `dropdown_militarybranch` (`id`, `name`) VALUES
(1, 'Army'),
(2, 'Navy'),
(3, 'Air Force'),
(4, 'Marines'),
(5, 'Coast Guard'),
(6, 'National Guard');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_militaryservicehonors`
--

CREATE TABLE `dropdown_militaryservicehonors` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_militaryservicehonors`
--

INSERT INTO `dropdown_militaryservicehonors` (`id`, `name`) VALUES
(1, 'Medal of Honor'),
(3, 'Distinguished Service Cross'),
(4, 'Purple Heart'),
(6, 'Bronze Star');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_occupation`
--

CREATE TABLE `dropdown_occupation` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_occupation`
--

INSERT INTO `dropdown_occupation` (`id`, `name`) VALUES
(1, 'occupation'),
(2, 'occupation2');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_plan`
--

CREATE TABLE `dropdown_plan` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_plan`
--

INSERT INTO `dropdown_plan` (`id`, `name`) VALUES
(2, 'Per Funeral - Onetime Setup'),
(3, 'Per Funeral Pro-Rated'),
(4, 'Monthly Payments'),
(5, 'Lifetime'),
(6, 'Demo');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_race`
--

CREATE TABLE `dropdown_race` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_race`
--

INSERT INTO `dropdown_race` (`id`, `name`) VALUES
(1, 'White'),
(2, 'Black or African American'),
(3, 'Asian'),
(4, 'American Indian or Alaska Native'),
(5, 'Native Hawaiian or Other Pacific Islander'),
(6, 'Hispanic or Latino');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_rank`
--

CREATE TABLE `dropdown_rank` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_rank`
--

INSERT INTO `dropdown_rank` (`id`, `name`) VALUES
(1, 'E1'),
(2, 'E2'),
(3, 'E3'),
(4, 'E4'),
(5, 'E5'),
(6, 'E6');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_reasonfor`
--

CREATE TABLE `dropdown_reasonfor` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_reasonfor`
--

INSERT INTO `dropdown_reasonfor` (`id`, `name`) VALUES
(7, 'sadfdsf'),
(8, 'unknown'),
(9, 'test'),
(10, 'Required by law'),
(11, 'reason1 for test');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_relationship`
--

CREATE TABLE `dropdown_relationship` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_relationship`
--

INSERT INTO `dropdown_relationship` (`id`, `name`) VALUES
(3, 'Child'),
(4, 'Grand Child'),
(5, 'Great Grand Child');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_religion`
--

CREATE TABLE `dropdown_religion` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_religion`
--

INSERT INTO `dropdown_religion` (`id`, `name`) VALUES
(1, 'Baptist'),
(2, 'Catholic');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_state`
--

CREATE TABLE `dropdown_state` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_state`
--

INSERT INTO `dropdown_state` (`id`, `name`) VALUES
(1, 'AL'),
(2, 'AK'),
(3, 'AZ'),
(4, 'AR'),
(5, 'CA'),
(6, 'CO'),
(7, 'CT'),
(8, 'DE'),
(9, 'FL'),
(10, 'GA'),
(11, 'HI'),
(12, 'ID'),
(13, 'IL'),
(14, 'IN'),
(15, 'IA'),
(16, 'KS'),
(17, 'KY'),
(18, 'LA'),
(19, 'ME'),
(20, 'MD'),
(21, 'MA'),
(22, 'MI'),
(23, 'MN'),
(24, 'MS'),
(25, 'MD'),
(26, 'MT'),
(27, 'NE'),
(28, 'NV'),
(29, 'NH'),
(30, 'NJ'),
(31, 'NM'),
(32, 'NY'),
(33, 'NC'),
(34, 'ND'),
(35, 'OH'),
(36, 'OK'),
(37, 'OR'),
(38, 'PA'),
(39, 'RI'),
(40, 'SC'),
(41, 'SD'),
(42, 'TN'),
(43, 'TX'),
(44, 'UT'),
(45, 'VT'),
(46, 'VT'),
(47, 'VA'),
(48, 'WA'),
(49, 'WV'),
(50, 'WY');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_statementcategories`
--

CREATE TABLE `dropdown_statementcategories` (
  `id` int(12) NOT NULL,
  `name` varchar(50) NOT NULL,
  `tablename` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_statementcategories`
--

INSERT INTO `dropdown_statementcategories` (`id`, `name`, `tablename`) VALUES
(1, 'Professional Services', 'statement_professional'),
(2, 'Facilites & Equipment', 'statement_facilities'),
(3, 'Automotive & Equipment', 'statement_automotive'),
(4, 'Charges of Merchandise Selected', 'statement_chargesofmerchandise'),
(5, 'Changes for Services Selected', 'statement_changesforservices'),
(6, 'Total Special Charges', 'statement_totalspecialcharges'),
(7, 'Cash Advanced', 'statement_cashadvanced'),
(8, 'Summary of Charges', 'statement_summaryofcharges'),
(9, 'Total Amount Due', 'statement_totalamountdue'),
(10, 'Reason For', 'statement_reasonfor');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_status`
--

CREATE TABLE `dropdown_status` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_status`
--

INSERT INTO `dropdown_status` (`id`, `name`) VALUES
(1, 'Pre-Need'),
(2, 'At-Need'),
(3, 'First-Call'),
(4, 'Case-Bio'),
(5, 'Final-Arrangements');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_statusdt`
--

CREATE TABLE `dropdown_statusdt` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_statusdt`
--

INSERT INTO `dropdown_statusdt` (`id`, `name`) VALUES
(1, 'Body Pickup'),
(2, 'Embalming'),
(3, 'Preparation for Visitation'),
(4, 'Preparation for Final Disposition');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_suffix`
--

CREATE TABLE `dropdown_suffix` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_suffix`
--

INSERT INTO `dropdown_suffix` (`id`, `name`) VALUES
(4, 'Miss'),
(6, 'Sr'),
(7, 'sir'),
(8, 'Love'),
(10, 'Jr');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_township`
--

CREATE TABLE `dropdown_township` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_township`
--

INSERT INTO `dropdown_township` (`id`, `name`) VALUES
(1, 'Boss');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_typeofdischarge`
--

CREATE TABLE `dropdown_typeofdischarge` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_typeofdischarge`
--

INSERT INTO `dropdown_typeofdischarge` (`id`, `name`) VALUES
(1, 'Honorable'),
(2, 'General - Under Honorable'),
(3, 'Bad Conduct'),
(4, 'Dishonorable'),
(5, 'Uncharacterized');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_undergraduatename`
--

CREATE TABLE `dropdown_undergraduatename` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_undergraduatename`
--

INSERT INTO `dropdown_undergraduatename` (`id`, `name`) VALUES
(1, 'fool'),
(2, 'fooling around'),
(3, 'TEST grade');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_warcampaign`
--

CREATE TABLE `dropdown_warcampaign` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_warcampaign`
--

INSERT INTO `dropdown_warcampaign` (`id`, `name`) VALUES
(1, 'WW II'),
(2, 'Korean'),
(3, 'Vietnam'),
(4, 'Desert Storm');

-- --------------------------------------------------------

--
-- Table structure for table `dropdown_zip`
--

CREATE TABLE `dropdown_zip` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dropdown_zip`
--

INSERT INTO `dropdown_zip` (`id`, `name`) VALUES
(1, '94203'),
(2, '94207'),
(3, '94210');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dropdown_ancestry`
--
ALTER TABLE `dropdown_ancestry`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_cemetery`
--
ALTER TABLE `dropdown_cemetery`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_citizenship`
--
ALTER TABLE `dropdown_citizenship`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_city`
--
ALTER TABLE `dropdown_city`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_college`
--
ALTER TABLE `dropdown_college`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_country`
--
ALTER TABLE `dropdown_country`
  ADD PRIMARY KEY (`countryID`);

--
-- Indexes for table `dropdown_county`
--
ALTER TABLE `dropdown_county`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_funeralmemorial`
--
ALTER TABLE `dropdown_funeralmemorial`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_funstatus`
--
ALTER TABLE `dropdown_funstatus`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_graduatename`
--
ALTER TABLE `dropdown_graduatename`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_highschool`
--
ALTER TABLE `dropdown_highschool`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_honorific`
--
ALTER TABLE `dropdown_honorific`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_lastname`
--
ALTER TABLE `dropdown_lastname`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_militarybranch`
--
ALTER TABLE `dropdown_militarybranch`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_militaryservicehonors`
--
ALTER TABLE `dropdown_militaryservicehonors`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_occupation`
--
ALTER TABLE `dropdown_occupation`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_plan`
--
ALTER TABLE `dropdown_plan`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_race`
--
ALTER TABLE `dropdown_race`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_rank`
--
ALTER TABLE `dropdown_rank`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_reasonfor`
--
ALTER TABLE `dropdown_reasonfor`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_relationship`
--
ALTER TABLE `dropdown_relationship`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_religion`
--
ALTER TABLE `dropdown_religion`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_state`
--
ALTER TABLE `dropdown_state`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_statementcategories`
--
ALTER TABLE `dropdown_statementcategories`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_status`
--
ALTER TABLE `dropdown_status`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_statusdt`
--
ALTER TABLE `dropdown_statusdt`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_suffix`
--
ALTER TABLE `dropdown_suffix`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_township`
--
ALTER TABLE `dropdown_township`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_typeofdischarge`
--
ALTER TABLE `dropdown_typeofdischarge`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_undergraduatename`
--
ALTER TABLE `dropdown_undergraduatename`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_warcampaign`
--
ALTER TABLE `dropdown_warcampaign`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dropdown_zip`
--
ALTER TABLE `dropdown_zip`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dropdown_ancestry`
--
ALTER TABLE `dropdown_ancestry`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dropdown_cemetery`
--
ALTER TABLE `dropdown_cemetery`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dropdown_citizenship`
--
ALTER TABLE `dropdown_citizenship`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dropdown_city`
--
ALTER TABLE `dropdown_city`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dropdown_college`
--
ALTER TABLE `dropdown_college`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dropdown_country`
--
ALTER TABLE `dropdown_country`
  MODIFY `countryID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dropdown_county`
--
ALTER TABLE `dropdown_county`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dropdown_funeralmemorial`
--
ALTER TABLE `dropdown_funeralmemorial`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dropdown_funstatus`
--
ALTER TABLE `dropdown_funstatus`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dropdown_graduatename`
--
ALTER TABLE `dropdown_graduatename`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dropdown_highschool`
--
ALTER TABLE `dropdown_highschool`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dropdown_honorific`
--
ALTER TABLE `dropdown_honorific`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `dropdown_lastname`
--
ALTER TABLE `dropdown_lastname`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `dropdown_militarybranch`
--
ALTER TABLE `dropdown_militarybranch`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `dropdown_militaryservicehonors`
--
ALTER TABLE `dropdown_militaryservicehonors`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `dropdown_occupation`
--
ALTER TABLE `dropdown_occupation`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dropdown_plan`
--
ALTER TABLE `dropdown_plan`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `dropdown_race`
--
ALTER TABLE `dropdown_race`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `dropdown_rank`
--
ALTER TABLE `dropdown_rank`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `dropdown_reasonfor`
--
ALTER TABLE `dropdown_reasonfor`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `dropdown_relationship`
--
ALTER TABLE `dropdown_relationship`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dropdown_religion`
--
ALTER TABLE `dropdown_religion`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dropdown_state`
--
ALTER TABLE `dropdown_state`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `dropdown_statementcategories`
--
ALTER TABLE `dropdown_statementcategories`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `dropdown_status`
--
ALTER TABLE `dropdown_status`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dropdown_statusdt`
--
ALTER TABLE `dropdown_statusdt`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dropdown_suffix`
--
ALTER TABLE `dropdown_suffix`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `dropdown_township`
--
ALTER TABLE `dropdown_township`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dropdown_typeofdischarge`
--
ALTER TABLE `dropdown_typeofdischarge`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dropdown_undergraduatename`
--
ALTER TABLE `dropdown_undergraduatename`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dropdown_warcampaign`
--
ALTER TABLE `dropdown_warcampaign`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dropdown_zip`
--
ALTER TABLE `dropdown_zip`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
