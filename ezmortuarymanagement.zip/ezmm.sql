/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 100137
 Source Host           : localhost:3306
 Source Schema         : ezmm

 Target Server Type    : MySQL
 Target Server Version : 100137
 File Encoding         : 65001

 Date: 10/09/2020 14:00:03
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for at_need_nok
-- ----------------------------
DROP TABLE IF EXISTS `at_need_nok`;
CREATE TABLE `at_need_nok`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `relationship` int(11) NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of at_need_nok
-- ----------------------------
INSERT INTO `at_need_nok` VALUES (1, 'test', 'aaaaa', '222222', '3333333', 2, 2, 2, 2, '(666) 666-6666', '(777) 777-7777', 'test@test.com');
INSERT INTO `at_need_nok` VALUES (3, 'test', 'from At to At-Need', 'bb', 'cc', 1, 1, 3, 1, '(222) 222-2222', '(333) 333-3333', 'test@test.com');

-- ----------------------------
-- Table structure for at_need_pi
-- ----------------------------
DROP TABLE IF EXISTS `at_need_pi`;
CREATE TABLE `at_need_pi`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caseID` int(11) NOT NULL,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `honorific` int(11) NOT NULL,
  `firstName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `middleName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `lastName` int(11) NOT NULL,
  `suffix` int(11) NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `township` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zipCode` int(11) NOT NULL,
  `country` int(11) NOT NULL,
  `nickName` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `gender` varchar(8) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SSN` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dateOfBirth` date NOT NULL,
  `dateOfDeath` date NOT NULL,
  `timeOfDeath` time(0) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of at_need_pi
-- ----------------------------
INSERT INTO `at_need_pi` VALUES (1, 0, 'test', 21, 'bbb', '222222', 333333, 4, '44444', '555555', 6666666, 77777, 0, 11111, 888888, '999999', 'x', '222-22-2222', 'test@test.com', '(333) 333-3333', '0000-00-00', '2020-07-25', '02:49:00');
INSERT INTO `at_need_pi` VALUES (2, 0, 'test', 22, 'aaaa', 'bbb', 1, 4, 'dddd', 'eeeee', 1, 1, 1, 2, 1, 'iiiiii', 'Male', '222-22-2222', 'test@test.com', '(333) 333-3333', '0000-00-00', '2020-07-18', '10:44:00');
INSERT INTO `at_need_pi` VALUES (3, 0, 'test', 23, 'aaaa', 'bbb', 1, 1, 'dddd', 'eeeee', 1, 1, 1, 2, 1, 'iiiiii', 'Male', '222-22-2222', 'test@test.com', '(333) 333-3333', '0000-00-00', '2020-07-24', '10:44:00');
INSERT INTO `at_need_pi` VALUES (5, 0, 'test', 24, 'aaaa', 'bbb', 1, 4, 'dddd', 'eeeee', 1, 1, 1, 2, 1, 'iiiiii', 'Male', '222-22-2222', 'test@test.com', '(333) 333-3333', '0000-00-00', '2020-07-18', '10:44:00');
INSERT INTO `at_need_pi` VALUES (7, 0, 'test', 23, 'aaaa', 'bbb', 2, 6, 'dddd', 'eeeee', 1, 1, 2, 2, 1, 'iiiiii', 'Male', '222-22-2222', 'test@test.com', '(333) 333-3333', '0000-00-00', '0000-00-00', '00:00:00');
INSERT INTO `at_need_pi` VALUES (8, 0, 'test', 21, 'aaaa', 'bbb', 2, 6, 'dddd', 'eeeee', 1, 1, 2, 2, 1, 'iiiiii', 'Male', '222-22-2222', 'test@test.com', '(333) 333-3333', '0000-00-00', '2020-08-22', '08:15:00');
INSERT INTO `at_need_pi` VALUES (10, 0, 'test', 21, 'convert to At Need', 'bbb', 2, 6, 'dddd', 'eeeee', 1, 1, 2, 2, 1, 'iiiiii', 'Male', '222-22-2222', 'test@test.com', '(333) 333-3333', '0000-00-00', '0000-00-00', '00:00:00');
INSERT INTO `at_need_pi` VALUES (12, 0, 'test', 22, 'John', '', 7, 10, 'dddd', 'eeeee', 1, 1, 2, 2, 1, 'iiiiii', 'Male', '222-22-2222', 'test@test.com', '(333) 333-3333', '0000-00-00', '2020-08-26', '00:00:00');

-- ----------------------------
-- Table structure for case_bio_children
-- ----------------------------
DROP TABLE IF EXISTS `case_bio_children`;
CREATE TABLE `case_bio_children`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `dob` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `relationship` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of case_bio_children
-- ----------------------------
INSERT INTO `case_bio_children` VALUES (2, 'test', 'child1', 'ad', 'ad2', 2, 1, 1, '2020-07-29', 1, 'test@test.com', '(888) 888-8888', '(888) 888-8888');

-- ----------------------------
-- Table structure for case_bio_church
-- ----------------------------
DROP TABLE IF EXISTS `case_bio_church`;
CREATE TABLE `case_bio_church`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Church` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ClergyName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `Email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of case_bio_church
-- ----------------------------
INSERT INTO `case_bio_church` VALUES (2, 'test', 'to case', 'bbbbbb', 'ccccc', 'dddddd', 1, 1, 2, 'test@test.com', '(222) 222-2222', '(333) 333-3333');

-- ----------------------------
-- Table structure for case_bio_deceased_info
-- ----------------------------
DROP TABLE IF EXISTS `case_bio_deceased_info`;
CREATE TABLE `case_bio_deceased_info`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caseID` int(11) NOT NULL,
  `username` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `firstName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `lastName` int(11) NULL DEFAULT NULL,
  `dateOfBirth` date NULL DEFAULT NULL,
  `dateOfDeath` date NULL DEFAULT NULL,
  `Citizenship` int(11) NOT NULL,
  `Race` int(11) NOT NULL,
  `Religion` int(11) NOT NULL,
  `PlaceOfBirth` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Ancestry` int(11) NOT NULL,
  `Business` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `States` int(11) NOT NULL,
  `InCommunitySInce` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `MovedFrom` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Photo` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of case_bio_deceased_info
-- ----------------------------
INSERT INTO `case_bio_deceased_info` VALUES (14, 161, 'test', 'Watshon_precase', 7, '1970-12-30', '2020-09-10', 4, 4, 1, 'asdf', 2, 'coder', 2, 'tetsdfasdf', 'te', 'eccd1dd2ab8349973eaf792d7df0d873.jpg');

-- ----------------------------
-- Table structure for case_bio_education
-- ----------------------------
DROP TABLE IF EXISTS `case_bio_education`;
CREATE TABLE `case_bio_education`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `EduHighSchool` int(11) NOT NULL,
  `EduHSGraduated` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `undergraducate` int(11) NOT NULL,
  `undergraducatedegree` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `undergraducatedegreecheck` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `graduate` int(11) NOT NULL,
  `graducatedegree` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `graducatedegreecheck` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of case_bio_education
-- ----------------------------
INSERT INTO `case_bio_education` VALUES (3, 'test', 1, 'Y', 2, 'bbbb', 'N', 2, 'dddd', 'Y');
INSERT INTO `case_bio_education` VALUES (4, 'test', 1, 'Y', 2, 'to final arrangement', 'N', 2, 'dddd', 'Y');

-- ----------------------------
-- Table structure for case_bio_grand_children
-- ----------------------------
DROP TABLE IF EXISTS `case_bio_grand_children`;
CREATE TABLE `case_bio_grand_children`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `dob` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `relationship` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for case_bio_great_grand_children
-- ----------------------------
DROP TABLE IF EXISTS `case_bio_great_grand_children`;
CREATE TABLE `case_bio_great_grand_children`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `dob` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `relationship` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for case_bio_great_great_grand_children
-- ----------------------------
DROP TABLE IF EXISTS `case_bio_great_great_grand_children`;
CREATE TABLE `case_bio_great_great_grand_children`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `dob` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `relationship` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for case_bio_marital
-- ----------------------------
DROP TABLE IF EXISTS `case_bio_marital`;
CREATE TABLE `case_bio_marital`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `maritalstatus` int(11) NOT NULL,
  `placeofmarriage` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dateofmarriage` date NOT NULL,
  `spousesname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Spousedeceased` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dateofdeath` date NOT NULL,
  `spousesplaceofdeath` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of case_bio_marital
-- ----------------------------
INSERT INTO `case_bio_marital` VALUES (2, 'test', 3, 'aaaa', '2020-07-11', 'bbbb', '', '2020-07-18', 'cccccc');
INSERT INTO `case_bio_marital` VALUES (3, 'test', 3, 'aaaa', '2020-07-11', 'bbbb', '', '2020-07-18', 'cccccc');
INSERT INTO `case_bio_marital` VALUES (4, 'test', 3, 'test', '2020-07-11', 'bbbb', '', '2020-07-18', 'cccccc');
INSERT INTO `case_bio_marital` VALUES (6, 'test', 3, 'TO case bio', '2020-07-11', 'bbbb', '', '2020-07-18', 'cccccc');

-- ----------------------------
-- Table structure for case_bio_military_service
-- ----------------------------
DROP TABLE IF EXISTS `case_bio_military_service`;
CREATE TABLE `case_bio_military_service`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `BranchID` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `WarCampaignID` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SerialNumber` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Rank` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `EnlistmentDate` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DischargeDate` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `TypeOfDischargeID` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DD214` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Headstone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ApplicationForBurial` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ApplicationForFlag` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `HonorGuard` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of case_bio_military_service
-- ----------------------------
INSERT INTO `case_bio_military_service` VALUES (3, 'test', '4', '1', '4566 to case bio/mlt', '3', '2020-07-11', '2020-07-18', '1', 'Y', 'Y', 'N', 'Y', 'Y');
INSERT INTO `case_bio_military_service` VALUES (4, 'test', '4', '1', '12', '3', '2020-07-11', '2020-07-18', '1', 'Y', 'N', 'N', 'Y', 'Y');
INSERT INTO `case_bio_military_service` VALUES (5, 'test', '4', '1', '1234', '3', '2020-07-11', '2020-07-18', '1', 'Y', 'Y', 'N', 'N', 'N');

-- ----------------------------
-- Table structure for case_bio_parents
-- ----------------------------
DROP TABLE IF EXISTS `case_bio_parents`;
CREATE TABLE `case_bio_parents`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `FathersName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `FDOB` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `FPlaceOfBirth` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `MothersName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `MothersMaidenName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `MDOB` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `MPlaceOfBirth` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of case_bio_parents
-- ----------------------------
INSERT INTO `case_bio_parents` VALUES (2, 'test', 'daniel', '2020-08-07', 'test place', 'sopia', 'sopia', '2020-08-11', 'test place');

-- ----------------------------
-- Table structure for case_bio_place_of_worship
-- ----------------------------
DROP TABLE IF EXISTS `case_bio_place_of_worship`;
CREATE TABLE `case_bio_place_of_worship`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `PlaceOfWorship` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ClergyName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of case_bio_place_of_worship
-- ----------------------------
INSERT INTO `case_bio_place_of_worship` VALUES (2, 'test', 'test', '2222222', '3333333', '444444', 1, 1, 2, 'aaa@aaa.com', '(777) 777-7788', '(888) 888-8888');

-- ----------------------------
-- Table structure for cases
-- ----------------------------
DROP TABLE IF EXISTS `cases`;
CREATE TABLE `cases`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffID` int(11) NOT NULL,
  `status` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `createddate` date NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 170 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cases
-- ----------------------------
INSERT INTO `cases` VALUES (161, 4, 'Case-Bio', '2020-09-05');

-- ----------------------------
-- Table structure for contractor
-- ----------------------------
DROP TABLE IF EXISTS `contractor`;
CREATE TABLE `contractor`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `funeralhome` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `statelicense` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `stateissued` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `bodypickkup` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `embalm` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of contractor
-- ----------------------------
INSERT INTO `contractor` VALUES (1, 'test', 'Funeral Home edit test', 'bbbb', 'ccccc', 'dddddd', 2, 1, 2, '65465', 'gggggggg', 'test@test.com', '(444) 444-4444', '(888) 888-8888', 'N', 'Y');

-- ----------------------------
-- Table structure for dropdown_ancestry
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_ancestry`;
CREATE TABLE `dropdown_ancestry`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_ancestry
-- ----------------------------
INSERT INTO `dropdown_ancestry` VALUES (2, 'anc2');
INSERT INTO `dropdown_ancestry` VALUES (3, 'dsfasdf');
INSERT INTO `dropdown_ancestry` VALUES (4, 'gggg');
INSERT INTO `dropdown_ancestry` VALUES (5, 'tttt');

-- ----------------------------
-- Table structure for dropdown_cemetery
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_cemetery`;
CREATE TABLE `dropdown_cemetery`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_cemetery
-- ----------------------------
INSERT INTO `dropdown_cemetery` VALUES (1, 'fooling');

-- ----------------------------
-- Table structure for dropdown_citizenship
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_citizenship`;
CREATE TABLE `dropdown_citizenship`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_citizenship
-- ----------------------------
INSERT INTO `dropdown_citizenship` VALUES (4, 'citizenship_1');
INSERT INTO `dropdown_citizenship` VALUES (5, 'citizenship_2');

-- ----------------------------
-- Table structure for dropdown_city
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_city`;
CREATE TABLE `dropdown_city`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_city
-- ----------------------------
INSERT INTO `dropdown_city` VALUES (1, 'New York');
INSERT INTO `dropdown_city` VALUES (2, 'Washington');
INSERT INTO `dropdown_city` VALUES (3, 'London');

-- ----------------------------
-- Table structure for dropdown_college
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_college`;
CREATE TABLE `dropdown_college`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_college
-- ----------------------------
INSERT INTO `dropdown_college` VALUES (1, 'Cam college');
INSERT INTO `dropdown_college` VALUES (2, 'London university');

-- ----------------------------
-- Table structure for dropdown_county
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_county`;
CREATE TABLE `dropdown_county`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_county
-- ----------------------------
INSERT INTO `dropdown_county` VALUES (1, 'USA');
INSERT INTO `dropdown_county` VALUES (2, 'UK');

-- ----------------------------
-- Table structure for dropdown_funeralmemorial
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_funeralmemorial`;
CREATE TABLE `dropdown_funeralmemorial`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_funeralmemorial
-- ----------------------------
INSERT INTO `dropdown_funeralmemorial` VALUES (1, 'funeralmemorial_1');

-- ----------------------------
-- Table structure for dropdown_funstatus
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_funstatus`;
CREATE TABLE `dropdown_funstatus`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_funstatus
-- ----------------------------
INSERT INTO `dropdown_funstatus` VALUES (2, 'Paid');
INSERT INTO `dropdown_funstatus` VALUES (3, 'Demo');

-- ----------------------------
-- Table structure for dropdown_graduatename
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_graduatename`;
CREATE TABLE `dropdown_graduatename`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_graduatename
-- ----------------------------
INSERT INTO `dropdown_graduatename` VALUES (1, 'stepone');
INSERT INTO `dropdown_graduatename` VALUES (2, 'step2');

-- ----------------------------
-- Table structure for dropdown_highschool
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_highschool`;
CREATE TABLE `dropdown_highschool`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_highschool
-- ----------------------------
INSERT INTO `dropdown_highschool` VALUES (1, 'chicago school');

-- ----------------------------
-- Table structure for dropdown_honorific
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_honorific`;
CREATE TABLE `dropdown_honorific`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_honorific
-- ----------------------------
INSERT INTO `dropdown_honorific` VALUES (21, 'Dr');
INSERT INTO `dropdown_honorific` VALUES (22, 'General');
INSERT INTO `dropdown_honorific` VALUES (23, 'Marshal');
INSERT INTO `dropdown_honorific` VALUES (24, 'depolma');

-- ----------------------------
-- Table structure for dropdown_lastname
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_lastname`;
CREATE TABLE `dropdown_lastname`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_lastname
-- ----------------------------
INSERT INTO `dropdown_lastname` VALUES (1, 'smith');
INSERT INTO `dropdown_lastname` VALUES (2, 'Johnson');
INSERT INTO `dropdown_lastname` VALUES (3, 'William');
INSERT INTO `dropdown_lastname` VALUES (4, 'Mic');
INSERT INTO `dropdown_lastname` VALUES (5, 'Mike');
INSERT INTO `dropdown_lastname` VALUES (7, 'Doe');

-- ----------------------------
-- Table structure for dropdown_militarybranch
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_militarybranch`;
CREATE TABLE `dropdown_militarybranch`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_militarybranch
-- ----------------------------
INSERT INTO `dropdown_militarybranch` VALUES (1, 'Boss');
INSERT INTO `dropdown_militarybranch` VALUES (2, 'seaforce');
INSERT INTO `dropdown_militarybranch` VALUES (3, 'tanker');
INSERT INTO `dropdown_militarybranch` VALUES (4, 'horser');
INSERT INTO `dropdown_militarybranch` VALUES (5, 'Navy');

-- ----------------------------
-- Table structure for dropdown_militaryservicehonors
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_militaryservicehonors`;
CREATE TABLE `dropdown_militaryservicehonors`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_militaryservicehonors
-- ----------------------------
INSERT INTO `dropdown_militaryservicehonors` VALUES (1, 'Purple Heart');
INSERT INTO `dropdown_militaryservicehonors` VALUES (3, 'Silver star');
INSERT INTO `dropdown_militaryservicehonors` VALUES (4, 'Medal of valor');
INSERT INTO `dropdown_militaryservicehonors` VALUES (6, 'Bronze Star');

-- ----------------------------
-- Table structure for dropdown_occupation
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_occupation`;
CREATE TABLE `dropdown_occupation`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_occupation
-- ----------------------------
INSERT INTO `dropdown_occupation` VALUES (1, 'occupation');
INSERT INTO `dropdown_occupation` VALUES (2, 'occupation2');

-- ----------------------------
-- Table structure for dropdown_plan
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_plan`;
CREATE TABLE `dropdown_plan`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_plan
-- ----------------------------
INSERT INTO `dropdown_plan` VALUES (4, 'Monthly Payments');
INSERT INTO `dropdown_plan` VALUES (5, 'Installment');

-- ----------------------------
-- Table structure for dropdown_race
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_race`;
CREATE TABLE `dropdown_race`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_race
-- ----------------------------
INSERT INTO `dropdown_race` VALUES (4, 'race1');
INSERT INTO `dropdown_race` VALUES (5, 'race2');

-- ----------------------------
-- Table structure for dropdown_rank
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_rank`;
CREATE TABLE `dropdown_rank`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_rank
-- ----------------------------
INSERT INTO `dropdown_rank` VALUES (2, 'rank1');
INSERT INTO `dropdown_rank` VALUES (3, 'rank2');

-- ----------------------------
-- Table structure for dropdown_reasonfor
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_reasonfor`;
CREATE TABLE `dropdown_reasonfor`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_reasonfor
-- ----------------------------
INSERT INTO `dropdown_reasonfor` VALUES (7, 'sadfdsf');
INSERT INTO `dropdown_reasonfor` VALUES (8, 'unknown');
INSERT INTO `dropdown_reasonfor` VALUES (9, 'test');
INSERT INTO `dropdown_reasonfor` VALUES (10, 'Required by law');
INSERT INTO `dropdown_reasonfor` VALUES (11, 'reason1 for test');

-- ----------------------------
-- Table structure for dropdown_relationship
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_relationship`;
CREATE TABLE `dropdown_relationship`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_relationship
-- ----------------------------
INSERT INTO `dropdown_relationship` VALUES (1, 'mate');
INSERT INTO `dropdown_relationship` VALUES (2, 'Colleague');

-- ----------------------------
-- Table structure for dropdown_religion
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_religion`;
CREATE TABLE `dropdown_religion`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_religion
-- ----------------------------
INSERT INTO `dropdown_religion` VALUES (1, 'rel1');
INSERT INTO `dropdown_religion` VALUES (2, 'rel2');

-- ----------------------------
-- Table structure for dropdown_state
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_state`;
CREATE TABLE `dropdown_state`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_state
-- ----------------------------
INSERT INTO `dropdown_state` VALUES (1, 'United States');
INSERT INTO `dropdown_state` VALUES (2, 'UK');

-- ----------------------------
-- Table structure for dropdown_statementcategories
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_statementcategories`;
CREATE TABLE `dropdown_statementcategories`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tablename` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_statementcategories
-- ----------------------------
INSERT INTO `dropdown_statementcategories` VALUES (1, 'Professional Services', 'statement_professional');
INSERT INTO `dropdown_statementcategories` VALUES (2, 'Facilites & Equipment', 'statement_facilities');
INSERT INTO `dropdown_statementcategories` VALUES (3, 'Automotive & Equipment', 'statement_automotive');
INSERT INTO `dropdown_statementcategories` VALUES (4, 'Charges of Merchandise Selected', 'statement_chargesofmerchandise');
INSERT INTO `dropdown_statementcategories` VALUES (5, 'Changes for Services Selected', 'statement_changesforservices');
INSERT INTO `dropdown_statementcategories` VALUES (6, 'Total Special Charges', 'statement_totalspecialcharges');
INSERT INTO `dropdown_statementcategories` VALUES (7, 'Cash Advanced', 'statement_cashadvanced');
INSERT INTO `dropdown_statementcategories` VALUES (8, 'Summary of Charges', 'statement_summaryofcharges');
INSERT INTO `dropdown_statementcategories` VALUES (9, 'Total Amount Due', 'statement_totalamountdue');
INSERT INTO `dropdown_statementcategories` VALUES (10, 'Reason For', 'statement_reasonfor');

-- ----------------------------
-- Table structure for dropdown_status
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_status`;
CREATE TABLE `dropdown_status`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_status
-- ----------------------------
INSERT INTO `dropdown_status` VALUES (1, 'Pre-Need');
INSERT INTO `dropdown_status` VALUES (2, 'At-Need');
INSERT INTO `dropdown_status` VALUES (3, 'First-Call');
INSERT INTO `dropdown_status` VALUES (4, 'Case-Bio');
INSERT INTO `dropdown_status` VALUES (5, 'Final-Arrangements');

-- ----------------------------
-- Table structure for dropdown_statusdt
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_statusdt`;
CREATE TABLE `dropdown_statusdt`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_statusdt
-- ----------------------------
INSERT INTO `dropdown_statusdt` VALUES (1, 'Body Pickup');
INSERT INTO `dropdown_statusdt` VALUES (2, 'Embalming');
INSERT INTO `dropdown_statusdt` VALUES (3, 'Preparation for Visitation');
INSERT INTO `dropdown_statusdt` VALUES (4, 'Preparation for Final Disposition');

-- ----------------------------
-- Table structure for dropdown_suffix
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_suffix`;
CREATE TABLE `dropdown_suffix`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_suffix
-- ----------------------------
INSERT INTO `dropdown_suffix` VALUES (4, 'Miss');
INSERT INTO `dropdown_suffix` VALUES (6, 'Sr');
INSERT INTO `dropdown_suffix` VALUES (7, 'sir');
INSERT INTO `dropdown_suffix` VALUES (8, 'Love');
INSERT INTO `dropdown_suffix` VALUES (10, 'Jr');

-- ----------------------------
-- Table structure for dropdown_township
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_township`;
CREATE TABLE `dropdown_township`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_township
-- ----------------------------
INSERT INTO `dropdown_township` VALUES (1, 'Boss');

-- ----------------------------
-- Table structure for dropdown_typeofdischarge
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_typeofdischarge`;
CREATE TABLE `dropdown_typeofdischarge`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_typeofdischarge
-- ----------------------------
INSERT INTO `dropdown_typeofdischarge` VALUES (1, 'typeofdischarge1');
INSERT INTO `dropdown_typeofdischarge` VALUES (2, 'typeofdischarge2');

-- ----------------------------
-- Table structure for dropdown_undergraduatename
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_undergraduatename`;
CREATE TABLE `dropdown_undergraduatename`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_undergraduatename
-- ----------------------------
INSERT INTO `dropdown_undergraduatename` VALUES (1, 'fool');
INSERT INTO `dropdown_undergraduatename` VALUES (2, 'fooling around');
INSERT INTO `dropdown_undergraduatename` VALUES (3, 'TEST grade');

-- ----------------------------
-- Table structure for dropdown_warcampaign
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_warcampaign`;
CREATE TABLE `dropdown_warcampaign`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_warcampaign
-- ----------------------------
INSERT INTO `dropdown_warcampaign` VALUES (1, 'the world war 1');
INSERT INTO `dropdown_warcampaign` VALUES (2, 'the world war 2');

-- ----------------------------
-- Table structure for dropdown_zip
-- ----------------------------
DROP TABLE IF EXISTS `dropdown_zip`;
CREATE TABLE `dropdown_zip`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dropdown_zip
-- ----------------------------
INSERT INTO `dropdown_zip` VALUES (1, '94203');
INSERT INTO `dropdown_zip` VALUES (2, '94207');
INSERT INTO `dropdown_zip` VALUES (3, '94210');

-- ----------------------------
-- Table structure for events
-- ----------------------------
DROP TABLE IF EXISTS `events`;
CREATE TABLE `events`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `image` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `start` datetime(0) NOT NULL,
  `end` datetime(0) NOT NULL,
  `url` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `color` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 379 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of events
-- ----------------------------
INSERT INTO `events` VALUES (369, 'test', '96350d48a3b84813f747e40d436fe9f0.png', 'test', '2020-07-16 02:55:00', '2020-07-24 15:50:00', 'https://www.myinjuryattorney.com/', '#5367ce');
INSERT INTO `events` VALUES (370, 'test2', '', '', '2020-07-16 15:35:00', '2020-07-31 10:35:00', 'https://www.myinjuryattorney.com/', '#4b6343');
INSERT INTO `events` VALUES (372, 'test2', '', 'payment integration', '2020-08-12 14:55:00', '2020-08-14 17:55:00', 'Tomicap.com', '#55ce53');
INSERT INTO `events` VALUES (373, 'test', '', 'superadmin &Todolist', '2020-08-26 21:00:00', '2020-08-28 19:00:00', 'Tomicap.com', '#ce53c2');
INSERT INTO `events` VALUES (374, 'test2', '', 'Superadmin&Todolist', '2020-08-31 19:00:00', '2020-09-01 19:00:00', 'ezmmsoft.com', '#495dc7');
INSERT INTO `events` VALUES (376, 'test2', '', 'test', '2020-08-19 09:05:00', '2020-08-19 19:05:00', 'ezmmsoft.com', '#5367ce');
INSERT INTO `events` VALUES (378, 'test2', '', 'superadmin and todolist', '2020-08-13 19:10:00', '2020-08-15 13:25:00', 'ezmmsoft.com', '#5367ce');

-- ----------------------------
-- Table structure for final_arrange_beauticianbarber
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_beauticianbarber`;
CREATE TABLE `final_arrange_beauticianbarber`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `gender` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_beauticianbarber
-- ----------------------------
INSERT INTO `final_arrange_beauticianbarber` VALUES (7, 'test', 'bb33', 'addbb1', 'addbb2', 1, 1, 1, 'bb1@test.com', '(888) 888-8888', 'Barber');
INSERT INTO `final_arrange_beauticianbarber` VALUES (8, 'test', 'bb22', 'addbb1', 'addbb2', 1, 1, 1, 'bb1@test.com', '(888) 888-8888', 'Beautician');
INSERT INTO `final_arrange_beauticianbarber` VALUES (9, 'test', 'bbtest', 'addbbtest1', 'addbbtest2', 2, 1, 2, 'bbtest@test.com', '(789) 546-1233', 'Barber');

-- ----------------------------
-- Table structure for final_arrange_cemetery
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_cemetery`;
CREATE TABLE `final_arrange_cemetery`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `contact` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_cemetery
-- ----------------------------
INSERT INTO `final_arrange_cemetery` VALUES (1, 'test', 'clergy1', NULL, '2222222', '3333333', 1, 2, 3, 'test@test.com', NULL, '(777) 777-7777');
INSERT INTO `final_arrange_cemetery` VALUES (2, 'test', 'clergy2', NULL, 'address1', 'address2', 2, 1, 2, 'vo@test.com', NULL, '(744) 444-4444');

-- ----------------------------
-- Table structure for final_arrange_children
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_children`;
CREATE TABLE `final_arrange_children`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `dob` date NOT NULL,
  `relationship` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_children
-- ----------------------------
INSERT INTO `final_arrange_children` VALUES (1, 'test', '111111', '2222222', '3333333', 1, 2, 3, '2020-07-07', 2, 'test@test.com', '(777) 777-7777', '(888) 888-8888');

-- ----------------------------
-- Table structure for final_arrange_church
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_church`;
CREATE TABLE `final_arrange_church`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Church` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ClergyName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `Email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_church
-- ----------------------------
INSERT INTO `final_arrange_church` VALUES (1, 'test', 'churchedittest1', 'bbbbb', 'ccccccc', 'dddddddd', 2, 2, 2, 'test@test.com', '(222) 222-2222', '(333) 333-3333');
INSERT INTO `final_arrange_church` VALUES (2, 'test', 'to final', 'bbbbbb', 'ccccc', 'dddddd', 1, 1, 2, 'test@test.com', '(222) 222-2222', '(333) 333-3333');
INSERT INTO `final_arrange_church` VALUES (3, 'test', 'to final', 'bbbbbb', 'ccccc', 'dddddd', 1, 1, 2, 'test@test.com', '(222) 222-2222', '(333) 333-3333');

-- ----------------------------
-- Table structure for final_arrange_clergy
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_clergy`;
CREATE TABLE `final_arrange_clergy`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_clergy
-- ----------------------------
INSERT INTO `final_arrange_clergy` VALUES (1, 'test', 'clergy1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777');
INSERT INTO `final_arrange_clergy` VALUES (2, 'test', 'clergy2', 'address1', 'address2', 2, 1, 2, 'vo@test.com', '(744) 444-4444');

-- ----------------------------
-- Table structure for final_arrange_colorguard
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_colorguard`;
CREATE TABLE `final_arrange_colorguard`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_colorguard
-- ----------------------------
INSERT INTO `final_arrange_colorguard` VALUES (1, 'test', 'clergy1', '2222222', '3333333', 1, 2, 3, 'test@test.com', NULL, '(777) 777-7777');
INSERT INTO `final_arrange_colorguard` VALUES (2, 'test', 'clergy2', 'address1', 'address2', 2, 1, 2, 'vo@test.com', NULL, '(744) 444-4444');
INSERT INTO `final_arrange_colorguard` VALUES (3, 'test', 'guard1', 'address1', 'address2', 2, 1, 1, 'test@test.com', '(555) 555-5555', '(666) 666-6666');

-- ----------------------------
-- Table structure for final_arrange_cosmetologist
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_cosmetologist`;
CREATE TABLE `final_arrange_cosmetologist`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_cosmetologist
-- ----------------------------
INSERT INTO `final_arrange_cosmetologist` VALUES (1, 'test', 'cosmetologist1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777');
INSERT INTO `final_arrange_cosmetologist` VALUES (2, 'test', 'cosmetologist edit test', 'address1', 'address2', 2, 2, 1, 'vo@test.com', '(744) 444-4444');
INSERT INTO `final_arrange_cosmetologist` VALUES (3, 'test', 'cos1', 'orgaddress1', 'orgaddress2', 1, 1, 2, 'org1@test.com', '(777) 777-3333');
INSERT INTO `final_arrange_cosmetologist` VALUES (4, 'test', 'cos2', 'org2address1', 'org2address2', 2, 1, 2, 'org12@test.com', '(789) 999-9999');
INSERT INTO `final_arrange_cosmetologist` VALUES (5, 'test', 'COS1', 'addcos1', 'addcos2', 2, 1, 2, 'cos1@test.com', '(785) 462-5633');

-- ----------------------------
-- Table structure for final_arrange_distributor
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_distributor`;
CREATE TABLE `final_arrange_distributor`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_distributor
-- ----------------------------
INSERT INTO `final_arrange_distributor` VALUES (1, 'test', 'clergy1', '2222222', '3333333', 1, 2, 3, 'test@test.com', NULL, '(777) 777-7777');
INSERT INTO `final_arrange_distributor` VALUES (2, 'test', 'clergy2', 'address1', 'address2', 2, 1, 2, 'vo@test.com', NULL, '(744) 444-4444');

-- ----------------------------
-- Table structure for final_arrange_driver
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_driver`;
CREATE TABLE `final_arrange_driver`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_driver
-- ----------------------------
INSERT INTO `final_arrange_driver` VALUES (1, 'test', 'driver1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777');
INSERT INTO `final_arrange_driver` VALUES (2, 'test', 'driver2', 'address1', 'address2', 2, 1, 2, 'vo@test.com', '(744) 444-4444');

-- ----------------------------
-- Table structure for final_arrange_education
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_education`;
CREATE TABLE `final_arrange_education`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `EduHighSchool` int(11) NOT NULL,
  `EduHSGraduated` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `undergraducate` int(11) NOT NULL,
  `undergraducatedegree` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `undergraducatedegreecheck` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `graduate` int(11) NOT NULL,
  `graducatedegree` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `graducatedegreecheck` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_education
-- ----------------------------
INSERT INTO `final_arrange_education` VALUES (1, 'test', 1, 'N', 2, 'bbbbb', 'N', 2, 'dddddd', 'Y');
INSERT INTO `final_arrange_education` VALUES (2, 'test', 1, 'Y', 3, 'bbbb', 'N', 2, 'dddd', 'Y');
INSERT INTO `final_arrange_education` VALUES (3, 'test', 1, 'Y', 3, 'bbbb', 'N', 2, 'dddd', 'Y');
INSERT INTO `final_arrange_education` VALUES (4, 'test', 1, 'Y', 1, 'bbbb', 'N', 2, 'dddd', 'Y');
INSERT INTO `final_arrange_education` VALUES (6, 'test', 1, 'Y', 2, 'to final', 'N', 2, 'dddd', 'Y');

-- ----------------------------
-- Table structure for final_arrange_equipment
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_equipment`;
CREATE TABLE `final_arrange_equipment`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `resource` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `make` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `model` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `yearpurchase` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_equipment
-- ----------------------------
INSERT INTO `final_arrange_equipment` VALUES (1, 'test', 'clergy1', NULL, '2222222', '3333333', 1, 2, '(777) 777-7777');
INSERT INTO `final_arrange_equipment` VALUES (2, 'test', 'clergy2', NULL, 'address1', 'address2', 2, 1, '(744) 444-4444');

-- ----------------------------
-- Table structure for final_arrange_escort
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_escort`;
CREATE TABLE `final_arrange_escort`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_escort
-- ----------------------------
INSERT INTO `final_arrange_escort` VALUES (1, 'test', 'escort', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777');
INSERT INTO `final_arrange_escort` VALUES (2, 'test', 'escort2', 'address1', 'address2', 2, 1, 2, 'vo@test.com', '(744) 444-4444');

-- ----------------------------
-- Table structure for final_arrange_final_crematory
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_final_crematory`;
CREATE TABLE `final_arrange_final_crematory`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `PartyOfInformant` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DateOfCremation` date NOT NULL,
  `TimeOfCremation` time(0) NOT NULL,
  `WaitTimeMet` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DirectorNote` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_final_crematory
-- ----------------------------
INSERT INTO `final_arrange_final_crematory` VALUES (2, 'test', 'party1', '0000-00-00', '00:00:00', 'Y', '');

-- ----------------------------
-- Table structure for final_arrange_final_disposition
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_final_disposition`;
CREATE TABLE `final_arrange_final_disposition`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Burial` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Entombment` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Cremation` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `BurialAtSea` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DateOfFinalDisposition` date NOT NULL,
  `FinalDisposition` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CemeteryID` int(11) NOT NULL,
  `Location` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Section` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `FuneralOrMemorialServiceAtID` int(11) NOT NULL,
  `NameLotRegisteredTo` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `WhereInLotIsGraveToBeOpened` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `LotNo` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `GraveNo` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_final_disposition
-- ----------------------------
INSERT INTO `final_arrange_final_disposition` VALUES (1, 'test', 'N', 'N', 'N', 'Y', '2020-08-07', 'bbbbbbb', 1, 'cccccc', 'eeeeeee', 1, 'fffffff', 'ggggggg', 'ddddddd', 'hhhhhhhh');
INSERT INTO `final_arrange_final_disposition` VALUES (2, 'test', '', '', '', '', '2011-11-01', '222222', 1, '33333', '55555', 1, '6666', '7777', '444444', '88888');
INSERT INTO `final_arrange_final_disposition` VALUES (3, 'test', 'Y', 'Y', 'N', 'N', '2011-11-01', '222222', 1, '33333', '55555', 1, '6666', '7777', '444444', '88888');

-- ----------------------------
-- Table structure for final_arrange_florist
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_florist`;
CREATE TABLE `final_arrange_florist`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `flowershowname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_florist
-- ----------------------------
INSERT INTO `final_arrange_florist` VALUES (1, 'test', 'florist1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777', 'showname1');
INSERT INTO `final_arrange_florist` VALUES (2, 'test', 'florist2', 'address1', 'address2', 2, 1, 2, 'vo@test.com', '(744) 444-4444', 'showname2');

-- ----------------------------
-- Table structure for final_arrange_funeral_home
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_funeral_home`;
CREATE TABLE `final_arrange_funeral_home`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `contact` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `license` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_funeral_home
-- ----------------------------
INSERT INTO `final_arrange_funeral_home` VALUES (1, 'test', 'vocalist_1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777', '', '');
INSERT INTO `final_arrange_funeral_home` VALUES (2, 'test', 'vocalist_edittest', 'address1', 'address2', 2, 1, 2, 'vo@test.com', '(744) 444-4444', 'dsfa', '1235');
INSERT INTO `final_arrange_funeral_home` VALUES (3, 'test', 'vocalist_111', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777', '', '');
INSERT INTO `final_arrange_funeral_home` VALUES (4, 'test', 'vocalist_1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777', NULL, NULL);
INSERT INTO `final_arrange_funeral_home` VALUES (5, 'test', 'vocalist_1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777', 'sfs', NULL);
INSERT INTO `final_arrange_funeral_home` VALUES (6, 'test', 'vocalist_1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777', 'contact1', NULL);
INSERT INTO `final_arrange_funeral_home` VALUES (7, 'test', 'vocalist_1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777', 'contact1', '11111');
INSERT INTO `final_arrange_funeral_home` VALUES (8, 'test', 'vocalist_1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777', 'contact1', '11111');
INSERT INTO `final_arrange_funeral_home` VALUES (9, 'test', 'vocalist_1', '2222222', '3333333', 3, 2, 3, 'test@test.com', '(777) 777-7777', 'contact1', '11111');

-- ----------------------------
-- Table structure for final_arrange_grand_children
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_grand_children`;
CREATE TABLE `final_arrange_grand_children`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `dob` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `relationship` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_grand_children
-- ----------------------------
INSERT INTO `final_arrange_grand_children` VALUES (1, 'test', 'aaaaa', 'zzzzz', 'ddddddd', 0, 0, 11111, '', 0, 'test@test.com', '(222) 222-2222', '(333) 333-3333');

-- ----------------------------
-- Table structure for final_arrange_honorarypallbearer
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_honorarypallbearer`;
CREATE TABLE `final_arrange_honorarypallbearer`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for final_arrange_manufacturer
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_manufacturer`;
CREATE TABLE `final_arrange_manufacturer`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_manufacturer
-- ----------------------------
INSERT INTO `final_arrange_manufacturer` VALUES (1, 'test', 'clergy1', '2222222', '3333333', 1, 2, 3, 'test@test.com', NULL, '(777) 777-7777');
INSERT INTO `final_arrange_manufacturer` VALUES (2, 'test', 'clergy2', 'address1', 'address2', 2, 1, 2, 'vo@test.com', NULL, '(744) 444-4444');
INSERT INTO `final_arrange_manufacturer` VALUES (3, 'test', 'manu', 'add1', 'add2', 1, 1, 2, 'tewst@test.com', '(666) 666-6666', '(555) 555-5555');

-- ----------------------------
-- Table structure for final_arrange_marital
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_marital`;
CREATE TABLE `final_arrange_marital`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `maritalstatus` int(11) NOT NULL,
  `placeofmarriage` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dateofmarriage` date NOT NULL,
  `spousesname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Spousedeceased` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dateofdeath` date NOT NULL,
  `spousesplaceofdeath` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_marital
-- ----------------------------
INSERT INTO `final_arrange_marital` VALUES (4, 'test', 3, 'TESTE', '2020-07-11', 'bbbb', '', '2020-07-18', 'cccccc');
INSERT INTO `final_arrange_marital` VALUES (6, 'test', 3, 'to final arrangement', '2020-07-11', 'bbbb', '', '2020-07-18', 'cccccc');

-- ----------------------------
-- Table structure for final_arrange_military_service
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_military_service`;
CREATE TABLE `final_arrange_military_service`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `honor1` int(11) NOT NULL,
  `WarCampaignID` int(11) NULL DEFAULT NULL,
  `contacted` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `rank` int(11) NULL DEFAULT NULL,
  `honor2` int(11) NULL DEFAULT NULL,
  `dob` date NULL DEFAULT NULL,
  `dod` date NULL DEFAULT NULL,
  `flag` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `cologuard` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `caission` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `inscription` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gravemarker` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `draped` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `folded` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_military_service
-- ----------------------------
INSERT INTO `final_arrange_military_service` VALUES (16, 'test', 1, 2, 'contacttest', 'Sorry', 2, 3, '1989-01-01', '2020-08-03', 'Y', 'N', 'N', '                We will miss her...', 'Y', NULL, NULL);
INSERT INTO `final_arrange_military_service` VALUES (21, 'test', 1, 0, 'contact4', '', 0, 0, '0000-00-00', '0000-00-00', 'Y', 'N', 'Y', '                ', 'Y', 'N', 'N');

-- ----------------------------
-- Table structure for final_arrange_newspaper
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_newspaper`;
CREATE TABLE `final_arrange_newspaper`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `faxnumber` int(11) NOT NULL,
  `website` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `password` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `deadline1` time(0) NOT NULL,
  `deadline2` time(0) NOT NULL,
  `contact` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `obituary` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_newspaper
-- ----------------------------
INSERT INTO `final_arrange_newspaper` VALUES (1, 'test', 'clergy1', NULL, 2222222, '3333333', '1', '00:00:02', '00:00:03', 'test@test.com', NULL);
INSERT INTO `final_arrange_newspaper` VALUES (2, 'test', 'clergy2', NULL, 0, 'address2', '2', '00:00:01', '00:00:02', 'vo@test.com', NULL);

-- ----------------------------
-- Table structure for final_arrange_organist
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_organist`;
CREATE TABLE `final_arrange_organist`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_organist
-- ----------------------------
INSERT INTO `final_arrange_organist` VALUES (1, 'test', 'organist1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777');
INSERT INTO `final_arrange_organist` VALUES (2, 'test', 'organist2', 'address1', 'address2', 2, 1, 2, 'vo@test.com', '(744) 444-4444');
INSERT INTO `final_arrange_organist` VALUES (3, 'test', 'org1', 'orgaddress1', 'orgaddress2', 1, 1, 2, 'org1@test.com', '(777) 777-3333');
INSERT INTO `final_arrange_organist` VALUES (4, 'test', 'org2', 'org2address1', 'org2address2', 2, 1, 2, 'org12@test.com', '(789) 999-9999');

-- ----------------------------
-- Table structure for final_arrange_pallbearer
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_pallbearer`;
CREATE TABLE `final_arrange_pallbearer`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for final_arrange_parents
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_parents`;
CREATE TABLE `final_arrange_parents`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ParentDeceasedFathersDOB` date NOT NULL,
  `ParentsDeceasedFathersDOD` date NOT NULL,
  `ParentsDeceasedMothersDOB` date NOT NULL,
  `ParentsDeceasedMothersDOD` date NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_parents
-- ----------------------------
INSERT INTO `final_arrange_parents` VALUES (1, 'test', '2011-11-01', '2020-08-21', '2020-08-04', '2020-08-18');
INSERT INTO `final_arrange_parents` VALUES (2, 'test', '2020-07-25', '2020-07-14', '2020-07-13', '2020-01-28');
INSERT INTO `final_arrange_parents` VALUES (3, 'test', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO `final_arrange_parents` VALUES (4, 'test', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO `final_arrange_parents` VALUES (5, 'test', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO `final_arrange_parents` VALUES (6, 'test', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');
INSERT INTO `final_arrange_parents` VALUES (7, 'test', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');

-- ----------------------------
-- Table structure for final_arrange_place_of_worship
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_place_of_worship`;
CREATE TABLE `final_arrange_place_of_worship`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `PlaceOfWorship` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ClergyName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_place_of_worship
-- ----------------------------
INSERT INTO `final_arrange_place_of_worship` VALUES (1, 'test', 'worship edit test', '222222', '3333333', '4444444', 2, 2, 2, 'test@test.com', '(777) 777-7777', '(888) 888-8888');
INSERT INTO `final_arrange_place_of_worship` VALUES (2, 'test', 'to final', '2222222', '3333333', '444444', 1, 1, 2, 'aaa@aaa.com', '(777) 777-7788', '(888) 888-8888');

-- ----------------------------
-- Table structure for final_arrange_salesperson
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_salesperson`;
CREATE TABLE `final_arrange_salesperson`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_salesperson
-- ----------------------------
INSERT INTO `final_arrange_salesperson` VALUES (1, 'test', 'clergy1', '2222222', '3333333', 1, 2, 3, 'test@test.com', NULL, '(777) 777-7777');
INSERT INTO `final_arrange_salesperson` VALUES (2, 'test', 'clergy2', 'address1', 'address2', 2, 1, 2, 'vo@test.com', NULL, '(744) 444-4444');

-- ----------------------------
-- Table structure for final_arrange_service
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_service`;
CREATE TABLE `final_arrange_service`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `StartDate` date NOT NULL,
  `StartTime` time(0) NOT NULL,
  `EndDate` date NOT NULL,
  `EndTime` time(0) NOT NULL,
  `ServiceName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ServiceAddress` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `Telephone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_service
-- ----------------------------
INSERT INTO `final_arrange_service` VALUES (3, 'test', '2020-08-10', '20:52:00', '2020-08-26', '20:51:00', 'place11', 'add1', 1, 2, '(666) 666-6666');
INSERT INTO `final_arrange_service` VALUES (4, 'test', '2020-08-10', '20:52:00', '2020-08-26', '20:51:00', 'place112', 'add1', 1, 2, '(666) 666-6666');
INSERT INTO `final_arrange_service` VALUES (5, 'test', '2020-08-10', '20:52:00', '2020-08-26', '20:51:00', 'place113', 'add1', 1, 2, '(666) 666-6666');
INSERT INTO `final_arrange_service` VALUES (6, 'test', '2020-08-10', '20:52:00', '2020-08-26', '20:51:00', 'place1123', 'add1', 1, 2, '(666) 666-6666');
INSERT INTO `final_arrange_service` VALUES (7, 'test', '2020-08-10', '20:52:00', '2020-08-26', '20:51:00', 'place11234', 'add1', 1, 2, '(666) 666-6666');
INSERT INTO `final_arrange_service` VALUES (8, 'test', '2020-08-10', '20:52:00', '2020-08-26', '20:51:00', 'place1136', 'add1', 1, 2, '(666) 666-6666');
INSERT INTO `final_arrange_service` VALUES (9, 'test', '2020-08-10', '20:52:00', '2020-08-26', '20:51:00', 'place11367', 'add1', 1, 2, '(666) 666-6666');
INSERT INTO `final_arrange_service` VALUES (10, 'test', '2020-08-10', '20:52:00', '2020-08-26', '20:51:00', 'place18', 'add1', 1, 2, '(666) 666-6666');
INSERT INTO `final_arrange_service` VALUES (11, 'test', '2020-07-29', '20:52:00', '2020-07-28', '20:51:00', 'place113678', 'add1', 1, 1, '(666) 666-6666');
INSERT INTO `final_arrange_service` VALUES (12, 'test', '2020-07-29', '20:52:00', '2020-07-28', '20:51:00', 'place1136788', 'add1', 1, 1, '(666) 666-6666');
INSERT INTO `final_arrange_service` VALUES (13, 'test', '2020-07-29', '20:52:00', '2020-07-28', '20:51:00', 'place8', 'add1', 1, 1, '(666) 666-6666');

-- ----------------------------
-- Table structure for final_arrange_sexton
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_sexton`;
CREATE TABLE `final_arrange_sexton`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_sexton
-- ----------------------------
INSERT INTO `final_arrange_sexton` VALUES (1, 'test', 'sexton1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777');
INSERT INTO `final_arrange_sexton` VALUES (2, 'test', 'sexton2', 'address1', 'address2', 2, 1, 2, 'vo@test.com', '(744) 444-4444');
INSERT INTO `final_arrange_sexton` VALUES (3, 'test', '', '', '', 0, 0, 0, '', '');
INSERT INTO `final_arrange_sexton` VALUES (4, 'test', '', '', '', 0, 0, 0, '', '');

-- ----------------------------
-- Table structure for final_arrange_visitation
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_visitation`;
CREATE TABLE `final_arrange_visitation`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `StartDate` date NOT NULL,
  `StartTime` time(0) NOT NULL,
  `EndDate` date NOT NULL,
  `EndTime` time(0) NOT NULL,
  `VisitationName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `VisitationAddress` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 59 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_visitation
-- ----------------------------
INSERT INTO `final_arrange_visitation` VALUES (56, 'test', '2020-08-05', '02:16:00', '2020-08-14', '02:15:00', 'test visitation', 'test address', 2, 1, '(555) 555-5555');
INSERT INTO `final_arrange_visitation` VALUES (58, 'test', '2020-08-04', '02:16:00', '2020-08-14', '02:15:00', 'test visitatio_edittest', 'test address', 2, 1, '(555) 555-5555');

-- ----------------------------
-- Table structure for final_arrange_vocalist
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_vocalist`;
CREATE TABLE `final_arrange_vocalist`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_vocalist
-- ----------------------------
INSERT INTO `final_arrange_vocalist` VALUES (1, 'test', 'vocalist_1', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777');
INSERT INTO `final_arrange_vocalist` VALUES (2, 'test', 'vocalist1', 'address1', 'address2', 2, 1, 2, 'vo@test.com', '(744) 444-4444');
INSERT INTO `final_arrange_vocalist` VALUES (3, 'test', 'vocalist_111', '2222222', '3333333', 1, 2, 3, 'test@test.com', '(777) 777-7777');
INSERT INTO `final_arrange_vocalist` VALUES (4, 'test', 'asdf', 'asdf', 'asdf', 1, 1, 1, 'asdf@test.com', '(555) 555-5555');

-- ----------------------------
-- Table structure for final_arrange_volunteer
-- ----------------------------
DROP TABLE IF EXISTS `final_arrange_volunteer`;
CREATE TABLE `final_arrange_volunteer`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of final_arrange_volunteer
-- ----------------------------
INSERT INTO `final_arrange_volunteer` VALUES (2, 'test', 'volunteer2', 'address1', 'address1', 2, 1, 2, 'vo@test.com', '(744) 444-4444', '(744) 444-4444');
INSERT INTO `final_arrange_volunteer` VALUES (3, 'test', 'volunteertest2', 'address1', 'address1', 1, 1, 1, 'test@test.com', '(333) 333-3333', '(333) 333-3333');

-- ----------------------------
-- Table structure for first_call_location
-- ----------------------------
DROP TABLE IF EXISTS `first_call_location`;
CREATE TABLE `first_call_location`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `location` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `contact` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Address1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `City` int(11) NOT NULL,
  `States` int(11) NOT NULL,
  `Zip` int(11) NOT NULL,
  `Email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `dod` date NULL DEFAULT NULL,
  `tode` time(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of first_call_location
-- ----------------------------
INSERT INTO `first_call_location` VALUES (1, 'test', 'locataion edit test', 'contactt', 'ad', 'ad2', 1, 1, 2, 'test@test.com', '(666) 666-6666', '2020-08-16', '18:50:00');

-- ----------------------------
-- Table structure for first_call_permission
-- ----------------------------
DROP TABLE IF EXISTS `first_call_permission`;
CREATE TABLE `first_call_permission`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `pickup` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `embalm` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of first_call_permission
-- ----------------------------
INSERT INTO `first_call_permission` VALUES (1, 'test', '', 'Y');

-- ----------------------------
-- Table structure for first_call_person_call
-- ----------------------------
DROP TABLE IF EXISTS `first_call_person_call`;
CREATE TABLE `first_call_person_call`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `WhoCalled` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Address2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `City` int(11) NOT NULL,
  `States` int(11) NOT NULL,
  `Zip` int(11) NOT NULL,
  `Email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dayphone` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `eveningphone` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of first_call_person_call
-- ----------------------------
INSERT INTO `first_call_person_call` VALUES (12, 'test', 'jacksontest edit', 'add1', '', 2, 1, 1, 'test@test.com', '(777) 777-7777', '(888) 888-8888');

-- ----------------------------
-- Table structure for first_call_physician
-- ----------------------------
DROP TABLE IF EXISTS `first_call_physician`;
CREATE TABLE `first_call_physician`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Physician` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ContactName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `City` int(11) NOT NULL,
  `States` int(11) NOT NULL,
  `Zip` int(11) NOT NULL,
  `Email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `officephone` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cellphone` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `pager` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of first_call_physician
-- ----------------------------
INSERT INTO `first_call_physician` VALUES (1, 'test', 'testPhy', '22222222', '333333', '4444444', 2, 1, 2, 'test@test.com', '(777) 777-7777', '(888) 888-8888', '(999) 999-9999');
INSERT INTO `first_call_physician` VALUES (2, 'test', 'testPhy test edit', '22222222', '333333', '4444444', 3, 2, 1, 'test@test.com', '(777) 777-7777', '(888) 888-8888', '(999) 999-9999');

-- ----------------------------
-- Table structure for first_call_pi
-- ----------------------------
DROP TABLE IF EXISTS `first_call_pi`;
CREATE TABLE `first_call_pi`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caseID` int(11) NOT NULL,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `honorific` int(11) NOT NULL,
  `firstName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `middleName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `lastName` int(11) NOT NULL,
  `suffix` int(11) NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `township` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zipCode` int(11) NOT NULL,
  `country` int(11) NOT NULL,
  `nickName` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `gender` varchar(8) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SSN` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dateOfBirth` date NOT NULL,
  `dateOfDeath` date NOT NULL,
  `timeOfDeath` time(0) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of first_call_pi
-- ----------------------------
INSERT INTO `first_call_pi` VALUES (5, 0, 'test', 22, 'aaaa', 'bbb', 1, 4, 'dddd', 'eeeee', 1, 1, 1, 2, 1, 'iiiiii', 'Male', '222-22-2222', 'test@test.com', '(333) 333-3333', '0000-00-00', '2020-07-18', '10:44:00');
INSERT INTO `first_call_pi` VALUES (6, 0, 'test', 22, 'danielhan', 'bbb', 1, 4, 'dddd', 'eeeee', 1, 1, 1, 2, 1, 'iiiiii', 'Male', '222-22-2222', 'test@test.com', '(888) 888-8888', '0000-00-00', '2020-07-18', '10:44:00');

-- ----------------------------
-- Table structure for first_call_place_of_death
-- ----------------------------
DROP TABLE IF EXISTS `first_call_place_of_death`;
CREATE TABLE `first_call_place_of_death`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Physician` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ContactName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `City` int(11) NOT NULL,
  `States` int(11) NOT NULL,
  `Zip` int(11) NOT NULL,
  `Email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `officephone` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of first_call_place_of_death
-- ----------------------------
INSERT INTO `first_call_place_of_death` VALUES (1, 'test', 'test place edit test2', 'contactname1', 'ccccc', 'ddddddd', 2, 2, 2, 'test@test.com', '(222) 222-2222');

-- ----------------------------
-- Table structure for media
-- ----------------------------
DROP TABLE IF EXISTS `media`;
CREATE TABLE `media`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `childid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Newspaper` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fax` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `website` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NUserName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Npass` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Nrate` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `WDDeadline` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `WDeadline` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NContact` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `obituraryContent` varchar(250) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of media
-- ----------------------------
INSERT INTO `media` VALUES (1, 'test', '0', 'aaaaaa', 'test@test.com', '(111) 111-1111', '(222) 222-2222', '333333333', '444444444', '$50', '12:52', '12:54', '2222222222', 'cccccccc');
INSERT INTO `media` VALUES (2, 'test', '1', '11111111', '22222222222', '(333) 333-33__', '(444) 444-44__', '555555555', '6666666', '$30', '17:58', '16:59', '7777777', '8888888888');

-- ----------------------------
-- Table structure for membership
-- ----------------------------
DROP TABLE IF EXISTS `membership`;
CREATE TABLE `membership`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `childid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `MembershipName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ContactName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `City` int(11) NOT NULL,
  `States` int(11) NOT NULL,
  `Zip` int(11) NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `URL` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of membership
-- ----------------------------
INSERT INTO `membership` VALUES (1, 'test', '0', 'aaaa', 'bbbbb', 'ccccccc', 'dddddddd', 1, 1, 2, '(222) 222-2222', 'https://test.com');

-- ----------------------------
-- Table structure for organization
-- ----------------------------
DROP TABLE IF EXISTS `organization`;
CREATE TABLE `organization`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Contact` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `City` int(11) NOT NULL,
  `States` int(11) NOT NULL,
  `Zip` int(11) NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `URL` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of organization
-- ----------------------------
INSERT INTO `organization` VALUES (1, 'test', 'aaaa', 'bbbbbbb', 'ccccc', 'ddddddd', 2, 2, 1, '(222) 222-2222', 'ffffffff');
INSERT INTO `organization` VALUES (2, 'useradmin', 'organizationedit', '22222', '33333', '44444444', 2, 2, 3, '(777) 777-777_', '88888888888');

-- ----------------------------
-- Table structure for pre_need_children
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_children`;
CREATE TABLE `pre_need_children`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `childrenid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `dob` date NOT NULL,
  `relationship` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_children
-- ----------------------------
INSERT INTO `pre_need_children` VALUES (5, 'test', '0', 'aaa', 'aaa', 'bbbbbb', 1, 2, 2, '2020-07-04', 2, 'test@test.com', '(222) 222-2222', '(333) 333-3333');
INSERT INTO `pre_need_children` VALUES (6, 'test', '1', 'bbb', '1111111', '2222222', 2, 3, 1, '2020-07-18', 1, 'test@test.com', '(666) 666-6666', '(666) 666-6666');

-- ----------------------------
-- Table structure for pre_need_church
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_church`;
CREATE TABLE `pre_need_church`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Church` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ClergyName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `Email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_church
-- ----------------------------
INSERT INTO `pre_need_church` VALUES (1, 'test', 'aaaaa', 'bbbbbb', 'ccccc', 'dddddd', 1, 1, 2, 'test@test.com', '(222) 222-2222', '(333) 333-3333');

-- ----------------------------
-- Table structure for pre_need_education
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_education`;
CREATE TABLE `pre_need_education`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `EduHighSchool` int(11) NOT NULL,
  `EduHSGraduated` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `undergraducate` int(11) NOT NULL,
  `undergraducatedegree` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `undergraducatedegreecheck` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `graduate` int(11) NOT NULL,
  `graducatedegree` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `graducatedegreecheck` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_education
-- ----------------------------
INSERT INTO `pre_need_education` VALUES (1, 'test', 1, 'Y', 2, 'to final arrangement', 'N', 2, 'dddd', 'Y');

-- ----------------------------
-- Table structure for pre_need_final_crematory
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_final_crematory`;
CREATE TABLE `pre_need_final_crematory`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `PartyOfInformant` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DateOfCremation` date NOT NULL,
  `TimeOfCremation` time(0) NOT NULL,
  `WaitTimeMet` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DirectorNote` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_final_crematory
-- ----------------------------
INSERT INTO `pre_need_final_crematory` VALUES (2, 'test', 'party1', '0000-00-00', '00:00:00', 'Y', '');

-- ----------------------------
-- Table structure for pre_need_final_disposition
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_final_disposition`;
CREATE TABLE `pre_need_final_disposition`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Burial` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Entombment` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Cremation` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `BurialAtSea` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DateOfFinalDisposition` date NOT NULL,
  `FinalDisposition` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CemeteryID` int(11) NOT NULL,
  `Location` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Section` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `FuneralOrMemorialServiceAtID` int(11) NOT NULL,
  `NameLotRegisteredTo` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `WhereInLotIsGraveToBeOpened` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `LotNo` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `GraveNo` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_final_disposition
-- ----------------------------
INSERT INTO `pre_need_final_disposition` VALUES (1, 'test', 'Y', 'Y', '', 'Y', '2011-11-01', '222222', 1, '33333', '55555', 1, '6666', '7777', '444444', '88888');

-- ----------------------------
-- Table structure for pre_need_grand_children
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_grand_children`;
CREATE TABLE `pre_need_grand_children`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `childrenid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `dob` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `relationship` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_grand_children
-- ----------------------------
INSERT INTO `pre_need_grand_children` VALUES (1, 'test', '0', '11111', '22222', '333333', 1, 1, 2, '2020-07-25', 2, 'test@test.com', '(777) 777-7777', '(888) 888-8888');
INSERT INTO `pre_need_grand_children` VALUES (3, 'test', '1', 'aaaaa', 'bbbbb', 'cccccc', 2, 2, 1, '2020-08-01', 1, 'test@test.com', '(444) 444-4444', '');
INSERT INTO `pre_need_grand_children` VALUES (4, 'test', '2', 'zzzzzz', 'zzzzz', 'zzzzzz', 2, 3, 3, '2020-07-25', 3, 'test@test.com', '(888) 888-888_', '(999) 999-9999');

-- ----------------------------
-- Table structure for pre_need_great_grand_children
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_great_grand_children`;
CREATE TABLE `pre_need_great_grand_children`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `childrenid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `dob` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `relationship` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_great_grand_children
-- ----------------------------
INSERT INTO `pre_need_great_grand_children` VALUES (1, 'test', '0', '11111', '22222', '333333', 1, 1, 2, '2020-07-25', 2, 'test@test.com', '(777) 777-7777', '(888) 888-8888');
INSERT INTO `pre_need_great_grand_children` VALUES (3, 'test', '1', 'aaaaa', 'bbbbb', 'cccccc', 2, 2, 1, '2020-08-01', 1, 'test@test.com', '(444) 444-4444', '');
INSERT INTO `pre_need_great_grand_children` VALUES (4, 'test', '2', 'zzzzzz', 'zzzzz', 'zzzzzz', 2, 3, 3, '2020-07-25', 3, 'test@test.com', '(888) 888-888_', '(999) 999-9999');

-- ----------------------------
-- Table structure for pre_need_marital
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_marital`;
CREATE TABLE `pre_need_marital`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `maritalstatus` int(11) NOT NULL,
  `placeofmarriage` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dateofmarriage` date NOT NULL,
  `spousesname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Spousedeceased` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dateofdeath` date NOT NULL,
  `spousesplaceofdeath` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_marital
-- ----------------------------
INSERT INTO `pre_need_marital` VALUES (1, 'test', 3, 'aaaa', '2020-07-11', 'bbbb', 'Y', '2020-07-18', 'cccccc');

-- ----------------------------
-- Table structure for pre_need_military_service
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_military_service`;
CREATE TABLE `pre_need_military_service`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `BranchID` int(11) NOT NULL,
  `WarCampaignID` int(11) NOT NULL,
  `SerialNumber` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Rank` int(11) NOT NULL,
  `EnlistmentDate` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DischargeDate` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `TypeOfDischargeID` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DD214` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Headstone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ApplicationForBurial` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ApplicationForFlag` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `HonorGuard` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_military_service
-- ----------------------------
INSERT INTO `pre_need_military_service` VALUES (1, 'test', 4, 1, '123456', 3, '2020-07-11', '2020-07-18', '1', 'Y', 'Y', '', 'Y', 'Y');

-- ----------------------------
-- Table structure for pre_need_nok
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_nok`;
CREATE TABLE `pre_need_nok`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `relationship` int(11) NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_nok
-- ----------------------------
INSERT INTO `pre_need_nok` VALUES (2, 'test', 'to Surviving', 'ff', 'ff', 2, 2, 1, 1, '(777) 777-777_', '(777) 777-7777', 'test@test.com');

-- ----------------------------
-- Table structure for pre_need_parents
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_parents`;
CREATE TABLE `pre_need_parents`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ParentDeceasedFathersDOB` date NOT NULL,
  `ParentsDeceasedFathersDOD` date NOT NULL,
  `ParentsDeceasedMothersDOB` date NOT NULL,
  `ParentsDeceasedMothersDOD` date NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_parents
-- ----------------------------
INSERT INTO `pre_need_parents` VALUES (1, 'test', '2020-07-07', '2020-07-14', '2020-07-13', '2020-01-28');

-- ----------------------------
-- Table structure for pre_need_pi
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_pi`;
CREATE TABLE `pre_need_pi`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caseID` int(11) NOT NULL,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `honorific` int(11) NOT NULL,
  `firstName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `middleName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `lastName` int(11) NOT NULL,
  `suffix` int(11) NOT NULL,
  `address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `township` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zipCode` int(8) NOT NULL,
  `country` int(11) NOT NULL,
  `nickName` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `gender` varchar(8) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SSN` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dateOfDeath` date NULL DEFAULT NULL,
  `dateOfBirth` date NOT NULL,
  `timeOfDeath` time(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_pi
-- ----------------------------
INSERT INTO `pre_need_pi` VALUES (4, 0, 'test', 21, 'John', '', 7, 10, 'dddd', 'eeeee', 1, 1, 2, 2, 1, 'iiiiii', 'Male', '222-22-2222', 'test@test.com', '(333) 333-3333', NULL, '0000-00-00', NULL);
INSERT INTO `pre_need_pi` VALUES (6, 0, 'test', 21, 'John', '', 7, 10, 'dddd', 'eeeee', 1, 1, 2, 2, 1, 'iiiiii', 'Male', '222-22-2222', 'test@test.com', '(333) 333-3333', NULL, '0000-00-00', NULL);

-- ----------------------------
-- Table structure for pre_need_place_of_worship
-- ----------------------------
DROP TABLE IF EXISTS `pre_need_place_of_worship`;
CREATE TABLE `pre_need_place_of_worship`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `PlaceOfWorship` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ClergyName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `phone2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pre_need_place_of_worship
-- ----------------------------
INSERT INTO `pre_need_place_of_worship` VALUES (1, 'test', 'test', '2222222', '3333333', '444444', 1, 1, 2, 'aaa@aaa.com', '(777) 777-7788', '(888) 888-8888');
INSERT INTO `pre_need_place_of_worship` VALUES (2, 'test', 'test12', '2222222', '3333333', '444444', 1, 1, 2, 'aaa@aaa.com', '(777) 777-7788', '(888) 888-8888');

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `description` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 145 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES (1, 'superadmin', NULL);
INSERT INTO `roles` VALUES (2, 'useradmin', NULL);
INSERT INTO `roles` VALUES (3, 'staff', NULL);

-- ----------------------------
-- Table structure for staff
-- ----------------------------
DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `useradminid` int(11) NULL DEFAULT NULL,
  `Fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `PersonalEmail` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CompanyEmail` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `City` int(11) NOT NULL,
  `States` int(11) NOT NULL,
  `Zip` int(11) NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `HireDate` date NOT NULL,
  `TerminationDate` date NOT NULL,
  `License` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `LicValidDate` date NOT NULL,
  `StateLicensed` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of staff
-- ----------------------------
INSERT INTO `staff` VALUES (6, 'test', 4, 'staff1', 'test@test.com', 'test@test.com', 'add1', 'add2', 1, 1, 1, '2222222222', '2020-09-01', '2020-08-25', '654654', '2020-08-27', 1);

-- ----------------------------
-- Table structure for statement_automotive
-- ----------------------------
DROP TABLE IF EXISTS `statement_automotive`;
CREATE TABLE `statement_automotive`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Service` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Permanent` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_automotive
-- ----------------------------
INSERT INTO `statement_automotive` VALUES (17, 'test', 'Transfer of Remains to Funeral Home', '', NULL);
INSERT INTO `statement_automotive` VALUES (18, 'test', 'Transfer of Remains to Place of Service', '', NULL);
INSERT INTO `statement_automotive` VALUES (19, 'test', 'Utility Lead Vehicle', '', NULL);
INSERT INTO `statement_automotive` VALUES (20, 'test', 'Hearse', '', NULL);
INSERT INTO `statement_automotive` VALUES (21, 'test', 'Total Services Selected', '', NULL);

-- ----------------------------
-- Table structure for statement_cashadvanced
-- ----------------------------
DROP TABLE IF EXISTS `statement_cashadvanced`;
CREATE TABLE `statement_cashadvanced`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Service` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Permanent` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 38 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_cashadvanced
-- ----------------------------
INSERT INTO `statement_cashadvanced` VALUES (18, 'test', 'Opening & Closing Grave', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (19, 'test', 'Cemetery Fee', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (26, 'test', 'Clergy', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (27, 'test', 'Organist', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (28, 'test', 'Vocalist', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (29, 'test', 'Flowers', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (30, 'test', 'Cert, Death Certification', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (31, 'test', 'Other Funeral Directors', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (32, 'test', 'Hairdress / Barber', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (33, 'test', 'Transportation', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (34, 'test', 'Donation', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (35, 'test', 'Other', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (36, 'test', 'Obituary', '', NULL);
INSERT INTO `statement_cashadvanced` VALUES (37, 'test', 'Total Cash Advanced', '', NULL);

-- ----------------------------
-- Table structure for statement_changesforservices
-- ----------------------------
DROP TABLE IF EXISTS `statement_changesforservices`;
CREATE TABLE `statement_changesforservices`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Service` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Permanent` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_changesforservices
-- ----------------------------
INSERT INTO `statement_changesforservices` VALUES (17, 'test', 'Registry Book', '', NULL);
INSERT INTO `statement_changesforservices` VALUES (18, 'test', 'Memory Folder / Prayer Cards', '', NULL);
INSERT INTO `statement_changesforservices` VALUES (19, 'test', 'Clothing', '', NULL);
INSERT INTO `statement_changesforservices` VALUES (20, 'test', 'Cremation Urn', '', NULL);
INSERT INTO `statement_changesforservices` VALUES (21, 'test', 'Total Merchandise Selected', '', NULL);

-- ----------------------------
-- Table structure for statement_chargesofmerchandise
-- ----------------------------
DROP TABLE IF EXISTS `statement_chargesofmerchandise`;
CREATE TABLE `statement_chargesofmerchandise`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Service` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Permanent` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_chargesofmerchandise
-- ----------------------------
INSERT INTO `statement_chargesofmerchandise` VALUES (16, 'test', 'Casket', '', NULL);
INSERT INTO `statement_chargesofmerchandise` VALUES (17, 'test', 'Outer Burial Container', '', NULL);
INSERT INTO `statement_chargesofmerchandise` VALUES (18, 'test', 'Acknowledgement Cards', '', NULL);

-- ----------------------------
-- Table structure for statement_facilities
-- ----------------------------
DROP TABLE IF EXISTS `statement_facilities`;
CREATE TABLE `statement_facilities`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Service` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Permanent` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_facilities
-- ----------------------------
INSERT INTO `statement_facilities` VALUES (16, 'test', 'Use of Facilities/Viewing/Visitation/Prayer/Wake', '', NULL);
INSERT INTO `statement_facilities` VALUES (17, 'test', 'User of Facilities & Equipment of Funeral', '', NULL);

-- ----------------------------
-- Table structure for statement_information
-- ----------------------------
DROP TABLE IF EXISTS `statement_information`;
CREATE TABLE `statement_information`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `informationid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `InformantName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `AcceptedBy` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `City` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `States` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Zip` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SSN` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `InvoiceDate` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DueDate` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_information
-- ----------------------------
INSERT INTO `statement_information` VALUES (1, 'test', '0', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `statement_information` VALUES (2, 'test', '1', '', '', '', '', '', '', '', '', '', '', '', '');

-- ----------------------------
-- Table structure for statement_professional
-- ----------------------------
DROP TABLE IF EXISTS `statement_professional`;
CREATE TABLE `statement_professional`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Service` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Permanent` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 35 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_professional
-- ----------------------------
INSERT INTO `statement_professional` VALUES (17, 'test', 'Embalming', '', NULL);
INSERT INTO `statement_professional` VALUES (31, 'test', 'Other Preparation of Body', '', 'N');
INSERT INTO `statement_professional` VALUES (32, 'test', 'Services of Funeral Director', '', 'Y');
INSERT INTO `statement_professional` VALUES (34, 'test', 'Flight to final place', '', 'Y');

-- ----------------------------
-- Table structure for statement_reasonfor
-- ----------------------------
DROP TABLE IF EXISTS `statement_reasonfor`;
CREATE TABLE `statement_reasonfor`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `childid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Service` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Permanent` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_reasonfor
-- ----------------------------
INSERT INTO `statement_reasonfor` VALUES (1, 'test', '0', '', '', '');
INSERT INTO `statement_reasonfor` VALUES (5, 'test', '1', '', '', '');

-- ----------------------------
-- Table structure for statement_summaryofcharges
-- ----------------------------
DROP TABLE IF EXISTS `statement_summaryofcharges`;
CREATE TABLE `statement_summaryofcharges`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Service` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Permanent` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_summaryofcharges
-- ----------------------------
INSERT INTO `statement_summaryofcharges` VALUES (16, 'test', 'Services Sub Total', '', NULL);
INSERT INTO `statement_summaryofcharges` VALUES (17, 'test', 'Merchandise Sub Total', '', NULL);
INSERT INTO `statement_summaryofcharges` VALUES (18, 'test', 'Cash Advanced Sub Total', '', NULL);
INSERT INTO `statement_summaryofcharges` VALUES (19, 'test', 'Summary Sub Total', '', NULL);
INSERT INTO `statement_summaryofcharges` VALUES (20, 'test', 'Write Off', '', NULL);

-- ----------------------------
-- Table structure for statement_terms_of_agreement
-- ----------------------------
DROP TABLE IF EXISTS `statement_terms_of_agreement`;
CREATE TABLE `statement_terms_of_agreement`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price3` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_terms_of_agreement
-- ----------------------------
INSERT INTO `statement_terms_of_agreement` VALUES (1, 'test', '', '', '');

-- ----------------------------
-- Table structure for statement_totalamountdue
-- ----------------------------
DROP TABLE IF EXISTS `statement_totalamountdue`;
CREATE TABLE `statement_totalamountdue`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Service` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Permanent` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_totalamountdue
-- ----------------------------
INSERT INTO `statement_totalamountdue` VALUES (16, 'test', 'Sales Tax Rate', '', NULL);
INSERT INTO `statement_totalamountdue` VALUES (17, 'test', 'Tax', '', NULL);
INSERT INTO `statement_totalamountdue` VALUES (18, 'test', 'Total Charge', '', NULL);
INSERT INTO `statement_totalamountdue` VALUES (19, 'test', 'Payment Amount', '', NULL);
INSERT INTO `statement_totalamountdue` VALUES (20, 'test', 'Current Balance', '', NULL);

-- ----------------------------
-- Table structure for statement_totalspecialcharges
-- ----------------------------
DROP TABLE IF EXISTS `statement_totalspecialcharges`;
CREATE TABLE `statement_totalspecialcharges`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Service` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Price` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Permanent` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of statement_totalspecialcharges
-- ----------------------------
INSERT INTO `statement_totalspecialcharges` VALUES (16, 'test', 'Forwarding of Remains Forms', '', 'N');
INSERT INTO `statement_totalspecialcharges` VALUES (17, 'test', 'Forwarding of Remains To', '', NULL);
INSERT INTO `statement_totalspecialcharges` VALUES (18, 'test', 'Immediate Burial', '', NULL);
INSERT INTO `statement_totalspecialcharges` VALUES (19, 'test', 'Direct Cremation', '', NULL);
INSERT INTO `statement_totalspecialcharges` VALUES (20, 'test', 'Total Special Charge', '', NULL);

-- ----------------------------
-- Table structure for surviving_relative
-- ----------------------------
DROP TABLE IF EXISTS `surviving_relative`;
CREATE TABLE `surviving_relative`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address1` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `city` int(11) NOT NULL,
  `states` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `relationship` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of surviving_relative
-- ----------------------------
INSERT INTO `surviving_relative` VALUES (3, 'test', 'sur edit test', 'ccccc', 1, 1, 1, '2222222222', 'test@test.com', 1);
INSERT INTO `surviving_relative` VALUES (5, 'test', 'surviving_test', 'ccccc', 1, 1, 1, '2222222222', 'test@test.com', 2);
INSERT INTO `surviving_relative` VALUES (7, 'test', 'suvivingadd', 'ccccc', 3, 2, 1, '2222222222', 'test@test.com', 1);
INSERT INTO `surviving_relative` VALUES (10, 'test', 'to Surviving', 'ff', 2, 2, 1, '(777) 777-777_', 'test@test.com', 1);
INSERT INTO `surviving_relative` VALUES (11, 'test', 'from At to At-Need', 'bb', 1, 1, 3, '(222) 222-2222', 'test@test.com', 1);

-- ----------------------------
-- Table structure for todolist
-- ----------------------------
DROP TABLE IF EXISTS `todolist`;
CREATE TABLE `todolist`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caseID` varchar(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `staffID` int(11) NULL DEFAULT NULL,
  `cDate` date NULL DEFAULT NULL,
  `rDate` date NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `isPerm` varchar(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `completed` varchar(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 157 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of todolist
-- ----------------------------
INSERT INTO `todolist` VALUES (156, '161', 4, '2020-09-10', '2020-09-09', 'Organist Notified', 'N', 'Y');
INSERT INTO `todolist` VALUES (155, '161', 4, '2020-09-09', '2020-09-12', 'Clergy notifiied', 'N', 'N');
INSERT INTO `todolist` VALUES (149, '169', 4, '2020-09-08', '2020-09-10', 'Clergy notifiied', 'Y', 'N');

-- ----------------------------
-- Table structure for type
-- ----------------------------
DROP TABLE IF EXISTS `type`;
CREATE TABLE `type`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 145 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of type
-- ----------------------------
INSERT INTO `type` VALUES (143, 'test');
INSERT INTO `type` VALUES (144, 'test2');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `passwords` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `crematory` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contactemail` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address1` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address2` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `city` int(11) NULL DEFAULT NULL,
  `states` int(11) NULL DEFAULT NULL,
  `zip` int(11) NULL DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `license` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `role` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cancreate` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `canread` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `canupdate` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `candelete` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `HireDate` date NULL DEFAULT NULL,
  `TerminationDate` date NULL DEFAULT NULL,
  `LicValidDate` date NULL DEFAULT NULL,
  `StateLicensed` int(11) NULL DEFAULT NULL,
  `photo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `companylogo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `useradminid` int(11) NULL DEFAULT NULL,
  `note` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `funstatus` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `daysremain` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `actived` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `plan` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `locations` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (4, 'test', 'newuser@test.com', '098f6bcd4621d373cade4e832627b4f6', 'funeral of adminstaff1', 'contact2', 'tet@test.com', 'ad1', 'ad12', 1, 1, 2, '(747) 777-7777', '684798', 'adminstaff', 'Y', 'Y', 'Y', 'Y', '2020-08-26', '2020-08-25', '2020-08-19', 1, '1ce550db1688352931278d96399749a1.jpg', '3aa8de6510bc992b4edff61af7ed6367.png', 4, 'Our funeral home provide fast service.', 'Paid', '25', 'N', '4', '5');
INSERT INTO `users` VALUES (12, 'newuser', 'newuser@test.com', '1efbbc060192cfeb5095777562823745', 'funeral_edit', 'contact', 'test@test.com', 'ad1', 'ad12', 1, 1, 2, '(747) 777-7777', '684798', 'staff', 'N', 'Y', 'N', 'N', '2020-08-02', '2020-10-21', '2020-08-02', 1, 'b9cbacc185f50c0a528b3600a3ddf51a.jpg', '1b4d51f83f32f55ac3096e9ec397bb6a.png', 14, 'Thanks for visiting our funeral home sevice<br>We will response to any emergency call.', 'Demo', '27', 'N', '4', '5');
INSERT INTO `users` VALUES (14, 'superadmin', 'ezmmsoftware@gmail.com', '1b3231655cebb7a1f783eddf27d254ca', 'ezmm', 'soufix', 'ezmmsoft@gmail.com', 'add1', 'add2', 2, 1, 2, '(777) 777-7777', '99999', 'superadmin', 'Y', 'Y', 'Y', 'Y', '2020-08-25', '2020-08-26', '2020-08-26', 1, '666e2f2ca844d0f065e93d9e283774ed.jpg', '8e7ff1d2c362f16bde2e5f5c373c9b63.png', 4, 'This is funeral Home of Super Admin', 'Demo', '30', 'N', '2', '5');

-- ----------------------------
-- Table structure for visitor
-- ----------------------------
DROP TABLE IF EXISTS `visitor`;
CREATE TABLE `visitor`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Email` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Address2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `City` int(11) NOT NULL,
  `States` int(11) NOT NULL,
  `Zip` int(11) NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of visitor
-- ----------------------------
INSERT INTO `visitor` VALUES (1, 'test', 'a', 'test@test.com', 'ccccc', 'ddddddd', 2, 2, 2, '(222) 222-2222');
INSERT INTO `visitor` VALUES (2, 'useradmin', 'visitor_edit', '2222222', '3333333', '4444444', 2, 2, 1, '(777) 777-7777');

-- ----------------------------
-- Table structure for vital_statistics_district
-- ----------------------------
DROP TABLE IF EXISTS `vital_statistics_district`;
CREATE TABLE `vital_statistics_district`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `FirstName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `MiddleName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `LastName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Suffix` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `NickName` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `GenderID` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `SSN` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `TimeOfDeath` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `RangeTimeOfDead` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `TimeFound` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DateOfDeath` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Indicator` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dateOfBirth` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `age` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `PlaceOfDeathID` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Place` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `facility_name` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CityID` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `City` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `StateID` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `State` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ZipCodeID` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CountryID` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CountryFIPS` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `armed_service` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dispositioni_method_of_disposition` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `disposition_crematory_name` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `disposition_crematory_name2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `disposition_city1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `disposition_country1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `disposition_state1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `disposition_place_of_disposition` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `disposition_place_of_disposition2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `disposition_city2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `disposition_country2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `disposition_state2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `funeral_home1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `funeral_home2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `funeral_city` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `funeral_country` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `funeral_state` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `funeral_director1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `funeral_director2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `funeral_director_license` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `funeral_home_number` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `assignment_certifier_type` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `assignment_coroner_location` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `assignment_physician1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `assignment_physician2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `assignment_dropped_to_papaer` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `assignment_email_notify` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `assignment_date_sent` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `assignment_certifier_location` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `assignment_certifier_country` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `residence_street_number` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `residence_apt` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `residence_city_limits` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `residence_zipcode` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `residence_city_township` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `residence_country1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `residence_country2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `residence_state` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_country_birth1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_country_birth2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_state_birth` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_marital_status` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `surviving_firstname` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `surviving_middlename` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `surviving_lastname` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `surviving_suffix` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `parents_firstname` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `parents_middlename` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `parents_lastname` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `parents_suffix` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `mother_firstname` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `mother_middlename` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `mother_lastname` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `informant_firstname` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `informant_middlename` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `informant_lastname` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `informant_suffix` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `informant_relationship1` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `informant_relationship2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `informant_mailing_address` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `informant_city` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `informant_state` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `informant_zipcode` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_education` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_hispanic` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_mexian` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_puerto` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_cuban` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_specify` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_other` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_white` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_black` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_asian` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_chinese` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_filipino` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_vietnamese` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_japanese` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_korean` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_hawaiian` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_samoan` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_guamanian` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_american` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_native_desc` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_native_chk` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_other_asian_desc` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_other_asian_chk` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_other_pacific_desc` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_other_pacific_chk` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_native_desc2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_other_asian_chk2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_other_asian_desc2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_other_pacific_chk2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `race_other_pacific_desc2` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_occupation` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `demographics_industry` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of vital_statistics_district
-- ----------------------------
INSERT INTO `vital_statistics_district` VALUES (1, 'test', 'a', 'bb', 'ccc', '', 'dd', '1', 'ee', 'ffff', 'ggg', 'hh', 'iiii', '', 'yyyyyyyy', 'kkk', '', 'll', 'mm', '', 'nn', '', 'oo', '', '', 'ppppp', '', '', '', 'qq', '', '', '', '', 'rrr', '', '', '', '', 'ss', '', '', '', '', 'ttt', '', '', 'u', 'vv', '', 'ww', 'xx', 'test@test.com', 'yyy', 'zzz', '111', '222', '3', '44', '', '55', '6666', '', '', '', '77', '', '', '88', '999', '0000', 'aa', 'bb', 'cc', 'ddd', 'eee', 'fff', 'iiii', 'jjj', 'llll', 'mmm', 'nnn', 'oooo', '', 'pppp', 'qqq', '', '', '', '', 'rrr', 'Y', '', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '11', 'Y', '2222', 'Y', '3333', 'Y', '44444', 'Y', '55555', 'Y', '66666', '7777', '8888888');

SET FOREIGN_KEY_CHECKS = 1;
