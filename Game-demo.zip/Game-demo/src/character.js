class Character {

  findSpot(side) {
    if(side == 'l') {
      var ind = left_side.findIndex(e => e == null);

      var spot = left_spots[ind];

      var x = spot[0] - this.display_width/2;
      var y = spot[1] + 15 - this.display_height;

      return {x: this.convertX(x), y: this.convertY(y), i: ind};
    }
    else {
      var ind = right_side.findIndex(e => e == null);
      var spot = right_spots[ind];

      var x = spot[0] - this.display_width/2;
      var y = spot[1] + 15 - this.display_height;

      return {x: this.convertX(x), y: this.convertY(y), i: ind};
    }
  }

  getSpotPosition() {
    if(this.side == 'l') {
      var ind = left_side.indexOf(this);
      var spot = left_spots[ind];

      var x = spot[0] - this.display_width/2;
      var y = spot[1] + 15 - this.display_height;

      return [this.convertX(x), this.convertY(y), ind];
    }
    else {
      var ind = right_side.indexOf(this);
      var spot = right_spots[ind];

      var x = spot[0] - this.display_width/2;
      var y = spot[1] + 15 - this.display_height;

      return [this.convertX(x), this.convertY(y), ind];
    }
  }

  displayTestMessage(message) {
    this.sprite.dom.innerHTML = message;
    this.sprite.dom.style.fontSize = "10vw";
  }

  constructor(
    name,
    start_left = false,
    display_width = -1
  ) {
    var that = this;

    characters.push(this);
    loadAsset(name);

    var conf = config[name];

    display_width = display_width < 0? conf.display_width: display_width;

    this.animations = {
      idle: {
        width: conf.idle.width,
        count: conf.idle.count,
        image: "sprites/"+name+"/Idle.png",
        frame: 0
      },

      walkin: {
        width: conf.walk.width,
        count: conf.walk.count,
        image: "sprites/"+name+"/Walking.png",
        frame: -1
      },

      walkout: {
        width: conf.walk.width,
        count: conf.walk.count,
        image: "sprites/"+name+"/Walking.png",
        frame: -1
      },

      turn: {
        width: conf.turn.width,
        count: conf.turn.count,
        image: "sprites/"+name+"/Turn.png",
        frame: -1
      }
    };

    this.animation_queue = [];
    this.animating = false;
    this.sprite = foreground.Sprite(this.animations.idle.image);

    this.sprite.setW(conf.frame_width);
    this.sprite.setH(conf.frame_height);
    this.scale = display_width/conf.frame_width;

    this.display_width = display_width;
    this.display_height = this.scale*conf.frame_height;

    this.display_x = () => {
      return that.sprite.x + (1-that.scale)*that.sprite.w/2;
    };

    this.display_y = () => {
      return that.sprite.y + (1-that.scale)*that.sprite.h/2;
    };

    this.convertX = (val) => val - (1-that.scale)*that.sprite.w/2;
    this.convertY = (val) => val - (1-that.scale)*that.sprite.h/2;

    this.revertX = (val) => val + (1-that.scale)*that.sprite.w/2;
    this.revertY = (val) => val + (1-that.scale)*that.sprite.h/2;

    this.sprite.setXScale(start_left? -this.scale: this.scale);
    this.sprite.setYScale(this.scale);

    this.side = start_left? 'l': 'r';
    this.facing = start_left? 'r': 'l';

    var spot = this.findSpot(this.side);
    if(this.side == 'r') right_side[spot.i] = this;
    else left_side[spot.i] = this;

    this.sprite.position(spot.x, spot.y);
    this.sprite.dom.style.zIndex = ""+Math.floor(this.display_y() + this.display_height);

    this.canBeLoaded = () => true;

    this.load = function() {
      if(that.canBeLoaded() && that.side == raft.side) {
        var spot = getRaftSpot(that);
        var check =
          (that.sprite.x > spot.x && that.facing == 'r') ||
          (that.sprite.x < spot.x && that.facing == 'l');
        if(check) that.animation_queue.push(that.animations.turn);
        that.animation_queue.push(that.animations.walkin);
        if(check) that.animation_queue.push(that.animations.turn);
      }
    };

    this.unload = function() {
      var spot = that.findSpot(that.side);
      var check =
        (that.sprite.x > spot.x && that.facing == 'r') ||
        (that.sprite.x < spot.x && that.facing == 'l');
      if(check) that.animation_queue.push(that.animations.turn);
      that.animation_queue.push(that.animations.walkout);
    };

    this.sprite.dom.onclick = () => {
      if(!that.animating) {
        if(raft.load.indexOf(this) != -1) that.unload();
        else that.load();
      }
    };

    this.sprite.update();
  }
}
