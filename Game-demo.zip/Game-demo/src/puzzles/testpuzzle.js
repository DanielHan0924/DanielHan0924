puzzles.test = () => {
  var curr;
  for(var t = 0; t < 8; t++) {
    curr = new Character("D", false, 100);
    curr = new Character("D", true, 100);
  }
};
