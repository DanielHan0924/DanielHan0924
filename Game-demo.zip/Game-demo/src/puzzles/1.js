puzzles[0] = () => {
  var a = new Character("A");

  var b = new Character("B");

  var c = new Character("C");

  var d1 = new Character("D");

  var d2 = new Character("D");

  // THIS FOLLOWING SECTION IS FOR TESTING ONLY AND SHOULD NOT BE PUBLISHED
  // a.displayTestMessage("A");
  // b.displayTestMessage("B");
  // c.displayTestMessage("C");
  // d1.displayTestMessage("D1");
  // d2.displayTestMessage("D2");
  // TESTING SECTION END

  // Fail state
  checkFailState = function() {
    // for A
    var check = raft.load.indexOf(a) == -1;
    for(slot of (a.side == 'r'? right_side: left_side)) {
      if(slot != a && slot != null) {
        check = false;
        break;
      }
    }
    if(check) return true;

    // for B
    var check_others = false;
    var check_ds = false;
    for(slot of (b.side == 'r'? right_side: left_side)) {
      if(slot == d1 || slot == d2) check_ds = true;
      if(slot == a || slot == c) check_others = true;
    }
    if(check_ds && !check_others && raft.load.indexOf(b) == -1) return true;

    return false;
  }

  // Loading conditions.
  a.canBeLoaded = () =>
    raft.count() == 0 ||
    (raft.count() == 1 && raft.load.indexOf(b) != -1);

  b.canBeLoaded = () =>
    raft.count() == 0 ||
    (raft.count() == 1 && raft.load.indexOf(a) != -1);

  c.canBeLoaded = () => raft.count() == 0;

  d1.canBeLoaded = () => raft.count() == 0;

  d2.canBeLoaded = () => raft.count() == 0;
}
