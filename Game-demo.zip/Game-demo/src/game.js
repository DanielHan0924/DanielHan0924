var scene = sjs.Scene({w:760, h:374});

var puzzles = [];

const TICK_DURATION = 40; // Duration of each frame (40 => ~24 fps)
const RAFT_TRAVEL_TIME = 24; // In frames
const CHAR_SPEED = 200/24; // In pixels per frame

var load_layer = scene.Layer("load_layer", {
  useCanvas: false,
  autoClear: false
});

var assets = [];

function loadAsset(folder_name) {
  var curr = load_layer.Sprite("sprites/" + folder_name + "/Idle.png", {w: 100, h:100});
  curr.update();
  assets.push(curr);

  curr = load_layer.Sprite("sprites/" + folder_name + "/Walking.png", {w: 100, h:100});
  curr.update();
  assets.push(curr);

  curr = load_layer.Sprite("sprites/" + folder_name + "/Turn.png", {w: 100, h:100});
  curr.update();
  assets.push(curr);
}

function clearAssets() {
  for(asset of assets) {
    asset.remove();
  }
  assets = [];
}

var background = scene.Layer("background", {
  useCanvas: false,
  autoClear: false
});

background.Sprite("sprites/background.png", {
  w: 760,
  h: 374
}).update();

var foreground = scene.Layer("foreground", {
  useCanvas: false,
  autoClear: false
});

var left_side = new Array(8);
var right_side = new Array(8);

var raft = foreground.Sprite("sprites/raft.png", {
  w: 151,
  h: 49
});

var ports = {
    r: [608, 283],
    l: [305, 314]
}

raft.position(
  ports.r[0],
  ports.r[1]
);

raft.side = 'r';
raft.update();
raft.load = [null, null];

raft.moveLoad = () => {
  if(!onMoveLoad() || raft.count() == 0) onMoveFailed();
  else {
    raft.moveframe = 0;
  }
}

var animating = false;

raft.dom.onclick = () => {
  if(!animating) raft.moveLoad();
}

raft.count = function () {
  var ans = 0;
  for(char of raft.load) if(char != null) ans++;
  return ans;
}

raft.moveframe = -1;
raft.unloadframe = -1;

var checkFailState = function() {
  return false;
}

var checkVictoryState = function () {
  return right_side.every(element => element == null) && raft.load.every(element => element == null);
}

raft.spots = [
  [50, 24],
  [100, 27]
];

function getRaftSpot(target) {
  var ind = raft.load.findIndex(e => e == null);
  var x = raft.x + raft.spots[ind][0] - target.display_width/2;
  var y = raft.y + raft.spots[ind][1] - target.display_height;
  return {x: target.convertX(x), y: target.convertY(y)};
}

var onMoveLoad = () => true;

var onMoveFailed = () => {
  window.alert("The raft won't move!");
}

var left_spots = [
  [317, 296], [267, 301], [221, 304],
  [171, 308], [115, 313], [66, 275],
  [58, 330], [30, 300]
];

var right_spots = [
  [592, 263], [542, 260], [496, 257],
  [446, 254], [390, 253], [333, 252],
  [650, 230], [564, 220]
];

var characters = [];

function manageAnimations() {
  for(char of characters) if(char != null) {

    // Walk in animation
    if(char.animations.walkin.frame > -1) {
      var anim = char.animations.walkin;
      char.animating = animating = true;

      if(anim.frame == 0) {
        char.spot = getRaftSpot(char);
        raft.load[raft.load.findIndex(e => e == null)] = char;
        char.sprite.loadImg(anim.image);

        var bank = char.side == 'r'? right_side: left_side;
        bank[bank.indexOf(char)] = null;

        char.dist_x = char.spot.x - char.sprite.x;
        char.dist_y = char.spot.y - char.sprite.y;
        char.dist = Math.hypot(char.dist_x, char.dist_y);
        char.time = Math.abs(char.dist/CHAR_SPEED);
      }

      if(anim.frame >= char.time - 1) {
        char.sprite.position(char.spot.x, char.spot.y);
        char.sprite.update();
        anim.frame = -1;
        char.animating = animating = false;
        char.sprite.loadImg(char.animations.idle.image);
        checkState();
      }
      else {
        var anim_frame = anim.frame%anim.count;
        char.sprite.setXOffset((anim_frame%anim.width)*char.sprite.w);
        char.sprite.setYOffset(Math.floor(anim_frame/anim.width)*char.sprite.h);

        var x_move = char.dist_x/char.time;
        var y_move = char.dist_y/char.time;
        char.sprite.move(x_move, y_move);
        char.sprite.dom.style.zIndex = ""+Math.floor(char.display_y() + char.display_height);
        char.sprite.update();

        anim.frame++;
      }
    }

    // Walk out animation
    else if(char.animations.walkout.frame > -1) {
      var anim = char.animations.walkout;
      char.animating = animating = true;

      if(anim.frame == 0) {
        char.spot = char.findSpot(char.side);

        var bank = char.side == 'r'? right_side: left_side;
        bank[char.spot.i] = char;
        raft.load[raft.load.indexOf(char)] = null;

        char.sprite.loadImg(anim.image);
        char.dist_x = char.spot.x - char.sprite.x;
        char.dist_y = char.spot.y - char.sprite.y;
        char.dist = Math.hypot(char.dist_x, char.dist_y);
        char.time = Math.abs(char.dist/CHAR_SPEED);
      }

      if(anim.frame >= char.time - 1) {
        char.sprite.position(char.spot.x, char.spot.y);
        char.sprite.update();
        char.animating = animating = false;
        anim.frame = -1;
        char.sprite.loadImg(char.animations.idle.image);
        if(char.side == char.facing) char.animation_queue.push(char.animations.turn);
        checkState();
      }
      else {
        var anim_frame = anim.frame%anim.count;
        char.sprite.setXOffset((anim_frame%anim.width)*char.sprite.w);
        char.sprite.setYOffset(Math.floor(anim_frame/anim.width)*char.sprite.h);

        var x_move = char.dist_x/char.time;
        var y_move = char.dist_y/char.time;
        char.sprite.move(x_move, y_move);
        char.sprite.dom.style.zIndex = ""+Math.floor(char.display_y() + char.display_height);
        char.sprite.update();

        anim.frame++;
      }
    }

    // Turn animation
    else if(char.animations.turn.frame > -1) {
      var anim = char.animations.turn;
      char.animating = animating = true;

      if(anim.frame == 0) {
        char.facing = char.facing == 'r'? 'l': 'r';
        char.sprite.loadImg(anim.image);
      }

      if(anim.frame >= anim.count - 1) {
        var scale = char.facing == 'r'? -char.scale: char.scale;
        char.sprite.setXScale(scale);
        char.sprite.update();
        anim.frame = -1;
        char.animating = animating = false;
        char.sprite.loadImg(char.animations.idle.image);
      }
      else {
        anim.frame++;

        var anim_frame = anim.frame%anim.count;
        char.sprite.setXOffset((anim_frame%anim.width)*char.sprite.w);
        char.sprite.setYOffset(Math.floor(anim_frame/anim.width)*char.sprite.h);

        char.sprite.update();
      }
    }

    // Idle animation and move animation_queue
    else {
      var next = char.animation_queue.shift();
      if(next != null) next.frame = 0;
      else {
        anim = char.animations.idle;
        anim.frame = (anim.frame+1)%anim.count;

        char.sprite.setXOffset((anim.frame%anim.width)*char.sprite.w);
        char.sprite.setYOffset(Math.floor(anim.frame/anim.width)*char.sprite.h);

        char.sprite.update();
      }
    }
  }

  if(raft.moveframe > -1) {
    animating = true;
    if(raft.moveframe == 0) {

      raft.port = ports[raft.side == 'r'? 'l': 'r'];
      raft.dist_x = raft.port[0] - raft.x;
      raft.dist_y = raft.port[1] - raft.y;

      if(raft.load[0] != null) raft.load[0].animating = true;
      if(raft.load[1] != null) raft.load[1].animating = true;
    }

    if(raft.moveframe >= RAFT_TRAVEL_TIME - 1) {
      raft.moveframe = -1;
      raft.unloadframe = 0;
      raft.side = raft.side == 'r'? 'l': 'r';

      if(raft.load[0] != null) {
        raft.load[0].animating = true;
        raft.load[0].side = raft.side;
      }
      if(raft.load[1] != null) {
        raft.load[1].animating = true;
        raft.load[1].side = raft.side;
      }

      raft.position(raft.port[0], raft.port[1]);
      raft.update();
      animating = false;
    }
    else {
      var move_x = raft.dist_x/RAFT_TRAVEL_TIME;
      var move_y = raft.dist_y/RAFT_TRAVEL_TIME;
      raft.move(move_x, move_y);
      raft.update();

      for(char of raft.load) if(char != null){
        char.sprite.move(move_x, move_y);
        char.sprite.dom.style.zIndex = ""+Math.floor(char.display_y() + char.display_height);
        char.sprite.update();
      }

      raft.moveframe++;
    }
  }
  else if(raft.unloadframe > -1) {
    if(raft.unloadframe == 0) {
      if(raft.load[0] != null) raft.load[0].unload();
    }

    if(raft.unloadframe == 12) {
      if(raft.load[1] != null) raft.load[1].unload();
      raft.unloadframe = -1;
    }
    else raft.unloadframe++;
  }
}

function checkState() {
  if(checkVictoryState()) victory();
  else if(checkFailState() && raft.load.every(e => e == null)) failure();
}

var ticker = scene.Ticker(
  manageAnimations,
  {
    tickDuration: TICK_DURATION,
    useAnimationFrame: false
  }
);

ticker.run();

/*
  These functions are called when the player wins or loses.
  Change them to do things like save to cookies, reset upon
  failure, go back to main menu, etc.
*/
function victory() {
  window.alert("You win!");
  loadPuzzle(current_puzzle + 1);
}

var current_puzzle = 0;

function failure() {
  window.alert("You lose!");
  loadPuzzle(current_puzzle);
}

// Load the puzzle you want this way, 0-indexed
function loadPuzzle(n) {
  window.alert("Level " + (n+1)); // this is for testing purposes and should be removed
  current_puzzle = n;
  unloadPuzzle();
  if(n < puzzles.length) puzzles[n]();
  ticker.resume();
  // document.getElementById("puzzlen").innerHTML = "puzzle " + (n + 1);
}

// Clears out the current puzzle and resets the position of the raft
function unloadPuzzle() {
  ticker.pause();
  raft.position(ports.r[0], ports.r[1]);
  raft.update();
  raft.side = 'r';

  for(ind in characters) {
    var char = characters[ind];
    clearInterval(char.idle_interval);
    char.sprite.remove();
  }

  characters = [];
  right_side = new Array(8);
  left_side = new Array(8);
  raft.load = new Array(2);
  onMoveLoad = () => true;
  onFailState = () => false;
  clearAssets();
  animating = false;
}
