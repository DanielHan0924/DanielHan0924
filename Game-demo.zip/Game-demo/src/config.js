var config = {
  A: {
    frame_width: 200,
    frame_height: 200,
    display_width: 70,

    idle: {
      width: 1,
      count: 1
    },

    walk: {
      width: 1,
      count: 1
    },

    turn: {
      width: 1,
      count: 1
    }
  },

  B: {
    frame_width: 200,
    frame_height: 200,
    display_width: 70,

    idle: {
      width: 1,
      count: 1
    },

    walk: {
      width: 1,
      count: 1
    },

    turn: {
      width: 1,
      count: 1
    }
  },

  C: {
    frame_width: 200,
    frame_height: 200,
    display_width: 70,

    idle: {
      width: 1,
      count: 1
    },

    walk: {
      width: 1,
      count: 1
    },

    turn: {
      width: 1,
      count: 1
    }
  },

  D: {
    frame_width: 200,
    frame_height: 200,
    display_width: 70,

    idle: {
      width: 1,
      count: 1
    },

    walk: {
      width: 1,
      count: 1
    },

    turn: {
      width: 1,
      count: 1
    }
  }


};
