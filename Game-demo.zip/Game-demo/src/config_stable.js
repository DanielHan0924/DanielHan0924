var config = {
  A: {
    frame_width: 266,
    frame_height: 171,
    display_width: 30,

    idle: {
      width: 31,
      count: 31
    },

    walk: {
      width: 7,
      count: 19
    },

    turn: {
      width: 4,
      count: 4
    }
  },

  B: {
    frame_width: 178,
    frame_height: 326,
    display_width: 30,

    idle: {
      width: 31,
      count: 31
    },

    walk: {
      width: 4,
      count: 23
    },

    turn: {
      width: 1,
      count: 4
    }
  },

  C: {
    frame_width: 382,
    frame_height: 479,
    display_width: 60,

    idle: {
      width: 16,
      count: 31
    },

    walk: {
      width: 6,
      count: 23
    },

    turn: {
      width: 3,
      count: 3
    }
  },

  D: {
    frame_width: 200,
    frame_height: 144,
    display_width: 60,

    idle: {
      width: 16,
      count: 31
    },

    walk: {
      width: 18,
      count: 35
    },

    turn: {
      width: 4,
      count: 4
    }
  },

  E: {
    frame_width: 266,
    frame_height: 171,
    display_width: 30,

    idle: {
      width: 31,
      count: 31
    },

    walk: {
      width: 7,
      count: 19
    },

    turn: {
      width: 4,
      count: 4
    }
  },

  F: {
    frame_width: 178,
    frame_height: 326,
    display_width: 30,

    idle: {
      width: 31,
      count: 31
    },

    walk: {
      width: 4,
      count: 23
    },

    turn: {
      width: 1,
      count: 4
    }
  },

  G: {
    frame_width: 382,
    frame_height: 479,
    display_width: 60,

    idle: {
      width: 16,
      count: 31
    },

    walk: {
      width: 6,
      count: 23
    },

    turn: {
      width: 3,
      count: 3
    }
  },

  H: {
    frame_width: 200,
    frame_height: 144,
    display_width: 60,

    idle: {
      width: 16,
      count: 31
    },

    walk: {
      width: 18,
      count: 35
    },

    turn: {
      width: 4,
      count: 4
    }
  }
};
