<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Addons_model (Addons Model)
 * User model class to get to handle user related data 
 * @author : Axis96
 * @version : 1.1
 * @since : 02 February 2019
 */
class Wallet_model extends CI_Model
{
    private $arr = array();
    private $flag_tier = 0;
    
    function create($transactionInfo, $senderNewBalance, $recipientNewBalance, $senderId, $recipientId){
        $this->db->trans_start();
        $this->db->insert('tbl_wallet_transactions', $transactionInfo);
        
        $insert_id = $this->db->insert_id();

        if($insert_id > 0)
        {
            $senderWallet = array(
                'balance'=>$senderNewBalance
            );

            $recipientWallet = array(
                'balance'=>$recipientNewBalance
            );

            $this->db->where('userId', $senderId);
            $this->db->update('tbl_wallets', $senderWallet);

            $this->db->where('userId', $recipientId);
            $this->db->update('tbl_wallets', $recipientWallet);
        }
        $this->db->trans_complete();
        
        return $insert_id;
    }

    function totalSent($senderId){
        $this->db->select_sum('amount');
        $this->db->from('tbl_wallet_transactions');
        $this->db->where('txnUserId', $senderId);
        $query = $this->db->get();
        $amount = $query->row()->amount;

        if($amount){
            return  -$amount;
        } else {
            return 0.00;
        }
    }

    function pendingDeposits($userId){
        $this->db->select('*');
        $this->db->from('tbl_wallet_transactions');
        $this->db->where('status =', 0);
        $this->db->where('txnUserId =', $userId);
        $this->db->where('type =', 'deposit');

        $query = $this->db->get();
        return $query->num_rows();
    }

    function totalReceived($recipientId){
        $this->db->select_sum('amount');
        $this->db->from('tbl_wallet_transactions');
        $this->db->where('recipientId', $recipientId);
        $query = $this->db->get();
        $amount = $query->row()->amount;

        if($amount){
            return $amount;
        } else {
            return 0.00;
        }
    }

    function wallet_transactionsListingCount($searchText = '', $type, $userId, $client){
        $this->db->select('BaseTbl.id, BaseTbl.type, BaseTbl.createdDtm, BaseTbl.method, BaseTbl.txnUserId, BaseTbl.status, BaseTbl.amount, BaseTbl.txn_id, UserTbl.userId as txnUserId, UserTbl.firstName as txnUserFName, UserTbl.email as txnUserEmail, UserTbl.lastName as txnUserLName');
        $this->db->from('tbl_wallet_transactions as BaseTbl');
        $this->db->join('tbl_users as UserTbl', 'UserTbl.userId = BaseTbl.txnUserId','left');
        if($type != NULL){
            $this->db->where('BaseTbl.type', $type);
        }
        if($userId != NULL){
            $this->db->where('BaseTbl.txnUserId', $userId); 
        }

        $query = $this->db->get();
        
        return $query->num_rows();
    }

    function wallet_transactions($searchText = '', $type, $userId, $client, $page, $segment, $startDate, $endDate){
        $this->db->select('BaseTbl.id, BaseTbl.type, BaseTbl.createdDtm, BaseTbl.method, BaseTbl.txnUserId, BaseTbl.status, BaseTbl.amount, BaseTbl.txn_id, UserTbl.userId as txnUserId, UserTbl.firstName as txnUserFName, UserTbl.email as txnUserEmail, UserTbl.lastName as txnUserLName');
        $this->db->from('tbl_wallet_transactions as BaseTbl');
        $this->db->join('tbl_users as UserTbl', 'UserTbl.userId = BaseTbl.txnUserId');
        // $this->db->where('UserTbl.userId =', $userId);
        //  $this->db->where('BaseTbl.type',lcfirst($type));
        
        if(!empty($startDate)){
            $this->db->or_like('BaseTbl.createdDtm >=', $startDate);
        }

        if(!empty($endDate)){
            $this->db->or_like('BaseTbl.createdDtm <=', $endDate);
        }

         if(!empty($client) ){
                $this->db->where('BaseTbl.txnUserId =', $userId);
         }
        if(!empty($type)){
            $this->db->where('BaseTbl.type',lcfirst($type));
        }

        if(!empty($searchText)) {
            $this->db->or_like('BaseTbl.txn_id', $searchText);
        }

        // $this->db->order_by('BaseTbl.id', 'DESC');
        $this->db->limit($page, $segment);

        $query = $this->db->get();
        
        return $query->result();
    }

    function transferListingCount($searchText = '')
    {
        $this->db->select('*');
        $this->db->from('tbl_wallet_transactions as BaseTbl');
        $this->db->join('tbl_users as UserTbl', 'UserTbl.userId = BaseTbl.txnUserId','left');

        if(!empty($searchText)) {
            $this->db->group_start();
            $terms = explode(' ', $searchText);
            if(count($terms)>1){
                $this->db->or_like('BaseTbl.amount', $this->db->escape_like_str($terms[0]));
                $this->db->or_like('BaseTbl.txn_id', $this->db->escape_like_str($terms[0]));
            }else{
                $this->db->or_like('UserTbl.firstName', $this->db->escape_like_str($terms[0]));
                $this->db->or_like('UserTbl.lastName', $this->db->escape_like_str($terms[0]));
            }
            $this->db->group_end();
        }
        
        $query = $this->db->get();
        
        return $query->num_rows();
    }

    function transferEmailIdCheck($email, $userId)
    {
        $this->db->select("*");
        $this->db->from("tbl_users");
        //Look if the email exists
        $this->db->where("email", $email);   
        //If it exists make sure it does not belong to the sender
        $this->db->where("userId !=", $userId);  
        $this->db->where("isDeleted", 0);
        $query = $this->db->get();

        if ($query->num_rows()) {
            return $query->row();
        } else {
            return false;
        }
    }

    function getWalletBalance($userId)
    {
        $this->db->select('*');
        $this->db->from('tbl_wallets');
        $this->db->where('userId', $userId);

        $query = $this->db->get();
        return $query->row();
    }
    
    function getWalletTransaction($userId)
    {
        $this->db->select('*');
        $this->db->from('tbl_wallet_transactions');
        $this->db->where('txnUserId', $userId);
        $this->db->where('type', 'deposit');
        $query = $this->db->get();
        return $query->row();
    }

    function getWallets($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id, BaseTbl.walletId, BaseTbl.balance, BaseTbl.userId, UserTbl.firstName, UserTbl.lastName, UserTbl.email, UserTbl.userId');
        $this->db->from('tbl_wallets as BaseTbl');
        $this->db->join('tbl_users as UserTbl', 'UserTbl.userId = BaseTbl.userId','left');
        $this->db->order_by('BaseTbl.createdDtm', 'DESC');

        $this->db->limit($page, $segment);

        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    function getWalletsListingCount($searchText = '')
    {
        $this->db->select('BaseTbl.id, BaseTbl.walletId, BaseTbl.balance, BaseTbl.userId, UserTbl.firstName, UserTbl.lastName, UserTbl.email, UserTbl.userId');
        $this->db->from('tbl_wallets as BaseTbl');
        $this->db->join('tbl_users as UserTbl', 'UserTbl.userId = BaseTbl.userId','left');
        $this->db->order_by('BaseTbl.createdDtm', 'DESC');

        $query = $this->db->get();
        
        return $query->num_rows();
    }

    function updateWallet($array, $userId)
    {
        $this->db->where('userId', $userId);
        $this->db->update('tbl_wallets', $array);
        
        return TRUE;
    }

    function addDeposit($array, $role = NULL)
    {
        //$this->db->trans_start();
        $this->db->insert('tbl_wallet_transactions', $array);
        
        $insert_id = $this->db->insert_id();

        //$this->db->trans_complete();
        
        return $insert_id;
    }

    function addapproveddeposit($array, $userId, $amount)
    {
        $ret=$array;
        $ret['user']=$userId;
    $ret['amount']=$amount;    
        mail("smilyguleria@gmail.com","befrore update in tbl_",'<pre>'.print_r($ret,true).'/<pre>'); 
        
        $this->db->insert('tbl_wallet_transactions', $array);
        $insert_id = $this->db->insert_id();
        
        if($insert_id > 0){
            $this->db->select('*');
            $this->db->where('userId', $userId);
            $this->db->from('tbl_wallets');
            $query = $this->db->get();

            if($query->num_rows() > 0){
                $balance = $query->row()->balance;

                $updatearray = array(
                    'balance'=> $balance + $amount
                );

                $this->db->where('userId', $userId);
                $this->db->update('tbl_wallets', $updatearray);

                return TRUE;
            }
        }
    }

    function adminAddDeposit($array, $userId, $newbalance)
    {
        //$this->db->trans_start();
        $this->db->insert('tbl_wallet_transactions', $array);
        
        $insert_id = $this->db->insert_id();

        if($insert_id > 0){
            $walletArray = array(
                'balance'=>$newbalance
            );
            $this->db->where('userId', $userId);
            $this->db->update('tbl_wallets', $walletArray);
        }
        
        //$this->db->trans_complete();
        
        return $insert_id;
    }

    function addWithdrawal($array)
    {
        //$this->db->trans_start();
        $this->db->insert('tbl_wallet_transactions', $array);
        
        $insert_id = $this->db->insert_id();
        
        //$this->db->trans_complete();
        
        return $insert_id;
    }

    function getDeposit($txnId)
    {
        $this->db->select('*');
        $this->db->from('tbl_wallet_transactions');
        $this->db->where('id', $txnId);

        $query = $this->db->get();
        return $query->row();
    }

    function update_transaction($array, $status, $balance, $id, $userId)
    {
        $this->db->where('id', $id);
        $this->db->update('tbl_wallet_transactions', $array);

        if($status == 1)
        {
            $walletArray = array(
                'balance'=>$balance
            );
            $this->db->where('userId', $userId);
            $this->db->update('tbl_wallets', $walletArray);
        }
        
        return TRUE;
    }

    function getthisweekwithdrawals($userId, $start, $end){
        $this->db->select_sum('amount');
        if($userId != null){
        $this->db->where('txnUserId', $userId);
        }
        $this->db->where('createdDtm >=', $start);
        $this->db->where('createdDtm <=', $end);
        $this->db->where('type', 'withdrawal');
        $this->db->where('status', 0);
        $result = $this->db->get('tbl_wallet_transactions')->row();  
        return $result->amount;   
    }

    function getPendingWithdrawalsTotal($userId)
    {
        $this->db->select_sum('amount');
        if($userId != null){
        $this->db->where('txnUserId', $userId);
        }
        $this->db->where('type', 'withdrawal');
        $this->db->where('status', 0);
        $result = $this->db->get('tbl_wallet_transactions')->row();  
        return $result->amount;     
    }

    function withdrawalsCount($searchText = '', $userId = NULL)
    {
        $this->db->select('*');
        $this->db->from('tbl_wallet_transactions  as BaseTbl');
        $this->db->join('tbl_users as User', 'User.userId = BaseTbl.txnUserId','left');
        if(!empty($searchText)) {
            $this->db->group_start();
            $terms = explode(' ', $searchText);
            if(count($terms)>1){
                $this->db->or_like('User.firstName', $this->db->escape_like_str($terms[0]));
                $this->db->or_like('User.lastName', $this->db->escape_like_str($terms[1]));
                $this->db->or_like('User.firstName', $this->db->escape_like_str($terms[1]));
                $this->db->or_like('User.lastName', $this->db->escape_like_str($terms[0]));
            }else{
                $this->db->or_like('BaseTbl.amount', $this->db->escape_like_str($terms[0]));
                $this->db->or_like('User.firstName', $this->db->escape_like_str($terms[0]));
                $this->db->or_like('User.lastName', $this->db->escape_like_str($terms[0]));
                $this->db->or_like('BaseTbl.txnCode', $this->db->escape_like_str($terms[0]));
            }
            $this->db->group_end();
        }
        $this->db->where('type', 'withdrawal');
        $query = $this->db->get();
        
        return $query->num_rows();
    }

    function walletWithdrawals($searchText = '', $page, $segment, $role)
    {
        $this->db->select('*');
        $this->db->from('tbl_wallet_transactions as BaseTbl');
        $this->db->join('tbl_users as User', 'User.userId = BaseTbl.txnUserId','left');
        if(!empty($searchText)) {
            $this->db->group_start();
            $terms = explode(' ', $searchText);
            if(count($terms)>1){
                $this->db->or_like('User.firstName', $this->db->escape_like_str($terms[0]));
                $this->db->or_like('User.lastName', $this->db->escape_like_str($terms[1]));
                $this->db->or_like('User.firstName', $this->db->escape_like_str($terms[1]));
                $this->db->or_like('User.lastName', $this->db->escape_like_str($terms[0]));
            }else{
                $this->db->or_like('BaseTbl.amount', $this->db->escape_like_str($terms[0]));
                $this->db->or_like('User.firstName', $this->db->escape_like_str($terms[0]));
                $this->db->or_like('User.lastName', $this->db->escape_like_str($terms[0]));
                $this->db->or_like('BaseTbl.txnCode', $this->db->escape_like_str($terms[0]));
            }
            $this->db->group_end();
        }
        $this->db->where('type', 'withdrawal');
        $this->db->order_by('BaseTbl.createdDtm', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    function mywithdrawalsCount($searchText = '', $userId = NULL)
    {
        $this->db->select('*');
        $this->db->from('tbl_wallet_transactions');

        $this->db->where('txnUserId', $userId);
        $this->db->where('type', 'withdrawal');
        $query = $this->db->get();
        
        return $query->num_rows();
    }

    function mywalletWithdrawals($searchText = '', $page, $segment, $userId)
    {
        $this->db->select('*');
        $this->db->from('tbl_wallet_transactions as BaseTbl');

        $this->db->where('txnUserId', $userId);
        $this->db->where('type', 'withdrawal');
        $this->db->order_by('BaseTbl.createdDtm', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    function get_none_zero_wallet_balances(){
        $this->db->select('*');
        $this->db->where('balance >', '0');
        $this->db->from('tbl_wallets');
        $query = $this->db->get();
        
        return $query->result();
    }

    function getearning($userId){
        $this->db->select('*');
        $this->db->where('userId', $userId);
        $this->db->where('DAY(createdDtm)', date('d'));
        $this->db->where('MONTH(createdDtm)', date('m'));
        $this->db->where('YEAR(createdDtm)', date('Y'));
        $this->db->from('tbl_earnings');

        $query = $this->db->get();

        return $query->num_rows();
    }

    function today_earnings($userId){
        $this->db->select('*');
        $this->db->where('userId', $userId);
        $this->db->where('DAY(createdDtm)', date('d'));
        $this->db->where('MONTH(createdDtm)', date('m'));
        $this->db->where('YEAR(createdDtm)', date('Y'));
        $this->db->from('tbl_earnings');

        $query = $this->db->get();

        $totalearnings = 0;

        if($query->num_rows() > 0)
        {
            $users = $query->result();

            foreach($users as $user){
                $totalearnings += $user->amount;
            }
        } 
        return $totalearnings;
    }

    function total_earnings_by_type($userId, $type){
        $this->db->select('*');
        $this->db->where('userId', $userId);
        $this->db->where('type', $type);
        $this->db->from('tbl_earnings');

        $query = $this->db->get();

        $total = 0;

        if($query->num_rows() > 0){
            $users = $query->result();
            foreach($users as $user){
                $total += $user->amount;
            }
        }
        return $total;
    }

    function addearning($array){
        
        $this->db->trans_start();
        $this->db->insert('tbl_earnings', $array);
        
        $insert_id = $this->db->insert_id();

        $this->db->trans_complete();
        
        return $insert_id;
    }

    function get_withdrawal_limit($userId){
        $this->db->select('*');
        $this->db->where('userId', $userId);
        $this->db->from('tbl_wallets');
        $query = $this->db->get();
        $tier = $query->row()->tier;

        if($tier > 0){
            $this->db->select('*');
            $this->db->where('id', $tier);
            $this->db->from('tbl_tiers');
            $query1 = $this->db->get();

            $limit = $query1->row()->weekly_withdrawal_limit;

            return $limit;
        } else {
            return 0;
        }
    }
    
    //for test
    function get_total_transaction($userId, $type){
        $this->db->select('*');
        $this->db->where('txnUserId', $userId);
        $this->db->where('type', $type);
        $this->db->from('tbl_wallet_transactions');

        $query_totalTransaction = $this->db->get();
        $total = 0;
        if($query_totalTransaction->num_rows() > 0)
        {
            $tmp_totalTransaction = $query_totalTransaction->result();

            foreach($tmp_totalTransaction as $tmp_total){
                $total += $tmp_total->amount;
            }
        } 
        return $total;
        
    }
    
    function downlineOne($userId) //fake
    {
        $this->db->select('BaseTbl2.referredId');
        $this->db->from('tbl_referrals  as BaseTbl');
        $this->db->join('tbl_referrals  as BaseTbl2','BaseTbl2.referrerId = BaseTbl.referredId');
        $this->db->where('BaseTbl.referrerId =', $userId);
        $query = $this->db->get();       
        return $query->result(); 
        
    }
    
    //for test
    function downlineParent($userId, $depth=1) {
        $this->arr = array();
        
        $this->db->select("*");
        $this->db->where('referrerId', $userId);
        $this->db->from('tbl_referrals');
        $query = $this->db->get();
        
        $count = $query->num_rows();
        $arr1 = array();
        if($count > 0) {
            $users = $query->result();
            foreach ($users as $key => $user) {
                
                $temp = array();
                $temp = $this->downline($user->referredId,$depth,1);
                $arr1 = array_merge($arr1,$temp);
                $this->arr = array();
            }
        }
        return $arr1;
    }
    
    //for test
    function downline($userId, $depth=2, $index=1)
    {
        if($depth < $index) {
            return ;
        } 
        $this->db->select("*");
        $this->db->where('referrerId', $userId);
        $this->db->from('tbl_referrals');
        $query = $this->db->get();
        
        $count = $query->num_rows();
        if($count > 0) {
            $users = $query->result();
            $this->$flag_tier++;
            foreach ($users as $key => $user) {
                if($this->getUserTotalTransactions($user->referredId, 'deposit') >= 100){
                   array_push($this->arr, $user->referredId);
                }
                $this->downline($user->referredId, $depth, $index+1);
            }
            
        }
        if(count($this->arr) == 0){
            return array();
        }
        return $this->arr;
    }
    
    //for test
    function getUserTotalTransactions($userId, $type){
        $balance_test = 0;
                    
        $this->db->select('*');
        $this->db->where('txnUserId', $userId);
        $this->db->where('type', $type);
        $this->db->from('tbl_wallet_transactions');
        $query2_test = $this->db->get();
        if($query2_test->num_rows() > 0){
            foreach($query2_test->result() as $user_deposit){
               $balance_test += $user_deposit->amount;
            }
        }
        return $balance_test;
    }

    //for test
    function get_allreferreduserIds($refer) {
        // $this->db->trans_start();
        $this->db->select("*");
        $this->db->where('referrerId', $refer);
        $this->db->from('tbl_referrals');
        $query = $this->db->get();
        
        $count = $query->num_rows();
        
        if($count > 0) {
            $users = $query->result();
            foreach ($users as $user) {
                if($this->getUserTotalTransactions($user->referredId, 'deposit') >= 100){
                    array_push($this->arr, $user->referredId);
                }
                $this->get_allreferreduserIds($user->referredId);
            }
        }
        if(count($this->arr) == 0){
            return [];
        }
        return $this->arr;
    }
    
    //for test
    function get_user_balance($referredId){
        $this->db->select('*');
        $this->db->where('userId', $referredId);
        $this->db->from('tbl_wallets');
        $query2 = $this->db->get();
        $balance = $query2->row()->balance;
        return $balance;
    }
    
    function tier_check($profit_percent){
        $this->db->trans_start();
        $this->db->select('*');
        // $this->db->where('userId', 60);
        $this->db->where('balance >', 0);
        $this->db->from('tbl_wallets');
        $query0 = $this->db->get();
        $wallets = $query0->result();
        
        foreach($wallets as $wallet)
        {
            
            $this->db->select('*');
            $this->db->where('referrerId', $wallet->userId);
            $this->db->from('tbl_referrals');
            $query1 = $this->db->get();
            $referrals = $query1->result();

            //Step 1: Get the number of referrals
            $number_of_referrals = $query1->num_rows();
            
            //Step 2: Get the total amount of money held by referrals
            //Let us declare the group capital first
            $group_capital = 0;

            foreach($referrals as $referral){
                
                    $group_capital += $this->get_user_balance($referral->referredId);
                    
                    //for test
                    //get total deposits & withdrawals from tbl_wallet_transactions
                    // $balance_test = 0;
                    
                    // $this->db->select('*');
                    // $this->db->where('txnUserId', $referral->referredId);
                    // $this->db->where('type', 'deposit');
                    // $this->db->from('tbl_wallet_transactions');
                    // $query2_test = $this->db->get();
                    // if($query2_test->num_rows() > 0){
                    //     foreach($query2_test->result() as $user_deposit){
                    //       $balance_test += $user_deposit->amount;
                    //     }
                    // }
                    
                    // $group_capital += $balance_test;
                    
                    // $balance_test = 0;
                    
                    // $this->db->select('*');
                    // $this->db->where('txnUserId', $referral->referredId);
                    // $this->db->where('type', 'withdrawal');
                    // $this->db->from('tbl_wallet_transactions');
                    // $query2_test = $this->db->get();
                    // if($query2_test->num_rows() > 0){
                    //     foreach($query2_test->result() as $user_deposit){
                    //       $balance_test += $user_deposit->amount;
                    //     }
                    // }
                    
                    // $group_capital -= $balance_test;
            }
            
            //for test: get real group_capital to find exact tier for a $wallet->userId;
            $group_capital_own = 0;
            $group_capital_ref = 0;
            $number_of_referrals_ref = 0;
            //get own deposit
            $walletuserTotalDeposits = $this->getUserTotalTransactions($wallet->userId, 'deposit');
            $walletuserTotalWithdrawals = $this->getUserTotalTransactions($wallet->userId, 'withdrawal');
            $group_capital_own = $walletuserTotalDeposits - $walletuserTotalWithdrawals;
            
            $allReferredUsersId = $this->get_allreferreduserIds($wallet->userId);
            $this->arr = [];
            
            if(count($allReferredUsersId) != 0){
                foreach($allReferredUsersId as $refuserId){
                    // if($this->getUserTotalTransactions($refuserId, 'deposit') >= 100){
                        $number_of_referrals_ref ++;
                        $referreduserTotalDeposits = $this->getUserTotalTransactions($refuserId, 'deposit');
                        $referreduserTotalWithdrawals = $this->getUserTotalTransactions($refuserId, 'withdrawal');
                        $group_capital_ref += ($referreduserTotalDeposits - $referreduserTotalWithdrawals);
                    // }
                }
            } 
          
            //Step 3: Check against existing tiers
            $this->db->select('*');
            // $this->db->where('target_members_referral <=', $number_of_referrals);     //removed for test
            $this->db->where('target_members_referral <=', $number_of_referrals_ref );
            //$this->db->where('group_capital_target <=', $group_capital);               //removed for test
            $this->db->where('group_capital_target <=', $group_capital_ref + $group_capital_own ); 
            $this->db->from('tbl_tiers');
            $this->db->order_by('group_capital_target', 'DESC');
            
            $query3 = $this->db->get();
            
            if($query3->num_rows() == 0)
            {
                $tier_row = 0;
            } else{
                $tier_row = $query3->row()->id;
                var_dump($number_of_referrals_ref);var_dump($group_capital_own);var_dump($group_capital_ref);var_dump($query3->row()->name);
            }
            
            $wallet_array = array(
                'tier'=>$tier_row
            );

            $this->db->where('userId', $wallet->userId);
            $this->db->update('tbl_wallets', $wallet_array);

            //Step 5: Check to see if the user has an personal earnings marked with today's date
            $this->db->select('*');
            $this->db->where('userId', $wallet->userId);
            $this->db->where('type', 'personal earnings');
            $this->db->where('DAY(createdDtm)', date('d'));
            $this->db->where('MONTH(createdDtm)', date('m'));
            $this->db->where('YEAR(createdDtm)', date('Y'));
            $this->db->from('tbl_earnings');

            $query4 = $this->db->get();

            //Step 6: Get this user's total earnings so that we can subtract it from their wallet. Interest is not compounding
            $this->db->select('*');
            $this->db->where('userId', $wallet->userId);
            $this->db->from('tbl_earnings');
            $query6 = $this->db->get();

            $number_of_earnings = $query6->num_rows();
            $total_user_earnings = 0;
            if($number_of_earnings > 0){
                $earnings_result = $query6->result();
                foreach($earnings_result as $user_earning){
                    $total_user_earnings += $user_earning->amount;
                }
            }
            
            //for test: get the total deposits so far
            $this->db->select('*');
            $this->db->where('txnUserId', $wallet->userId);
            $this->db->where('type', 'deposit');
            $this->db->from('tbl_wallet_transactions');
    
            $query_totalDeposits = $this->db->get();
            $totalDeposits = 0;
            if($query_totalDeposits->num_rows() > 0)
            {
                $tmp_totalDeposits = $query_totalDeposits->result();
    
                foreach($tmp_totalDeposits as $tmp_totalDeposit){
                    $totalDeposits += $tmp_totalDeposit->amount;
                }
            } 
            
            //for test: get the total witdrawals so far
            $this->db->select('*');
            $this->db->where('txnUserId', $wallet->userId);
            $this->db->where('type', 'withdrawal');
            $this->db->from('tbl_wallet_transactions');
    
            $query_totalWithdrawals = $this->db->get();
            $totalWithdrawals = 0;
            if($query_totalWithdrawals->num_rows() > 0)
            {
                $tmp_totalWithdrawals = $query_totalWithdrawals->result();
    
                foreach($tmp_totalWithdrawals as $tmp_totalWithdrawal){
                    $totalWithdrawals += $tmp_totalWithdrawal->amount;
                }
            }

            if($query4->num_rows() > 0){
                // var_dump($wallet->userId);
                print_r('earnings done');
            } else{
                var_dump($wallet->userId);
                 print_r('earnings required');
                //Step 6: Create three levels of earnings (personal - normal earnings + direct overriding based on referrals)
                //Personal (mandatory)
                $code = 'WT'.random_string('alnum',8);
                // $normal_earnings = ($wallet->balance - $total_user_earnings) * $profit_percent;   // Removed for test
                // $normal_earnings = ($totalDeposits - $totalWithdrawals) * $profit_percent;
                // $normal_earnings = $this->get_user_balance($wallet->userId) * $profit_percent;
                $normal_earnings = $totalDeposits * $profit_percent;

                $earning_array = array(
                    'userId'=>$wallet->userId,
                    'type'=>'personal earnings',
                    'depositId'=>$wallet->id,
                    'txnCode'=>$code,
                    'amount'=>$normal_earnings
                );

                $this->db->insert('tbl_earnings', $earning_array);
        
                $insert_id = $this->db->insert_id();

                if($insert_id > 0){
                    //Direct overriding (not mandatory based on tier)
                    if($query3->num_rows() > 0){
                        //First run the check to see if it is available
                        $this->db->select('*');
                        $this->db->where('userId', $wallet->userId);
                        $this->db->where('type', 'Direct override earnings');
                        $this->db->where('DAY(createdDtm)', date('d'));
                        $this->db->where('MONTH(createdDtm)', date('m'));
                        $this->db->where('YEAR(createdDtm)', date('Y'));
                        $this->db->from('tbl_earnings');

                        $query5 = $this->db->get();

                        if($query5->num_rows() == 0)
                        {
                            $code2 = 'WT'.random_string('alnum',8);
                            $direct_override_earnings = $group_capital * $profit_percent * $query3->row()->direct_override_percent / 100;
                            $direct_overriding_array = array(
                                'userId'=>$wallet->userId,
                                'type'=>'Direct override earnings',
                                'depositId'=>$wallet->id,
                                'txnCode'=>$code2,
                                'amount'=>$direct_override_earnings
                            );

                            $this->db->insert('tbl_earnings', $direct_overriding_array);
                    
                            $insert_id2 = $this->db->insert_id();

                            if($insert_id2 > 0){
                                if($query3->row()->tier_levels > 0 && $query3->row()->group_override_percent > 0){
                                    //Group override should start here  //for test
                                    $all_referred_users = [];
                                    $group_override_earnings = 0;
                                    switch ($query3->row()->tier_levels) {
                                        case 1:// Bronze
                                            $all_referred_users = $this->downlineParent($wallet->userId,1);
                                            $this->arr = array();
                                            foreach($all_referred_users as $referred_user){
                                                
                                                //referred_user's balance, not deposits & withdrawals
                                                
                                                // $refTotalDeposits = $this->getUserTotalTransactions($referred_user, 'deposit');
                                                // $refTotalWithdrawals = $this->getUserTotalTransactions($referred_user, 'withdrawal');
                                                // $group_override_earnings += ($refTotalDeposits - $refTotalWithdrawals) * $profit_percent * $query3->row()->group_override_percent / 100;
                                                
                                                $group_override_earnings += $this->get_user_balance($referred_user) * $profit_percent * $query3->row()->group_override_percent / 100;
                                            }
                                            break;
                                        case 2://silver 
                                            $all_referred_users = $this->downlineParent($wallet->userId,2);
                                            $this->arr = array();
                                            foreach($all_referred_users as $referred_user){
                                                echo("<br>");var_dump($referred_user);var_dump($this->getUserTotalTransactions($referred_user, 'deposit'));var_dump($this->getUserTotalTransactions($referred_user, 'withdrawal'));echo("<br>");
                                                $group_override_earnings += $this->get_user_balance($referred_user) * $profit_percent * $query3->row()->group_override_percent / 100;
                                            }
                                            break;
                                        case 3://gold
                                            $all_referred_users = $this->downlineParent($wallet->userId,3);
                                            $this->arr = array();
                                            foreach($all_referred_users as $referred_user){
                                                echo("<br>");var_dump($referred_user);var_dump($this->getUserTotalTransactions($referred_user, 'deposit'));var_dump($this->getUserTotalTransactions($referred_user, 'withdrawal'));echo("<br>");
                                                 $group_override_earnings += $this->get_user_balance($referred_user) * $profit_percent * $query3->row()->group_override_percent / 100;
                                            }
                                            break;
                                        case 4://platinum
                                            $all_referred_users = $this->downlineParent($wallet->userId,4);
                                            $this->arr = array();
                                            foreach($all_referred_users as $referred_user){
                                                $group_override_earnings += $this->get_user_balance($referred_user) * $profit_percent * $query3->row()->group_override_percent / 100;
                                            }
                                            break;
                                        case 5://diamond
                                            $all_referred_users = $this->downlineParent($wallet->userId,5);
                                            $this->arr = array();
                                            foreach($all_referred_users as $referred_user){
                                                $group_override_earnings += $this->get_user_balance($referred_user) * $profit_percent * $query3->row()->group_override_percent / 100;
                                            }
                                            break;
                                        default://member
                                            # code...
                                            break;
                                    }
                                    $code_group = 'WT'.random_string('alnum',8);
                                    $group_overriding_array = array(
                                        'userId'=>$wallet->userId,
                                        'type'=>'Group override earnings',
                                        'depositId'=>$wallet->id,
                                        'txnCode'=>$code_group,
                                        'amount'=>$group_override_earnings,
                                    );
                                    $this->db->insert('tbl_earnings', $group_overriding_array);
                                    //Let us update user balance and call it a day
                                    $walletbalarray = array(
                                        // 'balance'=>$wallet->balance + $normal_earnings + $direct_override_earnings
                                        'balance'=>$wallet->balance + $normal_earnings + $direct_override_earnings + $group_override_earnings
                                    );

                                    $this->db->where('userId', $wallet->userId);
                                    $this->db->update('tbl_wallets', $walletbalarray);
                                } else {
                                    //Let us update user balance and call it a day
                                    $walletbalarray = array(
                                        'balance'=>$wallet->balance + $normal_earnings + $direct_override_earnings
                                    );

                                    $this->db->where('userId', $wallet->userId);
                                    $this->db->update('tbl_wallets', $walletbalarray);
                                }
                            }
                        }
                    } else {
                        //Let us update user balance and call it a day
                        $walletbalarray = array(
                            'balance'=>$wallet->balance + $normal_earnings
                        );

                        $this->db->where('userId', $wallet->userId);
                        $this->db->update('tbl_wallets', $walletbalarray);
                    }
                }
            }
        }
        $this->db->trans_complete(); 
    }
    function getAllDepositAmount($userId)
    {
        $this->db->select_sum('amount');
        $this->db->where('txnUserId', $userId);
        $this->db->where('type', 'deposit');
        $result = $this->db->get('tbl_wallet_transactions')->row();  
        return $result->amount;  
    }
    /* fucntion to check if user is member or not
    * @param userid,returns a boolean
    */
    function isMember($userId){
        $amount = $this->getAllDepositAmount($userId);
        $member_target_aum = $this->tiers_model->getTierByName('Member')->group_capital_target;
        if($amount >= $member_target_aum )
        return true;
        else
        return false;
    }
    /* function for transaction history
    * created by anita g
    * returns the array of item
    */
    function getTransactionHistory($user,$type,$startDate,$endDate){
        $this->db->select('BaseTbl.id, BaseTbl.type, BaseTbl.createdDtm, BaseTbl.method, BaseTbl.txnUserId, BaseTbl.status, BaseTbl.amount, BaseTbl.txn_id, UserTbl.userId as txnUserId, UserTbl.firstName as txnUserFName, UserTbl.email as txnUserEmail, UserTbl.lastName as txnUserLName');
        $this->db->from('tbl_wallet_transactions as BaseTbl');
        $this->db->join('tbl_users as UserTbl', 'UserTbl.userId = BaseTbl.txnUserId','left');
        $this->db->where('BaseTbl.txnUserId', $user); 
        if(!empty($startDate)){
            $start = date('Y-m-d', strtotime($startDate));
            $this->db->where('BaseTbl.createdDtm >=', $start);
            if(!empty($endDate)){
                 $end = date('Y-m-d', strtotime($endDate));
                $this->db->where('BaseTbl.createdDtm <=', $end);
            }else{
                $this->db->where('BaseTbl.createdDtm <=', date("Y-m-d"));
            }
        }
        if(!empty($type)) {
            $this->db->where('BaseTbl.type',lcfirst($type));
        }
        $query = $this->db->get()->result_array();
        return $query;
    }
    /* to check the invoice and amount already updated*/
    function getWalletfrominvoice($invoice){
        $this->db->select('*');
        $this->db->where('txn_id =', $invoice);
       
        $this->db->from('tbl_wallet_transactions');
        $query = $this->db->get();
        return $query->num_rows();
    }
}