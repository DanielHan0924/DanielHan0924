<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Plans (PlansController)
 * Error class to perform CRUD functions on tiers
 * @author : Axis96
 * @version : 1.0
 * @since : 07 December 2019
 */
class Tiers extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public  $depositAumAmount=0;
    public function __construct()
    {
        parent::__construct();
        $this->load->model('plans_model');
        $this->load->model('payments_model');
        $this->load->model('user_model');
        $this->load->model('login_model');
        $this->load->model('twilio_model');
        $this->load->model('tiers_model');
        $this->load->model('wallet_model');
        $this->load->model('referral_model');
        $this->isLoggedIn();   
    }
    public function index(){

        //get user's target_members_referral value   
         $vendorId = $this->session->userdata('userId');
         $tie_name = $this->getUserTierInfo($vendorId);
        $data['tierforvendor'] = $this->tiers_model->getTierByLevel($tie_name);
        //get wallet transaction period to see the deposit loyalty bonus
        $userWalletTransaction = $this->wallet_model->getWalletTransaction($vendorId);
        $userBroughtStartDate = $userWalletTransaction->createdDtm;
        if(count((array)$userWalletTransaction)>0){
        $userBroughtStartDate = $userWalletTransaction->createdDtm;
        $today = date("Y-m-d");
        $ts1 = strtotime($userBroughtStartDate);
        $ts2 = strtotime($today);
        $year1 = date('Y', $ts1);
        $year2 = date('Y', $ts2);
        $month1 = date('m', $ts1);
        $month2 = date('m', $ts2);
        $data['diff'] = (($year2 - $year1) * 12) + ($month2 - $month1);
        }
        else{
        $data['diff'] = 0;    
        }
        
        $searchText = $this->input->post('searchText' ,TRUE);
        $data['searchText'] = $searchText;
        $role = '3';
        $this->global['pageTitle'] = 'Investment Tiers';
        $this->global['displayBreadcrumbs'] = true; 
        $this->global['breadcrumbs'] = 'Tiers'.' <span class="breadcrumb-arrow-right"></span> '.'Incentive'; 

        $this->loadViews('tiers/incentive', $this->global, $data, NULL);
    }
    
     function showOtherTier($newtier){
        $data['tierforvendor'] = $this->tiers_model->getTierByName($newtier);
        echo json_encode($data);
    }

    /**
     * @access: Admin Only
     * This function is used to load the investment plans list
     */
    function list()
    {
        $module_id = 'plans';
        $module_action = 'view';
        if($this->isAdmin($module_id, $module_action) == FALSE)
        {
            $this->loadThis();
        }
        else
        {        
            $searchText = $this->input->post('searchText' ,TRUE);
            $data['searchText'] = $searchText;
            $role = '3';
            
            $this->load->library('pagination');
            
            $count = $this->tiers_model->tierListingCount($searchText);

			$returns = $this->paginationCompress ( "tiers/", $count, 10 );
            
            $data['tiers'] = $this->tiers_model->getAllTiers($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Investment Tiers';
            $this->global['displayBreadcrumbs'] = true; 
            $this->global['breadcrumbs'] = 'Investment Tiers'.' <span class="breadcrumb-arrow-right"></span> '.'View'; 
            
            $this->loadViews("tiers/table", $this->global, $data, NULL);
        }
    }

    /**
     * @access: Admin Only
     * @desc: This function is used to load the add new plan form
     */
    function new()
    {
        $module_id = 'plans';
        $module_action = 'add';
        if($this->isAdmin($module_id, $module_action) == FALSE)
        {
            $this->loadThis();
        }
        else
        {
            $this->global['pageTitle'] = 'Create Tier';
            $this->global['displayBreadcrumbs'] = true; 
            $this->global['breadcrumbs'] = 'Tier Class'.' <span class="breadcrumb-arrow-right"></span> '.'New'; 

            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('tname','Tier Name','required');
            $this->form_validation->set_rules('personal_target_amount','Personal Target Amount','required');
            $this->form_validation->set_rules('group_target_amount','Group Target Amount','required');
            $this->form_validation->set_rules('target_referrals','Target Referrals','required');
            $this->form_validation->set_rules('tier_levels','Tier Levels','required');
            $this->form_validation->set_rules('tier_percent','Direct Override','required');
            $this->form_validation->set_rules('group_override','Group Override','required');
            $this->form_validation->set_rules('withdrawal_limit','Withdrawal Limit','required');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->session->set_flashdata('errors', validation_errors());
            }
            else
            {
                $tname = ucwords(strtolower($this->input->post('tname', TRUE)));
                $personal_target_amount = $this->input->post('personal_target_amount', TRUE);
                $group_target_amount = $this->input->post('group_target_amount', TRUE);
                $target_referrals = $this->input->post('target_referrals', TRUE);
                $tier_levels = $this->input->post('tier_levels', TRUE);
                $tier_percent = $this->input->post('tier_percent', TRUE);
                $group_percent = $this->input->post('group_override', TRUE);
                $withdrawal_limit = $this->input->post('withdrawal_limit', TRUE);
                
                $planInfo = array(
                    'name'=>$tname, 
                    'personal_capital_target'=>$personal_target_amount, 
                    'group_capital_target'=>$group_target_amount,
                    'target_members_referral'=>$target_referrals,
                    'tier_levels'=>$tier_levels,
                    'direct_override_percent'=>$tier_percent, 
                    'group_override_percent'=>$group_percent,
                    'weekly_withdrawal_limit'=> $withdrawal_limit, 
                    'createdDtm'=>date('Y-m-d H:i:s')
                );
                    
                $result = $this->tiers_model->add($planInfo);
                    
                if($result>0)
                {
                    $this->session->set_flashdata('success', 'Tier class created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Tier creation failed');
                }

                redirect('tiers/new');
            }
            
            $this->loadViews("tiers/new", $this->global, NULL, NULL);
        }
    }

    /**
     * @access: Admin Only
     * This function is used load the edit plan form
     * @param number $planId : Optional : This is the plan id
     */
    function edit($tierId = NULL)
    {
        $module_id = 'plans';
        $module_action = 'edit';
        if($this->isAdmin($module_id, $module_action) == FALSE)
        {
            $this->loadThis();
        }
        else
        {

            $this->global['pageTitle'] = 'Edit Tier';
            $this->global['displayBreadcrumbs'] = true; 
            $this->global['breadcrumbs'] = 'Tiers'.' <span class="breadcrumb-arrow-right"></span> '.'Edit'; 

            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('tname','Tier Name','required');
            $this->form_validation->set_rules('personal_target_amount','Personal Target Amount','required');
            $this->form_validation->set_rules('group_target_amount','Group Target Amount','required');
            $this->form_validation->set_rules('target_referrals','Target Referrals','required');
            $this->form_validation->set_rules('tier_levels','Tier levels','required');
            $this->form_validation->set_rules('tier_percent','Direct Override','required');
            $this->form_validation->set_rules('group_override','Group Override','required');
            $this->form_validation->set_rules('withdrawal_limit','Withdrawal Limit','required');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->session->set_flashdata('errors', validation_errors());
            }
            else
            {
                $tname = ucwords(strtolower($this->input->post('tname', TRUE)));
                $personal_target_amount = $this->input->post('personal_target_amount', TRUE);
                $group_target_amount = $this->input->post('group_target_amount', TRUE);
                $target_referrals = $this->input->post('target_referrals', TRUE);
                $tier_levels = $this->input->post('tier_levels', TRUE);
                $tier_percent = $this->input->post('tier_percent', TRUE);
                $withdrawal_limit = $this->input->post('withdrawal_limit', TRUE);
                $group_percent = $this->input->post('group_override', TRUE);
                
                $array = array(
                    'name'=>$tname, 
                    'personal_capital_target'=>$personal_target_amount, 
                    'group_capital_target'=>$group_target_amount, 
                    'target_members_referral'=>$target_referrals, 
                    'tier_levels'=>$tier_levels,
                    'direct_override_percent'=>$tier_percent,
                    'group_override_percent'=>$group_percent,
                    'weekly_withdrawal_limit'=> $withdrawal_limit,  
                    'createdDtm'=>date('Y-m-d H:i:s')
                );
                
                $result = $this->tiers_model->edit($array, $tierId);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Tier class updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Tier class update failed');
                }
                
                redirect('tiers/edit/'.$tierId);
            }
            
            $this->global['pageTitle'] = 'Edit Tier';
            $data['tierInfo'] = $this->tiers_model->getTierInfo($tierId);
            
            $this->loadViews("tiers/edit", $this->global, $data, NULL);
        }
    }

    
    /**
     * @access: Admin Only
     * This function is used to delete the plan using the planId
     * @return boolean $result : TRUE / FALSE
     */
    function delete($tierId = NULL)
    {
        $module_id = 'plans';
        $module_action = 'edit';
        if($this->isAdmin($module_id, $module_action) == FALSE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $csrfTokenName = $this->security->get_csrf_token_name();
            $csrfHash = $this->security->get_csrf_hash();

            $this->load->library('form_validation');
            $this->form_validation->set_rules('password','Password','required');
            $this->form_validation->set_rules('id','Plan ID','required');

            if($this->form_validation->run() == FALSE)
            {
                $this->session->set_flashdata('errors', validation_errors());
                $errors = array();
                // Loop through $_POST and get the keys
                foreach ($this->input->post() as $key => $value)
                {
                    // Add the error message for this field
                    $errors[$key] = form_error($key);
                }
                $response['errors'] = array_filter($errors); // Some might be empty
                $response['success'] = false;
                $response["csrfTokenName"] = $csrfTokenName;
                $response["csrfHash"] = $csrfHash;
                $response['msg'] = html_escape('Please correct the errors and try again.');

                echo json_encode($response); 
            } else
            {
                //$userId = $this->input->post('id', TRUE);
                $password = $this->input->post('password', TRUE);
                $useremail = $this->user_model->getUserInfoById($this->vendorId)->email;

                $result = $this->login_model->loginMe($useremail, $password);
                if(!empty($result))
                {
                    $result1 = $this->tiers_model->delete($tierId);
                
                    if ($result1 > 0) { 
                        $array = array(
                            'success' => true,
                            'msg' => html_escape('Succesfully Deleted Tier'),
                            "csrfTokenName" => $csrfTokenName,
                            "csrfHash" => $csrfHash
                        );

                        echo json_encode($array);
                    }
                    else { 
                        $array = array(
                            'success' => false,
                            'msg' => html_escape('There was an error in deleting your tier class. Please reload the page and try again'),
                            "csrfTokenName" => $csrfTokenName,
                            "csrfHash" => $csrfHash
                        );
                        
                        echo json_encode($array);
                    }

                }else{
                    $array = array(
                        'success' => false,
                        'msg' => html_escape('Incorrect password. Please try again'),
                        "csrfTokenName" => $csrfTokenName,
                        "csrfHash" => $csrfHash
                    );
    
                    echo json_encode($array);
                }
            }
        }
    }
    /* check the tier of the user
     * based on the user id,
     * must be a member first
     */
    function getUserTierInfo($userId){
        //check if user is member first
        $isMember = $this->wallet_model->isMember($userId); 
        if($isMember){
          $get_personal_deposit = $this->wallet_model->getAllDepositAmount($userId);
          $get_group_deposit = $this->getAumDeposit($userId) + $get_personal_deposit; 
         //get users downlines' deposit
         $membercount = $this->referral_model->getMembersCount($userId);
         echo "members:".$membercount." Group deposit: ".$get_group_deposit;
         $tie_name = $this->getTier($membercount, $get_group_deposit);
        }else{
         //randonm tier
         $tie_name = 7;
        }
        return $tie_name;
     }
     /* get deposit and group aum 
     *  @param userid or the parent in the network
     * return the group target AUM
     * BY anita g
     */
      function getAumDeposit($userId){
          $member_target_aum = $this->tiers_model->getTierByName('Member')->group_capital_target;
          $row1=[];
         $row = $this->db->query('select tb2.referredId,SUM(tb1.amount) as deposit,tb1.type from tbl_wallet_transactions as tb1 JOIN ( SELECT id, referrerId,referredId from tbl_referrals WHERE referrerId="'.$userId.'" ) tb2 on tb2.referredId=tb1.txnUserId WHERE tb1.type="deposit" GROUP BY tb2.referredId')->result_array();
         foreach($row as $key => $value)
         {
             if($value['deposit']>=$member_target_aum)
            $this->$depositAumAmount = $this->$depositAumAmount + $value['deposit']; 
             $nextlink = $this->getAumDeposit($value['referredId']);
             if(!empty($nextlink)){
                 $row1[$key]['reference'] = array_values($nextlink); 
             }
         }
         return $this->$depositAumAmount;
     }
     /*
     * get tier name on member wise and Aum wise
     * by Anita g
     * return tier level after calculating the tier user falls to
     */
     function getTier($members_referral, $group_deposit){
         try
         {
             $bronze_target_value = $this->tiers_model->getTierByName('Bronze')->target_members_referral;
             $bronze_target_aum = $this->tiers_model->getTierByName('Bronze')->group_capital_target;
             $bronze_tier = $this->tiers_model->getTierByName('Bronze')->tier_levels;
       
             $silver_target_value = $this->tiers_model->getTierByName('Silver')->target_members_referral;
             $silver_target_aum = $this->tiers_model->getTierByName('Silver')->group_capital_target;
             $silver_tier = $this->tiers_model->getTierByName('Silver')->tier_levels;
       
            $gold_target_value = $this->tiers_model->getTierByName('Gold')->target_members_referral;
            $gold_target_aum = $this->tiers_model->getTierByName('Gold')->group_capital_target;
            $gold_tier = $this->tiers_model->getTierByName('Gold')->tier_levels;
       
            $platinum_target_value = $this->tiers_model->getTierByName('Platinum')->target_members_referral;
            $platinum_target_aum = $this->tiers_model->getTierByName('Platinum')->group_capital_target;
            $platinum_tier = $this->tiers_model->getTierByName('Platinum')->tier_levels; 
       
            $diamond_target_value = $this->tiers_model->getTierByName('Diamond')->target_members_referral;
            $diamond_target_aum = $this->tiers_model->getTierByName('Diamond')->group_capital_target;
            $diamond_tier = $this->tiers_model->getTierByName('Diamond')->tier_levels;
            $tie_name = '';
               if(($members_referral >= $bronze_target_value ) && $members_referral < $silver_target_value ){
                   $member_wise_tier = $bronze_tier;
               }else if($members_referral >= $silver_target_value && $members_referral < $gold_target_value ){
                   $member_wise_tier = $silver_tier;
               }else if($members_referral >= $gold_target_value && $members_referral < $platinum_target_value ){
                   $member_wise_tier = $gold_tier;
               }else if($members_referral >= $platinum_target_value && $members_referral <  $diamond_target_value){
                   $member_wise_tier = $platinum_tier;
               }else if($members_referral >= $diamond_target_value){
                   $member_wise_tier = $diamond_tier;
               }else{
                   $member_wise_tier = 0;
               }
     
              if(($group_deposit >= $bronze_target_aum ) && $group_deposit < $silver_target_aum){
                 $deposit_wise_tier = $bronze_tier;
             }else if($group_deposit >= $silver_target_aum && $group_deposit < $gold_target_aum ){
                 $deposit_wise_tier = $silver_tier;
             }else if($group_deposit >= $gold_target_aum && $group_deposit < $platinum_target_aum ){
                 $deposit_wise_tier = $gold_tier;
             }else if($group_deposit >= $platinum_target_aum && $group_deposit <  $diamond_target_aum){
                 $deposit_wise_tier = $platinum_tier;
             }else if($group_deposit >= $diamond_target_aum){
                 $deposit_wise_tier = $diamond_tier;
             }else{
                 $deposit_wise_tier = 0;
             }
     
             if($member_wise_tier == $deposit_wise_tier){
                 $tier = $member_wise_tier; 
             }else if($member_wise_tier > $deposit_wise_tier){
                 $tier = $deposit_wise_tier;
             }else{
                 $tier = $member_wise_tier;
             }
             return $tier;
         }
         catch (\Exception $e)
         {
             return 1;
         }
        
     }
     function memberTestCount(){
         $membercount = $this->referral_model->getMembersCount(60);
     }
 

}