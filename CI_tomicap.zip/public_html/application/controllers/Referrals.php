<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Referrals (ReferralsController)
 * Referrals Class
 * @author : Axis96
 * @version : 1.0
 * @since : 07 December 2019
 */
class Referrals extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('transactions_model');
        $this->load->model('settings_model');
        $this->load->model('email_model');
        $this->load->model('twilio_model');
        $this->load->model('referral_model');
        $this->isLoggedIn();   
    }
    /**
     * This function used to send an invite link to new users
     */
    public function invite()
    {
        $csrfTokenName = $this->security->get_csrf_token_name();
        $csrfHash = $this->security->get_csrf_hash();
        $this->load->library('form_validation');
        $this->form_validation->set_rules('email','Email','trim|required|valid_email|max_length[128]');

        if($this->form_validation->run() == FALSE)
        {
            $array = array(
                'success' => false,
                'msg' => html_escape('Please enter the email address of the person you want to refer us to'),
                "csrfTokenName" => $csrfTokenName,
                "csrfHash" => $csrfHash
            );

            echo json_encode($array);
        }
        else
        { 
            $data = $this->user_model->getUserInfo($this->vendorId);
            $name = $data->firstName;
            $refcode = $data->refCode;
            $joinLink = base_url()."signup/".$data->refCode;

            //Send Mail
            $conditionUserMail = array('tbl_email_templates.type'=>'Referral Invitation');
            $resultEmail = $this->email_model->getEmailSettings($conditionUserMail);

            $companyInfo = $this->settings_model->getsettingsInfo();
        
            if($resultEmail->num_rows() > 0)
            {
                $rowUserMailContent = $resultEmail->row();
                $splVars = array(
                    "!referrerName" => $name,
                    "!referralLink" => $joinLink,
                    "!companyName" => $companyInfo['name'],
                    "!address" => $companyInfo['address'],
                    "!siteurl" => base_url()
                );

            $mailSubject = strtr($rowUserMailContent->mail_subject, $splVars);
            $mailContent = strtr($rowUserMailContent->mail_body, $splVars); 	

            $toEmail = $this->security->xss_clean($this->input->post('email'));
            $fromEmail = $companyInfo['SMTPUser'];

            $name = 'Support';

            $header = "From: ". $name . " <" . $fromEmail . ">\r\n"; //optional headerfields

            $send = $this->email_model->sendHtmlMail($toEmail,$fromEmail,$mailSubject,$mailContent,null);

            if($send == true) {
                $array = array(
                    'success' => true,
                    'msg' => html_escape('Your invitation has been sent succesfully'),
                    "csrfTokenName" => $csrfTokenName,
                    "csrfHash" => $csrfHash
                );

                echo json_encode($array);
            } else {
                $array = array(
                    'success' => false,
                    'msg' => html_escape('There is an error in sending your invitation. Please try again later.'),
                    "csrfTokenName" => $csrfTokenName,
                    "csrfHash" => $csrfHash
                );

                echo json_encode($array);
            }
            }           
        }
    }
    
    /**
     * This function is used to load the referral list
     * anita
     */
    function referrals()
    {
        
        $data['referralinfo']=$this->referral_model->referrals($this->vendorId);
        $this->global['pageTitle'] = 'Referrals';
        $this->global['displayBreadcrumbs'] = false; 
        
         $role = '3';
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        $this->load->library('pagination');            
        $this->loadViews("referrals/referral", $this->global, $data, NULL);
        // $count = $this->wallet_model->mywithdrawalsCount($searchText, $this->vendorId);
        // $returns = $this->paginationCompress ( "withdrawals/", $count, 10 );
            
        // $searchText = $this->input->post('searchText', TRUE);
        // $this->global['searchText'] = $this->input->post('searchText', TRUE);
       /* if($this->role == ROLE_CLIENT)
        {
            // $data['transactions'] = $this->wallet_model->mywalletwithdrawals($searchText, $returns["page"], $returns["segment"], $this->vendorId);
            // $data['earningsInfo'] = $this->transactions_model->getEarningsTotal($this->vendorId);
            // $data['withdrawalsInfo'] = $this->transactions_model->getPendingWithdrawalsTotal($this->vendorId);
            
            // $this->global['pageTitle'] = 'Withdrawals';
            // $this->global['displayBreadcrumbs'] = false; 
            // $this->loadViews("wallets/withdrawals", $this->global, $data, NULL);
        }
        else
        {  
            // $module_id = 'withdrawals';
            // $module_action = 'view';
            // if($this->isAdmin($module_id, $module_action) == FALSE)
            // {
            //     $this->loadThis();
            // } else 
            // {
            //     $role = '3';
            
            //     $this->load->library('pagination');
                
            //     $count = $this->wallet_model->withdrawalsCount($searchText, NULL);
            //     $returns = $this->paginationCompress ( "wallets/withdrawals/", $count, 10 );
                
            //     $data['transactions'] = $this->wallet_model->walletWithdrawals($searchText, $returns["page"], $returns["segment"], $role);
                
            //     $this->global['pageTitle'] = 'Withdrawals';
            //     $this->global['displayBreadcrumbs'] = false; 
            //     $this->loadViews("wallets/withdrawals", $this->global, $data, NULL);
            // }      
        }*/
    }
    
    /**
     * This function is used to load the downline user list
     * anita
     */
    function downline1($userId){
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        $data['referralinfo']=$this->referral_model->downlineOne($userId);
    
        $this->global['pageTitle'] = 'Refferals';
        $this->global['displayBreadcrumbs'] = false; 
         $role = '3';
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        $this->load->library('pagination');            
        $this->loadViews("referrals/referral", $this->global, $data, NULL);
        
    }
    
    /**
     * This function is used to load the downline2 user list
     * anita
     */
    function downline2($userId){
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        $data['referralinfo']=$this->referral_model->downlineTwo($userId);
        $this->global['pageTitle'] = 'Refferals';
        $this->global['displayBreadcrumbs'] = false; 
         $role = '3';
         
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        $this->load->library('pagination');            
        $this->loadViews("referrals/referral", $this->global, $data, NULL);
        
    }
    /**
     * This function is used to load the downline3 user list of user
     * anita
     */
    function downline3($userId){
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        $data['referralinfo']=$this->referral_model->downlineThree($userId);
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        $this->load->library('pagination');            
        $this->loadViews("referrals/referral", $this->global, $data, NULL);
    }
    /**
     * This function is used to load the downaline4 hierrachy
     * anita
     */
    function downline4($userId){
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        $data['referralinfo']=$this->referral_model->downlineFour($userId);
        $this->load->library('pagination');            
        $this->loadViews("referrals/referral", $this->global, $data, NULL);
    }
    function treeview($userId){
        $data['userInfo'] = $this->user_model->getUserInfo($userId);
        $data['upline']=$this->referral_model->upline($userId);
        $data['downline']=$this->referral_model->referrals($userId);
        $this->loadViews("referrals/treeview", $this->global, $data, NULL);
    }
    /**
     * Get All Data from this method fro treeview.
     *
     * @return Response
    */
     function membersTree($parent)
    {
        $row1 = [];
        //$row = $this->db->query('SELECT BaseTbl.id, BaseTbl.referrerId,User.firstName from tbl_referrals as BaseTbl JOIN tbl_users as User on User.userId = BaseTbl.referredId WHERE BaseTbl.referrerId="'.$parent.'"')->result_array();
         $row = $this->db->query('SELECT IF(sum(tb.amount),sum(tb.amount),0) as deposit,tb3.* FROM tbl_wallet_transactions as tb RIGHT JOIN( SELECT BaseTbl.id,BaseTbl.referredId, BaseTbl.referrerId,User.firstName from tbl_referrals as BaseTbl JOIN tbl_users as User on User.userId = BaseTbl.referredId WHERE BaseTbl.referrerId="'.$parent.'" ) tb3 on tb.txnUserId=tb3.referredId GROUP by tb3.referredId')->result_array();
        foreach($row as $key => $value)
        {
            $id = $key;
            $row1[$key]['id'] = $value['id'];
            $row1[$key]['name'] = $value['id'];
            $row1[$key]['text'] = $value['firstName'].'- $'.$value['deposit'];
            if(!empty($this->membersTree($value['id']))){
                $row1[$key]['nodes'] = array_values($this->membersTree($value['id']));
            }
            // $row1[$key]['nodes'] = array_values($this->membersTree($value['id']));
            $i++;
        }
        return $row1;
    }
       /**
     * Get All Data from this method.
     * created by anita
     * @return Response
    */
     function getItem()
     {
         $user = $_GET['userid'];
        $data = [];
        $parent = $this->referral_model->upline($user);
        $loggedinuser=$this->referral_model->getNode($user);
        /* if the user downline is empty or not*/
        if(!empty($this->membersTree($loggedinuser[0]->userId))){
            $currentuser = array(array(
                'id'=>$loggedinuser[0]->userId,
                'name'=>$loggedinuser[0]->firstName,
                'text'=>$loggedinuser[0]->firstName,
                'nodes'=>$this->membersTree($loggedinuser[0]->userId))
            );
        }else{
            $currentuser = array(array(
                'id'=>$loggedinuser[0]->userId,
                'name'=>$loggedinuser[0]->firstName,
                'text'=>$loggedinuser[0]->firstName
            ));
        }

        if(!empty($parent)){
            $superparent=$this->referral_model->getNode($parent[0]->referrerId);           
            $data = array(array(  
                        'id'=>$superparent[0]->userId,
                        'name'=>$superparent[0]->firstName,
                        "text"=>$superparent[0]->firstName,
                        'nodes'=>array_values($currentuser)));   
            // $data= array(array('id'=>$parent[0]->userId,
            // 'name'=>$parent[0]->firstName,
            // "text"=>$parent[0]->firstName,
            // 'nodes'=>$this->membersTree($parent[0]->userId)));
        }else{
            $parent = $this->referral_model->getNode($user);
            //$data= array(array('id'=>$loggedinuser[0]->userId,'name'=>$loggedinuser[0]->firstName,"text"=>$loggedinuser[0]->firstName,'nodes'=>$this->membersTree($loggedinuser[0]->userId)));
            $data = $currentuser;
        }
        echo json_encode(array_values($data));
    }
    

}