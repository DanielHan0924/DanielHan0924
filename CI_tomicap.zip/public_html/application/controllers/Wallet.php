<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Home (HomeController)
 * Home class to display the main site
 * @author : Axis96
 * @version : 1.0
 * @since : 07 December 2019
 */
class wallet extends BaseController {

	public function __construct()
    {
        parent::__construct();
		$this->load->model('settings_model');
        $this->load->model('transactions_model');
        $this->load->model('wallet_model');
        $this->load->model('user_model');
		$this->load->model('email_model');
        $this->load->model('twilio_model');
        $this->load->model('payments_model');
        $this->load->model('login_model');
        $this->isLoggedIn(); 
    }

    function view()
    {
        $companyInfo = $this->settings_model->getsettingsInfo();
		
        $this->global['pageTitle'] = 'Send Money';
        $this->global['displayBreadcrumbs'] = true; 
        $this->global['breadcrumbs'] = 'Fund Transfers'.' <span class="breadcrumb-arrow-right"></span> '.'Send';

        $earningsInfo = $this->transactions_model->getEarningsTotal($this->vendorId);
        $withdrawals = $this->transactions_model->getWithdrawalsTotal($this->vendorId);
        $pendingWithdrawals = $this->transactions_model->getPendingWithdrawalsTotal($this->vendorId);
        $walletBalance = $this->wallet_model->getWalletBalance($this->vendorId)->balance;
        $accountBalance = abs($walletBalance - $pendingWithdrawals);

        $data['companyInfo'] = $companyInfo;
        $data['earningsInfo'] = $earningsInfo;
        $data['withdrawals'] = $withdrawals;
        $data['pendingWithdrawals'] = $pendingWithdrawals;
        $data['accountInfo'] = $accountBalance;

        $this->loadViews('/wallets/send', $this->global, $data, NULL);
    }
    /*testing litecoin */
    
    public function testdeposit()
    {
        
        $companyInfo = $this->settings_model->getsettingsInfo();
        $data["companyInfo"] = $companyInfo ;
        $this->global['pageTitle'] = 'Wallet Deposit';
        $this->global['displayBreadcrumbs'] = true; 
        $this->global['breadcrumbs'] = 'Wallet'.' <span class="breadcrumb-arrow-right"></span> '.'Add Money';
        $data['breadcrumbs'] = "Wallet / Add Money";
        $this->load->helper('string');
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        if ($this->role == ROLE_CLIENT) 
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('amount','Amount','required');
            $this->form_validation->set_rules('payMethod','Payment Method','required');

            if($this->form_validation->run() == FALSE)
            {
                $this->session->set_flashdata('errors', validation_errors());
            }
            else
            {
                $amount = $this->input->post('amount', TRUE);
                $method = $this->input->post('payMethod', TRUE);
                $txnId = 'WD'.random_string('alnum',8);

                if($method == 'ST') 
                {
                    $paymentData = array(
                        'DepositAmount'  => $amount,
                    );
                
                    $this->session->set_userdata($paymentData);
                    // 'item' will be erased after 300 seconds
                    $this->session->mark_as_temp(array('DepositAmount'), 300);

                    redirect('/stripe-payment');
                }
                else if($method == 'PP')
                {
                    $methodData = $this->payments_model->getInfo('tbl_addons_api', 'paypal');
                    $cc_amount = $companyInfo['currency'] == 'USD' ? $amount : $amount/$companyInfo['currency_exchange_rate'];
                    $config = [
                        "clientID"=> $methodData->public_key,
                        "currency"=>"USD", //default is USD
                        "intent"=>"sale", //default is sale
                        "mode"=>$methodData->env,
                        "invoiceNumber"=>$code,
                        "clientSecret"=> $methodData->secret_key,
                        "redirectUrl"=> base_url('paypal/success'),//controller method paypal will return here after success
                        "cancelUrl"=>base_url('paypal/canceled')//localhost/paypal-integration-ci/index.php/welcome/payment/canceled"//controller method paypal will return here after cancel
                    ];
                    $this->load->library('paypal',$config);
                    $result = $this->paypal->pay($cc_amount);
                    $deposit_array = array(
                        'userid'=>$this->vendorId,
                        'invoice'=>$txnId,
                        'txn_id'=>$result["payment"]->id,
                        'local_currency'=>$amount,
                        'payment_gross'=>$cc_amount,
                        'currency_code'=>'USD',
                        'payer_email'=>'NA',
                        'payment_status'=>'0',
                        'createdDtm'=>date('Y-m-d H:i:s')

                    );
                    $this->payments_model->addPaypal($deposit_array);
                    if($result["error"] == '') { 
                        redirect($result["approval_url"]);
                    } else { 
                        $this->session->set_flashdata('error', 'There is an error depositing via Paypal');
                        redirect('/deposits/new');
                    }
                }
                else if($method == 'BT')
                {
                    $paymentData = array(
                        'DepositAmount'  => $amount
                    );
                
                    $this->session->set_userdata($paymentData);
                    // 'item' will be erased after 300 seconds
                    $this->session->mark_as_temp(array('DepositAmount', 'planId'), 300);
                    redirect('/bank-transfer');
                }
                else if($method == 'BTC' || $method == 'ETH' || $method == 'USDT' || $method == 'DASH' || $method == 'XRP' || $method == 'BCH')
                {
                    
                    $paymentData = array(
                        'DepositAmount'  => $amount,
                        'method' => 'LTCT'
                    );
                
                    $this->session->set_userdata($paymentData);
                    // 'item' will be erased after 300 seconds
                    $this->session->mark_as_temp(array('DepositAmount', 'planId'), 300);

                    redirect('/test-coin-payment');
                }
            }
            $data['paymentMethods'] = $this->payments_model->getPaymentMethods('1'); //Status 1 are activated payment methods
            $earningsInfo = $this->transactions_model->getEarningsTotal($this->vendorId);
            $withdrawals = $this->transactions_model->getWithdrawalsTotal($this->vendorId);
            $pendingWithdrawals = $this->transactions_model->getPendingWithdrawalsTotal($this->vendorId);
            $walletBalance = $this->wallet_model->getWalletBalance($this->vendorId)->balance;
            $accountBalance = abs($walletBalance - $pendingWithdrawals);
            $data['walletBalance'] = $accountBalance;
         echo "fetching ltct";   
            $this->loadViews("wallets/deposittest", $this->global, $data);
        } else {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('email', 'Email', 'required');
            $this->form_validation->set_rules('amount','Amount','trim|required|max_length[128]');
            if($this->form_validation->run() == FALSE)
            {
                $this->session->set_flashdata('errors', validation_errors());
            }
            else
            {
                $email = $this->input->post('email', TRUE);
                $amount = $this->input->post('amount', TRUE);
                $method = 'Manual';
                $txnId = 'WD'.random_string('alnum',8);

                //Check if email exists for client
                $emailCheck = $this->login_model->checkClientExist($email, '3');

                if($emailCheck)
                {
                    $depositArray = array(
                        'txnUserId'=>$emailCheck->userId,
                        'type'=>'deposit',
                        'txn_id'=>$txnId,
                        'amount'=>$amount,
                        'method'=>$method,
                        'status'=>1
                    );

                    $balance = $this->wallet_model->getWalletBalance($emailCheck->userId)->balance;
                    $newBalance = $balance + $amount;

                    $result = $this->wallet_model->adminAddDeposit($depositArray, $emailCheck->userId, $newBalance);

                    if($result > 0)
                    {
                        //Send Mail
                        $conditionUserMail = array('tbl_email_templates.type'=>'Notify Admin');
                        $resultEmail = $this->email_model->getEmailSettings($conditionUserMail);

                        $companyInfo = $this->settings_model->getsettingsInfo();
                        $userInfo = $this->user_model->getUserInfo($emailCheck->userId);
                    
                        if($resultEmail->num_rows() > 0)
                        {
                            $rowUserMailContent = $resultEmail->row();
                            $splVars = array(
                                "!name" => $userInfo->firstName.' '.$userInfo->lastName,
                                "!email" => $userInfo->email,
                                "!type"=> $method,
                                "!amount"=> to_currency($amount),
                                "!companyName" => $companyInfo['name'],
                                "!address" => $companyInfo['address'],
                                "!siteurl" => base_url()
                            );

                            $mailSubject = strtr($rowUserMailContent->mail_subject, $splVars);
                            $mailContent = strtr($rowUserMailContent->mail_body, $splVars); 	

                            $toEmail = $companyInfo['email'];
                            $fromEmail = $companyInfo['SMTPUser'];

                            $name = 'Support';

                            $header = "From: ". $name . " <" . $fromEmail . ">\r\n"; //optional headerfields

                            $send = $this->email_model->sendHtmlMail($toEmail,$fromEmail,$mailSubject,$mailContent,NULL);

                        }
                        $this->session->set_flashdata('error', 'Deposit has been created succesfully.');
                        redirect('/wallets/test_deposit_amount');
                    } else
                    {
                        $this->session->set_flashdata('error', 'There is an error making a deposit');
                        redirect('/wallets/test_deposit_amount');
                    }

                } else{
                    $this->session->set_flashdata('error', 'This email does not exist');
                }
            }
            $this->loadViews("wallets/deposittest", $this->global, $data);
        }
    }

    public function deposit()
    {
        $companyInfo = $this->settings_model->getsettingsInfo();
        $data["companyInfo"] = $companyInfo ;
        $this->global['pageTitle'] = 'Wallet Deposit';
        $this->global['displayBreadcrumbs'] = true; 
        $this->global['breadcrumbs'] = 'Wallet'.' <span class="breadcrumb-arrow-right"></span> '.'Add Money';
        $data['breadcrumbs'] = "Wallet / Add Money";
        $this->load->helper('string');
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        if ($this->role == ROLE_CLIENT) 
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('amount','Amount','required');
            $this->form_validation->set_rules('payMethod','Payment Method','required');

            if($this->form_validation->run() == FALSE)
            {
                $this->session->set_flashdata('errors', validation_errors());
            }
            else
            {
                $amount = $this->input->post('amount', TRUE);
                $method = $this->input->post('payMethod', TRUE);
                $txnId = 'WD'.random_string('alnum',8);

                if($method == 'ST') 
                {
                    $paymentData = array(
                        'DepositAmount'  => $amount,
                    );
                
                    $this->session->set_userdata($paymentData);
                    // 'item' will be erased after 300 seconds
                    $this->session->mark_as_temp(array('DepositAmount'), 300);

                    redirect('/stripe-payment');
                }
                else if($method == 'PP')
                {
                    $methodData = $this->payments_model->getInfo('tbl_addons_api', 'paypal');
                    $cc_amount = $companyInfo['currency'] == 'USD' ? $amount : $amount/$companyInfo['currency_exchange_rate'];
                    $config = [
                        "clientID"=> $methodData->public_key,
                        "currency"=>"USD", //default is USD
                        "intent"=>"sale", //default is sale
                        "mode"=>$methodData->env,
                        "invoiceNumber"=>$code,
                        "clientSecret"=> $methodData->secret_key,
                        "redirectUrl"=> base_url('paypal/success'),//controller method paypal will return here after success
                        "cancelUrl"=>base_url('paypal/canceled')//localhost/paypal-integration-ci/index.php/welcome/payment/canceled"//controller method paypal will return here after cancel
                    ];
                    $this->load->library('paypal',$config);
                    $result = $this->paypal->pay($cc_amount);
                    $deposit_array = array(
                        'userid'=>$this->vendorId,
                        'invoice'=>$txnId,
                        'txn_id'=>$result["payment"]->id,
                        'local_currency'=>$amount,
                        'payment_gross'=>$cc_amount,
                        'currency_code'=>'USD',
                        'payer_email'=>'NA',
                        'payment_status'=>'0',
                        'createdDtm'=>date('Y-m-d H:i:s')

                    );
                    $this->payments_model->addPaypal($deposit_array);
                    if($result["error"] == '') { 
                        redirect($result["approval_url"]);
                    } else { 
                        $this->session->set_flashdata('error', 'There is an error depositing via Paypal');
                        redirect('/deposits/new');
                    }
                }
                else if($method == 'BT')
                {
                    $paymentData = array(
                        'DepositAmount'  => $amount
                    );
                
                    $this->session->set_userdata($paymentData);
                    // 'item' will be erased after 300 seconds
                    $this->session->mark_as_temp(array('DepositAmount', 'planId'), 300);
                    redirect('/bank-transfer');
                }
                else if($method == 'BTC' || $method == 'ETH' || $method == 'USDT' ||  $method == 'USDT-ERC20' || $method == 'DASH' || $method == 'XRP' || $method == 'BCH')
                {
                    
                    $paymentData = array(
                        'DepositAmount'  => $amount,
                        'method' => $method
                    );
                
                    $this->session->set_userdata($paymentData);
                    // 'item' will be erased after 300 seconds
                    $this->session->mark_as_temp(array('DepositAmount', 'planId'), 300);

                    redirect('/coin-payment');
                }
            }
            $data['paymentMethods'] = $this->payments_model->getPaymentMethods('1'); //Status 1 are activated payment methods
            $earningsInfo = $this->transactions_model->getEarningsTotal($this->vendorId);
            $withdrawals = $this->transactions_model->getWithdrawalsTotal($this->vendorId);
            $pendingWithdrawals = $this->transactions_model->getPendingWithdrawalsTotal($this->vendorId);
            $walletBalance = $this->wallet_model->getWalletBalance($this->vendorId)->balance;
            $accountBalance = abs($walletBalance - $pendingWithdrawals);
            $data['walletBalance'] = $accountBalance;
            $this->loadViews("wallets/deposit", $this->global, $data);
        } else {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('email', 'Email', 'required');
            $this->form_validation->set_rules('amount','Amount','trim|required|max_length[128]');
            if($this->form_validation->run() == FALSE)
            {
                $this->session->set_flashdata('errors', validation_errors());
            }
            else
            {
                $email = $this->input->post('email', TRUE);
                $amount = $this->input->post('amount', TRUE);
                $method = 'Manual';
                $txnId = 'WD'.random_string('alnum',8);

                //Check if email exists for client
                $emailCheck = $this->login_model->checkClientExist($email, '3');

                if($emailCheck)
                {
                    $depositArray = array(
                        'txnUserId'=>$emailCheck->userId,
                        'type'=>'deposit',
                        'txn_id'=>$txnId,
                        'amount'=>$amount,
                        'method'=>$method,
                        'status'=>1
                    );

                    $balance = $this->wallet_model->getWalletBalance($emailCheck->userId)->balance;
                    $newBalance = $balance + $amount;

                    $result = $this->wallet_model->adminAddDeposit($depositArray, $emailCheck->userId, $newBalance);

                    if($result > 0)
                    {
                        //Send Mail
                        $conditionUserMail = array('tbl_email_templates.type'=>'Notify Admin');
                        $resultEmail = $this->email_model->getEmailSettings($conditionUserMail);

                        $companyInfo = $this->settings_model->getsettingsInfo();
                        $userInfo = $this->user_model->getUserInfo($emailCheck->userId);
                    
                        if($resultEmail->num_rows() > 0)
                        {
                            $rowUserMailContent = $resultEmail->row();
                            $splVars = array(
                                "!name" => $userInfo->firstName.' '.$userInfo->lastName,
                                "!email" => $userInfo->email,
                                "!type"=> $method,
                                "!amount"=> to_currency($amount),
                                "!companyName" => $companyInfo['name'],
                                "!address" => $companyInfo['address'],
                                "!siteurl" => base_url()
                            );

                            $mailSubject = strtr($rowUserMailContent->mail_subject, $splVars);
                            $mailContent = strtr($rowUserMailContent->mail_body, $splVars); 	

                            $toEmail = $companyInfo['email'];
                            $fromEmail = $companyInfo['SMTPUser'];

                            $name = 'Support';

                            $header = "From: ". $name . " <" . $fromEmail . ">\r\n"; //optional headerfields

                            $send = $this->email_model->sendHtmlMail($toEmail,$fromEmail,$mailSubject,$mailContent,NULL);

                        }
                        $this->session->set_flashdata('error', 'Deposit has been created succesfully.');
                        redirect('/wallets/deposit_amount');
                    } else
                    {
                        $this->session->set_flashdata('error', 'There is an error making a deposit');
                        redirect('/wallets/deposit_amount');
                    }

                } else{
                    $this->session->set_flashdata('error', 'This email does not exist');
                }
            }
            $this->loadViews("wallets/deposit", $this->global, $data);
        }
    }

    function approveTransaction($transactionId, $status)
    {
        $module_id = 'wallets';
        $module_action = 'view';
        if($this->isAdmin($module_id, $module_action) == FALSE)
        {
            $this->loadThis();
        } 
        else
        {
            $csrfTokenName = $this->security->get_csrf_token_name();
            $csrfHash = $this->security->get_csrf_hash();
            $this->load->library('form_validation');
            $this->form_validation->set_rules('password','Password','required');

            if($this->form_validation->run() == FALSE)
            {
                $errors = array();
                // Loop through $_POST and get the keys
                foreach ($this->input->post() as $key => $value)
                {
                    // Add the error message for this field
                    $errors[$key] = form_error($key);
                }
                $response['errors'] = array_filter($errors); // Some might be empty
                $response['success'] = false;
                $response["csrfTokenName"] = $csrfTokenName;
                $response["csrfHash"] = $csrfHash;
                $response['msg'] = html_escape('Please correct the errors and try again.');

                echo json_encode($response); 
            }
            else
            {
                $password = $this->input->post('password', TRUE);
                $useremail = $this->user_model->getUserInfoById($this->vendorId)->email;

                $result = $this->login_model->loginMe($useremail, $password);
                if(!empty($result))
                {
                    //Get the user's balance
                    $depoInfo = $this->wallet_model->getDeposit($transactionId);

                    $array = array(
                        'status'=>$status
                    );
                    if($status == 1)
                    {
                        $type = $depoInfo->type;
                        $deposit_amount = $depoInfo->amount;

                        if($type == 'deposit'){
                            $balance = $this->wallet_model->getWalletBalance($depoInfo->txnUserId)->balance;
                            $newBalance = $balance + $deposit_amount;
                        } else if($type == 'withdrawal'){
                            $balance = $this->wallet_model->getWalletBalance($depoInfo->txnUserId)->balance;
                            $newBalance = $balance - $deposit_amount;
                        }
                        $changeStatus = $this->wallet_model->update_transaction($array, $status, $newBalance, $transactionId, $depoInfo->txnUserId);
                    } else
                    {
                        $changeStatus = $this->wallet_model->update_transaction($array, $status, 0, $transactionId, $depoInfo->txnUserId);
                    }

                    if($changeStatus == TRUE)
                    {
                        $response = array(
                            'success'=>true,
                            'tid'=>$transactionId,
                            'status'=>$status == 1 ? 'Approved' : 'Cancelled'
                        );

                        echo json_encode($response);
                    } else
                    {
                        $response = array(
                            'success'=>false
                        );

                        echo json_encode($response);
                    }
                }
            }
        }
    }

    public function user_wallets()
    {
        $module_id = 'wallets';
        $module_action = 'view';
        if($this->isAdmin($module_id, $module_action) == FALSE)
        {
            $this->loadThis();
        } 
        else
        {
            $this->load->library('pagination');
            $companyInfo = $this->settings_model->getsettingsInfo();

            $this->global['displayBreadcrumbs'] = false; 
            $this->global['pageTitle'] = 'Client Wallets';
            
            /**Filters */
            $searchText = $this->input->post('searchText' ,TRUE);
            $startDate  = $this->input->post('start-date', TRUE);
            $endDate    = $this->input->post('end-date', TRUE);

            $count = $this->wallet_model->getWalletsListingCount($searchText);
            $returns = $this->paginationCompress ( "wallets/view/", $count, 10, 3 );

            $data['transactions'] = $this->wallet_model->getWallets($searchText, $returns["page"], $returns["segment"]);
            $data['companyInfo'] = $companyInfo;

            $this->loadViews('/wallets/view', $this->global, $data, NULL);
        }
    }

    public function editWallet($id)
    {
        $module_id = 'wallets';
        $module_action = 'edit';
        if($this->isAdmin($module_id, $module_action) == FALSE)
        {
            $this->loadThis();
        } 
        else
        {
            $data['walletInfo'] = $this->wallet_model->getWalletBalance($id);
            $data['userInfo'] = $this->user_model->getUserInfo($id);
            $this->global['pageTitle'] = 'Edit Wallet';   
            $this->global['displayBreadcrumbs'] = true; 
            $this->global['breadcrumbs'] = 'Wallets'.' <span class="breadcrumb-arrow-right"></span> '.'Edit';         
            $this->loadViews("wallets/edit", $this->global, $data, NULL);
        }
    }

    function updateWallet($userId){
        $module_id = 'wallets';
        $module_action = 'edit';
        if($this->isAdmin($module_id, $module_action) == FALSE)
        {
            $this->loadThis();
        } 
        else
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('balance','Balance Amount','required');

            if($this->form_validation->run() == FALSE)
            {
                $this->session->set_flashdata('errors', validation_errors());
            }
            else
            {
                $balance = $this->input->post('balance', TRUE);
                $array = array(
                    'balance'=>$balance
                );

                $result = $this->wallet_model->updateWallet($array, $userId);

                if($result == TRUE)
                {
                    $this->session->set_flashdata('success', 'Updated successfully');
                }else{
                    $this->session->set_flashdata('error', 'Update failed');
                }

                redirect('wallets/edit/'.$userId);
            }
        }
    }

    public function deposits()
	{
        $module_id = 'wallets';
        $module_action = 'deposits';
        if($this->isAdmin($module_id, $module_action) == FALSE)
        {
            $this->loadThis();
        } 
        else
        {
            $this->load->library('pagination');
            $companyInfo = $this->settings_model->getsettingsInfo();
            
            $this->global['displayBreadcrumbs'] = false; 
    
            $data['companyInfo'] = $companyInfo;
            $data['userId'] = $this->vendorId;
    
            /**Filters */
            $searchText = $this->input->post('searchText' ,TRUE);
            $startDate  = $this->input->post('start-date', TRUE);
            $endDate    = $this->input->post('end-date', TRUE);
    
            $count = $this->wallet_model->wallet_transactionsListingCount($searchText, 'deposit', NULL, false);
            $returns = $this->paginationCompress ( "wallets/deposits/", $count, 10,3 );
    
            $this->global['pageTitle'] = 'Wallet Deposits';
            $data['searchText'] = $searchText;
            $data['transactions'] = $this->wallet_model->wallet_transactions($searchText, 'deposit', $this->vendorId, false, $returns["page"], $returns["segment"], $startDate, $endDate);
    
            $this->loadViews('/wallets/table', $this->global, $data, NULL);
        }
    } 
    
    public function editDeposits()
    {
        $module_id = 'wallets';
        $module_action = 'deposits';
        if($this->isAdmin($module_id, $module_action) == FALSE)
        {
            $this->loadThis();
        } 
        else
        {

        }
    }
    
    public function transactions()
	{
        $this->load->library('pagination');
        $companyInfo = $this->settings_model->getsettingsInfo();
        
        $this->global['displayBreadcrumbs'] = false; 

        $data['companyInfo'] = $companyInfo;
        $data['userId'] = $this->vendorId;

        /**Filters */
        $searchText = $this->input->post('searchText' ,TRUE);
        $startDate  = $this->input->post('start-date', TRUE);
        $endDate    = $this->input->post('end-date', TRUE);       

        $data['searchText'] = $searchText;

		if ($this->role == ROLE_CLIENT) {
            $count = $this->wallet_model->wallet_transactionsListingCount($searchText, 'deposit', $this->vendorId, NULL);
            $returns = $this->paginationCompress ( "wallet/transactions/", $count, 10, 3 );
            $this->global['pageTitle'] = 'My Transactions';
            // $this->wallet_model->getTransactionHistory($this->vendorId,$type,$startDate,$endDate);
            $data['transactions'] = $this->wallet_model->wallet_transactions($searchText, 'deposit', $this->vendorId, true, $returns["page"], $returns["segment"], $startDate, $endDate);
        } else {
            $count = $this->wallet_model->wallet_transactionsListingCount($searchText, 'deposit', NULL, NULL);
            $returns = $this->paginationCompress ( "wallets/transactions/", $count, 10, 3 );
            $this->global['pageTitle'] = 'Money Transfers';
            $data['transactions'] = $this->wallet_model->wallet_transactions($searchText, 'deposit', $this->vendorId, false, $returns["page"], $returns["segment"], $startDate, $endDate);
        }

        $this->loadViews('/wallets/table', $this->global, $data, NULL);
    }

    function withdrawalfees($amount){
        //Calculate the withdrawal fee
        $companyInfo = $this->settings_model->getSettingsInfo();
        $variable = $companyInfo['withdrawal_fee'];
        $fixed = $companyInfo['fixed_fee'];
        $cap = $companyInfo['max_withdrawal_fee'];

        $withdrawalfee = ($variable/100 * $amount) + $fixed;
        if($withdrawalfee > $cap){
            $realamount = $cap;
        } else {
            $realamount = $withdrawalfee;
        }

        $fee = $realamount;
        $final_amount = $amount-$fee;

        $array = array(
            'success' => true,
            'fee' => $fee,
            'final_amount' => $final_amount
        );

        echo json_encode($array);
    }

    function withdrawals()
    {
        $searchText = $this->input->post('searchText', TRUE);
        $this->global['searchText'] = $this->input->post('searchText', TRUE);

        if($this->role == ROLE_CLIENT)
        {
            
            $role = '3';

            $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
            
            $this->load->library('pagination');
            
            $count = $this->wallet_model->mywithdrawalsCount($searchText, $this->vendorId);
			$returns = $this->paginationCompress ( "withdrawals/", $count, 10 );
            
            $data['transactions'] = $this->wallet_model->mywalletwithdrawals($searchText, $returns["page"], $returns["segment"], $this->vendorId);
            $data['earningsInfo'] = $this->transactions_model->getEarningsTotal($this->vendorId);
            $data['withdrawalsInfo'] = $this->transactions_model->getPendingWithdrawalsTotal($this->vendorId);
            
            $this->global['pageTitle'] = 'Withdrawals';
            $this->global['displayBreadcrumbs'] = false; 
            $this->loadViews("wallets/withdrawals", $this->global, $data, NULL);
        }
        else
        {  
            $module_id = 'withdrawals';
            $module_action = 'view';
            if($this->isAdmin($module_id, $module_action) == FALSE)
            {
                $this->loadThis();
            } else 
            {
                $role = '3';
            
                $this->load->library('pagination');
                
                $count = $this->wallet_model->withdrawalsCount($searchText, NULL);
                $returns = $this->paginationCompress ( "wallets/withdrawals/", $count, 10 );
                
                $data['transactions'] = $this->wallet_model->walletWithdrawals($searchText, $returns["page"], $returns["segment"], $role);
                
                $this->global['pageTitle'] = 'Withdrawals';
                $this->global['displayBreadcrumbs'] = false; 
                $this->loadViews("wallets/withdrawals", $this->global, $data, NULL);
            }      
        }
    }
    
    function newWithdrawal()
    {
        //$data["plans"] = $this->plans_model->getPlans();
        $this->global['pageTitle'] = 'New Withdrawal';
        $this->global['displayBreadcrumbs'] = true; 
        $this->global['breadcrumbs'] = 'Withdrawals'.' <span class="breadcrumb-arrow-right"></span> '.'New';
        $data['displayBreadcrumbs'] = true;
        $data['breadcrumbs'] = "Withdrawals / New Withdrawal";
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        $this->load->helper('string');

        if ($this->role == ROLE_CLIENT) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('amount','Amount','required');
            $this->form_validation->set_rules('usdtaccount','USDT Account','required');

            if($this->form_validation->run() == FALSE)
            {
                $this->session->set_flashdata('errors', validation_errors());
            }
            else
            {
                //Check if the week's maximum withdrawal has been reached
                $start = date("Y-m-d H:i:s", strtotime('monday this week'));
                
                $end = date("Y-m-d h:i:s", strtotime('Sunday this week'));
                $withdrawalthisweek = $this->wallet_model->getthisweekwithdrawals($this->vendorId, $start, $end);
                $walletinfo = $this->wallet_model->getWalletBalance($this->vendorId);

                if($walletinfo->tier == 0){
                    $limit = 100;
                } else {
                    $limit = $this->wallet_model->get_withdrawal_limit($this->vendorId);
                }
                
                $amount = $this->input->post('amount', TRUE);
                //echo $withdrawalthisweek;
                if($withdrawalthisweek < $limit){
                    //Check the if amoutn is more than the 100 limit of withdrawals per week
                    if($amount > ($amount - $withdrawalthisweek))
                    {
                        $this->session->set_flashdata('error', 'Your amount is greater than the withdrawal limit. You can only withdraw $'.($amount - $withdrawalthisweek));
                    } else {
                        //Get wallet balance
                        $availableFunds = $this->wallet_model->getWalletBalance($this->vendorId)->balance;
                        $pendingWithdrawals = $this->wallet_model->getPendingWithdrawalsTotal($this->vendorId);

                        if($availableFunds < $amount){
                            $this->session->set_flashdata('error', 'You don\'t have enough funds to make a withdrawal');
                        } else if($amount > ($availableFunds - $pendingWithdrawals)) {
                            $this->session->set_flashdata('error', 'You have pending withdrawals. You can only make a withdrawal of'.' $'.($availableFunds - $pendingWithdrawals));
                        } else {
                            $account = $this->input->post('usdtaccount', TRUE);
                            $userId = $this->vendorId;
                            $code = 'WT'.random_string('alnum',8);
                            $status = 0;
                            $createdBy = $this->vendorId;
                            $createdDtm = date('Y-m-d H:i:s'); 

                            //Calculate the withdrawal fee
                            $companyInfo = $this->settings_model->getSettingsInfo();
                            $variable = $companyInfo['withdrawal_fee'];
                            $fixed = $companyInfo['fixed_fee'];
                            $cap = $companyInfo['max_withdrawal_fee'];

                            $withdrawalfee = ($variable/100 * $amount) + $fixed;
                            if($withdrawalfee > $cap){
                                $realamount = $amount - $cap;
                            } else {
                                $realamount = $amount - $withdrawalfee;
                            }

                            $withdrawalInfo = array(
                                'txnUserId'=>$userId,
                                'type'=>'withdrawal', 
                                'txn_id'=>$code,
                                'amount'=>$amount, 
                                'actual_amount'=>$realamount,
                                'method'=>'USDT',
                                'account_number'=>$account,
                                'status' => $status,
                                'createdDtm'=>$createdDtm
                            );
                            $result = $this->wallet_model->addWithdrawal($withdrawalInfo);

                            if($result>0)
                            {
                                $result3 = $this->user_model->getUserInfo($this->vendorId);

                                if($result3)
                                {
                                    //Send Mail
                                    $conditionUserMail = array('tbl_email_templates.type'=>'Withdrawal Request');
                                    $resultEmail = $this->email_model->getEmailSettings($conditionUserMail);

                                    $companyInfo = $this->settings_model->getsettingsInfo();
                                
                                    if($resultEmail->num_rows() > 0)
                                    {
                                        $rowUserMailContent = $resultEmail->row();
                                        $splVars = array(
                                            "!clientName" => $result3->firstName,
                                            "!withdrawalAmount" => to_currency($this->input->post('amount', TRUE)),
                                            "!companyName" => $companyInfo['name'],
                                            "!address" => $companyInfo['address'],
                                            "!siteurl" => base_url()
                                        );

                                        $mailSubject = strtr($rowUserMailContent->mail_subject, $splVars);
                                        $mailContent = strtr($rowUserMailContent->mail_body, $splVars); 	

                                        $toEmail = $result3->email;
                                        $fromEmail = $companyInfo['SMTPUser'];

                                        $name = 'Support';

                                        $header = "From: ". $name . " <" . $fromEmail . ">\r\n"; //optional headerfields

                                        $send = $this->email_model->sendHtmlMail($toEmail,$fromEmail,$mailSubject,$mailContent,NULL);

                                        if($send == true) {
                                            $this->session->set_flashdata('success', 'Your withdrawal request is successful, please check email.');
                                            redirect('withdrawals');
                                        } else {
                                            $this->session->set_flashdata('error', 'Your withdrawal request is successful, however email sending has failed, try again.');
                                            redirect('withdrawals');
                                        }

                                        //Send SMS
                                        $phone = $result3->mobile;
                                        if($phone){
                                            $body = strtr($rowUserMailContent->sms_body, $splVars);

                                            $this->twilio_model->send_sms($phone, $body);
                                        }
                                    }
                                } else {
                                    $this->session->set_flashdata('success', 'Your withdrawal request has been received');
                                    redirect('withdrawals');
                                }
                            }
                            else
                            {
                                $this->session->set_flashdata('error', 'There\'s an error in processing your withdrawal request. Try again later.');
                            }
                        }
                    }
                } else {
                    $this->session->set_flashdata('success', 'You have reached the maximum withdrawal amount of '.$limit.' for this week');
                }
            }
            $data['pendingWithdrawals'] = $this->wallet_model->getPendingWithdrawalsTotal($this->vendorId);
            $data['accountInfo'] = $this->wallet_model->getWalletBalance($this->vendorId)->balance - $data['pendingWithdrawals'];
            $this->loadViews("transactions/new", $this->global, $data);
        } else {
            $this->loadThis();
        }
        
    }
}