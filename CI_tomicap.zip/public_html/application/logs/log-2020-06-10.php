<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-10 02:04:36 --> Severity: error --> Exception: syntax error, unexpected '}' /home/tomicgoz/public_html/application/models/Transactions_model.php 870
ERROR - 2020-06-10 02:04:37 --> Severity: error --> Exception: syntax error, unexpected '}' /home/tomicgoz/public_html/application/models/Transactions_model.php 870
INFO - 2020-06-10 02:04:54 --> Config Class Initialized
INFO - 2020-06-10 02:04:54 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:04:54 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:04:54 --> Utf8 Class Initialized
INFO - 2020-06-10 02:04:54 --> URI Class Initialized
DEBUG - 2020-06-10 02:04:54 --> No URI present. Default controller set.
INFO - 2020-06-10 02:04:54 --> Router Class Initialized
INFO - 2020-06-10 02:04:54 --> Output Class Initialized
INFO - 2020-06-10 02:04:54 --> Security Class Initialized
DEBUG - 2020-06-10 02:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:04:54 --> CSRF cookie sent
INFO - 2020-06-10 02:04:54 --> Input Class Initialized
INFO - 2020-06-10 02:04:54 --> Language Class Initialized
INFO - 2020-06-10 02:04:54 --> Loader Class Initialized
INFO - 2020-06-10 02:04:54 --> Helper loaded: url_helper
INFO - 2020-06-10 02:04:54 --> Helper loaded: form_helper
INFO - 2020-06-10 02:04:54 --> Helper loaded: file_helper
INFO - 2020-06-10 02:04:54 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:04:54 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:04:54 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:04:54 --> Database Driver Class Initialized
INFO - 2020-06-10 02:04:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:04:54 --> Controller Class Initialized
INFO - 2020-06-10 02:04:54 --> Model "Settings_model" initialized
ERROR - 2020-06-10 02:04:54 --> Severity: error --> Exception: syntax error, unexpected '}' /home/tomicgoz/public_html/application/models/Transactions_model.php 870
INFO - 2020-06-10 02:07:09 --> Config Class Initialized
INFO - 2020-06-10 02:07:09 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:07:09 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:07:09 --> Utf8 Class Initialized
INFO - 2020-06-10 02:07:09 --> URI Class Initialized
DEBUG - 2020-06-10 02:07:09 --> No URI present. Default controller set.
INFO - 2020-06-10 02:07:09 --> Router Class Initialized
INFO - 2020-06-10 02:07:09 --> Output Class Initialized
INFO - 2020-06-10 02:07:09 --> Security Class Initialized
DEBUG - 2020-06-10 02:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:07:09 --> CSRF cookie sent
INFO - 2020-06-10 02:07:09 --> Input Class Initialized
INFO - 2020-06-10 02:07:09 --> Language Class Initialized
INFO - 2020-06-10 02:07:09 --> Loader Class Initialized
INFO - 2020-06-10 02:07:09 --> Helper loaded: url_helper
INFO - 2020-06-10 02:07:09 --> Helper loaded: form_helper
INFO - 2020-06-10 02:07:09 --> Helper loaded: file_helper
INFO - 2020-06-10 02:07:09 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:07:09 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:07:09 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:07:09 --> Database Driver Class Initialized
INFO - 2020-06-10 02:07:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:07:09 --> Controller Class Initialized
INFO - 2020-06-10 02:07:09 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:07:09 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:07:09 --> Model "Email_model" initialized
INFO - 2020-06-10 02:07:09 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:07:09 --> Model "Plans_model" initialized
INFO - 2020-06-10 02:07:09 --> File loaded: /home/tomicgoz/public_html/application/views//partials/header.php
INFO - 2020-06-10 02:07:09 --> File loaded: /home/tomicgoz/public_html/application/views///siteContent/home.php
INFO - 2020-06-10 02:07:09 --> File loaded: /home/tomicgoz/public_html/application/views//partials/footer.php
INFO - 2020-06-10 02:07:09 --> Final output sent to browser
DEBUG - 2020-06-10 02:07:09 --> Total execution time: 0.0998
INFO - 2020-06-10 02:07:11 --> Config Class Initialized
INFO - 2020-06-10 02:07:11 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:07:11 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:07:11 --> Utf8 Class Initialized
INFO - 2020-06-10 02:07:11 --> URI Class Initialized
INFO - 2020-06-10 02:07:11 --> Router Class Initialized
INFO - 2020-06-10 02:07:11 --> Output Class Initialized
INFO - 2020-06-10 02:07:11 --> Security Class Initialized
INFO - 2020-06-10 02:07:11 --> Config Class Initialized
INFO - 2020-06-10 02:07:11 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:07:11 --> CSRF cookie sent
INFO - 2020-06-10 02:07:11 --> Input Class Initialized
INFO - 2020-06-10 02:07:11 --> Language Class Initialized
DEBUG - 2020-06-10 02:07:11 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:07:11 --> Utf8 Class Initialized
INFO - 2020-06-10 02:07:11 --> URI Class Initialized
INFO - 2020-06-10 02:07:11 --> Loader Class Initialized
INFO - 2020-06-10 02:07:11 --> Helper loaded: url_helper
INFO - 2020-06-10 02:07:11 --> Helper loaded: form_helper
INFO - 2020-06-10 02:07:11 --> Router Class Initialized
INFO - 2020-06-10 02:07:11 --> Helper loaded: file_helper
INFO - 2020-06-10 02:07:11 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:07:11 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:07:11 --> Output Class Initialized
INFO - 2020-06-10 02:07:11 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:07:11 --> Security Class Initialized
DEBUG - 2020-06-10 02:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:07:11 --> CSRF cookie sent
INFO - 2020-06-10 02:07:11 --> Input Class Initialized
INFO - 2020-06-10 02:07:11 --> Language Class Initialized
INFO - 2020-06-10 02:07:11 --> Loader Class Initialized
INFO - 2020-06-10 02:07:11 --> Database Driver Class Initialized
INFO - 2020-06-10 02:07:11 --> Helper loaded: url_helper
INFO - 2020-06-10 02:07:11 --> Helper loaded: form_helper
INFO - 2020-06-10 02:07:11 --> Helper loaded: file_helper
INFO - 2020-06-10 02:07:11 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:07:11 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:07:11 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:07:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:07:11 --> Controller Class Initialized
INFO - 2020-06-10 02:07:11 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:07:11 --> Database Driver Class Initialized
INFO - 2020-06-10 02:07:11 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:07:11 --> Model "Email_model" initialized
INFO - 2020-06-10 02:07:11 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:07:11 --> File loaded: /home/tomicgoz/public_html/application/views/404.php
INFO - 2020-06-10 02:07:11 --> Final output sent to browser
DEBUG - 2020-06-10 02:07:11 --> Total execution time: 0.0632
INFO - 2020-06-10 02:07:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:07:11 --> Controller Class Initialized
INFO - 2020-06-10 02:07:11 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:07:11 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:07:11 --> Model "Email_model" initialized
INFO - 2020-06-10 02:07:11 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:07:11 --> File loaded: /home/tomicgoz/public_html/application/views/404.php
INFO - 2020-06-10 02:07:11 --> Final output sent to browser
DEBUG - 2020-06-10 02:07:11 --> Total execution time: 0.0750
INFO - 2020-06-10 02:07:39 --> Config Class Initialized
INFO - 2020-06-10 02:07:39 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:07:39 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:07:39 --> Utf8 Class Initialized
INFO - 2020-06-10 02:07:39 --> URI Class Initialized
INFO - 2020-06-10 02:07:39 --> Router Class Initialized
INFO - 2020-06-10 02:07:39 --> Output Class Initialized
INFO - 2020-06-10 02:07:39 --> Security Class Initialized
DEBUG - 2020-06-10 02:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:07:39 --> CSRF cookie sent
INFO - 2020-06-10 02:07:39 --> Input Class Initialized
INFO - 2020-06-10 02:07:39 --> Language Class Initialized
INFO - 2020-06-10 02:07:39 --> Loader Class Initialized
INFO - 2020-06-10 02:07:39 --> Helper loaded: url_helper
INFO - 2020-06-10 02:07:39 --> Helper loaded: form_helper
INFO - 2020-06-10 02:07:39 --> Helper loaded: file_helper
INFO - 2020-06-10 02:07:39 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:07:39 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:07:39 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:07:39 --> Database Driver Class Initialized
INFO - 2020-06-10 02:07:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:07:39 --> Controller Class Initialized
INFO - 2020-06-10 02:07:39 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:07:39 --> Model "Login_model" initialized
INFO - 2020-06-10 02:07:39 --> Model "Email_model" initialized
INFO - 2020-06-10 02:07:39 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:07:39 --> Form Validation Class Initialized
INFO - 2020-06-10 02:07:39 --> File loaded: /home/tomicgoz/public_html/application/views//partials/header.php
INFO - 2020-06-10 02:07:39 --> File loaded: /home/tomicgoz/public_html/application/views///auth/login.php
INFO - 2020-06-10 02:07:39 --> File loaded: /home/tomicgoz/public_html/application/views//partials/footer.php
INFO - 2020-06-10 02:07:39 --> Final output sent to browser
DEBUG - 2020-06-10 02:07:39 --> Total execution time: 0.0448
INFO - 2020-06-10 02:07:40 --> Config Class Initialized
INFO - 2020-06-10 02:07:40 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:07:40 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:07:40 --> Utf8 Class Initialized
INFO - 2020-06-10 02:07:40 --> URI Class Initialized
DEBUG - 2020-06-10 02:07:40 --> No URI present. Default controller set.
INFO - 2020-06-10 02:07:40 --> Router Class Initialized
INFO - 2020-06-10 02:07:40 --> Output Class Initialized
INFO - 2020-06-10 02:07:40 --> Security Class Initialized
DEBUG - 2020-06-10 02:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:07:40 --> CSRF cookie sent
INFO - 2020-06-10 02:07:40 --> Input Class Initialized
INFO - 2020-06-10 02:07:40 --> Language Class Initialized
INFO - 2020-06-10 02:07:40 --> Loader Class Initialized
INFO - 2020-06-10 02:07:40 --> Helper loaded: url_helper
INFO - 2020-06-10 02:07:40 --> Helper loaded: form_helper
INFO - 2020-06-10 02:07:40 --> Helper loaded: file_helper
INFO - 2020-06-10 02:07:40 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:07:40 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:07:40 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:07:40 --> Database Driver Class Initialized
INFO - 2020-06-10 02:07:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:07:40 --> Controller Class Initialized
INFO - 2020-06-10 02:07:40 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:07:40 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:07:40 --> Model "Email_model" initialized
INFO - 2020-06-10 02:07:40 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:07:40 --> Model "Plans_model" initialized
INFO - 2020-06-10 02:07:40 --> File loaded: /home/tomicgoz/public_html/application/views//partials/header.php
INFO - 2020-06-10 02:07:40 --> File loaded: /home/tomicgoz/public_html/application/views///siteContent/home.php
INFO - 2020-06-10 02:07:40 --> File loaded: /home/tomicgoz/public_html/application/views//partials/footer.php
INFO - 2020-06-10 02:07:40 --> Final output sent to browser
DEBUG - 2020-06-10 02:07:40 --> Total execution time: 0.0631
INFO - 2020-06-10 02:07:41 --> Config Class Initialized
INFO - 2020-06-10 02:07:41 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:07:41 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:07:41 --> Utf8 Class Initialized
INFO - 2020-06-10 02:07:41 --> URI Class Initialized
INFO - 2020-06-10 02:07:41 --> Router Class Initialized
INFO - 2020-06-10 02:07:41 --> Output Class Initialized
INFO - 2020-06-10 02:07:41 --> Security Class Initialized
DEBUG - 2020-06-10 02:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:07:41 --> CSRF cookie sent
INFO - 2020-06-10 02:07:41 --> Input Class Initialized
INFO - 2020-06-10 02:07:41 --> Language Class Initialized
INFO - 2020-06-10 02:07:41 --> Loader Class Initialized
INFO - 2020-06-10 02:07:41 --> Helper loaded: url_helper
INFO - 2020-06-10 02:07:41 --> Helper loaded: form_helper
INFO - 2020-06-10 02:07:41 --> Helper loaded: file_helper
INFO - 2020-06-10 02:07:41 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:07:41 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:07:41 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:07:41 --> Database Driver Class Initialized
INFO - 2020-06-10 02:07:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:07:41 --> Controller Class Initialized
INFO - 2020-06-10 02:07:41 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:07:41 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:07:41 --> Model "Email_model" initialized
INFO - 2020-06-10 02:07:41 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:07:41 --> File loaded: /home/tomicgoz/public_html/application/views/404.php
INFO - 2020-06-10 02:07:41 --> Final output sent to browser
DEBUG - 2020-06-10 02:07:41 --> Total execution time: 0.0530
INFO - 2020-06-10 02:07:41 --> Config Class Initialized
INFO - 2020-06-10 02:07:41 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:07:41 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:07:41 --> Utf8 Class Initialized
INFO - 2020-06-10 02:07:41 --> URI Class Initialized
INFO - 2020-06-10 02:07:41 --> Router Class Initialized
INFO - 2020-06-10 02:07:41 --> Output Class Initialized
INFO - 2020-06-10 02:07:41 --> Security Class Initialized
DEBUG - 2020-06-10 02:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:07:41 --> CSRF cookie sent
INFO - 2020-06-10 02:07:41 --> Input Class Initialized
INFO - 2020-06-10 02:07:41 --> Language Class Initialized
INFO - 2020-06-10 02:07:41 --> Loader Class Initialized
INFO - 2020-06-10 02:07:41 --> Helper loaded: url_helper
INFO - 2020-06-10 02:07:41 --> Helper loaded: form_helper
INFO - 2020-06-10 02:07:41 --> Helper loaded: file_helper
INFO - 2020-06-10 02:07:41 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:07:41 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:07:41 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:07:41 --> Database Driver Class Initialized
INFO - 2020-06-10 02:07:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:07:41 --> Controller Class Initialized
INFO - 2020-06-10 02:07:41 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:07:41 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:07:41 --> Model "Email_model" initialized
INFO - 2020-06-10 02:07:41 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:07:41 --> File loaded: /home/tomicgoz/public_html/application/views/404.php
INFO - 2020-06-10 02:07:41 --> Final output sent to browser
DEBUG - 2020-06-10 02:07:41 --> Total execution time: 0.0718
INFO - 2020-06-10 02:07:42 --> Config Class Initialized
INFO - 2020-06-10 02:07:42 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:07:42 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:07:42 --> Utf8 Class Initialized
INFO - 2020-06-10 02:07:42 --> URI Class Initialized
INFO - 2020-06-10 02:07:42 --> Router Class Initialized
INFO - 2020-06-10 02:07:42 --> Output Class Initialized
INFO - 2020-06-10 02:07:42 --> Security Class Initialized
DEBUG - 2020-06-10 02:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:07:42 --> CSRF cookie sent
INFO - 2020-06-10 02:07:42 --> Input Class Initialized
INFO - 2020-06-10 02:07:42 --> Language Class Initialized
INFO - 2020-06-10 02:07:42 --> Config Class Initialized
INFO - 2020-06-10 02:07:42 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:07:42 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:07:42 --> Utf8 Class Initialized
INFO - 2020-06-10 02:07:42 --> Loader Class Initialized
INFO - 2020-06-10 02:07:42 --> URI Class Initialized
INFO - 2020-06-10 02:07:42 --> Helper loaded: url_helper
INFO - 2020-06-10 02:07:42 --> Helper loaded: form_helper
INFO - 2020-06-10 02:07:42 --> Helper loaded: file_helper
INFO - 2020-06-10 02:07:42 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:07:42 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:07:42 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:07:42 --> Router Class Initialized
INFO - 2020-06-10 02:07:42 --> Output Class Initialized
INFO - 2020-06-10 02:07:42 --> Security Class Initialized
DEBUG - 2020-06-10 02:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:07:42 --> CSRF cookie sent
INFO - 2020-06-10 02:07:42 --> Input Class Initialized
INFO - 2020-06-10 02:07:42 --> Language Class Initialized
INFO - 2020-06-10 02:07:42 --> Database Driver Class Initialized
INFO - 2020-06-10 02:07:42 --> Loader Class Initialized
INFO - 2020-06-10 02:07:42 --> Helper loaded: url_helper
INFO - 2020-06-10 02:07:42 --> Helper loaded: form_helper
INFO - 2020-06-10 02:07:42 --> Helper loaded: file_helper
INFO - 2020-06-10 02:07:42 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:07:42 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:07:42 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:07:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:07:42 --> Controller Class Initialized
INFO - 2020-06-10 02:07:42 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:07:42 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:07:42 --> Database Driver Class Initialized
INFO - 2020-06-10 02:07:42 --> Model "Email_model" initialized
INFO - 2020-06-10 02:07:42 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:07:42 --> File loaded: /home/tomicgoz/public_html/application/views/404.php
INFO - 2020-06-10 02:07:42 --> Final output sent to browser
DEBUG - 2020-06-10 02:07:42 --> Total execution time: 0.0584
INFO - 2020-06-10 02:07:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:07:42 --> Controller Class Initialized
INFO - 2020-06-10 02:07:42 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:07:42 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:07:42 --> Model "Email_model" initialized
INFO - 2020-06-10 02:07:42 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:07:42 --> File loaded: /home/tomicgoz/public_html/application/views/404.php
INFO - 2020-06-10 02:07:42 --> Final output sent to browser
DEBUG - 2020-06-10 02:07:42 --> Total execution time: 0.0612
INFO - 2020-06-10 02:07:44 --> Config Class Initialized
INFO - 2020-06-10 02:07:44 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:07:44 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:07:44 --> Utf8 Class Initialized
INFO - 2020-06-10 02:07:44 --> URI Class Initialized
INFO - 2020-06-10 02:07:44 --> Router Class Initialized
INFO - 2020-06-10 02:07:44 --> Output Class Initialized
INFO - 2020-06-10 02:07:44 --> Security Class Initialized
DEBUG - 2020-06-10 02:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:07:44 --> CSRF cookie sent
INFO - 2020-06-10 02:07:44 --> Input Class Initialized
INFO - 2020-06-10 02:07:44 --> Language Class Initialized
INFO - 2020-06-10 02:07:44 --> Loader Class Initialized
INFO - 2020-06-10 02:07:44 --> Helper loaded: url_helper
INFO - 2020-06-10 02:07:44 --> Helper loaded: form_helper
INFO - 2020-06-10 02:07:44 --> Helper loaded: file_helper
INFO - 2020-06-10 02:07:44 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:07:44 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:07:44 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:07:44 --> Database Driver Class Initialized
INFO - 2020-06-10 02:07:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:07:44 --> Controller Class Initialized
INFO - 2020-06-10 02:07:44 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:07:44 --> Model "Login_model" initialized
INFO - 2020-06-10 02:07:44 --> Model "Email_model" initialized
INFO - 2020-06-10 02:07:44 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:07:44 --> Form Validation Class Initialized
INFO - 2020-06-10 02:07:44 --> Config Class Initialized
INFO - 2020-06-10 02:07:44 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:07:44 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:07:44 --> Utf8 Class Initialized
INFO - 2020-06-10 02:07:44 --> URI Class Initialized
INFO - 2020-06-10 02:07:44 --> Router Class Initialized
INFO - 2020-06-10 02:07:44 --> Output Class Initialized
INFO - 2020-06-10 02:07:44 --> Security Class Initialized
DEBUG - 2020-06-10 02:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:07:44 --> CSRF cookie sent
INFO - 2020-06-10 02:07:44 --> Input Class Initialized
INFO - 2020-06-10 02:07:44 --> Language Class Initialized
INFO - 2020-06-10 02:07:44 --> Loader Class Initialized
INFO - 2020-06-10 02:07:44 --> Helper loaded: url_helper
INFO - 2020-06-10 02:07:44 --> Helper loaded: form_helper
INFO - 2020-06-10 02:07:44 --> Helper loaded: file_helper
INFO - 2020-06-10 02:07:44 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:07:44 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:07:44 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:07:44 --> Database Driver Class Initialized
INFO - 2020-06-10 02:07:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:07:44 --> Controller Class Initialized
INFO - 2020-06-10 02:07:44 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:07:44 --> Model "User_model" initialized
INFO - 2020-06-10 02:07:44 --> Model "Login_model" initialized
INFO - 2020-06-10 02:07:44 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:07:44 --> Model "Email_model" initialized
INFO - 2020-06-10 02:07:44 --> Model "Payments_model" initialized
INFO - 2020-06-10 02:07:44 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:07:44 --> Model "Wallet_model" initialized
INFO - 2020-06-10 02:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-06-10 02:07:45 --> Pagination Class Initialized
INFO - 2020-06-10 02:07:45 --> File loaded: /home/tomicgoz/public_html/application/views//partials/header.php
INFO - 2020-06-10 02:07:45 --> File loaded: /home/tomicgoz/public_html/application/views//dashboard.php
INFO - 2020-06-10 02:07:45 --> File loaded: /home/tomicgoz/public_html/application/views//partials/footer.php
INFO - 2020-06-10 02:07:45 --> Final output sent to browser
DEBUG - 2020-06-10 02:07:45 --> Total execution time: 1.0565
INFO - 2020-06-10 02:09:31 --> Config Class Initialized
INFO - 2020-06-10 02:09:31 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:09:31 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:09:31 --> Utf8 Class Initialized
INFO - 2020-06-10 02:09:31 --> URI Class Initialized
INFO - 2020-06-10 02:09:31 --> Router Class Initialized
INFO - 2020-06-10 02:09:31 --> Output Class Initialized
INFO - 2020-06-10 02:09:31 --> Security Class Initialized
DEBUG - 2020-06-10 02:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:09:31 --> CSRF cookie sent
INFO - 2020-06-10 02:09:31 --> CSRF token verified
INFO - 2020-06-10 02:09:31 --> Input Class Initialized
INFO - 2020-06-10 02:09:31 --> Language Class Initialized
INFO - 2020-06-10 02:09:31 --> Loader Class Initialized
INFO - 2020-06-10 02:09:31 --> Helper loaded: url_helper
INFO - 2020-06-10 02:09:31 --> Helper loaded: form_helper
INFO - 2020-06-10 02:09:31 --> Helper loaded: file_helper
INFO - 2020-06-10 02:09:31 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:09:31 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:09:31 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:09:31 --> Database Driver Class Initialized
INFO - 2020-06-10 02:09:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:09:31 --> Controller Class Initialized
INFO - 2020-06-10 02:09:31 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:09:31 --> Model "Login_model" initialized
INFO - 2020-06-10 02:09:31 --> Model "Email_model" initialized
INFO - 2020-06-10 02:09:31 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:09:31 --> Form Validation Class Initialized
INFO - 2020-06-10 02:09:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-06-10 02:09:32 --> User Agent Class Initialized
INFO - 2020-06-10 02:09:32 --> Config Class Initialized
INFO - 2020-06-10 02:09:32 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:09:32 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:09:32 --> Utf8 Class Initialized
INFO - 2020-06-10 02:09:32 --> URI Class Initialized
INFO - 2020-06-10 02:09:32 --> Router Class Initialized
INFO - 2020-06-10 02:09:32 --> Output Class Initialized
INFO - 2020-06-10 02:09:32 --> Security Class Initialized
DEBUG - 2020-06-10 02:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:09:32 --> CSRF cookie sent
INFO - 2020-06-10 02:09:32 --> Input Class Initialized
INFO - 2020-06-10 02:09:32 --> Language Class Initialized
INFO - 2020-06-10 02:09:32 --> Loader Class Initialized
INFO - 2020-06-10 02:09:32 --> Helper loaded: url_helper
INFO - 2020-06-10 02:09:32 --> Helper loaded: form_helper
INFO - 2020-06-10 02:09:32 --> Helper loaded: file_helper
INFO - 2020-06-10 02:09:32 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:09:32 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:09:32 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:09:32 --> Database Driver Class Initialized
INFO - 2020-06-10 02:09:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:09:32 --> Controller Class Initialized
INFO - 2020-06-10 02:09:32 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:09:32 --> Model "User_model" initialized
INFO - 2020-06-10 02:09:32 --> Model "Login_model" initialized
INFO - 2020-06-10 02:09:32 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:09:32 --> Model "Email_model" initialized
INFO - 2020-06-10 02:09:32 --> Model "Payments_model" initialized
INFO - 2020-06-10 02:09:32 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:09:32 --> Model "Wallet_model" initialized
INFO - 2020-06-10 02:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-06-10 02:09:32 --> Pagination Class Initialized
INFO - 2020-06-10 02:09:32 --> File loaded: /home/tomicgoz/public_html/application/views//partials/header.php
INFO - 2020-06-10 02:09:32 --> File loaded: /home/tomicgoz/public_html/application/views//dashboard.php
INFO - 2020-06-10 02:09:32 --> File loaded: /home/tomicgoz/public_html/application/views//partials/footer.php
INFO - 2020-06-10 02:09:32 --> Final output sent to browser
DEBUG - 2020-06-10 02:09:32 --> Total execution time: 0.0909
INFO - 2020-06-10 02:09:38 --> Config Class Initialized
INFO - 2020-06-10 02:09:38 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:09:38 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:09:38 --> Utf8 Class Initialized
INFO - 2020-06-10 02:09:38 --> URI Class Initialized
INFO - 2020-06-10 02:09:38 --> Router Class Initialized
INFO - 2020-06-10 02:09:38 --> Output Class Initialized
INFO - 2020-06-10 02:09:38 --> Security Class Initialized
DEBUG - 2020-06-10 02:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:09:38 --> CSRF cookie sent
INFO - 2020-06-10 02:09:38 --> Input Class Initialized
INFO - 2020-06-10 02:09:38 --> Language Class Initialized
INFO - 2020-06-10 02:09:38 --> Loader Class Initialized
INFO - 2020-06-10 02:09:38 --> Helper loaded: url_helper
INFO - 2020-06-10 02:09:38 --> Helper loaded: form_helper
INFO - 2020-06-10 02:09:38 --> Helper loaded: file_helper
INFO - 2020-06-10 02:09:38 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:09:38 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:09:38 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:09:38 --> Database Driver Class Initialized
INFO - 2020-06-10 02:09:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:09:38 --> Controller Class Initialized
INFO - 2020-06-10 02:09:38 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:09:38 --> Model "User_model" initialized
INFO - 2020-06-10 02:09:38 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:09:38 --> Model "Email_model" initialized
INFO - 2020-06-10 02:09:38 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:09:38 --> Model "Referral_model" initialized
INFO - 2020-06-10 02:09:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-06-10 02:09:38 --> Pagination Class Initialized
INFO - 2020-06-10 02:09:38 --> File loaded: /home/tomicgoz/public_html/application/views//partials/header.php
INFO - 2020-06-10 02:09:38 --> File loaded: /home/tomicgoz/public_html/application/views//referrals/referral.php
INFO - 2020-06-10 02:09:38 --> File loaded: /home/tomicgoz/public_html/application/views//partials/footer.php
INFO - 2020-06-10 02:09:38 --> Final output sent to browser
DEBUG - 2020-06-10 02:09:38 --> Total execution time: 0.2364
INFO - 2020-06-10 02:09:45 --> Config Class Initialized
INFO - 2020-06-10 02:09:45 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:09:45 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:09:45 --> Utf8 Class Initialized
INFO - 2020-06-10 02:09:45 --> URI Class Initialized
INFO - 2020-06-10 02:09:45 --> Router Class Initialized
INFO - 2020-06-10 02:09:45 --> Output Class Initialized
INFO - 2020-06-10 02:09:45 --> Security Class Initialized
DEBUG - 2020-06-10 02:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:09:45 --> CSRF cookie sent
INFO - 2020-06-10 02:09:45 --> Input Class Initialized
INFO - 2020-06-10 02:09:45 --> Language Class Initialized
INFO - 2020-06-10 02:09:45 --> Loader Class Initialized
INFO - 2020-06-10 02:09:45 --> Helper loaded: url_helper
INFO - 2020-06-10 02:09:45 --> Helper loaded: form_helper
INFO - 2020-06-10 02:09:45 --> Helper loaded: file_helper
INFO - 2020-06-10 02:09:45 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:09:45 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:09:45 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:09:45 --> Database Driver Class Initialized
INFO - 2020-06-10 02:09:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:09:45 --> Controller Class Initialized
INFO - 2020-06-10 02:09:45 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:09:45 --> Model "User_model" initialized
INFO - 2020-06-10 02:09:45 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:09:45 --> Model "Email_model" initialized
INFO - 2020-06-10 02:09:45 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:09:45 --> Model "Referral_model" initialized
INFO - 2020-06-10 02:09:45 --> File loaded: /home/tomicgoz/public_html/application/views//partials/header.php
INFO - 2020-06-10 02:09:45 --> File loaded: /home/tomicgoz/public_html/application/views//referrals/treeview.php
INFO - 2020-06-10 02:09:45 --> File loaded: /home/tomicgoz/public_html/application/views//partials/footer.php
INFO - 2020-06-10 02:09:45 --> Final output sent to browser
DEBUG - 2020-06-10 02:09:45 --> Total execution time: 0.1054
INFO - 2020-06-10 02:09:46 --> Config Class Initialized
INFO - 2020-06-10 02:09:46 --> Hooks Class Initialized
DEBUG - 2020-06-10 02:09:46 --> UTF-8 Support Enabled
INFO - 2020-06-10 02:09:46 --> Utf8 Class Initialized
INFO - 2020-06-10 02:09:46 --> URI Class Initialized
INFO - 2020-06-10 02:09:46 --> Router Class Initialized
INFO - 2020-06-10 02:09:46 --> Output Class Initialized
INFO - 2020-06-10 02:09:46 --> Security Class Initialized
DEBUG - 2020-06-10 02:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-10 02:09:46 --> CSRF cookie sent
INFO - 2020-06-10 02:09:46 --> Input Class Initialized
INFO - 2020-06-10 02:09:46 --> Language Class Initialized
INFO - 2020-06-10 02:09:46 --> Loader Class Initialized
INFO - 2020-06-10 02:09:46 --> Helper loaded: url_helper
INFO - 2020-06-10 02:09:46 --> Helper loaded: form_helper
INFO - 2020-06-10 02:09:46 --> Helper loaded: file_helper
INFO - 2020-06-10 02:09:46 --> Helper loaded: cias_helper
INFO - 2020-06-10 02:09:46 --> Helper loaded: htmlpurifier_helper
INFO - 2020-06-10 02:09:46 --> Helper loaded: currency_helper
INFO - 2020-06-10 02:09:46 --> Database Driver Class Initialized
INFO - 2020-06-10 02:09:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-06-10 02:09:46 --> Controller Class Initialized
INFO - 2020-06-10 02:09:46 --> Model "Settings_model" initialized
INFO - 2020-06-10 02:09:46 --> Model "User_model" initialized
INFO - 2020-06-10 02:09:46 --> Model "Transactions_model" initialized
INFO - 2020-06-10 02:09:46 --> Model "Email_model" initialized
INFO - 2020-06-10 02:09:46 --> Model "Twilio_model" initialized
INFO - 2020-06-10 02:09:46 --> Model "Referral_model" initialized
INFO - 2020-06-10 02:09:46 --> Final output sent to browser
DEBUG - 2020-06-10 02:09:46 --> Total execution time: 0.0572
