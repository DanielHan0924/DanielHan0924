### Changelog

## Version 1.1.1 (27 December 2018)


## Version 2.0.0 (16 April 2019)
 - Updated all package.json dependencies to latest versions.
 - Fixed tabs issue
 - various bug fixes

## Version 2.1.0 (28 October, 2019)
 - Mobile side bar fix.
 - package updated 2 bugs to be fixed
 - Update Task Complete
 - Now compatible with IE
 - Added polyfills
 - browser compatibility issues solved
 - packege udate complete
 - Renamed mathod
