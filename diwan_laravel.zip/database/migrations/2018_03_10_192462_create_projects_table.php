<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProjectsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('customer_id')->nullable();
            $table->string('name', 255);
            $table->enum('status', ['Waiting', 'Pending', 'Terminated', 'Finished', 'Progress'])->default('pending');
            $table->enum('priority', ['Low', 'Medium', 'High', 'Urgent'])->default('Medium');
            $table->integer('progress');
            $table->integer('budget');
            $table->string('tags', 250)->nullable();
            $table->mediumText('demo_url')->nullable();
            $table->date('start_date');
            $table->date('end_date');
            $table->integer('link_to_cal')->default(0);
            $table->text('note')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('projects');
    }
}
