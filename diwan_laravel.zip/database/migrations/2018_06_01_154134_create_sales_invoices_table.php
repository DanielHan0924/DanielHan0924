<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSalesInvoicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sales_invoices', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('customer_id')->unsigned();
            $table->integer('payment_method_id')->unsigned();
            $table->integer('payment_term_id')->unsigned();
            $table->integer('warehouse_id')->default(0);
            $table->date('invoice_date');
            $table->string('reference', 150);
            $table->mediumText('custom_item')->nullable();
            $table->string('order_note')->nullable();
            $table->decimal('sub_total', 10, 2)->default(0.00);
            $table->decimal('total_tax', 10, 2)->default(0.00);
            $table->decimal('grand_total', 10, 2)->default(0.00);
            $table->decimal('total_paid', 10, 2)->default(0.00);
            $table->decimal('total_due', 10, 2)->default(0.00);
            $table->tinyInteger('status')->default(0);
            /**
             * Foreign Key constraints
             */
            $table->foreign('customer_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('payment_method_id')->references('id')->on('payment_terms')->onDelete('cascade');
            $table->foreign('payment_term_id')->references('id')->on('invoice_payment_terms')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sales_invoices');
    }
}
