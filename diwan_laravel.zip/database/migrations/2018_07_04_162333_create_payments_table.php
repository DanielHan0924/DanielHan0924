<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('payment_method_id')->unsigned();
            $table->integer('invoice_id');
            $table->string('account_name', 150);
            $table->decimal('amount', 10, 2)->default(0.00);
            $table->date('payment_date');
            $table->string('description')->nullable();
            $table->string('reference_no', 100)->nullable();
            $table->string('payment_type', 15);
            $table->timestamps();
            $table->foreign('payment_method_id')->references('id')->on('payment_terms')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments');
    }
}
