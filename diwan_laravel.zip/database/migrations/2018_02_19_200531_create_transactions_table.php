<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->increments('id');
            $table->string('customer_name', 200)->nullable();
            $table->integer('account_id')->unsigned();
            $table->string('account', 200);
            $table->enum('type', ['Income', 'Expense', 'Transfer']);
            $table->string('transaction_category_name', 200);
            $table->decimal('debit', 10, 2)->nullable();
            $table->decimal('credit', 10, 2)->nullable();
            $table->integer('customer_id')->unsigned()->nullable();
            $table->string('pay_method', 200)->nullable();
            $table->date('date');
            $table->integer('tid')->nullable();
            $table->integer('user_id')->nullable(); // this should be the logged in users id
            $table->string('note', 250)->nullable();
            $table->integer('ext')->nullable();


            /**
             * Foreign key references
             */


            $table->foreign('customer_id')->references('id')->on('customers')->onDelete('cascade');
            $table->foreign('account_id')->references('id')->on('accounts')->onDelete('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
}
