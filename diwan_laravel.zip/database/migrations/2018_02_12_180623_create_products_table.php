<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('category_id')->unsigned();
            $table->integer('warehouse_id')->unsigned();
            $table->string('product_name', 50);
            $table->string('product_code', 250);
            $table->decimal('product_wholesale_price', 10, 2)->default(0.00);
            $table->decimal('product_retail_price', 10, 2)->default(0.00);
            $table->decimal('product_tax_rate', 10, 2)->default(0.00);
            $table->decimal('product_discount_rate', 10, 2)->default(0.00);
            $table->string('product_image', 250)->nullable();
            $table->mediumText('description')->nullable();
            $table->integer('product_quantity');


            /**
             * Foreign key references
             */

            $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');
            $table->foreign('warehouse_id')->references('id')->on('warehouses')->onDelete('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
