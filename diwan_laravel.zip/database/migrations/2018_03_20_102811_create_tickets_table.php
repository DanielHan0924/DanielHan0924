<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTicketsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('customer_id')->unsigned(); // Customer id
            $table->integer('project_id')->unsigned();
            $table->string('subject', 250)->nullable();
            $table->text('description')->nullable();
            $table->enum('priority', ['Low', 'Medium', 'High', 'Urgent'])->default('Medium');
            $table->enum('status', ['Open', 'Closed'])->default('Open');
            $table->date('closed_at')->nullable();
            $table->string('ticket_username')->nullable();
            $table->enum('answer_status', ['Open', 'Answered'])->default('Open');
            $table->enum('answer_status', ['Open', 'Answered'])->default('Open');

            //$table->foreign('customer_id')->references('id')->on('customers')->onDelete('cascade');
            //$table->foreign('project_id')->references('id')->on('projects')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tickets');
    }
}
