<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateApplicationSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('application_settings', function (Blueprint $table) {
            $table->increments('id');
            $table->string('company_name', 50)->nullable();
            $table->string('address', 250)->nullable();
            $table->string('city', 30)->nullable();
            $table->string('region', 40)->nullable();
            $table->integer('country_id')->unsigned();
            $table->string('postbox', 15)->nullable();
            $table->string('phone', 20)->nullable();
            $table->string('email', 30)->nullable();
            $table->string('taxid', 30)->nullable();
            $table->integer('tax')->nullable();
            $table->string('currency', 4)->nullable();
            $table->string('currency_format', 2)->nullable();
            $table->string('prefix', 5)->nullable();
            $table->integer('date_format')->nullable();
            $table->string('zone', 25)->nullable();
            $table->integer('default_expense_id')->default(0);
            $table->string('company_logo', 30)->nullable();

            /**
             * Foreign key references
             */

            $table->foreign('country_id')->references('id')->on('countries')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('application_settings');
    }
}
