<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePurchaseInvoicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('purchase_invoices', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('supplier_id')->unsigned();
            $table->integer('payment_method_id')->unsigned();
            $table->integer('payment_term_id')->unsigned();
            $table->date('invoice_date');
            $table->string('reference', 150);
            $table->string('order_note')->nullable(0);
            $table->decimal('sub_total', 10, 2)->default(0.00);
            $table->decimal('total_tax', 10, 2)->default(0.00);
            $table->decimal('grand_total', 10, 2)->default(0.00);
            $table->tinyInteger('status')->default(1);
            /**
             * Foreign Key constraints
             */
            $table->foreign('supplier_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('payment_method_id')->references('id')->on('payment_terms')->onDelete('cascade');
            $table->foreign('payment_term_id')->references('id')->on('invoice_payment_terms')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('purchase_invoices');
    }
}
