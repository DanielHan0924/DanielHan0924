<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInvoicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('project_id')->unsigned();
            $table->string('logo', 250)->nullable();
            $table->string('invoice_number', 25);
            $table->text('invoice_from');
            $table->text('bill_to');
            $table->date('invoice_create_date');
            $table->string("payment_terms");
            $table->date('invoice_due_date');
            $table->decimal('sub_total');
            $table->enum('discount_type', ['percentage', 'flat'])->default('flat');
            $table->decimal('discount_amount')->default(0.00);
            $table->decimal('total_payable');
            $table->decimal('amount_paid')->default(0.00);
            $table->decimal('total_due')->default(0.00);
            $table->text('note');
            $table->text('terms');
            $table->enum('invoice_status', ['Paid', 'Due']);

            /**
             * Foreign Key constraints
             */
            $table->foreign('project_id')->references('id')->on('projects')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('invoices');
    }
}
