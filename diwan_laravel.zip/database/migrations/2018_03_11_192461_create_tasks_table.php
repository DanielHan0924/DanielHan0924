<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTasksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tasks', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('project_id')->unsigned();
            $table->string('name', 100);
            $table->enum('status', ['Due', 'Done', 'Process'])->default('Due');
            $table->date('start_date');
            $table->date('due_date');
            $table->text('description');
            $table->integer('user_id')->nullable();
            $table->enum('priority', ['Low', 'Medium', 'High', 'Urgent']);

            /**
             * Foreign key references
             */


            $table->foreign('project_id')->references('id')->on('projects')->onDelete('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tasks');
    }
}
