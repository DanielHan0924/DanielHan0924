<?php

use Illuminate\Database\Seeder;

class PreferenceTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $preferences = [
            [
                'category' => 'preference',
                'field' => 'row_per_page',
                'value' => 25,
            ],
            [
                'category' => 'preference',
                'field' => 'date_format',
                'value' => 1,
            ],
            [
                'category' => 'preference',
                'field' => 'date_sepa',
                'value' => '-',
            ], [
                'category' => 'preference',
                'field' => 'date_format_type',
                'value' => 'dd-mm-yyyy',
            ],

        ];

        foreach ($preferences as $preference) {
            DB::table('preferences')->insert($preference);
        }
    }
}
