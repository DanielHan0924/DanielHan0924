<?php

use Illuminate\Database\Seeder;

class MonthTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $months = [
            [
                'name' => 'January'
            ],
            [
                'name' => 'February'
            ],
            [
                'name' => 'March'
            ], [
                'name' => 'April'
            ],
            [
                'name' => 'May'
            ],
            [
                'name' => 'June'
            ],
            [
                'name' => 'July'
            ],
            [
                'name' => 'August'
            ],
            [
                'name' => 'September'
            ],
            [
                'name' => 'October'
            ],
            [
                'name' => 'November'
            ],
            [
                'name' => 'December'
            ]

        ];

        foreach ($months as $month) {
            DB::table('months')->insert($month);
        }
    }
}
