<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //$this->call(SettingsTableSeeder::class);
        //$this->call(PreferenceTableSeeder::class);
        //$this->call(AccountTypeTableSeeder::class);
        //$this->call(MonthTableSeeder::class);
        $this->call(RolesPermissionsTableSeeder::class);
    }
}
