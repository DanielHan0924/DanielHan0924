<?php

use Illuminate\Database\Seeder;

class AccountTypeTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $accountTypeNames = [
            [
                'name' => 'Savings Account'
            ],
            [
                'name' => 'Chequing Account'
            ],
            [
                'name' => 'Credit Account'
            ], [
                'name' => 'Cash Account'
            ],

        ];

        foreach ($accountTypeNames as $accountTypeName) {
            DB::table('bank_account_type')->insert($accountTypeName);
        }


    }
}
