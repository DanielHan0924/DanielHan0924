<?php

use Illuminate\Database\Seeder;

class SettingsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('application_settings')->insert([
            'company_name'=>'QuantikLab',
            'address'=>'412 Example South Street',
            'city'=>'Los Angeles',
            'region'=>'FL',
            'country_id'=>18,
            'postbox'=>123,
            'phone'=>'410-987-89-60',
            'email'=>'quantiklab@gmail.com'
        ]);
    }
}
