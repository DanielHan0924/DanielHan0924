<?php

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolesPermissionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Reset cached roles and permissions
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();


        // create permissions for sales invoice
        Permission::create(['name' => 'create_sales_invoice']);
        Permission::create(['name' => 'view_sales_invoice']);
        Permission::create(['name' => 'edit_sales_invoice']);
        Permission::create(['name' => 'delete_sales_invoice']);

        // create permissions for quote
        Permission::create(['name' => 'create_quote']);
        Permission::create(['name' => 'view_quote']);
        Permission::create(['name' => 'edit_quote']);
        Permission::create(['name' => 'delete_quote']);
        Permission::create(['name' => 'convert_quote_to_invoice']);

        Permission::create(['name' => 'manage_payment']);

        Permission::create(['name' => 'create_product']);
        Permission::create(['name' => 'view_product']);
        Permission::create(['name' => 'edit_product']);
        Permission::create(['name' => 'delete_product']);

        Permission::create(['name' => 'create_category']);
        Permission::create(['name' => 'edit_category']);
        Permission::create(['name' => 'delete_category']);

        Permission::create(['name' => 'create_warehouse']);
        Permission::create(['name' => 'edit_warehouse']);
        Permission::create(['name' => 'delete_warehouse']);

        Permission::create(['name' => 'create_purchase_order']);
        Permission::create(['name' => 'view_purchase_order']);
        Permission::create(['name' => 'edit_purchase_order']);
        Permission::create(['name' => 'delete_purchase_order']);


        Permission::create(['name' => 'create_customer']);
        Permission::create(['name' => 'view_customer']);
        Permission::create(['name' => 'edit_customer']);
        Permission::create(['name' => 'delete_customer']);

        Permission::create(['name' => 'create_ticket']);
        Permission::create(['name' => 'view_ticket']);
        Permission::create(['name' => 'edit_ticket']);
        Permission::create(['name' => 'delete_ticket']);
        Permission::create(['name' => 'manage_answered_tickets']);

        Permission::create(['name' => 'create_supplier']);
        Permission::create(['name' => 'view_supplier']);
        Permission::create(['name' => 'edit_supplier']);
        Permission::create(['name' => 'delete_supplier']);

        Permission::create(['name' => 'create_employee']);
        Permission::create(['name' => 'view_employee']);
        Permission::create(['name' => 'edit_employee']);
        Permission::create(['name' => 'delete_employee']);

        Permission::create(['name' => 'create_project']);
        Permission::create(['name' => 'manage_project_room']);
        Permission::create(['name' => 'edit_project']);
        Permission::create(['name' => 'delete_project']);

        Permission::create(['name' => 'create_project_invoice']);
        Permission::create(['name' => 'view_project_invoice']);
        Permission::create(['name' => 'edit_project_invoice']);
        Permission::create(['name' => 'delete_project_invoice']);
        Permission::create(['name' => 'download_pdf_project_invoice']);

        Permission::create(['name' => 'create_task']);
        Permission::create(['name' => 'view_task']);
        Permission::create(['name' => 'edit_task']);
        Permission::create(['name' => 'delete_task']);

        Permission::create(['name' => 'create_account']);
        Permission::create(['name' => 'view_account']);
        Permission::create(['name' => 'edit_account']);
        Permission::create(['name' => 'delete_account']);
        Permission::create(['name' => 'manage_balance_sheet']);
        Permission::create(['name' => 'manage_account_statement']);

        Permission::create(['name' => 'create_transaction']);
        Permission::create(['name' => 'view_transaction']);
        Permission::create(['name' => 'delete_transaction']);
        Permission::create(['name' => 'manage_transfer']);

        Permission::create(['name' => 'create_income']);
        Permission::create(['name' => 'view_income']);
        Permission::create(['name' => 'delete_income']);

        Permission::create(['name' => 'create_expense']);
        Permission::create(['name' => 'view_expense']);
        Permission::create(['name' => 'delete_expense']);


        Permission::create(['name' => 'report_inventory_stock_on_hand']);
        Permission::create(['name' => 'report_sales_report']);
        Permission::create(['name' => 'report_purchase_report']);
        Permission::create(['name' => 'report_expense_report']);
        Permission::create(['name' => 'report_income_report']);
        Permission::create(['name' => 'report_income_vs_expense']);

        Permission::create(['name' => 'create_note']);
        Permission::create(['name' => 'edit_note']);
        Permission::create(['name' => 'delete_note']);

        Permission::create(['name' => 'manage_event']);
        Permission::create(['name' => 'manage_message']);

        Permission::create(['name' => 'application_setting']);
        Permission::create(['name' => 'email_template_setting']);
        Permission::create(['name' => 'manage_income_expense_category']);
        Permission::create(['name' => 'manage_role_permission']);

        Permission::create(['name' => 'create_payment_terms']);
        Permission::create(['name' => 'edit_payment_terms']);
        Permission::create(['name' => 'delete_payment_terms']);

        Permission::create(['name' => 'create_tax']);
        Permission::create(['name' => 'edit_tax']);
        Permission::create(['name' => 'delete_tax']);

        Permission::create(['name' => 'create_payment_method']);
        Permission::create(['name' => 'edit_payment_method']);
        Permission::create(['name' => 'delete_payment_method']);

        Permission::create(['name' => 'create_bank_account']);
        Permission::create(['name' => 'edit_bank_account']);
        Permission::create(['name' => 'delete_bank_account']);


        Permission::create(['name' => 'export_people_data']);
        Permission::create(['name' => 'export_transactions']);
        Permission::create(['name' => 'export_products']);
        Permission::create(['name' => 'manage_database_backup']);
        Permission::create(['name' => 'view_user_log']);

        // this can be done as separate statements
//        $role = Role::create(['name' => 'manager']);
//        $role->givePermissionTo(['create_customer','edit_customer','delete_customer']);

        // Grant all permission to a specific role
        $role = Role::create(['name' => 'business_owner']);
        $role->givePermissionTo(Permission::all());


    }
}
