/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 100408
 Source Host           : localhost:3306
 Source Schema         : ekiegrou_diwan3

 Target Server Type    : MySQL
 Target Server Version : 100408
 File Encoding         : 65001

 Date: 23/01/2021 04:01:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for accounts
-- ----------------------------
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `account_type_id` int(11) NULL DEFAULT NULL,
  `account_number` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_holder` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_balance` decimal(10, 2) NOT NULL DEFAULT 0,
  `note` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `bank_name` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `bank_address` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of accounts
-- ----------------------------
INSERT INTO `accounts` VALUES (3, 1, '7642347328', 'Accounts Receivable', 18900.00, 'Initial Account Receivable', '2018-07-10 11:44:13', '2019-03-16 16:24:02', 'Jamuna Bank', 'Syamoli, Mohammadpur');
INSERT INTO `accounts` VALUES (4, 4, '7642347320', 'General Sales', 9000.00, 'Sales Account', '2018-07-10 11:44:51', '2019-03-02 15:02:20', 'Bank Alfala', 'Mirpur');
INSERT INTO `accounts` VALUES (5, 4, '7642347326', 'Expense Account', -42000.00, 'Expenses', '2018-11-12 13:12:40', '2019-03-16 16:26:03', 'Bank Alfala', 'Dhaka, Mohammadpur');

-- ----------------------------
-- Table structure for activity_log
-- ----------------------------
DROP TABLE IF EXISTS `activity_log`;
CREATE TABLE `activity_log`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `log_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` int(11) NULL DEFAULT NULL,
  `subject_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `causer_id` int(11) NULL DEFAULT NULL,
  `causer_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `properties` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `activity_log_log_name_index`(`log_name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 843 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of activity_log
-- ----------------------------
INSERT INTO `activity_log` VALUES (751, 'default', 'Shibly has created supplier name Jon Doe', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 14:12:21', '2019-03-02 14:12:21');
INSERT INTO `activity_log` VALUES (752, 'default', 'Shibly has delete supplier.', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 14:12:44', '2019-03-02 14:12:44');
INSERT INTO `activity_log` VALUES (753, 'default', 'Shibly has created supplier name Jon Doe', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 14:17:00', '2019-03-02 14:17:00');
INSERT INTO `activity_log` VALUES (754, 'default', 'User Shibly has created a employee name: Joh Dew', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 14:20:37', '2019-03-02 14:20:37');
INSERT INTO `activity_log` VALUES (755, 'default', 'User Shibly has sales invoice created', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 14:22:08', '2019-03-02 14:22:08');
INSERT INTO `activity_log` VALUES (756, 'default', 'Shibly make a payment for an invoice', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 14:30:29', '2019-03-02 14:30:29');
INSERT INTO `activity_log` VALUES (757, 'default', 'User Shibly has created a quote 0001', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 14:32:50', '2019-03-02 14:32:50');
INSERT INTO `activity_log` VALUES (758, 'default', 'User Shibly has created a purchase invoice 0001', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 14:41:29', '2019-03-02 14:41:29');
INSERT INTO `activity_log` VALUES (759, 'default', 'User Shibly has sales invoice created', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 15:01:44', '2019-03-02 15:01:44');
INSERT INTO `activity_log` VALUES (760, 'default', 'Shibly make a payment for an invoice', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 15:02:24', '2019-03-02 15:02:24');
INSERT INTO `activity_log` VALUES (761, 'default', 'User Shibly has created project name:Bizbangladesh', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 15:04:15', '2019-03-02 15:04:15');
INSERT INTO `activity_log` VALUES (762, 'default', 'Shibly has created an invoice', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 15:06:37', '2019-03-02 15:06:37');
INSERT INTO `activity_log` VALUES (763, 'default', 'Shibly make a payment for an invoice', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 15:11:32', '2019-03-02 15:11:32');
INSERT INTO `activity_log` VALUES (764, 'default', 'Shibly has created an invoice', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 15:13:48', '2019-03-02 15:13:48');
INSERT INTO `activity_log` VALUES (765, 'default', 'Shibly make a payment for an invoice', NULL, NULL, 1, 'App\\User', '[]', '2019-03-02 15:16:36', '2019-03-02 15:16:36');
INSERT INTO `activity_log` VALUES (766, 'default', 'rakibuddin101 has logged in to the system at March 3, 2019, 2:28 pm', NULL, NULL, 37, 'App\\User', '[]', '2019-03-03 10:28:52', '2019-03-03 10:28:52');
INSERT INTO `activity_log` VALUES (767, 'default', 'rakibuddin101 has logged in to the system at March 3, 2019, 4:06 pm', NULL, NULL, 37, 'App\\User', '[]', '2019-03-03 12:06:23', '2019-03-03 12:06:23');
INSERT INTO `activity_log` VALUES (768, 'default', 'Shibly has logged in to the system at March 3, 2019, 4:15 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-03 12:15:27', '2019-03-03 12:15:27');
INSERT INTO `activity_log` VALUES (769, 'default', 'User Shibly has deleted a purchase invoice ', NULL, NULL, 1, 'App\\User', '[]', '2019-03-03 12:24:46', '2019-03-03 12:24:46');
INSERT INTO `activity_log` VALUES (770, 'default', 'User Shibly has created a purchase invoice 0001', NULL, NULL, 1, 'App\\User', '[]', '2019-03-03 12:39:14', '2019-03-03 12:39:14');
INSERT INTO `activity_log` VALUES (771, 'default', 'Shibly has created Update Second Version', NULL, NULL, 1, 'App\\User', '[]', '2019-03-03 14:17:53', '2019-03-03 14:17:53');
INSERT INTO `activity_log` VALUES (772, 'default', 'rakibuddin101 has logged in to the system at March 3, 2019, 6:23 pm', NULL, NULL, 37, 'App\\User', '[]', '2019-03-03 14:23:56', '2019-03-03 14:23:56');
INSERT INTO `activity_log` VALUES (773, 'default', 'Shibly has logged in to the system at March 3, 2019, 8:57 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-03 16:57:07', '2019-03-03 16:57:07');
INSERT INTO `activity_log` VALUES (774, 'default', 'Shibly has update details for customer name Rakib Uddin', NULL, NULL, 1, 'App\\User', '[]', '2019-03-03 17:00:30', '2019-03-03 17:00:30');
INSERT INTO `activity_log` VALUES (775, 'default', 'rakibuddin101 has logged in to the system at March 3, 2019, 9:00 pm', NULL, NULL, 37, 'App\\User', '[]', '2019-03-03 17:00:43', '2019-03-03 17:00:43');
INSERT INTO `activity_log` VALUES (776, 'default', 'Shibly has logged in to the system at March 3, 2019, 9:03 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-03 17:03:36', '2019-03-03 17:03:36');
INSERT INTO `activity_log` VALUES (777, 'default', 'Shibly has logged in to the system at March 4, 2019, 8:09 am', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 04:09:51', '2019-03-04 04:09:51');
INSERT INTO `activity_log` VALUES (778, 'default', 'User Shibly has created a employee name: Sales Manager', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 04:10:49', '2019-03-04 04:10:49');
INSERT INTO `activity_log` VALUES (779, 'default', 'User Shibly has created a employee name: Sales Person', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 04:11:46', '2019-03-04 04:11:46');
INSERT INTO `activity_log` VALUES (780, 'default', 'User Shibly has created a employee name: Project Manager', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 04:12:45', '2019-03-04 04:12:45');
INSERT INTO `activity_log` VALUES (781, 'default', 'User Shibly has created a employee name: Sotck Manager', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 04:16:50', '2019-03-04 04:16:50');
INSERT INTO `activity_log` VALUES (782, 'default', 'User Shibly has created a employee name: Project Person', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 04:17:44', '2019-03-04 04:17:44');
INSERT INTO `activity_log` VALUES (783, 'default', 'User Shibly has updated a employee name: Joh Dew', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 04:18:09', '2019-03-04 04:18:09');
INSERT INTO `activity_log` VALUES (784, 'default', 'User Shibly has updated a employee name: Project Person', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 04:18:40', '2019-03-04 04:18:40');
INSERT INTO `activity_log` VALUES (785, 'default', 'User Shibly has deleted a employee.', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 04:18:54', '2019-03-04 04:18:54');
INSERT INTO `activity_log` VALUES (786, 'default', 'Shibly has logged in to the system at March 4, 2019, 4:48 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 12:48:48', '2019-03-04 12:48:48');
INSERT INTO `activity_log` VALUES (787, 'default', 'Shibly has updated his profile', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 13:01:00', '2019-03-04 13:01:00');
INSERT INTO `activity_log` VALUES (788, 'default', 'User Shibly has updated project name:Bizbangladesh', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 13:38:40', '2019-03-04 13:38:40');
INSERT INTO `activity_log` VALUES (789, 'default', 'User Shibly has updated project name:Bizbangladesh', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 13:38:59', '2019-03-04 13:38:59');
INSERT INTO `activity_log` VALUES (790, 'default', 'Shibly has logged in to the system at March 4, 2019, 5:42 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 13:42:53', '2019-03-04 13:42:53');
INSERT INTO `activity_log` VALUES (791, 'default', 'sales has logged in to the system at March 4, 2019, 6:15 pm', NULL, NULL, 42, 'App\\User', '[]', '2019-03-04 14:15:19', '2019-03-04 14:15:19');
INSERT INTO `activity_log` VALUES (792, 'default', 'Shibly has logged in to the system at March 4, 2019, 6:18 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 14:18:24', '2019-03-04 14:18:24');
INSERT INTO `activity_log` VALUES (793, 'default', 'employee has logged in to the system at March 4, 2019, 6:32 pm', NULL, NULL, 40, 'App\\User', '[]', '2019-03-04 14:32:18', '2019-03-04 14:32:18');
INSERT INTO `activity_log` VALUES (794, 'default', 'manager has logged in to the system at March 4, 2019, 6:35 pm', NULL, NULL, 41, 'App\\User', '[]', '2019-03-04 14:35:09', '2019-03-04 14:35:09');
INSERT INTO `activity_log` VALUES (795, 'default', 'sales has logged in to the system at March 4, 2019, 6:37 pm', NULL, NULL, 42, 'App\\User', '[]', '2019-03-04 14:37:39', '2019-03-04 14:37:39');
INSERT INTO `activity_log` VALUES (796, 'default', 'Shibly has logged in to the system at March 4, 2019, 6:39 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 14:39:52', '2019-03-04 14:39:52');
INSERT INTO `activity_log` VALUES (797, 'default', 'User Shibly has created a employee name: Business Manager', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 14:42:57', '2019-03-04 14:42:57');
INSERT INTO `activity_log` VALUES (798, 'default', 'businessmanager has logged in to the system at March 4, 2019, 6:43 pm', NULL, NULL, 46, 'App\\User', '[]', '2019-03-04 14:43:19', '2019-03-04 14:43:19');
INSERT INTO `activity_log` VALUES (799, 'default', 'businessmanager has updated his profile', NULL, NULL, 46, 'App\\User', '[]', '2019-03-04 14:44:22', '2019-03-04 14:44:22');
INSERT INTO `activity_log` VALUES (800, 'default', 'Shibly has logged in to the system at March 4, 2019, 6:44 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 14:44:50', '2019-03-04 14:44:50');
INSERT INTO `activity_log` VALUES (801, 'default', 'Shibly has logged in to the system at March 4, 2019, 7:45 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 15:45:00', '2019-03-04 15:45:00');
INSERT INTO `activity_log` VALUES (802, 'default', 'User Shibly has updated a employee name: John Doe', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 15:45:28', '2019-03-04 15:45:28');
INSERT INTO `activity_log` VALUES (803, 'default', 'User Shibly has updated a employee name: Jane Doe', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 15:45:49', '2019-03-04 15:45:49');
INSERT INTO `activity_log` VALUES (804, 'default', 'User Shibly has updated a employee name: Jason Vore', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 15:46:54', '2019-03-04 15:46:54');
INSERT INTO `activity_log` VALUES (805, 'default', 'User Shibly has updated a employee name: David Vore', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 15:47:09', '2019-03-04 15:47:09');
INSERT INTO `activity_log` VALUES (806, 'default', 'User Shibly has updated a employee name: Salina Lee', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 15:47:25', '2019-03-04 15:47:25');
INSERT INTO `activity_log` VALUES (807, 'default', 'User Shibly has updated a employee name: Paul Alen', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 15:48:05', '2019-03-04 15:48:05');
INSERT INTO `activity_log` VALUES (808, 'default', 'Shibly has update details for customer name Rakib Uddin', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 15:49:03', '2019-03-04 15:49:03');
INSERT INTO `activity_log` VALUES (809, 'default', 'Shibly has updated his profile', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 15:49:28', '2019-03-04 15:49:28');
INSERT INTO `activity_log` VALUES (810, 'default', 'janedoe has logged in to the system at March 4, 2019, 7:49 pm', NULL, NULL, 40, 'App\\User', '[]', '2019-03-04 15:49:56', '2019-03-04 15:49:56');
INSERT INTO `activity_log` VALUES (811, 'default', 'admin has logged in to the system at March 4, 2019, 7:51 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 15:51:06', '2019-03-04 15:51:06');
INSERT INTO `activity_log` VALUES (812, 'default', 'admin has updated his profile', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 16:09:31', '2019-03-04 16:09:31');
INSERT INTO `activity_log` VALUES (813, 'default', 'janedoe has logged in to the system at March 4, 2019, 8:09 pm', NULL, NULL, 40, 'App\\User', '[]', '2019-03-04 16:09:42', '2019-03-04 16:09:42');
INSERT INTO `activity_log` VALUES (814, 'default', 'qlab has logged in to the system at March 4, 2019, 8:10 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-04 16:10:39', '2019-03-04 16:10:39');
INSERT INTO `activity_log` VALUES (815, 'default', 'janedoe has logged in to the system at March 4, 2019, 8:11 pm', NULL, NULL, 40, 'App\\User', '[]', '2019-03-04 16:11:14', '2019-03-04 16:11:14');
INSERT INTO `activity_log` VALUES (816, 'default', 'qlab has logged in to the system at March 5, 2019, 5:05 am', NULL, NULL, 1, 'App\\User', '[]', '2019-03-05 01:05:44', '2019-03-05 01:05:44');
INSERT INTO `activity_log` VALUES (817, 'default', 'qlab has update details for customer name Rakib Uddin', NULL, NULL, 1, 'App\\User', '[]', '2019-03-05 01:28:06', '2019-03-05 01:28:06');
INSERT INTO `activity_log` VALUES (818, 'default', 'qlab has update details for customer name Rakib Uddin', NULL, NULL, 1, 'App\\User', '[]', '2019-03-05 01:28:46', '2019-03-05 01:28:46');
INSERT INTO `activity_log` VALUES (819, 'default', 'rakibuddin101 has logged in to the system at March 5, 2019, 5:29 am', NULL, NULL, 37, 'App\\User', '[]', '2019-03-05 01:29:01', '2019-03-05 01:29:01');
INSERT INTO `activity_log` VALUES (820, 'default', 'qlab has logged in to the system at March 5, 2019, 5:29 am', NULL, NULL, 1, 'App\\User', '[]', '2019-03-05 01:29:45', '2019-03-05 01:29:45');
INSERT INTO `activity_log` VALUES (821, 'default', 'qlab has logged in to the system at March 5, 2019, 6:51 am', NULL, NULL, 1, 'App\\User', '[]', '2019-03-05 02:51:20', '2019-03-05 02:51:20');
INSERT INTO `activity_log` VALUES (822, 'default', 'qlab has logged in to the system at March 5, 2019, 9:14 am', NULL, NULL, 1, 'App\\User', '[]', '2019-03-05 05:14:53', '2019-03-05 05:14:53');
INSERT INTO `activity_log` VALUES (823, 'default', 'qlab has logged in to the system at March 9, 2019, 5:53 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-09 13:53:49', '2019-03-09 13:53:49');
INSERT INTO `activity_log` VALUES (824, 'default', 'qlab has logged in to the system at March 11, 2019, 6:48 am', NULL, NULL, 1, 'App\\User', '[]', '2019-03-11 02:48:58', '2019-03-11 02:48:58');
INSERT INTO `activity_log` VALUES (825, 'default', 'qlab has logged in to the system at March 12, 2019, 7:26 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-12 15:26:51', '2019-03-12 15:26:51');
INSERT INTO `activity_log` VALUES (826, 'default', 'qlab has logged in to the system at March 12, 2019, 7:56 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-12 15:56:08', '2019-03-12 15:56:08');
INSERT INTO `activity_log` VALUES (827, 'default', 'qlab has logged in to the system at March 12, 2019, 8:23 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-12 16:23:17', '2019-03-12 16:23:17');
INSERT INTO `activity_log` VALUES (828, 'default', 'qlab has logged in to the system at March 13, 2019, 8:15 am', NULL, NULL, 1, 'App\\User', '[]', '2019-03-13 04:15:14', '2019-03-13 04:15:14');
INSERT INTO `activity_log` VALUES (829, 'default', 'qlab has logged in to the system at March 13, 2019, 4:49 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-13 12:49:55', '2019-03-13 12:49:55');
INSERT INTO `activity_log` VALUES (830, 'default', 'qlab has logged in to the system at March 16, 2019, 8:23 pm', NULL, NULL, 1, 'App\\User', '[]', '2019-03-16 16:23:20', '2019-03-16 16:23:20');
INSERT INTO `activity_log` VALUES (831, 'default', 'Application settings has been updated.', NULL, NULL, 1, 'App\\User', '[]', '2020-12-27 18:29:24', '2020-12-27 18:29:24');
INSERT INTO `activity_log` VALUES (832, 'default', 'qlab has logged in to the system at December 28, 2020, 2:22 pm', NULL, NULL, 1, 'App\\User', '[]', '2020-12-28 16:22:12', '2020-12-28 16:22:12');
INSERT INTO `activity_log` VALUES (833, 'default', 'qlab has logged in to the system at December 28, 2020, 8:28 pm', NULL, NULL, 1, 'App\\User', '[]', '2020-12-28 22:28:49', '2020-12-28 22:28:49');
INSERT INTO `activity_log` VALUES (834, 'default', 'qlab has logged in to the system at December 30, 2020, 6:22 pm', NULL, NULL, 1, 'App\\User', '[]', '2020-12-30 20:22:34', '2020-12-30 20:22:34');
INSERT INTO `activity_log` VALUES (835, 'default', 'qlab has logged in to the system at December 30, 2020, 9:32 pm', NULL, NULL, 1, 'App\\User', '[]', '2020-12-30 23:32:21', '2020-12-30 23:32:21');
INSERT INTO `activity_log` VALUES (836, 'default', 'qlab has logged in to the system at December 30, 2020, 10:35 pm', NULL, NULL, 1, 'App\\User', '[]', '2020-12-31 00:35:53', '2020-12-31 00:35:53');
INSERT INTO `activity_log` VALUES (837, 'default', 'qlab has logged in to the system at December 31, 2020, 2:42 pm', NULL, NULL, 1, 'App\\User', '[]', '2020-12-31 16:42:49', '2020-12-31 16:42:49');
INSERT INTO `activity_log` VALUES (838, 'default', 'qlab has logged in to the system at December 31, 2020, 11:35 pm', NULL, NULL, 1, 'App\\User', '[]', '2021-01-01 01:35:22', '2021-01-01 01:35:22');
INSERT INTO `activity_log` VALUES (839, 'default', 'qlab has logged in to the system at December 31, 2020, 11:43 pm', NULL, NULL, 1, 'App\\User', '[]', '2021-01-01 01:43:53', '2021-01-01 01:43:53');
INSERT INTO `activity_log` VALUES (840, 'default', 'qlab has logged in to the system at December 31, 2020, 11:47 pm', NULL, NULL, 1, 'App\\User', '[]', '2021-01-01 01:47:11', '2021-01-01 01:47:11');
INSERT INTO `activity_log` VALUES (841, 'default', 'qlab has logged in to the system at January 1, 2021, 3:16 pm', NULL, NULL, 1, 'App\\User', '[]', '2021-01-01 17:16:58', '2021-01-01 17:16:58');
INSERT INTO `activity_log` VALUES (842, 'default', 'qlab has logged in to the system at January 1, 2021, 7:42 pm', NULL, NULL, 1, 'App\\User', '[]', '2021-01-01 21:42:02', '2021-01-01 21:42:02');

-- ----------------------------
-- Table structure for application_settings
-- ----------------------------
DROP TABLE IF EXISTS `application_settings`;
CREATE TABLE `application_settings`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `company_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `address` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `city` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `region` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `country_id` int(10) UNSIGNED NOT NULL,
  `postbox` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `email` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `taxid` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `tax` int(11) NULL DEFAULT NULL,
  `currency` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `currency_format` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `prefix` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `date_format` int(11) NULL DEFAULT NULL,
  `zone` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `company_logo` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '',
  `default_expense_id` int(10) NOT NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `application_settings_country_id_foreign`(`country_id`) USING BTREE,
  CONSTRAINT `application_settings_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of application_settings
-- ----------------------------
INSERT INTO `application_settings` VALUES (1, 'QuantikLab', '<p>Nobodoy housing society, road#9, house#4\n</p><p>Dhaka-1207, Bangladesh</p>', 'Dhaka', 'Dhaka', 18, '1207', '01613404299', 'quantiklab@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5c6e562988644.jpg', 0, NULL, '2020-12-27 18:29:24');

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of categories
-- ----------------------------
INSERT INTO `categories` VALUES (4, 'Dell', 'Dell', '2018-03-25 02:45:50', '2019-01-31 14:02:24');
INSERT INTO `categories` VALUES (5, 'Sony', 'Sony', '2018-03-25 02:45:55', '2019-01-31 14:02:31');
INSERT INTO `categories` VALUES (7, 'Test Category', 'This is a test category', '2018-03-27 11:29:14', '2018-03-27 11:29:14');
INSERT INTO `categories` VALUES (8, 'Test Category', 'This is a test category', '2018-03-27 11:29:33', '2018-03-27 11:29:33');
INSERT INTO `categories` VALUES (10, 'Fucking category', 'Fucking category description', '2018-04-04 15:03:27', '2018-04-04 15:03:27');
INSERT INTO `categories` VALUES (13, 'Apple', 'Apple Products goes here', '2018-04-04 15:18:24', '2018-04-04 15:18:24');

-- ----------------------------
-- Table structure for color_themes
-- ----------------------------
DROP TABLE IF EXISTS `color_themes`;
CREATE TABLE `color_themes`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `theme_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of color_themes
-- ----------------------------
INSERT INTO `color_themes` VALUES (1, 'skin-black', '2018-03-28 14:39:34', '2020-12-27 18:34:54');

-- ----------------------------
-- Table structure for countries
-- ----------------------------
DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `country_code` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 246 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of countries
-- ----------------------------
INSERT INTO `countries` VALUES (1, 'AF', 'Afghanistan');
INSERT INTO `countries` VALUES (2, 'AL', 'Albania');
INSERT INTO `countries` VALUES (3, 'DZ', 'Algeria');
INSERT INTO `countries` VALUES (4, 'DS', 'American Samoa');
INSERT INTO `countries` VALUES (5, 'AD', 'Andorra');
INSERT INTO `countries` VALUES (6, 'AO', 'Angola');
INSERT INTO `countries` VALUES (7, 'AI', 'Anguilla');
INSERT INTO `countries` VALUES (8, 'AQ', 'Antarctica');
INSERT INTO `countries` VALUES (9, 'AG', 'Antigua and Barbuda');
INSERT INTO `countries` VALUES (10, 'AR', 'Argentina');
INSERT INTO `countries` VALUES (11, 'AM', 'Armenia');
INSERT INTO `countries` VALUES (12, 'AW', 'Aruba');
INSERT INTO `countries` VALUES (13, 'AU', 'Australia');
INSERT INTO `countries` VALUES (14, 'AT', 'Austria');
INSERT INTO `countries` VALUES (15, 'AZ', 'Azerbaijan');
INSERT INTO `countries` VALUES (16, 'BS', 'Bahamas');
INSERT INTO `countries` VALUES (17, 'BH', 'Bahrain');
INSERT INTO `countries` VALUES (18, 'BD', 'Bangladesh');
INSERT INTO `countries` VALUES (19, 'BB', 'Barbados');
INSERT INTO `countries` VALUES (20, 'BY', 'Belarus');
INSERT INTO `countries` VALUES (21, 'BE', 'Belgium');
INSERT INTO `countries` VALUES (22, 'BZ', 'Belize');
INSERT INTO `countries` VALUES (23, 'BJ', 'Benin');
INSERT INTO `countries` VALUES (24, 'BM', 'Bermuda');
INSERT INTO `countries` VALUES (25, 'BT', 'Bhutan');
INSERT INTO `countries` VALUES (26, 'BO', 'Bolivia');
INSERT INTO `countries` VALUES (27, 'BA', 'Bosnia and Herzegovi');
INSERT INTO `countries` VALUES (28, 'BW', 'Botswana');
INSERT INTO `countries` VALUES (29, 'BV', 'Bouvet Island');
INSERT INTO `countries` VALUES (30, 'BR', 'Brazil');
INSERT INTO `countries` VALUES (31, 'IO', 'British Indian Ocean');
INSERT INTO `countries` VALUES (32, 'BN', 'Brunei Darussalam');
INSERT INTO `countries` VALUES (33, 'BG', 'Bulgaria');
INSERT INTO `countries` VALUES (34, 'BF', 'Burkina Faso');
INSERT INTO `countries` VALUES (35, 'BI', 'Burundi');
INSERT INTO `countries` VALUES (36, 'KH', 'Cambodia');
INSERT INTO `countries` VALUES (37, 'CM', 'Cameroon');
INSERT INTO `countries` VALUES (38, 'CA', 'Canada');
INSERT INTO `countries` VALUES (39, 'CV', 'Cape Verde');
INSERT INTO `countries` VALUES (40, 'KY', 'Cayman Islands');
INSERT INTO `countries` VALUES (41, 'CF', 'Central African Repu');
INSERT INTO `countries` VALUES (42, 'TD', 'Chad');
INSERT INTO `countries` VALUES (43, 'CL', 'Chile');
INSERT INTO `countries` VALUES (44, 'CN', 'China');
INSERT INTO `countries` VALUES (45, 'CX', 'Christmas Island');
INSERT INTO `countries` VALUES (46, 'CC', 'Cocos (Keeling) Isla');
INSERT INTO `countries` VALUES (47, 'CO', 'Colombia');
INSERT INTO `countries` VALUES (48, 'KM', 'Comoros');
INSERT INTO `countries` VALUES (49, 'CG', 'Congo');
INSERT INTO `countries` VALUES (50, 'CK', 'Cook Islands');
INSERT INTO `countries` VALUES (51, 'CR', 'Costa Rica');
INSERT INTO `countries` VALUES (52, 'HR', 'Croatia (Hrvatska)');
INSERT INTO `countries` VALUES (53, 'CU', 'Cuba');
INSERT INTO `countries` VALUES (54, 'CY', 'Cyprus');
INSERT INTO `countries` VALUES (55, 'CZ', 'Czech Republic');
INSERT INTO `countries` VALUES (56, 'DK', 'Denmark');
INSERT INTO `countries` VALUES (57, 'DJ', 'Djibouti');
INSERT INTO `countries` VALUES (58, 'DM', 'Dominica');
INSERT INTO `countries` VALUES (59, 'DO', 'Dominican Republic');
INSERT INTO `countries` VALUES (60, 'TP', 'East Timor');
INSERT INTO `countries` VALUES (61, 'EC', 'Ecuador');
INSERT INTO `countries` VALUES (62, 'EG', 'Egypt');
INSERT INTO `countries` VALUES (63, 'SV', 'El Salvador');
INSERT INTO `countries` VALUES (64, 'GQ', 'Equatorial Guinea');
INSERT INTO `countries` VALUES (65, 'ER', 'Eritrea');
INSERT INTO `countries` VALUES (66, 'EE', 'Estonia');
INSERT INTO `countries` VALUES (67, 'ET', 'Ethiopia');
INSERT INTO `countries` VALUES (68, 'FK', 'Falkland Islands (Ma');
INSERT INTO `countries` VALUES (69, 'FO', 'Faroe Islands');
INSERT INTO `countries` VALUES (70, 'FJ', 'Fiji');
INSERT INTO `countries` VALUES (71, 'FI', 'Finland');
INSERT INTO `countries` VALUES (72, 'FR', 'France');
INSERT INTO `countries` VALUES (73, 'FX', 'France, Metropolitan');
INSERT INTO `countries` VALUES (74, 'GF', 'French Guiana');
INSERT INTO `countries` VALUES (75, 'PF', 'French Polynesia');
INSERT INTO `countries` VALUES (76, 'TF', 'French Southern Terr');
INSERT INTO `countries` VALUES (77, 'GA', 'Gabon');
INSERT INTO `countries` VALUES (78, 'GM', 'Gambia');
INSERT INTO `countries` VALUES (79, 'GE', 'Georgia');
INSERT INTO `countries` VALUES (80, 'DE', 'Germany');
INSERT INTO `countries` VALUES (81, 'GH', 'Ghana');
INSERT INTO `countries` VALUES (82, 'GI', 'Gibraltar');
INSERT INTO `countries` VALUES (83, 'GK', 'Guernsey');
INSERT INTO `countries` VALUES (84, 'GR', 'Greece');
INSERT INTO `countries` VALUES (85, 'GL', 'Greenland');
INSERT INTO `countries` VALUES (86, 'GD', 'Grenada');
INSERT INTO `countries` VALUES (87, 'GP', 'Guadeloupe');
INSERT INTO `countries` VALUES (88, 'GU', 'Guam');
INSERT INTO `countries` VALUES (89, 'GT', 'Guatemala');
INSERT INTO `countries` VALUES (90, 'GN', 'Guinea');
INSERT INTO `countries` VALUES (91, 'GW', 'Guinea-Bissau');
INSERT INTO `countries` VALUES (92, 'GY', 'Guyana');
INSERT INTO `countries` VALUES (93, 'HT', 'Haiti');
INSERT INTO `countries` VALUES (94, 'HM', 'Heard and Mc Donald ');
INSERT INTO `countries` VALUES (95, 'HN', 'Honduras');
INSERT INTO `countries` VALUES (96, 'HK', 'Hong Kong');
INSERT INTO `countries` VALUES (97, 'HU', 'Hungary');
INSERT INTO `countries` VALUES (98, 'IS', 'Iceland');
INSERT INTO `countries` VALUES (99, 'IN', 'India');
INSERT INTO `countries` VALUES (100, 'IM', 'Isle of Man');
INSERT INTO `countries` VALUES (101, 'ID', 'Indonesia');
INSERT INTO `countries` VALUES (102, 'IR', 'Iran (Islamic Republ');
INSERT INTO `countries` VALUES (103, 'IQ', 'Iraq');
INSERT INTO `countries` VALUES (104, 'IE', 'Ireland');
INSERT INTO `countries` VALUES (105, 'IL', 'Israel');
INSERT INTO `countries` VALUES (106, 'IT', 'Italy');
INSERT INTO `countries` VALUES (107, 'CI', 'Ivory Coast');
INSERT INTO `countries` VALUES (108, 'JE', 'Jersey');
INSERT INTO `countries` VALUES (109, 'JM', 'Jamaica');
INSERT INTO `countries` VALUES (110, 'JP', 'Japan');
INSERT INTO `countries` VALUES (111, 'JO', 'Jordan');
INSERT INTO `countries` VALUES (112, 'KZ', 'Kazakhstan');
INSERT INTO `countries` VALUES (113, 'KE', 'Kenya');
INSERT INTO `countries` VALUES (114, 'KI', 'Kiribati');
INSERT INTO `countries` VALUES (115, 'KP', 'Korea, Democratic Pe');
INSERT INTO `countries` VALUES (116, 'KR', 'Korea, Republic of');
INSERT INTO `countries` VALUES (117, 'XK', 'Kosovo');
INSERT INTO `countries` VALUES (118, 'KW', 'Kuwait');
INSERT INTO `countries` VALUES (119, 'KG', 'Kyrgyzstan');
INSERT INTO `countries` VALUES (120, 'LA', 'Lao People\'s Democra');
INSERT INTO `countries` VALUES (121, 'LV', 'Latvia');
INSERT INTO `countries` VALUES (122, 'LB', 'Lebanon');
INSERT INTO `countries` VALUES (123, 'LS', 'Lesotho');
INSERT INTO `countries` VALUES (124, 'LR', 'Liberia');
INSERT INTO `countries` VALUES (125, 'LY', 'Libyan Arab Jamahiri');
INSERT INTO `countries` VALUES (126, 'LI', 'Liechtenstein');
INSERT INTO `countries` VALUES (127, 'LT', 'Lithuania');
INSERT INTO `countries` VALUES (128, 'LU', 'Luxembourg');
INSERT INTO `countries` VALUES (129, 'MO', 'Macau');
INSERT INTO `countries` VALUES (130, 'MK', 'Macedonia');
INSERT INTO `countries` VALUES (131, 'MG', 'Madagascar');
INSERT INTO `countries` VALUES (132, 'MW', 'Malawi');
INSERT INTO `countries` VALUES (133, 'MY', 'Malaysia');
INSERT INTO `countries` VALUES (134, 'MV', 'Maldives');
INSERT INTO `countries` VALUES (135, 'ML', 'Mali');
INSERT INTO `countries` VALUES (136, 'MT', 'Malta');
INSERT INTO `countries` VALUES (137, 'MH', 'Marshall Islands');
INSERT INTO `countries` VALUES (138, 'MQ', 'Martinique');
INSERT INTO `countries` VALUES (139, 'MR', 'Mauritania');
INSERT INTO `countries` VALUES (140, 'MU', 'Mauritius');
INSERT INTO `countries` VALUES (141, 'TY', 'Mayotte');
INSERT INTO `countries` VALUES (142, 'MX', 'Mexico');
INSERT INTO `countries` VALUES (143, 'FM', 'Micronesia, Federate');
INSERT INTO `countries` VALUES (144, 'MD', 'Moldova, Republic of');
INSERT INTO `countries` VALUES (145, 'MC', 'Monaco');
INSERT INTO `countries` VALUES (146, 'MN', 'Mongolia');
INSERT INTO `countries` VALUES (147, 'ME', 'Montenegro');
INSERT INTO `countries` VALUES (148, 'MS', 'Montserrat');
INSERT INTO `countries` VALUES (149, 'MA', 'Morocco');
INSERT INTO `countries` VALUES (150, 'MZ', 'Mozambique');
INSERT INTO `countries` VALUES (151, 'MM', 'Myanmar');
INSERT INTO `countries` VALUES (152, 'NA', 'Namibia');
INSERT INTO `countries` VALUES (153, 'NR', 'Nauru');
INSERT INTO `countries` VALUES (154, 'NP', 'Nepal');
INSERT INTO `countries` VALUES (155, 'NL', 'Netherlands');
INSERT INTO `countries` VALUES (156, 'AN', 'Netherlands Antilles');
INSERT INTO `countries` VALUES (157, 'NC', 'New Caledonia');
INSERT INTO `countries` VALUES (158, 'NZ', 'New Zealand');
INSERT INTO `countries` VALUES (159, 'NI', 'Nicaragua');
INSERT INTO `countries` VALUES (160, 'NE', 'Niger');
INSERT INTO `countries` VALUES (161, 'NG', 'Nigeria');
INSERT INTO `countries` VALUES (162, 'NU', 'Niue');
INSERT INTO `countries` VALUES (163, 'NF', 'Norfolk Island');
INSERT INTO `countries` VALUES (164, 'MP', 'Northern Mariana Isl');
INSERT INTO `countries` VALUES (165, 'NO', 'Norway');
INSERT INTO `countries` VALUES (166, 'OM', 'Oman');
INSERT INTO `countries` VALUES (167, 'PK', 'Pakistan');
INSERT INTO `countries` VALUES (168, 'PW', 'Palau');
INSERT INTO `countries` VALUES (169, 'PS', 'Palestine');
INSERT INTO `countries` VALUES (170, 'PA', 'Panama');
INSERT INTO `countries` VALUES (171, 'PG', 'Papua New Guinea');
INSERT INTO `countries` VALUES (172, 'PY', 'Paraguay');
INSERT INTO `countries` VALUES (173, 'PE', 'Peru');
INSERT INTO `countries` VALUES (174, 'PH', 'Philippines');
INSERT INTO `countries` VALUES (175, 'PN', 'Pitcairn');
INSERT INTO `countries` VALUES (176, 'PL', 'Poland');
INSERT INTO `countries` VALUES (177, 'PT', 'Portugal');
INSERT INTO `countries` VALUES (178, 'PR', 'Puerto Rico');
INSERT INTO `countries` VALUES (179, 'QA', 'Qatar');
INSERT INTO `countries` VALUES (180, 'RE', 'Reunion');
INSERT INTO `countries` VALUES (181, 'RO', 'Romania');
INSERT INTO `countries` VALUES (182, 'RU', 'Russian Federation');
INSERT INTO `countries` VALUES (183, 'RW', 'Rwanda');
INSERT INTO `countries` VALUES (184, 'KN', 'Saint Kitts and Nevi');
INSERT INTO `countries` VALUES (185, 'LC', 'Saint Lucia');
INSERT INTO `countries` VALUES (186, 'VC', 'Saint Vincent and th');
INSERT INTO `countries` VALUES (187, 'WS', 'Samoa');
INSERT INTO `countries` VALUES (188, 'SM', 'San Marino');
INSERT INTO `countries` VALUES (189, 'ST', 'Sao Tome and Princip');
INSERT INTO `countries` VALUES (190, 'SA', 'Saudi Arabia');
INSERT INTO `countries` VALUES (191, 'SN', 'Senegal');
INSERT INTO `countries` VALUES (192, 'RS', 'Serbia');
INSERT INTO `countries` VALUES (193, 'SC', 'Seychelles');
INSERT INTO `countries` VALUES (194, 'SL', 'Sierra Leone');
INSERT INTO `countries` VALUES (195, 'SG', 'Singapore');
INSERT INTO `countries` VALUES (196, 'SK', 'Slovakia');
INSERT INTO `countries` VALUES (197, 'SI', 'Slovenia');
INSERT INTO `countries` VALUES (198, 'SB', 'Solomon Islands');
INSERT INTO `countries` VALUES (199, 'SO', 'Somalia');
INSERT INTO `countries` VALUES (200, 'ZA', 'South Africa');
INSERT INTO `countries` VALUES (201, 'GS', 'South Georgia South ');
INSERT INTO `countries` VALUES (202, 'ES', 'Spain');
INSERT INTO `countries` VALUES (203, 'LK', 'Sri Lanka');
INSERT INTO `countries` VALUES (204, 'SH', 'St. Helena');
INSERT INTO `countries` VALUES (205, 'PM', 'St. Pierre and Mique');
INSERT INTO `countries` VALUES (206, 'SD', 'Sudan');
INSERT INTO `countries` VALUES (207, 'SR', 'Suriname');
INSERT INTO `countries` VALUES (208, 'SJ', 'Svalbard and Jan May');
INSERT INTO `countries` VALUES (209, 'SZ', 'Swaziland');
INSERT INTO `countries` VALUES (210, 'SE', 'Sweden');
INSERT INTO `countries` VALUES (211, 'CH', 'Switzerland');
INSERT INTO `countries` VALUES (212, 'SY', 'Syrian Arab Republic');
INSERT INTO `countries` VALUES (213, 'TW', 'Taiwan');
INSERT INTO `countries` VALUES (214, 'TJ', 'Tajikistan');
INSERT INTO `countries` VALUES (215, 'TZ', 'Tanzania, United Rep');
INSERT INTO `countries` VALUES (216, 'TH', 'Thailand');
INSERT INTO `countries` VALUES (217, 'TG', 'Togo');
INSERT INTO `countries` VALUES (218, 'TK', 'Tokelau');
INSERT INTO `countries` VALUES (219, 'TO', 'Tonga');
INSERT INTO `countries` VALUES (220, 'TT', 'Trinidad and Tobago');
INSERT INTO `countries` VALUES (221, 'TN', 'Tunisia');
INSERT INTO `countries` VALUES (222, 'TR', 'Turkey');
INSERT INTO `countries` VALUES (223, 'TM', 'Turkmenistan');
INSERT INTO `countries` VALUES (224, 'TC', 'Turks and Caicos Isl');
INSERT INTO `countries` VALUES (225, 'TV', 'Tuvalu');
INSERT INTO `countries` VALUES (226, 'UG', 'Uganda');
INSERT INTO `countries` VALUES (227, 'UA', 'Ukraine');
INSERT INTO `countries` VALUES (228, 'AE', 'United Arab Emirates');
INSERT INTO `countries` VALUES (229, 'GB', 'United Kingdom');
INSERT INTO `countries` VALUES (230, 'US', 'United States');
INSERT INTO `countries` VALUES (231, 'UM', 'United States minor ');
INSERT INTO `countries` VALUES (232, 'UY', 'Uruguay');
INSERT INTO `countries` VALUES (233, 'UZ', 'Uzbekistan');
INSERT INTO `countries` VALUES (234, 'VU', 'Vanuatu');
INSERT INTO `countries` VALUES (235, 'VA', 'Vatican City State');
INSERT INTO `countries` VALUES (236, 'VE', 'Venezuela');
INSERT INTO `countries` VALUES (237, 'VN', 'Vietnam');
INSERT INTO `countries` VALUES (238, 'VG', 'Virgin Islands (Brit');
INSERT INTO `countries` VALUES (239, 'VI', 'Virgin Islands (U.S.');
INSERT INTO `countries` VALUES (240, 'WF', 'Wallis and Futuna Is');
INSERT INTO `countries` VALUES (241, 'EH', 'Western Sahara');
INSERT INTO `countries` VALUES (242, 'YE', 'Yemen');
INSERT INTO `countries` VALUES (243, 'ZR', 'Zaire');
INSERT INTO `countries` VALUES (244, 'ZM', 'Zambia');
INSERT INTO `countries` VALUES (245, 'ZW', 'Zimbabwe');

-- ----------------------------
-- Table structure for cron_contact
-- ----------------------------
DROP TABLE IF EXISTS `cron_contact`;
CREATE TABLE `cron_contact`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `urns` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `etat` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `urns`(`urns`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 34 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cron_contact
-- ----------------------------
INSERT INTO `cron_contact` VALUES (1, '', '221303000072', 0);
INSERT INTO `cron_contact` VALUES (2, '', '221339515644', 0);
INSERT INTO `cron_contact` VALUES (3, '', '221302001471', 0);
INSERT INTO `cron_contact` VALUES (4, '', '221335957524', 0);
INSERT INTO `cron_contact` VALUES (5, '', '221304097246', 0);
INSERT INTO `cron_contact` VALUES (6, '', '221334933667', 0);
INSERT INTO `cron_contact` VALUES (7, '', '221300926957', 0);
INSERT INTO `cron_contact` VALUES (8, '', '221332915959', 0);
INSERT INTO `cron_contact` VALUES (9, '', '221309604746', 0);
INSERT INTO `cron_contact` VALUES (10, '', '221334226800', 0);
INSERT INTO `cron_contact` VALUES (11, '', '221301730094', 0);
INSERT INTO `cron_contact` VALUES (12, '', '221331796004', 0);
INSERT INTO `cron_contact` VALUES (13, '', '221303029857', 0);
INSERT INTO `cron_contact` VALUES (14, '', '221334607261', 0);
INSERT INTO `cron_contact` VALUES (15, '', '221304763324', 0);
INSERT INTO `cron_contact` VALUES (16, '', '221332430547', 0);
INSERT INTO `cron_contact` VALUES (17, '', '221308865257', 0);
INSERT INTO `cron_contact` VALUES (18, '', '221332216917', 0);
INSERT INTO `cron_contact` VALUES (19, '', '221301578756', 0);
INSERT INTO `cron_contact` VALUES (20, '', '221332726900', 0);
INSERT INTO `cron_contact` VALUES (21, '', '221307306675', 0);
INSERT INTO `cron_contact` VALUES (22, '', '221335027144', 0);
INSERT INTO `cron_contact` VALUES (23, '', '221307185721', 0);
INSERT INTO `cron_contact` VALUES (24, '', '221339289336', 0);
INSERT INTO `cron_contact` VALUES (25, '', '221302814175', 0);
INSERT INTO `cron_contact` VALUES (26, '', '221332279657', 0);
INSERT INTO `cron_contact` VALUES (27, '', '221306619007', 0);
INSERT INTO `cron_contact` VALUES (28, '', '221337480966', 0);
INSERT INTO `cron_contact` VALUES (29, '', '221308206662', 0);
INSERT INTO `cron_contact` VALUES (30, '', '221336685765', 0);
INSERT INTO `cron_contact` VALUES (31, 'test 1', '221778956541', 0);
INSERT INTO `cron_contact` VALUES (32, 'test 2', '221776598745', 0);

-- ----------------------------
-- Table structure for cron_mail
-- ----------------------------
DROP TABLE IF EXISTS `cron_mail`;
CREATE TABLE `cron_mail`  (
  `id` int(11) NOT NULL,
  `mail` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `token` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `uuid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `upload_count` int(11) NULL DEFAULT 0,
  `etat` int(11) NULL DEFAULT 0
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cron_mail
-- ----------------------------
INSERT INTO `cron_mail` VALUES (2, 'yulia.sukhoruchko@gmail.com', 'e22c7ff2d8f46a62c3ee45c6102de74740717ee0', '064e9916-3ea0-45aa-94ec-e8f38bcbb233', 0, 1);

-- ----------------------------
-- Table structure for email_configs
-- ----------------------------
DROP TABLE IF EXISTS `email_configs`;
CREATE TABLE `email_configs`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email_protocol` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_encryption` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `smtp_host` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `smtp_port` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `smtp_email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `smtp_username` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `smtp_password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of email_configs
-- ----------------------------
INSERT INTO `email_configs` VALUES (1, 'smtp', 'tls', 'smtp.gmail.com', '587', 'quantiklab@gmail.com', 'quantiklab@gmail.com', 'kvpxpmbpoxdkkkjl', 'quantiklab@gmail.com', 'quantiklab@gmail.com', NULL, '2018-04-25 17:16:56');

-- ----------------------------
-- Table structure for email_temp_details
-- ----------------------------
DROP TABLE IF EXISTS `email_temp_details`;
CREATE TABLE `email_temp_details`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `temp_id` tinyint(4) NOT NULL,
  `subject` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 44 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of email_temp_details
-- ----------------------------
INSERT INTO `email_temp_details` VALUES (1, 2, 'Your Quotation # {order_reference_no} from {company_name} has been shipped', 'Hi {customer_name},<br><br>Thank you for your Quotation. Here’s a brief overview of your shipment:<br>Quotation # {order_reference_no} was packed on {packed_date} and shipped on {delivery_date}.<br> <br><b>Shipping address   </b><br><br>{shipping_street}<br>{shipping_city}<br>{shipping_state}<br>{shipping_zip_code}<br>{shipping_country}<br><br><b>Item Summery</b><br>{item_information}<br> <br>If you have any questions, please feel free to reply to this email.<br><br>Regards<br>{company_name}<br><br><br>', NULL, NULL);
INSERT INTO `email_temp_details` VALUES (9, 1, 'Payment information for Invoice #{invoice_reference_no}.', '<p>Hi {customer_name},</p><p>Thank you for purchase our product and pay for this.</p><p>We just want to confirm a few details about payment information:</p><p><b>Payment Summary<br></b></p><p><b></b><i>Payment No : {payment_id}</i></p><p><i>Payment Date : {payment_date}&nbsp;</i></p><p><i>Payment Method : {payment_method} <br></i></p><p><i><b>Total Amount : ${total_amount}</b></i></p><p><i></i></p><p><i>Invoice No : {invoice_reference_no}</i><br></p><p><br></p><p>Regards,</p><p>{company_name}<br></p><br><br><br><br><br><br>', NULL, '2019-02-28 13:13:39');
INSERT INTO `email_temp_details` VALUES (17, 3, 'Payment information for Quotation#{order_reference_no} and Invoice#{invoice_reference_no}.', '<p>Hi {customer_name},</p><p>Thank you for purchase our product and pay for this.</p><p>We just want to confirm a few details about payment information:</p><p><b>Customer Information</b></p><p>{billing_street}</p><p>{billing_city}</p><p>{billing_state}</p><p>{billing_zip_code}<br></p><p>{billing_country}<br>&nbsp; &nbsp; &nbsp; &nbsp; <br></p><p><b>Payment Summary<br></b></p><p><b></b><i>Payment No : {payment_id}</i></p><p><i>Payment Date : {payment_date}&nbsp;</i></p><p><i>Payment Method : {payment_method} <br></i></p><p><i><b>Total Amount : {total_amount}</b><br>Quotation No : {order_reference_no}<br>&nbsp;</i><i>Invoice No : {invoice_reference_no}<br>&nbsp;</i>Regards,</p><p>{company_name} <br></p><br>', NULL, NULL);
INSERT INTO `email_temp_details` VALUES (25, 4, 'Your Invoice # {invoice_reference_no} for Quotation #{order_reference_no} from {company_name} has been created.', '<p>Hi {customer_name},</p><p>Thank you for your order. Here’s a brief overview of your invoice: Invoice #{invoice_reference_no} is for Quotation #{order_reference_no}. The invoice total is {currency}{total_amount}, please pay before {due_date}.</p><p>If you have any questions, please feel free to reply to this email. </p><p><b>Billing address</b></p><p>&nbsp;{billing_street}</p><p>&nbsp;{billing_city}</p><p>&nbsp;{billing_state}</p><p>&nbsp;{billing_zip_code}</p><p>&nbsp;{billing_country}</p><p><br></p><p><b>Regards,</b></p><p>{company_name}<br></p><br><br>', NULL, '2019-02-28 13:14:10');
INSERT INTO `email_temp_details` VALUES (33, 5, 'Your Quotation # {order_reference_no} from {company_name} has been shipped', '<p>Hi {customer_name},</p><p>Thank you for your order. Here’s a brief overview of your Quotation #{order_reference_no} that was created on {order_date}. The order total is {currency}{total_amount}.</p><p>If you have any questions, please feel free to reply to this email. </p><p><b>Billing address</b></p><p>&nbsp;{billing_street}</p><p>&nbsp;{billing_city}</p><p>&nbsp;{billing_state}</p><p>&nbsp;{billing_zip_code}</p><p>&nbsp;{billing_country}<br></p><p><br></p><p><br></p><p>Regards,</p><p>{company_name}</p><br><br>', NULL, '2019-02-28 13:16:41');
INSERT INTO `email_temp_details` VALUES (41, 6, 'Your Quotation # {order_reference_no} from {company_name} has been packed', 'Hi {customer_name},<br><br>Thank you for your order. Here’s a brief overview of your shipment:<br>Quotation # {order_reference_no} was packed on {packed_date}.<br> <br><b>Shipping address   </b><br><br>{shipping_street}<br>{shipping_city}<br>{shipping_state}<br>{shipping_zip_code}<br>{shipping_country}<br><br><b>Item Summery</b><br>{item_information}<br> <br>If you have any questions, please feel free to reply to this email.<br><br>Regards<br>{company_name}<br><br><br>', NULL, NULL);
INSERT INTO `email_temp_details` VALUES (43, 7, 'Welcome to  {company_name}', '<p>Hi {member_name},</p><p><span class=\"il\" style=\"color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small;\">Welcome</span><span style=\"color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small;\">&nbsp;to&nbsp;</span><font color=\"#222222\" face=\"Arial, Helvetica, sans-serif\" size=\"2\">{company_name}</font></p><p style=\"color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small;\">Here\'s your login details. You can change your password anytime.</p><p style=\"color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small;\">Email: {email}<br>Password: {password}</p><p style=\"\"><font color=\"#222222\" face=\"Arial, Helvetica, sans-serif\" size=\"2\">{login_url}</font><br></p><p style=\"\"><span style=\"color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small;\"><br></span></p><p>Regards,</p><p><span style=\"color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small;\">{company_name}</span><br></p><div><br></div><p style=\"\"><span style=\"color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small;\"><br></span></p><div><br></div><p><br></p>', NULL, '2019-02-25 13:40:39');

-- ----------------------------
-- Table structure for employees
-- ----------------------------
DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `employee_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EMP-001',
  `date_of_birth` date NULL DEFAULT NULL,
  `father_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `mother_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `date_of_joining` date NULL DEFAULT NULL,
  `date_of_leaving` date NULL DEFAULT NULL,
  `contact_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `alternate_contact_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `alternate_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `present_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `permanent_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `facebook_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `twitter_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `blogger_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `linkedin_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `googleplus_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `employees_user_id_foreign`(`user_id`) USING BTREE,
  CONSTRAINT `employees_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of employees
-- ----------------------------
INSERT INTO `employees` VALUES (5, 40, 'EMP-001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-02 14:20:37', '2019-03-02 14:20:37');
INSERT INTO `employees` VALUES (6, 41, 'EMP-001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-04 04:10:49', '2019-03-04 04:10:49');
INSERT INTO `employees` VALUES (7, 42, 'EMP-001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-04 04:11:46', '2019-03-04 04:11:46');
INSERT INTO `employees` VALUES (8, 43, 'EMP-001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-04 04:12:45', '2019-03-04 04:12:45');
INSERT INTO `employees` VALUES (9, 44, 'EMP-001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-04 04:16:50', '2019-03-04 04:16:50');
INSERT INTO `employees` VALUES (11, 46, 'EMP-001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-04 14:42:57', '2019-03-04 14:42:57');

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 72 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES (1, '2014_10_12_000000_create_users_table', 1);
INSERT INTO `migrations` VALUES (2, '2014_10_12_100000_create_password_resets_table', 1);
INSERT INTO `migrations` VALUES (3, '2018_02_12_180538_create_categories_table', 1);
INSERT INTO `migrations` VALUES (4, '2018_02_12_180556_create_warehouses_table', 1);
INSERT INTO `migrations` VALUES (5, '2018_02_12_180623_create_products_table', 1);
INSERT INTO `migrations` VALUES (6, '2018_02_16_195235_create_countries_table', 1);
INSERT INTO `migrations` VALUES (7, '2018_02_16_196237_create_suppliers_table', 1);
INSERT INTO `migrations` VALUES (8, '2018_02_17_173834_create_groups_table', 1);
INSERT INTO `migrations` VALUES (9, '2018_02_17_174311_create_customers_table', 1);
INSERT INTO `migrations` VALUES (10, '2018_02_18_100711_create_accounts_table', 1);
INSERT INTO `migrations` VALUES (11, '2018_02_19_101936_create_transaction_categories_table', 1);
INSERT INTO `migrations` VALUES (12, '2018_02_19_200531_create_transactions_table', 1);
INSERT INTO `migrations` VALUES (13, '2018_02_25_115821_create_application_settings_table', 1);
INSERT INTO `migrations` VALUES (14, '2018_03_03_104243_create_events_table', 1);
INSERT INTO `migrations` VALUES (15, '2018_03_10_192462_create_projects_table', 1);
INSERT INTO `migrations` VALUES (16, '2018_03_11_192461_create_tasks_table', 1);
INSERT INTO `migrations` VALUES (17, '2018_03_12_172834_create_notes_table', 1);
INSERT INTO `migrations` VALUES (18, '2018_03_14_174320_create_project_comments_table', 1);
INSERT INTO `migrations` VALUES (19, '2018_03_14_211422_create_project_attachments_table', 1);
INSERT INTO `migrations` VALUES (20, '2018_03_20_102806_create_tickets_table', 1);
INSERT INTO `migrations` VALUES (21, '2018_03_20_102849_create_ticket_notes_table', 1);
INSERT INTO `migrations` VALUES (22, '2018_03_20_102934_create_ticket_comments_table', 1);
INSERT INTO `migrations` VALUES (23, '2018_03_21_101022_create_assigned_projects_table', 1);
INSERT INTO `migrations` VALUES (24, '2018_03_21_101058_create_assigned_tasks_table', 1);
INSERT INTO `migrations` VALUES (25, '2018_03_21_101334_create_assigned_tickets_table', 1);
INSERT INTO `migrations` VALUES (26, '2018_03_22_104256_create_employees_table', 1);
INSERT INTO `migrations` VALUES (27, '2018_03_22_213514_create_activity_log_table', 1);
INSERT INTO `migrations` VALUES (28, '2018_03_26_201511_create_invoices_table', 1);
INSERT INTO `migrations` VALUES (29, '2018_03_20_102807_create_tickets_table', 2);
INSERT INTO `migrations` VALUES (30, '2018_03_20_102808_create_tickets_table', 3);
INSERT INTO `migrations` VALUES (31, '2018_03_20_102809_create_tickets_table', 4);
INSERT INTO `migrations` VALUES (32, '2018_03_20_102810_create_tickets_table', 5);
INSERT INTO `migrations` VALUES (33, '2018_03_20_102811_create_tickets_table', 6);
INSERT INTO `migrations` VALUES (34, '2018_03_14_174321_create_project_comments_table', 7);
INSERT INTO `migrations` VALUES (35, '2018_03_14_211423_create_project_attachments_table', 7);
INSERT INTO `migrations` VALUES (36, '2018_02_16_196238_create_suppliers_table', 8);
INSERT INTO `migrations` VALUES (37, '2018_02_16_196239_create_suppliers_table', 9);
INSERT INTO `migrations` VALUES (38, '2018_03_14_174322_create_project_comments_table', 10);
INSERT INTO `migrations` VALUES (39, '2018_03_28_185512_create_color_themes_table', 11);
INSERT INTO `migrations` VALUES (40, '2018_03_30_202231_create_messages_table', 12);
INSERT INTO `migrations` VALUES (41, '2018_04_15_175719_create_invoice_payment_terms_table', 13);
INSERT INTO `migrations` VALUES (42, '2018_04_15_200723_create_backups_table', 14);
INSERT INTO `migrations` VALUES (43, '2018_04_16_053955_create_email_configs_table', 15);
INSERT INTO `migrations` VALUES (44, '2018_04_16_103759_create_item_tax_types_table', 16);
INSERT INTO `migrations` VALUES (45, '2018_04_18_161437_create_email_temp_details_table', 17);
INSERT INTO `migrations` VALUES (46, '2018_04_25_082514_create_payment_terms_table', 18);
INSERT INTO `migrations` VALUES (47, '2018_04_28_101712_create_sales_order_details_table', 19);
INSERT INTO `migrations` VALUES (48, '2018_05_17_101446_create_sales_orders_table', 20);
INSERT INTO `migrations` VALUES (54, '2018_06_01_154134_create_sales_invoices_table', 21);
INSERT INTO `migrations` VALUES (55, '2018_06_01_154331_create_sales_invoice_details_table', 21);
INSERT INTO `migrations` VALUES (56, '2018_06_09_184905_create_quotes_table', 22);
INSERT INTO `migrations` VALUES (57, '2018_06_09_185013_create_quote_details_table', 22);
INSERT INTO `migrations` VALUES (60, '2018_06_22_180905_create_purchase_invoices_table', 23);
INSERT INTO `migrations` VALUES (61, '2018_06_22_181046_create_purchase_invoice_details_table', 23);
INSERT INTO `migrations` VALUES (63, '2018_07_04_162333_create_payments_table', 24);
INSERT INTO `migrations` VALUES (64, '2018_11_12_171322_create_expenses_table', 25);
INSERT INTO `migrations` VALUES (65, '2018_12_21_160113_create_invoice_items_table', 26);
INSERT INTO `migrations` VALUES (66, '2018_12_27_170111_create_bank_trans_table', 27);
INSERT INTO `migrations` VALUES (67, '2018_12_28_192639_create_preferences_table', 28);
INSERT INTO `migrations` VALUES (68, '2018_02_06_060434_entrust_setup_tables', 29);
INSERT INTO `migrations` VALUES (69, '2019_01_10_165030_create_bank_account_types_table', 30);
INSERT INTO `migrations` VALUES (70, '2019_01_10_191737_create_permission_tables', 31);
INSERT INTO `migrations` VALUES (71, '2019_01_14_194437_create_months_table', 32);

-- ----------------------------
-- Table structure for model_has_permissions
-- ----------------------------
DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE `model_has_permissions`  (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`, `model_id`, `model_type`) USING BTREE,
  INDEX `model_has_permissions_model_id_model_type_index`(`model_id`, `model_type`) USING BTREE,
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for model_has_roles
-- ----------------------------
DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE `model_has_roles`  (
  `role_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`role_id`, `model_id`, `model_type`) USING BTREE,
  INDEX `model_has_roles_model_id_model_type_index`(`model_id`, `model_type`) USING BTREE,
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of model_has_roles
-- ----------------------------
INSERT INTO `model_has_roles` VALUES (4, 'App\\User', 1);
INSERT INTO `model_has_roles` VALUES (4, 'App\\User', 36);
INSERT INTO `model_has_roles` VALUES (5, 'App\\User', 16);
INSERT INTO `model_has_roles` VALUES (5, 'App\\User', 17);
INSERT INTO `model_has_roles` VALUES (5, 'App\\User', 46);
INSERT INTO `model_has_roles` VALUES (6, 'App\\User', 41);
INSERT INTO `model_has_roles` VALUES (7, 'App\\User', 33);
INSERT INTO `model_has_roles` VALUES (7, 'App\\User', 42);
INSERT INTO `model_has_roles` VALUES (8, 'App\\User', 20);
INSERT INTO `model_has_roles` VALUES (8, 'App\\User', 24);
INSERT INTO `model_has_roles` VALUES (8, 'App\\User', 43);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 5);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 15);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 19);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 25);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 26);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 27);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 30);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 32);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 34);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 38);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 39);
INSERT INTO `model_has_roles` VALUES (9, 'App\\User', 44);
INSERT INTO `model_has_roles` VALUES (10, 'App\\User', 15);
INSERT INTO `model_has_roles` VALUES (10, 'App\\User', 23);
INSERT INTO `model_has_roles` VALUES (10, 'App\\User', 28);
INSERT INTO `model_has_roles` VALUES (10, 'App\\User', 29);
INSERT INTO `model_has_roles` VALUES (10, 'App\\User', 35);
INSERT INTO `model_has_roles` VALUES (10, 'App\\User', 37);
INSERT INTO `model_has_roles` VALUES (11, 'App\\User', 31);
INSERT INTO `model_has_roles` VALUES (11, 'App\\User', 40);
INSERT INTO `model_has_roles` VALUES (11, 'App\\User', 45);

-- ----------------------------
-- Table structure for months
-- ----------------------------
DROP TABLE IF EXISTS `months`;
CREATE TABLE `months`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of months
-- ----------------------------
INSERT INTO `months` VALUES (1, 'January');
INSERT INTO `months` VALUES (2, 'February');
INSERT INTO `months` VALUES (3, 'March');
INSERT INTO `months` VALUES (4, 'April');
INSERT INTO `months` VALUES (5, 'May');
INSERT INTO `months` VALUES (6, 'June');
INSERT INTO `months` VALUES (7, 'July');
INSERT INTO `months` VALUES (8, 'August');
INSERT INTO `months` VALUES (9, 'September');
INSERT INTO `months` VALUES (10, 'October');
INSERT INTO `months` VALUES (11, 'November');
INSERT INTO `months` VALUES (12, 'December');

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets`  (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `password_resets_email_index`(`email`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for permissions
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 110 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of permissions
-- ----------------------------
INSERT INTO `permissions` VALUES (8, 'create_sales_invoice', 'web', '2019-01-30 13:21:47', '2019-01-30 13:21:47');
INSERT INTO `permissions` VALUES (9, 'view_sales_invoice', 'web', '2019-01-30 13:21:47', '2019-01-30 13:21:47');
INSERT INTO `permissions` VALUES (10, 'edit_sales_invoice', 'web', '2019-01-30 13:21:47', '2019-01-30 13:21:47');
INSERT INTO `permissions` VALUES (11, 'delete_sales_invoice', 'web', '2019-01-30 13:21:47', '2019-01-30 13:21:47');
INSERT INTO `permissions` VALUES (12, 'create_quote', 'web', '2019-01-30 13:21:47', '2019-01-30 13:21:47');
INSERT INTO `permissions` VALUES (13, 'view_quote', 'web', '2019-01-30 13:21:47', '2019-01-30 13:21:47');
INSERT INTO `permissions` VALUES (14, 'edit_quote', 'web', '2019-01-30 13:21:47', '2019-01-30 13:21:47');
INSERT INTO `permissions` VALUES (15, 'delete_quote', 'web', '2019-01-30 13:21:47', '2019-01-30 13:21:47');
INSERT INTO `permissions` VALUES (16, 'convert_quote_to_invoice', 'web', '2019-01-30 13:21:47', '2019-01-30 13:21:47');
INSERT INTO `permissions` VALUES (17, 'manage_payment', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (18, 'create_product', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (19, 'view_product', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (20, 'edit_product', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (21, 'delete_product', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (22, 'create_category', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (23, 'edit_category', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (24, 'delete_category', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (25, 'create_warehouse', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (26, 'edit_warehouse', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (27, 'delete_warehouse', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (28, 'create_purchase_order', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (29, 'view_purchase_order', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (30, 'edit_purchase_order', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (31, 'delete_purchase_order', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (32, 'create_customer', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (33, 'view_customer', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (34, 'edit_customer', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (35, 'delete_customer', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (36, 'create_ticket', 'web', '2019-01-30 13:21:48', '2019-01-30 13:21:48');
INSERT INTO `permissions` VALUES (37, 'view_ticket', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (38, 'edit_ticket', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (39, 'delete_ticket', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (40, 'manage_answered_tickets', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (41, 'create_supplier', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (42, 'view_supplier', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (43, 'edit_supplier', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (44, 'delete_supplier', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (45, 'create_employee', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (46, 'view_employee', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (47, 'edit_employee', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (48, 'delete_employee', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (49, 'create_project', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (50, 'manage_project_room', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (51, 'edit_project', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (52, 'delete_project', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (53, 'create_project_invoice', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (54, 'view_project_invoice', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (55, 'edit_project_invoice', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (56, 'delete_project_invoice', 'web', '2019-01-30 13:21:49', '2019-01-30 13:21:49');
INSERT INTO `permissions` VALUES (57, 'download_pdf_project_invoice', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (58, 'create_task', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (59, 'view_task', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (60, 'edit_task', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (61, 'delete_task', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (62, 'create_account', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (63, 'view_account', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (64, 'edit_account', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (65, 'delete_account', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (66, 'manage_balance_sheet', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (67, 'manage_account_statement', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (68, 'create_transaction', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (69, 'view_transaction', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (70, 'delete_transaction', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (71, 'manage_transfer', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (72, 'create_income', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (73, 'view_income', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (74, 'delete_income', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (75, 'create_expense', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (76, 'view_expense', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (77, 'delete_expense', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (78, 'report_inventory_stock_on_hand', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (79, 'report_sales_report', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (80, 'report_purchase_report', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (81, 'report_expense_report', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (82, 'report_income_report', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (83, 'report_income_vs_expense', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (84, 'create_note', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (85, 'edit_note', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (86, 'delete_note', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (87, 'manage_event', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (88, 'manage_message', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (89, 'application_setting', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (90, 'email_template_setting', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (91, 'manage_income_expense_category', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (92, 'manage_role_permission', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (93, 'create_payment_terms', 'web', '2019-01-30 13:21:50', '2019-01-30 13:21:50');
INSERT INTO `permissions` VALUES (94, 'edit_payment_terms', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (95, 'delete_payment_terms', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (96, 'create_tax', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (97, 'edit_tax', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (98, 'delete_tax', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (99, 'create_payment_method', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (100, 'edit_payment_method', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (101, 'delete_payment_method', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (102, 'create_bank_account', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (103, 'edit_bank_account', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (104, 'delete_bank_account', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (105, 'export_people_data', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (106, 'export_transactions', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (107, 'export_products', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (108, 'manage_database_backup', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `permissions` VALUES (109, 'view_user_log', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');

-- ----------------------------
-- Table structure for preferences
-- ----------------------------
DROP TABLE IF EXISTS `preferences`;
CREATE TABLE `preferences`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `category` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of preferences
-- ----------------------------
INSERT INTO `preferences` VALUES (1, 'preference', 'row_per_page', '25');
INSERT INTO `preferences` VALUES (2, 'preference', 'date_format', '1');
INSERT INTO `preferences` VALUES (3, 'preference', 'date_sepa', '.');
INSERT INTO `preferences` VALUES (4, 'preference', 'date_format_type', 'dd.mm.yyyy');

-- ----------------------------
-- Table structure for role_has_permissions
-- ----------------------------
DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE `role_has_permissions`  (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`, `role_id`) USING BTREE,
  INDEX `role_has_permissions_role_id_foreign`(`role_id`) USING BTREE,
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role_has_permissions
-- ----------------------------
INSERT INTO `role_has_permissions` VALUES (8, 4);
INSERT INTO `role_has_permissions` VALUES (8, 5);
INSERT INTO `role_has_permissions` VALUES (8, 6);
INSERT INTO `role_has_permissions` VALUES (8, 7);
INSERT INTO `role_has_permissions` VALUES (9, 4);
INSERT INTO `role_has_permissions` VALUES (9, 5);
INSERT INTO `role_has_permissions` VALUES (9, 6);
INSERT INTO `role_has_permissions` VALUES (9, 7);
INSERT INTO `role_has_permissions` VALUES (9, 10);
INSERT INTO `role_has_permissions` VALUES (10, 4);
INSERT INTO `role_has_permissions` VALUES (10, 5);
INSERT INTO `role_has_permissions` VALUES (10, 6);
INSERT INTO `role_has_permissions` VALUES (10, 7);
INSERT INTO `role_has_permissions` VALUES (11, 4);
INSERT INTO `role_has_permissions` VALUES (11, 5);
INSERT INTO `role_has_permissions` VALUES (11, 6);
INSERT INTO `role_has_permissions` VALUES (11, 7);
INSERT INTO `role_has_permissions` VALUES (12, 4);
INSERT INTO `role_has_permissions` VALUES (12, 5);
INSERT INTO `role_has_permissions` VALUES (12, 6);
INSERT INTO `role_has_permissions` VALUES (12, 7);
INSERT INTO `role_has_permissions` VALUES (13, 4);
INSERT INTO `role_has_permissions` VALUES (13, 5);
INSERT INTO `role_has_permissions` VALUES (13, 6);
INSERT INTO `role_has_permissions` VALUES (13, 7);
INSERT INTO `role_has_permissions` VALUES (13, 10);
INSERT INTO `role_has_permissions` VALUES (14, 4);
INSERT INTO `role_has_permissions` VALUES (14, 5);
INSERT INTO `role_has_permissions` VALUES (14, 6);
INSERT INTO `role_has_permissions` VALUES (14, 7);
INSERT INTO `role_has_permissions` VALUES (15, 4);
INSERT INTO `role_has_permissions` VALUES (15, 5);
INSERT INTO `role_has_permissions` VALUES (15, 6);
INSERT INTO `role_has_permissions` VALUES (15, 7);
INSERT INTO `role_has_permissions` VALUES (16, 4);
INSERT INTO `role_has_permissions` VALUES (16, 5);
INSERT INTO `role_has_permissions` VALUES (16, 6);
INSERT INTO `role_has_permissions` VALUES (16, 7);
INSERT INTO `role_has_permissions` VALUES (17, 4);
INSERT INTO `role_has_permissions` VALUES (17, 5);
INSERT INTO `role_has_permissions` VALUES (17, 6);
INSERT INTO `role_has_permissions` VALUES (17, 7);
INSERT INTO `role_has_permissions` VALUES (18, 4);
INSERT INTO `role_has_permissions` VALUES (18, 5);
INSERT INTO `role_has_permissions` VALUES (18, 6);
INSERT INTO `role_has_permissions` VALUES (18, 9);
INSERT INTO `role_has_permissions` VALUES (19, 4);
INSERT INTO `role_has_permissions` VALUES (19, 5);
INSERT INTO `role_has_permissions` VALUES (19, 6);
INSERT INTO `role_has_permissions` VALUES (19, 9);
INSERT INTO `role_has_permissions` VALUES (20, 4);
INSERT INTO `role_has_permissions` VALUES (20, 5);
INSERT INTO `role_has_permissions` VALUES (20, 6);
INSERT INTO `role_has_permissions` VALUES (20, 9);
INSERT INTO `role_has_permissions` VALUES (21, 4);
INSERT INTO `role_has_permissions` VALUES (21, 5);
INSERT INTO `role_has_permissions` VALUES (21, 6);
INSERT INTO `role_has_permissions` VALUES (21, 9);
INSERT INTO `role_has_permissions` VALUES (22, 4);
INSERT INTO `role_has_permissions` VALUES (22, 5);
INSERT INTO `role_has_permissions` VALUES (22, 6);
INSERT INTO `role_has_permissions` VALUES (22, 9);
INSERT INTO `role_has_permissions` VALUES (23, 4);
INSERT INTO `role_has_permissions` VALUES (23, 5);
INSERT INTO `role_has_permissions` VALUES (23, 6);
INSERT INTO `role_has_permissions` VALUES (23, 9);
INSERT INTO `role_has_permissions` VALUES (24, 4);
INSERT INTO `role_has_permissions` VALUES (24, 5);
INSERT INTO `role_has_permissions` VALUES (24, 6);
INSERT INTO `role_has_permissions` VALUES (24, 9);
INSERT INTO `role_has_permissions` VALUES (25, 4);
INSERT INTO `role_has_permissions` VALUES (25, 5);
INSERT INTO `role_has_permissions` VALUES (25, 6);
INSERT INTO `role_has_permissions` VALUES (25, 9);
INSERT INTO `role_has_permissions` VALUES (26, 4);
INSERT INTO `role_has_permissions` VALUES (26, 5);
INSERT INTO `role_has_permissions` VALUES (26, 6);
INSERT INTO `role_has_permissions` VALUES (26, 9);
INSERT INTO `role_has_permissions` VALUES (27, 4);
INSERT INTO `role_has_permissions` VALUES (27, 5);
INSERT INTO `role_has_permissions` VALUES (27, 6);
INSERT INTO `role_has_permissions` VALUES (27, 9);
INSERT INTO `role_has_permissions` VALUES (28, 4);
INSERT INTO `role_has_permissions` VALUES (28, 5);
INSERT INTO `role_has_permissions` VALUES (28, 6);
INSERT INTO `role_has_permissions` VALUES (28, 9);
INSERT INTO `role_has_permissions` VALUES (29, 4);
INSERT INTO `role_has_permissions` VALUES (29, 5);
INSERT INTO `role_has_permissions` VALUES (29, 6);
INSERT INTO `role_has_permissions` VALUES (29, 9);
INSERT INTO `role_has_permissions` VALUES (30, 4);
INSERT INTO `role_has_permissions` VALUES (30, 5);
INSERT INTO `role_has_permissions` VALUES (30, 6);
INSERT INTO `role_has_permissions` VALUES (30, 9);
INSERT INTO `role_has_permissions` VALUES (31, 4);
INSERT INTO `role_has_permissions` VALUES (31, 5);
INSERT INTO `role_has_permissions` VALUES (31, 6);
INSERT INTO `role_has_permissions` VALUES (31, 9);
INSERT INTO `role_has_permissions` VALUES (32, 4);
INSERT INTO `role_has_permissions` VALUES (32, 5);
INSERT INTO `role_has_permissions` VALUES (32, 6);
INSERT INTO `role_has_permissions` VALUES (33, 4);
INSERT INTO `role_has_permissions` VALUES (33, 5);
INSERT INTO `role_has_permissions` VALUES (33, 6);
INSERT INTO `role_has_permissions` VALUES (34, 4);
INSERT INTO `role_has_permissions` VALUES (34, 5);
INSERT INTO `role_has_permissions` VALUES (34, 6);
INSERT INTO `role_has_permissions` VALUES (35, 4);
INSERT INTO `role_has_permissions` VALUES (35, 5);
INSERT INTO `role_has_permissions` VALUES (35, 6);
INSERT INTO `role_has_permissions` VALUES (36, 4);
INSERT INTO `role_has_permissions` VALUES (36, 5);
INSERT INTO `role_has_permissions` VALUES (36, 6);
INSERT INTO `role_has_permissions` VALUES (37, 4);
INSERT INTO `role_has_permissions` VALUES (37, 5);
INSERT INTO `role_has_permissions` VALUES (37, 6);
INSERT INTO `role_has_permissions` VALUES (37, 10);
INSERT INTO `role_has_permissions` VALUES (38, 4);
INSERT INTO `role_has_permissions` VALUES (38, 5);
INSERT INTO `role_has_permissions` VALUES (38, 6);
INSERT INTO `role_has_permissions` VALUES (39, 4);
INSERT INTO `role_has_permissions` VALUES (39, 5);
INSERT INTO `role_has_permissions` VALUES (39, 6);
INSERT INTO `role_has_permissions` VALUES (40, 4);
INSERT INTO `role_has_permissions` VALUES (40, 5);
INSERT INTO `role_has_permissions` VALUES (41, 4);
INSERT INTO `role_has_permissions` VALUES (41, 5);
INSERT INTO `role_has_permissions` VALUES (42, 4);
INSERT INTO `role_has_permissions` VALUES (42, 5);
INSERT INTO `role_has_permissions` VALUES (43, 4);
INSERT INTO `role_has_permissions` VALUES (43, 5);
INSERT INTO `role_has_permissions` VALUES (44, 4);
INSERT INTO `role_has_permissions` VALUES (44, 5);
INSERT INTO `role_has_permissions` VALUES (45, 4);
INSERT INTO `role_has_permissions` VALUES (46, 4);
INSERT INTO `role_has_permissions` VALUES (47, 4);
INSERT INTO `role_has_permissions` VALUES (48, 4);
INSERT INTO `role_has_permissions` VALUES (49, 4);
INSERT INTO `role_has_permissions` VALUES (49, 5);
INSERT INTO `role_has_permissions` VALUES (49, 8);
INSERT INTO `role_has_permissions` VALUES (49, 11);
INSERT INTO `role_has_permissions` VALUES (50, 4);
INSERT INTO `role_has_permissions` VALUES (50, 5);
INSERT INTO `role_has_permissions` VALUES (50, 8);
INSERT INTO `role_has_permissions` VALUES (50, 10);
INSERT INTO `role_has_permissions` VALUES (50, 11);
INSERT INTO `role_has_permissions` VALUES (51, 4);
INSERT INTO `role_has_permissions` VALUES (51, 5);
INSERT INTO `role_has_permissions` VALUES (51, 8);
INSERT INTO `role_has_permissions` VALUES (52, 4);
INSERT INTO `role_has_permissions` VALUES (52, 5);
INSERT INTO `role_has_permissions` VALUES (52, 8);
INSERT INTO `role_has_permissions` VALUES (52, 11);
INSERT INTO `role_has_permissions` VALUES (53, 4);
INSERT INTO `role_has_permissions` VALUES (54, 4);
INSERT INTO `role_has_permissions` VALUES (55, 4);
INSERT INTO `role_has_permissions` VALUES (56, 4);
INSERT INTO `role_has_permissions` VALUES (57, 4);
INSERT INTO `role_has_permissions` VALUES (58, 4);
INSERT INTO `role_has_permissions` VALUES (58, 5);
INSERT INTO `role_has_permissions` VALUES (59, 4);
INSERT INTO `role_has_permissions` VALUES (59, 5);
INSERT INTO `role_has_permissions` VALUES (59, 11);
INSERT INTO `role_has_permissions` VALUES (60, 4);
INSERT INTO `role_has_permissions` VALUES (60, 5);
INSERT INTO `role_has_permissions` VALUES (61, 4);
INSERT INTO `role_has_permissions` VALUES (61, 5);
INSERT INTO `role_has_permissions` VALUES (62, 4);
INSERT INTO `role_has_permissions` VALUES (62, 5);
INSERT INTO `role_has_permissions` VALUES (63, 4);
INSERT INTO `role_has_permissions` VALUES (63, 5);
INSERT INTO `role_has_permissions` VALUES (64, 4);
INSERT INTO `role_has_permissions` VALUES (64, 5);
INSERT INTO `role_has_permissions` VALUES (65, 4);
INSERT INTO `role_has_permissions` VALUES (65, 5);
INSERT INTO `role_has_permissions` VALUES (66, 4);
INSERT INTO `role_has_permissions` VALUES (66, 5);
INSERT INTO `role_has_permissions` VALUES (67, 4);
INSERT INTO `role_has_permissions` VALUES (67, 5);
INSERT INTO `role_has_permissions` VALUES (68, 4);
INSERT INTO `role_has_permissions` VALUES (68, 5);
INSERT INTO `role_has_permissions` VALUES (69, 4);
INSERT INTO `role_has_permissions` VALUES (69, 5);
INSERT INTO `role_has_permissions` VALUES (70, 4);
INSERT INTO `role_has_permissions` VALUES (70, 5);
INSERT INTO `role_has_permissions` VALUES (71, 4);
INSERT INTO `role_has_permissions` VALUES (71, 5);
INSERT INTO `role_has_permissions` VALUES (72, 4);
INSERT INTO `role_has_permissions` VALUES (72, 5);
INSERT INTO `role_has_permissions` VALUES (73, 4);
INSERT INTO `role_has_permissions` VALUES (73, 5);
INSERT INTO `role_has_permissions` VALUES (74, 4);
INSERT INTO `role_has_permissions` VALUES (74, 5);
INSERT INTO `role_has_permissions` VALUES (75, 4);
INSERT INTO `role_has_permissions` VALUES (75, 5);
INSERT INTO `role_has_permissions` VALUES (76, 4);
INSERT INTO `role_has_permissions` VALUES (76, 5);
INSERT INTO `role_has_permissions` VALUES (77, 4);
INSERT INTO `role_has_permissions` VALUES (77, 5);
INSERT INTO `role_has_permissions` VALUES (78, 4);
INSERT INTO `role_has_permissions` VALUES (78, 5);
INSERT INTO `role_has_permissions` VALUES (79, 4);
INSERT INTO `role_has_permissions` VALUES (79, 5);
INSERT INTO `role_has_permissions` VALUES (80, 4);
INSERT INTO `role_has_permissions` VALUES (80, 5);
INSERT INTO `role_has_permissions` VALUES (81, 4);
INSERT INTO `role_has_permissions` VALUES (81, 5);
INSERT INTO `role_has_permissions` VALUES (82, 4);
INSERT INTO `role_has_permissions` VALUES (82, 5);
INSERT INTO `role_has_permissions` VALUES (83, 4);
INSERT INTO `role_has_permissions` VALUES (83, 5);
INSERT INTO `role_has_permissions` VALUES (84, 4);
INSERT INTO `role_has_permissions` VALUES (84, 5);
INSERT INTO `role_has_permissions` VALUES (85, 4);
INSERT INTO `role_has_permissions` VALUES (85, 5);
INSERT INTO `role_has_permissions` VALUES (86, 4);
INSERT INTO `role_has_permissions` VALUES (86, 5);
INSERT INTO `role_has_permissions` VALUES (87, 4);
INSERT INTO `role_has_permissions` VALUES (87, 5);
INSERT INTO `role_has_permissions` VALUES (88, 4);
INSERT INTO `role_has_permissions` VALUES (88, 5);
INSERT INTO `role_has_permissions` VALUES (89, 4);
INSERT INTO `role_has_permissions` VALUES (90, 4);
INSERT INTO `role_has_permissions` VALUES (91, 4);
INSERT INTO `role_has_permissions` VALUES (92, 4);
INSERT INTO `role_has_permissions` VALUES (93, 4);
INSERT INTO `role_has_permissions` VALUES (94, 4);
INSERT INTO `role_has_permissions` VALUES (95, 4);
INSERT INTO `role_has_permissions` VALUES (96, 4);
INSERT INTO `role_has_permissions` VALUES (97, 4);
INSERT INTO `role_has_permissions` VALUES (98, 4);
INSERT INTO `role_has_permissions` VALUES (99, 4);
INSERT INTO `role_has_permissions` VALUES (100, 4);
INSERT INTO `role_has_permissions` VALUES (101, 4);
INSERT INTO `role_has_permissions` VALUES (102, 4);
INSERT INTO `role_has_permissions` VALUES (103, 4);
INSERT INTO `role_has_permissions` VALUES (104, 4);
INSERT INTO `role_has_permissions` VALUES (105, 4);
INSERT INTO `role_has_permissions` VALUES (106, 4);
INSERT INTO `role_has_permissions` VALUES (107, 4);
INSERT INTO `role_has_permissions` VALUES (108, 4);
INSERT INTO `role_has_permissions` VALUES (109, 4);

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES (4, 'business_owner', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `roles` VALUES (5, 'business_manager', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `roles` VALUES (6, 'sales_manager', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `roles` VALUES (7, 'sales_person', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `roles` VALUES (8, 'project_manager', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `roles` VALUES (9, 'stock_manager', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `roles` VALUES (10, 'customer', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');
INSERT INTO `roles` VALUES (11, 'project_person', 'web', '2019-01-30 13:21:51', '2019-01-30 13:21:51');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` int(11) NOT NULL DEFAULT 2,
  `profile_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `last_login` timestamp(0) NULL DEFAULT NULL,
  `last_login_ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `last_login_now` timestamp(0) NULL DEFAULT NULL,
  `last_login_ip_now` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `users_username_unique`(`username`) USING BTREE,
  UNIQUE INDEX `users_email_unique`(`email`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 47 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'Quantik', 'Lab', 'qlab', 'admin@gmail.com', '$2y$10$tGRjiamLn/zofZXpQZyAiO87zrikK1JBsZCrHIJWJnM174gXbEe8C', 2, '5b43a35c4c3ee.jpg', '2021-01-01 17:16:58', '41.83.221.223', '2021-01-01 21:42:02', '41.83.221.223', 'fQZp84mRCTsHB7eeiqGxC5n07YmSj5d20uOqSlCMGZCEyqdZT6dpo9RcH4nR', '2018-03-23 05:06:11', '2021-01-01 21:42:02');
INSERT INTO `users` VALUES (37, 'Rakib', 'Uddin', 'rakibuddin101', 'customer@gmail.com', '$2y$10$buxCVyz3.KwK4cqhB1cWUev9b2mDC/1ghY3I8Ul458WlDAN4mNpM6', 0, '5c7ac6d941689.jpg', '2019-03-03 17:00:43', '::1', '2019-03-05 01:29:01', '::1', 'fFcUS165ZahSyGh9FHvoN8eevU1Zolr7KQjDyjgFIqgljr8UZsYZSCqjXsAA', '2019-03-02 14:09:29', '2019-03-05 01:29:01');
INSERT INTO `users` VALUES (39, 'Jon', 'Doe', 'jon123', 'supplier@gmail.com', '$2y$10$WqPft0ftIH.tr1VjQzdpz.ScCE5W0tY5TAOIMzfwSFbrW9tg6c75W', 3, '5c7ac89c13b37.jpg', NULL, NULL, NULL, NULL, NULL, '2019-03-02 14:17:00', '2019-03-02 14:17:00');
INSERT INTO `users` VALUES (40, 'Jane', 'Doe', 'janedoe', 'employee@gmail.com', '$2y$10$f9T3LJ0nrgGbsXAfcWGKE.jSQxZJopziw5yxegDMN3Z4SBlNjd6M6', 1, NULL, '2019-03-04 16:09:42', '::1', '2019-03-04 16:11:14', '::1', 'ghFO3oJW8K4EmNVMiQ4KjGFjGIOCoVCjOxJMsOSF1tbOePdegLRBld41ku1t', '2019-03-02 14:20:37', '2019-03-04 16:11:14');
INSERT INTO `users` VALUES (41, 'David', 'Vore', 'david', 'manager@gmail.com', '$2y$10$snlIJx0m3J3wMvkuhe711ehspZv/DU9XYIdjyjy02RNrscGEZpwsa', 1, NULL, NULL, NULL, '2019-03-04 14:35:09', '::1', 'zdOKeAVhneOy0sopBR0b4j5BXNXQXBkFZGeetqobg8XGqmvvSVfDbvKz9o4M', '2019-03-04 04:10:49', '2019-03-04 15:47:09');
INSERT INTO `users` VALUES (42, 'Salina', 'Lee', 'salina', 'sales@gmail.com', '$2y$10$fME/T4u6YJIib/9hkY1yL.IWsUVZTKMnA.Wc3MHkqGzqnOHKd1IoO', 1, NULL, '2019-03-04 14:15:19', '::1', '2019-03-04 14:37:39', '::1', 'mWDXb9qlnrKaJmcPwXMoEfB4mtSaU2myl8MV9y4ho8c2jnzIjg9RpyPwGxn6', '2019-03-04 04:11:46', '2019-03-04 15:47:25');
INSERT INTO `users` VALUES (43, 'John', 'Doe', 'jdoe', 'project@gmail.com', '$2y$10$1WKTRHmMCcrtTBTRkLuCPeUB8ThgkrHL6O3qeCDbO7JiX6AHXGpu6', 1, NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-04 04:12:45', '2019-03-04 15:45:28');
INSERT INTO `users` VALUES (44, 'Paul', 'Alen', 'paul', 'stock@gmail.com', '$2y$10$4SGw.at.JT93bfRY7XeMtutQro8G0lOC8/.K2peSKzmqhAp5ZbTIK', 1, NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-04 04:16:50', '2019-03-04 15:48:05');
INSERT INTO `users` VALUES (45, 'Project', 'Person', 'project', 'person@gmail.com', '$2y$10$Uv6hFs2QiQj2GrrMZeiDn./Xjz6Axly5FE7.IiqWR1YrAeQbXr5oi', 1, NULL, NULL, NULL, NULL, NULL, NULL, '2019-03-04 04:17:44', '2019-03-04 04:17:44');
INSERT INTO `users` VALUES (46, 'Jason', 'Vore', 'jason', 'businessmanager@gmail.com', '$2y$10$mdZ9ryJHIXtC6hJrq.JQu.lZnpmVI4BLyMOOwIM0VOpYEHJZjLxUS', 1, '5c7d71b0d67bc.jpg', NULL, NULL, '2019-03-04 14:43:19', '::1', '5aS0zC6X5w4JLVeYGJecOhgQ5X4MLeVLc0efAxWLhQCel5ZRYr3AiXwivhhR', '2019-03-04 14:42:56', '2019-03-04 15:46:54');

SET FOREIGN_KEY_CHECKS = 1;
