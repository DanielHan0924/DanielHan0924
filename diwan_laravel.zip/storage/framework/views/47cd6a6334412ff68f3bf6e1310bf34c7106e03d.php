<?php $__env->startSection('content'); ?>

    <div class="login-box animated fadeIn">
        <div class="login-logo">
            <b style="color:#fff;">Bulk Contacts Import</b>
        </div>
        <!-- /.login-logo -->
        <div class="login-box-body">
            <p class="login-box-msg">Reset your password</p>
            <form method="post" action="<?php echo e(URL('send-password-link')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <?php if(Session::has('message')): ?>
                        <div class="successMessage alert alert-<?php echo e(Session::get('message_type')); ?> text-center">
                             <?php echo e(Session::get('message')); ?>

                        </div>
                    <?php endif; ?>

                    <input name="email" id="email" type="email" class="form-control" placeholder="Enter Registered Email" required autofocus>
                </div>

                <div class="row">
                    <div class="col-xs-12">
                        <button type="submit" class="btn btn-primary btn-flat">Send Password Reset Link</button>
                        <a href="<?php echo e(URL('login')); ?>" class="btn btn-success btn-flat pull-right ">Login</a>
                        <div class="clearfix"></div>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.login-master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>