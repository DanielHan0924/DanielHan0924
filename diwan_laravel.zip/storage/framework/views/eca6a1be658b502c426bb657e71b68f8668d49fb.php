<?php $__env->startSection('title'); ?>
    Qbilling  - <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <section class="content animated fadeIn">

           <p style="margin-top:180px;font-size:19px;text-align:center">Traitement soumis avec succés , merci de fermer le navigateur et d'attendre le mail de notification.</p>

			<div class="form-group">
						NOTE:	 Sed quis faucibus velit. Sed ut dolor vitae odio ullamcorper porta. Etiam gravida maximus maximus. Aliquam vel erat massa. Suspendisse in maximus nibh, id faucibus nunc. Morbi quis euismod nulla. Suspendisse potenti. Aliquam erat volutpat.
</div>	
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            /**
             * Front End validation
             */
            $('#create_account').validate({
                rules: {
                    account_number: {
                        required: true
                    },
                    account_holder: {
                        required: true
                    },
                    bank_name: {
                        required: true
                    },
                    bank_address: {
                        required: true
                    },
                    last_balance: {
                        required: true
                    }

                },
                messages: {
                    account_number: {
                        required: "Please put an account number"
                    },
                    account_holder: {
                        required: "Please put an account holder's name"
                    },
                    bank_address: {
                        required: "Put bank address"
                    },
                    bank_name: {
                        required: "Provide bank name"
                    },
                    last_balance: {
                        required: "Give an initial balance"
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>