<?php $__env->startSection('title'); ?>
    DIWAN  - <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content animated fadeIn">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="pull-left">
                        <h3 class="box-title"><?php echo e(strtoupper($title)); ?></h3>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_customer')): ?>
                        <div class="pull-right">
                            <a class="btn btn-primary" href="<?php echo e(url('group/0000/0000')); ?>" style="text-transform:uppercase">Add contacts / new group</a>
                        </div>
                    <?php endif; ?>
                    <div class="clearfix"></div>
                </div>
                <div class="box-body min-height">
                    <div class="row">
                        <div class="col-md-12">
                            <table id="customers" class=" table table-bordered table-striped dataTable"
                                   role="grid" data-form="deleteForm">
                                <thead>
                                <tr role="row">
                                    <th>Uuid</th>
                                    <th>Name</th>
                                    <th>Statut</th>
                                    <th>Count</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
								
								
	
	
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr role="row" class="odd">
                                        <td><?php echo e($group->uuid); ?></td>
                                        <td><?php echo e($group->name); ?></td>
                                        <td><?php echo e($group->status); ?></td>
                                        <td><?php echo e($group->count); ?></td>
                                       
                                        <td>
                                            
                                            <a data-tooltip="tooltip" title="Select this Group"
                                               class="btn btn-default btn-sm"
											   
											  
                                               href=" <?php echo e(url('group/'.$group->uuid.'/'.$group->name)); ?> "><i
                                                        class="fa fa-upload"></i> SELECT GROUP</a>
                                       
 
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
						
                    </div>
					
					<div class="form-group">
							NOTE :  Sed quis faucibus velit. Sed ut dolor vitae odio ullamcorper porta. Etiam gravida maximus maximus. Aliquam vel erat massa. Suspendisse in maximus nibh, id faucibus nunc. Morbi quis euismod nulla. Suspendisse potenti. Aliquam erat volutpat.
</div>
                </div>
            </div>
        </section>
        <?php echo $__env->make('admin.common.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            // Custom code goes here.
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>