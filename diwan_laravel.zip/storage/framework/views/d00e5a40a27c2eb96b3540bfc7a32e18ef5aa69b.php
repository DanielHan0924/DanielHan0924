<?php $__env->startSection('content'); ?>
    <div class="login-box animated fadeIn">
        <div class="login-logo" style="color:#fff;">
            <b>Bulk Contacts Import</b> Authentication
        </div>
        <!-- /.login-logo -->
        <div class="login-box-body">
            <p class="login-box-msg">Sign in to start your session</p>
            <form method="post" action="<?php echo e(route('login')); ?>">
                <?php echo e(csrf_field()); ?>


                <?php if(Session::has('message')): ?>
                    <div class="successMessage alert alert-<?php echo e(Session::get('message_type')); ?> text-center">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>

                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <input name="email" id="email" type="email" class="form-control" placeholder="Email"
                           value="<?php echo e(old('email')); ?>"
                           required autofocus>
                    <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                </div>

                <?php if($errors->has('email')): ?>
                    <span class="help-block"><strong style="color: #f55247"><?php echo e($errors->first('email')); ?></strong></span>
                <?php endif; ?>
                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <input name="password" type="password" class="form-control" placeholder="Password" required>
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>

                <?php if($errors->has('password')): ?>
                    <span class="help-block"><strong
                                style="color: #f55247"><?php echo e($errors->first('password')); ?></strong></span>
                <?php endif; ?>
                <div class="row">
                    <div class="col-xs-8">
                        <div class="checkbox icheck">
                            <label>
                                <input type="checkbox" <?php echo e(old('remember' ? 'checked':'')); ?>> Remember Me
                            </label>
                        </div>
                    </div>
                    <!-- /.col -->
                    <div class="col-xs-4">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>
            <!-- /.social-auth-links -->

            <a href="<?php echo e(route('password.request')); ?>">I forgot my password</a><br>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login-master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>