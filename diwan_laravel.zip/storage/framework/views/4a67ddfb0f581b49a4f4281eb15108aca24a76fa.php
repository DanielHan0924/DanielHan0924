<aside class="main-sidebar">
    <section class="sidebar">
   
        <ul class="sidebar-menu" data-widget="tree">
            <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-download"></i><span>Import Contacts</span></a></li>


           
    </section>
</aside>