<?php $__env->startSection('title'); ?>
    DIWAN  - <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <section class="content animated fadeIn">

            <?php if(Session::has('message')): ?>
                <div class="successMessage alert alert-success text-center"><h4 style="margin:0;"><i
                                class="fa fa-check-circle"></i> <?php echo e(Session::get('message')); ?></h4></div>
            <?php endif; ?>

            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="pull-left">
                        <h3 class="box-title"><?php echo e(strtoupper($title)); ?></h3>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="box-body min-height">
                    <div class="row">
                        <div class="col-md-12">
                            <form action="<?php echo e(route('api_token_store')); ?>" method="post" class="form-horizontal"
                                  id="create_account">
                                <?php echo e(csrf_field()); ?>

                                <div class="box-body">

     <div class="form-group">
                                        <label for="account_number" class="col-sm-2 control-label">URL RAPID PRO *</label>
										
										
                                        <div class="col-sm-10">
                                            <input name="account_number" class="form-control" id="title"
                                                   placeholder="Api token url , example: http://xxxxx.com" type="text" disabled
												   
												   value="https://sms.diwan.ly/api/v2/">
                                          
											
											
                                        </div>
                                    </div>

                                  
                                   
                                   
                                    <div class="form-group">
                                        <label for="account_number" class="col-sm-2 control-label">API TOKEN *</label>
										
										
                                        <div class="col-sm-10">
                                            <input name="api_token" class="form-control" id="title"
                                                   placeholder="Please add api token code ...." type="text"
                                                   value="<?php echo e(old('api_token')); ?>">
                                      
											
                                        </div>
                                    </div>
									
									
                               

                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button type="submit" class="btn btn-success pull-right col-sm-12">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            /**
             * Front End validation
             */
            $('#create_account').validate({
                rules: {
                    account_number: {
                        required: true
                    },
                    account_holder: {
                        required: true
                    },
                    bank_name: {
                        required: true
                    },
                    bank_address: {
                        required: true
                    },
                    last_balance: {
                        required: true
                    }

                },
                messages: {
                    account_number: {
                        required: "Please put an account number"
                    },
                    account_holder: {
                        required: "Please put an account holder's name"
                    },
                    bank_address: {
                        required: "Put bank address"
                    },
                    bank_name: {
                        required: "Provide bank name"
                    },
                    last_balance: {
                        required: "Give an initial balance"
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>