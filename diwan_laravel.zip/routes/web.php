<?php
if(version_compare(PHP_VERSION, '7.2.0', '>=')) {
    error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
}

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();
Route::get('cron', ['uses' => 'DashboardController@cron'])->name('upload_cron');
Route::get('dashboard', ['uses' => 'DashboardController@index']);

Route::get('/', 'DashboardController@index');
    
	 
Route::post('dashborad/store', ['uses' => 'DashboardController@store'])->name('api_token_store');
Route::post('dashborad/contact/upload', ['uses' => 'DashboardController@updloaddata'])->name('updloaddata');
Route::post('dashborad/contact/submit', ['uses' => 'DashboardController@submitdata'])->name('submitdata');
Route::get('group/{uuid}/{name}', ['uses' => 'DashboardController@upload_contacts'])->name('upload_group_contacts');
	
		 
Route::group(/**
 *
 */
    ['middleware' => 'auth'], function () {


    // Logout Route
    Route::get('/logout', 'Auth\LoginController@logout');

    // Dashboard Route
    
    /**
     * Product Routes
     */


    Route::get('viewProduct/{id}', ['uses' => 'ProductController@viewProduct'])->name('viewProduct');
    Route::get('downloadProductData', ['uses' => 'ProductController@exportProduct']);
    Route::get('itemDownloadCsv/{type}', 'ProductController@downloadCsv');


    /**
     * Account Routes
     */


    Route::get('account/balancesheet', 'AccountController@balancesheet')->name('balancesheet');
    Route::get('transaction-cat/categories', 'AccountController@transactionCategories')->name('categories');
    Route::get('transaction-cat/create', 'AccountController@createCategory')->name('createCategory');
    Route::post('transaction-cat/store', 'AccountController@storeCategory')->name('storeCategory');
    Route::post('deleteCategory/{id}', ['uses' => 'AccountController@deleteCategory'])->name('deleteCategory');
    Route::get('account/accountStatement', ['uses' => 'AccountController@accountStatement'])->name('accountStatement');
    Route::post('account/processAccountStatement', ['uses' => 'AccountController@processAccountStatement'])->name('processAccountStatement');


    Route::get('transaction-cat/edit/{id}', ['uses' => 'AccountController@editCategory']);
    Route::patch('transaction-cat/update/{id}', ['uses' => 'AccountController@updateCategory'])->name('updateCategory');

    Route::post('makeTransfer', ['uses' => 'TransactionController@makeTransfer'])->name('makeTransfer');


    Route::prefix('transaction')->group(function () {
        Route::get('transfer', ['uses' => 'TransactionController@transfer'])->name('transfer');
        Route::get('income', ['uses' => 'TransactionController@income'])->name('income');
        Route::get('expense', ['uses' => 'TransactionController@expense'])->name('expense');
    });


    /**
     * Events
     */

    Route::get('event', ['uses' => 'EventController@index'])->name('event');
    Route::prefix('event')->group(function () {
        Route::get('getEvents', ['uses' => 'EventController@getEvents'])->name('getEvents');
        Route::post('dragUpdateEvent', ['uses' => 'EventController@dragUpdateEvent'])->name('dragUpdateEvent');
        Route::post('addEvent', ['uses' => 'EventController@addEvent'])->name('addEvent');
        Route::post('updateEvent', ['uses' => 'EventController@updateEvent'])->name('updateEvent');
        Route::get('deleteEvent/{id}', ['uses' => 'EventController@deleteEvent'])->name('deleteEvent');
    });


    /**
     * Task
     */

    Route::get('viewTask/{id}', ['uses' => 'TaskController@viewTask'])->name('viewTask');


    /**
     * Ticket Route
     */

    Route::get('answeredTickets', ['uses' => 'TicketController@answeredTickets'])->name('answeredTickets');


    /**
     * Project Comment Routes
     */

    Route::post('postComment/{id}', ['uses' => 'ProjectCommentController@postComment'])->name('postComment');
    Route::delete('/ticket-comment/{id}', array('uses' => 'TicketCommentController@destroy', 'as' => 'ticket-comment.destroy'));


    /**
     * Project Attachment Route
     */


    //Route::post('postProjectAttachment/{id}', ['uses' => 'ProjectAttachmentController@postProjectAttachment'])->name('postProjectAttachment');

    Route::resource('project_attachment', 'ProjectAttachmentController', ['only' => ['store', 'destroy']]);
    /**
     * Ticket Comment Routes
     */

    Route::post('postTicketComment/{id}', ['uses' => 'TicketCommentController@postTicketComment'])->name('postTicketComment');


    Route::get('downloadInvoice/{id}', ['uses' => 'InvoiceController@downloadInvoice'])->name('downloadInvoice');
    Route::get('payment-for-project-invoice/{invoice_id}', 'InvoiceController@paymentForProjectInvoice');
    Route::post('submit-payment-for-project-invoice', 'InvoiceController@submitPaymentForProjectInvoice');
    Route::get('viewInvoice/{id}', ['uses' => 'InvoiceController@viewInvoice'])->name('viewInvoice');
    Route::get('createInvoice/{id}', ['uses' => 'InvoiceController@createInvoice'])->name('createInvoice');
    Route::post('storeInvoice', ['uses' => 'InvoiceController@storeInvoice'])->name('storeInvoice');
    Route::get('editInvoice/{id}', 'InvoiceController@editInvoice');
    Route::post('updateInvoice', 'InvoiceController@updateInvoice');
    //Route::get('deleteInvoice/{id}', 'InvoiceController@deleteInvoice');
    Route::resource('invoice', 'InvoiceController', ['only' => ['destroy']]);


    // Settings Route
    Route::get('backup/list', 'SettingsController@backupList')->name('backupLists');
    Route::get('back-up', 'SettingsController@backupDB');
    Route::post('deleteDatabaseBackup/{id}', ['uses' => 'SettingsController@deleteDatabaseBackup'])->name('deleteDatabaseBackup');
    Route::post('downloadDatabaseBackup/{id}', ['uses' => 'SettingsController@downloadDatabaseBackup'])->name('downloadDatabaseBackup');
    Route::get('changeUiTheme', ['uses' => 'SettingsController@changeUiTheme'])->name('changeUiTheme');
    Route::post('updateTheme/{id}', ['uses' => 'SettingsController@updateTheme'])->name('updateTheme');
    Route::get('emailSettings', ['uses' => 'SettingsController@emailSettings'])->name('emailSettings');
    Route::post('updateAppSettings', ['uses' => 'SettingsController@updateAppSettings'])->name('updateAppSettings');
    Route::post('save-email-config', 'SettingsController@emailSaveConfig');
    Route::get('tax', 'TaxController@index')->name('getTaxes');
    Route::post('save-tax', 'TaxController@store')->name('addTaxRate');
    Route::get('edit-tax/{id}', 'TaxController@edit');
    Route::post('update-tax', 'TaxController@update');
    Route::post('delete-tax/{id}', 'TaxController@destroy')->name('deleteTax');
    Route::post('save-preference', 'SettingsController@savePreference');


    /**
     * ActivityLog route
     */

    Route::get('viewlog', ['uses' => 'ActivityLogController@viewlog'])->name('viewlog');


    /**
     * Message Route
     */
    Route::get('/message/compose', 'MessageController@compose');
    Route::post('/message/{type}/lists', 'MessageController@lists');
    Route::post('/message', ['as' => 'message.store', 'uses' => 'MessageController@store']);
    Route::get('/message/sent', 'MessageController@sent');
    Route::get('/message', 'MessageController@inbox');
    Route::get('/message/{id}/download', 'MessageController@download');
    Route::get('/message/view/{id}/{token}', array('as' => 'message.view', 'uses' => 'MessageController@view'));
    Route::get('/message/{id}/delete/{token}', array('as' => 'message.delete', 'uses' => 'MessageController@delete'));


    /**
     * Change Password
     */


    Route::get('/change-password', 'PasswordController@changePassword');
    Route::post('/change-password', array('as' => 'change-password', 'uses' => 'PasswordController@doChangePassword'));


    /**
     * Edit User profile
     */

    Route::get('editProfile', ['uses' => 'EditProfileController@editProfile'])->name('editProfile');
    Route::post('updateProfile/{id}', ['uses' => 'EditProfileController@updateProfile'])->name('updateProfile');


    /**
     * Payment routes
     */


    Route::get('paymentTerms', 'PaymentTermsController@index');
    Route::post('addPaymentTerm', 'PaymentTermsController@addPaymentTerm');
    Route::get('get-payment-terms/{id}', 'PaymentTermsController@edit');
    Route::post('update-payment-term', 'PaymentTermsController@update');
    Route::post('deletePaymentTerm/{id}', ['uses' => 'PaymentTermsController@deletePaymentTerm'])->name('deletePaymentTerm');


    /**
     * Payment Method Routes
     */

    Route::get('payment/method', 'PaymentMethodController@index');
    Route::post('submit-payment-method', 'PaymentMethodController@addPaymentMethod');
    Route::get('edit-payment-method/{id}', 'PaymentMethodController@edit');
    Route::post('update-payment-method', 'PaymentMethodController@update');
    Route::post('method/delete/{id}', 'PaymentMethodController@deletePaymentMethod')->name('deletePaymentMethod');



    /**
     * Temporary testing route
     */

    Route::get('/emailTest', 'SettingsController@testEmailConfig');

    /**
     * Email Template routes
     */


    Route::prefix('email')->group(function () {
        Route::get('getTemplates', ['uses' => 'MailTemplateController@getEmailTemplate'])->name('getEmailTemplates');
        Route::get('customer-invoice-temp/{id}', 'MailTemplateController@customerInvTemp');
        Route::post('customer-invoice-temp/{id}', 'MailTemplateController@update');

    });


    /**
     * Income & Expense Category
     */

    Route::prefix('income-expense')->group(function () {
        Route::get('categories', 'IncomeExpenseCategoryController@index');
        Route::post('store', 'IncomeExpenseCategoryController@store');
        Route::get('edit/{id}', 'IncomeExpenseCategoryController@edit');
        Route::post('update/', 'IncomeExpenseCategoryController@update');
        Route::post('delete/{id}', 'IncomeExpenseCategoryController@delete');
    });


    /**
     * Sales Invoice Routes
     */


    Route::prefix('invoice')->group(function () {
        Route::get('sales', 'SalesController@index')->name('manageInvoice');
        Route::get('sales/add', 'SalesController@create')->name('createSaleInvoice');
        Route::get('sales/edit/{id}', 'SalesController@edit');
        Route::get('view-sales-invoice/{id}', 'SalesController@view')->name('invoice.view');
        Route::get('download-pdf-invoice/{id}', 'SalesController@invoiceDownload');
        Route::post('email-invoice-info', 'SalesController@sendInvoiceInformationByEmail');
        Route::post('sales/save', 'SalesController@store')->name('storeSalesInvoice');
        Route::post('sales/update', 'SalesController@update');
        Route::post('sales/search', 'SalesController@search');
        Route::get('delete-sales-invoice/{id}', 'SalesController@destroy');
        Route::get('get-item-for-sales-invoice/{item_id}', 'SalesController@getItem');

        Route::get('get-inventory-item/{warehouse_id}', 'SalesController@getInventoryItem');

        /** payment for sales invoice */

        Route::get('payment-for-sales-invoice/{id}', 'PaymentController@PaymentForSalesInvoice');
        Route::post('submit-payment-for-sales-invoice', 'PaymentController@SubmitPaymentForSalesInvoice');
        Route::get('payments', 'PaymentController@salesPayment');

    });

    /**
     * Quote Route
     */

    Route::prefix('quote')->group(function () {
        Route::get('manage', 'QuoteController@index');
        Route::get('add', 'QuoteController@create');
        Route::post('save', 'QuoteController@store');
        Route::get('edit/{id}', 'QuoteController@edit');
        Route::get('convert-to-invoice/{id}', 'QuoteController@convertToInvoice');
        Route::post('update', 'QuoteController@update');
        Route::get('view/{id}', 'QuoteController@view');
        Route::post('email-quote-info', 'QuoteController@emailQuoteInfo');
        Route::get('download-pdf-quote/{id}', 'QuoteController@quoteDownload');
        Route::get('delete-quote/{id}', 'QuoteController@destroy');
    });

    /**
     * Purchase Route
     */

    Route::prefix('purchase')->group(function () {
        Route::get('manage', 'PurchaseController@index');
        Route::get('add', 'PurchaseController@create');
        Route::post('save', 'PurchaseController@store');
        Route::get('edit/{id}', 'PurchaseController@edit');
        Route::post('update', 'PurchaseController@update');
        Route::get('view/{id}', 'PurchaseController@view');
        Route::get('download-pdf-purchase-invoice/{id}', 'PurchaseController@invoiceDownload');
        Route::get('delete-purchase-invoice/{id}', 'PurchaseController@destroy');

    });


    /**
     * Resourceful routes
     */


    Route::resources([
        'category' => 'CategoryController',
        'warehouse' => 'WareHouseController',
        'product' => 'ProductController',
        'supplier' => 'SupplierController',
        'group' => 'GroupController',
        'customer' => 'CustomerController',
        'account' => 'AccountController',
        'transaction' => 'TransactionController',
        'settings' => 'SettingsController',
        'task' => 'TaskController',
        'project' => 'ProjectController',
        'note' => 'NoteController',
        'employee' => 'EmployeeController',
        'ticket' => 'TicketController'
    ]);

    Route::get('get-transaction-category/{type}', 'TransactionController@getTransactionCategory');

    /** manage expense */
    Route::get('expenses', 'ExpenseController@index');
    Route::get('expense/add-expense', 'ExpenseController@addExpense');
    Route::post('expense/store', 'ExpenseController@store');
    Route::get('expense/edit/{id}', 'ExpenseController@edit');
    Route::post('expense/update', 'ExpenseController@update');
    Route::post('delete-expense/{id}', 'ExpenseController@delete');


    /**
     * Transaction Routes
     */

    Route::get('downloadTransactionData', ['uses' => 'TransactionController@exportTransaction']);

    /*=============Manage User Permission==============*/
    Route::get('admin/all-user', 'adminUserController@index');
    Route::post('save-permission', array('as' => 'configuration.save_permission', 'uses' => 'adminUserController@savePermission'));
    Route::get('user-permission', 'adminUserController@userPermission');
    //Route::post('admin/editor-image', 'adminGeneralSettingController@editorImage');
    /**
     * Manage Role Zone
     */
    Route::resource('role', 'roleController');


    /**
     * Search Result Page
     */

    Route::post('search-result', 'SearchController@searchResult')->name('searchResult');


    /**
     * Reporting routes
     */
    Route::get('report/inventory-stock-on-hand/{category_id?}/{warehouse_id?}','ReportController@inventoryStockOnHand');
    Route::post('inventory-stock-on-hand-by-filter', 'ReportController@inventoryStockOnHandByFilter');
    Route::get('report/expense-report','ReportController@expenseReport');
    Route::get('report/income-report','ReportController@incomeReport');
    Route::get('report/income-vs-expense','ReportController@incomeVsExpense');
    Route::get('report/sales-report/{product?}/{customer_id?}/{location?}/{year?}/{month?}','ReportController@salesReport');
    Route::post('report/sale-report-by-filter', 'ReportController@saleReportByFilter');
    Route::get('report/purchase-report/{product?}/{supplier?}/{location?}','ReportController@purchaseReport');
    Route::post('report/purchase-report-by-filter','ReportController@purchaseReportByFilter');
    Route::get('report/purchase-report-csv','ReportController@purchaseReportCsv');
    Route::get('report/purchase_report_date_wise/{time}','ReportController@purchaseReportDateWise');
    Route::get('report/sales_report_date_wise/{time}','ReportController@salesReportDateWise');

});



/** ====== forgot password ====== */
Route::get('change-password/{token}', 'Auth\ChangePasswordController@changePassword');
Route::post('update-password', 'Auth\ChangePasswordController@updatePassword');
Route::post('send-password-link', 'Auth\ChangePasswordController@sendPasswordLink');




