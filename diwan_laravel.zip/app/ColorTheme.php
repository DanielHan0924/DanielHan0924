<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ColorTheme extends Model
{
    protected $table = 'color_themes';
    protected $primaryKey = 'id';
    protected $fillable = [
        'theme_name'
    ];
}
