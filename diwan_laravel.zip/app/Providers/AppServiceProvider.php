<?php

namespace App\Providers;

use App\EmailConfig;
use Config;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);


        /**
         * Flags
         */


        if (env('DB_DATABASE') != '') {

            if (Schema::hasTable('email_configs')) {
                $result = EmailConfig::first();
                //$result = DB::table('email_configs')->first();
                Config::set([
                    'mail.driver' => $result->email_protocol,
                    'mail.host' => $result->smtp_host,
                    'mail.port' => $result->smtp_port,
                    'mail.from' => ['address' => $result->from_address,
                        'name' => $result->from_name],
                    'mail.encryption' => $result->email_encryption,
                    'mail.username' => $result->smtp_username,
                    'mail.password' => $result->smtp_password
                ]);
            }
        }
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
