<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmailConfig extends Model
{
    protected $table='email_configs';
    protected $primaryKey='id';
    protected $fillable = [
        'email_protocol',
        'email_encryption',
        'smtp_host',
        'smtp_port',
        'smtp_email',
        'smtp_username',
        'smtp_password',
        'from_address',
        'from_name'
    ];
}
