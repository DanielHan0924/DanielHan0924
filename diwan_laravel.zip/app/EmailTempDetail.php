<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmailTempDetail extends Model
{
    protected $table = 'email_temp_details';
    protected $primaryKey = 'id';

    protected $fillable = [
        'temp_id',
        'subject',
        'body'
    ];
}
