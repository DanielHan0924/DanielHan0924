<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    protected $table = 'tasks';
    protected $primaryKey = 'id';
    protected $fillable = [
        'project_id',
        'name',
        'status',
        'start_date',
        'due_date',
        'description',
        'user_id',
        'assign_to',
        'priority'
    ];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */

    public function project()
    {
        return $this->belongsTo(Project::class);
    }



    public function users()
    {
        return $this->belongsToMany(User::class, 'assigned_tasks', 'task_id', 'user_id');
    }

}
