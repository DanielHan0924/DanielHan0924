<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApplicationSetting extends Model
{
    protected $table = 'application_settings';
    protected $primaryKey = 'id';
    protected $fillable = [
        'company_name',
        'address',
        'city',
        'region',
        'country_id',
        'postbox',
        'phone',
        'email',
        'taxid',
        'tax',
        'currency',
        'currency_format',
        'date_format',
        'zone',
        'company_logo',
        'default_expense_id',

    ];


    public function country()
    {
        return $this->belongsTo(Country::class);
    }
}
