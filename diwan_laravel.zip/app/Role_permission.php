<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Role_permission extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'role_permissions';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['school_id', 'permission_id', 'role_id', 'permission_type'];
}
