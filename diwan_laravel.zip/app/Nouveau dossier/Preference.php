<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Preference extends Model
{
    protected $table = 'preferences';
    protected $primaryKey = 'id';
    protected $fillable = [
        'category',
        'field',
        'value'
    ];
}
