<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;


class User extends Authenticatable implements Searchable
{
    use Notifiable;
    use HasRoles;


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'password',
        'username',
        'profile_image',
        'last_login',
        'last_login_ip',
        'last_login_now',
        'last_login_ip_now'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];



    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function notes()
    {
        return $this->hasMany(Note::class);
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function comment()
    {
        return $this->belongsTo(ProjectComment::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function customer()
    {
        return $this->hasOne(Customer::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function supplier()
    {
        return $this->hasOne(Supplier::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function employee()
    {
        return $this->hasOne(Employee::class);
    }


    /**
     *
     * Pivot table relation
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function projects()
    {
        return $this->belongsToMany(Project::class, 'assigned_projects', 'user_id', 'project_id');
    }


    /**
     * Pivot table relation
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */

    public function ticket_stuffs()
    {
        return $this->belongsToMany(Ticket::class, 'assigned_tickets', 'user_id', 'ticket_id');
    }

    public function task_employees()
    {
        return $this->belongsToMany(Task::class, 'assigned_tasks', 'user_id', 'task_id');
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public function tickets()
    {
        return $this->hasMany(Tickets::class);
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function message()
    {
        return $this->hasMany(Message::class);
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    function tasks()
    {
        return $this->hasMany(Task::class);
    }


    /**
     * Attribute casting. Return first_name and last_name as full_name
     * @return string
     */

    public function getFullNameAttribute()
    {
        return $this->first_name . ' ' . $this->last_name;
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public function salesInvoice()
    {
        return $this->hasMany(Sales_invoice::class, 'customer_id');
    }


    public function quote()
    {
        return $this->hasMany(Quote::class, 'customer_id');
    }


    public function purchaseInvoice()
    {
        return $this->hasMany(Purchase_invoice::class, 'supplier_id');
    }

    public function bankTran()
    {
        return $this->hasMany(Bank_tran::class, 'person_id');
    }



    public function getSearchResult(): SearchResult
    {
        $url = route();
    }

}
