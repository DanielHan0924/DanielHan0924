<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Zizaco\Entrust\EntrustPermission;

class Permission extends EntrustPermission
{
    protected $table = 'permissions';
    protected $primaryKey = 'id';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['module', 'name'];

//    public function role(){
//        return $this->belongsToMany('App\Permission','role_permissions', 'permission_id', 'role_id');
//    }
}
