<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'projects';
    protected $fillable = [
        'name',
        'status',
        'priority',
        'budget',
        'tags',
        'progress',
        'customer_id',
        'start_date',
        'end_date',
        'link_to_cal',
        'note'
    ];


    public function customer()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function tasks()
    {
        return $this->hasMany(Task::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public function comments()
    {
        return $this->hasMany(ProjectComment::class);
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public function invoices()
    {
        return $this->hasMany(Invoice::class);
    }

    public function users()
    {
        return $this->belongsToMany(User::class, 'assigned_projects', 'project_id', 'user_id');
    }


    public function ticket()
    {
        return $this->hasOne(Tickets::class);
    }


}
