<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProjectAttachment extends Model
{
    protected $table = 'project_attachments';
    protected $primaryKey = 'id';


    protected $fillable = [
        'project_id',
        'attachment_title',
        'attachment_description',
        'attachment_username',
        'file'
    ];


    public function project()
    {
        return $this->belongsTo(Project::class);
    }
}
