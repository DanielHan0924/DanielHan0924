<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BankAccountType extends Model
{
    protected $table = 'bank_account_type';
    protected $primaryKey = 'id';

    protected $fillable = [
        'name'
    ];

    public function account()
    {
        return $this->hasMany(Account::class, 'account_type_id');
    }


}
