<?php

namespace App;

use Carbon;
use Illuminate\Database\Eloquent\Model;

class TicketComments extends Model
{
    protected $fillable = [
        'ticket_id',
        'user_id',
        'comment',
        'comment_username',
        'attachment',
    ];

    protected $table = 'ticket_comments';

    protected $primaryKey = 'id';

    public function ticket()
    {
        return $this->belongsTo(Tickets::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function getCreatedAtAttribute($date)
    {
        return Carbon\Carbon::createFromFormat('m/d/Y g:ia', $date);

    }

}
