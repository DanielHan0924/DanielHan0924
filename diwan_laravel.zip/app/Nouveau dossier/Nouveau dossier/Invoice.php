<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    protected $table = 'invoices';
    protected $primaryKey = 'id';
    protected $fillable = [
        'project_id',
        'logo',
        'invoice_number',
        'invoice_from',
        'bill_to',
        'invoice_create_date',
        'payment_terms',
        'invoice_due_date',
        'sub_total',
        'discount_type',
        'discount_amount',
        'total_payable',
        'amount_paid',
        'total_due',
        'note',
        'terms',
    ];



    public function project(){
        return $this->belongsTo(Project::class);
    }

    public function items()
    {
        return $this->hasMany(Invoice_item::class, 'invoice_id');
    }

}
