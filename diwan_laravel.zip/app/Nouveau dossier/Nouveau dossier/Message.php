<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    protected $fillable = [
        'from_user_id',
        'to_user_id',
        'subject',
        'body',
        'attachments',
        'is_read',
        'delete_sender',
        'delete_receiver',
    ];
    protected $primaryKey = 'id';
    protected $table = 'messages';

    public function userTo()
    {
        return $this->belongsTo(User::class, 'to_user_id');
    }


    public function userForm()
    {
        return $this->belongsTo(User::class, 'from_user_id');
    }
}
