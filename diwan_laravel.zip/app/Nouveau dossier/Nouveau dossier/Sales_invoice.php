<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;

class Sales_invoice extends Model implements Searchable
{
    static $searchType = 'Sales Invoice';
    protected $table = 'sales_invoices';
    protected $primaryKey = 'id';
    protected $fillable = [
        'customer_id',
        'payment_method_id',
        'payment_term_id',
        'warehouse_id',
        'invoice_date',
        'reference',
        'custom_item',
        'order_note',
        'sub_total',
        'total_tax',
        'grand_total',
        'total_paid',
        'total_due',
        'status'
    ];



    public function getSearchResult(): SearchResult
    {
        $url = route('invoice.view', $this->id);
        return new SearchResult($this, $this->reference, $url);
    }



    public function user()
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function paymentMethod()
    {
        return $this->belongsTo(PaymentTerm::class, 'payment_method_id');
    }


    public function paymentTerm()
    {
        return $this->belongsTo(InvoicePaymentTerms::class, 'payment_term_id');
    }

    public function salesInvoiceDetails()
    {
        return $this->hasMany(Sales_invoice_details::class, 'invoice_id');
    }

    public function payment()
    {
        return $this->hasMany(Payment::class, 'invoice_id');
    }

}
