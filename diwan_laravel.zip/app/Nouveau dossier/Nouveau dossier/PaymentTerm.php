<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentTerm extends Model
{
    protected $table = 'payment_terms';
    protected $primaryKey = 'id';
    protected $fillable = [
        'name',
        'default'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public function salesInvoice()
    {
        return $this->hasMany(Sales_invoice::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public function quote()
    {
        return $this->hasMany(Quote::class);
    }

    public function purchaseInvoice()
    {
        return $this->hasMany(Purchase_invoice::class, 'payment_method_id');
    }

    public function payment()
    {
        return $this->hasMany(Payment::class, 'payment_method_id');
    }

    public function bankTran()
    {
        return $this->hasMany(Bank_tran::class, 'payment_method');
    }

}
