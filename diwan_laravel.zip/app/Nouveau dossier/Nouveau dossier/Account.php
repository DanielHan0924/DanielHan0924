<?php

namespace App;

use DB;
use Illuminate\Database\Eloquent\Model;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;

class Account extends Model implements Searchable
{
    protected $table = 'accounts';
    protected $primaryKey = 'id';
    protected $fillable = [
        'account_type_id',
        'account_number',
        'account_holder',
        'last_balance',
        'bank_name',
        'bank_address',
        'note'
    ];


    public function getSearchResult(): SearchResult
    {
        $url = route('account.show', $this->id);
        return new SearchResult($this, $this->account_number, $url);
    }


    /**
     * @return total available balance from all account
     */
    public function balanceSheet()
    {
        return $this->sum('last_balance');
    }

    public function expense()
    {
        return $this->hasMany(Expense::class, 'account_id');
    }


    public function bankTran()
    {
        return $this->hasMany(Bank_tran::class, 'account_no');
    }

    public function accountType()
    {
        return $this->belongsTo(BankAccountType::class, 'account_type_id');
    }


    public function getAccounts()
    {

        // Query has error....

        $data = DB::select("
                select ba.*, bat.name as account_type, 
                SUM(bt.amount) as balance from accounts as ba
                LEFT JOIN bank_trans as bt
                  ON ba.id = bt.account_no
                LEFT JOIN bank_account_type as bat
                  ON bat.id = ba.account_type_id
                GROUP BY bt.account_no
                ORDER BY ba.account_holder ASC
                ");
        return $data;
    }

}
