<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Expense extends Model
{
    protected $table = "expenses";
    protected $primaryKey = "id";
    protected $fillable = [
        'account_id',
        'category_id',
        'added_date',
        'description',
        'amount',
        'payment_method',
        'reference',
        'attachment',
    ];


    public function account()
    {
        return $this->belongsTo(Account::class, 'account_id');
    }

    public function category()
    {
        return $this->belongsTo(TransactionCategory::class, 'category_id');
    }
}
