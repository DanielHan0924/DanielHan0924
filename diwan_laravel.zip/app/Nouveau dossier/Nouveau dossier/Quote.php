<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Quote extends Model
{
    protected $table = 'quotes';
    protected $primaryKey = 'id';
    protected $fillable = [
        'customer_id',
        'payment_method_id',
        'payment_term_id',
        'invoice_date',
        'reference',
        'custom_item',
        'order_note',
        'sub_total',
        'total_tax',
        'grand_total',
        'invoice_status',
        'status'
    ];


    public function user() {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function inventoryItem()
    {
        return $this->hasMany(Quote_details::class, 'quote_id');
    }

    public function paymentMethod()
    {
        return $this->belongsTo(PaymentTerm::class, 'payment_method_id');
    }


    public function paymentTerm()
    {
        return $this->belongsTo(InvoicePaymentTerms::class, 'payment_term_id');
    }

    public function quoteDetails()
    {
        return $this->hasMany(Quote_details::class, 'quote_id');
    }

}
