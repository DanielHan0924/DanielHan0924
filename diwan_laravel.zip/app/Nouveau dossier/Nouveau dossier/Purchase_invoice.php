<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchase_invoice extends Model
{
    protected $table = 'purchase_invoices';
    protected $primaryKey = 'id';
    protected $fillable = [
        'supplier_id',
        'payment_method_id',
        'payment_term_id',
        'invoice_date',
        'warehouse_id',
        'reference',
        'order_note',
        'sub_total',
        'total_tax',
        'grand_total',
        'status',
    ];


    public function user()
    {
        return $this->belongsTo(User::class, 'supplier_id');
    }

    public function paymentMethod()
    {
        return $this->belongsTo(PaymentTerm::class, 'payment_method_id');
    }


    public function paymentTerm()
    {
        return $this->belongsTo(InvoicePaymentTerms::class, 'payment_term_id');
    }

    public function purchaseItemDetails()
    {
        return $this->hasMany(Purchase_invoice_details::class, 'invoice_id');
    }

}
