<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    protected $table = 'suppliers';
    protected $primaryKey = 'id';
    protected $fillable = [
        'phone',
        'address',
        'city',
        'region',
        'country_id',
        'postbox',
        'company'
    ];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */

    public function country()
    {
        return $this->belongsTo(Country::class);
    }


    public function user()
    {
        return $this->belongsTo(User::class);
    }


}
