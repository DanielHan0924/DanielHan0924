<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;

class Customer extends Model implements Searchable
{

    protected $table = 'customers';
    protected $primaryKey = 'id';
    protected $fillable = [
        'name',
        'user_id',
        'phone',
        'address',
        'city',
        'region',
        'country_id',
        'postbox',
        'email',
        'company',
        'tax_id',
        's_name',
        's_phone',
        's_address',
        's_city',
        's_region',
        's_country_id',
        's_postbox',
        's_email',
        'same_as_billing'
    ];


    public function getSearchResult(): SearchResult
    {
        $url = route('customer.show', $this->id);
        return new SearchResult($this, $this->name, $url);
    }

    public function group()
    {
        return $this->belongsTo(Group::class);
    }


    public function country()
    {
        return $this->belongsTo(Country::class, 'country_id');
    }

    public function shippingCountry()
    {
        return $this->belongsTo(Country::class, 's_country_id');
    }


    public function user()
    {
        return $this->belongsTo(User::class);
    }


    public function projects()
    {
        return $this->hasMany(Project::class);
    }





}
