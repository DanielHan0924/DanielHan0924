<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tickets extends Model
{
    protected $fillable = [
        'customer_id',
        'project_id',
        'subject',
        'description',
        'priority',
        'answer_status',
        'closed_at',
        'status'
    ];

    protected $primaryKey = 'id';
    protected $table = 'tickets';


    public function customer()
    {
        return $this->belongsTo(User::class);
    }

    public function employees()
    {
        return $this->belongsToMany(User::class, 'assigned_tickets', 'ticket_id', 'user_id');
    }


    public function project()
    {
        return $this->belongsTo(Project::class);
    }

//    public function userAdded()
//    {
//        return $this->belongsTo(User::class, 'user_id');
//    }


    public function comments()
    {
        return $this->hasMany(TicketComments::class);
    }

    public function notes()
    {
        return $this->hasMany(TicketNotes::class);
    }


}
