<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransactionCategory extends Model
{
    protected $table = 'transaction_categories';
    protected $primaryKey = 'id';
    protected $fillable = [
        'name',
        'type'
    ];


    public function expense()
    {
        return $this->hasMany(Expense::class, 'category_id');
    }

    public function bankTran()
    {
        return $this->hasMany(Bank_tran::class, 'category_id');
    }

}
