<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemTaxType extends Model
{
    protected $table = 'item_tax_types';
    protected $primaryKey = 'id';
    protected $fillable = [
        'name',
        'tax_rate',
        'default'
    ];


    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function salesInvoiceDetails()
    {
        return $this->hasMany(Sales_invoice_details::class,'tax_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public function quoteDetails()
    {
        return $this->hasMany(Quote_details::class,'tax_id');
    }

    public function purchaseInvoiceDetails()
    {
        return $this->hasMany(Purchase_invoice_details::class, 'tax_id');
    }
}
