<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Backup extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'backups';
    protected $fillable = [
        'name'
    ];
}
