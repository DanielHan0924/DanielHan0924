<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InvoicePaymentTerms extends Model
{
    protected $primaryKey = 'id';
    protected $table='invoice_payment_terms';
    protected $fillable=[
        'terms',
        'days_before_due',
        'defaults'
    ];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public function salesInvoice()
    {
        return $this->hasMany(Sales_invoice::class, 'payment_term_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public function quote()
    {
        return $this->hasMany(Quote::class, 'payment_term_id');
    }

    public function purchaseInvoice()
    {
        return $this->hasMany(Purchase_invoice::class, 'payment_term_id');
    }
}
