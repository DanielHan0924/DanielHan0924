<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bank_tran extends Model
{
    protected $table = 'bank_trans';
    protected $primaryKey = 'id';
    protected $fillable = [
        'account_no',
        'category_id',
        'payment_method',
        'amount',
        'trans_type',
        'trans_date',
        'person_id',
        'reference',
        'description',
        'attachment'
    ];

    public function person()
    {
        return $this->belongsTo(User::class, 'person_id');
    }
    public function account()
    {
        return $this->belongsTo(Account::class, 'account_no');
    }

    public function category()
    {
        return $this->belongsTo(TransactionCategory::class, 'category_id');
    }

    public function paymentMethod()
    {
        return $this->belongsTo(PaymentTerm::class, 'payment_method');
    }
}
