<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TicketUsers extends Model
{
    //
}
