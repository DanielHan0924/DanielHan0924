<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TicketNotes extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'ticket_notes';
    protected $fillable = [
        'note',
        'user_id',
        'ticket_id'
    ];

    public function ticket()
    {
        return $this->belongsTo(Tickets::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
