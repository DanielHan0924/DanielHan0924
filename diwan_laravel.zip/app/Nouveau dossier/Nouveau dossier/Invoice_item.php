<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invoice_item extends Model
{
    protected $table = 'invoice_items';
    protected $primaryKey = 'id';
    protected $fillable = [
        'invoice_id',
        'item',
        'quantity',
        'rate',
        'amount'
    ];

    public function invoice()
    {
        return $this->belongsTo(Invoice::class, 'invoice_id');
    }
}
