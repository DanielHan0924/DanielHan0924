<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Quote_details extends Model
{
    protected $table = 'quote_details';
    protected $primaryKey = 'id';
    protected $fillable = [
    'quote_id',
    'product_id',
    'tax_id',
    'product_name',
    'qty',
    'unit_price',
    'tax',
    'discount',
    'unit_total_price',
    ];

    public function quote()
    {
        return $this->belongsTo(Quote::class, 'quote_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }


    public function tax()
    {
        return $this->belongsTo(ItemTaxType::class, 'tax_id');
    }
}
