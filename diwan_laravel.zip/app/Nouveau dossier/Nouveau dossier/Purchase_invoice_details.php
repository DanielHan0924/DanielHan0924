<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchase_invoice_details extends Model
{
    protected $table = 'purchase_invoice_details';
    protected $primaryKey = 'id';
    protected $fillable = [
        'invoice_id',
        'product_id',
        'tax_id',
        'product_name',
        'qty',
        'unit_price',
        'tax',
        'discount',
        'unit_total_price',
    ];

    public function purchaseInvoice()
    {
        return $this->belongsTo(Purchase_invoice::class, 'invoice_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }


    public function tax()
    {
        return $this->belongsTo(ItemTaxType::class, 'tax_id');
    }


}
