<?php

namespace App;

use DB;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    protected $table = 'transactions';
    protected $primaryKey = 'id';

    protected $fillable = [
        'customer_name',
        'account_id',
        'account',
        'type',
        'transaction_category_name',
        'debit',
        'credit',
        'customer_id',
        'pay_method',
        'date',
        'tid',
        'user_id',
        'note',
        'ext'
    ];


    /**
     * @param $account_id
     * @return Account holder's name for specific account id
     */

    public function account($account_id)
    {
        return Account::findOrFail($account_id);
    }


    /**
     * @param $customer_id
     * @return mixed
     */

    public function customer($customer_id)
    {
        return Customer::findOrFail($customer_id);
    }

    public function lastThirtyDaysExpenses()
    {
        $getLastOneMonthDates = getLastOneMonthDates();
        $final = [];
        $data_map = array();
        $today = date('Y-m-d');
        $previousDate = date("Y-m-d", strtotime("-30 day", strtotime(date('d-m-Y'))));

        $data = DB::select("SELECT SUM(amount) as amount,trans_date,MONTH(trans_date) as month,DAY(trans_date) as day FROM bank_trans WHERE trans_date BETWEEN '$previousDate' AND '$today' AND trans_type IN ('expense') GROUP BY trans_date");

        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $data_map[$value->day][$value->month] = abs($value->amount);
            }

            $dataArray = [];
            $i = 0;
            foreach ($getLastOneMonthDates as $key => $value) {
                $date = explode('-', $value);
                $td = (int)$date[0];
                $tm = (int)$date[1];
                $dataArray[$i]['day'] = $date[0];
                $dataArray[$i]['month'] = $date[1];
                if (isset($data_map[$td][$tm])) {
                    $dataArray[$i]['amount'] = $data_map[$td][$tm];
                } else {
                    $dataArray[$i]['amount'] = 0;
                }
                $i++;
            }


            foreach ($dataArray as $key => $res) {
                $final[$key] = $res['amount'];
            }

        }
        return $final;
    }


    public function expenseAmountByCategory()
    {
        $data = DB::select("SELECT bt.category_id, iec.name, SUM(ABS(bt.amount)) as amount FROM `bank_trans` as bt
          LEFT JOIN transaction_categories as iec
          ON iec.id = bt.category_id
          WHERE bt.trans_type = 'expense'
          GROUP BY bt.category_id
          ORDER BY amount DESC
          ");

        return $data;
    }

    /**
     * @return mixed
     */
    public function getTotalExpense()
    {
        $data = DB::table('bank_trans')
            ->where('trans_type', 'expense')
            ->sum('amount');
        return $data;
    }

    /**
     * @return float|int
     */
    public function lastThirtyDaysExpenseAmount()
    {
        $amount = 0;
        $today = date('Y-m-d H:i:s');
        $preDay = date('Y-m-d H:i:s', strtotime("-30 days"));
        $expenseAmount = DB::select("SELECT SUM(credit) as amount FROM transactions WHERE created_at BETWEEN '$preDay' AND '$today' AND type='Expense'");

        if (!empty($expenseAmount[0]->amount)) {
            $amount = abs($expenseAmount[0]->amount);
        }

        return $amount;
    }

    /**
     * @return array
     */
    public function getSixMonthExpense()
    {
        $today = date('Y-m-d');
        $previousDate = previousDate();

        $data = DB::select("SELECT SUM(amount) as amount,month,year FROM(SELECT amount,trans_date,MONTH(trans_date) as month,YEAR(trans_date) as year  FROM bank_trans 
        WHERE trans_date BETWEEN '$previousDate' AND '$today' AND trans_type = 'expense')expense GROUP BY month,year");
        return $data;
    }

    /**
     * @return \Illuminate\Support\Collection
     */
    public function latestIncomeExpenses()
    {
        $data = DB::table('bank_trans')
            ->where('trans_type', 'expense')
            ->orderBy('id', 'DESC')
            ->take(5)
            ->get();
        return $data;
    }


    public function getExpenseYears()
    {
        $year = array();
        $data = DB::select("SELECT DISTINCT(bt.year) 
                                  FROM(SELECT category_id,year(trans_date)as year from bank_trans)bt 
                                  RIGHT JOIN(SELECT * FROM transaction_categories 
                                  WHERE type NOT IN ('income'))iec ON bt.category_id = iec.id ");

        if (!empty($data)) {
            foreach ($data as $key => $value) {
                if (!empty($value->year)) {
                    $year[$key] = $value->year;
                }
            }
        }

        return $year;
    }


    public function getIncomeReport($year)
    {

        $data = DB::select("SELECT bt.*,iec.name FROM(SELECT category_id,month(trans_date) AS month,SUM(amount) as amount from bank_trans WHERE YEAR(trans_date)=$year GROUP BY month, category_id)bt RIGHT JOIN(SELECT * FROM transaction_categories WHERE type IN ('income'))iec ON bt.category_id = iec.id");

        return $data;
    }


    public function getExpenseReport($year)
    {

        $data = DB::select("SELECT bt.*,iec.name FROM(SELECT category_id,month(trans_date) AS month,SUM(amount) as amount from bank_trans WHERE YEAR(trans_date)=$year GROUP BY month, category_id)bt RIGHT JOIN(SELECT * FROM transaction_categories WHERE type NOT IN ('income'))iec ON bt.category_id = iec.id");

        return $data;
    }

    public function getIncomeYears()
    {
        $year = array();
        $data = DB::select("SELECT DISTINCT(bt.year) FROM(SELECT category_id,year(trans_date)as year from bank_trans)bt RIGHT JOIN(SELECT * FROM transaction_categories WHERE type IN ('income'))iec ON bt.category_id = iec.id");

        if (!empty($data)) {
            foreach ($data as $key => $value) {
                if (!empty($value->year)) {
                    $year[$key] = $value->year;
                }
            }
        }

        return $year;
    }


    public function incomeVsExpense($year)
    {
        $data = [];
        $income_map = [];
        $expense_map = [];
        $incomeFinal = [];
        $expenseFinal = [];
        $finalArray = [];
        $monthList = DB::table('months')->pluck('name', 'id');
        // Income Start
        $incomeArray = DB::SELECT("SELECT month(trans_date) AS month,SUM(amount) as amount from bank_trans WHERE trans_type IN ('deposit','cash-in-by-sale') AND YEAR(trans_date)='$year' GROUP BY month");

        foreach ($incomeArray as $key => $income) {
            $income_map[$income->month] = $income->amount;
        }
        $counter = 0;
        foreach ($monthList as $i => $month) {
            if (isset($income_map[$i])) {
                $incomeFinal[$counter]['amount'] = $income_map[$i];
                $incomeFinal[$counter]['month'] = $month;
            } else {
                $incomeFinal[$counter]['amount'] = 0;
                $incomeFinal[$counter]['month'] = $month;
            }
            $counter++;
        }


        // Expense Start
        $expenseArray = DB::SELECT("SELECT month(trans_date) AS month,SUM(amount) as amount from bank_trans WHERE trans_type IN ('expense') AND YEAR(trans_date)='$year' GROUP BY month");

        foreach ($expenseArray as $expense) {
            $expense_map[$expense->month] = $expense->amount;
        }
        $count = 0;
        foreach ($monthList as $index => $month) {
            if (isset($expense_map[$index])) {
                $expenseFinal[$count]['amount'] = abs($expense_map[$index]);
                $expenseFinal[$count]['month'] = $month;
            } else {
                $expenseFinal[$count]['amount'] = 0;
                $expenseFinal[$count]['month'] = $month;
            }
            $count++;
        }

        for ($row = 0; $row <= 11; $row++) {
            $finalArray[$row]['month'] = $expenseFinal[$row]['month'];
            $finalArray[$row]['income'] = $incomeFinal[$row]['amount'];
            $finalArray[$row]['expense'] = $expenseFinal[$row]['amount'];
            $finalArray[$row]['profit'] = ($incomeFinal[$row]['amount'] - $expenseFinal[$row]['amount']);
        }
        return $finalArray;
    }


}
