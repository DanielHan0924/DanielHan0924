<?php

namespace App;

use DB;
use Illuminate\Database\Eloquent\Model;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;

class Product extends Model implements Searchable
{
    protected $table = 'products';
    protected $primaryKey = 'id';
    protected $fillable = [
        'category_id',
        'warehouse_id',
        'product_name',
        'product_code',
        'product_wholesale_price',
        'product_retail_price',
        'product_tax_rate_id',
//        'product_discount_rate',
        'product_quantity',
        'product_image',

    ];

    public function getSearchResult(): SearchResult
    {
        $url = route('product.show', $this->id);
        return new SearchResult($this, $this->product_name, $url);
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function category()
    {
        return $this->belongsTo(Category::class);
    }


    public function taxes()
    {
        return $this->hasMany(ItemTaxType::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */

    public function warehouse()
    {
        return $this->belongsTo(Warehouse::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public function salesInvoiceDetails()
    {
        return $this->hasMany(Sales_invoice_details::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function quoteDetails()
    {
        return $this->hasMany(Quote_details::class);
    }

    public function purchaseInvoiceDetails()
    {
        return $this->hasMany(Purchase_invoice_details::class, 'product_id');
    }


    public function getAllItemCsv()
    {
        $products = DB::select("select id, product_name, product_code, product_wholesale_price as wholesale_price, 
                                  product_retail_price as retail_price, product_quantity as stock_quantity, description
                                  from products");
        return $products;
    }
}
