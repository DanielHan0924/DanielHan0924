<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        switch ($this->method()) {
            case 'GET':
            case 'DELETE':
                {
                    return [];
                }
            case'POST':
                {
                    return [
                        'category_id' => 'required',
                        'warehouse_id' => 'required',
                        'product_name' => 'required|unique:products',
                        'product_code' => 'required|unique:products',
                        'product_wholesale_price' => 'required|numeric',
                        'product_retail_price' => 'required|numeric',
                        'product_quantity' => 'required|numeric',
                        'product_image' => 'mimes:jpg,JPG,jpeg,png,svg'
                    ];
                }
            case 'PUT':
            case 'PATCH':
                {
                    return [
                        'category_id' => 'required',
                        'warehouse_id' => 'required',
                        'product_name' => 'required',
                        'product_code' => 'required',
                        'product_wholesale_price' => 'required|numeric',
                        'product_retail_price' => 'required|numeric',
                        'product_quantity' => 'required|numeric',
                        'product_image' => 'mimes:jpg,JPG,jpeg,png,svg'
                    ];
                }
        }


    }

    public function messages()
    {
        return [
            'product_name.required' => 'You need to give the product a name',
            'warehouse_id.required' => 'You must need to select an warehouse.',
            'product_code.required' => 'You need to give a product code',
            'product_wholesale_price.required' => 'You suppose to give a wholesale price for this product',
            'product_retail_price.required' => 'You suppose to give a retail price for this product',
            'product_quantity.required' => 'You forgot to add product quantity'

        ];
    }
}
