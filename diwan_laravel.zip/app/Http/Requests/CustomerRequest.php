<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CustomerRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        switch ($this->method()) {
            case'GET':
            case 'DELETE':
                {
                    return [];
                }
            case 'POST':
                {
                    return [
                        'first_name' => 'required',
                        'last_name' => 'required',
                        'username' => 'required|unique:users',
                        'password' => 'required',
                        'phone' => 'unique:customers',
                        'country_id' => 'required',
                        'email' => 'unique:customers',


                    ];
                }
            case 'PUT':
            case 'PATCH':
                {
                    return [
                        'first_name' => 'required',
                        'last_name' => 'required',
                        'username' => 'required',
                        'country_id' => 'required',
                    ];

                }
        }
    }


    public function messages()
    {
        return [
            'name.required' => 'Put a customer name',
            's_name.required' => 'Put a shipping name'
        ];
    }
}
