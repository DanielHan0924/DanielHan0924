<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SettingsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        switch ($this->method()) {
            case'GET':
            case 'DELETE':
                {
                    return [];
                }
            case 'POST':
            case 'PUT':
            case 'PATCH':
                {
                    return [
                        'company_name' => 'required',
                        'address' => 'required',
                        'city' => 'required',
                        'region' => 'required',
                        'postbox' => 'required',
                        'phone' => 'required',
                        'email' => 'required',
                    ];

                }
        }
    }


    public function messages()
    {
        return [
            'company_name.required' => 'Put your company name',
            'address.required' => 'Put your company address',
            'city.required' => 'Put your company city',
            'region.required' => 'Put your company region',
            'postbox.required' => 'Put your company postbox',
            'phone.required' => 'Put your company phone',
            'email.required' => 'Put your company email',
        ];
    }

}
