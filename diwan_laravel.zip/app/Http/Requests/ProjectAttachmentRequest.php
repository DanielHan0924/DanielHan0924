<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProjectAttachmentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'attachment_title' => 'required',
            'file' => 'required|mimes:pdf,doc,docx,jpg,JPG,jpeg,xlsx,csv,txt,png,svg'
        ];
    }


    public function messages()
    {
        return [
            'attachment_title.required' => 'Give A Title For The Attachment File',
            'file.required' => 'It Seems You Forgot To Attach File'
        ];
    }
}
