<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PaymentTermRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        switch ($this->method()) {
            case'GET':
            case 'DELETE':
                {
                    return [];
                }
            case 'POST':
                {
                    return [
                        'terms' => 'required|unique:invoice_payment_terms',
                        'days_before_due' => 'required|unique:invoice_payment_terms',
                        'defaults' => 'required',
                    ];
                }
            case 'PUT':
            case 'PATCH':
                {
                    return [
                        'terms' => 'required',
                        'days_before_due' => 'required',
                        'defaults' => 'required',
                    ];

                }
        }
    }


    public function messages()
    {
        return [
            'terms.required' => 'Put a term name',
            'days_before_due' => 'Give a numeric days before due value, e.g: 10, 15, etc.'
        ];
    }
}
