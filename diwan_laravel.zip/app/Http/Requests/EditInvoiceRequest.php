<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EditInvoiceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'invoice_number' => 'required',
            'invoice_from' => 'required',
            'bill_to' => 'required',
            'invoice_create_date' => 'required',
            'sub_total' => 'required',
            'discount_type' => 'required',
            'total_payable' => 'required',

        ];
    }


    public function messages()
    {
        return [
            'invoice_from.required' => 'Who is the invoice from ?',
            'bill_to.required' => 'Who to bill for this invoice ?',
            'invoice_create_date.required' => 'Put an invoice creation date',
        ];
    }
}
