<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MessageRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'to_user_id' => 'required',
            'subject' => 'required',
            'attachments' => 'mimes:pdf,doc,docx,xls,xlsx,jpg,jpeg,txt'
        ];
    }


    public function messages()
    {
        return [
            'subject.required' => 'Message subject field is required'
        ];
    }
}
