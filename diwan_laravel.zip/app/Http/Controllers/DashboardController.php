<?php

namespace App\Http\Controllers;

use App\Account;
use App\Employee;
use Illuminate\Http\Request;

use Carbon\Carbon;
use GuzzleHttp\Client;

use GuzzleHttp\Exception\RequestException;
use Illuminate\Support\Facades\DB;


class   DashboardController extends Controller
{

   

    public function index()
    {

       
        $data['title'] = 'TOKEN API';
        $data['activeMenu'] = 'dashboard';

        return view('admin.dashboard', $data);
    }
	
	public function readCSV($csvFile, $array)
{
    $file_handle = fopen($csvFile, 'r');
    while (!feof($file_handle)) {
        $line_of_text[] = fgetcsv($file_handle, 0, $array['delimiter']);
    }
    fclose($file_handle);
    return $line_of_text;
}


	
 public function updloaddata(Request $request)
    {
		
        $request->file->move(public_path('file'), "contacts.csv");
		
		//dd('');
		$csvFileName = "contacts.csv";
$csvFile = public_path('file/' . $csvFileName);
//dd($this->readCSV($csvFile,array('delimiter' => ';')));
$taille_array=sizeof($this->readCSV($csvFile,array('delimiter' => ';')));

$time=	
number_format((($taille_array / 100) / 60), 2);

//dd($taille_array);

    return back()
            ->with('message','You have successfully upload file | '.$taille_array.' Contact(s)')
            ->with('taille',$time);

		
	}
	
	 public function cron()
    {	
		$contacts = DB::select('SELECT * FROM cron_contact where etat=0');
		$i;
		$users0 = DB::table('cron_mail')->first();
	$token = $users0->token;
	if($users0->etat==0){
		foreach($contacts as $r){
			if($i % 100 == 0) sleep(5);

			
			 //{"name": "Ben Haggerty", "groups": [], "urns": ["tel:+250788123123"]}
			 
		//	 $myBody['name'] = "Demo";
   // $request = $client->post($url,  ['body'=>$myBody]);
   // $response = $request->send();
	
	//debut
		try {

    
	  
	$client = new Client(['base_uri' => 'https://sms.diwan.ly/api/v2/']);
		
		$headers = [
			'Authorization' => 'Token ' . $token,        
			'Accept'        => 'application/json',
		];
			//dd($r);
		 $myBody['name'] = $r->name;
		 $myBody['urns'] = array("tel:+".$r->urns);
		 $myBody['groups'] = $users0->uuid;


		$response = $client->request('POST', 'contacts.json', [
		'timeout' => 0,
		'connect_timeout ' => 10000,
        'headers' => $headers,
		'form_params' => $myBody,
		]);
		//  dd( $response);

		
	
	DB::table('cron_contact')->where('id',$r->id)->update(array(
                                 'etat'=>1));
								 
								 
    // Here the code for successful request

} catch (RequestException $e) {

    // Catch all 4XX errors 
    
    // To catch exactly error 400 use 
    if ($e->hasResponse()){
        if ($e->getResponse()->getStatusCode() == '400') {
              DB::table('cron_contact')->where('id',$r->id)->update(array(
                                 'etat'=>1));
				
        }
    }

    // You can check for whatever error status code you need 
    
} catch (\Exception $e) {

    // There was another exception.

}
	//fin
		//dd($users0->uuid);
		




		$i++;

		//I want to be able to insert manually the limitation of the number of contacts they can upload that's why I put this command
		if($i==25000) break;
		}
			
	DB::table('cron_mail')->where('id',2)->update(array(
		'etat'=>1));

		$msg="All contacts are successfully upload in your rapidpro system";
		mail($users0->mail,"RAPIDPRO UPLOAD CONTACTS",$msg);

			}
	}
	
	
 public function submitdata(Request $request)
    {
		//email
		$mail=$request->input('mail');
		//DB::table('cron_mail')->delete();
		
		//cron_contact
		//name;urns
		
			 DB::table('cron_mail')->where('id',2)->update(array(
                                 'mail'=>$mail));
								 
							
		//dd('');
		$csvFileName = "contacts.csv";
$csvFile = public_path('file/' . $csvFileName);
//dd($this->readCSV($csvFile,array('delimiter' => ';')));
$taille_array=sizeof($this->readCSV($csvFile,array('delimiter' => ';')));

$a=0;
foreach ($this->readCSV($csvFile,array('delimiter' => ';')) as $value) {
 if($a>0){
 
  DB::insert('insert into cron_contact (name,urns) values (?,?)', [$value[0],$value[1]]);
 }
 $a++;
 
}

//dd($taille_array);
   return view('admin.done', $data);
   
		
	}

 public function store(Request $request)
    {
		
		//$client = new \Guzzle\Service\Client('https://sms.diwan.ly/api/v2/contacts.json');
		
		$token = $request->input('api_token');
		
		 DB::table('cron_mail')->where('id',2)->update(array(
                                 'token'=>$token));
								 
		//dd($token);
		$client = new Client(['base_uri' => 'https://sms.diwan.ly/api/v2/']);
		
		$headers = [
			'Authorization' => 'Token ' . $token,        
			'Accept'        => 'application/json',
		];
		
		$response = $client->request('GET', 'groups.json', [
        'headers' => $headers
		]);
		
		
	$body = $response->getBody();
	//dd($body);
	$body = json_decode($body);

$groups = $body->results;

 $data['title'] = 'LIST GROUPS';
 $data['activeMenu'] = 'dashboard';
		

$data['groups'] = $groups ;

        return view('admin.groups', $data);
		
	
		

}




 public function upload_contacts($uuid,$name)
    {
		
	
								 
 $data['title'] = 'UPLOAD CONTACT GROUP ';
 $data['activeMenu'] = 'dashboard';
 
 if($name=="0000"){
	 $limit=20;
	$uniq_id0=substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, $limit);
	
	 $limit2=5;
	$uniq_id02=substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, $limit2);
 $data['name'] = "Default_".$uniq_id02."_".date("d_m_Y ");
 
 DB::table('cron_mail')->where('id',2)->update(array(
                                 'uuid'=>$data['name']));
								 
								 $users0 = DB::table('cron_mail')->first();
	$token = $users0->token;

	//dd($token);
		$client = new Client(['base_uri' => 'https://sms.diwan.ly/api/v2/']);
		
		$headers = [
			'Authorization' => 'Token ' . $token,        
			'Accept'        => 'application/json',
		];
		
		 $myBody['name'] = $data['name'];



		$response = $client->request('GET', 'groups.json', [
        'headers' => $headers,
		'form_params' => $myBody
		]);
		
		
	$body = $response->getBody();

	$body = json_decode($body);

$groups_uuid = $body->results[0]->uuid;

		 DB::table('cron_mail')->where('id',2)->update(array(
                                 'uuid'=>$groups_uuid));	
 }
 else{
 $data['name'] = $name;
	 DB::table('cron_mail')->where('id',2)->update(array(
                                 'uuid'=>$uuid));	
		 
 }
			

        return view('admin.upload', $data);
		
	
		

}



}