<?php

namespace App\Http\Controllers;

use App\ApplicationSetting;
use App\EmailTempDetail;
use App\Employee;
use App\Http\Requests\EmployeeRequest;
use App\Role;
use App\User;
use Auth;
use DB;
use Hash;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function __construct(EmailController $email)
    {
        $this->email = $email;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!Auth::user()->can('create_employee') && !Auth::user()->can('view_employee') && !Auth::user()->can('edit_employee') && !Auth::user()->can('delete_employee')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Employees';
        $data['activeMenu'] = 'employee';

        $data['employees'] = Employee::orderBy('id', 'DESC')->get();

        return view('admin.employee.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        if (!Auth::user()->can('create_employee')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Create new employee';
        $data['activeMenu'] = 'employee';
        $data['roles'] = Role::select('id', 'name')->get();
        return view('admin.employee.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     * @param EmployeeRequest $request
     * @return void
     */
    public function store(EmployeeRequest $request, User $user)
    {
        if (!Auth::user()->can('create_employee')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $user->fill($request->all());
        $user->password = Hash::make($request->password);
        $user->user_type = 1; // Type = 1 for employee
        // Assign employee to a specific role.
        $user->assignRole($request->role);

        $filename = uniqid();
        if ($request->hasFile('profile_image')) {
            $extension = $request->file('profile_image')->getClientOriginalExtension();
            $request->file('profile_image')->move('public/uploads/users_profile', $filename . '.' . $extension);
            $user->profile_image = $filename . '.' . $extension;
        }

        $user->save();
        $employee = new Employee();
        $employee->user()->associate($user);
        $employee->save();

        activity()->log('User ' . Auth::user()->username . ' has created a employee name: ' . $request->first_name . ' ' . $request->last_name);

        $notification = array(
            'message' => 'New Employee has been created',
            'alert-type' => 'success'
        );

        /** ======== Mail process =======*/
        $member_name = $request->first_name . " " . $request->last_name;
        $loginURL = URL('login');
        $clickHereToLogin = '<a href="' . $loginURL . '">Click here to log in</a>';

        $applicationSetting = ApplicationSetting::find(1);
        $emailInfo = EmailTempDetail::where('temp_id', 7)->select('subject', 'body')->first();

        $subject = str_replace('{company_name}', $applicationSetting->company_name, $emailInfo->subject);

        $message = str_replace(
            array("{member_name}", "{company_name}", "{email}", "{password}", "{login_url}"),
            array($member_name, $applicationSetting->company_name, $request->email, $request->password, $clickHereToLogin),
            $emailInfo->body
        );

        //$this->email->sendGeneralMail($request->email, $subject, $message);
        /** ======== End Mail process =======*/

        return redirect('employee')->with($notification);

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (!Auth::user()->can('view_employee')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Employees Details';
        $data['activeMenu'] = 'employee';
        $data['employee'] = Employee::find($id);
        return view('admin.employee.view', $data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Auth::user()->can('edit_employee')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Edit Details';
        $data['activeMenu'] = 'employee';
        $data['employee'] = Employee::find($id);
        $data['roles'] = Role::select('id', 'name')->get();

        $user_id = $data['employee']->user_id;
        if (DB::table('model_has_roles')->where('model_id', $user_id)->count() > 0) {
            $selected_role = DB::table('model_has_roles')->where('model_id', $user_id)->first();
            $data['selected_role_id'] = $selected_role->role_id;
        } else {
            $data['selected_role_id'] = 0;
        }

        return view('admin.employee.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (!Auth::user()->can('edit_employee')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $user = User::find($request->user_id);
        $user->fill($request->all());
        //dd($request->user_id);

        DB::table('model_has_roles')->where('model_id', $user->id)->delete();
        $user->assignRole($request->role);

        $filename = uniqid();
        if ($request->hasFile('profile_image')) {
            $extension = $request->file('profile_image')->getClientOriginalExtension();
            $request->file('profile_image')->move('public/uploads/users_profile', $filename . '.' . $extension);
            $user->profile_image = $filename . '.' . $extension;
        }

        $user->save();

        activity()->log('User ' . Auth::user()->username . ' has updated a employee name: ' . $user->first_name . ' ' . $user->last_name);

        $notification = array(
            'message' => 'Successfully Save & Update',
            'alert-type' => 'info'
        );

        return redirect('employee')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     * @param User $employee
     * @return \Illuminate\Http\Response
     * @throws \Exception
     */
    public function destroy($id)
    {
        if (!Auth::user()->can('delete_employee')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $employee = Employee::find($id);
        if ($employee->id == Auth::user()->id) {
            return redirect()->back()->with('message', 'You can not delete yourself.');

        }

        $employee->delete();

        activity()->log('User ' . Auth::user()->username . ' has deleted a employee.');
        $notification = array(
            'message' => 'Employee has been deleted from system',
            'alert-type' => 'error'
        );
        return redirect()->back()->with($notification);
    }
}
