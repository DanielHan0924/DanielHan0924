<?php

namespace App\Http\Controllers;

use App\Account;
use App\ApplicationSetting;
use App\Backup;
use App\ColorTheme;
use App\Country;
use App\EmailConfig;
use App\Http\Requests\EmailConfigRequest;
use App\Http\Requests\SettingsRequest;
use App\Http\Requests\ThemeRequest;
use App\InvoicePaymentTerms;
use App\PaymentTerm;
use Auth;
use DB;
use Illuminate\Http\Request;
use Spatie;
use Validator;

class SettingsController extends Controller
{


    public function __construct(EmailController $email)
    {
        $this->email = $email;

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!Auth::user()->can('application_setting')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Application Settings';
        $data['activeMenu'] = 'application_settings';
        $data['theme'] = ColorTheme::find(1);
        $data['settings'] = ApplicationSetting::find(1);
        $data['countries'] = Country::all();
        $data['emailConfigData'] = EmailConfig::first();
        //$data['accounts'] = Account::all();
        $pref = DB::table('preferences')->where('category', 'preference')->get()->toArray();
        $data['prefData'] = $pref;


        return view('admin.configuration.application-settings', $data);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */

    public function savePreference(Request $request)
    {
        $post = $request->all();
        unset($post['_token']);


        if ($post['date_format'] == 0) {
            $post['date_format_type'] = 'yyyy' . $post['date_sepa'] . 'mm' . $post['date_sepa'] . 'dd';
        } elseif ($post['date_format'] == 1) {
            $post['date_format_type'] = 'dd' . $post['date_sepa'] . 'mm' . $post['date_sepa'] . 'yyyy';
        } elseif ($post['date_format'] == 2) {
            $post['date_format_type'] = 'mm' . $post['date_sepa'] . 'dd' . $post['date_sepa'] . 'yyyy';
        } elseif ($post['date_format'] == 3) {
            $post['date_format_type'] = 'dd' . $post['date_sepa'] . 'M' . $post['date_sepa'] . 'yyyy';
        } elseif ($post['date_format'] == 4) {
            $post['date_format_type'] = 'yyyy' . $post['date_sepa'] . 'M' . $post['date_sepa'] . 'dd';
        }

        $i = 0;
        foreach ($post as $key => $value) {
            $data[$i]['category'] = "preference";
            $data[$i]['field'] = $key;
            $data[$i]['value'] = $value;
            $i++;
        }

        $data = $data;
        array_unshift($data, "");
        unset($data[0]);
        //dd($data,1);
        $currData = DB::table('preferences')->where('category', "preference")->first();
        if (!empty($currData)) {
            for ($j = 1; $j <= 4; $j++) {
                //Preference::Where('field', $data[$j]['field'])->update($data[$j]);
                DB::table('preferences')->where('field', $data[$j]['field'])->update($data[$j]);
            }

            $notification = array(
                'message' => 'Application Preferences has been updated.',
                'alert-type' => 'info'
            );

            //Session::flash('success', trans('message.success.update_success'));
            return redirect()->route('settings.index')->with($notification);
        }

        if (!empty($data)) {

            //Preference::Insert($data);
            DB::table('preferences')->insert($data);

            //Session::flash('success', trans('message.success.save_success'));
            return redirect()->route('settings.index')->with($notification);
        }

    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit($id)
    {
        $data['title'] = 'Update application settings';
        $data['activeMenu'] = 'application_settings';
        $data['settings'] = ApplicationSetting::findOrFail($id);
        $data['countries'] = Country::all();

        return view('admin.configuration.company', $data);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param SettingsRequest $request
     * @return void
     */
    public function updateAppSettings(SettingsRequest $request)
    {
        $data = $request->all();
        unset($data['_token']);


        $settings = ApplicationSetting::where('id', 1)->first();
        $settings->fill($request->all());
        $filename = uniqid();

        if (!empty($settings)) {

            if ($request->hasFile('company_logo')) {
                $extension = $request->file('company_logo')->getClientOriginalExtension();
                $request->file('company_logo')->move('public/uploads/company_logo', $filename . '.' . $extension);
                $settings->company_logo = $filename . '.' . $extension;

            } else {
                $settings->company_logo = $request->company_logo_old;
            }
            $settings->save();
            //ApplicationSetting::where('id', 1)->update($data);
        } else {
            ApplicationSetting::insert($data);
        }
        $notification = array(
            'message' => 'Application settings has been updated',
            'alert-type' => 'info',
            'settings_data' => $request->all()
        );

        activity()->log('Application settings has been updated.');
        return response()->json($notification);

    }


    public function changeUiTheme()
    {
        $data['title'] = 'Change UI Color Scheme';
        $data['activeMenu'] = 'change_theme';
        $data['theme'] = ColorTheme::find(1);
        return view('admin.configuration.themes', $data);
    }

    /**
     * @param ThemeRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateTheme(ThemeRequest $request, $id)
    {
        $theme = ColorTheme::find($id);
        $theme->theme_name = $request->theme_name;
        $theme->save();

        $notification = array(
            'message' => 'UI theme changed. Refresh the page to see effect.',
            'alert-type' => 'info'
        );
        return response()->json($notification);

    }


    public function emailSettings()
    {

        $data['title'] = 'Email Settings';
        $data['activeMenu'] = 'email_settings';
        return view('admin.configuration.email', $data);
    }



    /**
     * @return \Illuminate\Http\RedirectResponse
     *
     * Backup database
     */

    public function backupDB()
    {
        $backup_name = backup_tables(env('DB_HOST'), env('DB_USERNAME'), env('DB_PASSWORD'), env('DB_DATABASE'));
        if ($backup_name != 0) {
            DB::table('backups')->insert(['name' => $backup_name, 'created_at' => date('Y-m-d H:i:s')]);

        }
        $notification = array(
            'message' => 'Database backup has been created',
            'alert-type' => 'success',
        );
        return redirect()->back()->with($notification);
    }


    public function backupList()
    {
        if (!Auth::user()->can('manage_database_backup')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Database backup lists';
        $data['activeMenu'] = 'backup_list';
        $data['backups'] = Backup::all();
        return view('admin.configuration.database-backup', $data);
    }

    public function deleteDatabaseBackup($id)
    {
        if (!Auth::user()->can('manage_database_backup')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $backup = Backup::find($id);
        $backup->delete();

        $notification = array(
            'message' => 'Database backup has been deleted',
            'alert-type' => 'error',
        );

        return redirect()->back()->with($notification);

    }


    public function downloadDatabaseBackup($id)
    {
        if (!Auth::user()->can('manage_database_backup')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $backup = Backup::where('id', $id)->first();
        $backupName = $backup->name;
        $file = storage_path('laravel-backups/' . $backupName);
        return response()->download($file, $backupName);
    }


    public function emailSaveConfig(EmailConfigRequest $request)
    {
        $data = $request->all();
        unset($data['_token']);
        $emailConfig = EmailConfig::where('id', '=', 1)->first();
        if (!empty($emailConfig)) {
            EmailConfig::where('id', '=', 1)->update($data);
        } else {
            EmailConfig::insert($data);
        }
        $notification = array(
            'message' => 'Email settings has been saved.',
            'alertType' => 'info',
        );
        return response()->json($notification);

    }





    /**
     * Test sending email using email config
     */

    public function testEmailConfig()
    {

        //return view('admin.emails.paymentReceipt');
        $this->email->sendEmail('shibly.phy@gmail.com', 'Thank you for your order !', 'Email send test');


    }

}
