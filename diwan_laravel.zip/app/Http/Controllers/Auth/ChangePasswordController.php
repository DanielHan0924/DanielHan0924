<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\EmailController;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class ChangePasswordController extends Controller
{
    public function __construct(EmailController $email)
    {
        $this->email = $email;
    }

    public function sendPasswordLink(Request $request)
    {
        if (User::where('email', $request->email)->count() > 0)
        {

            $resetPassword = DB::table('password_resets')->insert([
                'email' => $request->email,
                'token' => $request->_token
            ]);

            $url = URL('change-password/'.$request->_token);
            $subject = 'qBilling password recovery';
            $message = '<h2>Hi</h2>';
            $message .= '<p>We recently received a request to reset the password for your qBilling profile.</p>';
            $message .= 'To reset your password, please click <a href="'.$url.'" target="_blank"> this link </a> and you will be taken to a page where you can add a new password.';
            $message .='<br /> <br /> <strong>Thanks</strong><br /> qBilling';

            $this->email->sendResetPasswordLink($request->email, $subject, $message);

            return redirect()->back()->with('message', 'Reset password link send to your mail')->with('message_type', 'success');

        } else {
            return redirect()->back()->with('message', 'Invalid Email Address')->with('message_type', 'danger');
        }
    }

    public function changePassword($token)
    {
        if (DB::table('password_resets')->where('token', $token)->count() > 0)
        {
            return view('auth.passwords.change-password', compact('token'));
        } else {
            return redirect('login');
        }
    }

    public function updatePassword(Request $request)
    {
        $info = DB::table('password_resets')->where('token', $request->token)->first();
        $user = User::where('email', $info->email)->first();
        $user->password = bcrypt($request->password);
        $user->save();

        DB::table('password_resets')->where('token', $request->token)->delete();

        return redirect('login')->with('message', 'Password has been reset')->with('message_type', 'success');
    }
}
