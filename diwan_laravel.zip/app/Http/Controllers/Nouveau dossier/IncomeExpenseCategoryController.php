<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\TransactionCategory;
use Auth;
class IncomeExpenseCategoryController extends Controller
{
    public function index()
    {
        if (!Auth::user()->can('manage_income_expense_category'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Income Expense Categories';
        $data['activeMenu'] = 'IncomeExpenseCategory';
        $data['transactionCategories'] = TransactionCategory::all();
        return view('admin.transaction-category.index', $data);
    }

    public function store(Request $request)
    {
        TransactionCategory::create($request->all());
        return redirect()->back()->with('message', 'New account has been created');

    }

    public function edit($id)
    {
        return TransactionCategory::find($id)->toJson();
    }

    public function update(Request $request)
    {
        $category = TransactionCategory::find($request->id);
        $category->fill($request->all());
        $category->save();

        return redirect()->back()->with('message', 'Account details has been updated.');
    }


    public function delete($id)
    {
        $transactionCategory = TransactionCategory::find($id);
        $transactionCategory->delete();
        return redirect()->back()->with('message', 'Transaction category has been deleted.');
    }
}
