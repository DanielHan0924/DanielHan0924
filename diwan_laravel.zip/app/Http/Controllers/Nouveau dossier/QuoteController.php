<?php

namespace App\Http\Controllers;

use App\ApplicationSetting;
use App\InvoicePaymentTerms;
use App\ItemTaxType;
use App\PaymentTerm;
use App\Product;
use App\Quote;
use App\Quote_details;
use App\Sales_invoice;
use App\Sales_invoice_details;
use App\User;
use App\Warehouse;
use Illuminate\Http\Request;
use PDF;
use Auth;
use DB;

class QuoteController extends Controller
{
    public function __construct(EmailController $email)
    {
        $this->email = $email;

    }

    public function index()
    {
        if (!Auth::user()->can('create_quote') && !Auth::user()->can('view_quote') && !Auth::user()->can('edit_quote') && !Auth::user()->can('delete_quote') && !Auth::user()->can('convert_quote_to_invoice') )
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Manage Quote';
        $data['activeMenu'] = 'manage_quote';
        if(memberRole(Auth::user()->id) == "Business Owner")
        {
            $data['getQuotes'] = Quote::orderBy('id', 'DESC')->where('invoice_status', 0)->get();
        } else {
            $data['getQuotes'] = Quote::where('customer_id', Auth::user()->id)->orderBy('id', 'DESC')->where('invoice_status', 0)->get();
        }

        return view('admin.quote.index', $data);
    }

    public function create()
    {
        if (!Auth::user()->can('create_quote'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['title'] = 'Create Quote';
        $data['activeMenu'] = 'create_quote';
        $data['customerData'] = User::where('user_type', 0)->get();
        $data['payments'] = PaymentTerm::get();
        $data['paymentTerms'] = InvoicePaymentTerms::get();
        $data['GetWarehouses'] = Warehouse::orderBy('title', 'asc')->get();

        $taxTypeList = ItemTaxType::get();
        $taxOptions = '';
        $selectStart = "<select class='form-control taxList' name='tax_id[]'>";
        $selectEnd = "</select>";

        $selectStartCustom = "<select class='form-control taxListCustom' name='tax_id_custom[]'>";
        $selectEndCustom = "</select>";

        $selectStartItem = "<select class='form-control taxListCustom' name='item_tax_id[]'>";
        $selectEndItem = "</select>";


        foreach ($taxTypeList as $key => $value) {
            $taxOptions .= "<option value='" . $value->id . "' taxrate='" . $value->tax_rate . "'>" . $value->name . '(' . $value->tax_rate . ')' . "</option>";
        }
        $data['tax_type'] = $selectStart . $taxOptions . $selectEnd;
        $data['tax_type_custom'] = $selectStartCustom . $taxOptions . $selectEndCustom;
        $data['tax_type_item'] = $selectStartItem . $taxOptions . $selectEndItem;
        return view('admin.quote.create', $data);

    }

    public function store(Request $request)
    {

        if (!Auth::user()->can('create_quote'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        if (count($request->items_name) ==0 && count($request->custom_items_name) == 0)
        {
            $notification = array(
                'message' => 'Please Select Item',
                'alert-type' => 'info'
            );

            return redirect()->back()->withInput()->with($notification);
        }


        /** manage custom item*/
        $custom_items_name = $request->custom_items_name;
        $custom_items_qty = $request->custom_items_qty;
        $custom_items_rate = $request->custom_items_rate;
        $tax_id_custom = $request->tax_id_custom;
        $custom_items_discount = $request->custom_items_discount;
        $custom_items_amount = $request->custom_items_amount;
        $custom_item_info = [];
        $sl = 0;
        for ($i = 0; $i < count($custom_items_name); $i++) {
            if ($custom_items_name[$i] != '' AND $custom_items_qty[$i] != '' AND $custom_items_rate[$i] != '' AND $tax_id_custom[$i] != '' AND $custom_items_discount[$i] != '' AND $custom_items_amount[$i] != '') {
                $taxInfo = ItemTaxType::find($tax_id_custom[$i]);
                $item_total = $custom_items_amount[$i];
                $total_tax = ($item_total * $taxInfo->tax_rate) / 100;

                $custom_item_info[$sl]['custom_items_name'] = $custom_items_name[$i];
                $custom_item_info[$sl]['custom_items_qty'] = $custom_items_qty[$i];
                $custom_item_info[$sl]['custom_items_rate'] = number_format($custom_items_rate[$i], 2);
                $custom_item_info[$sl]['custom_tax_id_custom'] = $tax_id_custom[$i];
                $custom_item_info[$sl]['custom_items_discount'] = number_format($custom_items_discount[$i], 2);
                $custom_item_info[$sl]['custom_item_total_tax'] = number_format($total_tax, 2);
                $custom_item_info[$sl]['custom_items_amount'] = number_format($custom_items_amount[$i], 2);
                $sl++;
            }
        }
        /** end custom item*/

        $data = $request->all();
        $quote = new  Quote;
        $quote->fill($data);
        $quote->custom_item = json_encode($custom_item_info);
        $quote->invoice_date = DbDateFormat($request->invoice_date);
        $quote->invoice_status = 0;
        $quote->save(); // save sales invoice
        $quote_id = $quote->id; // latest invoice ID


        /** manage Inventory Item item*/
        $items_name = $request->items_name;
        $items_qty = $request->items_qty;
        $items_rate = $request->items_rate;
        $item_tax_id = $request->item_tax_id;
        $items_discount = $request->items_discount;
        $items_amount = $request->items_amount;

        for ($j = 0; $j < count($items_name); $j++) {
            if ($items_name[$j] != '' AND $items_qty[$j] != '' AND $items_rate[$j] != '' AND $item_tax_id[$j] != '' AND $items_discount[$j] != '' AND $items_amount[$j] != '') {

                $product = Product::where('product_name', $items_name[$j])->first();

                $itemTaxInfo = ItemTaxType::find($item_tax_id[$j]);
                $itemTotal = $items_amount[$j];
                $totalItemTax = ($itemTotal * $itemTaxInfo->tax_rate) / 100;

                $quoteDetails = new Quote_details;
                $quoteDetails->quote_id = $quote_id;
                $quoteDetails->product_id = $product->id;
                $quoteDetails->tax_id = $item_tax_id[$j];
                $quoteDetails->product_name = $items_name[$j];
                $quoteDetails->qty = $items_qty[$j];
                $quoteDetails->unit_price = $items_rate[$j];
                $quoteDetails->tax = $totalItemTax;
                $quoteDetails->discount = $items_discount[$j];
                $quoteDetails->unit_total_price = $items_amount[$j];
                $quoteDetails->save();
            }
        }
        /** end custom item*/

        activity()->log('User ' . Auth::user()->username . ' has created a quote ' . $request->reference);

        $notification = array(
            'message' => 'Sales quote created',
            'alert-type' => 'success'
        );
        return redirect('quote/view/' . $quote_id)->with($notification);

    }


    public function edit($id)
    {
        if (!Auth::user()->can('edit_quote'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['title'] = 'Edit Quote';
        $data['activeMenu'] = 'manage_quote';
        $data['customerData'] = User::where('user_type', 0)->get();
        $data['payments'] = PaymentTerm::get();
        $data['paymentTerms'] = InvoicePaymentTerms::get();
        $data['products'] = Product::all();
        $data['quote'] = Quote::find($id);

        $taxTypeList = ItemTaxType::get();
        $taxOptions = '';
        $selectStart = "<select class='form-control taxList' name='tax_id[]'>";
        $selectEnd = "</select>";

        $selectStartCustom = "<select class='form-control taxListCustom' name='tax_id_custom[]'>";
        $selectEndCustom = "</select>";

        $selectStartItem = "<select class='form-control taxListCustom' name='item_tax_id[]'>";
        $selectEndItem = "</select>";


        foreach ($taxTypeList as $key => $value) {
            $taxOptions .= "<option value='" . $value->id . "' taxrate='" . $value->tax_rate . "'>" . $value->name . '(' . $value->tax_rate . ')' . "</option>";
        }
        $data['tax_type'] = $selectStart . $taxOptions . $selectEnd;
        $data['tax_type_custom'] = $selectStartCustom . $taxOptions . $selectEndCustom;
        $data['tax_type_item'] = $selectStartItem . $taxOptions . $selectEndItem;
        $data['getTax'] = ItemTaxType::get();
        return view('admin.quote.edit', $data);
    }

    public function update(Request $request)
    {
        if (!Auth::user()->can('edit_quote'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        if (count($request->items_name) == 0 && count($request->custom_items_name) == 0)
        {
            $notification = array(
                'message' => 'Please Select Item',
                'alert-type' => 'info'
            );

            return redirect()->back()->withInput()->with($notification);
        }

        $quote = Quote::find($request->id);

        /** manage custom item*/
        $custom_items_name = $request->custom_items_name;
        $custom_items_qty = $request->custom_items_qty;
        $custom_items_rate = $request->custom_items_rate;
        $tax_id_custom = $request->tax_id_custom;
        $custom_items_discount = $request->custom_items_discount;
        $custom_items_amount = $request->custom_items_amount;
        $custom_item_info = [];
        $sl = 0;
        for ($i = 0; $i < count($custom_items_name); $i++) {
            if ($custom_items_name[$i] != '' AND $custom_items_qty[$i] != '' AND $custom_items_rate[$i] != '' AND $tax_id_custom[$i] != '' AND $custom_items_discount[$i] != '' AND $custom_items_amount[$i] != '') {
                $taxInfo = ItemTaxType::find($tax_id_custom[$i]);
                $item_total = $custom_items_amount[$i];


                $total_tax = ($item_total * $taxInfo->tax_rate) / 100;

                $custom_item_info[$sl]['custom_items_name'] = $custom_items_name[$i];
                $custom_item_info[$sl]['custom_items_qty'] = $custom_items_qty[$i];
                $custom_item_info[$sl]['custom_items_rate'] = number_format($custom_items_rate[$i], 2);
                $custom_item_info[$sl]['custom_tax_id_custom'] = $tax_id_custom[$i];
                $custom_item_info[$sl]['custom_items_discount'] = number_format($custom_items_discount[$i], 2);
                $custom_item_info[$sl]['custom_item_total_tax'] = number_format($total_tax, 2);
                $custom_item_info[$sl]['custom_items_amount'] = number_format($custom_items_amount[$i], 2);
                $sl++;
            }
        }
        /** end custom item*/

        $data = $request->all();
        $quote->fill($data);
        $quote->invoice_date = DbDateFormat($request->invoice_date);
        $quote->custom_item = json_encode($custom_item_info);
        $quote->save(); // save sales invoice


        /** manage Inventory Item item*/
        if (count($quote->quoteDetails)) {
            Quote_details::where('quote_id', $quote->id)->delete(); // old data

            $items_name = $request->items_name;
            $items_qty = $request->items_qty;
            $items_rate = $request->items_rate;
            $item_tax_id = $request->item_tax_id;
            $items_discount = $request->items_discount;
            $items_amount = $request->items_amount;

            for ($j = 0; $j < count($items_name); $j++) {
                if ($items_name[$j] != '' AND $items_qty[$j] != '' AND $items_rate[$j] != '' AND $item_tax_id[$j] != '' AND $items_discount[$j] != '' AND $items_amount[$j] != '') {

                    $product = Product::where('product_name', $items_name[$j])->first();

                    $itemTaxInfo = ItemTaxType::find($item_tax_id[$j]);
                    $itemTotal = $items_amount[$j];
                    $totalItemTax = ($itemTotal * $itemTaxInfo->tax_rate) / 100;

                    $quoteDetails = new Quote_details;
                    $quoteDetails->quote_id = $quote->id;
                    $quoteDetails->product_id = $product->id;
                    $quoteDetails->tax_id = $item_tax_id[$j];
                    $quoteDetails->product_name = $items_name[$j];
                    $quoteDetails->qty = $items_qty[$j];
                    $quoteDetails->unit_price = $items_rate[$j];
                    $quoteDetails->tax = $totalItemTax;
                    $quoteDetails->discount = $items_discount[$j];
                    $quoteDetails->unit_total_price = $items_amount[$j];
                    $quoteDetails->save();
                }
            }
        }
        /** end custom item*/




        activity()->log('User ' . Auth::user()->username . ' has updated a quote ' . $request->reference);

        $notification = array(
            'message' => 'Sales quote updated',
            'alert-type' => 'info'
        );
        return redirect('quote/view/' . $quote->id)->with($notification);

    }

    public function view($id)
    {

        if (!Auth::user()->can('view_quote'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['title'] = 'View Quote';
        $data['activeMenu'] = 'manage_quote';
        $data['quote'] = Quote::find($id);
        $data['company'] = ApplicationSetting::find(1);
        $data['emailInfo'] = DB::table('email_temp_details')->where(['temp_id' => 5,])->select('subject', 'body')->first();
        return view('admin.quote.view', $data);
    }



    public function emailQuoteInfo(Request $request)
    {
        $activeMenu = '';
        $quote = Quote::find($request->quote_id);
        $invoice_name = 'quote_' . time() . '.pdf';
        // make sure email invoice is checked.
        if ($request->invoice_pdf && $request->invoice_pdf == 'on') {
            $pdf = PDF::loadView('admin.quote.pdf', ['quote' => $quote, 'activeMenu' => $activeMenu]);
            $pdf->setPaper(array(0, 0, 750, 1060), 'portrait');
            $pdf->save(public_path() . '/uploads/quote/' . $invoice_name);
            $this->email->sendQuoteEmailWithAttachment($quote, $request->email, $request->subject, $request->message, $invoice_name);
        }

        return redirect()->back()->with('message', 'Quote has been sent to client.');
    }

    public function quoteDownload($id)
    {

        $activeMenu = '';
        $quote = Quote::find($id);
        $pdf = PDF::loadView('admin.quote.pdf', ['quote' => $quote, 'activeMenu' => $activeMenu]);
        return $pdf->download('quote-' . $id . '.pdf');
        return redirect()->back();
    }

    public function destroy($id)
    {
        if (!Auth::user()->can('delete_quote'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        Quote::where('id', $id)->delete();
        activity()->log('User ' . Auth::user()->username . ' has deleted a  quote');

        $notification = array(
            'message' => 'Quote has beeen deleted',
            'alert-type' => 'error'
        );

        return redirect()->back()->with($notification);
    }


    public function convertToInvoice($id)
    {
        if (!Auth::user()->can('convert_quote_to_invoice'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking



        $quote = Quote::find($id);
        $invoice = new  Sales_invoice;
        $invoice->customer_id = $quote->customer_id;
        $invoice->payment_method_id = $quote->payment_method_id;
        $invoice->payment_term_id = $quote->payment_term_id;
        $invoice->invoice_date = $quote->invoice_date;
        $invoice->reference = $quote->reference;
        $invoice->custom_item = $quote->custom_item;
        $invoice->order_note = $quote->order_note;
        $invoice->sub_total = $quote->sub_total;
        $invoice->total_tax = $quote->total_tax;
        $invoice->grand_total = $quote->grand_total;
        $invoice->total_paid = 0;
        $invoice->total_due = $quote->grand_total;
        $invoice->save(); // save sales invoice
        $invoice_id = $invoice->id; // latest invoice ID


        /** manage Inventory Item item*/

        if (count($quote->inventoryItem) > 0) {
            foreach ($quote->inventoryItem as $item) {

                $invoiceDetails = new Sales_invoice_details;
                $invoiceDetails->invoice_id = $invoice_id;
                $invoiceDetails->product_id = $item->product_id;
                $invoiceDetails->tax_id = $item->tax_id;
                $invoiceDetails->product_name = $item->product_name;
                $invoiceDetails->qty = $item->qty;
                $invoiceDetails->unit_price = $item->unit_price;
                $invoiceDetails->tax = $item->tax;
                $invoiceDetails->discount = $item->discount;
                $invoiceDetails->unit_total_price = $item->unit_total_price;
                $invoiceDetails->save();
            }
        }
        /** end Inventory item*/

        $quote->invoice_status = 1; // quote convert to invoice
        $quote->save();


        activity()->log('User ' . Auth::user()->username . ' has generate a invoice from Quotation ');

        $notification = array(
            'message' => 'Quotation Convert to Invoice',
            'alert-type' => 'info'
        );

        return redirect('invoice/view-sales-invoice/' . $invoice_id)->with($notification);

    }

}
