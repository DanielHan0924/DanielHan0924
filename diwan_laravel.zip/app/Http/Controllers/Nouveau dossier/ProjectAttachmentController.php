<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProjectAttachmentRequest;
use App\ProjectAttachment;
use Auth;
use File;

class ProjectAttachmentController extends Controller
{
    public function store(ProjectAttachmentRequest $request, ProjectAttachment $projectAttachment)
    {

        $filename = uniqid();
        $projectAttachment->fill($request->all());

        if ($request->hasFile('file')) {
            $extension = $request->file('file')->getClientOriginalExtension();
            $request->file('file')->move('public/uploads/attachment_files', $filename . '.' . $extension);
            $projectAttachment->file = $filename . '.' . $extension;
        }

        $projectAttachment->attachment_username = Auth::user()->username;

        $projectAttachment->save();

        $notification = array(
            'message' => 'A file has been added to this project',
            'alert-type' => 'success'
        );

        activity()->log(Auth::user()->username . ' has added ' . $filename . '.' . $extension . ' to this project');
        return redirect('/project/' . $request->input('project_id'))->with($notification);
    }

    public function destroy(ProjectAttachment $projectAttachment)
    {

        $id = $projectAttachment->project->id;
        File::delete('uploads/attachment_files/' . $projectAttachment->file);
        $projectAttachment->delete();

        activity()->log(Auth::user()->username . ' has deleted attachment');
        $notification = array(
            'message' => 'Attachment has been deleted',
            'alert-type' => 'error'
        );
        return redirect('/project/' . $id)->with($notification);


    }
}
