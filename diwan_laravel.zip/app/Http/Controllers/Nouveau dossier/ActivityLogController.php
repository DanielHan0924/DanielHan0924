<?php

namespace App\Http\Controllers;

use Spatie\Activitylog\Models\Activity;
use Auth;
class ActivityLogController extends Controller
{
    public function viewlog()
    {
        if (!Auth::user()->can('view_user_log'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['title'] = 'Activity Log';
        $data['activeMenu'] = 'activity_log';
        //$data['logs'] = Activity::all();
        return view('admin.configuration.activity', $data);
    }
}
