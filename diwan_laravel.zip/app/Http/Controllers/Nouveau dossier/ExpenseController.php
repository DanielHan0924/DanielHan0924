<?php

namespace App\Http\Controllers;

use App\Account;
use App\ApplicationSetting;
use App\Bank_tran;
use App\TransactionCategory;
use Auth;
use DB;
use File;
use Illuminate\Http\Request;

class ExpenseController extends Controller
{
    public function index()
    {
        if (!Auth::user()->can('create_expense') && !Auth::user()->can('view_expense') && !Auth::user()->can('delete_expense')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Expenses';
        $data['activeMenu'] = 'expenses';
        $data['bank_trans'] = Bank_tran::where('trans_type', 'expense')->orderBy('id', 'DESC')->get();
        $data['accounts'] = Account::all();
        $data['setting'] = ApplicationSetting::first();

        return view('admin.expense.index', $data);
    }


    public function addExpense()
    {
        if (!Auth::user()->can('create_expense')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Add New Expense';
        $data['activeMenu'] = 'expense';
        $data['accounts'] = Account::select('account_holder', 'id', 'account_number')->get();
        //dd($data['accounts']);
        $data['expenseCategories'] = TransactionCategory::Where('type', 'expense')->pluck('name', 'id');
        $data['payment_methods'] = DB::table('payment_terms')->pluck('name', 'id');
        return view('admin.expense.add', $data);
    }

    public function store(Request $request)
    {
        if (!Auth::user()->can('create_expense')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        if ($request->attachment) {
            $file = $request->attachment;
            $imgName = time() . '-' . $file->getClientOriginalName();
            $attachmentPath = $file->move('public/uploads/attachment_files', $imgName);
        } else {
            $attachmentPath = '';
        }


        /**
         * Update account balance for the selected account
         */

        $account = Account::findOrFail($request->account_no);
        $account->last_balance = $account->last_balance - $request->amount;
        $account->save();

        $bankTran = new Bank_tran();
        $bankTran->fill($request->all());
        $bankTran->amount = "-" . $request->amount;
        $bankTran->attachment = $attachmentPath;
        $bankTran->trans_type = "expense";
        $bankTran->person_id = Auth::user()->id;
        $bankTran->save();

        activity()->log(Auth::user()->username . ' has added a expense transaction ');
        $notification = array(
            'message' => 'Expense transaction has been added.',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);
    }

    public function edit($id)
    {

        $data['title'] = 'Edit Expense';
        $data['activeMenu'] = 'expense';
        $data['bankTran'] = Bank_tran::find($id);
        $data['accounts'] = Account::pluck('account_holder', 'id');
        $data['expenseCategories'] = TransactionCategory::Where('type', 'expense')->pluck('name', 'id');
        $data['payment_methods'] = DB::table('payment_terms')->pluck('name', 'id');
        return view('admin.expense.edit', $data);
    }

    public function update(Request $request)
    {


        if ($request->attachment) {
            File::delete($request->orgAttachment);
            $file = $request->attachment;
            $imgName = time() . '-' . $file->getClientOriginalName();
            $attachmentPath = $file->move('public/uploads/attachment_files', $imgName);
        } else {
            $attachmentPath = $request->orgAttachment;
        }


        $bankTran = Bank_tran::find($request->id);
        $bankTran->fill($request->all());
        $bankTran->amount = "-" . $request->amount;
        $bankTran->attachment = $attachmentPath;
        $bankTran->person_id = Auth::user()->id;
        $bankTran->save();

        activity()->log(Auth::user()->username . ' has update a expense transaction ');
        $notification = array(
            'message' => 'Expense has been updated.',
            'alert-type' => 'info'
        );

        return redirect('expenses')->with($notification);
    }

    public function delete($id)
    {
        if (!Auth::user()->can('delete_expense')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $bankTran = Bank_tran::find($id);
        if ($bankTran->attachment != '') {
            File::delete($bankTran->attachment);
        }

        Bank_tran::where('id', $id)->delete();

        activity()->log(Auth::user()->username . ' delete a expense transaction ');
        $notification = array(
            'message' => 'Transaction has been deleted.',
            'alert-type' => 'error'
        );
        return redirect('expenses')->with($notification);

    }
}
