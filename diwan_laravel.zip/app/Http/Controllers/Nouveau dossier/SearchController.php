<?php

namespace App\Http\Controllers;

use App\Account;
use App\Product;
use App\Sales_invoice;
use Illuminate\Http\Request;
use Spatie\Searchable\Search;

class SearchController extends Controller
{
    public function searchResult(Request $request)
    {
        $data['title'] = 'Search Results for ' . $request->q;
        $data['activeMenu'] = 'payments';

        $data['searchTerm'] = $request->q;
        $data['searchResults'] = (new Search())
            ->registerModel(Product::class, 'product_name')// Can be passed an array if search needs to be performed in multiple columns
            ->registerModel(Account::class, 'account_number')
            ->registerModel(Sales_invoice::class, 'reference')
            ->perform($request->q);

        $data['result'] = 'This is the search result page';
        return view('admin.search.index', $data);

    }
}
