<?php

namespace App\Http\Controllers;

use App\ApplicationSetting;
use App\Country;
use App\Customer;
use App\EmailTempDetail;
use App\Group;
use App\Http\Requests\CustomerRequest;
use App\Role;
use App\User;
use Auth;
use DB;
use Hash;

class CustomerController extends Controller
{
    public function __construct(EmailController $email)
    {
        $this->email = $email;
    }

    /**
     * Display a listing of the resource.
     *
     * @return void
     */

    public function index()
    {
        if (!Auth::user()->can('create_customer') && !Auth::user()->can('view_customer') && !Auth::user()->can('edit_customer') && !Auth::user()->can('delete_customer')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Customers';
        $data['activeMenu'] = 'customers';
        $data['customers'] = Customer::get();
        return view('admin.customer.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return void
     */
    public function create()
    {
        if (!Auth::user()->can('create_customer')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Add New Customer';
        $data['activeMenu'] = 'create_customer';
        $data['groups'] = Group::get();
        $data['countries'] = Country::get();
        $data['roles'] = Role::select('id', 'name')->get();
        return view('admin.customer.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param CustomerRequest $request
     * @return void
     */
    public function store(CustomerRequest $request)
    {

        if (!Auth::user()->can('create_customer')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        // Create an user first


        $user = new User;
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->username = $request->username;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->user_type = 0;
        // Assign employee to a specific role.
        $user->assignRole($request->role);
        $filename = uniqid();
        if ($request->hasFile('profile_image')) {
            $extension = $request->file('profile_image')->getClientOriginalExtension();
            $request->file('profile_image')->move('public/uploads/users_profile', $filename . '.' . $extension);
            $user->profile_image = $filename . '.' . $extension;
        }



        $user->save();

        if ($request->same_as_billing == 1) {
            $same_as_billing = 1;
            $s_name = $request->first_name . " " . $request->first_name;
            $s_phone = $request->phone;
            $s_address = strip_tags($request->address);
            $s_city = $request->city;
            $s_region = $request->region;
            $s_country_id = $request->country_id;
            $s_postbox = $request->postbox;
            $s_email = $request->email;
        } else {
            $same_as_billing = 0;
            $s_name = $request->s_name;
            $s_phone = $request->s_phone;
            $s_address = $request->s_address;
            $s_city = $request->s_city;
            $s_region = $request->s_region;
            $s_country_id = $request->s_country_id;
            $s_postbox = $request->s_postbox;
            $s_email = $request->s_email;
        }

        $customer = new Customer;
        $customer->user_id = User::all()->last()->id;
        $customer->phone = $request->phone;
        $customer->address = $request->address;
        $customer->city = $request->city;
        $customer->region = $request->region;
        $customer->country_id = $request->country_id;
        $customer->postbox = $request->postbox;
        $customer->email = $request->email;
        $customer->company = $request->company;
        $customer->tax_id = $request->tax_id;
        $customer->s_name = $s_name;
        $customer->s_phone = $s_phone;
        $customer->s_address = $s_address;
        $customer->s_city = $s_city;
        $customer->s_region = $s_region;
        $customer->s_country_id = $s_country_id;
        $customer->s_postbox = $s_postbox;
        $customer->s_email = $s_email;
        $customer->same_as_billing = $same_as_billing;

        activity()->log('User ' . Auth::user()->username . ' has created a customer name: ' . $request->username);

        $customer->save();

        /** ======== Mail process =======*/
        $member_name = $request->first_name . " " . $request->last_name;
        $loginURL = URL('login');
        $clickHereToLogin = '<a href="' . $loginURL . '">Click here to log in</a>';

        $applicationSetting = ApplicationSetting::find(1);
        $emailInfo = EmailTempDetail::where('temp_id', 7)->select('subject', 'body')->first();

        $subject = str_replace('{company_name}', $applicationSetting->company_name, $emailInfo->subject);

        $message = str_replace(
            array("{member_name}", "{company_name}", "{email}", "{password}", "{login_url}"),
            array($member_name, $applicationSetting->company_name, $request->email, $request->password, $clickHereToLogin),
            $emailInfo->body
        );

        //$this->email->sendGeneralMail($request->email, $subject, $message);
        /** ======== End Mail process =======*/


        $notification = array(
            'message' => 'Customer has been created.',
            'alert-type' => 'success'
        );

        return redirect('customer')->with($notification);

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function show($id)
    {
        if (!Auth::user()->can('view_customer')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['customer'] = Customer::find($id);
        $data['title'] = 'View Customer Details';
        $data['activeMenu'] = 'customers';
        return view('admin.customer.show', $data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function edit($id)
    {
        if (!Auth::user()->can('edit_customer')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['customer'] = Customer::find($id);
        $data['title'] = 'Edit Customer Info';
        $data['activeMenu'] = 'customers';
        $data['countries'] = Country::get();
        $data['roles'] = Role::select('id', 'name')->get();
        $user_id = $data['customer']->user_id;

        if (DB::table('model_has_roles')->where('model_id', $user_id)->count() > 0) {
            $selected_role = DB::table('model_has_roles')->where('model_id', $user_id)->first();
            $data['selected_role_id'] = $selected_role->role_id;
        } else {
            $data['selected_role_id'] = 0;
        }


        return view('admin.customer.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return void
     */
    public function update(CustomerRequest $request, $id)
    {

        if (!Auth::user()->can('edit_customer')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $customer = Customer::find($id);
        $user = $customer->user;

        if (User::where('id', '!=', $user->id)->where('email', $request->email)->count() > 0) {
            $notification = array(
                'message' => 'Email already exist',
                'alert-type' => 'info'
            );

            return redirect()->back()->with($notification);
        }

        if (User::where('id', '!=', $user->id)->where('username', $request->username)->count() > 0) {
            $notification = array(
                'message' => 'Username already exist',
                'alert-type' => 'info'
            );

            return redirect()->back()->with($notification);
        }

        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->username = $request->username;
        $user->email = $request->email;

        $user->user_type = 0;
        // Assign employee to a specific role.
        DB::table('model_has_roles')->where('model_id', $user->id)->delete();
        $user->assignRole($request->role);

        $filename = uniqid();
        if ($request->hasFile('profile_image')) {
            $extension = $request->file('profile_image')->getClientOriginalExtension();
            $request->file('profile_image')->move('public/uploads/users_profile', $filename . '.' . $extension);
            $user->profile_image = $filename . '.' . $extension;
        }


        $user->save();


        if ($request->same_as_billing == 1) {
            $same_as_billing = 1;
            $s_name = $request->first_name . " " . $request->last_name;
            $s_phone = $request->phone;
            $s_address = strip_tags($request->address);
            $s_city = $request->city;
            $s_region = $request->region;
            $s_country_id = $request->country_id;
            $s_postbox = $request->postbox;
            $s_email = $request->email;
        } else {
            $same_as_billing = 0;
            $s_name = $request->s_name;
            $s_phone = $request->s_phone;
            $s_address = $request->s_address;
            $s_city = $request->s_city;
            $s_region = $request->s_region;
            $s_country_id = $request->s_country_id;
            $s_postbox = $request->s_postbox;
            $s_email = $request->s_email;
        }


        $data = $request->all();
        $customer->fill($data);
        $customer->s_name = $s_name;
        $customer->s_phone = $s_phone;
        $customer->s_address = $s_address;
        $customer->s_city = $s_city;
        $customer->s_region = $s_region;
        $customer->s_country_id = $s_country_id;
        $customer->s_postbox = $s_postbox;
        $customer->s_email = $s_email;
        $customer->same_as_billing = $same_as_billing;
        $customer->save();

        activity()->log(Auth::user()->username . ' has update details for customer name ' . $s_name);
        $notification = array(
            'message' => 'Customer details has been updated',
            'alert-type' => 'success'
        );

        return redirect('customer')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return void
     */
    public function destroy($id)
    {
        if (!Auth::user()->can('delete_customer')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $customer = Customer::find($id);
        User::where('id', $customer->user_id)->delete();
        Customer::where('id', $id)->delete();

        $notification = array(
            'message' => 'Customer has been deleted.',
            'alert-type' => 'error'
        );

        return redirect()->back()->with($notification);
    }
}
