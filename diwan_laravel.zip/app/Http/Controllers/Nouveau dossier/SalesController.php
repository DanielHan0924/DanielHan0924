<?php

namespace App\Http\Controllers;

use App\ApplicationSetting;
use App\InvoicePaymentTerms;
use App\ItemTaxType;
use App\Payment;
use App\PaymentTerm;
use App\Product;
use App\Sales_invoice;
use App\Sales_invoice_details;
use App\User;
use App\Warehouse;
use Auth;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;
use PDF;


class SalesController extends Controller
{


    public function __construct(EmailController $email)
    {
        $this->email = $email;
    }

    public function index()
    {

        if (!Auth::user()->can('create_sales_invoice') && !Auth::user()->can('view_sales_invoice') && !Auth::user()->can('edit_sales_invoice') && !Auth::user()->can('delete_sales_invoice')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['title'] = 'Manage Sales Invoice';
        $data['activeMenu'] = 'manage_sales_invoice';

        if(memberRole(Auth::user()->id) == "Business Owner")
        {
            $data['salesInvoices'] = Sales_invoice::orderBy('id', 'DESC')->get();
            $data['todayInvoice'] = count(Sales_invoice::whereDate('created_at', Carbon::today())->get());
            $data['todayInvoiceSum'] = Sales_invoice::whereDate('created_at', Carbon::today())->sum('grand_total');
            $currentMonth = date('m');
            $data['currentMonthInvoice'] = count(DB::table("sales_invoices")
                ->whereRaw('MONTH(created_at) = ?', [$currentMonth])
                ->get());

            $data['thisMonthInvoiceSale'] = DB::table("sales_invoices")
                ->whereRaw('MONTH(created_at) = ?', [$currentMonth])
                ->sum('grand_total');
        } else {

            $data['salesInvoices'] = Sales_invoice::where('customer_id', Auth::user()->id)->orderBy('id', 'DESC')->get();
            $data['todayInvoice'] = count(Sales_invoice::where('customer_id', Auth::user()->id)->whereDate('created_at', Carbon::today())->get());
            $data['todayInvoiceSum'] = Sales_invoice::where('customer_id', Auth::user()->id)->whereDate('created_at', Carbon::today())->sum('grand_total');
            $currentMonth = date('m');
            $data['currentMonthInvoice'] = count(DB::table("sales_invoices")
                ->where('customer_id', Auth::user()->id)
                ->whereRaw('MONTH(created_at) = ?', [$currentMonth])
                ->get());

            $data['thisMonthInvoiceSale'] = DB::table("sales_invoices")
                ->whereRaw('MONTH(created_at) = ?', [$currentMonth])
                ->sum('grand_total');
        }

        return view('admin.sales-invoice.index', $data);

    }

    public function create()
    {

        if (!Auth::user()->can('create_sales_invoice')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Create sales invoice';
        $data['activeMenu'] = 'create_sales_invoice';
        $data['customerData'] = User::where('user_type', 0)->get();


        $data['payments'] = PaymentTerm::get();
        $data['paymentTerms'] = InvoicePaymentTerms::get();
        $data['GetWarehouses'] = Warehouse::orderBy('title', 'asc')->get();
        $data['invoice_count'] = DB::table('sales_invoices')->max('id');

        $taxTypeList = ItemTaxType::get();
        $taxOptions = '';
        $selectStart = "<select class='form-control taxList' name='tax_id[]'>";
        $selectEnd = "</select>";

        $selectStartCustom = "<select class='form-control taxListCustom' name='tax_id_custom[]'>";
        $selectEndCustom = "</select>";

        $selectStartItem = "<select class='form-control taxListCustom' name='item_tax_id[]'>";
        $selectEndItem = "</select>";


        foreach ($taxTypeList as $key => $value) {
            $taxOptions .= "<option value='" . $value->id . "' taxrate='" . $value->tax_rate . "'>" . $value->name . '(' . $value->tax_rate . ')' . "</option>";
        }
        $data['tax_type'] = $selectStart . $taxOptions . $selectEnd;
        $data['tax_type_custom'] = $selectStartCustom . $taxOptions . $selectEndCustom;
        $data['tax_type_item'] = $selectStartItem . $taxOptions . $selectEndItem;
        return view('admin.sales-invoice.create', $data);

    }


    public function store(Request $request)
    {

        if (!Auth::user()->can('create_sales_invoice')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        /** manage custom item*/

        if (count($request->items_name) ==0 && count($request->custom_items_name) == 0)
        {
            $notification = array(
                'message' => 'Please Select Item',
                'alert-type' => 'info'
            );
            return redirect()->back()->withInput()->with($notification);
        }

        $custom_items_name = $request->custom_items_name;
        $custom_items_qty = $request->custom_items_qty;
        $custom_items_rate = $request->custom_items_rate;
        $tax_id_custom = $request->tax_id_custom;
        $custom_items_discount = $request->custom_items_discount;
        $custom_items_amount = $request->custom_items_amount;
        $custom_item_info = [];
        $sl = 0;
        for ($i = 0; $i < count($custom_items_name); $i++) {
            if ($custom_items_name[$i] != '' AND $custom_items_qty[$i] != '' AND $custom_items_rate[$i] != '' AND $tax_id_custom[$i] != '' AND $custom_items_discount[$i] != '' AND $custom_items_amount[$i] != '') {
                $taxInfo = ItemTaxType::find($tax_id_custom[$i]);
                $item_total = $custom_items_amount[$i];
                $total_tax = ($item_total * $taxInfo->tax_rate) / 100;

                $custom_item_info[$sl]['custom_items_name'] = $custom_items_name[$i];
                $custom_item_info[$sl]['custom_items_qty'] = $custom_items_qty[$i];
                $custom_item_info[$sl]['custom_items_rate'] = number_format($custom_items_rate[$i], 2);
                $custom_item_info[$sl]['custom_tax_id_custom'] = $tax_id_custom[$i];
                $custom_item_info[$sl]['custom_items_discount'] = number_format($custom_items_discount[$i], 2);
                $custom_item_info[$sl]['custom_item_total_tax'] = number_format($total_tax, 2);
                $custom_item_info[$sl]['custom_items_amount'] = number_format($custom_items_amount[$i], 2);
                $sl++;
            }
        }
        /** end custom item*/

        $data = $request->all();
        $invoice = new  Sales_invoice;
        $invoice->fill($data);
        $invoice->custom_item = json_encode($custom_item_info);
        $invoice->total_paid = 0;
        $invoice->sub_total = $request->grand_total;
        $invoice->total_due = $request->grand_total;
        $invoice->invoice_date = DbDateFormat($request->invoice_date);
        $invoice->save(); // save sales invoice
        $invoice_id = $invoice->id; // latest invoice ID

        /** manage Inventory Item item*/
        $items_name = $request->items_name;
        $items_qty = $request->items_qty;
        $items_rate = $request->items_rate;
        $item_tax_id = $request->item_tax_id;
        $items_discount = $request->items_discount;
        $items_amount = $request->items_amount;

        for ($j = 0; $j < count($items_name); $j++) {
            if ($items_name[$j] != '' AND $items_qty[$j] != '' AND $items_rate[$j] != '' AND $item_tax_id[$j] != '' AND $items_discount[$j] != '' AND $items_amount[$j] != '') {

                $product = Product::where('product_name', $items_name[$j])->first();

                $itemTaxInfo = ItemTaxType::find($item_tax_id[$j]);
                $itemTotal = $items_amount[$j];
                $totalItemTax = ($itemTotal * $itemTaxInfo->tax_rate) / 100;

                $invoiceDetails = new Sales_invoice_details;
                $invoiceDetails->invoice_id = $invoice_id;
                $invoiceDetails->product_id = $product->id;
                $invoiceDetails->tax_id = $item_tax_id[$j];
                $invoiceDetails->product_name = $items_name[$j];
                $invoiceDetails->qty = $items_qty[$j];
                $invoiceDetails->unit_price = $items_rate[$j];
                $invoiceDetails->tax = $totalItemTax;
                $invoiceDetails->discount = $items_discount[$j];
                $invoiceDetails->unit_total_price = $items_amount[$j];
                $invoiceDetails->save();
            }
        }
        /** end custom item*/


        activity()->log('User ' . Auth::user()->username . ' has sales invoice created');

        $notification = array(
            'message' => 'Sales Invoice Created',
            'alert-type' => 'success'
        );
        return redirect('invoice/view-sales-invoice/' . $invoice_id)->with($notification);
    }


    public function view($id)
    {
        if (!Auth::user()->can('view_sales_invoice')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'View Invoice';
        $data['activeMenu'] = 'manage_sales_invoice';
        $data['invoice'] = Sales_invoice::find($id);
        $data['company'] = ApplicationSetting::find(1);
        $data['payments'] = Payment::where('invoice_id', $id)->get();

        // Load sales invoice template from database and push object to view.
        $data['emailInfo'] = DB::table('email_temp_details')->where(['temp_id' => 4,])->select('subject', 'body')->first();

        return view('admin.sales-invoice.view', $data);
    }

    /**
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response
     */
    public function invoiceDownload($id)
    {
        if (!Auth::user()->can('view_sales_invoice')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $activeMenu = '';
        $invoice = Sales_invoice::find($id);
        //return view('admin.payment.download-invoice');
        $pdf = PDF::loadView('admin.sales-invoice.pdf', ['invoice' => $invoice, 'activeMenu' => $activeMenu]);
        return $pdf->download('invoice-' . $id . '.pdf');
        return redirect()->back();
    }


    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function sendInvoiceInformationByEmail(Request $request)
    {

        $activeMenu = '';
        $invoice = Sales_invoice::find($request->invoice_id);
        $invoice_name = 'invoice_' . time() . '.pdf';
        // make sure email invoice is checked.
        if ($request->invoice_pdf && $request->invoice_pdf == 'on') {
            $pdf = PDF::loadView('admin.sales-invoice.pdf', ['invoice' => $invoice, 'activeMenu' => $activeMenu]);
            $pdf->setPaper(array(0, 0, 750, 1060), 'portrait');
            $pdf->save(public_path() . '/uploads/invoices/' . $invoice_name);
            $this->email->sendEmailWithAttachment($invoice, $request->email, $request->subject, $request->message, $invoice_name);
        }

        return redirect()->back()->with('message', 'Order invoice with attachment has been sent to client.');

    }


    public function edit($id)
    {

        if (!Auth::user()->can('edit_sales_invoice')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Edit sales invoice';
        $data['activeMenu'] = 'manage_sales_invoice';
        $data['customerData'] = User::where('user_type', 0)->get();
        $data['payments'] = PaymentTerm::get();
        $data['paymentTerms'] = InvoicePaymentTerms::get();
        $data['products'] = Product::all();
        $data['invoice'] = Sales_invoice::find($id);

        $taxTypeList = ItemTaxType::get();
        $taxOptions = '';
        $selectStart = "<select class='form-control taxList' name='tax_id[]'>";
        $selectEnd = "</select>";

        $selectStartCustom = "<select class='form-control taxListCustom' name='tax_id_custom[]'>";
        $selectEndCustom = "</select>";

        $selectStartItem = "<select class='form-control taxListCustom' name='item_tax_id[]'>";
        $selectEndItem = "</select>";


        foreach ($taxTypeList as $key => $value) {
            $taxOptions .= "<option value='" . $value->id . "' taxrate='" . $value->tax_rate . "'>" . $value->name . '(' . $value->tax_rate . ')' . "</option>";
        }
        $data['tax_type'] = $selectStart . $taxOptions . $selectEnd;
        $data['tax_type_custom'] = $selectStartCustom . $taxOptions . $selectEndCustom;
        $data['tax_type_item'] = $selectStartItem . $taxOptions . $selectEndItem;
        $data['getTax'] = ItemTaxType::get();
        return view('admin.sales-invoice.edit', $data);
    }

    public function update(Request $request)
    {
        if (!Auth::user()->can('edit_sales_invoice')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        if (count($request->items_name) ==0 && count($request->custom_items_name) == 0)
        {
            $notification = array(
                'message' => 'Please Select Item',
                'alert-type' => 'info'
            );
            return redirect()->back()->with($notification);
        }

        $invoice = Sales_invoice::find($request->id);

        /** manage custom item*/
        $custom_items_name = $request->custom_items_name;
        $custom_items_qty = $request->custom_items_qty;
        $custom_items_rate = $request->custom_items_rate;
        $tax_id_custom = $request->tax_id_custom;
        $custom_items_discount = $request->custom_items_discount;
        $custom_items_amount = $request->custom_items_amount;
        $custom_item_info = [];
        $sl = 0;
        for ($i = 0; $i < count($custom_items_name); $i++) {
            if ($custom_items_name[$i] != '' AND $custom_items_qty[$i] != '' AND $custom_items_rate[$i] != '' AND $tax_id_custom[$i] != '' AND $custom_items_discount[$i] != '' AND $custom_items_amount[$i] != '') {
                $taxInfo = ItemTaxType::find($tax_id_custom[$i]);


                $item_total = $custom_items_amount[$i];

                $total_tax = ($item_total * $taxInfo->tax_rate) / 100;

                $custom_item_info[$sl]['custom_items_name'] = $custom_items_name[$i];
                $custom_item_info[$sl]['custom_items_qty'] = $custom_items_qty[$i];
                $custom_item_info[$sl]['custom_items_rate'] = number_format($custom_items_rate[$i], 2);
                $custom_item_info[$sl]['custom_tax_id_custom'] = $tax_id_custom[$i];
                $custom_item_info[$sl]['custom_items_discount'] = number_format($custom_items_discount[$i], 2);
                $custom_item_info[$sl]['custom_item_total_tax'] = number_format($total_tax, 2);
                $custom_item_info[$sl]['custom_items_amount'] = number_format($custom_items_amount[$i], 2);
                $sl++;
            }
        }
        /** end custom item*/

        $data = $request->all();
        $invoice->fill($data);
        $invoice->invoice_date = DbDateFormat($request->invoice_date);
        $invoice->custom_item = json_encode($custom_item_info);
        $invoice->save(); // save sales invoice


        /** manage Inventory Item item*/
        if (count($invoice->salesInvoiceDetails)) {
            Sales_invoice_details::where('invoice_id', $invoice->id)->delete(); // old data

            $items_name = $request->items_name;
            $items_qty = $request->items_qty;
            $items_rate = $request->items_rate;
            $item_tax_id = $request->item_tax_id;
            $items_discount = $request->items_discount;
            $items_amount = $request->items_amount;

            for ($j = 0; $j < count($items_name); $j++) {
                if ($items_name[$j] != '' AND $items_qty[$j] != '' AND $items_rate[$j] != '' AND $item_tax_id[$j] != '' AND $items_discount[$j] != '' AND $items_amount[$j] != '') {

                    $product = Product::where('product_name', $items_name[$j])->first();

                    $itemTaxInfo = ItemTaxType::find($item_tax_id[$j]);
                    $itemTotal = $items_amount[$j];
                    $totalItemTax = ($itemTotal * $itemTaxInfo->tax_rate) / 100;

                    $invoiceDetails = new Sales_invoice_details;
                    $invoiceDetails->invoice_id = $invoice->id;
                    $invoiceDetails->product_id = $product->id;
                    $invoiceDetails->tax_id = $item_tax_id[$j];
                    $invoiceDetails->product_name = $items_name[$j];
                    $invoiceDetails->qty = $items_qty[$j];
                    $invoiceDetails->unit_price = $items_rate[$j];
                    $invoiceDetails->tax = $totalItemTax;
                    $invoiceDetails->discount = $items_discount[$j];
                    $invoiceDetails->unit_total_price = $items_amount[$j];
                    $invoiceDetails->save();
                }
            }
        }
        /** end custom item*/


        activity()->log('User ' . Auth::user()->username . ' has sales invoice update:');
        $notification = array(
            'message' => 'Invoice Save & Updated',
            'alert-type' => 'info'
        );

        return redirect('invoice/view-sales-invoice/' . $invoice->id)->with($notification);


    }

    public function destroy($id)
    {
        if (!Auth::user()->can('delete_sales_invoice')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        Sales_invoice::where('id', $id)->delete();
        activity()->log('User ' . Auth::user()->username . ' has delete sales invoice:');
        $notification = array(
            'message' => 'Invoice hsa been deleted',
            'alert-type' => 'error'
        );


        return redirect()->back()->with($notification);
    }


    public function getItem($item_id)
    {
        return Product::find($item_id)->toJson();
    }

    public function getInventoryItem($warehouse_id)
    {
        return Product::where('warehouse_id', $warehouse_id)->orderBy('product_name', 'asc')->select('id', 'product_name')->get()->toJson();
    }

}
