<?php

namespace App\Http\Controllers;

use App\Category;
use App\Http\Requests\CategoryRequest;
use Auth;
use Redirect;
use Entrust;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index()
    {
        if (!Auth::user()->can('create_category') && !Auth::user()->can('edit_category') && !Auth::user()->can('delete_category') )
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Categories';
        $data['categories'] = Category::all();
        $data['activeMenu'] = 'categories';

        return view('admin.category.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return void
     */
    public function create()
    {
        if (!Auth::user()->can('create_category'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['activeMenu'] = 'categories';
        $data['title'] = 'Create Category';
        return view('admin.category.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param CategoryRequest $request
     * @return void
     */
    public function store(CategoryRequest $request, Category $category)
    {
        if (!Auth::user()->can('create_category'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        Category::create($request->all());
        activity()->performedOn($category)->log(Auth::user()->full_name . ' has created a category name ' . $request->title);
        $notification = array(
            'message' => 'Category has been created',
            'alert-type' => 'success'
        );
        return redirect()->route('category.create')->with($notification);

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function edit($id)
    {
        if (!Auth::user()->can('edit_category'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Edit Category';
        $data['activeMenu'] = 'categories';
        $data['category'] = Category::find($id);
        return view('admin.category.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param CategoryRequest $request
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(CategoryRequest $request, $id)
    {
        if (!Auth::user()->can('edit_category'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $category = Category::find($id);
        $category->title = $request->title;
        $category->description = $request->description;
        activity()->performedOn($category)->log(Auth::user()->full_name . ' has updated a category name ' . $request->title);
        $category->save();
        $notification = array(
            'message' => 'Category name has been updated',
            'alert-type' => 'info'
        );
        return Redirect::to('category')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        if (!Auth::user()->can('delete_category'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $category = Category::find($id);
        $category->delete();
        activity()->performedOn($category)->log(Auth::user()->full_name . ' has created a category name ' . $category->title);
        $notification = array(
            'message' => 'Category has been removed',
            'alert-type' => 'warning'
        );
        return Redirect::to('category')->with($notification);
    }
}
