<?php

namespace App\Http\Controllers;

use App\Account;
use App\Bank_tran;
use App\InvoicePaymentTerms;
use App\ItemTaxType;
use App\PaymentTerm;
use App\Product;
use App\Purchase_invoice;
use App\Purchase_invoice_details;
use App\Transaction;
use App\User;
use App\Warehouse;
use Auth;
use Illuminate\Http\Request;
use PDF;
use DB;

class PurchaseController extends Controller
{
    public function index()
    {

        if (!Auth::user()->can('create_purchase_order') && !Auth::user()->can('view_purchase_order') && !Auth::user()->can('edit_purchase_order') && !Auth::user()->can('delete_purchase_order') )
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Manage Purchase Invoice';
        $data['activeMenu'] = 'manage_purchase';

        if(memberRole(Auth::user()->id) == "Business Owner")
        {
            $data['getPurchaseInvoice'] = Purchase_invoice::orderBy('id', 'DESC')->get();
        } else {
            $data['getPurchaseInvoice'] = Purchase_invoice::where('supplier_id', Auth::user()->id)->orderBy('id', 'DESC')->get();
        }

        return view('admin.purchase.index', $data);
    }

    public function create()
    {

        if (!Auth::user()->can('create_purchase_order'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Create Purchase Order';
        $data['activeMenu'] = 'create_purchase_order';
        $data['supplierData'] = User::where('user_type', 3)->get();
        $data['payments'] = PaymentTerm::get();
        $data['paymentTerms'] = InvoicePaymentTerms::get();
        $data['products'] = Product::all();
        $data['invoice_count'] = DB::table('purchase_invoices')->max('id');

        $taxTypeList = ItemTaxType::get();
        $taxOptions = '';
        $selectStart = "<select class='form-control taxList' name='tax_id[]'>";
        $selectEnd = "</select>";

        $selectStartCustom = "<select class='form-control taxListCustom' name='tax_id_custom[]'>";
        $selectEndCustom = "</select>";

        $selectStartItem = "<select class='form-control taxListCustom' name='item_tax_id[]'>";
        $selectEndItem = "</select>";


        foreach ($taxTypeList as $key => $value) {
            $taxOptions .= "<option value='" . $value->id . "' taxrate='" . $value->tax_rate . "'>" . $value->name . '(' . $value->tax_rate . ')' . "</option>";
        }



        $data['warehouses'] = Warehouse::all();
        $data['tax_type'] = $selectStart . $taxOptions . $selectEnd;
        $data['tax_type_custom'] = $selectStartCustom . $taxOptions . $selectEndCustom;
        $data['tax_type_item'] = $selectStartItem . $taxOptions . $selectEndItem;

        $data['accounts'] = Account::all();

        return view('admin.purchase.create', $data);
    }

    public function store(Request $request)
    {

        if (!Auth::user()->can('create_purchase_order'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $items_name = $request->items_name;
        if (count($items_name) > 0) {
            $data = $request->all();
            $purchaseInvoice = new  Purchase_invoice;
            $purchaseInvoice->fill($data);
            $purchaseInvoice->invoice_date = DbDateFormat($request->invoice_date);
            $purchaseInvoice->save(); // save purchase invoice
            $purchase_id = $purchaseInvoice->id; // latest invoice ID




            /** ======= Manage Account ======= */
                $account = Account::findOrFail($request->account_id);

            if ($request->note != '') {
                $description = $request->note;
            } else {
                $description = '';
            }
                $creditTransition = new Transaction;
                $creditTransition->customer_name = $purchaseInvoice->user->getFullNameAttribute();
                $creditTransition->debit = 0.00;
                $creditTransition->credit = $request->grand_total;
                $creditTransition->type = 'Expense';
                $creditTransition->account_id = $request->account_id; // account id 4 is sales account
                $creditTransition->date = DbDateFormat($request->invoice_date);
                $creditTransition->note = $description;
                $creditTransition->transaction_category_name = $purchaseInvoice->paymentMethod->name;
                $creditTransition->pay_method = $purchaseInvoice->paymentMethod->name;
                $creditTransition->save(); // save Credit Transition




                $bankTran = new Bank_tran();
                $bankTran->account_no = $request->account_id;
                $bankTran->category_id = 4; // id 4 is purchase category
                $bankTran->payment_method = $request->payment_method_id;
                $bankTran->amount = "-" . $request->grand_total;
                $bankTran->trans_type = "expense";
                $bankTran->trans_date = DbDateFormat($request->invoice_date);
                $bankTran->person_id = Auth::user()->id;
                $bankTran->reference = "INV-" . $request->reference;
                $bankTran->description = $description;
                $bankTran->save();


                // Update last balance for the selected account
                $account->last_balance = $account->last_balance - $request->grand_total;
                $account->save();

            /** ====== End manage account ===== */



            /** manage Inventory Item item*/
            $items_name = $request->items_name;
            $items_qty = $request->items_qty;
            $items_rate = $request->items_rate;
            $item_tax_id = $request->item_tax_id;
            $items_discount = $request->items_discount;
            $items_amount = $request->items_amount;
            for ($j = 0; $j < count($items_name); $j++) {
                if ($items_name[$j] != '' AND $items_qty[$j] != '' AND $items_rate[$j] != '' AND $item_tax_id[$j] != '' AND $items_discount[$j] != '' AND $items_amount[$j] != '') {

                    $product = Product::where('product_name', $items_name[$j])->first();

                    $itemTaxInfo = ItemTaxType::find($item_tax_id[$j]);
                    $itemTotal = $items_amount[$j];
                    $totalItemTax = ($itemTotal * $itemTaxInfo->tax_rate) / 100;

                    $purchaseInvoiceDetails = new Purchase_invoice_details;
                    $purchaseInvoiceDetails->invoice_id = $purchase_id;
                    $purchaseInvoiceDetails->product_id = $product->id;
                    $purchaseInvoiceDetails->tax_id = $item_tax_id[$j];
                    $purchaseInvoiceDetails->product_name = $items_name[$j];

                    $purchaseInvoiceDetails->qty = $items_qty[$j];
                    $purchaseInvoiceDetails->unit_price = $items_rate[$j];
                    $purchaseInvoiceDetails->tax = $totalItemTax;
                    $purchaseInvoiceDetails->discount = $items_discount[$j];
                    $purchaseInvoiceDetails->unit_total_price = $items_amount[$j];
                    $purchaseInvoiceDetails->save();

                    /** ========= update stock ======== */

                    $product->product_quantity = $product->product_quantity + $items_qty[$j];
                    $product->save();

                }
            }
            /** end custom item*/

            activity()->log('User ' . Auth::user()->username . ' has created a purchase invoice ' . $request->reference);

            $notification = array(
                'message' => 'New purchase invoice has been created',
                'alert-type' => 'success'
            );
            return redirect('purchase/view/' . $purchase_id)->with($notification);


        } else {
            return redirect()->back()->with('message', 'Please Select Item');
        }
    }


    public function edit($id)
    {
        if (!Auth::user()->can('edit_purchase_order'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Edit Invoice';
        $data['activeMenu'] = 'manage_purchase';
        $data['supplierData'] = User::where('user_type', 3)->get();
        $data['payments'] = PaymentTerm::get();
        $data['paymentTerms'] = InvoicePaymentTerms::get();
        $data['products'] = Product::all();
        $data['purchase'] = Purchase_invoice::find($id);

        $data['warehouses'] = Warehouse::all();

        $taxTypeList = ItemTaxType::get();
        $taxOptions = '';
        $selectStart = "<select class='form-control taxList' name='tax_id[]'>";
        $selectEnd = "</select>";

        $selectStartCustom = "<select class='form-control taxListCustom' name='tax_id_custom[]'>";
        $selectEndCustom = "</select>";

        $selectStartItem = "<select class='form-control taxListCustom' name='item_tax_id[]'>";
        $selectEndItem = "</select>";


        foreach ($taxTypeList as $key => $value) {
            $taxOptions .= "<option value='" . $value->id . "' taxrate='" . $value->tax_rate . "'>" . $value->name . '(' . $value->tax_rate . ')' . "</option>";
        }
        $data['tax_type'] = $selectStart . $taxOptions . $selectEnd;
        $data['tax_type_custom'] = $selectStartCustom . $taxOptions . $selectEndCustom;
        $data['tax_type_item'] = $selectStartItem . $taxOptions . $selectEndItem;
        $data['getTax'] = ItemTaxType::get();
        return view('admin.purchase.edit', $data);
    }

    public function update(Request $request)
    {
        if (!Auth::user()->can('edit_purchase_order'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $items_name = $request->items_name;
        if (count($items_name) > 0) {


            $purchase = Purchase_invoice::find($request->id);
            $data = $request->all();
            $purchase->fill($data);
            $purchase->invoice_date = DbDateFormat($request->invoice_date);
            $purchase->save(); // save sales invoice


            /** manage Inventory Item item*/
            if (count($purchase->purchaseItemDetails)) {
                Purchase_invoice_details::where('invoice_id', $purchase->id)->delete(); // old data

                $items_name = $request->items_name;
                $items_qty = $request->items_qty;
                $items_rate = $request->items_rate;
                $item_tax_id = $request->item_tax_id;
                $items_discount = $request->items_discount;
                $items_amount = $request->items_amount;


                for ($j = 0; $j < count($items_name); $j++) {
                    if ($items_name[$j] != '' AND $items_qty[$j] != '' AND $items_rate[$j] != '' AND $item_tax_id[$j] != '' AND $items_discount[$j] != '' AND $items_amount[$j] != '') {

                        $product = Product::where('product_name', $items_name[$j])->first();

                        $itemTaxInfo = ItemTaxType::find($item_tax_id[$j]);
                        $itemTotal = $items_amount[$j];
                        $totalItemTax = ($itemTotal * $itemTaxInfo->tax_rate) / 100;

                        $purchaseInvoiceDetails = new Purchase_invoice_details;
                        $purchaseInvoiceDetails->invoice_id = $purchase->id;
                        $purchaseInvoiceDetails->product_id = $product->id;
                        $purchaseInvoiceDetails->tax_id = $item_tax_id[$j];
                        $purchaseInvoiceDetails->product_name = $items_name[$j];
                        $purchaseInvoiceDetails->qty = $items_qty[$j];
                        $purchaseInvoiceDetails->unit_price = $items_rate[$j];
                        $purchaseInvoiceDetails->tax = $totalItemTax;
                        $purchaseInvoiceDetails->discount = $items_discount[$j];
                        $purchaseInvoiceDetails->unit_total_price = $items_amount[$j];
                        $purchaseInvoiceDetails->save();
                    }
                }
            }
            /** end custom item*/

            activity()->log('User ' . Auth::user()->username . ' has updated a purchase invoice ' . $request->reference);

            $notification = array(
                'message' => 'Purchase Invoice Save & Updated',
                'alert-type' => 'info'
            );

            return redirect('purchase/view/' . $purchase->id)->with($notification);


        } else {
            return redirect()->back()->with('message', 'Please Select Item');
        }
    }

    public function view($id)
    {

        if (!Auth::user()->can('view_purchase_order'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'View Invoice';
        $data['activeMenu'] = 'manage_purchase';
        $data['purchase'] = Purchase_invoice::find($id);
        return view('admin.purchase.view', $data);
    }

    public function invoiceDownload($id)
    {

        $activeMenu = '';
        $purchase = Purchase_invoice::find($id);
        $pdf = PDF::loadView('admin.purchase.pdf', ['purchase' => $purchase, 'activeMenu' => $activeMenu]);
        return $pdf->download('purchase-invoice-' . $id . '.pdf');
        return redirect()->back();
    }

    public function destroy($id)
    {
        if (!Auth::user()->can('delete_purchase_order'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        Purchase_invoice::where('id', $id)->delete();

        activity()->log('User ' . Auth::user()->username . ' has deleted a purchase invoice ');

        $notification = array(
            'message' => 'Purchase Invoice Save & Updated',
            'alert-type' => 'info'
        );

        return redirect()->back()->with($notification);
    }

}
