<?php

namespace App\Http\Controllers;

use App\Account;
use App\ApplicationSetting;
use App\Bank_tran;
use App\EmailTempDetail;
use App\Http\Requests\PaymentRequest;
use App\Payment;
use App\PaymentTerm;
use App\Sales_invoice;
use App\Transaction;
use App\TransactionCategory;
use Auth;
use Carbon\Carbon;
use Entrust;


class PaymentController extends Controller
{

    public function __construct(EmailController $email)
    {
        $this->email = $email;
    }

    public function salesPayment()
    {
        if (!Auth::user()->can('manage_payment'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Payments';
        $data['activeMenu'] = 'payments';
        $data['getInvoice'] = Sales_invoice::orderBy('id', "DESC")->get();
        return view('admin.sales-invoice.payment.index', $data);
    }

    public function PaymentForSalesInvoice($id)
    {

        if (!Auth::user()->can('manage_payment'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Payment';
        $data['activeMenu'] = 'manage_sales_invoice';
        $data['payments'] = PaymentTerm::get();
        $data['accounts'] = Account::all();
        $data['incomeCategories'] = TransactionCategory::Where('type', 'income')->select('id', 'name')->get();
        $data['payments'] = PaymentTerm::all();
        $data['invoice'] = Sales_invoice::find($id);
        return view('admin.sales-invoice.payment.create', $data);
    }

    public function SubmitPaymentForSalesInvoice(PaymentRequest $request)
    {
        if (!Auth::user()->can('manage_payment'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $account = Account::findOrFail($request->account_id);
        $invoice = Sales_invoice::find($request->invoice_id);

        if ($invoice->status == 0) {
            $TotalPaidAmount = $invoice->total_paid + $request->paid_amount;
            $TotalDue = $invoice->total_due - $request->paid_amount;
            if (number_format((float)$TotalPaidAmount, 2, '.', '') == $invoice->grand_total) {
                $status = 1;
            } else {
                $status = 0;
            }

            $invoice->total_paid = number_format((float)$TotalPaidAmount, 2, '.', '');
            $invoice->total_due = number_format((float)$TotalDue, 2, '.', '');
            $invoice->status = $status;
            $invoice->save(); // update invoice


            $debitTransition = new Transaction;
            $debitTransition->customer_name = $invoice->user->getFullNameAttribute();
            $debitTransition->debit = $request->paid_amount;
            $debitTransition->credit = 0.00;
            $debitTransition->type = 'income';
            $debitTransition->account_id = $request->account_id; // account id 3 is Accounts Receivable
            $debitTransition->date = DbDateFormat($request->payment_date);
            $debitTransition->transaction_category_name = $invoice->paymentMethod->name;
            $debitTransition->pay_method = $invoice->paymentMethod->name;
            $debitTransition->note = $request->note;
            $debitTransition->save();


            if ($request->note != '') {
                $description = $request->note;
            } else {
                $description = '';
            }


            // Update last balance for the selected account
            $account->last_balance = $account->last_balance + $request->paid_amount;
            $account->save();

            $bankTran = new Bank_tran();
            $bankTran->account_no = $request->account_id;
            $bankTran->category_id = $request->category_id;
            $bankTran->payment_method = $request->payment_method_id;
            $bankTran->amount = "+" . $request->paid_amount;
            $bankTran->trans_type = "cash-in-by-sale";
            $bankTran->trans_date = DbDateFormat($request->payment_date);
            $bankTran->person_id = Auth::user()->id;
            $bankTran->reference = "INV-" . $invoice->reference;
            $bankTran->description = $description;
            $bankTran->save();

            /** ========= Store payment history ======== */

            $payment = new Payment();
            $payment->invoice_id = $invoice->id;
            $payment->payment_method_id = $request->payment_method_id;
            $payment->account_name = 'Product Sales';
            $payment->amount = $request->paid_amount;
            $payment->payment_date = DbDateFormat($request->payment_date);
            $payment->reference_no = "INV-" . $invoice->reference;
            $payment->payment_type = "sales";
            $payment->description = $request->note;
            $payment->save();


            /** ======== Mail process =======*/
            $customer = $invoice->user->customer;
            $customer_name = $invoice->user->first_name . " " . $invoice->user->last_name;
            $billing_street = $customer->address;
            $billing_city = $customer->city;
            $billing_state = $customer->region;
            $billing_zip_code = $customer->postbox;
            $billing_country = $customer->country->country_name;
            $payment_id = $payment->id;
            $payment_date = Carbon::parse($request->payment_date)->format("d M, Y");
            $payment_method = $payment->paymentMethod->name;
            $total_amount = $payment->amount;

            $invoice_reference_no = "INV-" . $invoice->reference;

            $applicationSetting = ApplicationSetting::find(1);
            $emailInfo = EmailTempDetail::where('temp_id', 1)->select('subject', 'body')->first();

            $subject = str_replace('{invoice_reference_no}', $invoice_reference_no, $emailInfo->subject);

            $message = str_replace(
                array("{customer_name}","{billing_street}", "{billing_city}", "{billing_state}", "{billing_zip_code}", "{billing_country}", "{payment_id}", "{payment_date}", "{payment_method}", "{total_amount}", "{invoice_reference_no}", "{company_name}"),
                array($customer_name, $billing_street, $billing_city, $billing_state, $billing_zip_code, $billing_country, $payment_id, $payment_date, $payment_method, $total_amount, $invoice_reference_no, $applicationSetting->company_name),
                $emailInfo->body
            );

            //$this->email->sendGeneralMail($customer->email, $subject, $message);
            /** ======== End Mail process =======*/


            activity()->log(Auth::user()->username . ' make a payment for an invoice');


            $notification = array(
                'message' => 'Payment has been made for this invoice',
                'alert-type' => 'success'
            );

            return redirect('invoice/view-sales-invoice/' . $invoice->id)->with($notification);


        } else {
            return redirect()->back()->with("message", "Payment Completed");
        }

    }
}
