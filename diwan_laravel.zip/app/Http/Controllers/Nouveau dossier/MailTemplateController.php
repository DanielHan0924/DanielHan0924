<?php

namespace App\Http\Controllers;

use App\EmailTempDetail;
use Illuminate\Http\Request;
use Auth;
class MailTemplateController extends Controller
{


    public function customerInvTemp($id)
    {
        if (!Auth::user()->can('email_template_setting'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Email Templates';
        $data['activeMenu'] = 'email_templates';
        $data['list_menu'] = 'menu-' . $id;
        $data['tempId'] = $id;
        $data['temp_Data'] = EmailTempDetail::where('temp_id', $id)->first();
        return view('admin.configuration.emailConfig', $data);
    }

    public function update(Request $request, $id)
    {

        $tempDetail = EmailTempDetail::where('temp_id', $id)->firstOrFail();
        $tempDetail->subject = $request->subject;
        $tempDetail->body = $request->body;
        $tempDetail->save();

        $notification = array(
            'message' => 'Email template has been updated',
            'alert-type' => 'info'
        );

        return redirect()->intended("email/customer-invoice-temp/$id")->with($notification);


    }
}
