<?php

namespace App\Http\Controllers;

use App\Account;
use App\ApplicationSetting;
use App\Bank_tran;
use App\Http\Requests\EditInvoiceRequest;
use App\Http\Requests\InvoiceRequest;
use App\Http\Requests\PaymentRequest;
use App\Invoice;
use App\Invoice_item;
use App\Payment;
use App\PaymentTerm;
use App\Transaction;
use App\TransactionCategory;
use Auth;
use PDF;
use Redirect;

class InvoiceController extends Controller
{

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */

    public function viewInvoice($id)
    {
        if (!Auth::user()->can('view_project_invoice'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $invoice = Invoice::find($id);
        $data['title'] = 'View Invoice';
        $data['activeMenu'] = 'view_invoice';
        $data['invoice'] = $invoice;
        $data['items'] = $invoice->items;
        $data['company'] = ApplicationSetting::find(1);
        return view('admin.invoice.view', $data);
    }


    public function paymentForProjectInvoice($invoice_id)
    {
        $data['title'] = 'Payment';
        $data['activeMenu'] = 'view_invoice';
        $data['payments'] = PaymentTerm::get();
        $data['accounts'] = Account::all();
        $data['incomeCategories'] = TransactionCategory::Where('type', 'income')->select('id', 'name')->get();
        $data['payments'] = PaymentTerm::all();
        $data['invoice'] = Invoice::find($invoice_id);
        return view('admin.invoice.payment.create', $data);
    }

    public function submitPaymentForProjectInvoice(PaymentRequest $request)
    {

        $account = Account::findOrFail($request->account_id);
        $invoice = Invoice::find($request->invoice_id);
        if ($invoice->invoice_status == 'Due') {
            $TotalPaidAmount = $invoice->amount_paid + $request->paid_amount;
            $TotalDue = $invoice->total_due - $request->paid_amount;
            if (number_format((float)$TotalPaidAmount, 2, '.', '') == $invoice->total_payable) {
                $invoice_status = 'Paid';
            } else {
                $invoice_status = 'Due';
            }

            $invoice->amount_paid = number_format((float)$TotalPaidAmount, 2, '.', '');
            $invoice->total_due = number_format((float)$TotalDue, 2, '.', '');
            $invoice->invoice_status = $invoice_status;
            $invoice->save(); // update invoice

            $payment_method = PaymentTerm::find($request->payment_method_id);

            $debitTransition = new Transaction();
            $debitTransition->debit = $request->paid_amount;
            $debitTransition->credit = 0.00;
            $debitTransition->type = 'income';
            $debitTransition->account_id = $request->account_id; // account id 3 is Accounts Receivable
            $debitTransition->date = DbDateFormat($request->payment_date);
            $debitTransition->transaction_category_name = $payment_method->name;
            $debitTransition->pay_method = $payment_method->name;
            $debitTransition->note = $request->note;
            $debitTransition->save();



            if ($request->note != '') {
                $description = $request->note;
            } else {
                $description = '';
            }


            // Update last balance for the selected account
            $account->last_balance = $account->last_balance + $request->paid_amount;
            $account->save();

            $bankTran = new Bank_tran();
            $bankTran->account_no = $request->account_id;
            $bankTran->category_id = $request->category_id;
            $bankTran->payment_method = $request->payment_method_id;
            $bankTran->amount = "+" . $request->paid_amount;
            $bankTran->trans_type = "cash-in-by-project-invoice";
            $bankTran->trans_date = DbDateFormat($request->payment_date);
            $bankTran->person_id = Auth::user()->id;
            $bankTran->reference = "";
            $bankTran->description = $description;
            $bankTran->save();

            /** ========= Store payment history ======== */

            $payment = new Payment();
            $payment->invoice_id = $invoice->id;
            $payment->payment_method_id = $request->payment_method_id;
            $payment->account_name = 'Project Invoice';
            $payment->amount = $request->paid_amount;
            $payment->payment_date = DbDateFormat($request->payment_date);
            $payment->reference_no = "";
            $payment->payment_type = "project_invoice";
            $payment->description = $request->note;
            $payment->save();


            activity()->log(Auth::user()->username . ' make a payment for an invoice');
            $notification = array(
                'message' => 'Payment has been made for this invoice',
                'alert-type' => 'success'
            );

            return redirect('viewInvoice/' . $invoice->id)->with($notification);


        } else {
            return redirect()->back()->with("message", "Payment Completed");
        }
    }

    public function createInvoice($id)
    {

        if (!Auth::user()->can('create_project_invoice'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Create New Invoice';
        $data['activeMenu'] = 'create_project_invoice';
        $data['project_id'] = $id;
        $data['invoice_number'] = mt_rand(1, 1000000);

        return view('admin.invoice.create', $data);
    }

    /**
     * @param InvoiceRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function storeInvoice(InvoiceRequest $request)
    {
        if (!Auth::user()->can('create_project_invoice'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $invoice = new Invoice;
        $invoice->project_id = $request->project_id;
        $invoice->invoice_from = $request->invoice_from;
        $invoice->bill_to = $request->bill_to;
        $invoice->invoice_number = $request->invoice_number;
        $invoice->invoice_create_date = DbDateFormat($request->invoice_create_date);
        $invoice->payment_terms = $request->payment_terms;
        $invoice->invoice_due_date = DbDateFormat($request->invoice_due_date);
        $invoice->sub_total = $request->sub_total;
        $invoice->discount_type = $request->discount_type;
        $invoice->discount_amount = $request->discount_amount;
        $invoice->total_payable = $request->total_payable;
        $invoice->total_due = $request->total_payable;
        $invoice->note = $request->note;
        $invoice->terms = $request->terms;
        $invoice->invoice_status = 'Due';
        $invoice->save();


        // Serialize items quantity and rate arrays...
        $items = $request->item;
        $quantities = $request->quantity;
        $rates = $request->rate;
        $amounts = $request->amount;

        $number_of_entries = sizeof($items);
        for ($i = 0; $i < $number_of_entries; $i++) {
            if ($items[$i] != "" && $quantities[$i] != "" && $rates[$i] != "" && $amounts[$i] != "") {

                $invoiceItem = new Invoice_item();
                $invoiceItem->invoice_id = $invoice->id;
                $invoiceItem->item = $items[$i];
                $invoiceItem->quantity = $quantities[$i];
                $invoiceItem->rate = $rates[$i];
                $invoiceItem->amount = $amounts[$i];
                $invoiceItem->save();
            }

        }


        // Need to insert payment data if payment is PAID into a default payment receive account

        $invoice->save();
        activity()->log(Auth::user()->username . ' has created an invoice');
        $notification = array(
            'message' => 'New invoice has been created.',
            'alert-type' => 'success'
        );

        return redirect('viewInvoice/'.$invoice->id)->with($notification);


    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function editInvoice($id)
    {
        if (!Auth::user()->can('edit_project_invoice'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $invoice = Invoice::find($id);
        $data['title'] = 'Edit Invoice';
        $data['activeMenu'] = 'view_invoice';
        $data['invoice'] = $invoice;
        $data['items'] = $invoice->items;

        return view('admin.invoice.edit', $data);
    }

    /**
     * @param EditInvoiceRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */

    public function updateInvoice(EditInvoiceRequest $request)
    {
        if (!Auth::user()->can('edit_project_invoice'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $invoice = Invoice::find($request->invoice_id);
        $invoice->invoice_from = $request->invoice_from;
        $invoice->bill_to = $request->bill_to;
        $invoice->invoice_number = $request->invoice_number;
        $invoice->invoice_create_date = DbDateFormat($request->invoice_create_date);
        $invoice->payment_terms = $request->payment_terms;
        $invoice->invoice_due_date = DbDateFormat($request->invoice_due_date);
        $invoice->sub_total = $request->sub_total;
        $invoice->discount_type = $request->discount_type;
        $invoice->discount_amount = $request->discount_amount;
        $invoice->total_payable = $request->total_payable;
        $invoice->amount_paid = $request->amount_paid;
        $invoice->total_due = $request->total_due;
        $invoice->note = $request->note;
        $invoice->terms = $request->terms;

        if ($request->total_due == 0) {
            $invoice->invoice_status = 'Paid';
        } else {
            $invoice->invoice_status = 'Due';
        }


        $invoice->save();


        Invoice_item::where('invoice_id', $invoice->id)->delete(); // delete previous items


        // Serialize items quantity and rate arrays...
        $items = $request->item;
        $quantities = $request->quantity;
        $rates = $request->rate;
        $amounts = $request->amount;

        $number_of_entries = sizeof($items);
        for ($i = 0; $i < $number_of_entries; $i++) {
            if ($items[$i] != "" && $quantities[$i] != "" && $rates[$i] != "" && $amounts[$i] != "") {

                $invoiceItem = new Invoice_item();
                $invoiceItem->invoice_id = $invoice->id;
                $invoiceItem->item = $items[$i];
                $invoiceItem->quantity = $quantities[$i];
                $invoiceItem->rate = $rates[$i];
                $invoiceItem->amount = $amounts[$i];
                $invoiceItem->save();
            }

        }


        // Need to insert payment data if payment is PAID into a default payment receive account

        $invoice->save();


        // Log activity
        activity()->log(Auth::user()->username . ' has update invoice .' . $invoice->invoice_number);

        // Flash message and type
        $notification = array(
            'message' => 'New invoice has been created.',
            'alert-type' => 'info'
        );

        return redirect('viewInvoice/'.$invoice->id)->with($notification);
    }

    /**
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        if (!Auth::user()->can('delete_project_invoice'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $invoice = Invoice::findOrFail($id);
        $invoice->delete();
        $notification = array(
            'message' => 'Invoice has been deleted',
            'alert-type' => 'error'
        );
        activity()->log(Auth::user()->full_name . ' has deleted invoice ' . $invoice->invoice_number);

        return Redirect::to('project/' . $invoice->project_id)->with($notification);
    }


    /**
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response
     */

    public function downloadInvoice($id)
    {
        if (!Auth::user()->can('download_pdf_project_invoice'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $invoice = Invoice::find($id);
        $data['title'] = 'View Invoice';
        $data['activeMenu'] = 'view_invoice';
        $data['invoice'] = $invoice;
        $data['items'] = $invoice->items;
        $data['company'] = ApplicationSetting::find(1);
        $pdf = PDF::loadView('admin.invoice.downloadInvoice', $data);
        return $pdf->download('invoice#' . $invoice->invoice_number . '.pdf');
        //return redirect()->back();

    }


}
