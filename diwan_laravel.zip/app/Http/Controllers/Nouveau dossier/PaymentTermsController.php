<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\InvoicePaymentTerms;
use Auth;
use Validator;
class PaymentTermsController extends Controller
{
    public function index()
    {
        if (!Auth::user()->can('create_payment_terms') && !Auth::user()->can('edit_payment_terms') && !Auth::user()->can('delete_payment_terms')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['title'] = 'Payment Terms';
        $data['activeMenu'] = 'payment_terms';
        $data['terms'] = InvoicePaymentTerms::all();
        return view('admin.configuration.payment-terms', $data);
    }


    function addPaymentTerm(Request $request, InvoicePaymentTerms $paymentTerm)
    {
        if (!Auth::user()->can('create_payment_terms')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data = $request->all();
        $paymentTerm->fill($data);


        if ($request->defaults == 1) {
            InvoicePaymentTerms::where('defaults', 1)->update(['defaults' => 0]);
        }

        $validator = Validator::make($request->all(), [
            'terms' => 'required|unique:invoice_payment_terms',
            'days_before_due' => 'required|unique:invoice_payment_terms',
            'defaults' => 'required',

        ]);

        if ($validator->passes()) {
            $paymentTerm->save();
            $notification = array(
                'message' => 'New payment term has been added.',
                'alert-type' => 'success',
            );
            return response()->json(['success' => $notification]);
        }

        return response()->json(['error' => $validator->errors()->all()]);


    }


    public function edit($id)
    {
        if (!Auth::user()->can('edit_payment_terms')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        return InvoicePaymentTerms::find($id)->toJson();
    }

    public function update(Request $request)
    {
        if (!Auth::user()->can('edit_payment_terms')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $paymentTerm = InvoicePaymentTerms::find($request->id);
        $data = $request->all();
        $paymentTerm->fill($data);


        if ($request->defaults == 1) {
            InvoicePaymentTerms::where('defaults', 1)->update(['defaults' => 0]);
        }

        $validator = Validator::make($request->all(), [
            'terms' => 'required',
            'days_before_due' => 'required',
            'defaults' => 'required',

        ]);

        if ($validator->passes()) {
            $paymentTerm->save();

            $notification = array(
                'message' => 'Successfully Save & Update',
                'alert-type' => 'success'
            );

            return redirect()->back()->with($notification);
        }

        $notification = array(
            'message' => 'Pleae enter information',
            'alert-type' => 'info'
        );

        return redirect()->back()->with($notification);

    }


    /**
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */

    function deletePaymentTerm($id)
    {
        if (!Auth::user()->can('delete_payment_terms')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $term = InvoicePaymentTerms::find($id);
        $term->delete();

        $notification = array(
            'message' => 'Payment term has been deleted',
            'alert-type' => 'error',
        );
        return redirect()->back()->with($notification);

    }

}
