<?php

namespace App\Http\Controllers;

use App\Http\Requests\NoteRequest;
use App\Note;
use Auth;
use Redirect;

class NoteController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!Auth::user()->can('create_note') && !Auth::user()->can('view_note') && !Auth::user()->can('delete_note') )
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Notes';
        $data['activeMenu'] = 'notes';
        $data['notes'] = Note::all();
        return view('admin.note.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Auth::user()->can('create_note'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['activeMenu'] = 'notes';
        $data['title'] = 'Create Note';
        return view('admin.note.create', $data);

    }

    /**
     * Store a newly created resource in storage.
     * @param NoteRequest $request
     * @return \Illuminate\Http\Response
     */
    public function store(NoteRequest $request, Note $note)
    {
        if (!Auth::user()->can('create_note'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $note->fill($request->all());
        $note->user_id = Auth::user()->id;
        $note->note = $request->note;
        $note->save();
        $notification = array(
            'message' => 'Note has been created',
            'alert-type' => 'success'
        );
        return redirect()->route('note.index')->with($notification);

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Auth::user()->can('edit_note'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Edit Note';
        $data['activeMenu'] = 'notes';
        $data['note'] = Note::find($id);
        return view('admin.note.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     * @param NoteRequest $request
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */

    public function update(NoteRequest $request, $id)
    {
        if (!Auth::user()->can('edit_note'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $note = Note::find($id);
        $note->title = $request->title;
        $note->note = $request->note;
        $note->user_id = Auth::user()->id;
        $note->save();
        $notification = array(
            'message' => 'Note has been updated',
            'alert-type' => 'info'
        );
        return Redirect::to('note')->with($notification);

    }

    /**
     * Remove the specified resource from storage.
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */

    public function destroy($id)
    {
        if (!Auth::user()->can('delete_note'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $note = Note::find($id);
        $note->delete();
        $notification = array(
            'message' => 'Note has been deleted',
            'alert-type' => 'error'
        );
        return Redirect::to('note')->with($notification);

    }
}
