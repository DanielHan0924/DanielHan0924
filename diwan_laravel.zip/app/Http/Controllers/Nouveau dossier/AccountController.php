<?php

namespace App\Http\Controllers;

use App\Account;
use App\Http\Requests\AccountRequest;
use App\Http\Requests\TransactionCategoryRequest;
use App\Transaction;
use App\TransactionCategory;
use Auth;
use DB;
use Entrust;
use Illuminate\Http\Request;
use Redirect;

class AccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        if (!Auth::user()->can('create_account') && !Auth::user()->can('view_account') && !Auth::user()->can('edit_account') && !Auth::user()->can('delete_account') )
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $account = new Account();
        $data['title'] = 'All Accounts';
        $data['activeMenu'] = 'accounts';
        $data['accounts'] = Account::all();
        $data['total_account'] = Account::count();
        $data['balancesheet'] = $account->balanceSheet();
        return view('admin.account.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        if (!Auth::user()->can('create_account'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Add new account';
        $data['activeMenu'] = 'create_account';
        $data['accountTypes'] = DB::table('bank_account_type')->get();
        return view('admin.account.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param AccountRequest $request
     * @return \Illuminate\Http\Response
     */
    public function store(AccountRequest $request)
    {

        if (!Auth::user()->can('create_account'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        //dd($request->all());
        Account::create($request->all());
        activity()->log('User ' . Auth::user()->username . ' has created an account : A/C#' . $request->account_number);

        $notification = array(
            'message' => 'New account has been created',
            'alert-type' => 'success'
        );
        return redirect('account')->with($notification);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function show($id)
    {

        if (!Auth::user()->can('view_account'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['title'] = 'Account Details';
        $data['activeMenu'] = 'accounts';
        $data['account'] = Account::findOrFail($id);
        return view('admin.account.show', $data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Auth::user()->can('edit_account'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Edit Account';
        $data['activeMenu'] = 'accounts';
        $data['account'] = Account::find($id);
        $data['accountTypes'] = DB::table('bank_account_type')->get();
        return view('admin.account.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {

        if (!Auth::user()->can('edit_account'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $account = Account::find($id);
        $account->account_number = $request->account_number;
        $account->account_holder = $request->account_holder;
        $account->last_balance = $request->last_balance;
        $account->bank_name = $request->bank_name;
        $account->bank_address = $request->bank_address;
        $account->account_type_id = $request->account_type_id;
        $account->note = $request->note;
        $account->save();


        activity()->log('User ' . Auth::user()->username . ' has updated account : A/C#' . $request->account_number);

        $notification = array(
            'message' => 'Account has been updated',
            'alert-type' => 'success'
        );

        return Redirect::to('account')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        if (!Auth::user()->can('delete_account'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $account = Account::findOrFail($id);
        $account->delete();
        activity()->log('User ' . Auth::user()->username . ' has deleted account : A/C#' . $account->account_number);

        $notification = array(
            'message' => 'Account has been deleted',
            'alert-type' => 'alert'
        );

        return Redirect::to('account')->with($notification);

    }


    public function balanceSheet()
    {
        if (!Auth::user()->can('manage_balance_sheet'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $account = new Account();
        $data['accounts'] = Account::all();
        $data['title'] = 'BalanceSheet';
        $data['activeMenu'] = 'balancesheet';
        $data['balancesheet'] = $account->balanceSheet();
        return view('admin.account.balancesheet', $data);

    }


    /**
     * Account Transaction Categories
     */


    public function transactionCategories()
    {
        if (!Auth::user()->can('manage_account_statement'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking




        $data['title'] = 'Transaction Categories';
        $data['activeMenu'] = 'TransactionCategories';
        $data['transactionCategories'] = TransactionCategory::all();
        return view('admin.transaction-category.index', $data);
    }


    public function createCategory()
    {
        $data['title'] = 'Transaction Categories';
        $data['activeMenu'] = 'TransactionCategories';
        return view('admin.transaction-category.create', $data);
    }


    public function storeCategory(TransactionCategoryRequest $request)
    {
        TransactionCategory::create($request->all());

        $notification = array(
            'message' => 'New account category has been created',
            'alert-type' => 'success'
        );

        return Redirect::to('createCategory')->with($notification);


    }


    public function editCategory($id)
    {
        $data['category'] = TransactionCategory::findOrFail($id);
        $data['title'] = 'Edit transaction category';
        $data['activeMenu'] = 'transaction_category';
        return view('admin.transaction-category.edit', $data);

    }


    public function updateCategory(TransactionCategoryRequest $request, $id)
    {
        $category = TransactionCategory::findOrFail($id);
        $category->name = $request->name;
        $category->save();

        $notification = array(
            'message' => 'Transaction category has been updated',
            'alert-type' => 'alert'
        );

        return Redirect::to('transaction-cat/categories')->with($notification);


    }


    public function deleteCategory($id)
    {
        $transactionCategory = TransactionCategory::find($id);
        $transactionCategory->delete();
        return redirect('transaction-cat/categories')->with('message', 'Transaction category has been deleted.');
    }


    public function accountStatement()
    {


        $data['title'] = 'Account Statement';
        $data['activeMenu'] = 'account_statement';
        $data['accounts'] = Account::all();
        return view('admin.account.statement', $data);
    }


    public function processAccountStatement(Request $request)
    {


        $data['title'] = 'Account Statement';
        $data['activeMenu'] = 'account_statement';
        $account_id = $request->account_id;

        $type = $request->type;
        $from_date = $request->from_date;
        $to_date = $request->to_date;

        if ($type == 'All') {
            $result = Transaction::where('account_id', '=', $account_id)->where('ext', '=', 1)->whereBetween('date', [$from_date, $to_date])->get();
        } else {
            $result = Transaction::where('account_id', '=', $account_id)->where('ext', '=', 1)->where('type', '=', $type)->whereBetween('date', [$from_date, $to_date])->get();
        }

        $data['results'] = $result;
        return view('admin.account.result', $data);


    }


}
