<?php

namespace App\Http\Controllers;

use App\Category;
use App\Sales_invoice;
use Spatie\Activitylog\Models\Activity;

class ApiController extends Controller
{

    /**
     * @return \Illuminate\Http\JsonResponse|mixed
     * @throws \Exception
     */
    public function getActivityLog()
    {
        return datatables(Activity::select('id', 'description')->orderBy('id', 'DESC'))->make(true);

    }


    /**
     * @return \Illuminate\Http\JsonResponse|mixed
     * @throws \Exception
     */
    public function getCategories()
    {
        return datatables(Category::select('title', 'description'))->make(true);
    }


    public function getSalesInvoices()
    {
        return datatables(Sales_invoice::select(formatDate('invoice_date'), 'sub_total', 'total_tax', 'grand_total'))->make(true);
    }
}
