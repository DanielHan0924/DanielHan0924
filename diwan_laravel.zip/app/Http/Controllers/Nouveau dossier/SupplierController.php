<?php

namespace App\Http\Controllers;

use App\ApplicationSetting;
use App\Country;
use App\EmailTempDetail;
use App\Http\Requests\SupplierRequest;
use App\Role;
use App\Supplier;
use App\User;
use Auth;
use DB;
use Hash;

class SupplierController extends Controller
{
    public function __construct(EmailController $email)
    {
        $this->email = $email;
    }

    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index()
    {
        if (!Auth::user()->can('create_supplier') && !Auth::user()->can('view_supplier') && !Auth::user()->can('edit_supplier') && !Auth::user()->can('delete_supplier')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Suppliers';
        $data['activeMenu'] = 'suppliers';
        $data['suppliers'] = Supplier::all();
        return view('admin.supplier.index', $data);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Auth::user()->can('create_supplier')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['roles'] = Role::select('id', 'name')->get();
        $data['activeMenu'] = 'create_supplier';
        $data['title'] = 'Add new supplier details';
        $data['countries'] = Country::all();

        return view('admin.supplier.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param SupplierRequest $request
     * @return \Illuminate\Http\Response
     */
    public function store(SupplierRequest $request)
    {
        if (!Auth::user()->can('create_supplier')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        // Create an user first


        $user = new User;
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->username = $request->username;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->user_type = 3; // User type 3 for supplier

        $user->assignRole($request->role);

        $filename = uniqid();
        if ($request->hasFile('profile_image')) {
            $extension = $request->file('profile_image')->getClientOriginalExtension();
            $request->file('profile_image')->move('public/uploads/users_profile', $filename . '.' . $extension);
            $user->profile_image = $filename . '.' . $extension;
        }

        $user->save();


        $supplier = new Supplier;
        $supplier->user_id = User::all()->last()->id;
        $supplier->phone = $request->phone;
        $supplier->address = $request->address;
        $supplier->city = $request->city;
        $supplier->region = $request->region;
        $supplier->country_id = $request->country_id;
        $supplier->postbox = $request->postbox;
        $supplier->company = $request->company;
        $supplier->save();


        activity()->log(Auth::user()->username . ' has created supplier name ' . $request->first_name . ' ' . $request->last_name);

        $notification = array(
            'message' => 'Supplier has been created',
            'alert-type' => 'success'
        );

        /** ======== Mail process =======*/
        $member_name = $request->first_name . " " . $request->last_name;
        $loginURL = URL('login');
        $clickHereToLogin = '<a href="' . $loginURL . '">Click here to log in</a>';

        $applicationSetting = ApplicationSetting::find(1);
        $emailInfo = EmailTempDetail::where('temp_id', 7)->select('subject', 'body')->first();

        $subject = str_replace('{company_name}', $applicationSetting->company_name, $emailInfo->subject);

        $message = str_replace(
            array("{member_name}", "{company_name}", "{email}", "{password}", "{login_url}"),
            array($member_name, $applicationSetting->company_name, $request->email, $request->password, $clickHereToLogin),
            $emailInfo->body
        );

        //$this->email->sendGeneralMail($request->email, $subject, $message);
        /** ======== End Mail process =======*/

        return redirect()->route('supplier.index')->with($notification);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function show($id)
    {

        if (!Auth::user()->can('view_supplier')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Supplier Details';
        $data['activeMenu'] = 'suppliers';
        $data['supplier'] = Supplier::findOrFail($id);
        return view('admin.supplier.show', $data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function edit($id)
    {
        if (!Auth::user()->can('edit_supplier')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Edit Supplier';
        $data['activeMenu'] = 'suppliers';
        $data['supplier'] = Supplier::findOrFail($id);
        $data['countries'] = Country::all();
        $data['roles'] = Role::select('id', 'name')->get();

        $user_id = $data['supplier']->user_id;

        if (DB::table('model_has_roles')->where('model_id', $user_id)->count() > 0) {
            $selected_role = DB::table('model_has_roles')->where('model_id', $user_id)->first();
            $data['selected_role_id'] = $selected_role->role_id;
        } else {
            $data['selected_role_id'] = 0;
        }

        return view('admin.supplier.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param SupplierRequest $request
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(SupplierRequest $request, $id)
    {

        if (!Auth::user()->can('edit_supplier')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $supplier = Supplier::find($id);
        $supplier->phone = $request->phone;
        $supplier->address = $request->address;
        $supplier->city = $request->city;
        $supplier->region = $request->region;
        $supplier->country_id = $request->country_id;
        $supplier->postbox = $request->postbox;
        $supplier->company = $request->company;
        $supplier->save();

        $user = $supplier->user;
        DB::table('model_has_roles')->where('model_id', $user->id)->delete();
        $user->assignRole($request->role);

        $filename = uniqid();
        if ($request->hasFile('profile_image')) {
            $extension = $request->file('profile_image')->getClientOriginalExtension();
            $request->file('profile_image')->move('public/uploads/users_profile', $filename . '.' . $extension);
            $user->profile_image = $filename . '.' . $extension;
        }

        $user->save();

        activity()->log(Auth::user()->username . ' has updated supplier.');

        $notification = array(
            'message' => 'Supplier details has been updated',
            'alert-type' => 'info'
        );

        return redirect('supplier')->with($notification);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        if (!Auth::user()->can('delete_supplier')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $supplier = Supplier::findOrFail($id);
        User::where('id', $supplier->user_id)->delete();

        $supplier->delete();

        activity()->log(Auth::user()->username . ' has delete supplier.');

        $notification = array(
            'message' => 'Supplier has been deleted',
            'alert-type' => 'error'
        );
        return redirect('supplier')->with($notification);

    }
}
