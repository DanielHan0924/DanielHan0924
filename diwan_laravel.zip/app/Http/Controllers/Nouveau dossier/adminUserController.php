<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests\userRequest;
use Illuminate\Support\Facades\Redirect;
use Auth;
use Input;
use Validator;
use Session;
use DB;
use App\Role;

class adminUserController extends Controller
{

    public function userPermission()
    {
        if (!Auth::user()->can('manage_role_permission'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $title = 'Set Permission';
        $activeMenu ='roles_permissions';

        $roles = DB::table('roles')->get();
        $permissions = DB::table('permissions')->get();


        $permissionRole = DB::table('role_has_permissions')
            ->select(DB::raw('CONCAT(role_id,"-",permission_id) AS detail'))
            ->pluck('detail')->toArray();


        return View('admin.user.permission-setting', compact('title', 'roles', 'permissions', 'activeMenu', 'permissionRole'));
    }

    public function savePermission(Request $request)
    {
        if (!Auth::user()->can('manage_role_permission'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


       DB::table('role_has_permissions')->truncate();
        $input = $request->all();
        $permissions = array_get($input, 'permission');
        if ($permissions != '')
            foreach ($permissions as $r_key => $permission) {
                foreach ($permission as $p_key => $per) {
                    $values[] = $p_key;
                }

               // $role = Role::find($r_key);

                if (count($values))
                    for ($i = 0; $i < count($values); $i++)
                    {
                        DB::table('role_has_permissions')->insert([
                            'permission_id' => $values[$i],
                            'role_id' => $r_key
                        ]);
                    }
                unset($values);
            }

        $notification = array(
            'message' => 'Permission successfully Saved.',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);
    }

}
