<?php

namespace App\Http\Controllers;

use App\libraries\MailService;

class EmailController extends Controller
{
    public function __construct()
    {
    }


    public function sendEmail($to, $subject, $messageBody)
    {
        $mail = new MailService;
        $dataMail = [
            'to' => array($to),
            'subject' => $subject,
            'content' => $messageBody
        ];
        $mail->send($dataMail, 'admin.emails.paymentReceipt');
    }



    public function sendEmailWithAttachment($invoice, $to, $subject, $messageBody, $invoiceName)
    {
        $mail = new MailService;
        $dataMail = array(
            'to' => array($to),
            'subject' => $subject,
            'content' => $messageBody,
            'invoice' => $invoice,
            'attach' => url("public/uploads/invoices/$invoiceName")
        );

        $mail->send($dataMail, 'admin.emails.paymentReceipt');

        @unlink(public_path('/uploads/invoices/' . $invoiceName));

    }

    public function sendQuoteEmailWithAttachment($quote, $to, $subject, $messageBody, $invoiceName)
    {
        $mail = new MailService;
        $dataMail = array(
            'to' => array($to),
            'subject' => $subject,
            'content' => $messageBody,
            'invoice' => $quote,
            'attach' => url("public/uploads/quote/$invoiceName")
        );

        $mail->send($dataMail, 'admin.emails.paymentReceipt');

        @unlink(public_path('/uploads/quote/' . $invoiceName));

    }


    public function sendResetPasswordLink($to, $subject, $messageBody)
    {
        $mail = new MailService;
        $dataMail = [
            'to' => array($to),
            'subject' => $subject,
            'content' => $messageBody
        ];
        $mail->send($dataMail, 'admin.emails.password-link');
    }

    public function sendGeneralMail($to, $subject, $messageBody)
    {
        $mail = new MailService;
        $dataMail = [
            'to' => array($to),
            'subject' => $subject,
            'content' => $messageBody
        ];
        $mail->send($dataMail, 'admin.emails.send-general-mail');
    }

}
