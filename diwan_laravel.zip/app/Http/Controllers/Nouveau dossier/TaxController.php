<?php

namespace App\Http\Controllers;

use App\ItemTaxType;
use Illuminate\Http\Request;
use Validator;
use Auth;

class TaxController extends Controller
{
    public function index()
    {
        if (!Auth::user()->can('create_tax') && !Auth::user()->can('edit_tax') && !Auth::user()->can('delete_tax') )
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Taxes';
        $data['activeMenu'] = 'taxes';
        $data['taxes'] = ItemTaxType::all();
        return view('admin.configuration.tax-type', $data);

    }

    public function create()
    {

    }

    public function store(Request $request, ItemTaxType $taxType)
    {
        if (!Auth::user()->can('create_tax'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data = $request->all();
        $taxType->fill($data);


        if ($request->default == 1) {
            ItemTaxType::where('default', 1)->update(['default' => 0]);
        }

        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:item_tax_types',
            'tax_rate' => 'required|unique:item_tax_types',
            'default' => 'required',

        ]);

        if ($validator->passes()) {
            $taxType->save();
            $notification = array(
                'message' => 'New tax rate has been added.',
                'alert-type' => 'success',
            );
            return response()->json(['success' => $notification]);

        }

        return response()->json(['error' => $validator->errors()->all()]);

    }

    public function edit($id)
    {
       return ItemTaxType::find($id)->toJson();
    }

    public function update(Request $request)
    {
            $tax = ItemTaxType::find($request->id);
            $tax->fill($request->all());
            $tax->save();

        $notification = array(
            'message' => 'Successfully Save & Update',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);
    }

    public function destroy($id)
    {
        if (!Auth::user()->can('delete_tax'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $tax = ItemTaxType::find($id);
        $tax->delete();

        $notification = array(
            'message' => 'Tax rate has been deleted.',
            'alert-type' => 'error',
        );
        return redirect()->back()->with($notification);
    }

}
