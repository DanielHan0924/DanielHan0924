<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\roleRequest;
use App\Role;
use App\News;
use Entrust;
use Auth;
use Input;
use Validator;
use Image;
use File;
use Session;

class roleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $get_role = Role::all();
        $title = 'Manage User Role';
        return view('contents.admin.role.index', compact('title', 'get_role'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Entrust::can('manage_users')) // check permission
            return Redirect::to('/admin/dashboard')->with('message', 'Access denied'); // redirect to dashboard
        $title = 'Create User Role';
        return view('contents.admin.role.create', compact('title', 'page_name'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(roleRequest $request, Role $role)
    {
        if (!Entrust::can('manage_users')) // check permission
            return Redirect::to('/admin/dashboard')->with('message', 'Access denied'); // redirect to dashboard

        $data = $request->all();
        $role->fill($data);
        $role->name = strtolower(str_replace(' ', '_', $request->display_name));
        $role->save();

        /** Log entry */
        activity()->performedOn($role)->causedBy(Auth::user()->id)
            ->useLog('role_created')
            ->log($request->display_name);
        /**End Log entry */

        return redirect('role')->with('message', 'User Role Successfully Created.')->with('message_type', 'success');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Entrust::can('manage_users')) // check permission
            return Redirect::to('/admin/dashboard')->with('message', 'Access denied'); // redirect to dashboard
        $role = Role::find($id);
        $title = 'Edit User Role';
        return view('contents.admin.role.edit', compact('title', 'role'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(roleRequest $request, $id)
    {
        if (!Entrust::can('manage_users')) // check permission
            return Redirect::to('/admin/dashboard')->with('message', 'Access denied'); // redirect to dashboard
        $role = Role::find($id);
        $data = $request->all();
        $role->fill($data);
        $role->name = strtolower(str_replace(' ', '_', $request->display_name));
        $role->save();
        /** Log entry */
        activity()->performedOn($role)->causedBy(Auth::user()->id)
            ->useLog('role_updated')
            ->log($request->display_name);
        /**End Log entry */
        return redirect('role')->with('message', 'User Role Successfully Update.')->with('message_type', 'success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (!Entrust::can('manage_users')) // check permission
            return Redirect::to('/admin/dashboard')->with('message', 'Access denied'); // redirect to dashboard
        $role = Role::find($id);
        /** Log entry */
        activity()->performedOn($role)->causedBy(Auth::user()->id)
            ->useLog('role_updated')
            ->log($role->display_name);
        /**End Log entry */

        Role::where('id', $id)->delete();
        return redirect()->back()->with('message', 'User role has been deleted.')->with('message_type', 'success');
    }
}
