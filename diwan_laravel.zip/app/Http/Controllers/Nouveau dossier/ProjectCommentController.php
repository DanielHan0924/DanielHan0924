<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProjectCommentRequest;
use App\Project;
use App\ProjectComment;
use Auth;

class ProjectCommentController extends Controller
{
    public function postComment(ProjectCommentRequest $request, $id)
    {
        $comment = new ProjectComment;
        $comment->comment = $request->comment;
        $comment->project_id = $id;
        $comment->user_id = Auth::user()->id;
        $comment->save();
        activity()->log(Auth::user()->username . ' has commented on ' . Project::find($id)->name);
        $notification = array(
            'message' => 'New comment has been added',
            'alert-type' => 'success'
        );

        return redirect('/project/' . $id)->with($notification);
    }
}
