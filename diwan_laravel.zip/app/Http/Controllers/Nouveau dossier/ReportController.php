<?php

namespace App\Http\Controllers;

use App\Category;
use App\Customer;
use App\Product;
use App\Purchase_invoice;
use App\Purchase_invoice_details;
use App\Sales_invoice;
use App\Supplier;
use App\Transaction;
use App\Warehouse;
use Auth;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;

class ReportController extends Controller
{


    public function __construct(Transaction $transaction)
    {
        $this->transaction = $transaction;
    }


    /**
     * Return inventory Stock On Hand
     */
    public function inventoryStockOnHand($category_id = null, $warehouse_id = null)
    {

        if (!Auth::user()->can('report_inventory_stock_on_hand')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        if ($category_id == null && $warehouse_id == null) {
            $data['categories'] = Category::all();
            $data['warehouses'] = Warehouse::all();
            $data['title'] = 'Inventory Stock On Hand';
            $data['activeMenu'] = 'inventory_stock_on_hand';
            $data['products'] = Product::all();
            $data['totalProduct'] = DB::table('products')->sum('product_quantity');
            $data['totalCostValue'] = DB::table('products')->sum('product_wholesale_price');
            $data['totalRetailValue'] = DB::table('products')->sum('product_retail_price');
            return view('admin.report.inventory_stock_on_hand', $data);
        } else {

            $data['categories'] = Category::all();
            $data['warehouses'] = Warehouse::all();
            $data['title'] = 'Inventory Stock On Hand';
            $data['activeMenu'] = 'inventory_stock_on_hand';

            if ($category_id != 'all' && $warehouse_id != 'all') {
                $data['products'] = Product::where('category_id', $category_id)->where('warehouse_id', $warehouse_id)->get();
                $data['totalProduct'] = DB::table('products')->where('category_id', $category_id)->where('warehouse_id', $warehouse_id)->sum('product_quantity');
                $data['totalCostValue'] = DB::table('products')->where('category_id', $category_id)->where('warehouse_id', $warehouse_id)->sum('product_wholesale_price');
                $data['totalRetailValue'] = DB::table('products')->where('category_id', $category_id)->where('warehouse_id', $warehouse_id)->sum('product_retail_price');

            } elseif ($category_id == 'all' && $warehouse_id != 'all') {
                $data['products'] = Product::where('warehouse_id', $warehouse_id)->get();
                $data['totalProduct'] = DB::table('products')->where('warehouse_id', $warehouse_id)->sum('product_quantity');
                $data['totalCostValue'] = DB::table('products')->where('warehouse_id', $warehouse_id)->sum('product_wholesale_price');
                $data['totalRetailValue'] = DB::table('products')->where('warehouse_id', $warehouse_id)->sum('product_retail_price');

            } elseif ($category_id != 'all' && $warehouse_id == 'all') {
                $data['products'] = Product::where('category_id', $category_id)->get();
                $data['totalProduct'] = DB::table('products')->where('category_id', $category_id)->sum('product_quantity');
                $data['totalCostValue'] = DB::table('products')->where('category_id', $category_id)->sum('product_wholesale_price');
                $data['totalRetailValue'] = DB::table('products')->where('category_id', $category_id)->sum('product_retail_price');
            } else {
                return redirect('report/inventory-stock-on-hand');
            }


            $data['selectedCategory'] = $category_id;
            $data['selectedWarehouse'] = $warehouse_id;
            return view('admin.report.inventory_stock_on_hand', $data);

        }


    }

    public function inventoryStockOnHandByFilter(Request $request)
    {
        if (!Auth::user()->can('report_inventory_stock_on_hand')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        if ($request->category_id == 'all' && $request->warehouse_id == 'all') {
            return redirect('report/inventory-stock-on-hand');
        } else {
            return redirect('report/inventory-stock-on-hand/' . $request->category_id . '/' . $request->warehouse_id);
        }
    }


    public function salesReport($product = null, $customer_id = null, $location = null, $year = null, $month = null)
    {

        if (!Auth::user()->can('report_sales_report')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        if ($product == null && $customer_id == null && $location == null) {

            $currentYear = Carbon::parse()->format("Y");
            $currentMonth = Carbon::parse()->format("m");


            $data['title'] = 'Sales Report';
            $data['activeMenu'] = 'sales_report';
            $data['products'] = Product::all();
            $data['customersList'] = Customer::all();
            $data['warehouses'] = Warehouse::all();

            $orders = Sales_invoice::whereYear('invoice_date', $currentYear)->whereMonth('invoice_date', $currentMonth)->get();
            $data['total_order'] = count($orders);

            $data['sales_volume'] = 0;
            $data['sales_value'] = 0.00;
            $data['cost_value'] = 0.00;

            if ($data['total_order'] > 0) {
                foreach ($orders as $order) {
                    $data['sales_volume'] = $data['sales_volume'] + $order->salesInvoiceDetails->sum('qty');
                    $data['sales_value'] = $data['sales_value'] + $order->salesInvoiceDetails->sum('unit_total_price');

                    /** start cost value calculate */
                    foreach ($order->salesInvoiceDetails as $salesItem) {
                        if (Purchase_invoice_details::where('product_id', $salesItem->product_id)->orderBy('id', 'DESC')->count() > 0) {
                            $purchaseItem = Purchase_invoice_details::where('product_id', $salesItem->product_id)->orderBy('id', 'DESC')->first();
                            $salesQty = $salesItem->qty;
                            $calculateCostValue = $salesQty * $purchaseItem->unit_price;
                            $data['cost_value'] = $data['cost_value'] + $calculateCostValue;
                        }
                    }
                }
            }

            $data['profit'] = $data['sales_value'] - $data['cost_value'];
            $data['daily_sales'] = Sales_invoice::whereYear('invoice_date', $currentYear)->whereMonth('invoice_date', $currentMonth)->groupBy('invoice_date')->get();

            return view('admin.report.sales_report', $data);

        } else {


            $data['title'] = 'Sales Report';
            $data['activeMenu'] = 'sales_report';
            $data['products'] = Product::all();
            $data['customersList'] = Customer::all();
            $data['warehouses'] = Warehouse::all();

            if ($customer_id != 'all' && $location != 'all') {

                if ($product == 'all') {

                    $orders = Sales_invoice::whereYear('invoice_date', $year)->whereMonth('invoice_date', $month)->where('customer_id', $customer_id)->where('warehouse_id', $location)->get();
                    $data['daily_sales'] = Sales_invoice::whereYear('invoice_date', $year)->whereMonth('invoice_date', $month)->where('customer_id', $customer_id)->where('warehouse_id', $location)->groupBy('invoice_date')->get();

                } else {

                    $orders = Sales_invoice::join('sales_invoice_details', 'sales_invoices.id', 'sales_invoice_details.invoice_id')
                        ->whereYear('sales_invoices.invoice_date', $year)
                        ->whereMonth('sales_invoices.invoice_date', $month)
                        ->where('sales_invoices.customer_id', $customer_id)
                        ->where('sales_invoices.warehouse_id', $location)
                        ->where('sales_invoice_details.product_id', $product)
                        ->select('sales_invoices.*')
                        ->get();

                    $data['daily_sales'] = Sales_invoice::join('sales_invoice_details', 'sales_invoices.id', 'sales_invoice_details.invoice_id')
                        ->whereYear('sales_invoices.invoice_date', $year)
                        ->whereMonth('sales_invoices.invoice_date', $month)
                        ->where('sales_invoices.customer_id', $customer_id)
                        ->where('sales_invoices.warehouse_id', $location)
                        ->where('sales_invoice_details.product_id', $product)
                        ->groupBy('sales_invoices.invoice_date')
                        ->get();
                }


            } elseif ($customer_id != 'all' && $location == 'all') {

                if ($product == 'all') {

                    $orders = Sales_invoice::whereYear('invoice_date', $year)->whereMonth('invoice_date', $month)->where('customer_id', $customer_id)->get();
                    $data['daily_sales'] = Sales_invoice::whereYear('invoice_date', $year)->whereMonth('invoice_date', $month)->where('customer_id', $customer_id)->groupBy('invoice_date')->get();


                } else {

                    $orders = Sales_invoice::join('sales_invoice_details', 'sales_invoices.id', 'sales_invoice_details.invoice_id')
                        ->whereYear('sales_invoices.invoice_date', $year)
                        ->whereMonth('sales_invoices.invoice_date', $month)
                        ->where('sales_invoices.customer_id', $customer_id)
                        ->where('sales_invoice_details.product_id', $product)
                        ->select('sales_invoices.*')
                        ->get();

                    $data['daily_sales'] = Sales_invoice::join('sales_invoice_details', 'sales_invoices.id', 'sales_invoice_details.invoice_id')
                        ->whereYear('sales_invoices.invoice_date', $year)
                        ->whereMonth('sales_invoices.invoice_date', $month)
                        ->where('sales_invoices.customer_id', $customer_id)
                        ->where('sales_invoice_details.product_id', $product)
                        ->groupBy('sales_invoices.invoice_date')
                        ->get();

                }


            } elseif ($customer_id == 'all' && $location != 'all') {
                //

                if ($product == 'all') {

                    $orders = Sales_invoice::whereYear('invoice_date', $year)->whereMonth('invoice_date', $month)->where('warehouse_id', $location)->get();
                    $data['daily_sales'] = Sales_invoice::whereYear('invoice_date', $year)->whereMonth('invoice_date', $month)->where('warehouse_id', $location)->groupBy('invoice_date')->get();

                } else {

                    $orders = Sales_invoice::join('sales_invoice_details', 'sales_invoices.id', 'sales_invoice_details.invoice_id')
                        ->whereYear('sales_invoices.invoice_date', $year)
                        ->whereMonth('sales_invoices.invoice_date', $month)
                        ->where('sales_invoices.warehouse_id', $location)
                        ->where('sales_invoice_details.product_id', $product)
                        ->select('sales_invoices.*')
                        ->get();

                    $data['daily_sales'] = Sales_invoice::join('sales_invoice_details', 'sales_invoices.id', 'sales_invoice_details.invoice_id')
                        ->whereYear('sales_invoices.invoice_date', $year)
                        ->whereMonth('sales_invoices.invoice_date', $month)
                        ->where('sales_invoices.warehouse_id', $location)
                        ->where('sales_invoice_details.product_id', $product)
                        ->groupBy('sales_invoices.invoice_date')
                        ->get();
                }

            } elseif ($customer_id == 'all' && $location == 'all') {
                if ($product == 'all') {

                    $orders = Sales_invoice::whereYear('invoice_date', $year)->whereMonth('invoice_date', $month)->get();
                    $data['daily_sales'] = Sales_invoice::whereYear('invoice_date', $year)->whereMonth('invoice_date', $month)->groupBy('invoice_date')->get();

                } else {

                    $orders = Sales_invoice::join('sales_invoice_details', 'sales_invoices.id', 'sales_invoice_details.invoice_id')
                        ->whereYear('sales_invoices.invoice_date', $year)
                        ->whereMonth('sales_invoices.invoice_date', $month)
                        ->where('sales_invoice_details.product_id', $product)
                        ->select('sales_invoices.*')
                        ->get();

                    $data['daily_sales'] = Sales_invoice::join('sales_invoice_details', 'sales_invoices.id', 'sales_invoice_details.invoice_id')
                        ->whereYear('sales_invoices.invoice_date', $year)
                        ->whereMonth('sales_invoices.invoice_date', $month)
                        ->where('sales_invoice_details.product_id', $product)
                        ->groupBy('sales_invoices.invoice_date')
                        ->get();
                }
            } else {
                return redirect('report/sales-report');
            }


            $data['total_order'] = count($orders);
            $data['sales_volume'] = 0;
            $data['sales_value'] = 0.00;
            $data['cost_value'] = 0.00;

            if ($data['total_order'] > 0) {
                foreach ($orders as $order) {
                    $data['sales_volume'] = $data['sales_volume'] + $order->salesInvoiceDetails->sum('qty');
                    $data['sales_value'] = $data['sales_value'] + $order->salesInvoiceDetails->sum('unit_total_price');

                    /** start cost value calculate */

                    foreach ($order->salesInvoiceDetails as $salesItem) {
                        if (Purchase_invoice_details::where('product_id', $salesItem->product_id)->orderBy('id', 'DESC')->count() > 0) {
                            $purchaseItem = Purchase_invoice_details::where('product_id', $salesItem->product_id)->orderBy('id', 'DESC')->first();
                            $salesQty = $salesItem->qty;
                            $calculateCostValue = $salesQty * $purchaseItem->unit_price;
                            $data['cost_value'] = $data['cost_value'] + $calculateCostValue;
                        }
                    }

                }
            }
            $data['profit'] = $data['sales_value'] - $data['cost_value'];


            $data['selectedProduct'] = $product;
            $data['selectedCustomer'] = $customer_id;
            $data['selectedLocation'] = $location;
            $data['selectedYear'] = $year;
            $data['selectedMonth'] = $month;

            return view('admin.report.sales_report', $data);
        }

    }

    public function saleReportByFilter(Request $request)
    {
        if (!Auth::user()->can('report_sales_report')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        return redirect('report/sales-report/' . $request->product . '/' . $request->customer_id . '/' . $request->location . '/' . $request->year . '/' . $request->month);
    }

    public function purchaseReport($product = null, $supplier = null, $location = null)
    {
        if (!Auth::user()->can('report_purchase_report')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $currentYear = Carbon::parse()->format("Y");
        $data['title'] = 'Purchase Report';
        $data['activeMenu'] = 'purchase_report';


        if ($product == null && $supplier == null && $location == null) {
            $data['title'] = 'Purchase Report';
            $data['activeMenu'] = 'purchase_report';


            $data['products'] = Product::all();
            $data['supplierList'] = Supplier::all();
            $data['warehouses'] = Warehouse::all();

            $data['purchaseOrder'] = Purchase_invoice::whereYear('invoice_date', $currentYear)->get();
            $data['totalPurchaseInvoice'] = count($data['purchaseOrder']);

            $data['totalPurchaseVolume'] = 0;
            $data['totalPurchaseCostValue'] = 0.00;

            if ($data['totalPurchaseInvoice'] > 0) {
                foreach ($data['purchaseOrder'] as $purchaseOrders) {
                    $data['totalPurchaseVolume'] = $data['totalPurchaseVolume'] + $purchaseOrders->purchaseItemDetails->sum('qty');
                    $data['totalPurchaseCostValue'] = $data['totalPurchaseCostValue'] + $purchaseOrders->purchaseItemDetails->sum('unit_total_price');
                }
            }


            $data['currentYearPurchase'] = Purchase_invoice::whereYear('invoice_date', $currentYear)->groupBy('invoice_date')->get();


            return view('admin.report.purchase_report', $data);


        } else {
            if ($product == 'all' && $supplier == 'all' && $location == 'all') {
                return redirect('report/purchase-report');
            } else {


                $data['products'] = Product::all();
                $data['supplierList'] = Supplier::all();
                $data['warehouses'] = Warehouse::all();

                if ($supplier != 'all' && $location != 'all') {
                    $data['purchaseOrder'] = Purchase_invoice::where('supplier_id', $supplier)->where('warehouse_id', $location)->whereYear('invoice_date', $currentYear)->get();

                    if ($product == 'all') {
                        $data['currentYearPurchase'] = Purchase_invoice::where('supplier_id', $supplier)->where('warehouse_id', $location)->whereYear('invoice_date', $currentYear)->groupBy('invoice_date')->get();
                    } else {
                        $data['currentYearPurchase'] = Purchase_invoice::join('purchase_invoice_details', 'purchase_invoices.id', 'purchase_invoice_details.invoice_id')
                            ->where('purchase_invoices.supplier_id', $supplier)
                            ->where('purchase_invoices.warehouse_id', $location)
                            ->whereYear('purchase_invoices.invoice_date', $currentYear)
                            ->where('purchase_invoice_details.product_id', $product)
                            ->groupBy('purchase_invoices.invoice_date')
                            ->select('purchase_invoices.*')
                            ->get();
                    }


                } elseif ($supplier != 'all' && $location == 'all') {
                    $data['purchaseOrder'] = Purchase_invoice::where('supplier_id', $supplier)->whereYear('invoice_date', $currentYear)->get();


                    if ($product == 'all') {
                        $data['currentYearPurchase'] = Purchase_invoice::where('supplier_id', $supplier)->whereYear('invoice_date', $currentYear)->groupBy('invoice_date')->get();
                    } else {
                        $data['currentYearPurchase'] = Purchase_invoice::join('purchase_invoice_details', 'purchase_invoices.id', 'purchase_invoice_details.invoice_id')
                            ->where('purchase_invoices.supplier_id', $supplier)
                            ->whereYear('purchase_invoices.invoice_date', $currentYear)
                            ->where('purchase_invoice_details.product_id', $product)
                            ->select('purchase_invoices.*')
                            ->groupBy('purchase_invoices.invoice_date')
                            ->get();
                    }


                } elseif ($supplier == 'all' && $location != 'all') {
                    $data['purchaseOrder'] = Purchase_invoice::where('warehouse_id', $location)->whereYear('invoice_date', $currentYear)->get();

                    if ($product == 'all') {
                        $data['currentYearPurchase'] = Purchase_invoice::where('warehouse_id', $location)->whereYear('invoice_date', $currentYear)->groupBy('invoice_date')->get();
                    } else {
                        $data['currentYearPurchase'] = Purchase_invoice::join('purchase_invoice_details', 'purchase_invoices.id', 'purchase_invoice_details.invoice_id')
                            ->where('purchase_invoices.warehouse_id', $location)
                            ->whereYear('purchase_invoices.invoice_date', $currentYear)
                            ->where('purchase_invoice_details.product_id', $product)
                            ->select('purchase_invoices.*')
                            ->groupBy('purchase_invoices.invoice_date')
                            ->get();
                    }

                } else {
                    return redirect('report/purchase-report');
                }

                $data['totalPurchaseInvoice'] = count($data['purchaseOrder']);

                $data['totalPurchaseVolume'] = 0;
                $data['totalPurchaseCostValue'] = 0.00;

                if ($data['totalPurchaseInvoice'] > 0) {
                    foreach ($data['purchaseOrder'] as $purchaseOrder) {
                        if ($product == 'all') {
                            $data['totalPurchaseVolume'] = $data['totalPurchaseVolume'] + $purchaseOrder->purchaseItemDetails->sum('qty');
                            $data['totalPurchaseCostValue'] = $data['totalPurchaseCostValue'] + $purchaseOrder->purchaseItemDetails->sum('unit_total_price');
                        } else {

                            $data['totalPurchaseVolume'] = $data['totalPurchaseVolume'] + Purchase_invoice_details::where('invoice_id', $purchaseOrder->id)->where('product_id', $product)->sum('qty');;
                            $data['totalPurchaseCostValue'] = $data['totalPurchaseCostValue'] + Purchase_invoice_details::where('invoice_id', $purchaseOrder->id)->where('product_id', $product)->sum('unit_total_price');
                        }
                    }
                }


                $data['selectedProduct'] = $product;
                $data['selectedSupplier'] = $supplier;
                $data['selectedLocation'] = $location;


                return view('admin.report.purchase_report', $data);
            }
        }
    }


    public function purchaseReportByFilter(Request $request)
    {
        if (!Auth::user()->can('report_purchase_report')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        return redirect('report/purchase-report/' . $request->product . '/' . $request->supplier . '/' . $request->location);
    }


    public function expenseReport()
    {
        if (!Auth::user()->can('report_expense_report')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking
        $data['title'] = 'Expense Report';
        $data['activeMenu'] = 'expense_report';
        $year = date('Y');
        if (isset($_GET['year'])) {
            $year = $_GET['year'];
        }

        $month = array();
        $data['yearList'] = $this->transaction->getExpenseYears();


        $expenseList = $this->transaction->getExpenseReport($year);
        if (!empty($expenseList)) {
            foreach ($expenseList as $key => $value) {
                $month[$value->name][$value->month] = $value->amount;
            }
        }
        $data['expenseList'] = $month;
        $data['yearSelected'] = $year;

        $graphs = makeExpenseReportGraph($month);
        $data['graph'] = json_encode($graphs);

        return view('admin.report.expense_report', $data);
    }


    public function incomeReport()
    {
        if (!Auth::user()->can('report_income_report')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Income Report';
        $data['activeMenu'] = 'income_report';

        $year = date('Y');
        if (isset($_GET['year'])) {
            $year = $_GET['year'];
        }

        $month = array();
        $data['yearList'] = $this->transaction->getIncomeYears();

        $expenseList = $this->transaction->getIncomeReport($year);
        if (!empty($expenseList)) {
            foreach ($expenseList as $key => $value) {
                $month[$value->name][$value->month] = $value->amount;
            }
        }

        $data['incomeList'] = $month;
        $data['yearSelected'] = $year;

        // Graph Start
        $graphs = makeExpenseReportGraph($month);
        $data['graph'] = json_encode($graphs);
        //d($data,1);
        // Graph End
        return view('admin.report.income_report', $data);
    }


    public function incomeVsExpense()
    {
        if (!Auth::user()->can('report_income_vs_expense')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Income VS Expense';
        $data['activeMenu'] = 'income_vs_expense';
        $data['yearList'] = DB::SELECT("SELECT DISTINCT(YEAR(trans_date)) AS year FROM `bank_trans`");

        $year = date('Y');
        if (isset($_GET['year'])) {
            $year = $_GET['year'];
        }
        $data['yearSelected'] = $year;
        $data['dataList'] = $this->transaction->incomeVsExpense($year);

        return view('admin.report.income_vs_expense', $data);
    }


    public function purchaseReportCsv()
    {


        // Date, Order, Quantity, Cost
        $csvExporter = new \Laracsv\Export();
        $fields = ['Date', 'Order', 'Quantity', 'Cost'];
        $purchase_data = [];
        $currentYear = Carbon::parse()->format("Y");
        $currentYearPurchase = Purchase_invoice::whereYear('invoice_date', $currentYear)->groupBy('invoice_date')->get();

        $csvExporter->beforeEach(function ($purchase) {
            $purchase->Date = formatDate($purchase->invoice_date);
            $purchase->Order = numberOfPurchaseOrderByDate($purchase->invoice_date);
            $purchase->Quantity = purchaseVolumeByDate($purchase->invoice_date);
            $purchase->Cost = purchaseCostByDate($purchase->invoice_date);
        });

        $csvExporter->build(Purchase_invoice::whereYear('invoice_date', $currentYear)->groupBy('invoice_date')->get(),
            ['Date', 'Order', 'Quantity', 'Cost'])->download();


    }


    /**
     * @param $time
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function purchaseReportDateWise($time)
    {
        $data['title'] = 'Purchase Report';
        $data['activeMenu'] = 'purchase_report';
        $date = DbDateFormat(date('d-m-Y', $time));

        $data['purchaseOrder'] = Purchase_invoice::where('invoice_date', $date)->get();

        //dd($data['purchaseOrder']);

        $data['date'] = formatDate(date('d-m-Y', $time));
        return view('admin.report.purchase_report_date_wise', $data);
    }

    /**
     * @param $time
     */
    public function salesReportDateWise($time)
    {

        $data['title'] = 'sales Report';
        $data['activeMenu'] = 'sales_report';
        $date = DbDateFormat(date('d-m-Y', $time));
        $data['date'] = formatDate(date('d-m-Y', $time));
        $data['salesOrder'] = Sales_invoice::where('invoice_date', $date)->get();
        return view('admin.report.sales_report_date_wise', $data);
    }


}
