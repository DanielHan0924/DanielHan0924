<?php

namespace App\Http\Controllers;

use App\Http\Requests\WarehouseRequest;
use App\Warehouse;
use Auth;

class WareHouseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index()
    {
        if (!Auth::user()->can('create_warehouse') && !Auth::user()->can('edit_warehouse') && !Auth::user()->can('delete_warehouse') )
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Warehouses';
        $data['activeMenu'] = 'warehouses';
        $data['warehouses'] = Warehouse::all();
        return view('admin.warehouse.index', $data);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Auth::user()->can('create_warehouse'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Add New Product Warehouse';
        $data['activeMenu'] = 'warehouses';
        return view('admin.warehouse.create', $data);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param WarehouseRequest $request
     * @return \Illuminate\Http\Response
     */
    public function store(WarehouseRequest $request)
    {


        if (!Auth::user()->can('create_warehouse'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        Warehouse::create($request->all());

        activity()->log('User ' . Auth::user()->username . ' has created a warehouse name ' . $request->title);

        $notification = array(
            'message' => 'New Product Warehouse Has Been Created.',
            'alert-type' => 'success'
        );

        return redirect('warehouse')->with($notification);

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Auth::user()->can('edit_warehouse'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Edit Warehouse';
        $data['activeMenu'] = 'warehouses';
        $data['warehouse'] = Warehouse::find($id);
        return view('admin.warehouse.edit', $data);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param WarehouseRequest $request
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(WarehouseRequest $request, $id)
    {

        if (!Auth::user()->can('edit_warehouse'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $warehouse = Warehouse::find($id);
        $warehouse->title = $request->title;
        $warehouse->description = $request->description;
        $warehouse->save();

        activity()->log('User ' . Auth::user()->username . ' has update a warehouse name ' . $request->title);

        $notification = array(
            'message' => 'Warehouse Name Has Been Updated.',
            'alert-type' => 'success'
        );

        return redirect('warehouse')->with($notification);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {

        if (!Auth::user()->can('delete_warehouse'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $warehouse = Warehouse::find($id);
        activity()->log('User ' . Auth::user()->username . ' has deleted a warehouse name ' . $warehouse->title);
        $notification = array(
            'message' => 'Warehouse has been deleted',
            'alert-type' => 'error'
        );
        $warehouse->delete();
        return redirect('warehouse')->with($notification);
    }
}
