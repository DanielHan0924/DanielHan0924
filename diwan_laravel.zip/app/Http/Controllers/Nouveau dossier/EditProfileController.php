<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserRequest;
use App\User;
use Auth;

class EditProfileController extends Controller
{
    public function editProfile()
    {
        $data['title'] = 'Edit Profile';
        $data['activeMenu'] = 'edit_profile';
        $data['userDetail'] = Auth::user();
        return view('admin.profile.edit', $data);
    }


    public function updateProfile($id, UserRequest $request)
    {
        $user = User::find($id);
        $filename = uniqid();
        $user->fill($request->all());
        if ($request->hasFile('profile_image')) {
            $extension = $request->file('profile_image')->getClientOriginalExtension();
            $request->file('profile_image')->move('public/uploads/users_profile', $filename . '.' . $extension);
            $user->profile_image = $filename . '.' . $extension;
        }
        $user->save();
        $notification = array(
            'message' => 'Profile has been updated.',
            'alert-type' => 'info'
        );
        activity()->log(Auth::user()->username . ' has updated his profile');
        return redirect()->back()->with($notification);

    }
}
