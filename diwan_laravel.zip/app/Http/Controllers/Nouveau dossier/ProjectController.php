<?php

namespace App\Http\Controllers;

use App\Event;
use App\Http\Requests\ProjectRequest;
use App\Project;
use App\User;
use Auth;
use DB;
use Illuminate\Http\Request;
use Redirect;
use Session;
use Entrust;

class ProjectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        if (!Auth::user()->can('create_project') && !Auth::user()->can('manage_project_room') && !Auth::user()->can('edit_project') && !Auth::user()->can('delete_project') )
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Projects';
        $data['activeMenu'] = 'projects';

        $data['waiting'] = Project::where('status', '=', 'Waiting')->count();
        $data['progress'] = Project::where('status', '=', 'Progress')->count();
        $data['finish'] = Project::where('status', '=', 'Finish')->count();
        $data['total'] = Project::count();

        if(memberRole(Auth::user()->id) == "Business Owner")
        {
            $data['projects'] = Project::all();
        } else {

            $project_id = [];
            $assignedProjects = DB::table('assigned_projects')->where('user_id', Auth::user()->id)->select('project_id')->get();

            foreach ($assignedProjects as $key => $assignedProject)
            {
                $project_id[$key] = $assignedProject->project_id;
            }

            $data['projects'] = Project::whereIn('id', $project_id)->get();
        }


        return view('admin.project.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        if (!Auth::user()->can('create_project'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Create Project';
        $data['activeMenu'] = 'create_project';
        $data['customers'] = User::where('user_type', 0)->get();
        $data['employees'] = User::where('user_type', 1)->get();
        return view('admin.project.create', $data);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param ProjectRequest $request
     * @return void
     */
    public function store(ProjectRequest $request, Project $project)
    {

        if (!Auth::user()->can('create_project'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $link_to_cal = $request->link_to_cal;
        $event = new Event;

        if ($link_to_cal != 0) {
            $event->title = '[PROJECT] - ' . $request->name;
            if ($request->note === null) {
                $event->description = 'Project - ' . $request->name . ' has been created';
            } else {
                $event->description = $request->note;
            }
            $event->color = '#dc3545';
            if ($link_to_cal == 1) {
                $event->start = $request->end_date;
                $event->end = $request->end_date;
            } else if ($link_to_cal == 2) {
                $event->start = $request->start_date;
                $event->end = $request->end_date;
            }
            $event->save();
        }


        $data = $request->all();
        $project->fill($data);
        $project->start_date = DbDateFormat($request->start_date);
        $project->end_date = DbDateFormat($request->end_date);
        $project->save();

        $project->users()->sync($request->user_id);
        // Let's start logging.

        activity()->log('User ' . Auth::user()->username . ' has created project name:' . $request->name);

        $notification = array(
            'message' => 'Project has been created.',
            'alert-type' => 'success'
        );


        return redirect()->route('project.index')->with($notification);

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @param Request $request
     * @return \Illuminate\Http\Response
     * @throws \Throwable
     */
    public function show($id, Request $request)
    {
        if (!Auth::user()->can('manage_project_room'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['title'] = 'Project Room';
        $data['activeMenu'] = 'show_project';
        $data['project'] = Project::find($id);

        $attachments = DB::table('project_attachments')
            ->where('project_id', '=', $data['project']->id)
            ->join('projects', 'projects.id', '=', 'project_attachments.project_id')
            ->select(DB::raw('attachment_username,project_attachments.id,project_attachments.attachment_title,
                                    attachment_description,project_attachments.created_at,project_attachments.file'))
            ->orderBy('project_attachments.id', 'desc')->get();


        $comments = DB::table('project_comments')->where('project_id', '=', $data['project']->id)
            ->join('projects', 'projects.id', '=', 'project_comments.project_id')
            ->select(DB::raw('project_comments.user_id,project_comments.id,project_comments.comment,project_comments.created_at'))
            ->orderBy('project_comments.id', 'desc')->paginate(10);


        $data['comments'] = $comments;

        // handle comment pagination via ajax.

        if ($request->ajax()) {
            return view('admin.project.comments', ['comments' => $comments])->render();
        }

        $data['attachments'] = $attachments;

        $selected_employees = array();
        foreach ($data['project']->users as $user) {
            $selected_employees[] = $user->full_name;
        }
        $data['employees'] = $selected_employees;


        return view('admin.project.show', $data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Auth::user()->can('edit_project'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking



        $project = Project::find($id);

        $customer = User::where('user_type', 0)->get();
        $employees = User::where('user_type', 1)->get();
        $data['customers'] = $customer;
        $data['employees'] = $employees;
        $data['title'] = 'Edit ' . $project->name;
        $data['activeMenu'] = 'edit_project';
        $data['project'] = $project;
        return view('admin.project.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param ProjectRequest $request
     * @param Project $project
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(ProjectRequest $request, Project $project)
    {
        if (!Auth::user()->can('edit_project'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $link_to_cal = $request->link_to_cal;

        if ($link_to_cal != 0 AND $request->link_to_cal != $project->link_to_cal) {

            $eventTitle = '[PROJECT] - ' . $request->name;
            Event::where('title', $eventTitle)->delete();
            $event = new Event;

            $event->title = '[PROJECT] - ' . $request->name;
            if ($request->note === null) {
                $event->description = 'Project - ' . $request->name . ' has been created';
            } else {
                $event->description = $request->note;
            }
            $event->color = '#dc3545';
            if ($link_to_cal == 1) {
                $event->start = $request->end_date;
                $event->end = $request->end_date;
            } else if ($link_to_cal == 2) {
                $event->start = $request->start_date;
                $event->end = $request->end_date;
            }
            $event->save();
        }

        $data = $request->all();
        $project->fill($data);
        $project->name = $request->name;
        $project->status = $request->status;
        $project->priority = $request->priority;
        $project->progress = $request->progress;
        $project->budget = $request->budget;
        $project->tags = $request->tags;
        $project->start_date = DbDateFormat($request->start_date);
        $project->end_date = DbDateFormat($request->end_date);
        $project->note = $request->note;
        $project->save();
        $project->users()->sync($request->user_id);


        activity()->log('User ' . Auth::user()->username . ' has updated project name:' . $request->name);

        $notification = array(
            'message' => 'Project ' . $request->name . ' has been updated',
            'alert-type' => 'info'
        );

        return redirect('project')->with($notification);


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        if (!Auth::user()->can('delete_project'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $project = Project::find($id);
        $project->delete();
        activity()->log('User ' . Auth::user()->username . ' has deleted a project:');
        $notification = array(
            'message' => 'Project has been deleted',
            'alert-type' => 'error'
        );
        return redirect('project')->with($notification);

    }
}
