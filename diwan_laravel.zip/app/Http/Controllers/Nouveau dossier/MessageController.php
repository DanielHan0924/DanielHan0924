<?php

namespace App\Http\Controllers;

use App\Http\Requests\MessageRequest;
use App\Message;
use App\User;
use Auth;
use Request;

class MessageController extends Controller
{
    public function inbox()
    {
        if (!Auth::user()->can('manage_message'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['messages'] = Message::whereToUserId(Auth::user()->id)->whereDeleteReceiver('0')->orderBy('created_at', 'desc')->get();
        $data['count_inbox'] = count($data['messages']);
        $data['count_sent'] = Message::whereFromUserId(Auth::user()->id)->whereDeleteSender('0')->count();
        $data['title'] = 'Inbox';
        $data['token'] = csrf_token();
        $data['activeMenu'] = 'message_box';
        return view('admin.message.inbox', $data);
    }

    public function sent()
    {

        $data['activeMenu'] = 'message_box';
        $data['title'] = 'Sent messages';
        $data['token'] = csrf_token();
        $data['messages'] = Message::whereFromUserId(Auth::user()->id)->whereDeleteSender('0')->orderBy('created_at', 'desc')->get();
        $data['count_sent'] = count($data['messages']);
        $data['count_inbox'] = Message::whereToUserId(Auth::user()->id)->whereDeleteReceiver('0')->count();
        return view('admin.message.sent', $data);

    }

    public function lists($type, Request $request)
    {
        if ($type == 'sent')
            $data['messages'] = Message::whereFromUserId(Auth::user()->id)->whereDeleteSender('0')->orderBy('created_at', 'desc')->get();
        else
            $data['messages'] = Message::whereToUserId(Auth::user()->id)->whereDeleteReceiver('0')->orderBy('created_at', 'desc')->get();
    }

    public function compose()
    {
        $data['messages'] = Message::whereToUserId(Auth::user()->id)->whereDeleteReceiver('0')->get();
        $data['count_inbox'] = count($data['messages']);
        $data['count_sent'] = Message::whereFromUserId(Auth::user()->id)->whereDeleteSender('0')->count();
        $data['title'] = 'Compose Message';
        $data['activeMenu'] = 'message_box';
        $data['users'] = User::where('id', '!=', Auth::id())->get();
        return view('admin.message.compose', $data);
    }

    public function store(MessageRequest $request)
    {
        $data = $request->all();
        $filename = uniqid();
        if ($request->hasFile('file')) {
            $extension = $request->file('file')->getClientOriginalExtension();
            $request->file('file')->move('public/uploads/message_attachments/', $filename . "." . $extension);
            $data['attachments'] = $filename . "." . $extension;
        } else
            $data['attachments'] = '';

        $message = new Message;
        $message->fill($data);
        $message->body = $request->body;
        $message->from_user_id = Auth::user()->id;
        $message->is_read = 0;
        $message->save();
        activity()->log('Message sent');

        if ($request->ajax()) {
            return 'Message sent';
        }

        return redirect('/message/compose')->with('message', 'Message has been sent.');
    }

    public function download($id)
    {
    }

    public function view($id)
    {
        $message = Message::find($id);
        if (!$message)
            return redirect('/message')->with('message', 'Invalid link');

        $query = User::whereNotNull('id');
        if ($message->from_user_id == Auth::user()->id) {
            $message_type = 'sent';
            $query->where('id', '=', $message->to_user_id);

        } elseif ($message->to_user_id == Auth::user()->id) {
            $message_type = 'inbox';

            // Update the message status as read
            $message->is_read = 1;
            $query->where('id', '=', $message->from_user_id);
        } else
            return redirect('/message')->with('message', 'Invalid link');
        $user = $query->first();
        $data['count_inbox'] = Message::whereToUserId(Auth::user()->id)->whereDeleteReceiver('0')->count();
        $data['count_sent'] = Message::whereFromUserId(Auth::user()->id)->whereDeleteSender('0')->count();
        $message->save();

        $data['title'] = 'View Message Detail';
        $data['activeMenu'] = 'message_box';
        $data['message'] = $message;
        $data['user'] = $user;


        return view('admin.message.view', $data);


    }

    public function delete($id, $token)
    {
        $message = Message::find($id);
        if (!$message || ($message->to_user_id != Auth::user()->id && $message->from_user_id != Auth::user()->id))
            return redirect('/message')->with('message', 'Invalid Link');

        if ($message->to_user_id == Auth::user()->id)
            $message->delete_receiver = 1;
        else
            $message->delete_sender = 1;
        $message->save();

        return redirect('/message')->with('message', 'Message has been deleted');

    }

}
