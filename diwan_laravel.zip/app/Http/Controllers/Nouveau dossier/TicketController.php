<?php

namespace App\Http\Controllers;

use App\Http\Requests\TicketRequest;
use App\Project;
use App\Tickets;
use App\User;
use Auth;
use DB;
use Illuminate\Http\Request;
use Redirect;
use Session;

class TicketController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        if (!Auth::user()->can('create_ticket') && !Auth::user()->can('view_ticket') && !Auth::user()->can('edit_ticket') && !Auth::user()->can('delete_ticket') )
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Tickets';
        $data['activeMenu'] = 'tickets';

        if(memberRole(Auth::user()->id) == "Business Owner")
        {
            $data['tickets'] = Tickets::where('status', '=', 'Open')->where('answer_status', 'Open')->get();
            $data['tickets_answered'] = Tickets::where('status', '=', 'Open')->where('answer_status', 'Answered')->get();

        } else {
            $data['tickets'] = Tickets::where('customer_id', Auth::user()->id)->where('status', '=', 'Open')->where('answer_status', 'Open')->get();
            $data['tickets_answered'] = Tickets::where('customer_id', Auth::user()->id)->where('status', '=', 'Open')->where('answer_status', 'Answered')->get();

        }


        return view('admin.ticket.index', $data);

    }


    public function answeredTickets()
    {


        if (!Auth::user()->can('manage_answered_tickets'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Tickets';
        $data['activeMenu'] = 'tickets_answered';
        $data['tickets'] = Tickets::where('status', '=', 'Closed')->get();
        $data['tickets_answered'] = Tickets::where('status', '=', 'Open')->where('answer_status', 'Answered')->get();
        return view('admin.ticket.index', $data);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        if (!Auth::user()->can('create_ticket'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Create Ticket';
        $data['activeMenu'] = 'create_ticket';
        $data['customers'] = User::where('user_type', 0)->get();
        $data['employees'] = User::where('user_type', 1)->get();
        $data['projects'] = Project::all();
        return view('admin.ticket.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     * @param TicketRequest $request
     * @param Tickets $ticket
     * @return \Illuminate\Http\Response
     */
    public function store(TicketRequest $request, Tickets $ticket)
    {

        if (!Auth::user()->can('create_ticket'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data = $request->all();
        //dd($data);
        $ticket->fill($data);
        $ticket->save();
        $ticket->employees()->sync($request->user_id);
        activity()->log(Auth::user()->username . ' has created ' . $request->subject);

        $notification = array(
            'message' => 'A new ticket has been created',
            'alert-type' => 'success'
        );

        return redirect()->to('ticket')->with($notification);

    }

    /**
     * Display the specified resource.
     * @param  int $id
     * @param Request $request
     * @return \Illuminate\Http\Response
     * @throws \Throwable
     */
    public function show($id, Request $request)
    {
        if (!Auth::user()->can('view_ticket'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $ticket = Tickets::find($id);
        $data['title'] = 'Ticket Details';
        $data['activeMenu'] = 'tickets';
        $data['ticket'] = $ticket;

        $comments = DB::table('ticket_comments')
            ->where('ticket_id', '=', $ticket->id)
            ->join('tickets', 'tickets.id', '=', 'ticket_comments.ticket_id')
            ->join('users', 'users.username', '=', 'ticket_comments.comment_username')
            ->select(DB::raw('users.username,ticket_comments.id,ticket_comments.attachment,users.id as user_id,comment,ticket_comments.created_at,first_name,last_name'))->orderBy('ticket_comments.id', 'desc')->paginate(10);


        /**
         * Handle Ajax pagination
         */

        if ($request->ajax()) {

            return view('admin.ticket.comments', ['comments' => $comments])->render();
            //return Response::json(View::make('admin.ticket.show', ['comments' => $comments]))->render();
        }

        $data['comments'] = $comments;
        return view('admin.ticket.show', $data);
    }

    /**
     * Show the form for editing the specified resource.
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Auth::user()->can('edit_ticket'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $ticket = Tickets::find($id);
        $data['title'] = 'Edit ' . $ticket->subject;
        $data['activeMenu'] = 'create_ticket';
        $data['ticket'] = $ticket;
        $data['customers'] = User::where('user_type', 0)->get();
        $data['employees'] = User::where('user_type', 1)->get();
        $data['projects'] = Project::all();


        return view('admin.ticket.edit', $data);


    }

    /**
     * Update the specified resource in storage.
     * @param TicketRequest $request
     * @param Tickets $ticket
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(TicketRequest $request, Tickets $ticket)
    {
        if (!Auth::user()->can('edit_ticket'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data = $request->all();
        $ticket->fill($data);
        $ticket->subject = $request->subject;
        $ticket->description = $request->description;
        $ticket->priority = $request->priority;
        $ticket->status = $request->status;
        $ticket->save();
        $ticket->employees()->sync($request->user_id);
        activity()->log('User ' . Auth::user()->username . ' has updated ticket with subject name:' . $request->subject);

        $notification = array(
            'message' => 'Ticket details updated.',
            'alert-type' => 'info'
        );

        return redirect('ticket')->with($notification);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (!Auth::user()->can('delete_ticket'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $ticket = Tickets::find($id);

        activity()->log('User ' . Auth::user()->username . ' has deleted ticket with subject name:' . $ticket->subject);

        $ticket->delete();

        $notification = array(
            'message' => 'Ticket has been deleted',
            'alert-type' => 'error'
        );

        return redirect('ticket')->with($notification);
    }
}
