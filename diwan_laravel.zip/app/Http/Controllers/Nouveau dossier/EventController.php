<?php

namespace App\Http\Controllers;

use App\Event;
use Illuminate\Http\Request;
use Auth;

class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!Auth::user()->can('manage_event'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Events';
        $data['activeMenu'] = 'events';
        return view('admin.event.index', $data);
    }


    public function getEvents()
    {
        return Event::all()->toJson();
    }


    /**
     * @param Request $request
     * @return void
     */
    public function dragUpdateEvent(Request $request)
    {


        $start = $request->start;
        $end = $request->end;

        $event = Event::findOrFail($request->id);
        $event->start = $start;
        $event->end = $end;
        $event->save();
        echo true;


    }


    /**
     * @param Request $request
     */

    public function addEvent(Request $request)
    {
        $event = new Event;
        $event->title = $request->title;
        $event->start = $request->start;
        $event->end = $request->end;
        $event->description = $request->description;
        $event->color = $request->color;

        $event->save();

    }


    public function updateEvent(Request $request)
    {
        $event = Event::findOrFail($request->id);
        $event->title = $request->title;
        $event->description = $request->description;
        $event->color = $request->color;
        $event->save();

    }


    public function deleteEvent($id)
    {
        $event = Event::findOrFail($id);
        $event->delete();
    }

}
