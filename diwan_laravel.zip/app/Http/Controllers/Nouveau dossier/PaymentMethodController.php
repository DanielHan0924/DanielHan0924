<?php

namespace App\Http\Controllers;

use App\PaymentTerm;
use Illuminate\Http\Request;
use Auth;
use Validator;

class PaymentMethodController extends Controller
{
    public function index()
    {

        if (!Auth::user()->can('create_payment_method') && !Auth::user()->can('edit_payment_method') && !Auth::user()->can('delete_payment_method')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['title'] = 'Payment Methods';
        $data['activeMenu'] = 'payment_methods';
        $data['methods'] = PaymentTerm::all();
        return view('admin.configuration.payment-methods', $data);
    }


    public function addPaymentMethod(Request $request, PaymentTerm $paymentTerm)
    {

        if (!Auth::user()->can('create_payment_method')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data = $request->all();
        unset($data['_token']);
        $paymentTerm->fill($data);

        if ($request->default == 1) {
            PaymentTerm::where('default', 1)->update(['default' => 0]);
        }


        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:payment_terms',
            'default' => 'required',

        ]);

        if ($validator->passes()) {
            $paymentTerm->save();
            $notification = array(
                'message' => 'New payment method has been added.',
                'alertType' => 'success',
            );
            return response()->json(['success' => $notification]);

        }

        return response()->json(['error' => $validator->errors()->all()]);


    }


    public function edit($id)
    {
        return PaymentTerm::find($id)->toJson();
    }

    public function update(Request $request)
    {
        $paymentMethod = PaymentTerm::find($request->id);
        $paymentMethod->fill($request->all());
        $paymentMethod->save();

        $notification = array(
            'message' => 'Successfully Save & Update',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);
    }


    function deletePaymentMethod($id)
    {
        if (!Auth::user()->can('delete_payment_method')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking
        if (!Auth::user()->can('create_payment_method')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $term = PaymentTerm::find($id);
        $term->delete();

        $notification = array(
            'message' => 'Payment method has been deleted',
            'alert-type' => 'error',
        );
        return redirect()->back()->with($notification);

    }
}
