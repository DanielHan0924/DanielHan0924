<?php

namespace App\Http\Controllers;

use App\Http\Requests\TicketCommentRequest;
use App\TicketComments;
use App\Tickets;
use Auth;
use Illuminate\Http\Request;

class TicketCommentController extends Controller
{
    public function postTicketComment(TicketCommentRequest $request, TicketComments $comments)
    {
        $comments->fill($request->all());


        // File handling
        $filename = uniqid();
        if ($request->hasFile('comment_attachment')) {
            //dd($request->comment_attachment);
            $extension = $request->file('comment_attachment')->getClientOriginalExtension();
            $request->file('comment_attachment')->move('public/uploads/attachment_files/', $filename . "." . $extension);
            $comments->attachment = $filename . "." . $extension;
        }

        $comments->comment_username = Auth::user()->username;
        $comments->user_id = Auth::user()->id;


        $user_type = Auth::user()->user_type;
        $ticket = Tickets::find($request->ticket_id);
        if ($user_type == 2 || $user_type == 1) {
            $ticket->answer_status = 'Answered';
        } else {
            $ticket->answer_status = 'Open';
        }

        $ticket->save();

        $comments->save();
        activity()->log(Auth::user()->username . ' has commented on ' . Tickets::find($request->ticket_id)->subject);

        $notification = array(
            'message' => 'A new comment has been published',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);

    }

    public function destroy($id, Request $request)
    {


        $ticketComment = TicketComments::find($id);
        activity()->log(Auth::user()->username . ' has deleted comment');
        $id = $ticketComment->ticket->id;
        $ticketComment->delete();

        $notification = array(
            'message' => 'Comment has been deleted',
            'alert-type' => 'error'
        );
        return redirect()->to('/ticket/' . $id)->with($notification);
    }
}
