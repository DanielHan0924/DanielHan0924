<?php

namespace App\Http\Controllers;

use App\Http\Requests\TaskRequest;
use App\Project;
use App\Task;
use App\User;
use Auth;
use Redirect;


class TaskController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!Auth::user()->can('create_task') && !Auth::user()->can('view_task') && !Auth::user()->can('edit_task') && !Auth::user()->can('delete_task') )
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Tasks';
        $data['activeMenu'] = 'tasks';
        $data['due'] = Task::where('status', '=', 'Due')->count();
        $data['progress'] = Task::where('status', '=', 'Progress')->count();
        $data['done'] = Task::where('status', '=', 'Done')->count();
        $data['total'] = Task::count();
        $data['tasks'] = Task::all();


        return view('admin.task.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Auth::user()->can('create_task'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['projects'] = Project::all();
        $data['title'] = 'Add New task';
        $data['activeMenu'] = 'tasks';
        $data['employees'] = User::where('user_type', 1)->get();
        return view('admin.task.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param TaskRequest $request
     * @return \Illuminate\Http\Response
     */
    public function store(TaskRequest $request, Task $task)
    {
        if (!Auth::user()->can('create_task'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data = $request->all();
        $task->fill($data);
        $task->user_id = Auth::user()->id;
        $task->save();
        $task->users()->sync($request->user_id);

        $notification = array(
            'message' => 'New Task has been created',
            'alert-type' => 'success'
        );
        return redirect()->route('task.index')->with($notification);

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Auth::user()->can('edit_task'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['projects'] = Project::all();
        $data['title'] = 'Edit task';
        $data['activeMenu'] = 'tasks';
        $data['task'] = Task::findOrFail($id);
        $data['employees'] = User::where('user_type', 1)->get();
        return view('admin.task.edit', $data);

    }

    /**
     * Update the specified resource in storage.
     * @param TaskRequest $request
     * @param Task $task
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(TaskRequest $request, Task $task)
    {

        if (!Auth::user()->can('edit_task'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data = $request->all();
        $task->fill($data);
        $task->project_id = $request->project_id;
        $task->name = $request->name;
        $task->status = $request->status;
        $task->start_date = $request->start_date;
        $task->due_date = $request->due_date;
        $task->description = $request->description;
        $task->priority = $request->priority;
        $task->user_id = Auth::user()->id;
        $task->save();
        $task->users()->sync($request->user_id);

        activity()->log('User ' . Auth::user()->username . ' has updated task name:' . $request->name);

        $notification = array(
            'message' => 'Task has been updated',
            'alert-type' => 'info'
        );
        return Redirect::to('task')->with($notification);

    }

    /**
     * Remove the specified resource from storage.
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        if (!Auth::user()->can('delete_task'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $task = Task::findOrFail($id);
        $task->delete();
        $notification = array(
            'message' => 'Task has been deleted',
            'alert-type' => 'error'
        );
        return Redirect::to('task')->with($notification);
    }

    public function viewTask($id)
    {
        $task = Task::findOrFail($id);
        return $task->toJson();

    }
}
