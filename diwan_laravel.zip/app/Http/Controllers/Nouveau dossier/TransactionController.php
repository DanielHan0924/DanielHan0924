<?php

namespace App\Http\Controllers;

use App\Account;
use App\ApplicationSetting;
use App\Bank_tran;
use App\Country;
use App\Customer;
use App\EmailConfig;
use App\Http\Requests\TransactionRequest;
use App\PaymentTerm;
use App\Transaction;
use App\TransactionCategory;
use Auth;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index()
    {
        if (!Auth::user()->can('create_transaction') && !Auth::user()->can('view_transaction') && !Auth::user()->can('delete_transaction')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['title'] = 'Transaction Lists';
        $data['activeMenu'] = 'transactions';
        $data['transactions'] = Transaction::all();
        return view('admin.transaction.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Auth::user()->can('create_transaction')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Add new transaction';
        $data['activeMenu'] = 'create_transaction';
        $data['customers'] = Customer::all();
        $data['accounts'] = Account::all();
        $data['payments'] = PaymentTerm::get();
        $data['transaction_categories'] = TransactionCategory::orderBy('name', 'asc')->get();
        return view('admin.transaction.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param TransactionRequest $request
     * @return void
     */
    public function store(TransactionRequest $request)
    {
        if (!Auth::user()->can('create_transaction')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $debit = 0;
        $credit = 0;

        $customer_id = $request->customer_id;
        $customer_name = $request->customer_name;
        $account_id = $request->account_id;
        $date = $request->date;
        $amount = $request->amount;
        $pay_type = $request->type;
        $transactionCategory = TransactionCategory::find($request->category_id);
        $transaction_category_name = $transactionCategory->name;
        $paymentMethod = PaymentTerm::find($request->mayment_method_id);
        $pay_method = $paymentMethod->name;
        $note = $request->note;

        if ($pay_type == 'Income') {
            $debit = $amount;
        } elseif ($pay_type == 'Expense') {
            $credit = $amount;
        }

        $transaction = new Transaction;
        $transaction->customer_name = $customer_name;
        if ($customer_id > 0) {
            $transaction->customer_id = $customer_id;
        }

        $transaction->account_id = $account_id;
        $transaction->date = $date;
        $transaction->debit = $debit;
        $transaction->credit = $credit;
        $transaction->transaction_category_name = $transaction_category_name;
        $transaction->pay_method = $pay_method;
        $transaction->note = $note;
        $transaction->type = $pay_type;
        $transaction->save();



        $bankTran = new Bank_tran();
        $bankTran->account_no = $account_id;
        $bankTran->category_id = $request->category_id;
        $bankTran->payment_method = $request->mayment_method_id;

        if ($pay_type == 'Income') {
            $bankTran->amount =  $amount;
            $bankTran->trans_type = "income";

        } elseif ($pay_type == 'Expense') {
            $bankTran->amount = "-" . $amount;
            $bankTran->trans_type = "expense";
        }

        $bankTran->trans_date = DbDateFormat($request->date);
        $bankTran->person_id = Auth::user()->id;
        $bankTran->reference = "";
        if ($request->note != '') {
            $bankTran->description = $request->note;
        } else {
            $bankTran->description = '';
        }
        $bankTran->save();



        // Once transaction is done, also update amount in account table



        $account = Account::findOrFail($account_id);
        if ($pay_type == 'Income') {
            $account->last_balance = $account->last_balance + $amount;
        } else {
            $account->last_balance = $account->last_balance - $amount;
        }
        $account->save();


        $notification = array(
            'message' => 'Transaction completed',
            'alert-type' => 'success'
        );

        if ($request->type == "Income")
        {
            return redirect('transaction/income')->with($notification);
        } else {
            return redirect('transaction/expense')->with($notification);
        }



    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function show($id)
    {
        if (!Auth::user()->can('view_transaction')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Transaction Details';
        $data['activeMenu'] = 'show_transaction';
        $data['transaction'] = Transaction::findOrFail($id);
        $data['settings'] = ApplicationSetting::find(1);
        $data['countries'] = Country::all();
        $data['emailConfigData'] = EmailConfig::first();


        return view('admin.transaction.show', $data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return void
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return void
     */
    public function destroy($id)
    {
        /**
         * When a transaction has been deleted:
         * 1. Balance will be adjusted ?
         * or 2. It will just remove entry ?
         */


        if (!Auth::user()->can('delete_transaction')) {
            return redirect('dashboard')->with(denied());

        } // end permission checking

        Transaction::Where('id', $id)->delete();

        $notification = array(
            'message' => 'Transaction has been deleted',
            'alert-type' => 'warning'
        );

        return redirect()->back()->with($notification);
    }


    public function getTransactionCategory($type)
    {
        return TransactionCategory::where('type', $type)->orderBy('name', 'asc')->get();
    }


    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function transfer()
    {
        if (!Auth::user()->can('manage_transfer')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Add new transfer';
        $data['activeMenu'] = 'transfer';
        $data['transactionCategories'] = TransactionCategory::all();
        $data['accounts'] = Account::all();
        return view('admin.transaction.transfer', $data);
    }


    /**
     * @param Request $request
     * Complete the account transfer process from one account to another account
     * @return \Illuminate\Http\RedirectResponse
     */
    public function makeTransfer(Request $request)
    {
        if (!Auth::user()->can('manage_transfer')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $from_account = $request->from_account_id;
        $to_account = $request->to_account_id;
        $amount = $request->amount;


        if ($from_account > 0) {
            $account = Account::findOrFail($from_account);
            $account2 = Account::findOrFail($to_account);


            $transaction_to = new Transaction;
            $transaction_from = new Transaction;

            $transaction_to->account_id = $to_account;
            $transaction_to->customer_name = $account2->account_holder;
            $transaction_to->debit = 0;
            $transaction_to->ext = 1;
            $transaction_to->credit = $amount;
            $transaction_to->type = 'Transfer';
            $transaction_to->date = date('Y-m-d');
            $transaction_to->note = 'Transferred by ' . $account->account_holder;
            $transaction_to->save();


            // Update account balance

            $money_account = Account::findOrFail($to_account);
            $money_account->last_balance = $money_account->last_balance + $amount;
            $money_account->save();


            $transaction_from->account_id = $from_account;
            $transaction_from->customer_name = $account->account_holder;
            $transaction_from->debit = $amount;
            $transaction_from->credit = 0;
            $transaction_from->ext = 1;
            $transaction_from->type = 'Transfer';
            $transaction_from->date = date('Y-m-d');
            $transaction_from->note = 'Transferred to ' . $account2->account_holder;
            $transaction_from->save();

            $money_account2 = Account::findOrFail($from_account);
            $money_account2->last_balance = $money_account2->last_balance - $amount;
            $money_account2->save();

            $notification = array(
                'message' => 'Transfer success',
                'alert-type' => 'success'
            );

            return redirect()->back()->with($notification);


        }
    }


    public function income()
    {

        if (!Auth::user()->can('create_income') && !Auth::user()->can('view_income') && !Auth::user()->can('delete_income')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking


        $data['title'] = 'Income Transactions';
        $data['activeMenu'] = 'income';
        $data['transactions'] = Transaction::where('type', '=', 'income')->get();
        return view('admin.transaction.income', $data);
    }

    public function expense()
    {
        if (!Auth::user()->can('create_expense') && !Auth::user()->can('view_expense') && !Auth::user()->can('delete_expense')) {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Expense Transactions';
        $data['activeMenu'] = 'expense';
        $data['transactions'] = Transaction::where('type', '=', 'expense')->get();

        return view('admin.transaction.expense', $data);

    }

    public function exportTransaction()
    {
        //return Excel::download(new TransactionExport(), 'transactions.xlsx');
        $transactions = Transaction::get();
        $csvExporter = new \Laracsv\Export();
        $csvExporter->build($transactions, ['customer_name' => 'Customer Name', 'type' => 'Transaction Type',
            'debit' => 'Debit', 'credit' => 'Credit', 'note' => 'Transaction Note'])->download();

    }


}
