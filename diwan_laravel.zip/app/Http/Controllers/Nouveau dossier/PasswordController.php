<?php

namespace App\Http\Controllers;

use App\Rules\CheckPassword;
use Auth;
use Hash;
use Illuminate\Http\Request;
use Validator;


class PasswordController extends Controller
{
    public function changePassword()
    {
        $data['title'] = 'Change Password';
        $data['activeMenu'] = 'change_password';
        return view('admin.settings.change-password', $data);

    }

    public function doChangePassword(Request $request)
    {
        $credentials = $request->only(
            'new_password', 'new_password_confirmation'
        );


        $validation = Validator::make($request->all(), [
            'old_password' => ['required', new CheckPassword()],
            'new_password' => 'required|confirmed|different:old_password|min:6',
            'new_password_confirmation' => 'required|different:old_password|same:new_password'

        ]);


        if ($validation->fails()) {
            return redirect()->back()->withErrors($validation)->withInput();
        }

        $user = Auth::user();
        $user->password = Hash::make($credentials['new_password']);
        $user->save();
        activity()->log(Auth::user()->username . ' has changed password');

        $notification = array(
            'message' => 'Password has been changed',
            'alert-type' => 'success'
        );

        return redirect()->back()->with($notification);

    }
}
