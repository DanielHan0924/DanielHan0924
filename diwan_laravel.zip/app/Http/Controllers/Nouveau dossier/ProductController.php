<?php

namespace App\Http\Controllers;

use App\Category;
use App\Http\Requests\ProductRequest;
use App\ItemTaxType;
use App\Product;
use App\Warehouse;
use Auth;
use Maatwebsite\Excel\Facades\Excel;
use Redirect;
use File;


class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index()
    {
        if (!Auth::user()->can('create_product') && !Auth::user()->can('view_product') && !Auth::user()->can('edit_product') && !Auth::user()->can('delete_product') )
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Products';
        $data['products'] = Product::all();
        $data['stock'] = Product::sum('product_quantity');
        $data['activeMenu'] = 'products';
        $data['out_of_stock'] = Product::where('product_quantity', '=', '0')->count('product_quantity');

        //dd($data['out_of_stock']);
        return view('admin.product.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return void
     */
    public function create()
    {
        if (!Auth::user()->can('create_product'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Add New Product';
        $data['activeMenu'] = 'create_product';
        $data['categories'] = Category::all();
        $data['warehouses'] = Warehouse::all();
        $data['productTaxRates'] = ItemTaxType::all();
        return view('admin.product.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param ProductRequest $request
     * @return void
     */
    public function store(ProductRequest $request, Product $product)
    {
        if (!Auth::user()->can('create_product'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $filename = uniqid();
        $product->fill($request->all());
        if ($request->hasFile('product_image')) {
            $extension = $request->file('product_image')->getClientOriginalExtension();
            $request->file('product_image')->move('public/uploads/products/', $filename . "." . $extension);
            $product->product_image = $filename . "." . $extension;
        }
        $product->description = $request->description;
        $product->save();

        activity()->performedOn($product)->log(Auth::user()->full_name . ' has created a product name ' . $request->product_name);

        $notification = array(
            'message' => 'Product has been created',
            'alert-type' => 'success'
        );


        return redirect()->route('product.index')->with($notification);

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function edit($id)
    {
        if (!Auth::user()->can('edit_product'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $data['title'] = 'Edit Product';
        $data['activeMenu'] = 'products';
        $data['product'] = Product::findOrFail($id);
        $data['categories'] = Category::all();
        $data['warehouses'] = Warehouse::all();
        $data['productTaxRates'] = ItemTaxType::all();
        return view('admin.product.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param ProductRequest $request
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(ProductRequest $request, Product $product)
    {
        if (!Auth::user()->can('edit_product'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $product->fill($request->all());
        $product->category_id = $request->category_id;
        $product->warehouse_id = $request->warehouse_id;
        $product->product_name = $request->product_name;
        $product->product_code = $request->product_code;
        $product->product_wholesale_price = $request->product_wholesale_price;
        $product->product_retail_price = $request->product_retail_price;
        $product->product_tax_rate_id = $request->product_tax_rate_id;
        $product->product_quantity = $request->product_quantity;
        $product->description = $request->description;

        $filename = uniqid();
        $product->fill($request->all());
        if ($request->hasFile('product_image')) {
            $extension = $request->file('product_image')->getClientOriginalExtension();
            $request->file('product_image')->move('public/uploads/products/', $filename . "." . $extension);
            $product->product_image = $filename . "." . $extension;
        }
        $product->save();

        activity()->performedOn($product)->log(Auth::user()->full_name . ' has updated a product name ' . $request->product_name);

        $notification = array(
            'message' => 'Product has been updated',
            'alert-type' => 'info'
        );

        return Redirect::to('product')->with($notification);
    }


    /**
     * @param $id
     * @return product data as json object
     *
     */

    public function viewProduct($id)
    {


        $product = Product::findOrFail($id);

        $data = [
            'category' => $product->category->title,
            'warehouse' => $product->warehouse->title,
            'product_name' => $product->product_name,
            'product_code' => $product->product_code,
            'product_wholesale_price' => $product->product_wholesale_price,
            'product_retail_price' => $product->product_retail_price,
            'product_quantity' => $product->product_quantity,
            'product_image' => $product->product_image ? asset('/public/uploads/products/') . '/' . $product->product_image : asset('/public/uploads/products/') . '/noImage.png',
            'description' => $product->description,
        ];
        return json_encode($data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        if (!Auth::user()->can('delete_product'))
        {
            return redirect('dashboard')->with(denied());
        } // end permission checking

        $product = Product::findOrFail($id);
        if ($product->product_image != null)
        {
            File::delete('public/uploads/products/'.$product->product_image);
        }
        activity()->log('User ' . Auth::user()->username . ' has deleted product: ' . $product->product_name);

        $product->delete();

        $notification = array(
            'message' => 'Product has been deleted',
            'alert-type' => 'error'
        );
        return redirect()->back()->with($notification);
    }


    /**
     * @return \Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function exportProduct()
    {

        $products = Product::get();
        $csvExporter = new \Laracsv\Export();
        $csvExporter->build($products, ['product_name' => 'Product Name', 'product_code' => 'Product Code',
            'product_retail_price' => 'Retail Price', 'product_wholesale_price' => 'Wholesale Price', 'product_quantity' => 'Stock Quantity'])->download();
    }


    /**
     * @param $type
     * @return mixed
     */
    public function downloadCsv($type)
    {


        if ($type == 'csv') {

            $itemData = (new Product)->getAllItemCsv();


            foreach ($itemData as $key => $value) {
                $csvData[$key]['id'] = $value->id;
                $csvData[$key]['Product Name'] = $value->product_name;
                $csvData[$key]['Stock Quantity'] = $value->stock_quantity;
                $csvData[$key]['Purchase Price'] = $value->wholesale_price;
                $csvData[$key]['Retail Price'] = $value->retail_price;


            }
        }

        return Excel::download($csvData, 'Products.csv');


    }


}
