<?php

namespace App\Http\Controllers;

use App\Group;
use App\Http\Requests\GroupRequest;
use Redirect;
use Session;

class GroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index()
    {


        $data['title'] = 'Groups';
        $data['groups'] = Group::all();
        $data['activeMenu'] = 'groups';
        return view('admin.group.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return void
     */
    public function create()
    {
        $data['title'] = 'Create Group';
        $data['activeMenu'] = 'groups';
        return view('admin.group.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param GroupRequest $request
     * @return void
     */
    public function store(GroupRequest $request)
    {
        Group::create($request->all());
        return redirect()->route('group.create')->with('message', 'Group has been created.');

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return void
     */
    public function edit($id)
    {
        $data['title'] = 'Edit Group';
        $data['activeMenu'] = 'groups';
        $data['group'] = Group::find($id);
        return view('admin.group.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param GroupRequest $request
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(GroupRequest $request, $id)
    {
        $group = Group::find($id);
        $group->title = $request->title;
        $group->description = $request->description;
        $group->save();
        Session::flash('message', 'Group name has been updated.');
        return Redirect::to('group');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $group = Group::find($id);
        $group->delete();
        Session::flash('message', 'Group has been deleted !');
        return Redirect::to('group');
    }
}
