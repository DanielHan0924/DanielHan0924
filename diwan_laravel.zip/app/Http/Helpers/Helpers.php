<?php

use App\ApplicationSetting;
use App\Message;
use App\User;

//use Html;

// Check the number of "unread" messages.
if (!function_exists('menu_message_count')) {
    function menu_message_count()
    {
      
    }
}

// Return user type, i.e: customer, employee, supplier or admin

if (!function_exists('get_user_type')) {
    function get_user_type($user_id)
    {
        if (Auth::check()) {
            return User::findOrFail($user_id);
        }
    }
}


/**
 * Return full user name
 */

if (!function_exists('get_full_user_name')) {
    function get_full_user_name($user_id)
    {
        if (Auth::check()) {
            return User::findOrFail($user_id)->full_name;
        }
    }
}

/**
 * Return user avatar
 */
if (!function_exists('get_avatar')) {
    function get_avatar($user_id, $size = null)
    {
        if (Auth::check()) {
            $user = User::findOrFail($user_id);
            $name = ($user->full_name) ?: $user->username;
            $tooltip = $name;
            if ($size == null)
                $size = '40px';
            if (isset($user->profile_image))
                echo '<div class="pull-left"><img src="' . asset('/public/uploads/users_profile/') . '/' . $user->profile_image . '" class="img-circle" alt="User Image"></div>';
            else
                echo '<div class="pull-left"><img src="' . asset('/public/uploads/users_profile/avatar.png') . '" class="img-circle" alt="User Image"></div>';

        }
    }
}


/**
 * @return \Illuminate\Database\Eloquent\Collection
 */
function tasks()
{
    return Auth::user()->task_employees()->where('status', '=', 'Due')->get();
}

/**
 * @param $param
 * @param string $name
 * @param int $data_table_row_delete
 * @param string $label
 * @return string
 */

function delete_form($param, $name = '', $data_table_row_delete = 0, $label = '')
{
    $form = Form::open(['method' => 'DELETE', 'route' => $param, 'class' => 'form-inline', 'id' => $name . '_' . $param[1], 'data-table-row-delete' => $data_table_row_delete]);
    $form .= (Form::button('<i class="fa fa-trash-o"></i> ' . $label, ['data-toggle' => 'tooltip', 'title' => 'Delete Comment', 'class' => 'btn btn-default btn-xs',
        'data-submit-confirm-text' => 'Yes', 'type' => 'submit']));
    return $form .= Form::close();
}


/**
 * @param $host
 * @param $user
 * @param $pass
 * @param $name
 * @param string $tables
 * @return string
 */
function backup_tables($host, $user, $pass, $name, $tables = '*')
{
    try {
        $con = mysqli_connect($host, $user, $pass, $name);
    } catch (Exception $e) {

    }
    //mysqli_select_db($name,$link);

    if (mysqli_connect_errno()) {

        $notification = array(
            'message' => 'Error connecting database server',
            'alert-type' => 'error',
        );
        //dd($notification);

    }

    //get all of the tables
    if ($tables == '*') {
        $tables = array();
        $result = mysqli_query($con, 'SHOW TABLES');
        while ($row = mysqli_fetch_row($result)) {
            $tables[] = $row[0];
        }
    } else {
        $tables = is_array($tables) ? $tables : explode(',', $tables);
    }

    //cycle through
    $return = '';
    foreach ($tables as $table) {
        $result = mysqli_query($con, 'SELECT * FROM ' . $table);
        $num_fields = mysqli_num_fields($result);


        //$return.= 'DROP TABLE '.$table.';';
        $row2 = mysqli_fetch_row(mysqli_query($con, 'SHOW CREATE TABLE ' . $table));
        $return .= "\n\n" . str_replace("CREATE TABLE", "CREATE TABLE IF NOT EXISTS", $row2[1]) . ";\n\n";

        for ($i = 0; $i < $num_fields; $i++) {
            while ($row = mysqli_fetch_row($result)) {
                $return .= 'INSERT INTO ' . $table . ' VALUES(';
                for ($j = 0; $j < $num_fields; $j++) {
                    $row[$j] = addslashes($row[$j]);
                    $row[$j] = preg_replace("/\n/", "\\n", $row[$j]);
                    if (isset($row[$j])) {
                        $return .= '"' . $row[$j] . '"';
                    } else {
                        $return .= '""';
                    }
                    if ($j < ($num_fields - 1)) {
                        $return .= ',';
                    }
                }
                $return .= ");\n";
            }
        }

        $return .= "\n\n\n";
    }

    $backup_name = date('Y-m-d-His') . '.sql';

    //save file
    $handle = fopen(storage_path("laravel-backups") . '/' . $backup_name, 'w+');
    fwrite($handle, $return);
    fclose($handle);

    return $backup_name;
}


function getApplicationLogo()
{

    $logo = ApplicationSetting::select('company_logo')->where('id', 1)->first();
    return $logo->company_logo;
}


function getApplicationSettings()
{
    return ApplicationSetting::whereId(1)->first();

}

/**
 * @param $value
 * @return false|mixed|string
 */
function DbDateFormat($value)
{

    $pref = DB::table('preferences')->where('category', 'preference')->get()->toArray();
    $preference = $pref[3]->value;

    $data = str_replace(['/', '.', ' ', '-'], ['-', '-', '-', '-'], $preference);
    $data = explode('-', $data);
    $mm = $data[0];
    if ($mm == 'mm') {
        $dateInfo = str_replace(['/', '.', ' ', '-'], ['-', '-', '-', '-'], $value);
        $dataStream = explode('-', $dateInfo);
        $month = $dataStream[0];
        $day = $dataStream[1];
        $year = $dataStream[2];
        $value = $day . '-' . $month . '-' . $year;
    } else {
        $value = str_replace(['/', '.', ' ', '-'], ['-', '-', '-', '-'], $value);
    }
    $value = date('Y-m-d', strtotime($value));

    return $value;
}

/**
 * @param $value
 * @return false|string
 */
function formatDate($value)
{
    $prefData = DB::table('preferences')->where('category', 'preference')->get()->toArray();
    if ($prefData[1]->value == '0') {
        //yyyy-mm-dd
        $format = 'Y' . $prefData[2]->value . 'm' . $prefData[2]->value . 'd';
        $date = date($format, strtotime($value));
    } elseif ($prefData[1]->value == '1') {
        //dd-mm-yyyy
        $format = 'd' . $prefData[2]->value . 'm' . $prefData[2]->value . 'Y';
        $date = date($format, strtotime($value));
    } elseif ($prefData[1]->value == '2') {
        //mm-dd-yyyy
        $format = 'm' . $prefData[2]->value . 'd' . $prefData[2]->value . 'Y';
        $date = date($format, strtotime($value));
    } elseif ($prefData[1]->value == '3') {
        //D-M-yyyy
        $format = 'd' . $prefData[2]->value . 'M' . $prefData[2]->value . 'Y';
        $date = date($format, strtotime($value));
    } elseif ($prefData[1]->value == '4') {
        //yyyy-mm-D
        $format = 'Y' . $prefData[2]->value . 'M' . $prefData[2]->value . 'd';
        $date = date($format, strtotime($value));
    }

    return $date;

}

function denied()
{
    return array(
        'message' => 'Access Denied',
        'alert-type' => 'warning'
    );
}

/**
 * @return array
 */
function getLastOneMonthDates()
{
    $data = array();
    for ($j = 30; $j > -1; $j--) {
        $data[30 - $j] = date("d-m", strtotime(" -$j day"));
    }
    return $data;
}


function thirtyDaysNameList()
{
    $data = array();
    for ($j = 30; $j > -1; $j--) {
        $data[30 - $j] = date("d M", strtotime("-$j day"));
    }
    // d($data,1);
    return $data;
}


function getLastSixMonthName()
{
    $data = array();
    for ($j = 5; $j >= 0; $j--) {
        $data[5 - $j] = date("F-Y", strtotime(" -$j month"));
    }
    return $data;
}

function getLastSixMonthNumber()
{
    $data = array();
    for ($j = 5; $j >= 0; $j--) {
        $data[5 - $j] = date("n-Y", strtotime(" -$j month"));
    }
    return $data;
}


function previousDate()
{
    $preDate = date("Y-m-d", strtotime("-5 month"));
    $preday = date("d", strtotime($preDate)) - 1;
    $newdate = strtotime("-$preday day", strtotime($preDate));
    $newdate = date('Y-m-j', $newdate);
    return $newdate;
}


function getExpenseArrayList($sixMonthExpense, $getLastSixMonthNumber)
{

    $data_map = [];
    foreach ($sixMonthExpense as $key => $value) {
        $data_map[$value->month][$value->year] = $value->amount;
    }
    $final = [];
    $i = 0;
    foreach ($getLastSixMonthNumber as $key => $value) {
        $date = explode('-', $value);
        $tm = (int)$date[0];
        $ty = (int)$date[1];
        $final[$i]['month'] = $date[0];
        $final[$i]['year'] = $date[1];
        if (isset($data_map[$tm][$ty])) $final[$i]['amount'] = $data_map[$tm][$ty];
        else $final[$i]['amount'] = 0;
        $i++;
    }

    return $final;

}


function makeExpenseReportGraph($datas)
{
    $graphData = [];
    $i = 0;
    $j = 0;
    foreach ($datas as $key => $value) {
        $graphData[$i][$j++] = $key;
        $sm = 0;
        foreach ($value as $v) {
            $sm += abs($v);
        }
        $graphData[$i][$j++] = $sm;
        $j = 0;
        $i++;
    }
    return $graphData;
}


function numberOfPurchaseOrderByDate($invoice_date)
{
    return \App\Purchase_invoice::where('invoice_date', $invoice_date)->count();
}

function purchaseVolumeByDate($invoice_date)
{
    $invoices = \App\Purchase_invoice::where('invoice_date', $invoice_date)->get();
    $purchaseVolume = 0;
    foreach ($invoices as $invoice) {
        $purchaseVolume = $purchaseVolume + $invoice->purchaseItemDetails->sum('qty');
    }
    return $purchaseVolume;
}

function purchaseCostByDate($invoice_date)
{
    $invoices = \App\Purchase_invoice::where('invoice_date', $invoice_date)->get();
    $purchaseCost = 0;
    foreach ($invoices as $invoice) {
        $purchaseCost = $purchaseCost + $invoice->purchaseItemDetails->sum('unit_total_price');
    }
    return $purchaseCost;
}

function dailySalesOrder($invoice_date)
{
    return \App\Sales_invoice::where('invoice_date', $invoice_date)->count();
}

function dailySalesVolume($invoice_date)
{
    $orders = \App\Sales_invoice::where('invoice_date', $invoice_date)->get();

    $salesVolume = 0;

    if (count($orders) > 0) {
        foreach ($orders as $order) {
            $salesVolume = $salesVolume + $order->salesInvoiceDetails->sum('qty');
        }
    }

    return $salesVolume;
}

function dailySalesValue($invoice_date)
{
    $orders = \App\Sales_invoice::where('invoice_date', $invoice_date)->get();
    $salesValue = 0.00;
    if (count($orders) > 0) {
        foreach ($orders as $order) {
            $salesValue = $salesValue + $order->salesInvoiceDetails->sum('unit_total_price');
        }
    }

    return $salesValue;
}

function dailySalesCostValue($invoice_date)
{
    $orders = \App\Sales_invoice::where('invoice_date', $invoice_date)->get();

    $costValue = 0.00;

    if (count($orders) > 0) {
        foreach ($orders as $order) {
            /** start cost value calculate */
            foreach ($order->salesInvoiceDetails as $salesItem) {
                if (\App\Purchase_invoice_details::where('product_id', $salesItem->product_id)->orderBy('id', 'DESC')->count() > 0) {
                    $purchaseItem = \App\Purchase_invoice_details::where('product_id', $salesItem->product_id)->orderBy('id', 'DESC')->first();
                    $salesQty = $salesItem->qty;
                    $calculateCostValue = $salesQty * $purchaseItem->unit_price;
                    $costValue = $costValue + $calculateCostValue;
                }
            }

        }
    }

    return $costValue;
}

function memberRole($user_id)
{
    if (DB::table('model_has_roles')->where('model_id', $user_id)->count() > 0)
    {
        $selected_role = DB::table('model_has_roles')->where('model_id', $user_id)->first();
        $role = \App\Role::find($selected_role->role_id);
        return ucwords(str_replace("_", " ", $role->name));
    } else {
        return "";
    }


}


