<?php

namespace App\Listeners;

use Auth;
use DateTime;
use Illuminate\Auth\Events\Login;
use Illuminate\Http\Request;

class LogSuccessfulLogin
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    private $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /**
     * Handle the event.
     *
     * @param  Login $event
     * @return void
     */
    public function handle(Login $event)
    {
        Auth::user()->last_login = Auth::user()->last_login_now;
        Auth::user()->last_login_ip = Auth::user()->last_login_ip_now;
        Auth::user()->last_login_now = new DateTime();
        Auth::user()->last_login_ip_now = $this->request->getClientIp();
        Auth::user()->save();
        activity()->log(Auth::user()->username . ' has logged in to the system at '. date("F j, Y, g:i a"));

    }
}
