<?php

namespace App\Exports;

use App\Transaction;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class TransactionExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        return Transaction::all();
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'id',
            'customer_name',
            'account_id',
            'account',
            'type',
            'transaction_category_name',
            'debit',
            'credit',
            'customer_id',
            'pay_method',
            'date',
            'tid',
            'user_id',
            'note',
            'ext',
            'created_at',
            'updated_at',
        ];
    }
}
