<?php

namespace App\Exports;

use App\Product;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ProductExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        return Product::all();
    }


    public function headings(): array
    {
        return [
            '#ID',
            'Category ID',
            'Warehouse ID',
            'Product Name',
            'Product Code',
            'Wholesale Price',
            'Retail Price',
            'Tax Rate ID',
            'Quantity',
            'Image Name',
            'Description',
            'Created At',
            'Updated At'
        ];
    }
}
