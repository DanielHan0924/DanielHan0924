@extends('layouts.login-master')
@section('content')

    <div class="login-box animated fadeIn">
        <div class="login-logo">
            <b style="color:#fff;">Bulk Contacts Import</b>
        </div>
        <!-- /.login-logo -->
        <div class="login-box-body">
            <p class="login-box-msg">Reset your password</p>
            <form method="post" action="{{URL('send-password-link')}}">
                {{csrf_field()}}

                <div class="form-group">
                    @if(Session::has('message'))
                        <div class="successMessage alert alert-{{Session::get('message_type')}} text-center">
                             {{ Session::get('message') }}
                        </div>
                    @endif

                    <input name="email" id="email" type="email" class="form-control" placeholder="Enter Registered Email" required autofocus>
                </div>

                <div class="row">
                    <div class="col-xs-12">
                        <button type="submit" class="btn btn-primary btn-flat">Send Password Reset Link</button>
                        <a href="{{URL('login')}}" class="btn btn-success btn-flat pull-right ">Login</a>
                        <div class="clearfix"></div>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

        </div>
    </div>
@endsection

