@extends('layouts.login-master')

@section('content')
    <div class="register-box">
        <div class="register-logo">
            <a href="#"><b style="color:#fff;">Bulk Contacts Import</b></a>
        </div>

        <div class="register-box-body">
            <p class="login-box-msg">Register a new membership</p>

            <form method="post" action="{{route('register')}}">
                {{csrf_field()}}
                <div class="form-group has-feedback">
                    <input name="first_name" id="name" type="text" class="form-control" placeholder="First Name"
                           value="{{old('first_name')}}" required>
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>

                @if ($errors->has('first_name'))
                    <span class="help-block">
                        <strong>{{ $errors->first('first_name') }}</strong>
                    </span>
                @endif
                <div class="form-group has-feedback">
                    <input name="last_name" id="name" type="text" class="form-control" placeholder="Last Name"
                           value="{{old('last_name')}}" required>
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>

                @if ($errors->has('last_name'))
                    <span class="help-block">
                        <strong>{{ $errors->first('last_name') }}</strong>
                    </span>
                @endif

                <div class="form-group has-feedback">
                    <input name="username" id="name" type="text" class="form-control" placeholder="User Name"
                           value="{{old('username')}}" required>
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>

                @if ($errors->has('username'))
                    <span class="help-block">
                        <strong>{{ $errors->first('username') }}</strong>
                    </span>
                @endif


                <div class="form-group has-feedback">
                    <input name="email" id="name" type="email" class="form-control" placeholder="Email"
                           value="{{old('email')}}" required>
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>

                @if ($errors->has('email'))
                    <span class="help-block">
                        <strong>{{ $errors->first('email') }}</strong>
                    </span>
                @endif

                <div class="form-group has-feedback">
                    <input name="password" type="password" class="form-control" placeholder="Password">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>

                @if ($errors->has('password'))
                    <span class="help-block">
                        <strong>{{ $errors->first('password') }}</strong>
                    </span>
                @endif


                <div class="form-group has-feedback">
                    <input type="password" name="password_confirmation" class="form-control"
                           placeholder="Retype password">
                    <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
                </div>
                <div class="row">
                    <div class="col-xs-4">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Register</button>
                    </div>
                </div>
            </form>
            <a href="{{route('login')}}" class="text-center">I already have an account</a>
        </div>

    </div>
@endsection
