@extends('admin.master')
@section('title')
    Qbilling  - {{$title}}
@endsection
@section('content')


    <div class="content-wrapper">
        @include('admin.partials._breadcrumbs')
        <section class="content animated fadeIn">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="pull-left">
                        <h3 class="box-title">{{strtoupper($title)}}</h3>
                    </div>
                    @can('create_warehouse')
                        <div class="pull-right">
                            <a class="btn btn-primary" href="{{url('warehouse/create')}}">Create New</a>
                        </div>
                    @endcan
                    <div class="clearfix"></div>
                </div>
                <div class="box-body min-height">
                    <div class="row">
                        <div class="col-md-12">
                            <table id="warehouses" class=" table table-bordered table-striped dataTable"
                                   role="grid" data-form="deleteForm">
                                <thead>
                                <tr role="row">
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>

                                @foreach($warehouses as $category)
                                    <tr role="row" class="odd">
                                        <td>{{$category->title}}</td>
                                        <td>{{$category->description}}</td>
                                        <td>
                                            @can('edit_warehouse')
                                                <a data-tooltip="tooltip" title="Edit Warehouse"
                                                   class="btn btn-sm btn-default"
                                                   href="{{URL::to('warehouse/'.$category->id.'/edit')}}"><i
                                                            class="fa fa-pencil" aria-hidden="true"></i></a>
                                            @endcan

                                                @can('delete_warehouse')
                                            {{Form::open(['url'=>'warehouse/'.$category->id,'class'=>'inline form-delete'])}}
                                            {{Form::hidden('_method','DELETE')}}
                                            <button data-toggle="tooltip" title="Delete Warehouse" type="submit"
                                                    class="btn btn-default btn-sm delete_modal"><i
                                                        class="fa fa-trash"></i></button>
                                            {{Form::close()}}
                                                    @endcan

                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        @include('admin.common.modal')
    </div>
@endsection

@section('script')
    <script>
        $(function () {
            // Custom code goes here.
        });
    </script>
@endsection

