@extends('admin.master')
@section('title')
    Qbilling  - {{$title}}
@endsection
@section('content')
    <div class="content-wrapper">

        @include('admin.partials._breadcrumbs')
        <section class="content animated fadeIn">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="pull-left">
                        <h3 class="box-title">{{strtoupper($title)}}</h3>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <!-- /.box-header -->
                <div class="box-body min-height">
                    <div class="row">
                        <div class="col-md-12">
                            <form action="{{route('warehouse.store')}}" method="post" class="form-horizontal"
                                  id="product-warehouse">
                                {{csrf_field()}}
                                <div class="box-body">
                                    <div class="form-group">
                                        <label for="title" class="col-sm-2 control-label">Warehouse Name *</label>

                                        <div class="col-sm-10">
                                            <input name="title" class="form-control" id="title"
                                                   placeholder="Product Warehouse Name"
                                                   type="text">
                                            @if ($errors->has('title'))
                                                <span class="help-block"><strong><i class="fa fa-warning"></i> {{ $errors->first('title') }}</strong></span>
                                            @endif

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="description" class="col-sm-2 control-label">Description</label>

                                        <div class="col-sm-10">
                                            <input name="description" class="form-control" id="description"
                                                   placeholder="Product Warehouse Description"
                                                   type="text">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button type="submit" class="btn btn-info pull-right">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /.row -->
                </div>
            </div>
            <!-- /.box -->
        </section>
        <!-- /.content -->
    </div>
@endsection

@section('script')
    <script>
        $(function () {

            $("#product-warehouse").validate({
                rules: {
                    title: {
                        required: true
                    }
                },
                messages: {
                    title: {
                        required: 'Give a warehouse name'
                    }
                }
            });

            // Remove the success flash message after 1 second.
            $(".successMessage").delay(1000).fadeOut();
        });
    </script>
@endsection