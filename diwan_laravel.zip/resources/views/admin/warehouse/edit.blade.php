@extends('admin.master')
@section('title')
    Qbilling  - {{$title}}
@endsection
@section('content')
    <div class="content-wrapper">

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="{{url('dashboard')}}">DASHBOARD</a>
            </li>
            <li class="breadcrumb-item">
                <a href="{{url('warehouse')}}">Warehouses</a>
            </li>
            <li class="breadcrumb-item">
                {{$title}}
            </li>
        </ol>
        <section class="content animated fadeIn">

            @if(Session::has('message'))
                <div class="successMessage alert alert-success text-center"><h4 style="margin:0;"><i
                                class="fa fa-check-circle"></i> {{ Session::get('message') }}</h4></div>
            @endif

            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="pull-left">
                        <h3 class="box-title">{{strtoupper($title)}}</h3>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <!-- /.box-header -->
                <div class="box-body min-height">
                    <div class="row">
                        <div class="col-md-12">


                            {!! Form::model($warehouse,['method' => 'PATCH','route' => ['warehouse.update',$warehouse->id] ,'role' => 'form', 'id'=>'product-warehouse', 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                            {{csrf_field()}}
                            <div class="box-body">
                                <div class="form-group">
                                    <label for="title" class="col-sm-2 control-label">Warehouse Name</label>

                                    <div class="col-sm-10">
                                        <input name="title" class="form-control" id="title"
                                               placeholder="Category Name" value="{{$warehouse->title}}"
                                               type="text">
                                        @if ($errors->has('title'))
                                            <span class="help-block"><strong><i class="fa fa-warning"></i> {{ $errors->first('title') }}</strong></span>
                                        @endif

                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="description" class="col-sm-2 control-label">Description</label>

                                    <div class="col-sm-10">
                                        <input name="description" class="form-control" id="description"
                                               placeholder="Description" value="{{$warehouse->description}}"
                                               type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <button type="submit" class="btn btn-info pull-right">Update</button>
                                    </div>
                                </div>
                            </div>
                            {!! Form::close() !!}
                        </div>
                    </div>
                    <!-- /.row -->
                </div>
            </div>
            <!-- /.box -->
        </section>
        <!-- /.content -->
    </div>
@endsection

@section('script')
    <script>
        $(function () {

            $("#product-warehouse").validate({
                rules: {
                    title: {
                        required: true
                    }
                },
                messages: {
                    title: {
                        required: 'Give a warehouse name'
                    }
                }
            });
        });
    </script>
@endsection