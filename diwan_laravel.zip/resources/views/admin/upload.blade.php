@extends('admin.master')
@section('title')
    Qbilling  - {{$title}}
@endsection
@section('content')
    <div class="content-wrapper">

        <section class="content animated fadeIn">

            @if(Session::has('message'))
                <div class="successMessage alert alert-success text-center"><h4 style="margin:0;"><i
                                class="fa fa-check-circle"></i> {{ Session::get('message') }}</h4></div>
            @endif

 @if(Session::has('message2'))
                <div class="successMessage alert alert-success text-center"><h4 style="margin:0;"><i
                                class="fa fa-check-circle"></i> {{ Session::get('message2') }}</h4></div>
            @endif

	@if(!session()->has('message') and !Session::has('message2'))
            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="pull-left">
                        <h3 class="box-title">{{strtoupper($title)}} 
						<strong>{{strtoupper($name)}}</strong>
						</h3>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="box-body min-height">
                    <div class="row">
				
                        <div class="col-md-12">
                            <form action="{{route('updloaddata')}}" method="post" class="form-horizontal" enctype="multipart/form-data"
                                  id="create_account">
                                {{csrf_field()}}
                                <div class="box-body">

     <div class="form-group">
                                        <label for="" class="col-sm-4 control-label">Upload File contacts (.csv) *</label>
										
										
                                        <div class="col-sm-8">
                                            <input name="file" class="form-control" id="file" type="file"  required
												   >
                                          
											
											
                                        </div>
                                    </div>

                                  
                                   
                                   
                                 
                               

                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button type="submit" class="btn btn-primary pull-right col-sm-12">UPLOAD FILE</button>
											
                                        </div>
                                    </div>
                                </div>
                            </form>
							
							 <div class="form-group">
							 Sed quis faucibus velit. Sed ut dolor vitae odio ullamcorper porta. Etiam gravida maximus maximus. Aliquam vel erat massa. Suspendisse in maximus nibh, id faucibus nunc. Morbi quis euismod nulla. Suspendisse potenti. Aliquam erat volutpat.
</div>
                        </div>
						
						
					

                    </div>
                </div>
            </div>
			@endif
			
			
			
				@if(session()->has('message'))
            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="pull-left">
                        <h3 class="box-title">
						
						</h3>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="box-body min-height">
                    <div class="row">
				
                        <div class="col-md-12">
                            <form action="{{route('submitdata')}}" method="post" class="form-horizontal" enctype="multipart/form-data"
                                  id="create_account">
                                {{csrf_field()}}
                                <div class="box-body">

     <div class="form-group">
                                        <label for="" class="col-sm-3 control-label">Adresse Mail </label>
										
										
                                        <div class="col-sm-9">
                                            <input name="mail" class="form-control" id="mail" type="mail"  required
												   >
                                          <span>Veuillez renseigner votre adresse mail</span>
											
											
                                        </div>
                                    </div>
									
									<div class="form-group">
										  </div><span>L'upload de votre liste de contacts prendra : 
										  @if(Session::get('taille')<1) <strong>moins d'une minute </strong>@endif
										@if(Session::get('taille')>=1)  {{ Session::get('taille') }} mn</span>@endif
									</div>
                                  
                                   
                                   
                                 
                               

                                  <button type="submit" class="btn btn-primary pull-right col-sm-12">SUBMIT TO CRON </button>
											
                                </div>
                            </form>
                        </div>
						
						
					

                    </div>
                </div>
            </div>
			@endif
			
			
				
        </section>
    </div>
@endsection

@section('script')
    <script>
        $(function () {
            /**
             * Front End validation
             */
            $('#create_account').validate({
                rules: {
                    account_number: {
                        required: true
                    },
                    account_holder: {
                        required: true
                    },
                    bank_name: {
                        required: true
                    },
                    bank_address: {
                        required: true
                    },
                    last_balance: {
                        required: true
                    }

                },
                messages: {
                    account_number: {
                        required: "Please put an account number"
                    },
                    account_holder: {
                        required: "Please put an account holder's name"
                    },
                    bank_address: {
                        required: "Put bank address"
                    },
                    bank_name: {
                        required: "Provide bank name"
                    },
                    last_balance: {
                        required: "Give an initial balance"
                    }
                }
            });
        });
    </script>
@endsection