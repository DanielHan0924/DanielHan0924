@extends('admin.master')
@section('title')
    Qbilling  - {{$title}}
@endsection
@section('content')
    <div class="content-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="{{url('dashboard')}}">DASHBOARD</a>
            </li>
            <li class="breadcrumb-item">
                {{$title}}
            </li>
        </ol>
        <section class="content animated fadeIn">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="pull-left">
                        <h3 class="box-title">{{strtoupper($title)}}</h3>
                    </div>
                    {{--<div class="pull-right">--}}
                    {{--<a class="btn btn-primary" href="#" data-toggle="modal">Manage Role</a>--}}
                    {{--</div>--}}
                    <div class="clearfix"></div>
                </div>
                <div class="box-body min-height">
                    <div class="table-responsive">
                        {!! Form::open(['route' => 'configuration.save_permission','role' => 'form', 'class'=>'permission-form ']) !!}
                        <table class="table table-hover table-striped">
                            <thead>
                            <tr>
                                <th>Permission</th>
                                @foreach($roles as $role)
                                    <th class="text-center">{!! ucwords(str_replace("_", " ", $role->name)) !!}</th>
                                @endforeach
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($permissions as $permission)
                                <tr>
                                    <td>{!! ucwords(str_replace("_", " ", $permission->name)) !!}</td>
                                    @foreach($roles as $role)
                                        <td>
                                            <input id="checkbox" type="checkbox"
                                                   name="permission[{!!$role->id!!}][{!!$permission->id!!}]"
                                                   value='1' {!! (in_array($role->id.'-'.$permission->id, $permissionRole)) ? 'checked' : '' !!} >
                                        </td>
                                    @endforeach
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {!! Form::submit(isset($buttonText) ? $buttonText : 'Save Permission',['class' => 'btn btn-primary btn-block']) !!}
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </section>
        @include('admin.common.modal')
    </div>
    <div id="AddCategory" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add New Category</h4>
                </div>
                <div class="modal-body">
                    <br/>
                    <form action="{{URL('income-expense/store')}}" method="post" class="form-horizontal"
                          id="FormValidation">
                        {{@csrf_field()}}

                        <div class="form-group">
                            <label class="col-md-3">Type: *</label>
                            <div class="col-md-8">
                                <select name="type" class="form-control" required>
                                    <option value=""> -- Category Type --</option>
                                    <option value="Income">Income</option>
                                    <option value="Expense">Expense</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-3">Category Name : *</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" placeholder="Category Name" name="name"
                                       minlength="2" maxlength="30" required>
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="col-md-3"></label>
                            <div class="col-md-8">
                                <button type="submit" class="btn btn-success">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>
    <div id="EditCategory" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Edit Category</h4>
                </div>
                <div class="modal-body">
                    <br/>
                    <form action="{{URL('income-expense/update')}}" method="post" class="form-horizontal"
                          id="EditValidation">
                        {{@csrf_field()}}
                        <input type="hidden" name="id" id="id">


                        <div class="form-group">
                            <label class="col-md-3" for="type">Type: *</label>
                            <div class="col-md-8">
                                <select name="type" id="type" class="form-control" required>
                                    <option value=""> -- Category Type --</option>
                                    <option value="Income">Income</option>
                                    <option value="Expense">Expense</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3" for="name">Category Name : *</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" id="name" placeholder="Category Name"
                                       name="name" minlength="2" maxlength="30" required>
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="col-md-3"></label>
                            <div class="col-md-8">
                                <button type="submit" class="btn btn-success">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function () {

        });
    </script>
@endsection
