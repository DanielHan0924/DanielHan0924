@extends('admin.master')
@section('title')
    DIWAN  - {{$title}}
@endsection
@section('content')
    <div class="content-wrapper">
        <section class="content animated fadeIn">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="pull-left">
                        <h3 class="box-title">{{strtoupper($title)}}</h3>
                    </div>
                    @can('create_customer')
                        <div class="pull-right">
                            <a class="btn btn-primary" href="{{url('group/0000/0000')}}" style="text-transform:uppercase">Add contacts / new group</a>
                        </div>
                    @endcan
                    <div class="clearfix"></div>
                </div>
                <div class="box-body min-height">
                    <div class="row">
                        <div class="col-md-12">
                            <table id="customers" class=" table table-bordered table-striped dataTable"
                                   role="grid" data-form="deleteForm">
                                <thead>
                                <tr role="row">
                                    <th>Uuid</th>
                                    <th>Name</th>
                                    <th>Statut</th>
                                    <th>Count</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
								
								
	
	
                                @foreach($groups as $group)
                                    <tr role="row" class="odd">
                                        <td>{{$group->uuid}}</td>
                                        <td>{{$group->name}}</td>
                                        <td>{{$group->status}}</td>
                                        <td>{{$group->count}}</td>
                                       
                                        <td>
                                            
                                            <a data-tooltip="tooltip" title="Select this Group"
                                               class="btn btn-default btn-sm"
											   
											  
                                               href=" {{url('group/'.$group->uuid.'/'.$group->name)}} "><i
                                                        class="fa fa-upload"></i> SELECT GROUP</a>
                                       
 
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
						
                    </div>
					
					<div class="form-group">
							NOTE :  Sed quis faucibus velit. Sed ut dolor vitae odio ullamcorper porta. Etiam gravida maximus maximus. Aliquam vel erat massa. Suspendisse in maximus nibh, id faucibus nunc. Morbi quis euismod nulla. Suspendisse potenti. Aliquam erat volutpat.
</div>
                </div>
            </div>
        </section>
        @include('admin.common.modal')
    </div>
@endsection

@section('script')
    <script>
        $(function () {
            // Custom code goes here.
        });
    </script>
@endsection

