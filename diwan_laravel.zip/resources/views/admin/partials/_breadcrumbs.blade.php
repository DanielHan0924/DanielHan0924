<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{url('dashboard')}}">DASHBOARD</a>
    </li>
    @foreach($segments = request()->segments() as $index => $segment)
        <li class="breadcrumb-item">
            <a href="{{url(implode(array_slice($segments,0,$index+1),'/'))}}">{{strtoupper($segment)}}</a>
        </li>
    @endforeach
</ol>




