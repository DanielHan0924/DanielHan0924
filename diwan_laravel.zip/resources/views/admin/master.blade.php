<!DOCTYPE html>

<?php $pref = DB::table('preferences')->where('category', 'preference')->get()->toArray();
$date_format_type = $pref[3]->value;
$row_per_page = $pref[0]->value;

?>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>@yield('title')</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="{{asset('/public/admin/bower_components/bootstrap/dist/css/bootstrap.min.css') }}">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{asset('/public/admin/bower_components/font-awesome/css/font-awesome.min.css') }}">
    <!-- Ionicons -->
    <link rel="stylesheet" href="{{asset('/public/admin/bower_components/Ionicons/css/ionicons.min.css') }}">

    <!-- Animate.css -->
    <link rel="stylesheet" href="{{asset('/public/css/animate.css') }}">


    <!-- fullCalendar -->
    <link rel="stylesheet" href="{{asset('/public/admin/bower_components/fullcalendar/dist/fullcalendar.min.css') }}">
{{--<link rel="stylesheet" href="{{asset('/public/admin/bower_components/fullcalendar/dist/fullcalendar.print.css') }}">--}}

<!-- daterange picker -->
    <link rel="stylesheet"
          href="{{asset('/public/admin/bower_components/bootstrap-daterangepicker/daterangepicker.css') }}">
    <!-- bootstrap datepicker -->
    <link rel="stylesheet"
          href="{{asset('/public/admin/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css') }}">
    <!-- iCheck for checkboxes and radio inputs -->
    <link rel="stylesheet" href="{{asset('/public/admin/plugins/iCheck/all.css') }}">
    <!-- Bootstrap Color Picker -->
    <link rel="stylesheet"
          href="{{asset('/public/admin/bower_components/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css') }}">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="{{asset('/public/admin/plugins/timepicker/bootstrap-timepicker.min.css') }}">
    <!-- Select2 -->
    <link rel="stylesheet" href="{{asset('/public/admin/bower_components/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet" href="{{asset('/public/admin/bower_components/toasterjs/toastr.css') }}">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{asset('/public/admin/dist/css/AdminLTE.css') }}">
    <link rel="stylesheet" href="{{asset('/public/admin/dist/css/skins/_all-skins.min.css') }}">

    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="{{asset('/public/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')}}">
    <!-- Summernote - text editor -->
    <link rel="stylesheet" href="{{asset('/public/admin/bower_components/summernote/summernote.css') }}">
    {{--Datatable--}}

    <link rel="stylesheet"
          href="{{asset('/public/admin/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')}}">

    <link rel="stylesheet" href="{{asset('/public/admin/chart/TableBarChart.css')}}">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>


    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Google Font -->
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    <link rel="shortcut icon" href="{{{ asset('public/images/favicon.png') }}}">
    <script type="text/javascript">
        var SITE_URL = "{{URL::to('/')}}";
    </script>

    <style>
        .breadcrumb-item {
            text-transform: uppercase;
        }
    </style>

</head>
<body class="hold-transition {{\App\ColorTheme::find(1)->theme_name}} sidebar-mini">
<!-- <iframe name="FRAME1" src="https://ekie-group.com/diwan/" width="100%" height="100%" marginheight="0" marginwidth="0" scrolling="auto" frameborder="0"> -->
<div class="wrapper">
    <!--=====include header========-->
@include('admin.common.header')
<!-- Left side column. contains the logo and sidebar -->
@include('admin.common.sidebar')

<!-- Content Wrapper. Contains page content -->
@yield('content')
<!-- /.content-wrapper -->
@include('admin.common.footer')

<!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
<!-- </iframe> -->
</div>
<!-- ./wrapper -->
<!-- jQuery 3 -->
<script src="{{asset('/public/admin/bower_components/jquery/dist/jquery.min.js') }}"></script>
<script src="{{asset('/public/admin/bower_components/jquery/dist/jquery.validate.min.js') }}"></script>
<!-- Bootstrap 3.3.7 -->
<script src="{{asset('/public/admin/bower_components/bootstrap/dist/js/bootstrap.min.js') }}"></script>
<script src="{{asset('/public/admin/bower_components/jquery-ui/jquery-ui.min.js') }}"></script>
<script src="{{asset('/public/admin/bower_components/jquery-migrate-3.0.0.js') }}"></script>
<script src="{{asset('/public/admin/bower_components/jquery.form.js') }}"></script>
<!-- Select2 -->
<script src="{{asset('/public/admin/bower_components/select2/dist/js/select2.full.min.js') }}"></script>
<!-- InputMask -->
<script src="{{asset('/public/admin/plugins/input-mask/jquery.inputmask.js') }}"></script>
<script src="{{asset('/public/admin/plugins/input-mask/jquery.inputmask.date.extensions.js') }}"></script>
<script src="{{asset('/public/admin/plugins/input-mask/jquery.inputmask.extensions.js') }}"></script>
<!-- date-range-picker -->
<script src="{{asset('/public/admin/bower_components/moment/min/moment.min.js') }}"></script>
<script src="{{asset('/public/admin/bower_components/bootstrap-daterangepicker/daterangepicker.js') }}"></script>
<!-- bootstrap datepicker -->
<script src="{{asset('/public/admin/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
<!-- bootstrap color picker -->
<script src="{{asset('/public/admin/bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js') }}"></script>
<!-- bootstrap time picker -->
<script src="{{asset('/public/admin/plugins/timepicker/bootstrap-timepicker.min.js') }}"></script>
<!-- Highcharts -->
<script src="{{asset('/public/admin/plugins/highcharts/highcharts.js') }}"></script>

<!-- SlimScroll -->
<script src="{{asset('/public/admin/bower_components/jquery-slimscroll/jquery.slimscroll.min.js') }}"></script>

<!-- bootstrap js -->
<script src="{{asset('/public/admin/bower_components/bootstrap/js/tooltip.js') }}"></script>

<!-- DataTables -->
<script src="{{asset('/public/admin/bower_components/datatables.net/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('/public/admin/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')}}"></script>

<!-- iCheck 1.0.1 -->
<script src="{{asset('/public/admin/plugins/iCheck/icheck.min.js') }}"></script>
<!-- FastClick -->
<script src="{{asset('/public/admin/bower_components/fastclick/lib/fastclick.js') }}"></script>

<!-- AdminLTE App -->
<script src="{{asset('/public/admin/dist/js/adminlte.min.js') }}"></script>
<!-- AdminLTE for demo purposes -->
{{--<script src="{{asset('/public/admin/dist/js/pages/dashboard2.js') }}"></script>--}}

<script src="{{asset('/public/admin/bower_components/chart.js/Chart.js') }}"></script>
<script src="{{asset('/public/admin/dist/js/demo.js') }}"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="{{asset('/public/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')}}"></script>

<script src="{{asset('/public/admin/bower_components/moment/moment.js') }}"></script>

<script src="{{asset('/public/admin/bower_components/fullcalendar/dist/fullcalendar.min.js') }}"></script>

{{--<script src="{{asset('/public/admin/bower_components/toasterjs/jquery.easing.1.3.js') }}"></script>--}}
<script src="{{asset('/public/admin/bower_components/toasterjs/toastr.min.js') }}"></script>
<script src="{{asset('/public/admin/bower_components/jquery.form.min.js') }}"></script>

<!-- include summernote css/js -->
<script src="{{asset('/public/admin/bower_components/summernote/summernote.min.js') }}"></script>

<script>
    // Common Scripts that will be available globally
    $(document).ready(function () {


        // Globally set autocomplete off to all over the application

        $(':text').prop('autocomplete', 'off');
        // $('input').iCheck({
        //     checkboxClass: 'icheckbox_square-blue',
        //     radioClass: 'iradio_square'
        // });

        // Datatable basic configuration

        $('.dataTable').DataTable({
            'paging': true,
            'lengthChange': true,
            "pageLength": '<?php echo $row_per_page;?>',
            'searching': true,
            'ordering': true,
            'info': true,
            'autoWidth': true
        });


        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal').iCheck({
            checkboxClass: 'icheckbox_minimal-blue'
        });


        // Summernote with configuration

        $(".summernote").summernote({
            height: 300,
            dialogsInBody: true
        });

        // Basic select2 configuration
        $(".select2").select2();
        // Tooltip, when mouse hover button
        $('[data-tooltip="tooltip"]').tooltip();


        // Delete modal popup form
        $('table[data-form="deleteForm"]').on('click', '.form-delete', function (e) {
            e.preventDefault();
            var $form = $(this);
            $('#confirm').modal({backdrop: 'static', keyboard: false})
                .on('click', '#delete-btn', function () {
                    $form.submit();
                });
        });

        // Toastr settings

        toastr.options = {
            "closeButton": true,
            "debug": true,
            "newestOnTop": false,
            "progressBar": true,
            "positionClass": "toast-bottom-right",
            "preventDuplicates": true,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "2000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        };


                @if(Session::has('message'))
        var type = "{{ Session::get('alert-type', 'info') }}";
        switch (type) {
            case 'info':
                toastr["info"]("{{ Session::get('message') }}");
                break;

            case 'warning':
                toastr["warning"]("{{ Session::get('message') }}");
                break;

            case 'success':
                toastr["success"]("{{ Session::get('message') }}");
                break;

            case 'error':
                toastr["error"]("{{ Session::get('message') }}");
                break;
        }
        @endif



    });

    $(".datepicker").datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd',
        autoclose: true
    });


</script>


<!-- Page script -->
@yield('script')
</body>
</html>

