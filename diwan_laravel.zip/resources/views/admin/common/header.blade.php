<header class="main-header">
    <a href="{{URL('dashboard')}}" class="logo">
        <span class="logo-mini"><b>B</b></span>
        <span class="logo-lg"><b style="font-size:19px;">Bulk Contacts Import</b>
            
        </span>
    </a>
    <nav class="navbar navbar-static-top">
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </a>
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                
               
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        @if(Auth::user()->profile_image)
                            <img src="{{asset('/public/uploads/users_profile/'.'/'.Auth::user()->profile_image)}}"
                                 class="user-image" alt="{{Auth::user()->username}}">
                        @else
                            <img src="{{asset('/public/uploads/users_profile/'.'/avatar.png')}}" class="user-image"
                                 alt="{{Auth::user()->username}}">
                        @endif
                        <span class="hidden-xs">{{Auth::user()->full_name}}</span></a>
                    <ul class="dropdown-menu animated fadeIn" style="width: 300px !important;">
                        <li class="user-header">
                            @if(Auth::user()->profile_image)
                                <img src="{{asset('/public/uploads/users_profile/'.'/'.Auth::user()->profile_image)}}"
                                     class="img-circle" alt="{{Auth::user()->username}}">
                            @else
                                <img src="{{asset('/public/uploads/users_profile/'.'/avatar.png')}}" class="img-circle"
                                     alt="{{Auth::user()->username}}">
                            @endif
                            <p>
                                {{Auth::user()->full_name}}
                                <small>
                                    {{memberRole(Auth::user()->id)}}
                                </small>
                            </p>
                        </li>
                        <li class="user-footer">
                            <div class="pull-left">
                                <a data-tooltip="tooltip" title="Change Password" href="{{url('/change-password')}}"
                                   class="btn btn-default btn-flat"><i class="fa change-password fa-key"></i>
                                    Password</a>
                            </div>
                            <div class="pull-left" style="position: relative;margin-left: 7px !important;">
                                <a data-tooltip="tooltip" title="Edit Profile" href="{{url('editProfile')}}"
                                   class="btn btn-default btn-flat"><i class="fa edit-profile fa-pencil"></i> Edit
                                </a>
                            </div>
                            <div class="pull-right">
                                <a data-tooltip="tooltip" title="Logout" href="{{URL('/logout')}}"
                                   class="btn btn-default btn-flat"><i class="fa user-logout fa-sign-out"></i>
                                    Logout</a>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>