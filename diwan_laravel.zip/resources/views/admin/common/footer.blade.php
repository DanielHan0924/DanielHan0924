<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version 1.0</b>
    </div>
    <strong>Copyright &copy; 2021</strong> All
    rights
    reserved.
</footer>