<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'guesty' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '#h+dB2q*s=xM}V*KKnBV,Z;!btca<0|2tzF1*8jk?{!^:|RI#?)C}N=bbZWp1:4_' );
define( 'SECURE_AUTH_KEY',  ']t$t7WVmz#&8Je:%BRrqRL]l&D@`_Ad>lkQ%xfo>#k[&]rYZL:YlJzJ&4f:Hyn@e' );
define( 'LOGGED_IN_KEY',    'xT6]4+C%5DlP)|F;L)Zh34?2 ebm%7zzBzW=]DgVTc.SG|GoIlGm|SM+.T-0[_e:' );
define( 'NONCE_KEY',        '-[k-mzKnBBEKj(NH8bJWRom>jh(-!O [d?~]4lMJ/m$`{Sm{9`Wpj$:tB:3!p=~Y' );
define( 'AUTH_SALT',        'Qy2S|w~e/KtA&]4p48t,8/pIX!ex`]juO.*ku7Hz.]VlAiO;#o--sN2Q;g/YG^]u' );
define( 'SECURE_AUTH_SALT', 'QU<.)TTD:y;;G<&sm}J15`e+y>)p#K&1vEU?P$SM3ek%7:9.tf?/2p#KV6H+o@lu' );
define( 'LOGGED_IN_SALT',   '#rewvl~ZUe+Ikb5(yfV1lgNL*S<. 2:4,2oh@P+gj4?e#.(}.e3IrikL++(AAxqJ' );
define( 'NONCE_SALT',       'NxCK;YAP[0jh3%|.X1!*SmE`~`baKgNoB+#LeKY(S7Se6&uiS_L_5TSoLS0$9v&h' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
