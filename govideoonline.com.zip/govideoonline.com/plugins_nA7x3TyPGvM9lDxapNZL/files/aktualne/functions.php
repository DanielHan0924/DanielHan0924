<?php
/*
Script for: Aktualne.cz
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 			  	= array();
		$curl_content 		= PHP_SYSTEM_url_get_contents($url);
		$preg_replace 		= preg_replace('#.*BBXPlayer\.setup\(\s*(.*?)\);.*#s', '$1', $curl_content);
		$json_data 			= json_decode($preg_replace ,true);
		$i = 0;
		foreach ($json_data['tracks']['MP4'] as $data_video) {
			$data['video'][$i] = [
									[
										'url' 			=> $data_video["src"],
										'format' 		=> 'mp4',
										'quality' 		=> $data_video["label"],
										'size' 			=> PHP_file_size($data_video["src"])
									],  
								];
			$i++;
		}
		return [
			'title'				=> trim(preg_replace('#.*<h1.*?>(.*?)</h1>.*#s', '$1', $curl_content)),
			'thumbnail'			=> PHP_string_between($curl_content, '<meta property="og:image" content="', '">'),
			'source'			=> 'aktualne',
			'video'				=> true,
			'data'				=> $data,
		];
	}
?>