<?php
/*
Script for: mashable.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 				= array();
		 
        $curl_content 		= PHP_SYSTEM_url_get_contents($url);
        preg_match_all('@<script class="playerMetadata" type="application/json">(.*?)</script>@si', $curl_content, $match);
        $json_data 			= $match[1][0]; 
		$json_data 			= json_decode($json_data, true);
		$i = 0;
        foreach ($json_data["player"]["sources"] as $data_video) {
			if(preg_match_all("@/(.*?).mp4@si", $data_video["file"], $match)){
				$data['video'][$i] = [
										[
											'url' 			=> $data_video["file"],
											'format' 		=> 'mp4',
											'quality' 		=> $match[1][1] . "p",
											'size' 			=> PHP_file_size($data_video["file"])
										],  
									];
				$i++;
			}
        }
		return [
			'title'				=> $json_data["player"]["title"],
			'thumbnail'			=> $json_data["player"]["image"],
			'source'			=> 'mashable',
			'video'				=> true,
			'data'				=> $data,
		];
	}
?>