<?php
/*
Script for: instagram.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
header('Content-Type: text/html; charset=utf-8');
set_time_limit(0);
date_default_timezone_set('UTC');
require __DIR__ . '/vendor/autoload.php';
\InstagramAPI\Instagram::$allowDangerousWebUsageAtMyOwnRisk = true;
/*
	> This part includes your instagram login information, your username and password
	> For you to connect to the API
*/
$data_class['user'] 		= "USER";
$data_class['pass'] 		= "PASS";
$debug 						= false;
$truncatedDebug 			= false;
$data_class['new'] 			= new \InstagramAPI\Instagram($debug, $truncatedDebug);
	error_reporting(0);
	function Data_Host_Function($url){
		global $data_class;
		$data 			= array(); 
        $curl_content 	= PHP_NATIVE_cURL($url);
		$video_true 	= false;
		$image_true 	= false;
		$Title 			= '';
		$Thumbnail 		= '';
		if(preg_match("/instagram.com\/stories\/([a-z1-9.-_]+)/", $url)){
			preg_match("/stories\/([a-zA-Z0-9]+)/", $url, $match);
			$data_class['new']->login($data_class['user'], $data_class['pass']);
			$user 		= $data_class['new']->people->getUserIdForName($match[1]);
			$storyFeed 	= $data_class['new']->story->getUserStoryFeed($user);
			$storyItems = $storyFeed->getReel()->getItems();
			$storyCount	= count($storyItems);
			for ($i=0; $i < $storyCount; $i++) {
				$json = $storyItems[$i]->getUser();
				$data_json = json_decode($json, true);
				//--> $data_json['username'];
				$Title 			 = $data_json['full_name'];
				$Thumbnail 		 = $data_json['profile_pic_url'];
				
				if ($storyItems[$i]->getMediaType()==1) {
					$image_true 	  = true;
					$data['list'][$i] = [
											[
												'url' 			=> $storyItems[$i]->getImageVersions2()->getCandidates()[0]->getUrl(),
												'format' 		=> 'jpg',
												'quality' 		=> 'Imagen',
												'size' 			=> (PHP_file_size($storyItems[$i]->getImageVersions2()->getCandidates()[0]->getUrl()) == NULL)? '?' : PHP_file_size($storyItems[$i]->getImageVersions2()->getCandidates()[0]->getUrl())
											],  
										];
				}else{
					$video_true 	   = true;
					$data['video'][$i] = [
											[
												'url' 			=> $storyItems[$i]->getVideoVersions()[0]->getUrl(),
												'format' 		=> 'mp4',
												'quality' 		=> 'HD',
												'size' 			=> PHP_file_size($storyItems[$i]->getVideoVersions()[0]->getUrl())
											],  
										];	
				}
			}
		}else{	
			switch (Data_type($curl_content)) {
				case "instapp:photo":
					$image_true 	 = true;
					$Title 			 = PHP_string_between($curl_content,'<title>','</title>');
					$Thumbnail 		 = Thumbnail($curl_content);
					$data['list'][0] = [
											[
												'url' 			=> Thumbnail($curl_content),
												'format' 		=> 'jpg',
												'quality' 		=> 'Imagen',
												'size' 			=> PHP_file_size(Thumbnail($curl_content))
											],  
										];
				break;
				case "video":
					$video_true 	  = true;
					$Title 			  = PHP_string_between($curl_content,'<title>','</title>');
					$Thumbnail 		  = Thumbnail($curl_content);
					$data['video'][0] = [
											[
												'url' 			=> Data_video($curl_content),
												'format' 		=> 'jpg',
												'quality' 		=> 'Imagen',
												'size' 			=> PHP_file_size(Data_video($curl_content))
											],  
										];				
				break;
			}
        }
		return [
			'title'				=> $Title,
			'thumbnail'			=> $Thumbnail,
			'source'			=> 'instagram',
			'video'				=> $video_true,
			'list'				=> $image_true,
			'data'				=> $data,
		];
	}
 	
	function Data_type($curl_content){
		return PHP_string_between($curl_content,'<meta property="og:type" content="','" />');
    }

    function Thumbnail($curl_content){
		return PHP_string_between($curl_content,'<meta property="og:image" content="','" />');
    }

    function Data_video($curl_content){
		return PHP_string_between($curl_content,'<meta property="og:video" content="','" />');
    }
 
?>