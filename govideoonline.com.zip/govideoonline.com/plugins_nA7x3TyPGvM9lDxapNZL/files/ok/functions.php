<?php
/*
Script for: ok.ru
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/	
	error_reporting(0);
	function Data_Host_Function($url){
        $video_data 			= get_data(str_replace("video/", "", substr(parse_url($url, PHP_URL_PATH), 1)));
		if (isset($video_data) != "") {
            $video_data = json_decode($video_data, true);
            $i = 0;
            foreach ($video_data["videos"] as $data_video) {
				$data['video'][$i] = [
										[
											'url' 			=> $data_video["url"],
											'format' 		=> 'mp4',
											'quality' 		=> $data_video["name"],
											'size' 			=> PHP_file_size($data_video["url"])
										],  
									];
                $i++;
            }
        } else {
            $data['video'][0] = [
									[
										'url' 			=> '',
										'format' 		=> '',
										'quality' 		=> '',
										'size' 			=> ''
									],  
								];
        }
		return [
			'title'				=> $video_data["movie"]["title"],
			'thumbnail'			=> $video_data["movie"]["poster"],
			'source'			=> 'ok.ru',
			'video'				=> true,
			'data'				=> $data,
			
		];
	} 
	
	function get_data($video_id){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://ok.ru/dk?cmd=videoPlayerMetadata&mid=$video_id",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST"
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return false;
        } else {
            return $response;
        }
    }

?>