<?php
/*
Script for: Ted.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 				= array();
        $curl_content 		= PHP_SYSTEM_url_get_contents($url);
        preg_match_all('@"__INITIAL_DATA__":(.*?)\}\)</script>@si', $curl_content, $match); 
		$json_data 			= json_decode($match[1][0], true);
		$i = 0;
        foreach ($json_data["talks"][0]["downloads"]["nativeDownloads"] as $quality => $data_video){
			$data['video'][$i] = [
									[
										'url' 			=> $data_video,
										'format' 		=> 'mp4',
										'quality' 		=> $quality,
										'size' 			=> size_url($data_video)
									],  
								];					
            $i++;
        }
		if($json_data["talks"][0]["downloads"]["audioDownload"]){
			$data['audio'][0] = [
									[
										'url' 			=> $json_data["talks"][0]["downloads"]["audioDownload"],
										'format' 		=> 'mp3',
										'quality' 		=> '128 Kbps',
										'size' 			=> size_url($json_data["talks"][0]["downloads"]["audioDownload"])
									],  
								];	
		}
		return [
			'title'				=> $json_data["name"],
			'thumbnail'			=> $json_data["talks"][0]["hero"],
			'source'			=> 'ted',
			'video'				=> true,
			'audio'				=> true,
			'direct_download'	=> 'on',
			'data'				=> $data,
		];
	}
	
	function size_url($url){
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_NOBODY, true);
		curl_setopt($curl, CURLOPT_HEADER, true);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_REFERER, '');
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240");
		$header = curl_exec($curl);
		return (int)curl_getinfo($curl, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
		curl_close($curl);
	}
?>