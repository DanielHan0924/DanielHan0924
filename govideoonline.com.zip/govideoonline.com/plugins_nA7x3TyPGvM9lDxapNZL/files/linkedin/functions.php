<?php
/*
Script for: linkedin.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 				= array();
		$curl_content 		= PHP_SYSTEM_url_get_contents($url);
		$content 			= _Decode(PHP_string_between($curl_content,'data-sources="','"'));
		preg_match('/"src":"(.*?)"/', $content, $data_video);

		$data['video'][0] = [
								[
									'url' 			=> $data_video[1],
									'format' 		=> 'mp4',
									'quality' 		=> 'HD',
									'size' 			=> PHP_file_size($data_video[1])
								],  
							];
		return [
			'title'				=> PHP_string_between($curl_content, '<title>' ,'</title>'),
			'thumbnail'			=> PHP_string_between($curl_content, '<meta property="og:image" content="' ,'"/>'),
			'source'			=> 'Linkedin',
			'video'				=> true,
			'data'				=> $data,
		];
	}

	 
?>