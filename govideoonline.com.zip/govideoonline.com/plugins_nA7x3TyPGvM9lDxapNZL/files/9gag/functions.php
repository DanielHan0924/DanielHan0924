<?php
/*
Script for: 9gag.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 				= array();
		$curl_content 		= PHP_SYSTEM_url_get_contents($url);
		$id 				= explode('/', parse_url($url, PHP_URL_PATH));
        $id 				= $id[2];
        $url 				= "https://img-9gag-fun.9cache.com/photo/" . $id . "_460sv.mp4";
        $data_video 		= PHP_file_size($url);
		if ($data_video > 1000) {
			$data['video'][0] = [
									[
										'url' 			=> $url,
										'format' 		=> 'mp4',
										'quality' 		=> 'HD',
										'size' 			=> $data_video
									],  
								];
                 
        }
		return [
			'title'				=> '9gag' . time(),
			'thumbnail'			=> "http://images-cdn.9gag.com/photo/" . $id . "_460s.jpg",
			'source'			=> '9gag',
			'video'				=> true,
			'data'				=> $data,
		];
	}

	 
?>