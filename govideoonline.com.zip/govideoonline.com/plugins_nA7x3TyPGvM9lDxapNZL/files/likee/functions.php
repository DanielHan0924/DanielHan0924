<?php
/*
Script for: mobile.like-video.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 			  	= array();
		$curl_content 	  	= PHP_SYSTEM_url_get_contents(ExtractVideoId($url));
		
		$Url_video 			= Url_video($curl_content);
		$Watermarked	 	= str_replace("_4.mp4", ".mp4", $Url_video);
		$size_video 		= PHP_file_size($Watermarked);	
		
        $data['video'][0] = [
								[
									'url' 			=> $Url_video,
									'format' 		=> 'mp4',
									'quality' 		=> '720p',
									'size' 			=> PHP_file_size($Url_video)
								],  
							];
							
		$data['video'][1] = [
								[
									'url' 			=> $Watermarked,
									'format' 		=> 'mp4',
									'quality' 		=> 'HD - Watermarked',
									'size' 			=> $size_video
								],  
							];	
		 
		return [
			'title'				=> PHP_string_between($curl_content,'<title>','</title>'),
			'thumbnail'			=> Thumbnail($curl_content),
			'source'			=> 'Likee',
			'video'				=> true,
			'data'				=> $data,
			
		];
	} 
	
	function Url_video($curl_content){
		preg_match('@"video_url":"(.*?)"@si', $curl_content, $match);
        $url = str_replace('\/', '/', $match[1]);		
        return $url;		
	}

	function Thumbnail($curl_content){
        preg_match('@"image2":"(.*?)"@si', $curl_content, $match);
        return $match[1];
        
    }
	
	function ExtractVideoId($url){
        $domain = str_ireplace("www.", "", parse_url($url, PHP_URL_HOST));
        switch ($domain) {
            case "mobile.like-video.com":
                $path = parse_url($url, PHP_URL_PATH);
                $path_fragments = explode("/", $path);
                $video_id = end($path_fragments);
                return 'https://mobile.like-video.com/s/'.$video_id;
                break;
            case "likee.video":
                $path = parse_url($url, PHP_URL_PATH);
                $path_fragments = explode("/", $path);
                $video_id = end($path_fragments);
                return 'https://mobile.like-video.com/s/'.$video_id;
                break;
			case "like.video":
                $path = parse_url($url, PHP_URL_PATH);
                $path_fragments = explode("/", $path);
                $video_id = end($path_fragments);
                return 'https://mobile.like-video.com/s/'.$video_id;
                break;				
            default:
                return "";
                break;
        }
    }

?> 