<?php
/*
Script for: douban.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 				= array();
		$curl_content 		= PHP_SYSTEM_url_get_contents($url);
		$contents 			= PHP_string_between($curl_content,'<script type="application/ld+json">','</script>');
		$json_data 			= json_decode($contents , true);
		
		$data['video'][0] = [
								[
									'url' 			=> $json_data['embedUrl'],
									'format' 		=> 'mp4',
									'quality' 		=> 'HD',
									'size' 			=> PHP_file_size($json_data['embedUrl'])
								],  
							];
		return [
			'title'				=> $json_data['name'],
			'thumbnail'			=> $json_data['thumbnailUrl'],
			'source'			=> 'douban',
			'video'				=> true,
			'data'				=> $data,
		];
	}

	 
?>