<?php
/*
Script for: imdb.COM
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 				= array();
		preg_match_all('/vi\d{5,20}/m', $url, $video_id, PREG_SET_ORDER, 0);
		$content 			= "https://www.imdb.com/video/imdb/" . $video_id[0][0]. "/imdb/embed";
        $curl_content 		= PHP_SYSTEM_url_get_contents($content);
        $content 			= PHP_string_between($curl_content, '<script class="imdb-player-data" type="text/imdb-video-player-json">', '</script>');
        $content 			= json_decode($content, true);
		$json_data 			= $content["videoPlayerObject"]["video"]["videoInfoList"];
		$i = 0;
        foreach ($json_data as $data_video) {
            if ($data_video["videoMimeType"] == "video/mp4") {
				$data['video'][$i] = [
										[
											'url' 			=> $data_video["videoUrl"],
											'format' 		=> 'mp4',
											'quality' 		=> 'HD',
											'size' 			=> PHP_file_size($data_video["videoUrl"])
										],  
									];
                    $i++;
                }
        }
		return [
			'title'				=> PHP_string_between($curl_content, '<meta property="og:title" content="', '"/>'),
			'thumbnail'			=> PHP_string_between($curl_content, '<meta property="og:image" content="', '"/>'),
			'source'			=> 'imdb',
			'video'				=> true,
			'data'				=> $data,
		];
	}
?>