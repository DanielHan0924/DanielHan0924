<?php
/*
Plugin Name: vimeo
Plugin Key: 4A
Plugin Icon: https://i.imgur.com/bd2jB2B.png
Update date: 24-07-2020
Version: 1.4
Author: zhareiv
Url_line: "url_line":"/vimeo.com\/([a-z1-9.-_]+)/";
Title plugin: Vimeo Video Downloader
Description plugin: Vimeo Video Downloader
Content plugin:  &lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;
Url: vimeo-videos-downloader
*/
?>