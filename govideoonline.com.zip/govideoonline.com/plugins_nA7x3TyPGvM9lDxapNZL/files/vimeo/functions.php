<?php
/*
Script for: Vimeo.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 			  	= array();
		$curl_content 	  	= PHP_SYSTEM_url_get_contents($url);
		if (preg_match_all('/window.vimeo.clip_page_config.player\s*=\s*({.+?})\s*;\s*\n/', $curl_content, $match)) {
			$config_url 	= json_decode($match[1][0], true)["config_url"];
			$result 		= json_decode(PHP_SYSTEM_url_get_contents($config_url), true);
			$i = 0;
			foreach ($result["request"]["files"]["progressive"] as $data_video) {
				$data['video'][$i] = [
										[
											'url' 			=> $data_video["url"],
											'format' 		=> 'mp4',
											'quality' 		=> $data_video["quality"],
											'size' 			=> PHP_file_size($data_video["url"])
										],  
									];
				$i++;					
			}						
		}						
		return [
			'title'				=> $result["video"]["title"],
			'thumbnail'			=> reset($result["video"]["thumbs"]),
			'source'			=> 'Vimeo',
			'video'				=> true,
			'data'				=> $data,
			
		];
	}
?>
