<?php
/*
Script for: break.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/	
	error_reporting(0);
	$curl_content  = PHP_NATIVE_cURL($data_url);
	preg_match('~<video id="player"[^>]*>(.*?)</video>~si', $curl_content, $load_url);		
	preg_match('/< *source [^>]*src *= *["\']?([^"\']*)/i', $load_url[1], $matches);
	$media_url = str_ireplace("www.", "", parse_url($matches[1], PHP_URL_HOST));        
	if ($media_url == "youtube.com" || $media_url == "m.youtube.com" || $media_url == "youtu.be"){ //--> Extension of YouTube 
		$data_url = $matches[1];
		include($plugins_dir . "/youtube/functions.php");
	}else{
		function Data_Host_Function($url){
			$data			  = array();
			$curl_content  	  = PHP_SYSTEM_url_get_contents($url);
			preg_match_all('/<iframe src="(.*?)"/', $curl_content, $url_media);
			$content	  	  = PHP_SYSTEM_url_get_contents($url_media[1][0]);
			$data['video'][0] = [
									[
										'url' 			=> PHP_string_between($content, '_mvp.file = "', '";'),
										'format' 		=> 'mp4',
										'quality' 		=> 'SD',
										'size' 			=> PHP_file_size(PHP_string_between($content, '_mvp.file = "', '";'))
									],  
								]; 
			return [
				'title'				=> PHP_string_between($curl_content,'<meta property="og:title" content="','" />'),
				'thumbnail'			=> PHP_string_between($content, '_mvp.image = "', '";'),
				'source'			=> 'break',
				'video'				=> true,
				'data'				=> $data,
			];
		}
	}
?>