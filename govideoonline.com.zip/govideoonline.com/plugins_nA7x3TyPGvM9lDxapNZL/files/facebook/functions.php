<?php
/*
Script for: facebook.com
Author: Zhareiv
Update date: 29-10-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 			= array();
        $curl_content 	= url_get_contents_facebook(remove_url($url));
		$Video_SD 		= Video_SD($curl_content);
		$Video_HD 		= Video_HD($curl_content);
		 
		$data['video'][0] = [
								[
									'url' 			=> $Video_SD,
									'format' 		=> 'mp4',
									'quality' 		=> 'SD',
									'size' 			=> PHP_file_size($Video_SD)
								],  
							];
		if(!empty($Video_HD)){
			$data['video'][1] = [
									[
										'url' 			=> $Video_HD,
										'format' 		=> 'mp4',
										'quality' 		=> 'HD',
										'size' 			=> PHP_file_size($Video_HD)
									],  
								];
		}
		return [
			'title'				=> Title_video($curl_content),
			'thumbnail'			=> thumbnail($curl_content),
			'source'			=> 'facebook',
			'video'				=> true,
			'data'				=> $data,
		];
	} 

	function thumbnail($curl_content){
		
		$image_1 		= PHP_string_between($curl_content,'<meta name="twitter:image" content="','" />');
		$image_2 		= PHP_string_between($curl_content,'<meta property="og:image" content="','" />');
		$thumbnail 		= '';
		if($image_1){
			$thumbnail 	= $image_1;
		}else if($image_2){
			$thumbnail 	= $image_2;
		}
		
		return $thumbnail;
	}

	function cleanStr($str){
		return html_entity_decode(strip_tags($str), ENT_QUOTES, 'UTF-8');
	}

	function Video_SD($curl_content){
		$regex = '/sd_src_no_ratelimit:"([^"]+)"/';
		if (preg_match($regex, $curl_content, $match)) {
			return $match[1];
		} else {
			return;
		}
	}

	function Video_HD($curl_content){
        $regex = '/hd_src:"([^"]+)"/';
		if (preg_match($regex, $curl_content, $match)) {
			return $match[1];
		} else {
			return;
		}
	}

	function remove_url($url){
        $url = str_replace("m.facebook.com", "www.facebook.com", $url);
        return $url;
    }

	function Title_video($curl_content){
		if (preg_match('/<title[^>]*>([^<]*)<\/title>/si', $curl_content, $matches) == 1){
			$Title = preg_replace('/[^\p{L}\p{N} ]+/u', "", trim($matches[1]));
			$Title = preg_replace('/(\s*facebook)$/i', "", trim($Title));
			$Title = (!empty($Title)) ? $Title : 'No title';
		}
		return cleanStr($Title);
	}
	
	function mobilLink($curl_content){
		$regex = '@&quot;https:(.*?)&quot;,&quot;@si';
		if (preg_match_all($regex, $curl_content, $match)) {
			return $match[1][0];
		} else {
			return;
		}
	}
	
	function url_get_contents_facebook($url){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.47 Safari/537.36');    
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		$data = curl_exec($ch);
		curl_close($ch);
		return $data;
	}	
?>