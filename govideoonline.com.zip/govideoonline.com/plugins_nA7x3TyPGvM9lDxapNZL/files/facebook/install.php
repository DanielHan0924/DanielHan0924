<?php
/*
Plugin Name: FaceBook
Plugin Key: 2A
Plugin Icon: https://i.imgur.com/qnFg0N7.png
Update date: 29-10-2020
Version: 1.9
Author: zhareiv
Url_line:"url_line":"/facebook.com\/watch\/(.+)v=([a-z1-9.-_]+)/"; "url_line":"/facebook.com\/watch\/([a-z1-9.-_]+)/"; "url_line":"/fb.watch\/([a-z1-9.-_]+)/"; "url_line":"/facebook.com\/([a-z1-9.-_]+)/"; "url_line":"/m.facebook.com\/([a-z1-9.-_]+)/"; "url_line":"/web.facebook.com\/([a-z1-9.-_]+)/";
Title plugin: FaceBook Video Downloader
Description plugin: FaceBook Video Downloader
Content plugin:  &lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;
Url: facebook-videos-downloader
*/
?>
 