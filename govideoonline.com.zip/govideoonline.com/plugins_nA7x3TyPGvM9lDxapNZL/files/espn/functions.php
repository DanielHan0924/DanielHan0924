<?php
/*
Script for: espn.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 				= array();
		$Video_id 			= Video_id($url);
		$url 				= 'http://cdn.espn.com/video/clip/_/id/'.$Video_id.'?xhr=1&device=desktop&country=us';
		$curl_content 		= PHP_SYSTEM_url_get_contents($url);
		$json_data 			= json_decode($curl_content, true);
		$i = 0;
        foreach ($json_data["content"]["links"]["source"] as $key => $data_video) {
            if($key == "href"){
				$data['video'][$i] = [
										[
											'url' 			=> $data_video,
											'format' 		=> 'mp4',
											'quality' 		=> '360p',
											'size' 			=> PHP_file_size($data_video)
										],  
									];
                    $i++;
			}else if($key == "HD"){
				$data['video'][$i] = [
										[
											'url' 			=> $data_video["href"],
											'format' 		=> 'mp4',
											'quality' 		=> '720p',
											'size' 			=> PHP_file_size($data_video["href"])
										],  
									];
                $i++;
			}
        }
		return [
			'title'				=> PHP_string_between($curl_content,'<meta property="og:title" content="','">'),
			'thumbnail'			=> PHP_string_between($curl_content,'<meta property="og:image" content="','">'),
			'source'			=> 'espn',
			'video'				=> true,
			'data'				=> $data,
		];
	}

	function Video_id($url){
        if (preg_match("/(id=[^&]+)/", $url, $match)) {
            $data_video = (int)filter_var($match[0], FILTER_SANITIZE_NUMBER_INT);
            return $data_video;
        }else if(preg_match("/(id\/[^&]+)/", $url, $match)){
			$data_video = (int)filter_var($match[0], FILTER_SANITIZE_NUMBER_INT);
            return $data_video;
        }else if(preg_match("/(video\/[^&]+)/", $url, $match)){
			$data_video = (int)filter_var($match[0], FILTER_SANITIZE_NUMBER_INT);
            return $data_video;
		}
    } 
?>