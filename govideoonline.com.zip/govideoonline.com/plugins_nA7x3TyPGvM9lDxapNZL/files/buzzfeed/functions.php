<?php
/*
Script for: buzzfeed.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	$curl_content  = PHP_NATIVE_cURL($data_url);
	if (preg_match('@<fb:post class="fb-post js-fb-post js-hidden" data-href="(.*?)" style="width: 100%"></fb:post>@si', $curl_content, $video_url)) {
		$original_url 	= $video_url[1];
		$data_url 		= $original_url;
		include($plugins_dir . "/facebook/functions.php");
	} elseif (preg_match('@"videoId": "(.*?)"@si', $curl_content, $video_url)) {
		$original_url 	= "https://www.youtube.com/watch?v=" . $video_url[1];
		$data_url 		= $original_url;
		include($plugins_dir . "/youtube/functions.php");
	}
	

?>