<?php
/*
Script for: Liveleak.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	$curl_content  		= PHP_SYSTEM_url_get_contents($data_url);
	$data_video_url 	= PHP_string_between($curl_content, '<iframe width="100%" height="500px" src="', '" allow="autoplay" frameborder="0" allowfullscreen>'); 
	$data_video_url 	= str_replace('//www.youtube.com/embed/', 'https://www.youtube.com/watch?v=', $data_video_url);
	$data_video_url 	= str_replace('?autoplay=1', '', $data_video_url);
	$media_url		 	= str_ireplace("www.", "", parse_url($data_video_url, PHP_URL_HOST));        
	if ($media_url == "youtube.com" || $media_url == "m.youtube.com" || $media_url == "youtu.be"){		
		//--> YouTube
		$data_url = $data_video_url;
		include($plugins_dir . "/youtube/functions.php");
	}else{
		function Data_Host_Function($url){
			$data 				= array();
			$curl_content 		= PHP_SYSTEM_url_get_contents($url);
			$i = 0;
			if (preg_match_all('/src="(.*?)" (default|) label="(720p|360p|HD|SD)"/', $curl_content, $json_data)) {
				foreach ($json_data[1] as $data_video) {
					$data['video'][$i] = [
											[
												'url' 			=> $data_video,
												'format' 		=> 'mp4',
												'quality' 		=> $data_video[3][$i],
												'size' 			=> PHP_file_size($data_video)
											],  
										];
					$i++;
				}
			}
			return [
				'title'				=> PHP_string_between($curl_content, '<meta property="og:title" content="', '"/>'),
				'thumbnail'			=> PHP_string_between($curl_content, '<meta property="og:image" content="', '"/>'),
				'source'			=> 'Liveleak',
				'video'				=> true,
				'data'				=> $data,
			];
		}
	}
?>