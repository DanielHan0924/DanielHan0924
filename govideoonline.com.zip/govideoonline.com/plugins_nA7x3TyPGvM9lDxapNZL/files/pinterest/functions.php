<?php 
/*
Script for: pinterest.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 			  	= array();
		if (preg_match("/pin.it(.+)([^&]+)/", $url)){
			$curl_content 	= PHP_SYSTEM_url_get_contents($url);
			$url 			= PHP_string_between($curl_content,'<meta property="og:url" name="og:url" content="','" data-app="true"/>');
		} 
		$curl_content 		= PHP_SYSTEM_url_get_contents($url);	 
		$curl_content_json 	= PHP_string_between($curl_content, '<script id="initial-state" type="application/json">', '</script>');
		$json_data 			= json_decode($curl_content_json, true);
		$i = 0;
		foreach ($json_data["resourceResponses"][0]["response"]["data"]["videos"]["video_list"] as $data_video) {
			if (PHP_Format_video($data_video["url"]) == "MP4"){
				$data['video'][$i] = [
										[
											'url' 			=> $data_video["url"],
											'format' 		=> strtolower(PHP_Format_video($data_video["url"])),
											'quality' 		=> $data_video["width"] . "p",
											'size' 			=> PHP_file_size($data_video["url"])
										],  
									];
			} 
			$i++;
		}
		return [
			'title'				=> PHP_string_between($curl_content,'<meta property="og:title" name="og:title" content="','" data-app="true"/>'),
			'thumbnail'			=> PHP_string_between($curl_content,'<meta property="og:image" name="og:image" content="','" data-app="true"/>'),
			'source'			=> 'Pinteres',
			'video'				=> true,
			'data'				=> $data,
		];
	}
?>