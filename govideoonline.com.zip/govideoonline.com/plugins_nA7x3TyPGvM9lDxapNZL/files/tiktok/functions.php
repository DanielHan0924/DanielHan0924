<?php
/*
Script for: tiktok.com
Author: Zhareiv
Update date: 01-11-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		global $config;
		$curl_content 	= PHP_SYSTEM_url_get_contents($url);
		
		
		$videoObject 	= getContent($url);
		$data_url 		= explode('"downloadAddr":"', $videoObject);
		if(isset($data_url) != ""){
			 
			$data_url 			= explode("\"",$data_url[1])[0];
			$video_data_url 		= str_replace("\\u0026", "&", $data_url);
			$title 					= PHP_string_between($videoObject,'<meta property="og:title" content="','"/>');
            $thumbnail 				= PHP_string_between($videoObject,'<meta property="og:image" content="','"/>');
			$video_data 			= download_Video_tiktok($video_data_url);
			$video_data_watermarked = getContent($config['site_url'].'/'.$video_data);
			preg_match('/vid:([a-zA-Z0-9]+)/', $video_data_watermarked, $matches);
			
			if(count($matches) > 1){
				$true_video = true;
				$video_Key 	= $matches[1];
				
				$url_watermarked = getContent("https://api2-16-h2.musical.ly/aweme/v1/play/?video_id=$video_Key&vr_type=0&is_play_url=1&source=PackSourceEnum_PUBLISH&media_type=4", true);
			} else {
				$true_video = false;
			}
 
			
			//--> Audio TikTok
			$audio_true 	= false;
			/* preg_match('~<script id="__NEXT_DATA__"[^>]*>(.*?)</script>~si', $videoObject, $audio);
			$json_decode 	= $audio[1];
			$data_audio 	= json_decode($json_decode, true);
			$content_audio 	= getContent(audio_tiktok($videoObject), true);  */
			$audio_tiktok 	= PHP_string_between($videoObject,'"playUrl":"','",'); 
		 
			 
            $data['video'][0] = [
									[
										'url' 			=> $config['site_url'].'/'.$video_data,
										'format' 		=> 'mp4',
										'quality' 		=> 'HD - Origial',
										'size' 			=> filesize($video_data)
									],  
								];
			if($true_video){
				$data['video'][1] = [
										[
											'url' 			=> $url_watermarked,
											'format' 		=> 'mp4',
											'quality' 		=> 'HD - Watermarked',
											'size' 			=> PHP_file_size($url_watermarked)
										],  
									];
			}
			if($audio_tiktok){
				$audio_true 	  = true;
				$data['audio'][0] = [
										[
											'url' 			=> $audio_tiktok,
											'format' 		=> 'MP3',
											'quality' 		=> '128 Kbps',
											'size' 			=> PHP_file_size($audio_tiktok)
										],  
									];
			}					
		}

		return [
			'title'				=> $title,
			'thumbnail'			=> $thumbnail,
			'source'			=> 'tiktok',
			'video'				=> true,
			'audio'				=> $audio_true,
			'data'				=> $data,
		];
	}
 
	function download_Video_tiktok($video_url, $geturl = false){		
		$ch = curl_init();
		$headers = array(
			'Range: bytes=0-',
		);
		$options = array(
			CURLOPT_URL            => $video_url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_HEADER         => false,
			CURLOPT_HTTPHEADER     => $headers,
			CURLOPT_FOLLOWLOCATION => true,
			CURLINFO_HEADER_OUT    => true,
			CURLOPT_USERAGENT => 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Mobile Safari/537.36',
			CURLOPT_ENCODING       => "utf-8",
			CURLOPT_AUTOREFERER    => true,
			CURLOPT_COOKIEJAR      => 'cookie_tiktok.txt',
			CURLOPT_COOKIEFILE     => 'cookie_tiktok.txt',
			CURLOPT_REFERER        => 'https://www.tiktok.com/',
			CURLOPT_CONNECTTIMEOUT => 30,
			CURLOPT_SSL_VERIFYHOST => false,
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_TIMEOUT        => 30,
			CURLOPT_MAXREDIRS      => 10,
		);
		curl_setopt_array( $ch, $options );
		if (defined('CURLOPT_IPRESOLVE') && defined('CURL_IPRESOLVE_V4')) {
		  curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
		}
		$data = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		if ($geturl === true){
			return curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
		}
		curl_close($ch);
		
		$time = time() + 1500;
		
		$in = 'time_{'.$time.'}_tintok_'.PHP_GetKey(5,8).time().".mp4";
		
		$data_file = array(
				'video' => $in
			);
		
		File_download_host($data_file);
		
		$filename = "download_file/" . $in;
		$d = fopen($filename, "w");
		fwrite($d, $data);
		fclose($d);
		return $filename;
	}
 
	function audio_tiktok($url){
		$musicName 	= str_replace(' ', '-', PHP_string_between($url,'"musicName":"','"'));
		$musicId 	= str_replace(' ', '-', PHP_string_between($url,'"musicId":"','"'));
		$data 		= 'https://www.tiktok.com/music/'.$musicName.'-'.$musicId.'';
		return $data;
	}
		
	function getContent($url, $geturl = false){
		$ch = curl_init();
		$options = array(
			CURLOPT_URL            	=> $url,
			CURLOPT_RETURNTRANSFER 	=> true,
			CURLOPT_HEADER         	=> false,
			CURLOPT_FOLLOWLOCATION 	=> true,
			CURLOPT_USERAGENT 		=> 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Mobile Safari/537.36',
			CURLOPT_ENCODING       	=> "utf-8",
			CURLOPT_AUTOREFERER    	=> false,
			CURLOPT_COOKIEJAR      	=> 'cookie_tiktok.txt',
			CURLOPT_COOKIEFILE     	=> 'cookie_tiktok.txt',
			CURLOPT_REFERER        	=> 'https://www.tiktok.com/',
			CURLOPT_CONNECTTIMEOUT 	=> 30,
			CURLOPT_SSL_VERIFYHOST 	=> false,
			CURLOPT_SSL_VERIFYPEER 	=> false,
			CURLOPT_TIMEOUT        	=> 30,
			CURLOPT_MAXREDIRS      	=> 10,
		);
		curl_setopt_array( $ch, $options );
		if(defined('CURLOPT_IPRESOLVE') && defined('CURL_IPRESOLVE_V4')) {
		  curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
		}
		$data = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		if ($geturl === true){
			return curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
		}
		curl_close($ch);
		return strval($data);
	}
?>