<?php
/*
Plugin Name: TikTok
Plugin Key: 8A
Plugin Icon: https://i.imgur.com/bO21kdQ.png
Update date: 01-11-2020
Version: 2.0
Author: zhareiv
Url_line: "url_line":"/vt.tiktok.com\/([^&]+)/"; "url_line":"/m.tiktok.com\/v\/([^&]+)/"; "url_line":"/vm.tiktok.com\/([^&]+)/"; "url_line":"/tiktok.com\/share\/video\/([^&]+)/"; "url_line":"/tiktok.com\/([a-z1-9.-_]+)\/video\/([^&]+)/";
Title plugin: TikTok Video Downloader
Description plugin: TikTok Video Downloader
Content plugin:  &lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;
Url: tiktok-videos-downloader
*/
?>