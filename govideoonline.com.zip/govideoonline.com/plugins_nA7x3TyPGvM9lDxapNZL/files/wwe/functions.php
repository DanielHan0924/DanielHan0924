<?php
/*
Script for: wwe.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 			  	= array();
		$url_video 			= curl_content($url);
		$meta 				= PHP_Get_Tags($url);
		$data['video'][0] = [
								[
									'url' 			=> $url_video['stream'],
									'format' 		=> 'mp4',
									'quality' 		=> 'HD',
									'size' 			=> PHP_file_size($url_video['stream'])
								],  
							];
			
		return [
			'title'				=> $meta['title'],
			'thumbnail'			=> $meta['image'],
			'source'			=> 'wwe',
			'video'				=> true,
			'data'				=> $data,
		];
	}

	function curl_content($url) {
		@$html = file_get_contents($url);
		@libxml_use_internal_errors(true);
		$dom = new DomDocument();
		@$dom->loadHTML($html);
		$xpath = new DOMXPath($dom);
		$query = '//*/meta[starts-with(@name, \'twitter:player:\')]';
		$result = $xpath->query($query);
		foreach ($result as $meta) {
			$name = $meta->getAttribute('name');
			$content = $meta->getAttribute('content');
		
			$name = str_replace('twitter:player:', '', $name);
			$list[$name] = $content;
		}
		return @$list;
	}
?>