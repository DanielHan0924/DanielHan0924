<?php
/*
Script for: reddit.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
        $curl_content = get_contents_Reddit($url);
		if (preg_match('@"scrubberThumbSource":"(.*?)"@si', $curl_content, $data_video)) {

			$quality 	= array(
								96,
								144,
								240,
								360,
								480,
								720,
								1080
							);
			$i = 0;				
			foreach($quality as $size) {
				
				$url_video = str_replace('DASH_96', 'DASH_' . $size, $data_video[1]);
			 
				if(PHP_file_size($url_video) > 300){
					$data['video'][$i] = [
											[
												'url' 			=> $url_video,
												'format' 		=> 'mp4',
												'quality' 		=> $size . 'p',
												'size' 			=> PHP_file_size($url_video)
											],  
										];	 
					}
				
				$i++;					
			}					
        } else {
            $data['video'][0] = [
									[
										'url' 			=> '',
										'format' 		=> '',
										'quality' 		=> '',
										'size' 			=> ''
									],  
								];
        }
		return [
			'title'				=> PHP_string_between($curl_content,'<meta property="og:title" content="','"/>'),
			'thumbnail'			=> PHP_string_between($curl_content,'<meta property="og:image" content="','"/>'),
			'source'			=> 'Reddit',
			'video'				=> true,
			'data'				=> $data,
		];
	} 
	
	function get_contents_Reddit($linkinfo){
		$context = [
			'http' => [
				'method' => 'GET',
				'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.47 Safari/537.36",
			],
		];
		$context = stream_context_create($context);
		$data = file_get_contents($linkinfo, false, $context);
		return $data;
	}	
?>