<?php
/*
Script for: izlesene.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 			  	= array();
		$curl_content 		= PHP_SYSTEM_url_get_contents($url);
		if (preg_match_all('/videoObj\s*=\s*({.+?})\s*;\s*\n/', $curl_content, $match)) {
            $media 			= json_decode($match[1][0], true);
			if (!empty($media["media"]["level"])) {
                $i = 0;
				foreach ($media["media"]["level"] as $data_video) {
					$Header 		   = curlHeader($data_video["source"]);
					$data['video'][$i] = [
											[
												'url' 			=> $data_video["source"],
												'format' 		=> 'mp4',
												'quality' 		=> $data_video["value"] . "p",
												'size' 			=> size_url($data_video["source"])
											],  
										];
					$i++;
				}
			}
		}
		return [
			'title'				=> $media["videoTitle"],
			'thumbnail'			=> $media["posterURL"],
			'source'			=> 'izlesene',
			'video'				=> true,
			'data'				=> $data,
		];
	}
	
	function size_url($url){
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_NOBODY, true);
		curl_setopt($curl, CURLOPT_HEADER, true);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_REFERER, '');
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240");
		$header = curl_exec($curl);
		return (int)curl_getinfo($curl, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
		curl_close($curl);
	}
?>