<?php
/*
Script for: krcom.ch
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 				= array();
        $curl_content 		= PHP_SYSTEM_url_get_contents($url);
		preg_match_all("/video-sources=(.*?)action-data=/is", $curl_content, $matches);
		$videosUrlList 		= str_replace(['\n', '\"'], '', $matches[1][0]);
		$videosUrlList 		= explode('video&', $videosUrlList);
		$thumbnailUrl 		= explode('cover_img=', $curl_content);
		$thumbnail 			= explode('=', $thumbnailUrl[1]);
		$i = 0;
		foreach($videosUrlList as $data_video){
			$temp 			= explode('=', $data_video);
			$data_video 	= rtrim(str_replace('video', '', $temp[1]));
			if(PHP_file_size('http:' . urldecode($data_video) . 'video')=='unknown'){
					//--> error
			}else{
				$data_video 	= (PHP_file_size('http:' . urldecode($data_video) . 'video')=='unknown')?'':'http:' . urldecode($data_video) . 'video';
			}
			$data['video'][$i] 	= [
									[
										'url' 			=> $data_video,
										'format' 		=> 'mp4',
										'quality' 		=> $temp[0]. 'p',
										'size' 			=> PHP_file_size($data_video)
									],  
								];
			$i++;
		}					
		return [
			'title'				=> PHP_string_between($curl_content,'<title>','</title>'),
			'thumbnail'			=> urldecode($thumbnail[0]),
			'source'			=> 'krcom',
			'video'				=> true,
			'data'				=> $data,
		];
	}
?>