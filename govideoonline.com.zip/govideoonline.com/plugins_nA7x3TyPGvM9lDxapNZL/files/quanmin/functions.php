<?php
/*
Script for: quanmin.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 				= array();
        $curl_content 		= PHP_SYSTEM_url_get_contents(html_entity_decode($url));
		preg_match_all('/window._page_data = (({.+?}));/', $curl_content, $matches);
		$json_data 			= $matches[1][0];
		$json_data 			= json_decode($json_data, true);	
		$data_video 		= $json_data['meta']['videoInfo']['clarityUrl'][0]['url'];
		$data['video'][0] 	= [
								[
									'url' 			=> $data_video,
									'format' 		=> 'mp4',
									'quality' 		=> strtoupper($json_data['meta']['videoInfo']['clarityUrl'][0]['key']),
									'size' 			=> PHP_file_size($data_video)
								],  
							];
            
		return [
			'title'				=> PHP_string_between($curl_content, '<meta property="og:title" content="', '">'),
			'thumbnail'			=> $json_data['meta']['image'],
			'source'			=> 'quanmin',
			'video'				=> true,
			'data'				=> $data,
		];
	}
?>
