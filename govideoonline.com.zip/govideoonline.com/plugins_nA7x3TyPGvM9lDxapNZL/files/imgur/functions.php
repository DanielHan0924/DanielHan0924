<?php
/*
Script for: imgur.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 				= array();
		$curl_content 		= PHP_SYSTEM_url_get_contents($url);
		$data['list'][0] 	= [
								[
									'url' 			=> PHP_string_between($curl_content,'<meta property="og:video"             content="','" />'),
									'format' 		=> 'mp4',
									'quality' 		=> 'HD',
									'size' 			=> PHP_file_size(Video($curl_content))
								],  
							];
		return [
			'title'				=> PHP_string_between($curl_content,'<meta property="og:title" content="','"/>'),
			'thumbnail'			=> PHP_string_between($curl_content,'<meta property="og:image"             content="','" />'),
			'source'			=> 'imgur',
			'list'				=> true,
			'data'				=> $data,
		];
	}
?>