<?php
/*
Script for: vmate.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 			  	= array();
		$curl_content 	  	= PHP_SYSTEM_url_get_contents($url);
		$data['video'][0] = [
								[
									'url' 			=> video_url($curl_content),
									'format' 		=> 'mp4',
									'quality' 		=> 'HD',
									'size' 			=> PHP_file_size(video_url($curl_content))
								],  
							];		 						
		return [
			'title'				=> Data_title($curl_content),
			'thumbnail'			=> Data_thumbnail($curl_content),
			'source'			=> 'vmate',
			'video'				=> true,
			'data'				=> $data,
			
		];
	}

    function Data_thumbnail($curl_content){
        preg_match('@"thumbnailUrl":"(.*?)"@si', $curl_content, $match);
        return $match[1];
    }	

	function video_url($curl_content){
		preg_match('@"contentUrl":"(.*?)"@si', $curl_content, $match);
        return $match[1];
	}

    function Data_title($curl_content){
        preg_match('@"name":"(.*?)"@si', $curl_content, $match);
        return $match[1];
    }	
?>