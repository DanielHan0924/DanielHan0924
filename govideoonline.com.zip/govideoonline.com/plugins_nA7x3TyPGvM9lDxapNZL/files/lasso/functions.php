<?php
/*
Script for: lassovideos.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 			= array();
        $curl_content 	= PHP_SYSTEM_url_get_contents($url);
		$Video_SD 		= Video_SD($curl_content);
		$Video_HD 		= Video_HD($curl_content);
		$data['video'][0] = [
								[
									'url' 			=> str_replace_url($Video_SD),
									'format' 		=> 'mp4',
									'quality' 		=> 'SD',
									'size' 			=> PHP_file_size(str_replace_url($Video_SD))
								],  
							];
		if(!empty($Video_HD)){
			$data['video'][1] = [
									[
										'url' 			=> str_replace_url($Video_HD),
										'format' 		=> 'mp4',
										'quality' 		=> 'HD',
										'size' 			=> PHP_file_size(str_replace_url($Video_HD))
									],  
								];
		}
		return [
			'title'				=> PHP_string_between($curl_content, '<meta property="og:title" content="', '" />'),,
			'thumbnail'			=> PHP_string_between($curl_content, '<meta property="og:image" content="', '" />'),
			'source'			=> 'lasso',
			'video'				=> true,
			'data'				=> $data,
		];
	} 

	function cleanStr($str){
		return html_entity_decode(strip_tags($str), ENT_QUOTES, 'UTF-8');
	}

	function str_replace_url($url){
		$data = str_replace('\/', '/', $url);
		//$data = str_replace(':/', ':/', $url);
		return $data;
	}	

	function Video_HD($curl_content){
        preg_match('@"hd_src":"(.*?)"@si', $curl_content, $match);
        return $match[1];
	}

	function Video_SD($curl_content){
		preg_match('@"sd_src_no_ratelimit":"(.*?)"@si', $curl_content, $match);
		return $match[1];
	}	
?>