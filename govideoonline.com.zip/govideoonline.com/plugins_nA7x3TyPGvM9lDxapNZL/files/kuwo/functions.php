<?php
/*
Script for: douban.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 				= array();
		$curl_content 		= PHP_SYSTEM_url_get_contents($url);
		$Url_video 			= PHP_string_between($curl_content,'src:"','"');
		$Url_video 			= str_replace('\u002F', '/', $Url_video);
		
		$Url_image 			= PHP_string_between($curl_content,'pic:"','"');
		$Url_image 			= str_replace('\u002F', '/', $Url_image);
		
		$data['video'][0] = [
								[
									'url' 			=> $Url_video,
									'format' 		=> 'mp4',
									'quality' 		=> 'HD',
									'size' 			=> PHP_file_size($Url_video)
								],  
							];
		return [
			'title'				=> PHP_string_between($curl_content,'<title data-n-head="true">','</title>'),
			'thumbnail'			=> $Url_image,
			'source'			=> 'douban',
			'video'				=> true,
			'data'				=> $data,
		];
	}

	 
?>