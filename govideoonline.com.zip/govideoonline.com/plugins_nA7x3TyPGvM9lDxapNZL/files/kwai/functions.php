<?php
/*
Script for: kwai.com
Author: Zhareiv
Update date: 24-07-2020
Copyright (c) 2020 Videoit. All rights reserved.
*/
	error_reporting(0);
	function Data_Host_Function($url){
		$data 			  	= array();
		$curl_content 		= PHP_SYSTEM_url_get_contents($url);
		$data['video'][0] = [
								[
									'url' 			=> PHP_string_between($curl_content, '"mp4Url":"', '"'),
									'format' 		=> 'mp4',
									'quality' 		=> 'HD',
									'size' 			=> PHP_file_size(PHP_string_between($curl_content, '"mp4Url":"', '"'))
								],  
							];
			
		return [
			'title'				=> PHP_string_between($curl_content, '"userName":"', '"'),
			'thumbnail'			=> PHP_string_between($curl_content, '<meta property="og:image" content="', '"/>'),
			'source'			=> 'Kwai',
			'video'				=> true,
			'data'				=> $data,
		];
	}

	
?>