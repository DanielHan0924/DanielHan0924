<?php
// tables
define('T_CONFIG', 'config');
define('T_MEDIA', 'platform_media');
define('T_SHARE', 'share_urls');
define('T_REPORT_LINK', 'report_link');
define('T_POST', 'post');
define('T_COMMENTS', 'comments');
define('T_DOWNLOAD', 'download_list');
 
?>