<?php
// +------------------------------------------------------------------------+
// | @author Zhareiv or csode and scode
// | Copyright (c) 2017 Zhareiv. All rights reserved.
// +------------------------------------------------------------------------+
date_default_timezone_set('UTC');
session_start();
require_once ('system/cache.php');
require_once ('system/tables.php');
require_once ('system/function_app.php');
require_once ('system/function_admin.php');
require_once ('system/function_security.php');



 