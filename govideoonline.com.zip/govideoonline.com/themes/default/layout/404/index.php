{{INCLUDE_HEADER}}
<div id="page" class="page">
	<section class="section_home">
		<div id="content_page">
			<div class="text_center_404">
				<br>
				<h2 class="text_h2_404">404</h2>
				<p class="text_p_404">{{LANG 404_desc}}</p>
			</div>
		</div>  
	</section>
</div>
{{INCLUDE_FOOTER}}