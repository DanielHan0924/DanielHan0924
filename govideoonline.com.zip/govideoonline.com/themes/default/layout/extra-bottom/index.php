<script type="text/javascript" src="{{CONFIG theme_url}}/js/script_code.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/js/adaptive-backgrounds.js"></script>
<script type="text/javascript">
	AdaptiveBackgrounds();
</script>