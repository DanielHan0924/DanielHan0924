<link type="text/css" rel="stylesheet" href="{{CONFIG theme_url}}/plugins/bootstrap/css/bootstrap.min.css?n=<?php echo time(); ?>">
<link type="text/css" rel="stylesheet" href="{{CONFIG theme_url}}/css/main.css?n=<?php echo time(); ?>">
<link type="text/css" rel="stylesheet" href="{{CONFIG theme_url}}/css/responsive.css?n=<?php echo time(); ?>">
<link type="text/css" rel="stylesheet" href="{{CONFIG theme_url}}/css/fontawesome.css?n=<?php echo time(); ?>">
<script type="text/javascript" src="{{CONFIG theme_url}}/js/jquery.min.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/js/jquery.form.min.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/bootstrap/js/bootstrap.min.js"></script>
<meta http-equiv='cache-control' content='no-cache'>
<meta http-equiv='expires' content='0'>
<meta http-equiv='pragma' content='no-cache'>