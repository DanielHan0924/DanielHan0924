<div class="panel_contenido_div_1">
    <a href="{{CONFIG site_url}}/eden/">
        <div class="<?php echo ($_GET['page'] == NULL)?'do_hi':''; ?> down_menu_asr_div">
            <div class="down_menu_asr_div_icon">
                <svg class="_color_1" viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                    <polyline points="9 22 9 12 15 12 15 22"></polyline>
                </svg>
            </div>
            <span>
                <?php echo $lang_admin->menu_2; ?>
            </span>
        </div>
    </a>
	<a href="{{CONFIG site_url}}/eden/plugins">
        <div class="<?php echo ($_GET['page'] == 'plugins')?'do_hi':''; ?> down_menu_asr_div">
            <div class="down_menu_asr_div_icon">
                <svg class="_color_1" viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"></line><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
            </div>
            <span>
               <?php echo $lang_admin->menu_3; ?>
            </span>
        </div>
    </a>
	<a href="{{CONFIG site_url}}/eden/articles">
        <div class="<?php echo ($_GET['page'] == 'articles')?'do_hi':''; ?> down_menu_asr_div">
            <div class="down_menu_asr_div_icon">
                <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
            </div>
            <span>
               <?php echo $lang_admin->menu_4; ?>
            </span>
        </div>
    </a>
	<a href="{{CONFIG site_url}}/eden/messages">
        <div class="<?php echo ($_GET['page'] == 'messages')?'do_hi':''; ?> down_menu_asr_div">
            <div class="down_menu_asr_div_icon">
                <svg class="_color_1" viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
            </div>
            <span>
                <?php echo $lang_admin->menu_5; ?>
            </span>
        </div>
    </a>
	<a href="{{CONFIG site_url}}/eden/script">
        <div class="<?php echo ($_GET['page'] == 'script')?'do_hi':''; ?> down_menu_asr_div">
            <div class="down_menu_asr_div_icon">
				<svg class="_color_1" viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>
            </div>
            <span>
                <?php echo $lang_admin->menu_6; ?>
            </span>
        </div>
    </a>	
	<a href="{{CONFIG site_url}}/eden/settings">
        <div class="<?php echo ($_GET['page'] == 'settings')?'do_hi':''; ?> down_menu_asr_div">
            <div class="down_menu_asr_div_icon">
                <svg class="_color_6" viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
            </div>
            <span>
                <?php echo $lang_admin->menu_7; ?>
            </span>
        </div>
    </a>
	<a href="{{CONFIG site_url}}/eden/logout">
        <div class="<?php echo ($_GET['page'] == 'logout')?'do_hi':''; ?> down_menu_asr_div">
            <div class="down_menu_asr_div_icon">
                <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
            </div>
            <span class="logout_css">
               <?php echo $lang_admin->menu_8; ?>
            </span>
        </div>
    </a>
</div>
