<header>
    <div class="index_div_logo">
        <a>
            <img class="index_img_logo" src="{{CONFIG theme_url}}/layout/template/eden_themes/images/logo.png" />
        </a>
    </div>
    <div class="index_menu_1">
        <ul class="index_menu_1_ul">
			<a href="{{CONFIG site_url}}" target="_blank">
				<li class="index_menu_bor">
					<?php echo $lang_admin->menu_1; ?>
				</li>
			</a>
        </ul>
    </div>
</header>
