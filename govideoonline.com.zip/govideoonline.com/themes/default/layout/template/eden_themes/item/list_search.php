<div class="search_box_drop">
	<div class="search_box_drop_div">
		<div class="search_box_drop_1">
			{{TITLE}}
		</div>
		<div class="search_box_drop_2">
			<a href="{{CONFIG site_url}}/eden/articles/?details=edit&id={{ID}}"><?php echo $lang_admin->gene_edit; ?></a>
		</div>
	</div>
</div>