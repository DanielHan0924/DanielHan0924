<div class="div_pro_wall">
    <div class="img_div_pro">
        <img src="{{ICON}}" />
    </div>
    <div class="caja_div_pro_wall_das">
        <div class="caja_div_pro_wall_das_1">
            <div class="progress my-3 circle" style="height: 6px;">
                <div class="progress-bar circle gd-primary" data-toggle="tooltip" title="" style="width: {{ROUND}}%;" data-original-title="100%"></div>
            </div>
            <span>{{ROUND}}%</span>
        </div>
        <div class="caja_div_pro_wall_das_2">
            <span class="span_ver_div_pro_1">{{TITLE}}</span>
            <div class="ver_div_pro_2"><a class="a_btn_bla" href="{{CONFIG site_url}}/eden/plugins/?details={{KEY_ID}}"><?php echo $lang_admin->Ver_plugin; ?></a></div>
        </div>
    </div>
</div>
