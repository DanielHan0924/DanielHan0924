<div class="index_footer">
    <!---->
    <div class="index_foot_sitemap">
        <div class="index_foot_sitemap_box_1">
            <div class="index_foot_sitemap_link">
                <img src="{{CONFIG theme_url}}/layout/template/eden_themes/images/logo_dev.png"/>
            </div>
        </div>
        <div class="index_foot_sitemap_box_2">
            <span class="index_foot_sitemap_box_t"><?php echo $lang_admin->Gene_dev; ?></span>
        </div>
    </div>
</div>
