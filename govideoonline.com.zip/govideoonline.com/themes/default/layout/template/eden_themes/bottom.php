<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/upload/jquery.knob.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/upload/jquery.ui.widget.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/upload/jquery.iframe-transport.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/upload/jquery.fileupload.js?n"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/upload/script.js"></script>
