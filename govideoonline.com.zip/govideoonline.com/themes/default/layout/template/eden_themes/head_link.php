<link type="text/css" rel="stylesheet" href="{{CONFIG theme_url}}/plugins/bootstrap/css/bootstrap.min.css?n=<?php echo time(); ?>">
<link type="text/css" rel="stylesheet" href="{{CONFIG theme_url}}/plugins/eden_style/main.css?n=<?php echo time(); ?>">
<link type="text/css" rel="stylesheet" href="{{CONFIG theme_url}}/plugins/eden_style/css_class.css?n=<?php echo time(); ?>">
<link type="text/css" rel="stylesheet" href="{{CONFIG theme_url}}/plugins/eden_style/checkbox.min.css?n=<?php echo time(); ?>">
<link type="text/css" rel="stylesheet" href="{{CONFIG theme_url}}/plugins/eden_style/upload.css?n=<?php echo time(); ?>">
<script type="text/javascript" src="{{CONFIG theme_url}}/js/jquery.min.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/js/jquery.form.min.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/bootstrap-tagsinput/src/bootstrap-tagsinput.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/eden_style/script.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/eden_style/select.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/eden_style/jquery.textarea_autosize.min.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/tinymce/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="{{CONFIG theme_url}}/plugins/chartJS/Chart.min.js"></script>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="pragma" content="no-cache">
<script type="text/javascript">
	var Delay_f5 = (function(){
		var timer = 0;
		return function(callback, ms){
			clearTimeout (timer);
			timer = setTimeout(callback, ms);
		};
	})();
</script>