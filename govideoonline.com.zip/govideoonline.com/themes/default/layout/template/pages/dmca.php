{{INCLUDE_HEADER}}
<?php
	$add_action->do_action('Hook_load_plugin_56');
?>
<div id="page" class="page">
	<section class="section_home">
		<div id="content_page">
			<div class="cl_contsct_box_div">
				{{CONTENT}}
			</div>
		</div>  
	</section>
</div>
{{INCLUDE_FOOTER}}
