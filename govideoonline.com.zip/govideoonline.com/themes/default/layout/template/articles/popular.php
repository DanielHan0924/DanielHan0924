<a href="{{CONFIG site_url}}/articles/post/{{LINK}}">
	<div class="wall_post_le_2_div">
		<div class="wall_post_le_2_div_img">
			<img src="{{IMAGE}}" />
		</div>
		<div class="wall_post_le_2_div_text_da">
			<p class="wall_post_le_2_div_text">
				{{TITLE}}
			</p>
		</div>
	</div>
</a> 