<?php
	$add_action->do_action('Hook_load_plugin_62');
?>
<div style="border-style:solid;border-width:thin;border-color:#dadce0;border-radius:8px;padding:40px 20px">
	<div style="text-align:center;    background: url({{CONFIG theme_url}}/img/image_meta.jpg) repeat 0 0;
    background-color: #fff;
    background-size: 100%; width: 100%; border-radius:8px;magin:12px;padding-top:3%">
	</div>
	<div style="font-family:'Google Sans',Roboto,RobotoDraft,Helvetica,Arial,sans-serif;border-bottom:thin solid #dadce0;color:rgba(0,0,0,0.87);line-height:32px;padding-bottom:24px;text-align:center;word-break:break-word">
		<br>
		<div style="font-size:24px">
		Hello {{USERNAME}}
		</div>
	</div>
	<br><br>
	<div style="font-family:Roboto-Regular,Helvetica,Arial,sans-serif;font-size:14px;color:rgba(0,0,0,0.87);line-height:20px;padding-top:20px;text-align:left">
		<br>
		{{MESSAGE}}
	</div>	
	<div style="padding-top:32px;text-align:center">
	</div>
	<br><br>
</div>
<?php
	$add_action->do_action('Hook_load_plugin_63');
?>