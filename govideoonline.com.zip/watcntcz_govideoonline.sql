-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 29, 2021 at 06:24 PM
-- Server version: 10.3.27-MariaDB-log-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `watcntcz_govideoonline`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_graphics`
--

CREATE TABLE `admin_graphics` (
  `graphicsID` int(11) NOT NULL,
  `look` date NOT NULL,
  `Visits` int(11) NOT NULL,
  `click` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `chat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `admin_graphics`
--

INSERT INTO `admin_graphics` (`graphicsID`, `look`, `Visits`, `click`, `user`, `chat`) VALUES
(1, '2021-01-29', 8, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `comments` text CHARACTER SET utf8 NOT NULL,
  `response` text CHARACTER SET utf8 NOT NULL,
  `key_comments` varchar(250) CHARACTER SET utf8 NOT NULL,
  `first_name` text CHARACTER SET utf8 NOT NULL,
  `last_name` text CHARACTER SET utf8 NOT NULL,
  `email` varchar(120) CHARACTER SET utf8 NOT NULL,
  `time` varchar(20) NOT NULL,
  `ip_user` varchar(20) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `name`, `value`) VALUES
(1, 'theme', 'default'),
(2, 'censored_words', ''),
(3, 'title', 'Govideoonline - Drive videos online'),
(4, 'name', 'Govideoonline'),
(5, 'image', 'png'),
(6, 'email_web', 'chuy@gmail.com'),
(7, 'description', 'Govideoonline Drive videos online  videos, Download  and save - Download Govideoonline Script PHP'),
(8, 'validation', 'off'),
(9, 'recaptcha', 'off'),
(10, 'recaptcha_key', ''),
(11, 'language', 'english'),
(12, 'terms', '&lt;h3&gt;&lt;strong&gt;Terms of use&lt;/strong&gt;&lt;/h3&gt;&lt;p&gt;&amp;nbsp;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;1.&lt;/strong&gt; Terms By accessing SharePlus hereinafter referred to as a website, you agree to comply with these Terms and Conditions of Website Use, all applicable laws and regulations and agree that you are responsible for compliance with applicable local laws.&lt;/p&gt;&lt;p&gt;If you do not agree with any of these terms, it is prohibited to use or access this site.&lt;/p&gt;&lt;p&gt;The materials contained on this site are protected by the applicable laws of copyright and trademarks.&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;2.&lt;/strong&gt; Use License Permission is granted to temporarily download a copy of the materials (information or software) on the website for personal and non-commercial use.&lt;/p&gt;&lt;p&gt;This is the granting of a license, not a transfer of title, and under this license you can not:&lt;/p&gt;&lt;p&gt;modify or copy the material;&lt;/p&gt;&lt;p&gt;use the material for any commercial purpose, or to show to the public (commercial or non-commercial);&lt;/p&gt;&lt;p&gt;attempt to modify or reverse engineer the system included in the website;&lt;/p&gt;&lt;p&gt;remove any copyright information or notes from the owner on the materials;&lt;/p&gt;&lt;p&gt;or transfer the material to another person or &quot;copy&quot; the material to another server.&lt;/p&gt;&lt;p&gt;This license will terminate automatically if you violate any of these restrictions and may be terminated by the website at any time.&lt;/p&gt;&lt;p&gt;Upon completion of the viewing of these materials or upon completion of this license, you must destroy any downloaded material in your possession, either in electronic or printed format.&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;3.&lt;/strong&gt; Exemption from Liability A.The materials on the website are provided &quot;as is&quot;.&lt;/p&gt;&lt;p&gt;The website makes no warranties, express or implied, and hereby denies and denies all other warranties, including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, intellectual property infringement or other breach of rights.&lt;/p&gt;&lt;p&gt;In addition, the website does not guarantee or make any representation with respect to the accuracy, probable results or reliability of the use of the materials on its Internet website or otherwise related to such materials or any site linked to this site. . B.We do not exercise or promote the infringement of copyright.&lt;/p&gt;&lt;p&gt;All videos on YouTube are the copyright of their respective owners and any copyright infringement resulting from their transfer to other websites such as Facebook, will be the responsibility of the user who performs such action.&lt;/p&gt;&lt;p&gt;We also do not store videos or other material on our servers, the links are cached and after 3 hours they are destroyed, even if the users have not made the download.&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;4.&lt;/strong&gt; Limitations In no case shall the website or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profits, or due to business interruption) arising from the use or inability to use the materials, even if the Website or an authorized representative of the website has been notified orally or in writing of the possibility of such damage.&lt;/p&gt;&lt;p&gt;Because some jurisdictions do not allow limitations on implied warranties, or limitations of liability for consequential or incidental damages, these limitations may not apply to you.&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;5.&lt;/strong&gt; Reviews and Errata The materials that appear on the website may include technical, typographical or photographic errors.&lt;br&gt;The website does not guarantee that any of the materials on its website are accurate, complete or current.&lt;br&gt;The website may make changes to the materials contained on its website at any time without prior notice.&lt;br&gt;The website does not commit, however, to update the materials.&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;6.&lt;/strong&gt; Links The website has not reviewed all the sites linked to its Internet website and is not responsible for the contents of such linked sites.&lt;br&gt;The inclusion of any link does not imply endorsement by the website.&lt;br&gt;The use of any linked website is at the risk of the user.&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;7.&lt;/strong&gt; Modifications to the Conditions of use of the Site The website may revise these terms of use at any time without prior notice.&lt;/p&gt;&lt;p&gt;By using this website, you are agreeing to be bound by the current version of these Terms and Conditions of Use.&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;8.&lt;/strong&gt; Law that governs us Any claim related to the website will be governed by the laws of the Republic of India without regard to its conflict of laws provisions.&lt;/p&gt;&lt;p&gt;General terms and conditions applicable to the use of a website.&lt;/p&gt;'),
(13, 'privacy-policy', '&lt;h3 style=&quot;text-align: left;&quot; data-mce-style=&quot;text-align: left;&quot;&gt;Privacy Policy&lt;/h3&gt;&lt;p&gt;What information do we collect and store?&lt;/p&gt;&lt;p&gt;We do not ask or store any type of user information We use cookies?&lt;/p&gt;&lt;p&gt;We use cookies eventually but on SSL secure protocol.&lt;/p&gt;&lt;p&gt;Sell ​​or deliver information to third parties? We do not sell or negotiate or transfer your personal identification to third parties.&lt;/p&gt;&lt;p&gt;It does not include business partners that intervene in the operation of the website, or serve you, since these third parties have agreed to keep this information confidential.&lt;/p&gt;&lt;p&gt;We will release your information when we believe it is appropriate to abide by the law, strengthen our policies, or protect our and others rights, property, or safety. However, visitor information is never provided to third parties for marketing, advertising or other uses.&lt;/p&gt;&lt;p&gt;Privacy Policies only on the Internet These privacy policies apply only to the information collected on our website.&lt;/p&gt;&lt;p&gt;Your consent By browsing and using the services of our website, you adhere to our privacy policy.&lt;/p&gt;&lt;p&gt;Changes to our Privacy Policies If we make changes to our privacy policies, we will update those changes on this page.&lt;/p&gt;&lt;p&gt;Contact Us If you have any questions about this privacy policy, please inform us using this form.&lt;/p&gt;'),
(14, 'dmca', '&lt;h2&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;Copyright (DMCA)&lt;/span&gt;&lt;/h2&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;Videoit respects copyright of all works, and doesn’t allow users to use others’ videos for anything that is against the copyright protection terms and conditions. Any kind of copyright infringement is not allowed on Videoit.zhareiv.com, and we blacklist all the copyrighted contents from displaying in the search results.&lt;/p&gt;&lt;p&gt;Videoit complies with the Digital Millennium Copyright Act (DMCA) and promptly suspends Content from access when properly notified.&lt;/p&gt;&lt;p&gt;To file a copyright infringement notification with Videoit, you will need to send an email that includes substantially the information required by and stated in Section 512(c)(3) of the Digital Millennium Copyright Act.&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;strong&gt;Required information:&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;1. Identify yourself as either: a) The owner of a copyrighted work(s), or b) A person &quot;authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.&quot; Include a physical or electronic signature.&lt;/p&gt;&lt;p&gt;2. Identify the copyrighted work claimed to have been infringed.&lt;/p&gt;&lt;p&gt;3. Identify the Content that is claimed to be infringing or to be the subject of the infringing activity and that is to be suspended or access to which is to be disabled, as well as information reasonably sufficient to permit Shareplus to locate the Content. Providing URLs are required to help us locate the Content.&lt;/p&gt;&lt;p&gt;4. Provide contact information that is reasonably sufficient to permit us to contact you, such as an address, telephone number, and a valid email address.&lt;/p&gt;&lt;p&gt;5. State that you have a good faith belief that use of the Content in the manner complained of is not authorized by the copyright owner, its agents, or the law.&lt;/p&gt;&lt;p&gt;6. State that the information in the notification is accurate and under penalty of perjury the complaining party is authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;Upon receipt of valid notification, as required by law, we will suspend access to Content from our website.&lt;/p&gt;&lt;p&gt;&lt;strong&gt;  &lt;/strong&gt;&lt;/p&gt;&lt;p&gt;If you have any questions, please contact us at&amp;nbsp;&lt;a href=&quot;mailto:videoit@zhareiv.com&quot; data-mce-href=&quot;mailto:videoit@zhareiv.com&quot;&gt;user@mail.com&lt;/a&gt;&lt;/p&gt;'),
(15, 'page', ''),
(16, 'facebook', ''),
(17, 'twitter', ''),
(18, 'blog', 'off'),
(19, 'seo_link', 'on'),
(20, 'contsct', 'on'),
(21, 'ads', 'off'),
(22, 'api', 'off'),
(23, 'Languages_panel', 'en'),
(24, 'email', 'yulia.sukhoruchko@gmail.com'),
(25, 'password', '7408d5d486d4e3bb421ee711aa028c0c9b9273ec'),
(26, 'smtp_host', ''),
(27, 'smtp_username', ''),
(28, 'smtp_password', ''),
(29, 'smtp_encryption', 'TLS'),
(30, 'smtp_port', ''),
(31, 'verfiti_login', 'ki37b87u3q1h3afaikxio9sq5kbkqk'),
(32, 'note', ''),
(33, 'keyword', ''),
(34, 'ads_one', ''),
(35, 'ads_two', ''),
(36, 'ads_three', ''),
(37, 'add_tag_ad_1', ''),
(38, 'add_tag_ad_2', ''),
(39, 'add_tag_ad_3', ''),
(40, 'add_tag_ad_4', ''),
(41, 'add_tag_ad_5', ''),
(42, 'ads_four', '');

-- --------------------------------------------------------

--
-- Table structure for table `download_list`
--

CREATE TABLE `download_list` (
  `id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `video` varchar(255) CHARACTER SET utf8 NOT NULL,
  `audio` varchar(255) CHARACTER SET utf8 NOT NULL,
  `type_file` varchar(255) NOT NULL,
  `time` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `platform_media`
--

CREATE TABLE `platform_media` (
  `id` int(11) NOT NULL,
  `key_plugin` varchar(11) NOT NULL,
  `platform` varchar(255) CHARACTER SET utf8 NOT NULL,
  `url` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `title_content` varchar(300) CHARACTER SET utf8 NOT NULL,
  `description_content` varchar(300) CHARACTER SET utf8 NOT NULL,
  `keywords_content` varchar(300) CHARACTER SET utf8 NOT NULL,
  `platform_content` text CHARACTER SET utf8 NOT NULL,
  `visits` int(120) NOT NULL DEFAULT 0,
  `Data_Update` text CHARACTER SET utf8 NOT NULL,
  `version` varchar(255) NOT NULL,
  `Author` varchar(120) CHARACTER SET utf8 NOT NULL,
  `icon` text CHARACTER SET utf8 NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `url_line` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `platform_media`
--

INSERT INTO `platform_media` (`id`, `key_plugin`, `platform`, `url`, `title_content`, `description_content`, `keywords_content`, `platform_content`, `visits`, `Data_Update`, `version`, `Author`, `icon`, `active`, `url_line`) VALUES
(3, '12A', 'ok', 'ok-videos-downloader', 'Ok.ru Video Downloader', 'Ok.ru Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.1', 'Zhareiv', './upload/icons/ok_icon.png', 1, '\"url_line\":\"/ok.ru\\/video\\/([a-z1-9.-_]+)/\";'),
(4, '32A', 'douban', 'douban-videos-downloader', 'Douban Video Downloader', 'Douban Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/douban_icon.png', 1, '\"url_line\":\"/movie.douban.com\\/([^&]+)/\";'),
(5, '25A', 'IMDB', 'imdb-videos-downloader', 'IMDB Video Downloader', 'IMDB Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/imdb_icon.png', 1, '\"url_line\":\"/imdb.com\\/([^&]+)/\"; \"url_line\":\"/m.imdb.com\\/([^&]+)/\";'),
(6, '9A', 'imgur', 'imgur-videos-downloader', 'imgur images & Video Downloader', 'imgur images & Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.4', 'zhareiv', './upload/icons/imgur_icon.png', 1, '\"url_line\":\"/imgur.com\\/gallery\\/([a-z1-9.-_]+)/\";'),
(7, '33A', 'ESPN', 'espn-videos-downloader', 'ESPN Video Downloader', 'ESPN Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/espn_icon.png', 1, '\"url_line\":\"/espn.com.mx\\/([^&]+)/\"; \"url_line\":\"/espn.com\\/([^&]+)/\"; \"url_line\":\"/espn.in\\/([^&]+)/\"; \"url_line\":\"/africa.espn.com\\/([^&]+)/\";'),
(8, '19A', 'kuwo', 'kuwo-videos-downloader', 'Kuwo Video Downloader', 'Kuwo Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/kuwo_icon.png', 1, '\"url_line\":\"/bd.kuwo.cn\\/([^&]+)/\";'),
(9, '26A', 'izlesene', 'izlesene-videos-downloader', 'izlesene Video Downloader', 'izlesene Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/izlesene_icon.png', 1, '\"url_line\":\"/izlesene.com\\/video\\/([^&]+)/\";'),
(10, '35A', 'Kwai', 'kwai-videos-downloader', 'Kwai Video Downloader', 'Kwai Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/kwai_icon.png', 1, '\"url_line\":\"/kw.ai\\/([a-z1-9.-_]+)/\";'),
(11, '15A', 'lasso', 'lasso-videos-downloader', 'lasso Video Downloader', 'lasso Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/lasso_icon.png', 1, '\"url_line\":\"/lassovideos.com\\/video\\/([^&]+)/\"; \"url_line\":\"/lassovideos.com\\/([^&]+)/\";'),
(12, '30A', 'IFeng', 'IFeng-videos-downloader', 'IFeng Video Downloader', 'IFeng Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/ifeng_icon.png', 1, '\"url_line\":\"/ent.ifeng.com\\/([^&]+)/\";'),
(13, '27A', 'Krcom', 'krcom-videos-downloader', 'Krcom Video Downloader', 'Krcom Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'Zhareiv', './upload/icons/krcom_icon.png', 1, '\"url_line\":\"/krcom.ch\\/([^&]+)/\";'),
(14, '2A', 'FaceBook', 'facebook-videos-downloader', 'FaceBook Video Downloader', 'FaceBook Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 2, '29-10-2020', '1.9', 'zhareiv', './upload/icons/facebook_icon.png', 1, '\"url_line\":\"/facebook.com\\/watch\\/(.+)v=([a-z1-9.-_]+)/\"; \"url_line\":\"/facebook.com\\/watch\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/fb.watch\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/facebook.com\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/m.facebook.com\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/web.facebook.com\\/([a-z1-9.-_]+)/\";'),
(15, '29A', 'linkedin', 'linkedin-videos-downloader', 'linkedin Video Downloader', 'linkedin Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/linkedin_icon.png', 1, '\"url_line\":\"/linkedin.com\\/([^&]+)/\";'),
(16, '11A', 'Pinterest', 'pinterest-videos-downloader', 'Pinterest Video Downloader', 'Pinterest Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.6', 'zhareiv', './upload/icons/pinterest_icon.png', 1, '\"url_line\":\"/pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.com.mx\\/pin\\/([^&]+)/\"; \"url_line\":\"/gr.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/in.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.ie\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.it\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.ch\\/pin\\/([^&]+)/\"; \"url_line\":\"/cz.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/id.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.es\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.ca\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.co.uk\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.ru\\/pin\\/([^&]+)/\"; \"url_line\":\"/nl.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/br.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/no.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/tr.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.com.au\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.at\\/pin\\/([^&]+)/\"; \"url_line\":\"/pl.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.fr\\/pin\\/([^&]+)/\"; \"url_line\":\"/ro.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.de\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.dk\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.nz\\/pin\\/([^&]+)/\"; \"url_line\":\"/fi.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/hu.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.jp\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.pt\\/pin\\/([^&]+)/\"; \"url_line\":\"/ar.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.co.kr\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.se\\/pin\\/([^&]+)/\"; \"url_line\":\"/sk.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.cl\\/pin\\/([^&]+)/\"; \"url_line\":\"/co.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/za.pinterest.com\\/pin\\/([^&]+)/\"; \"url_line\":\"/pinterest.ph\\/pin\\/([^&]+)/\"; \"url_line\":\"/pin.it\\/([^&]+)/\";'),
(17, '18A', 'Mashable', 'mashable-videos-downloader', 'Mashable Video Downloader', 'Mashable Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/mashable_icon.png', 1, '\"url_line\":\"/mashable.com\\/([^&]+)/\";'),
(18, '17A', 'likee', 'likee-videos-downloader', 'Likee Video Downloader', 'Likee Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '2-11-2020', '1.2', 'Zhareiv', './upload/icons/likee_icon.png', 1, '\"url_line\":\"/mobile.like-video.com\\/s\\/([a-z1-9.-_]+)/\" \"url_line\":\"/likee.video\\/([a-z1-9.-_]+)/\" \"url_line\":\"/like.video\\/([a-z1-9.-_]+)/\";'),
(19, '7A', 'Liveleak', 'liveleak-videos-downloader', 'Liveleak Video Downloader', 'Liveleak Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.4', 'zhareiv', './upload/icons/liveleak_icon.png', 1, '\"url_line\":\"/liveleak.com\\/([a-z1-9.-_]+)/\";'),
(20, '20A', 'quanmin', 'quanmin-videos-downloader', 'Quanmin Video Downloader', 'Quanmin Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'Zhareiv', './upload/icons/quanmin_icon.png', 1, '\"url_line\":\"/quanmin.([^&]+).com\\/([a-z1-9.-_]+)/\";'),
(21, '14A', 'tumblr', 'tumblr-videos-downloader', 'tumblr Video Downloader', 'tumblr Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.5', 'zhareiv', './upload/icons/tumblr_icon.png', 1, '\"url_line\":\"/tumblr.com\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/line_tumblr.tumblr.com\\/post\\/([a-z1-9.-_]+)/\";'),
(22, '34A', 'PlayTube', 'playtube-videos-downloader', 'PlayTube Video Downloader', 'PlayTube Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/playtube_icon.png', 1, '\"url_line\":\"/playtubescript.com\\/watch\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/playtubescript.com\\/embed\\/([a-z1-9.-_]+)/\";'),
(23, '21A', 'Ted', 'ted-videos-downloader', 'Ted Video Downloader', 'Ted Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'Zhareiv', './upload/icons/ted_icon.png', 1, '\"url_line\":\"/ted.com\\/talks\\/([a-z1-9.-_]+)/\";'),
(24, '13A', 'reddit', 'reddit-videos-downloader', 'Reddit Video Downloader', 'Reddit Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'Zhareiv', './upload/icons/reddit_icon.png', 1, '\"url_line\":\"/reddit.com\\/r\\/([a-z1-9.-_]+)\\/comments\\/([a-z1-9.-_]+)\\/([a-z1-9.-_]+)/\";'),
(25, '28A', 'vmate', 'vmate-videos-downloader', 'vmate Video Downloader', 'vmate Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 4, '24-07-2020', '1.0', 'zhareiv', './upload/icons/vmate_icon.png', 1, '\"url_line\":\"/s.vmate.com\\/([^&]+)/\"; \"url_line\":\"/s.vmate.in\\/([^&]+)/\";'),
(26, '4A', 'vimeo', 'vimeo-videos-downloader', 'Vimeo Video Downloader', 'Vimeo Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.4', 'zhareiv', './upload/icons/vimeo_icon.png', 1, '\"url_line\":\"/vimeo.com\\/([a-z1-9.-_]+)/\";'),
(27, '8A', 'TikTok', 'tiktok-videos-downloader', 'TikTok Video Downloader', 'TikTok Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 2, '01-11-2020', '2.0', 'zhareiv', './upload/icons/tiktok_icon.png', 1, '\"url_line\":\"/vt.tiktok.com\\/([^&]+)/\"; \"url_line\":\"/m.tiktok.com\\/v\\/([^&]+)/\"; \"url_line\":\"/vm.tiktok.com\\/([^&]+)/\"; \"url_line\":\"/tiktok.com\\/share\\/video\\/([^&]+)/\"; \"url_line\":\"/tiktok.com\\/([a-z1-9.-_]+)\\/video\\/([^&]+)/\";'),
(28, '6A', 'vk', 'vk-videos-downloader', 'VK Video Downloader', 'VK Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.1', 'Zhareiv', './upload/icons/vk_icon.png', 1, '\"url_line\":\"/vk.com\\/video-([a-z1-9.-_]+)/\"; \"url_line\":\"/vk.com\\/video([a-z1-9.-_]+)/\";'),
(29, '22A', 'WWE', 'wwe-videos-downloader', 'WWE Video Downloader', 'WWE Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.4', 'zhareiv', './upload/icons/wwe_icon.png', 1, '\"url_line\":\"/wwe.com\\/videos\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/de.wwe.com\\/videos\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/espanol.wwe.com\\/videos\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/arabic.wwe.com\\/videos\\/([a-z1-9.-_]+)/\";'),
(30, '23A', '9gag', '9gag-videos-downloader', '9GAG Video Downloader', '9GAG Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/9gag_icon.png', 1, '\"url_line\":\"/9gag.com\\/([^&]+)/\";'),
(31, '24A', 'Aktualne', 'aktualne-videos-downloader', 'Aktualne Video Downloader', 'Aktualne Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'zhareiv', './upload/icons/aktualne_icon.png', 1, '\"url_line\":\"/video.aktualne.cz\\/([^&]+)/\"; \"url_line\":\"/sport.aktualne.cz\\/([^&]+)/\"; \"url_line\":\"/zpravy.aktualne.cz\\/([^&]+)/\";'),
(32, '3A', 'Dailymotion', 'dailymotion-videos-downloader', 'Dailymotion Video Downloader', 'Dailymotion Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '16-10-2020', '1.7', 'zhareiv', './upload/icons/dailymotion_icon.png', 1, '\"url_line\":\"/dailymotion.com\\/video\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/dai.ly\\/([a-z1-9.-_]+)/\";'),
(33, '31A', 'Break', 'Break-videos-downloader', 'Break Video Downloader', 'Break Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'Zhareiv', './upload/icons/break_icon.png', 1, '\"url_line\":\"/break.com\\/([a-z1-9.-_]+)/\";'),
(34, '16A', 'Buzzfeed', 'buzzfeed-videos-downloader', 'Buzzfeed Video Downloader', 'Buzzfeed Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.0', 'Zhareiv', './upload/icons/buzzfeed_icon.png', 1, '\"url_line\":\"/buzzfeed.com\\/([^&]+)/\";'),
(35, '1A', 'YouTube', 'youtube-videos-downloader', 'Youtube Video Downloader', 'Youtube Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 1, '09-10-2020', '2.6', 'zhareiv', './upload/icons/youtube_icon.png', 1, '\"url_line\":\"/youtube.com(.+)v=([^&]+)/\"; \"url_line\":\"/m.youtube.com(.+)v=([^&]+)/\"; \"url_line\":\"/youtu.be\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/youtube.com\\/embed\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/youtube.com\\/shorts\\/([a-z1-9.-_]+)/\";'),
(36, '5A', 'Twitter', 'twitter-videos-downloader', 'Twitter Video Downloader', 'Twitter Video Downloader', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.1', 'zhareiv', './upload/icons/twitter_icon.png', 1, '\"url_line\":\"/twitter.com\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/mobile.twitter.com\\/([a-z1-9.-_]+)/\";'),
(37, '10A', 'Instagram', 'instagram-videos-downloader', 'Instagram video downloader and stories', 'Instagram video downloader and stories', '', '&lt;h3 data-mce-style=&quot;text-align: center;&quot; style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color: rgb(255, 102, 0);&quot; data-mce-style=&quot;color: #ff6600;&quot;&gt;Oops&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;,&lt;/span&gt; &lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;there is no content on this page.&lt;/strong&gt;&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: rgb(0, 0, 0);&quot; data-mce-style=&quot;color: #000000;&quot;&gt;&lt;strong&gt;To add content to this page, please&lt;/strong&gt;&lt;/span&gt; &lt;a data-mce-href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot; href=&quot;https://192.168.1.70/shareplus_demo/script/admin/plugins&quot;&gt;click here.&lt;/a&gt;&lt;/h3&gt;', 0, '24-07-2020', '1.4', 'Zhareiv', './upload/icons/instagram_icon.png', 1, '\"url_line\":\"/instagram.com\\/p\\/([a-z1-9.-_]+)/\"; \"url_line\":\"/instagram.com\\/stories\\/([a-z1-9.-_]+)/\";');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL,
  `title` varchar(120) NOT NULL,
  `description` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `category` varchar(200) NOT NULL,
  `tags` text NOT NULL,
  `views` varchar(120) NOT NULL,
  `time` varchar(20) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `report_link`
--

CREATE TABLE `report_link` (
  `id` int(11) NOT NULL,
  `report_link` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `platform` varchar(50) NOT NULL,
  `time` int(11) NOT NULL,
  `ip_user` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `share_urls`
--

CREATE TABLE `share_urls` (
  `id` int(11) NOT NULL,
  `id_url` varchar(120) CHARACTER SET utf8 NOT NULL,
  `url` varchar(120) CHARACTER SET utf8 NOT NULL,
  `platform` varchar(11) NOT NULL,
  `ip_user` varchar(120) CHARACTER SET utf8 NOT NULL,
  `views` varchar(11) NOT NULL,
  `time` varchar(11) NOT NULL,
  `facebook` tinyint(255) NOT NULL,
  `twitter` tinyint(255) NOT NULL,
  `whatsapp` tinyint(255) NOT NULL,
  `vk` tinyint(255) NOT NULL,
  `telegram` tinyint(255) NOT NULL,
  `discord` tinyint(255) NOT NULL,
  `viber` tinyint(255) NOT NULL,
  `other` tinyint(255) NOT NULL,
  `downloads` tinyint(255) NOT NULL,
  `privacy` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `share_urls`
--

INSERT INTO `share_urls` (`id`, `id_url`, `url`, `platform`, `ip_user`, `views`, `time`, `facebook`, `twitter`, `whatsapp`, `vk`, `telegram`, `discord`, `viber`, `other`, `downloads`, `privacy`) VALUES
(1, 'cGwGSHjONbl3gWN', 'https://www.youtube.com/watch?v=ZkalEnH7xqw', 'youtube', '162.213.251.40', '0', '1611954770', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 'Dv9G3guIfJEGJpB', 'https://www.youtube.com/watch?v=ZkalEnH7xqw', 'youtube', '162.213.251.40', '0', '1611955035', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 'CzJSSQQiEbHolIN', 'https://youtu.be/KWbREKt8qL8', 'youtube', '162.213.251.40', '0', '1611955975', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 'd45ee4V4kMQEd6m', 'https://youtu.be/KWbREKt8qL8', 'youtube', '162.213.251.40', '0', '1611956247', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 'In5f7uamvKgWz8W', 'https://twitter.com/MusicVideoHype/status/1216837555376861189?s=09', 'twitter', '162.213.251.40', '0', '1611956377', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(6, 'WK2hIqbdXBimC2t', 'https://vm.tiktok.com/ZMJomk5wT/', 'tiktok', '162.213.251.40', '0', '1611958511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(7, 'qdlqer79i36jLVo', 'https://vm.tiktok.com/ZMJomk5wT/', 'tiktok', '162.213.251.40', '0', '1611958569', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(8, 'C8uWi1LXmhJoQdy', 'https://youtu.be/KWbREKt8qL8', 'youtube', '162.213.251.40', '0', '1611962412', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_graphics`
--
ALTER TABLE `admin_graphics`
  ADD PRIMARY KEY (`graphicsID`) USING BTREE;

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `name` (`name`) USING BTREE,
  ADD KEY `value` (`value`(255)) USING BTREE;

--
-- Indexes for table `download_list`
--
ALTER TABLE `download_list`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `platform_media`
--
ALTER TABLE `platform_media`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `report_link`
--
ALTER TABLE `report_link`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `share_urls`
--
ALTER TABLE `share_urls`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_graphics`
--
ALTER TABLE `admin_graphics`
  MODIFY `graphicsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `download_list`
--
ALTER TABLE `download_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `platform_media`
--
ALTER TABLE `platform_media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_link`
--
ALTER TABLE `report_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `share_urls`
--
ALTER TABLE `share_urls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
