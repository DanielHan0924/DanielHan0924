<?php
    if (isset($_POST['inputPhone'])) {

        $params='{"phone_numbers":[';

        $row_data = explode(',', $_POST['inputPhone']);
        $countPhonenumber = count($row_data);
        $index = 0;
        foreach($row_data as $phonenumber)
        {
            $index++;
            if ($index == $countPhonenumber) {
                $params.='"+'.trim($phonenumber).'"';
            } else {
                $params.='"+'.trim($phonenumber).'", ';
            }
        }

        $params.= ']}';

        $url = 'https://api.telnyx.com/v2/portability_checks';
        // $params='{"phone_numbers":["+07702825908","+38765396462","+'.$_POST['exampleInputPhone1'].'"]}';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        // curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER,
            array('Content-Type:application/json', 'Accept: application/json', 'Authorization: Bearer KEY017703814AC4E91E6F085BA525FA438D_U14aCHXwizGU1TxuqJYcxZ')
        );
        # Return response instead of printing.
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        $result = curl_exec($ch);
        $result = json_decode($result);
        // var_dump($result);die();

        if(curl_error($ch)) {
            $response = array('status' => 'curlfailed');
            echo json_encode($response); return;
        }
        curl_close($ch);
        
        $response = array('status' => 'success','object'=>$result);
        echo json_encode($response); return;

    } else {
        $response = array('status' => 'postfailed');
        echo json_encode($response); return;
    }

?>

