<?php 
// require_once('getCountryCode.php');

// $countryCode = ip_info("Visitor", "Country Code");

if($countryCode != NULL){

	switch ($countryCode) {
		case 'GB':
			# carousels for GB
?>		
            <h3 class="padding-top10">The best Roulette casinos for <span class="font500">UK</span> players</h3>
            <p class="lead">Updated <script>document.write(currentmonth);</script>'</p>
            <div id="boxes-wrap">
    
            <!-- box 1 -->
            <div class="box-wrap">
            
                <div class="box-left main-box"> 
            
                <div class="l-box-1"> 
            
                    <div class="box-holder" style="background-color: #005955">
            
                    <div class="box-number-holder">
                        <span class="no">1</span>
                    </div> 
            
                    <div class="box-img-holder">
                        <a href="bet365-online-casino-review.html"><img class="bet365-logo-box-sprite" alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJ8AAAAuAQMAAAAMQ1lzAAAAA1BMVEX///+nxBvIAAAAAXRSTlMAQObYZgAAABFJREFUeNpjYBgFo2AUDG0AAAPGAAE/NOQyAAAAAElFTkSuQmCC"></a>
                    </div>
            
                </div>
            
                </div>
            
                <div class="inner-half">
                    <div class="l-box-2 v-center"> 
            
                    <div class="box-offer">
                        <span class="small"> 100% Up To</span>
                        <span class="box-amount"> &pound;100 </span>
                        <span class="small"> welcome bonus </span>
                    </div>
            
                    </div>
                    <div class="l-box-3 cb v-center"> 
                    <ul class="box-features mobile">
                        <li>Live Roulette</li>
                        <li>&pound;100 match bonus</li>
                        <li>75x wagering</li>
                    </ul>
            
                    <a href="https://casino.bet365.com/dl/dl.aspx?page=openingbonus&affiliate=365_388398" rel="nofollow" target="_blank" title="Play online at bet365" class="claim none-mobile">
                        <h3>Claim Bonus</h3>
                        <span> at bet365 <br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></span>
                    </a>
            
                    </div>
                </div>
            
                </div>
            
                <div class="box-right main-box"> 
            
                <div class="inner-half">
                    <div class="r-box-s v-center"> 
                    <div class="rating-wrap">
            
                        <div class="star-ratings-css">
                        <div class="star-ratings-css-top" style="width: 92%"><span>★</span><span>★</span><span>★</span><span>★</span><span>★</span></div>
                        <div class="star-ratings-css-bottom"><span>★</span><span>★</span><span>★</span><span>★</span><span>★</span></div>
                        </div>
            
                        <span class="no-of-users">92% rating</span>
            
                        <span class="box-review-link">
                        <a href="bet365-online-casino-review.html" title="bet365 casino review">Expert review</a></span>
            
                    </div> <!-- rating ended -->
                    </div>
                    <div class="r-box-s fs v-center"> 
            
                    <a href="https://casino.bet365.com/dl/dl.aspx?page=openingbonus&affiliate=365_388398" rel="nofollow" target="_blank" title="Play online at bet365" class="claim mobile">
                    <h3>Claim Bonus</h3>
                    <span> at bet365 <br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></span>
                    </a>
            
                    <ul class="box-features none-mobile">
                        <li>Great Live Roulette</li>
                        <li>&pound;100 match bonus</li>
                        <li>75x wagering</li>
                    </ul>
                    </div>
                </div>
                <div class="r-box-s last"> 
                    <div class="highlight v-center">
                    <i><img class="img-responsive" src="assets/images/icon-live-dealer.png"></i>
                    <span class="desc">Great Live Casino Tables</span>
                    </div>
                </div>
            
                </div>
            
                <div class="box-bottom"><strong>#ad 18+ BeGambleAware.org</strong> New Casino customers only.
            Deposit min. &pound;10. Applies to first deposit to Casino only. Max. bonus &pound;100. 20x wagering (game weighting, table coverage and max. bet rules apply) on deposit and bonus to make the bonus balance withdrawable. Time limits and T&Cs apply.</div>
            
            </div>
            
            <!-- box 2 -->
            <div class="box-wrap">
            
                <div class="box-left main-box"> 
            
                <div class="l-box-1"> 
            
                    <div class="box-holder" style="background-color: black">
            
                    <div class="box-number-holder">
                        <span class="no">2</span>
                    </div> 
            
                    <div class="box-img-holder">
                        <a href="https://bit.ly/2sA7z4B" rel="nofollow" target="_blank" title="Play at Videoslots casino"><img class="vs-logo-box-sprite" alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJ8AAAAuAQMAAAAMQ1lzAAAAA1BMVEX///+nxBvIAAAAAXRSTlMAQObYZgAAABFJREFUeNpjYBgFo2AUDG0AAAPGAAE/NOQyAAAAAElFTkSuQmCC"></a>
                    </div>
            
                </div>
            
                </div>
            
                <div class="inner-half">
                    <div class="l-box-2 v-center"> 
            
                    <div class="box-offer">
                        <span class="small"> 100% up to</span>
                        <span class="box-amount"> &pound;200 </span>
                        <span class="small"> + Extra Spins </span>
                    </div>
            
                    </div>
                    <div class="l-box-3 cb v-center"> 
                    <ul class="box-features mobile">
                        <li>Over 30 Roulettes</li>
                        <li>&pound;110 bonus</li>
                        <li>11 free spins</li>
                    </ul>
            
                    <a href="https://bit.ly/2sA7z4B" rel="nofollow" target="_blank" title="Play at Videoslots casino" class="claim none-mobile">
                        <h3>Claim Bonus</h3>
                        <span> at Videoslots <br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></span>
                    </a>
            
                    </div>
                </div>
            
                </div>
            
                <div class="box-right main-box"> 
            
                <div class="inner-half">
                    <div class="r-box-s v-center"> 
                    <div class="rating-wrap">
            
                        <div class="star-ratings-css">
                        <div class="star-ratings-css-top" style="width: 92%"><span>★</span><span>★</span><span>★</span><span>★</span><span>★</span></div>
                        <div class="star-ratings-css-bottom"><span>★</span><span>★</span><span>★</span><span>★</span><span>★</span></div>
                        </div>
            
                        <span class="no-of-users">92% rating</span>
            
                        <span class="box-review-link">
                        <a href="videoslots-casino-review.html" title="Videoslots casino review">Expert review</a></span>
            
                    </div>
                    </div>
                    <div class="r-box-s fs v-center"> 
            
                    <a href="https://bit.ly/2sA7z4B" rel="nofollow" target="_blank" title="Play at Videoslots casino" class="claim mobile">
                    <h3>Claim Bonus</h3>
                    <span> at Videoslots <br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></span>
                    </a>
            
                    <ul class="box-features none-mobile">
                        <li>Over 30 Roulettes</li>
                        <li>&pound;100 + 10 bonus</li>
                        <li>+11 free spins</li>
                    </ul>
                    </div>
                </div>
            
                <div class="r-box-s last"> 
                    <div class="highlight v-center">
                    <i><img class="img-responsive" src="assets/images/icon-chips.png"></i>
                    <span class="desc">34 Roulette games</span>
                    </div>
                </div>
            
                </div>
            
                <div class="box-bottom"><strong>#ad 18+ BeGambleAware.org</strong> New Customers Only. Min &pound;20 deposit. Max bonus &pound;200. Wagering 35x bonus. No max cash out on deposit offers. When playing with bonus funds, max bet is &pound;5. Welcome bonus excluded for deposits with Skrill/Neteller T&Cs apply.</div>
            
            </div>
            </div>

<?php
			break;
		case 'US':
			# carousels for US
?>
            <h3 class="padding-top10">The best Roulette casinos for <span class="font500">US</span> players</h3>
            <p class="lead">Updated '.$currentMonth.'</p>
            <div id="boxes-wrap">
                <!-- box 1 -->
                <div class="box-wrap">

                    <div class="box-left main-box"> 

                    <div class="l-box-1"> 

                        <div class="box-holder" style="background-color: #1e2a32">

                        <div class="box-number-holder">
                            <span class="no">1</span>
                        </div> 

                        <div class="box-img-holder">
                            <a href="https://bit.ly/bovada-bitcoin-2020" rel="nofollow" target="_blank" title="Play at Bovada"><img class="bov-logo-box-sprite" alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJ8AAAAuAQMAAAAMQ1lzAAAAA1BMVEX///+nxBvIAAAAAXRSTlMAQObYZgAAABFJREFUeNpjYBgFo2AUDG0AAAPGAAE/NOQyAAAAAElFTkSuQmCC"></a>
                        </div>

                        </div>

                    </div>

                    <div class="inner-half">
                        <div class="l-box-2 v-center"> 

                        <div class="box-offer">
                            <span class="small"> 100% up to</span>
                            <span class="box-amount"> &dollar;1,000 </span>
                            <span class="small"> x3 bonuses </span>
                        </div>

                        </div>
                        <div class="l-box-3 cb v-center"> 
                        <ul class="box-features mobile">
                            <li>&dollar;3,000 bonuses</li>
                            <li>25x wagering</li>
                            <li>Sports &amp; Poker</li>
                        </ul>

                        <a href="https://bit.ly/bovada-bitcoin-2020" rel="nofollow" target="_blank" title="Play at Bovada" class="claim none-mobile">
                            <h3>Claim Bonus</h3>
                            <span> at Bovada <br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></span>
                        </a>

                        </div>
                    </div>

                    </div>

                    <div class="box-right main-box"> 

                    <div class="inner-half">
                        <div class="r-box-s v-center"> 
                        <div class="rating-wrap">

                            <div class="star-ratings-css">
                            <div class="star-ratings-css-top" style="width: 84%"><span>★</span><span>★</span><span>★</span><span>★</span><span>★</span></div>
                            <div class="star-ratings-css-bottom"><span>★</span><span>★</span><span>★</span><span>★</span><span>★</span></div>
                            </div>

                            <span class="no-of-users">84% rating</span>

                            <span class="box-review-link">
                            <a href="bovada-online-casino-review.html" title="Bovada casino review">Expert review</a></span>

                        </div> <!-- rating ended -->
                        </div>
                        <div class="r-box-s fs v-center"> 

                        <a href="https://bit.ly/bovada-bitcoin-2020" rel="nofollow" target="_blank" title="Play at Bovada" class="claim mobile">
                        <h3>Claim Bonus</h3>
                        <span> at Bovada <br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></span>
                        </a>

                        <ul class="box-features none-mobile">
                            <li>&dollar;1,000 bonus x 3</li>
                            <li>&dollar;3,000 total</li>
                            <li>25x basic wagering</li>
                        </ul>
                        </div>
                    </div>

                    <div class="r-box-s last"> 
                        <div class="highlight v-center">
                        <i><img class="img-responsive" src="assets/images/icon-chip.png"></i>
                        <span class="desc">Great bonuses</span>
                        </div>
                    </div>

                    </div>

                    <div class="box-bottom"><strong>#ad 18+ BeGambleAware.org</strong> </div>

                </div>

                <!-- box 2 -->
                <div class="box-wrap">

                    <div class="box-left main-box"> 

                    <div class="l-box-1"> 

                        <div class="box-holder" style="background-color: #0e0e0e">

                        <div class="box-number-holder">
                            <span class="no">2</span>
                        </div> 

                        <div class="box-img-holder">
                            <a href="https://bit.ly/ic-july-special" rel="nofollow" target="_blank" title="Play at Intertops Casino Classic casino"><img class="icc-logo-box-sprite" alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJ8AAAAuAQMAAAAMQ1lzAAAAA1BMVEX///+nxBvIAAAAAXRSTlMAQObYZgAAABFJREFUeNpjYBgFo2AUDG0AAAPGAAE/NOQyAAAAAElFTkSuQmCC"></a>
                        </div>
                
                        </div>
                
                    </div>
                
                    <div class="inner-half">
                        <div class="l-box-2 v-center"> 
                
                        <div class="box-offer">
                            <span class="small color-red"> &starf; EXCLUSIVE &starf;</span>
                            <span class="box-amount"> &dollar;200 </span>
                            <span class="small"> BONUS</span>
                        </div>
                
                        </div>
                        <div class="l-box-3 cb v-center"> 
                        <ul class="box-features mobile">
                            <li>&dollar;200 bonus</li>
                            <li>+ 50 free spins</li>
                            <li>Code <strong>BFLYMATCH</strong></li>
                        </ul>

                
                        <a href="https://bit.ly/ic-july-special" rel="nofollow" target="_blank" title="Play at Intertops Casino Classic casino" class="claim none-mobile">
                            <h3>Claim Bonus</h3>
                            <span> at Intertops <br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></span>
                        </a>
                
                        </div>
                    </div>
                
                    </div>
                
                    <div class="box-right main-box"> 
                
                    <div class="inner-half">
                        <div class="r-box-s v-center"> 
                        <div class="rating-wrap">
                
                            <div class="star-ratings-css">
                            <div class="star-ratings-css-top" style="width: 94%"><span>★</span><span>★</span><span>★</span><span>★</span><span>★</span></div>
                            <div class="star-ratings-css-bottom"><span>★</span><span>★</span><span>★</span><span>★</span><span>★</span></div>
                            </div>
                
                            <span class="no-of-users">94% rating</span>
                
                            <span class="box-review-link">
                            <a href="intertops-casino-classic-review.html" title="Intertops casino review">Expert review</a></span>
                
                        </div>
                        </div>
                        <div class="r-box-s fs v-center"> 
                
                        <a href="https://bit.ly/ic-july-special" rel="nofollow" target="_blank" title="Play at Intertops Casino Classic casino" class="claim mobile">
                        <h3>Claim Bonus</h3>
                        <span> at Intertops <br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></span>
                        </a>
                
                        <ul class="box-features none-mobile">
                            <li>&dollar;200 bonus</li>
                            <li>+ 50 free spins</li>
                            <li>Code <strong>BFLYMATCH</strong></li>
                        </ul>
                    </div>
                    </div>
                
                    <div class="r-box-s last"> 
                        <div class="highlight v-center">
                        <i><img class="img-responsive" src="assets/images/icon-cards.png"></i>
                        <span class="desc">Established 1996</span>
                        </div>
                    </div>
                
                    </div>
                
                    <div class="box-bottom"><strong>#ad 18+ BeGambleAware.org</strong> 100% up to $200 Bonus. 100% match bonus + 50 Butterflies II free spins. Coupon: BFLYMATCH. Min deposit $20.00. Max Bonus $200.00 + 50 free spins. All players, valid until December 31 2020.</div>
                </div>
            </div>

<?php
			break;
        case "CA":
            #content for CA
            ?>
            <h3 class = "padding-top10"> The best Roulette casinos for <span class = "font500"> CA </span> players </h3>
            <p class = " lead "> Updated <script> document.write ( currentmonth); </script> </p>

<?php
			break;
			
		default:
			# no content for other country-codes
?>
			<h3>Sorry - we currently do not recommend any casinos for <?php echo $countryCode; ?> players</h3>
<?php
			break;
	}
    
} else{ // in case unknown IP address
	?>
    <h3>Sorry but there is no content for this section until now.</h3>
<?php    
}

?>


