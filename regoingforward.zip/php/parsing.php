<?php
    include('requestsComparison.class.php');

    function arrayRestructure ($file_1, $file_2) {
        $result = array();
        $result['file_1'] = $file_1;
        $result['file_2'] = $file_2;
        $result['different'] = $file_1 == $file_2 ? false : true;
        return $result;
    }
    function getHeadersArray ($data,$param){
        $result = array();
        if ($param == 'value') {
            foreach($data as $key => $value){
                $result[$value['name']] = $value['value'];
            }
            return $result;
        }
        foreach($data as $key => $value){
            array_push($result, $value[$param]);
        }
        return $result;
    }
    $fileLocation = 'townplannerDotCom.har';     // Add this
    $fileLocation2 = 'townplannerDotCom_FilteredHAR.har';     // Add this
    $testClass = new requestsComparison();
    $result1 = $testClass->convertFileToArray($fileLocation);
    $result2 = $testClass->convertFileToArray($fileLocation2);

    $final_array = array();
 
    foreach($result1 as $key => $value) {
        $final_array[$key]['time'] = arrayRestructure($result1[$key]['time'], $result2[$key]['time']);
        $final_array[$key]['serverIPAddress'] = arrayRestructure($result1[$key]['serverIPAddress'], $result2[$key]['serverIPAddress']);
        $final_array[$key]['connection'] = arrayRestructure($result1[$key]['connection'], $result2[$key]['connection']);
        $final_array[$key]['request']['headersSize'] = arrayRestructure($result1[$key]['request']['headersSize'], $result2[$key]['request']['headersSize']);
        
        $headersArray1 = ($result1[$key]['request']['headers']);
        $headersArray2 = ($result2[$key]['request']['headers']);
        $headersNameArray1 = getHeadersArray($headersArray1, 'name');
        $headersNameArray2 = getHeadersArray($headersArray2, 'name');
        $headerValueArray1 = getHeadersArray($headersArray1, 'value');
        $headerValueArray2 = getHeadersArray($headersArray2, 'value');
        
        $headersNameMergeArray = array_unique (array_merge ($headersNameArray1, $headersNameArray2));
        // var_dump($headersNameMergeArray);die();

        foreach($headersNameMergeArray as $index => $headervalue){
            // $param1 = isset($headersArray1[$key])
            $file_1 = array_key_exists($headervalue, $headerValueArray1) ? $headerValueArray1[$headervalue] : "not found";
            $file_2 = array_key_exists($headervalue, $headerValueArray2) ? $headerValueArray2[$headervalue] : "not found";
            $final_array[$key]['request']['headers'][$headervalue] = arrayRestructure($file_1,$file_2);
            // var_dump ($final_array[$key]['request']['headers'][$value]);

        }

        // $final_array[$key]['request']['queryString'] = arrayRestructure($result1[$key]['request']['queryString'], $result2[$key]['request']['queryString']);
        // $final_array[$key]['request']['bodySize'] = arrayRestructure($result1[$key]['request']['bodySize'], $result2[$key]['request']['bodySize']);
        // $final_array[$key]['request']['url'] = arrayRestructure($result1[$key]['request']['url'], $result2[$key]['request']['url']);
        // $final_array[$key]['request']['cookies'] = arrayRestructure($result1[$key]['request']['cookies'], $result2[$key]['request']['cookies']);
        // $final_array[$key]['request']['method'] = arrayRestructure($result1[$key]['request']['method'], $result2[$key]['request']['method']);
        // $final_array[$key]['request']['httpVersion'] = arrayRestructure($result1[$key]['request']['httpVersion'], $result2[$key]['request']['httpVersion']);

    }
    $final_array = json_encode($final_array);
    echo($final_array);
    
?>

