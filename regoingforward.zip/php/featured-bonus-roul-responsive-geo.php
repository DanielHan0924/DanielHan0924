<?php
// require_once('getCountryCode.php');

// $countryCode = ip_info("Visitor", "Country Code");

if($countryCode != NULL)
{

    switch ($countryCode) {
        case 'GB':
            # content for GB code & random number...
            $casino=rand(1,3); // How many US casinos?

            if ($casino == 1) { ?>
                <div class="container " style="background-image:url(assets/images/review-header-narrow-roul.jpg); background-size: 1387px 320px;">
                    <div class="row">
                        <div class="col-md-4 col-sm-6 hidden-xs col-centered">
                            <a href="https://bit.ly/2joFxGX" title="Play at Dreams casino"><img class="center-block padding-top60" src="assets/images/dr-bonus-roul.png" width="280px"></img></a>
                        </div>
                        <div class="hidden-xs col-sm-6 col-md-4 col-centered">
                            <h2 class="text-center font500 fsize30 padding-top20 margin-bottom20 color-lightgrey">&dollar;2,000 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/dr-logo-trans.png" width="220px"></img>
                            <p class="text-center fsize20 padding-top30 color-lightgrey">NO wagering required!</p>
                            <div class="col-xs-12 text-center margin-bottom20 font500"> 
                                <a href="https://bit.ly/2joFxGX" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Get my &dollar;2,000</a>
                            </div>
                        </div>
                        <div class="col-xs-12 hidden-sm hidden-md hidden-lg col-centered">
                            <h2 class="text-center font400 fsize26 padding-top15 margin-bottom15 color-lightgrey">&dollar;2,000 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/dr-logo-trans.png" width="120px"></img>
                            <p class="text-center fsize20 padding-top20 color-lightgrey">NO wagering required!</p>
                            <div class="col-xs-12 text-center margin-bottom20 padding-top15 font400"> 
                                <a href="https://bit.ly/2joFxGX" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Get my &dollar;2,000</a>
                            </div>
                        </div>
                        <div class="col-md-3 col-md-offset-1 col-centered hidden-sm hidden-xs padding-top60">
                            <ul class="list-icon spaced check-square ad-list text-left">
                                <li>$2,000 new player bonus</li>
                                <li>Roulette is eligible</li>
                                <li>NO wagering requirement</li>
                                <li>200% - double your deposit</li>
                                <li>USA players welcome <img class="inline-block" src="assets/images/accepts-us-tick.png" height="18px"></li>
                            </ul>
                        </div>
        
                    </div>
        
                </div>
            <?php }
            if ($casino == 2) { ?>
                <div class="container " style="background-image:url(assets/images/review-header-narrow-roul.jpg); background-size: 1387px 320px;">
                    <div class="row">
                        <div class="col-md-4 col-sm-6 hidden-xs col-centered">
                            <a href="https://bit.ly/fp-cj-2020" title="Play at Cherry Jackpot casino"><img class="center-block padding-top60" src="assets/images/cj-bonus-casino.jpg" width="280px"></img></a>
                        </div>
                        <div class="hidden-xs col-sm-6 col-md-4 col-centered">
                            <h2 class="text-center font500 fsize30 padding-top20 margin-bottom20 color-lightgrey">&dollar;20,000 Casino bonuses</h2>
                            <img class="center-block" src="assets/images/cj-logo-trans.png" width="220px"></img>
                            <p class="text-center fsize20 padding-top30 color-lightgrey">Just 30x wagering!</p>
                            <div class="col-xs-12 text-center margin-bottom20 font500"> 
                                <a href="https://bit.ly/fp-cj-2020" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Get my bonus</a>
                            </div>
                        </div>
                        <div class="col-xs-12 hidden-sm hidden-md hidden-lg col-centered">
                            <h2 class="text-center font400 fsize26 padding-top15 margin-bottom15 color-lightgrey">&dollar;20,000 Casino bonuses</h2>
                            <img class="center-block" src="assets/images/cj-logo-trans.png" width="200px"></img>
                            <p class="text-center fsize20 padding-top20 color-lightgrey">Just 30x wagering!</p>
                            <div class="col-xs-12 text-center margin-bottom20 padding-top15 font400">   
                                <a href="https://bit.ly/fp-cj-2020" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Get my bonus</a>
                            </div>
                        </div>
                        <div class="col-md-3 col-md-offset-1 col-centered hidden-sm hidden-xs padding-top60">
                            <ul class="list-icon spaced check-square ad-list text-left">
                                <li>&dollar;20,000 new player bonuses</li>
                                <li>TEN &dollar;2,000 bonuses</li>
                                <li>200% - double your deposits</li>
                                <li>NO maximum cashout limit!</li>
                                <li>USA players welcome <img class="inline-block" src="assets/images/accepts-us-tick.png" height="18px"></li>
                            </ul>
                        </div>
        
                    </div>
        
                </div>
            <?php }
            if ($casino == 3) { ?>
                <div class="container " style="background-image:url(assets/images/review-header-narrow-roul.jpg); background-size: 1387px 320px;">
                    <div class="row">
                        <div class="col-md-4 col-sm-6 hidden-xs col-centered">
                            <a href="https://bit.ly/2joFxGX" title="Play at Dreams casino"><img class="center-block padding-top60" src="assets/images/dr-bonus-roul.png" width="280px"></img></a>
                        </div>
                        <div class="hidden-xs col-sm-6 col-md-4 col-centered">
                            <h2 class="text-center font500 fsize30 padding-top20 margin-bottom20 color-lightgrey">&dollar;2,000 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/dr-logo-trans.png" width="220px"></img>
                            <p class="text-center fsize20 padding-top30 color-lightgrey">NO wagering required!</p>
                            <div class="col-xs-12 text-center margin-bottom20 font500"> 
                                <a href="https://bit.ly/2joFxGX" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Get my &dollar;2,000</a>
                            </div>
                        </div>
                        <div class="col-xs-12 hidden-sm hidden-md hidden-lg col-centered">
                            <h2 class="text-center font400 fsize26 padding-top15 margin-bottom15 color-lightgrey">&dollar;2,000 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/dr-logo-trans.png" width="120px"></img>
                            <p class="text-center fsize20 padding-top20 color-lightgrey">NO wagering required!</p>
                            <div class="col-xs-12 text-center margin-bottom20 padding-top15 font400"> 
                                <a href="https://bit.ly/2joFxGX" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Get my &dollar;2,000</a>
                            </div>
                        </div>
                        <div class="col-md-3 col-md-offset-1 col-centered hidden-sm hidden-xs padding-top60">
                            <ul class="list-icon spaced check-square ad-list text-left">
                                <li>$2,000 new player bonus</li>
                                <li>Roulette is eligible</li>
                                <li>NO wagering requirement</li>
                                <li>200% - double your deposit</li>
                                <li>USA players welcome <img class="inline-block" src="assets/images/accepts-us-tick.png" height="18px"></li>
                            </ul>
                        </div>
        
                    </div>
        
                </div>
            <?php }
            break;
        case 'US':
            # content for US code & random number...
            $casino=rand(1,4); // How many UK casinos?

            if ($casino == 1) { ?>
                <div class="container" style="background-image:url(assets/images/review-header-narrow-roul.jpg); background-size: 1387px 320px;">
                    <div class="row">
                        <div class="col-md-4 col-sm-6 hidden-xs col-centered">
                            <a href="https://bit.ly/fp-ladbrokes-10-50" title="Play Roulette now at Ladbrokes"><img class="center-block padding20" src="assets/images/lb-ss-500.jpg" width="250px"></img></a>
                            <p class="fsize9 text-center color-lightgrey">18+. New Customers Only. Min &pound;20 deposit. Max bonus &pound;500. 20x (deposit + bonus) wagering reqs apply. Contributions to wagering reqs vary by game. Bonus valid for 30 days (bonus + winnings removed). Certain games and payment methods excluded. Bets covering 67% or more of Roulette table don’t count to wagering. T&Cs apply.</p>
                        </div>
                        <div class="hidden-xs col-sm-6 col-md-4 col-centered">
                            <h2 class="text-center font500 fsize30 padding-top20 margin-bottom20 color-lightgrey">&pound;500 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/lb-logo-trans.png" width="160px"></img>
                            <p class="text-center fsize20 padding-top20 color-lightgrey">Bonuses on three deposits</p>
                            <div class="col-xs-12 text-center margin-bottom20 font150"> 
                                <a href="https://bit.ly/fp-ladbrokes-10-50" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Play Now</a>
                            </div>
                        </div>
                        <div class="col-xs-12 hidden-sm hidden-md hidden-lg col-centered">
                            <h2 class="text-center font400 fsize26 padding-top15 margin-bottom15 color-lightgrey">&pound;500 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/lb-logo-trans.png" width="120px"></img>
                            <p class="text-center fsize24 padding-top20 color-lightgrey">New player offer</p>
                            <div class="col-xs-12 text-center margin-bottom20 padding-top15 font400">   
                                <a href="https://bit.ly/fp-ladbrokes-10-50" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Play Now</a>
                            </div>
                            <p class="fsize9 text-center color-lightgrey">18+. New Customers Only. Min &pound;20 deposit. Max bonus &pound;500. 20x (deposit + bonus) wagering reqs apply. Contributions to wagering reqs vary by game. Bonus valid for 30 days (bonus + winnings removed). Certain games and payment methods excluded. Bets covering 67% or more of Roulette table don’t count to wagering. T&Cs apply.</p>
                        </div>
                        <div class="col-md-3 col-md-offset-1 col-centered hidden-sm hidden-xs padding-top60">
                            <ul class="list-icon spaced check-square ad-list text-left">
                                <li>3 Roulette bonuses</li>
                                <li>&pound;500 on 3 deposits</li>
                                <li>Up to &pound;1,500 in bonuses</li>
                                <li>15 Roulette variations</li>
                                <li>Live Dealer Roulette</li>
                            </ul>
                        </div>
        
                    </div>
        
                </div>
            <?php }
            if ($casino == 2) { ?>
                <div class="container" style="background-image:url(assets/images/review-header-narrow-roul.jpg); background-size: 1387px 320px;"> 
                    <div class="row">
                        <div class="col-md-4 col-sm-6 hidden-xs col-centered">
                            <a href="https://bit.ly/b3-bonus-18" title="Play Roulette now at bet365 Casino"><img class="center-block padding-top60" src="assets/images/b3-compliant.gif" width="300px"></img></a>
                        </div>
                        <div class="hidden-xs col-sm-6 col-md-4 col-centered">
                            <h2 class="text-center font500 fsize30 padding-top20 margin-bottom20 color-lightgrey">&pound;100 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/bet365-logo.png" width="160px"></img>
                            <p class="text-center fsize24 padding-top20 color-lightgrey">New player offer</p>
                            <p class="fsize9 text-center color-lightgrey">18+ New Casino customers only.
                                Deposit min. &pound;10. Applies to first deposit to Casino only. Max. bonus &pound;100. 20x wagering (game weighting, table coverage and max. bet rules apply) on deposit and bonus to make the bonus balance withdrawable. Time limits and T&amp;Cs apply.</p>
                            <div class="col-xs-12 text-center margin-bottom20 font150"> 
                                <a href="https://bit.ly/b3-bonus-18" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Play Now</a>
                            </div>
                        </div>
                        <div class="col-xs-12 hidden-sm hidden-md hidden-lg col-centered">
                            <h2 class="text-center font400 fsize26 padding-top15 margin-bottom15 color-lightgrey">&pound;100 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/bet365-logo.png" width="150px"></img>
                            <p class="text-center fsize24 padding-top20 color-lightgrey">New player offer</p>
                            <p class="fsize9 text-center color-lightgrey">18+ New Casino customers only.
                                Deposit min. &pound;10. Applies to first deposit to Casino only. Max. bonus &pound;100. 20x wagering (game weighting, table coverage and max. bet rules apply) on deposit and bonus to make the bonus balance withdrawable. Time limits and T&amp;Cs apply.</p>
                            <div class="col-xs-12 text-center margin-bottom20 padding-top15 font400">   
                                <a href="https://bit.ly/b3-bonus-18" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Play Now</a>
                            </div>
                        </div>
                        <div class="col-md-3 col-md-offset-1 col-centered hidden-sm hidden-xs padding-top40">
                            <ul class="list-icon spaced check-square ad-list text-left color-white">
                                <li>Great Roulette bonus</li>
                                <li>&pound;100 deposit match</li>
                                <li>Only 15x wagering needed</li>
                                <li>Standard and Live Dealers</li>
                                <li>New customers only</li>
                                <li>Time limits and T&amp;Cs apply</li>
                                <li>18+ only</li>
                            </ul>
                        </div>
        
                    </div>
        
                </div>
            <?php }
            if ($casino == 3) { ?>
                <div class="container" style="background-image:url(assets/images/review-header-narrow-roul.jpg);  background-size: 1387px 320px;">
                    <div class="row">
                        <div class="col-md-4 col-sm-6 hidden-xs col-centered">
                            <a href="https://bit.ly/2BxiNND" title="Play Roulette now at betfair"><img class="center-block padding-top50" src="../assets/images/bf-bonus-roul.png" width="280px"></img></a>
                        </div>
                        <div class="hidden-xs col-sm-6 col-md-4 col-centered">
                            <h2 class="text-center font500 fsize30 padding-top20 margin-bottom20 color-lightgrey">&pound;100 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/bf-logo-white.png" width="220px"></img>
                            <p class="text-center fsize20 padding-top15 color-lightgrey">New player offer</p>
                            <div class="col-xs-12 text-center margin-bottom10 font500"> 
                                <a href="https://bit.ly/2BxiNND" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Get my &pound;100</a>
                            </div>
                            <p class="fsize9 text-center color-lightgrey"><a data-toggle="tooltip" data-placement="bottom" data-original-title="All games bonus key terms and conditions - Minimum deposit of &pound;10, x45 wagering, Roulette and blackjack 50% weighting. Bonus Valid for 7 days. Not available to customers using Moneybookers/Skrill or Neteller as a payment method." href="betfair-online-casino-bonus.html">Ts &amp; Cs apply</a>, 18+, New Customers Only, Wagering Requirements apply, Play Responsibly, <a href="https://www.begambleaware.org">Gambleaware</a></p>
                        </div>
                        <div class="col-xs-12 hidden-sm hidden-md hidden-lg col-centered">
                            <h2 class="text-center font400 fsize26 padding-top15 margin-bottom15 color-lightgrey">&pound;100 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/bf-logo-white.png" width="180px"></img>
                            <p class="text-center fsize20 padding-top15 margin-bottom10 color-lightgrey">New player offer</p>
                            <div class="col-xs-12 text-center margin-bottom10 padding-top10 font400">   
                                <a href="https://bit.ly/2BxiNND" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Get my &pound;100</a>
                            </div>
                            <p class="fsize9 text-center color-lightgrey"><a data-toggle="tooltip" data-placement="bottom" data-original-title="All games bonus key terms and conditions - Minimum deposit of &pound;10, x45 wagering, Roulette and blackjack 50% weighting. Bonus Valid for 7 days. Not available to customers using Moneybookers/Skrill or Neteller as a payment method." href="betfair-online-casino-bonus.html">Ts &amp; Cs apply</a>, 18+, New Customers Only, Wagering Requirements apply, Play Responsibly, <a href="https://www.begambleaware.org">Gambleaware</a></p>
                        </div>
                        <div class="col-md-3 col-md-offset-1 col-centered hidden-sm hidden-xs padding-top60">
                            <ul class="list-icon spaced check-square ad-list text-left">
                                <li>&pound;100 Roulette bonus</li>
                                <li>New player bonus</li>
                                <li>Standard or Live Dealer</li>
                                <li>Exclusive Exchange Roulette</li>
                                <li>90x wagering requirements</li>
                            </ul>
                        </div>
        
                    </div>
        
                </div>
            <?php }
            if ($casino == 4) { ?>
                <div class="container" style="background-image:url(assets/images/review-header-narrow-roul.jpg); background-size: 1500px 350px;">
                    <div class="row">
                        <div class="col-md-4 col-sm-6 hidden-xs col-centered">
                            <a href="https://bit.ly/WHC-300" title="Play Roulette now at William Hill"><img class="center-block padding-top20 margin-bottom10" src="assets/images/whc-big.gif" width="300px"></img></a>
                            <p class="fsize9 text-center color-lightgrey"><a data-toggle="tooltip" data-placement="bottom" data-original-title="Opt in required. New customers to Casino page only. Available 1x per customer. Min Buy in &pound;10. Bonus value 100% of Buy in. Max Bonus &pound;300. 40x wagering. Bonus expires 7 days from issue. Game weighting, player, currency, country, game restrictions & full terms apply.">Ts &amp; Cs apply</a></p>
                        </div>
                        <div class="hidden-xs col-sm-6 col-md-4 col-centered">
                            <h2 class="text-center font500 fsize30 padding-top20 margin-bottom10 color-lightgrey">&pound;300 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/wh-logo-trans.png" width="160px"></img>
                            <p class="text-center fsize24 padding-top10 color-lightgrey">New player offer</p>
                            <div class="col-xs-12 text-center font150"> 
                                <a href="https://bit.ly/WHC-300" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Sign up</a>
                                <p class="fsize9 text-center color-lightgrey margin-top6"><a data-toggle="tooltip" data-placement="bottom" data-original-title="Opt in required. New customers to Casino page only. Available 1x per customer. Min Buy in &pound;10. Bonus value 100% of Buy in. Max Bonus &pound;300. 40x wagering. Bonus expires 7 days from issue. Game weighting, player, currency, country, game restrictions & full terms apply.">Ts &amp; Cs apply</a></p>
                            </div>
                        </div>
                        
                        <div class="col-xs-12 hidden-sm hidden-md hidden-lg col-centered">
                            <h2 class="text-center font400 fsize26 padding-top15 margin-bottom10 color-lightgrey">&pound;300 Roulette bonus</h2>
                            <img class="center-block" src="assets/images/wh-logo-trans.png" width="120px"></img>
                            <p class="text-center fsize24 padding-top10 margin-bottom6 color-lightgrey">New player offer</p>
                            <div class="col-xs-12 text-center padding-top10 font400">   
                                <a href="https://bit.ly/WHC-300" rel="nofollow" target="_blank" title="Claim this bonus offer" class="btn btn-danger btn-lg" role="button">Sign up</a>
                                <p class="fsize9 text-center color-lightgrey padding-top10">Opt in required. New customers to Casino page only. Available 1x per customer. Min Buy in &pound;10. Bonus value 100% of Buy in. Max Bonus &pound;300. 40x wagering. Bonus expires 7 days from issue. Game weighting, player, currency, country, game restrictions & full terms apply.</p>
                            </div>
                            
                        </div>
                        <div class="col-md-3 col-md-offset-1 col-centered hidden-sm hidden-xs padding-top40">
                            <ul class="list-icon spaced check-square ad-list text-left color-white">
                                <li>New player Casino Bonus</li>
                                <li>Min buy-in is just &pound;10
                                <li>Max bonus is &pound;300</li>
                                <li>Just 80x wagering on Roulette</li>
                                <li>6 Roulette variations</li>
                                <li>17 Live Roulette tables</li>
                            </ul>
                        </div>
        
                    </div>
        
                </div>
        <?php } break;
		default:
        # no content for other country-codes
?>
        <h3>Sorry but there is no content for this section until now.</h3>
<?php
        break;
}

} else { # no content for unclear IP address
?>
<h3>Sorry but there is no content for this section until now.</h3>
<?php    
}

?>



