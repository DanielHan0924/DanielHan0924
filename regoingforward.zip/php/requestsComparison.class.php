<?php

class requestsComparison {

    function convertFileToArray($fileLocation) {
        try {
            $arr = $this->_loadHarFile($fileLocation);
            return ($arr);
        } catch (Exception $ex) {
            var_dump($ex);
        }
    }

    private function _loadHarFile($fileLocation) {
        if (!file_exists($fileLocation)) {
            throw new Exception('Invalid File Location: ' . $fileLocation);
        }
        $fileContent = file_get_contents($fileLocation);
        $cleanedFileContent = $this->_cleanJSONString($fileContent);
        $arrayOutput = json_decode($cleanedFileContent, true)['log']['entries'];
        if (!$arrayOutput) {
            throw new Exception('Invalid JSON Format in HAR file: ' . $fileLocation);
        }
        return $arrayOutput;
    }

    private function _cleanJSONString($jsonString) {
        // From -> https://stackoverflow.com/a/20845642
        // This will remove unwanted characters.
        // Check http://www.php.net/chr for details
        for ($i = 0; $i <= 31; ++$i) {
            $jsonString = str_replace(chr($i), "", $jsonString);
        }
        $jsonString = str_replace(chr(127), "", $jsonString);
        // This is the most common part
        // Some file begins with 'efbbbf' to mark the beginning of the file. (binary level)
        // here we detect it and we remove it, basically it's the first 3 characters 
        if (0 === strpos(bin2hex($jsonString), 'efbbbf')) {
            $jsonString = substr($jsonString, 3);
        }
        return $jsonString;
    }

}

// $fileLocation = '';     // Add this
// $testClass = new requestsComparison();
// $testClass->convertFileToArray($fileLocation);
