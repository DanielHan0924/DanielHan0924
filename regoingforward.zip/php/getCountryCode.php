<?php 
// session_start();
function ip_info_alt(){

	$ip = $_SERVER["REMOTE_ADDR"];    //----This is the correct IP address for a visitor.

	$geoData = file_get_contents('https://api.hostip.info/get_json.php?ip='.$ip);
	$geoData = json_decode($geoData, true);
        
	if (isset($geoData['country_code'])) {

		$output = $geoData['country_code'];
		return $output;

	} else {

		return 'unknown';

	}
}

function ip_info_simple(){

	$ip = $_SERVER["REMOTE_ADDR"];    //----This is the correct IP address for a visitor.

	$geoData = file_get_contents('https://api.ipdata.co/'.$ip.'?api-key=a7464683cd2e16551bd7e860853111e7f6259b34fbf59e1d973289aa');
	$geoData = json_decode($geoData, true);
        
	if (isset($geoData['country_code'])) {

		$output = $geoData['country_code'];
		return $output;

	} else {

		return NULL;

	}
}

function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {

    $output = NULL;

    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {

        $ip = $_SERVER["REMOTE_ADDR"];
        $ip = '137.186.18.255';         //-------------test URL for CA
        // $ip = '12.215.42.19';           //-------------test URL for US
        // $ip = '88.208.252.17';          //-------------test URl for GB
        $ip = '89.22.173.53';          //-------------test URl for RU

        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));

    $support = array("ip","is_eu","country", "countrycode", "state", "region", "city", "location", "address");
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        
        $ipdat_countrycode = file_get_contents('https://api.ipdata.co/'.$ip.'/country_code?api-key=a7464683cd2e16551bd7e860853111e7f6259b34fbf59e1d973289aa');
        
        if (@strlen(trim($ipdat_countrycode)) == 2) {
            switch ($purpose) {
                case "countrycode":
                    $output = $ipdat_countrycode;
                break;
            }
        }
    }

    return $output;
}

?>