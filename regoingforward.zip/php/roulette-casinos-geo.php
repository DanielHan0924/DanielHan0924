<?php 
// require_once('getCountryCode.php');

// $countryCode = ip_info("Visitor", "Country Code");

if($countryCode != NULL){

	switch ($countryCode) {
		case 'GB':
			# carousels for GB
?>		
			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://bit.ly/NB-2020-LC" rel="nofollow" target="_blank" title="Play online at No Bonus">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="assets/images/nb-lightning.jpg" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="no-bonus-casino-review.html" title="A full, detailed review of No Bonus casino">No Bonus</a>
						<span class="bonus"><strong>UNIQUE</strong></span>
						<span class="bonus-desc">Lightning Roulette</span>
						<a href="https://bit.ly/NB-2020-LC" rel="nofollow" target="_blank" title="Play online at No Bonus" class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://bit.ly/fp-coral-10-50" rel="nofollow">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="assets/images/coral-roul.jpg" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="coral-online-casino-bonuses.html" title="Details of this bonus">Coral</a>
						<span class="bonus"><strong>27</strong></span>
						<span class="bonus-desc">Roulette games</span>
						<a href="https://bit.ly/fp-coral-10-50d" rel="nofollow" class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://bit.ly/2BxiNND" rel="nofollow">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="assets/images/bf-roul.jpg" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="betfair-online-casino-review.html" title="A full, detailed review of betfair casino">betfair</a>
						<span class="bonus"><strong>26</strong></span>
						<span class="bonus-desc">Roulette games</span>
						<a href="https://bit.ly/2BxiNND" rel="nofollow" target="_blank" title="Play at betfair casino"class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://bit.ly/fp-ladbrokes-10-50" rel="nofollow" target="_blank" title="Play online at Ladbrokes">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="assets/images/lb-roul.gif" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="ladbrokes-online-casino-review.html" title="A full, detailed review of Ladbrokes casino">Ladbrokes</a>
						<span class="bonus"><strong>15</strong></span>
						<span class="bonus-desc">Roulette games</span>
						<a href="https://bit.ly/fp-ladbrokes-10-50" rel="nofollow" target="_blank" title="Play online at Ladbrokes" class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://bit.ly/2sA7z4B" rel="nofollow" target="_blank" title="Play at Videoslots casino">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="assets/images/vs-roul.jpg" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="videoslots-casino-review.html" title="Read a full, detailed review of Videoslots">Videoslots</a>
						<span class="bonus"><strong>14</strong></span>
						<span class="bonus-desc">Roulette games</span>
						<a href="https://bit.ly/2sA7z4B" rel="nofollow" target="_blank" title="Play at Videoslots casino" class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://bit.ly/AB-2020-LCR" rel="nofollow" target="_blank" title="Play at All British casino">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="assets/images/ab-roul.jpg" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="all-british-casino-review.html" title="Read a full, detailed review of All British">All British</a>
						<span class="bonus"><strong>8</strong></span>
						<span class="bonus-desc">Roulette games</span>
						<a href="https://bit.ly/AB-2020-LCR" rel="nofollow" target="_blank" title="Play at All British casino" class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

<?php
			break;
		case 'US':
			# carousels for US
?>
			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://bit.ly/bovada-bitcoin-2020" rel="nofollow" target="_blank" title="Play at Bovada casino">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="../assets/images/bv-roul.jpg" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="../bovada-online-casino-review.html" title="Read a full, detailed review of Bovada">Bovada <i class="small flag-icon flag-icon-us margin-left5"></i></a>
						<span class="bonus"><strong>&dollar;3,000</strong></span>
						<span class="bonus-desc">Roulette bonus</span>
						<a href="https://bit.ly/bovada-bitcoin-2020" rel="nofollow" target="_blank" title="Play at Bovada casino" class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://casino.bet365.com?affiliate=365_099765" rel="nofollow">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="../assets/images/b3-logo.gif" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="bet365-online-casino-review.html" title="A full, detailed review of bet365 casino">bet365</a>
						<span class="bonus"><strong>10</strong></span>
						<span class="bonus-desc">Roulette games</span>
						<a href="https://casino.bet365.com?affiliate=365_099765" rel="nofollow"title="Play at bet365 casino" class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://bit.ly/2BxiNND" rel="nofollow">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="assets/images/bf-roul.jpg" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="betfair-online-casino-review.html" title="A full, detailed review of betfair casino">betfair</a>
						<span class="bonus"><strong>26</strong></span>
						<span class="bonus-desc">Roulette games</span>
						<a href="https://bit.ly/2BxiNND" rel="nofollow" target="_blank" title="Play at betfair casino"class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://bit.ly/fp-ladbrokes-10-50" rel="nofollow" target="_blank" title="Play online at Ladbrokes">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="assets/images/lb-roul.gif" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="ladbrokes-online-casino-review.html" title="A full, detailed review of Ladbrokes casino">Ladbrokes</a>
						<span class="bonus"><strong>15</strong></span>
						<span class="bonus-desc">Roulette games</span>
						<a href="https://bit.ly/fp-ladbrokes-10-50" rel="nofollow" target="_blank" title="Play online at Ladbrokes" class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://bit.ly/2sA7z4B" rel="nofollow" target="_blank" title="Play at Videoslots casino">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="assets/images/vs-roul.jpg" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="videoslots-casino-review.html" title="Read a full, detailed review of Videoslots">Videoslots</a>
						<span class="bonus"><strong>14</strong></span>
						<span class="bonus-desc">Roulette games</span>
						<a href="https://bit.ly/2sA7z4B" rel="nofollow" target="_blank" title="Play at Videoslots casino" class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

			<div class="owl-featured-box">
				<div class="owl-featured-item">
					<a class="figure" href="https://bit.ly/AB-2020-LCR" rel="nofollow" target="_blank" title="Play at All British casino">
						<span><i class="fa fa-play"></i></span>
						<img alt="" src="assets/images/ab-roul.jpg" width="230" />
					</a>
					<div class="owl-featured-detail">
						<a class="featured-casino" href="all-british-casino-review.html" title="Read a full, detailed review of All British">All British</a>
						<span class="bonus"><strong>8</strong></span>
						<span class="bonus-desc">Roulette games</span>
						<a href="https://bit.ly/AB-2020-LCR" rel="nofollow" target="_blank" title="Play at All British casino" class="btn btn-success btn-lg">Go to casino<br><span class="fsize11 color-lightgrey text-align: center-block">#ad 18+</span></a>
					</div>
				</div>
			</div>

<?php
			break;
		case "CA":
			
		default:
			# no content for other country-codes
?>
			<h3>Sorry but there is no content for this section until now.</h3>
<?php
			break;
	}
    
} else{ 
	?>
    <h3>Sorry but there is no content for this section until now.</h3>
<?php    
}

?>


