<?php 
// require_once('getCountryCode.php');

// $countryCode = ip_info("Visitor", "Country Code");

if($countryCode != NULL){

	switch ($countryCode) {
		case 'GB':
			# carousels for GB
?>		
			<div class="inline-ad-block">
				<h4 class="font400">The best Roulette casino?</h4>
				<div class="tabs nomargin">
					<div class="tab-content nopadding">
						<div id="tab_x" class="">
							<p class="padding-top15"><strong>Videoslots Casino</strong> have a great selection of over 30 different Roulette games, including 10 excellent Live tables. They also offer new players a 100% deposit bonus up to &pound;200 to get you started!</p>
							<a href="https://bit.ly/2sA7z4B" rel="nofollow" target="_blank" title="Get my bonus!">Play Roulette at Videoslots &raquo;</a>
						</div>
					</div>
				</div>
			</div>

<?php
			break;
		case 'US':
			# carousels for US
?>
			<div class="inline-ad-block">
				<h4 class="font400">The best Roulette casino?</h4>
				<div class="tabs nomargin">
					<div class="tab-content nopadding">
						<div id="tab_z" class="">
							<p class="padding-top15"><strong>Bovada Casino</strong> are offering new players 3 deposit match bonuses <strong>up to &dollar;1,000 each</strong>, that you can use on Roulette with wagering of just 42x!</p>
							<a href="https://bit.ly/bovada-bitcoin-2020" rel="nofollow" target="_blank" title="Read more about this bonus offer">Play Roulette at Bovada now &raquo;</a>
						</div>
					</div>
				</div>
			</div>

<?php
			break;
		case "CA":
			break;
			
		default:
			# no content for other country-codes
?>
			<h3>Sorry but there is no content for this section until now.</h3>
<?php
			break;
	}
    
} else{ 
	?>
    <h3>Sorry but there is no content for this section until now.</h3>
<?php    
}

?>




