[
    0 => [
        'time' => [
            'file_1' => 'value from file 1', 
            'file_2' => 'value from file 2', 
            'different' => 'true/false'
        ],
        'connection' =>  [
            'file_1' => 'value from file 1', 
            'file_2' => 'value from file 2', 
            'different' => 'true/false'
        ],
        'request' => [
            'headersSize' =>  [
                'file_1' => 'value from file 1', 
                'file_2' => 'value from file 2', 
                'different' => 'true/false'
            ],
            'postData' => [],
            ...etc
        ]
    ]
];

Post Data can be of different types

the array format is
"headers": [
    {
        "name": "Accept-Encoding",
        "value": "gzip,deflate",
        "comment": ""
    },
    {
        "name": "Accept-Language",
        "value": "en-us,en;q=0.5",
        "comment": ""
    }
]
"queryString": [
    {
        "name": "param1",
        "value": "value1",
        "comment": ""
    },
    {
        "name": "param1",
        "value": "value1",
        "comment": ""
    }
]

"cookies": [
    {
        "name": "TestCookie",
        "value": "Cookie Value",
        "path": "/",
        "domain": "www.janodvarko.cz",
        "expires": "2009-07-24T19:20:30.123+02:00",
        "httpOnly": false,
        "secure": false,
        "comment": ""
    }
]

"postData": {
    "mimeType": "multipart/form-data",
    "params": [],
    "text" : "plain posted data",
    "comment": ""
}
    where params is
    "params": [
        {
            "name": "paramName",
            "value": "paramValue",
            "fileName": "example.pdf",
            "contentType": "application/pdf",
            "comment": ""
        }
    ]

post data format content (or body) is different as per the content type: This is one form of complexity that I was talking about
application/x-www-form-urlencoded
multipart/form-data 
application/json

postData => [
	'w' => [
		'file1' => 'd',
		'file2' => 'd',
		'different' => false
	],
	'x' => [
		'file1' => 'a',
		'file2' => 'b',
		'different' => true
	],
	'y' => [
		'file1' => 'b',
		'file2' => 'not found',
		'different' => true
	],
	'z' => [
		'file1' => 'c',
		'file2' => 'not found',
		'different' => true
	]
	'm' => [
		'file1' => 'not found',
		'file2' => 'c',
		'different' => true
	]
]

headers => ['Host' => [
			'file1' => 'www.townplanner.com',
			'file2' => '......',
			'different' => false
			],
			['Connection' => [
			'file1' => 'keep-alive'
			'file2; => '.....',
			'different' => '...'
            ]

************************************

