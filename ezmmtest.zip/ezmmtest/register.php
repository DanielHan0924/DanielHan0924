<!DOCTYPE html>
<html>
<head>
	<title>SignUp :: EZM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
	
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    
   
    <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" >
    
	<!--Custom styles-->
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="overlay"></div>
    <div class="container">
	<?php 
		$site_key = '6LcnP6kUAAAAAG28XmCbMXAbbtkxfsO0ckr9obJO';
	?>
	<div class="d-flex justify-content-center h-100">
		<div class="card">
			<div class="card-header">
				<h3>Sign Up</h3>
				<div class="d-flex justify-content-end social_icon">
					<span><img src="assets/images/ezm-logo.png" style="width:120px;"></span>
				</div>
			</div>
			<div class="card-body">
			    <div class="alert alert-danger d-none" id="message"></div>
				<form class="singup_form">
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="text" class="form-control" placeholder="username" name="username" id="username" required>
					</div>
                    <div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fa fa-envelope" aria-hidden="true"></i></span>
						</div>
						<input type="email" class="form-control" placeholder="email" name="email" id="email" required>
						
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-key"></i></span>
						</div>
						<input type="password" class="form-control" placeholder="new password" name="new_password" id="new_password" required>
					</div>
                    <div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-key"></i></span>
						</div>
						<input type="password" class="form-control" placeholder="confirm password" name="confirm_password" id="confirm_password" required>
					</div>
					<div class="g-recaptcha" data-sitekey="<?php echo $site_key; ?>"></div>
					<div id="mail-status"></div>
					<div class="form-group">
						<input type="button" value="SignUp" class="btn float-right" onclick="registerButton()">
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="scripts/database.js"></script>
<script src="https://www.google.com/recaptcha/api.js"></script>

</body>
</html>