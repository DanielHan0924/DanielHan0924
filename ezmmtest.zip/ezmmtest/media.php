<?php 
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';

        $sql = "SELECT * FROM media WHERE username='".$_SESSION['username']."';";
        $result = $conn->query($sql);
        $resultCount = mysqli_num_rows($result);

        $conn->close();
    } else {
        header('Location: login.php');
    }
?>
<div class="page-title-heading">
    <div>
        <h3>MEDIA</h3>
    </div>
</div>
</div>
</div>

<div class="row">
    <div class="col-md-12">
        <form class="longforms" id="media-form">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            
                            <h5 class="card-title custom-head">MEDIA</h5>
                        </div>
                        <!-- <div class="col-lg-2">
                            <div class="image-holder">
                                <img src="assets/images/oldman.jpeg" />
                                <div class="d-block text-center card-footer">
                                    <button class="btn-sm btn-block btn btn-success" onclick="saveMediaForm()">Save</button>
                                </div>
                            </div>
                        </div> -->
                    </div>

                </div>
                <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                    <div class="card">
                        <div id="headingOne" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">NEWSPAPER</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                            <?php
                                if ($resultCount > 0) {
                                    $i = 0;
                                    while($media = mysqli_fetch_assoc($result)) { 
                                        $i ++;
                                        if ($i == $resultCount) { ?>
                                            <div class="card-body" id="media_child">
                                        <?php } else { ?>
                                            <div class="card-body">
                                        <?php }
                                            include('inc/newspaper.php'); ?>
                                        </div>
                                    <?php } 
                                } else { ?>
                                    <div class="card-body" id="media_child">
                                        <?php include('inc/newspaper.php'); ?>
                                    </div>
                                <?php }
                            ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="d-block text-center card-footer">
                                        <button type="button" class="btn-wide btn btn-warning pull-left" onclick="addChildForm('media_child')">Add Newspaper</button>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                    <div class="card">
                        <div id="headingOne" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">RADIO</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                            <div class="card-body">
                                <!--PLACEHOLDER FOR INC FILE-->

                            </div>
                        </div>
                    </div>
                    
                    

                </div>
                <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                    <div class="card">
                        <div id="headingOne" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">TELEVISION</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                            <div class="card-body">
                                <!--PLACEHOLDER FOR INC FILE-->

                            </div>
                        </div>
                    </div>
                    
                    

                </div>
                <div class="d-block text-center card-footer">
                    <button type="button" class="btn-wide btn btn-primary pull-left">Back to Home</button>
                    <button class="btn-wide btn btn-success pull-right" onclick="saveMediaForm()">Save</button>
                </div>

            </div>
        </form>
    </div>
</div>

<?php include('inc/footer.php'); ?>
