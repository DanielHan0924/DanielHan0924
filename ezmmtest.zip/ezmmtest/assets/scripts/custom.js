
$(document).ready(function() {
    // alert(localStorage.getItem("caseID"));
    /** Report redirect */
    $("#btn_preneedreport").click(function(){
       location.assign('report_preneed.php');
    });
    $("#btn_visitorsreport").click(function(){
        location.assign('report_visitors.php');
     });
     $("#btn_statementreport").click(function(){
        location.assign('report_statement.php');
     });
    /** for adding/editing/deleting subform switch*/ 
    $(".editsubform").hide();
    $(".addsubform").hide();
    $(".delsubform").hide();
    $(".btn-switchsubform-add").click(function(){
        $(".addsubform").show();
        $(".editsubform").hide();
        $(".delsubform").hide();
        $(".switchsubform").hide();
    });
    $(".btn-switchsubform-edit").click(function(){
        $(".editsubform").show();
        $(".addsubform").hide();
        $(".delsubform").hide();
        $(".switchsubform").hide();
    }); 
    $(".btn-switchsubform-delete").click(function(){
        $(".delsubform").show();
        $(".addsubform").hide();
        $(".editsubform").hide();
        $(".switchsubform").hide();
    });
    $(".btn-link-back").click(function(){
        $(".editsubform").hide();
        $(".addsubform").hide();
        $(".delsubform").hide();
        $(".switchsubform").show();
    }); 

    /**for image preview  */ 
    $(".imgAdd").click(function(){
        $(this).closest(".row").find('.imgAdd').before('<div class="col-sm-2 imgUp"><div class="imagePreview"></div><label class="btn btn-primary">Upload<input type="file" class="uploadFile img" value="Upload Photo" style="width:0px;height:0px;overflow:hidden;"></label><i class="fa fa-times del"></i></div>');
    });
    $(document).on("click", "i.del" , function() {
        $(this).parent().remove();
    });
    /** Image preview/upload in Person Who Called sub-section */
    $(document).on("change",".uploadFile", function()
    {
        var uploadFile = $(this);
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support

        if (/^image/.test( files[0].type)){ // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file
            reader.onloadend = function(){ // set image data as background of div
            uploadFile.closest(".imgUp").find('.imagePreview').css("background", "url("+this.result+") no-repeat center center");
            uploadFile.closest(".imgUp").find('.imagePreview').css("background-size", "auto 100%");
            // $(".testimageview").attr("src", this.result);
            }
        }
    });

/* Showing hidden subForms in Military Service Honor sub-section */
    $('#MSH_Gravemarker').change(function() {
        $("#subform_gravemarker").toggle(this.checked);
    });
    $('#MSH_Flag').change(function() {
        $("#subform_DrapedAndFolded").prop("hidden", !(this.checked));
    });

/* Showing hidden subForms in Statement Goods/Services section */
    $( "#SOGS_merchandise_casket" ).focus(function() {
        $("#casket-form").prop('hidden', false);
        $("#outer-form").prop('hidden', true);
    });
    $( "#SOGS_merchandise_obc" ).focus(function() {
        $("#outer-form").prop('hidden', false);
        $("#casket-form").prop('hidden', true);
    });
    $( "#btn_casket_form" ).click(function() {
        $("#casket-form").prop('hidden', true);
    });
    $( "#btn_obc_form" ).click(function() {
        $("#outer-form").prop('hidden', true);
    });

    $('#PI_checkEnable').change(function(){
        if($(this).is(':checked')) {
            $("#PI_hiddendatetime").prop('hidden', false);
            $("#PI_dod").prop('required', true);
            $("#PI_tode").prop('required', true);
            $(".subm_convert").prop('disabled', false);
        } else {
            $("#PI_hiddendatetime").prop('hidden', true);
            $("#PI_dod").prop('required', false);
            $("#PI_tode").prop('required', false);
            $(".subm_convert").prop('disabled', true);
        }
    });

    $('#NOK_checkEnable').change(function(){
        if($(this).is(':checked')) {
            $("#NOK_radio").prop('hidden', false);
            $(".subm_convert").prop('disabled', false);
        } else {
            $("#NOK_radio").prop('hidden', true);
            $(".subm_convert").prop('disabled', true);
        }
    });

    $('#PI_checkEnable').change(function(){
        if($(this).is(':checked')) {
            // Checkbox is checked..
            $("#NOK_radio").prop('hidden', false);
            $(".subm_convert").prop('disabled', false);
        } else {
            // Checkbox is not checked..
            $("#NOK_radio").prop('hidden', true);
            $(".subm_convert").prop('disabled', true);
        }
    });
    $('.convert_checkEnable').change(function(){
        if($(this).is(':checked')) {
            // Checkbox is checked..
            $(".table_radio").prop('hidden', false);
            $(".subm_convert").prop('disabled', false);
        } else {
            // Checkbox is not checked..
            $(".table_radio").prop('hidden', true);
            $(".subm_convert").prop('disabled', true);
        }
    });

    /** change the value of checkboxes whenever clicking it */
    $('.SOGS_permanent').click(function(e) {
        if (e.target.checked) {
            $(this).val('Y');
        } else {
            $(this).val('N');
        }
    });
    $('input[type=checkbox]').click(function(e) {
        if (e.target.checked) {
            $(this).val('Y');
            // alert($(this).val());
        } else {
            $(this).val('N');
        }
    });

    var subm="";      // To use clicked buttonValue whenever formSubmit event.
    var optionID = 1; // To use clicked optionId whenever formSubmit event.

    /* Getting selectoption clicking events on all recurring sub-sections. */
    $(document).on("change","#HPB_case_select", function()
    {
        optionID = $(this).val();// selected caseID
        var recurringTable = $("#recurrings_table_honorarypallbearer").val();
        $.ajax({
            type: "POST",
            url: "getRecurrings_multi.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    var order = 1;
                    $('.multi-select-custom').html('');
                    $.each(result.data, function(i, e){
                        var year = result.data[i];
                        var single_select = "<div class='col-md-2'><select name='HPB_select' id='HPB_select' class='form-control HPB_select'><option hidden> Pallbearer "+order+" </option><option value='"+year.id+"' >"+year.fullname+"</option></select></div>";
                        $('.multi-select-custom').append(single_select);
                        order++;
                    });
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#PB_case_select", function()
    {
        optionID = $(this).val();// selected caseID
        var recurringTable = $("#recurrings_table_pallbearer").val();
        $.ajax({
            type: "POST",
            url: "getRecurrings_multi.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    var order = 1;
                    $('.multi-select-custom').html('');
                    $.each(result.data, function(i, e){
                        var year = result.data[i];
                        var single_select = "<div class='col-md-2'><select name='PB_select' id='PB_select' class='form-control PB_select'><option hidden> Pallbearer "+order+" </option><option value='"+year.id+"' >"+year.fullname+"</option></select></div>";
                        $('.multi-select-custom').append(single_select);
                        order++;
                    });
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#MS_case_select", function()
    {
        optionID = $(this).val();// selected caseID
        var recurringTable = $("#recurrings_table_marital").val();
        $.ajax({
            type: "POST",
            url: "getRecurrings_multi.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    var order = 1;
                    $('.multi-select-custom').html('');
                    $.each(result.data, function(i, e){
                        var year = result.data[i];
                        var single_select = "<div class='col-md-2'><select name='MS_select' id='MS_select' class='form-control MS_select'><option hidden> Marital Status "+order+" </option><option value='"+year.id+"' >"+year.maritalstatus+"</option></select></div>";
                        $('.multi-select-custom').append(single_select);
                        order++;
                    });
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#FLOR_case_select", function()
    {
        optionID = $(this).val();// selected caseID
        var recurringTable = $("#recurrings_table_florist").val();
        $.ajax({
            type: "POST",
            url: "getRecurrings_multi.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    var order = 1;
                    $('.multi-select-custom').html('');
                    $.each(result.data, function(i, e){
                        var year = result.data[i];
                        var single_select = "<div class='col-md-2'><select name='FLOR_select' id='FLOR_select' class='form-control FLOR_select'><option hidden> Florist "+order+" </option><option value='"+year.id+"' >"+year.fullname+"</option></select></div>";
                        $('.multi-select-custom').append(single_select);
                        order++;
                    });
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#MSH_case_select", function()
    {
        optionID = $(this).val();// selected caseID
        var recurringTable = $("#recurrings_table_militaryservice").val();
        $.ajax({
            type: "POST",
            url: "getRecurrings_multi.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    var order = 1;
                    $('.multi-select-custom').html('');
                    $.each(result.data, function(i, e){
                        var year = result.data[i];
                        var single_select = "<div class='col-md-2'><select name='MSH_select' id='MSH_select' class='form-control MSH_select'><option hidden> Honor "+order+" </option><option value='"+year.id+"' >"+year.honor1+"</option></select></div>";
                        $('.multi-select-custom').append(single_select);
                        order++;
                    });
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#SUREL_case_select", function()
    {
        optionID = $(this).val();// selected caseID
        var recurringTable = $("#recurrings_table_survivingrelative").val();
        $.ajax({
            type: "POST",
            url: "getRecurrings_multi.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    var order = 1;
                    $('.multi-select-custom').html('');
                    $.each(result.data, function(i, e){
                        var year = result.data[i];
                        var singlle_select = "<div class='col-md-2'><select name='SUREL_select' id='SUREL_select' class='form-control SUREL_select'><option hidden> Relative "+order+" </option><option value='"+year.id+"' >"+year.fullname+"</option></select></div>";
                        $('.multi-select-custom').append(singlle_select);
                        order++;
                    });
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#VISITOR_case_select", function()
    {
        optionID = $(this).val();// selected caseID
        var recurringTable = $("#recurrings_table_visitor").val();
        $.ajax({
            type: "POST",
            url: "getRecurrings_multi.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    var order = 1;
                    $('.multi-select-custom').html('');
                    $.each(result.data, function(i, e){
                        var year = result.data[i];
                        var singlle_select = "<div class='col-md-2'><select name='VISITOR_select' id='VISITOR_select' class='form-control VISITOR_select'><option hidden> Visitor "+order+" </option><option value='"+year.id+"' >"+year.Name+"</option></select></div>";
                        $('.multi-select-custom').append(singlle_select);
                        order++;
                    });
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#NOK_case_select", function()
    {
        optionID = $(this).val();// selected caseID
        var recurringTable = $("#recurrings_table_nextofkin").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings_multi.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.numrow);
                    console.log(result.data);
                    // var array = $.map(result.data, function(value, index) {
                    //     return [value];
                    // });
                    var order = 1;
                    $('.multi-select-custom').html('');
                    $.each(result.data, function(i, e){
                        var year = result.data[i];
                        var singlle_select = "<div class='col-md-2'><select name='NOK_select' id='NOK_select' class='form-control NOK_select'><option hidden> Next of kin "+order+" </option><option value='"+year.id+"' >"+year.fullname+"</option></select></div>";
                        $('.multi-select-custom').append(singlle_select);
                        order++;
                    });
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#CLD_case_select", function()
    {
        optionID = $(this).val();// selected caseID
        var recurringTable = $("#recurrings_table_children").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings_multi.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.numrow);
                    console.log(result.data);
                    // var array = $.map(result.data, function(value, index) {
                    //     return [value];
                    // });
                    var order = 1;
                    $('.multi-select-custom').html('');
                    $.each(result.data, function(i, e){
                        var year = result.data[i];
                        var singlle_select = "<div class='col-md-2'><select name='CLD_select' id='CLD_select' class='form-control CLD_select'><option hidden>Child "+order+" </option><option value='"+year.id+"' >"+year.fullname+"</option></select></div>";
                        $('.multi-select-custom').append(singlle_select);
                        order++;
                    });
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#INF_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_informant").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#INF_InformantName").val(result.data.InformantName);
                    $("#INF_SSN").val(result.data.SSN);
                    $("#INF_Email").val(result.data.Email);
                    $("#INF_phone").val(result.data.Phone);
                    $("#INF_InvoiceDate").val(result.data.InvoiceDate);
                    $("#INF_DueDate").val(result.data.DueDate);
                    $("#INF_Address1").val(result.data.Address1);
                    $("#INF_Address2").val(result.data.Address2);
                    $("#INF_City").val(result.data.City);
                    $("#INF_State").val(result.data.States);
                    $("#INF_Zip").val(result.data.Zip);
                    $("#INF_note").val(result.data.note);
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#DES_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#hasphoto_table_deceasedinfo").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#DES_firstname").val(result.data.firstName);
                    $("#DES_lastname").val(result.data.lastName);
                    $("#DES_DOB").val(result.data.dateOfBirth);
                    $("#DES_DOD").val(result.data.dateOfDeath);
                    $("#DES_citizenship").val(result.data.Citizenship);
                    $("#DES_race").val(result.data.Race);
                    $("#DES_religion").val(result.data.Religion);
                    $("#DES_PlaceOfBirth").val(result.data.PlaceOfBirth);
                    $("#DES_ancestry").val(result.data.Ancestry);
                    $("#DES_Business").val(result.data.Business);
                    $("#DES_occupation").val(result.data.States);
                    $("#DES_InCommunitySInce").val(result.data.InCommunitySInce);
                    $("#DES_MovedFrom").val(result.data.MovedFrom);
                    //show photo
                    $(".uploadedFile_casebiophoto").css("background", "url(uploads/casebiophoto/"+result.data.Photo+") no-repeat center center");
                    $(".uploadedFile_casebiophoto").css("background-size", "auto 100%");
                    //show header line information
                    $fullname = $("#DES_firstname").val();
                    $lastname = $("#DES_lastname").val();
                    $DOB = $("#DES_DOB").val();
                    $DOD = $("#DES_DOD").val();
                    $ageAtDeath = new Date(new Date($DOD) - new Date($DOB)).getFullYear() - 1970;
                    $(".greyHeaderInformations").html($fullname + ':  ' + $DOB + ' to '+ $DOD + ' ( Death at  '+$ageAtDeath + '  years old )' );

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#DOCU_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#hasphoto_table_document").val();
        $('#subm_deldoc').prop('disabled',false);

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show file
                    var pdffile_url = "uploads/documents/"+result.data.filename;
                    var ext = result.data.filename.slice(-4); //get extension of the file
                    if (ext === '.pdf' || ext === '.txt') { 
                        $('#div_pdfviewer').prop('hidden',false);
                    } else { $('#div_pdfviewer').prop('hidden',true); }
                    $('#pdfviewer').attr('src',pdffile_url);   
                    $('#docpreview').append('<a href="' + pdffile_url + '" target="_blank">' + result.data.filename + '</a>');
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#IMAGE_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#hasphoto_table_image").val();
        $('#subm_delimage').prop('disabled',false);

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show photo
                    //show file
                    var pdffile_url = "uploads/images/"+result.data.filename;
                    $(".div_testimageview").prop('hidden', false);
                    $(".testimageview").prop("src", "uploads/images/"+result.data.filename);
                    $('#imgpreview').append('<a href="' + pdffile_url + '" target="_blank">' + result.data.filename + '</a>');
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#VIS_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_visitation").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#VIS_StartDate").val(result.data.StartDate);
                    $("#VIS_StartTime").val(result.data.StartTime);
                    $("#VIS_EndDate").val(result.data.EndDate);
                    $("#VIS_EndTime").val(result.data.EndTime);
                    $("#VIS_Visitation").val(result.data.VisitationName);
                    $("#VIS_Address").val(result.data.VisitationAddress);
                    $("#VIS_City").val(result.data.city);
                    $("#VIS_State").val(result.data.states);
                    $("#VIS_Telephone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#COS_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_cosmetologist").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#COS_FullName").val(result.data.fullname);
                    $("#COS_Email").val(result.data.email);
                    $("#COS_Address1").val(result.data.address1);
                    $("#COS_Address2").val(result.data.address2);
                    $("#COS_City").val(result.data.city);
                    $("#COS_State").val(result.data.states);
                    $("#COS_Zip").val(result.data.zip);
                    $("#COS_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#VOC_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_vocalist").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#VOC_FullName").val(result.data.fullname);
                    $("#VOC_Email").val(result.data.email);
                    $("#VOC_Address1").val(result.data.address1);
                    $("#VOC_Address2").val(result.data.address2);
                    $("#VOC_City").val(result.data.city);
                    $("#VOC_State").val(result.data.states);
                    $("#VOC_Zip").val(result.data.zip);
                    $("#VOC_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#ORG_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_organist").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#ORG_FullName").val(result.data.fullname);
                    $("#ORG_Email").val(result.data.email);
                    $("#ORG_Address1").val(result.data.address1);
                    $("#ORG_Address2").val(result.data.address2);
                    $("#ORG_City").val(result.data.city);
                    $("#ORG_State").val(result.data.states);
                    $("#ORG_Zip").val(result.data.zip);
                    $("#ORG_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#BB_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_beauticianbarber").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#BB_FullName").val(result.data.fullname);
                    $("#BB_Email").val(result.data.email);
                    $("#BB_Address1").val(result.data.address1);
                    $("#BB_Address2").val(result.data.address2);
                    $("#BB_City").val(result.data.city);
                    $("#BB_State").val(result.data.states);
                    $("#BB_Zip").val(result.data.zip);
                    $("#BB_phone").val(result.data.phone);
                    // $("#BB_gender").val(result.data.gender);
                    $("input[name=BB_gender][value=" + result.data.gender + "]").prop('checked', true);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#PB_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_pallbearer").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#PB_FullName").val(result.data.fullname);
                    $("#PB_Email").val(result.data.email);
                    $("#PB_Address1").val(result.data.address1);
                    $("#PB_Address2").val(result.data.address2);
                    $("#PB_City").val(result.data.city);
                    $("#PB_State").val(result.data.states);
                    $("#PB_Zip").val(result.data.zip);
                    $("#PB_phone").val(result.data.phone);
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change",".HPB_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_honorarypallbearer").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#HPB_FullName").val(result.data.fullname);
                    $("#HPB_Email").val(result.data.email);
                    $("#HPB_Address1").val(result.data.address1);
                    $("#HPB_Address2").val(result.data.address2);
                    $("#HPB_City").val(result.data.city);
                    $("#HPB_State").val(result.data.states);
                    $("#HPB_Zip").val(result.data.zip);
                    $("#HPB_phone").val(result.data.phone);
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#CHUR_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_clergy").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#CHUR_FullName").val(result.data.fullname);
                    $("#CHUR_Email").val(result.data.email);
                    $("#CHUR_Address1").val(result.data.address1);
                    $("#CHUR_Address2").val(result.data.address2);
                    $("#CHUR_City").val(result.data.city);
                    $("#CHUR_State").val(result.data.states);
                    $("#CHUR_Zip").val(result.data.zip);
                    $("#CHUR_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#DRV_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_driver").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#DRV_FullName").val(result.data.fullname);
                    $("#DRV_Email").val(result.data.email);
                    $("#DRV_Address1").val(result.data.address1);
                    $("#DRV_Address2").val(result.data.address2);
                    $("#DRV_City").val(result.data.city);
                    $("#DRV_State").val(result.data.states);
                    $("#DRV_Zip").val(result.data.zip);
                    $("#DRV_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#ESC_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_escort").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#ESC_FullName").val(result.data.fullname);
                    $("#ESC_Email").val(result.data.email);
                    $("#ESC_Address1").val(result.data.address1);
                    $("#ESC_Address2").val(result.data.address2);
                    $("#ESC_City").val(result.data.city);
                    $("#ESC_State").val(result.data.states);
                    $("#ESC_Zip").val(result.data.zip);
                    $("#ESC_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#FLOR_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_florist").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#FLOR_FullName").val(result.data.fullname);
                    $("#FLOR_Email").val(result.data.email);
                    $("#FLOR_Address1").val(result.data.address1);
                    $("#FLOR_Address2").val(result.data.address2);
                    $("#FLOR_City").val(result.data.city);
                    $("#FLOR_State").val(result.data.states);
                    $("#FLOR_Zip").val(result.data.zip);
                    $("#FLOR_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#SEX_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_sexton").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#SEX_FullName").val(result.data.fullname);
                    $("#SEX_Email").val(result.data.email);
                    $("#SEX_Address1").val(result.data.address1);
                    $("#SEX_Address2").val(result.data.address2);
                    $("#SEX_City").val(result.data.city);
                    $("#SEX_State").val(result.data.states);
                    $("#SEX_Zip").val(result.data.zip);
                    $("#SEX_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#SER_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_service").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#SER_StartDate").val(result.data.StartDate);
                    $("#SER_StartTime").val(result.data.StartTime);
                    $("#SER_EndDate").val(result.data.EndDate);
                    $("#SER_EndTime").val(result.data.EndTime);
                    $("#SER_Service").val(result.data.ServiceName);
                    $("#SER_Address").val(result.data.ServiceAddress);
                    $("#SER_City").val(result.data.city);
                    $("#SER_State").val(result.data.states);
                    $("#SER_Telephone").val(result.data.Telephone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#FUNHOMCRE_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_funhomcre").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#FUNHOMCRE_FullName").val(result.data.fullname);
                    $("#FUNHOMCRE_Contact").val(result.data.contact);
                    $("#FUNHOMCRE_l").val(result.data.license);
                    $("#FUNHOMCRE_Email").val(result.data.email);
                    $("#FUNHOMCRE_Address1").val(result.data.address1);
                    $("#FUNHOMCRE_Address2").val(result.data.address2);
                    $("#FUNHOMCRE_City").val(result.data.city);
                    $("#FUNHOMCRE_State").val(result.data.states);
                    $("#FUNHOMCRE_Zip").val(result.data.zip);
                    $("#FUNHOMCRE_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#CEM_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_cemetery").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#VOC_FullName").val(result.data.fullname);
                    $("#VOC_Email").val(result.data.email);
                    $("#VOC_Address1").val(result.data.address1);
                    $("#VOC_Address2").val(result.data.address2);
                    $("#VOC_City").val(result.data.city);
                    $("#VOC_State").val(result.data.states);
                    $("#VOC_Zip").val(result.data.zip);
                    $("#VOC_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#CG_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_colorguard").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#VOC_FullName").val(result.data.fullname);
                    $("#VOC_Email").val(result.data.email);
                    $("#VOC_Address1").val(result.data.address1);
                    $("#VOC_Address2").val(result.data.address2);
                    $("#VOC_City").val(result.data.city);
                    $("#VOC_State").val(result.data.states);
                    $("#VOC_Zip").val(result.data.zip);
                    $("#VOC_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#DTB_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_distributor").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#VOC_FullName").val(result.data.fullname);
                    $("#VOC_Email").val(result.data.email);
                    $("#VOC_Address1").val(result.data.address1);
                    $("#VOC_Address2").val(result.data.address2);
                    $("#VOC_City").val(result.data.city);
                    $("#VOC_State").val(result.data.states);
                    $("#VOC_Zip").val(result.data.zip);
                    $("#VOC_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#EQU_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_equipment").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#VOC_FullName").val(result.data.fullname);
                    $("#VOC_Email").val(result.data.email);
                    $("#VOC_Address1").val(result.data.address1);
                    $("#VOC_Address2").val(result.data.address2);
                    $("#VOC_City").val(result.data.city);
                    $("#VOC_State").val(result.data.states);
                    $("#VOC_Zip").val(result.data.zip);
                    $("#VOC_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#MANU_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_manufacturer").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#VOC_FullName").val(result.data.fullname);
                    $("#VOC_Email").val(result.data.email);
                    $("#VOC_Address1").val(result.data.address1);
                    $("#VOC_Address2").val(result.data.address2);
                    $("#VOC_City").val(result.data.city);
                    $("#VOC_State").val(result.data.states);
                    $("#VOC_Zip").val(result.data.zip);
                    $("#VOC_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#SALER_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_saleperson").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#VOC_FullName").val(result.data.fullname);
                    $("#VOC_Email").val(result.data.email);
                    $("#VOC_Address1").val(result.data.address1);
                    $("#VOC_Address2").val(result.data.address2);
                    $("#VOC_City").val(result.data.city);
                    $("#VOC_State").val(result.data.states);
                    $("#VOC_Zip").val(result.data.zip);
                    $("#VOC_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#VOLN_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_volunteer").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#VOLN_FullName").val(result.data.fullname);
                    $("#VOLN_Address1").val(result.data.address1);
                    $("#VOLN_Address2").val(result.data.address2);
                    $("#VOLN_City").val(result.data.city);
                    $("#VOLN_State").val(result.data.states);
                    $("#VOLN_Zip").val(result.data.zip);
                    $("#VOLN_Email").val(result.data.email);
                    $("#VOLN_phone").val(result.data.phone);
                    $("#VOLN_phone2").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#MSH_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_militaryservice").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#MSH_honors").val(result.data.honor1);
                    $("#MSH_Contacted").val(result.data.contacted);
                    $("#MSH_FullName").val(result.data.fullname);
                    $("#MSH_rank").val(result.data.rank);
                    $("#MSH_warcampaign").val(result.data.WarCampaignID);
                    $("#MSH_Awards").val(result.data.honor2);
                    $("#MSH_DateOfBirth").val(result.data.dob);
                    $("#MSH_DateOfDeath").val(result.data.dod);
                    $("#MSH_Inscription").val(result.data.inscription);

                    // checkbox review
                    result.data.flag == 'Y'? $("#MSH_Flag").prop('checked', true):$("#MSH_Flag").prop('checked', false);
                    result.data.cologuard == 'Y'? $("#MSH_HonorGuard").prop('checked', true):$("#MSH_HonorGuard").prop('checked', false);
                    result.data.caission == 'Y'? $("#MSH_DD214").prop('checked', true):$("#MSH_DD214").prop('checked', false);
                    result.data.gravemarker == 'Y'? $("#MSH_Gravemarker").prop('checked', true):$("#MSH_Gravemarker").prop('checked', false);
                    result.data.draped == 'Y'? $("#MSH_Draped").prop('checked', true):$("#MSH_Draped").prop('checked', false);
                    result.data.folded == 'Y'? $("#MSH_Folded").prop('checked', true):$("#MSH_Folded").prop('checked', false);

                    // toggle the marker modal in case the gravemarker is checked
                    if (result.data.gravemarker == 'Y') {
                        $("#subform_gravemarker").toggle(true);   

                    } 
                    if (result.data.flag == 'Y') {
                        $("#subform_DrapedAndFolded").prop("hidden", false);
                    }
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    
    $(document).on("change","#CHU_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_church").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#CHU_Church").val(result.data.Church);
                    $("#CHU_ClergyName").val(result.data.ClergyName);
                    $("#CHU_Address1").val(result.data.Address1);
                    $("#CHU_Address2").val(result.data.Address2);
                    $("#CHU_City").val(result.data.city);
                    $("#CHU_State").val(result.data.states);
                    $("#CHU_Zip").val(result.data.zip);
                    $("#CHU_Email").val(result.data.Email);
                    $("#CHU_phone").val(result.data.phone);
                    $("#CHU_phone2").val(result.data.phone2);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#POW_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_placeofworship").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#POW_PlaceOfWorship").val(result.data.PlaceOfWorship);
                    $("#POW_ClergyName").val(result.data.ClergyName);
                    $("#POW_Address1").val(result.data.Address1);
                    $("#POW_Address2").val(result.data.Address2);
                    $("#POW_City").val(result.data.city);
                    $("#POW_State").val(result.data.states);
                    $("#POW_Zip").val(result.data.zip);
                    $("#POW_Email").val(result.data.email);
                    $("#POW_phone").val(result.data.phone);
                    $("#POW_phone2").val(result.data.phone2);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#EDU_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_education").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#EDU_highschool").val(result.data.EduHighSchool);
                    $("#EDU_undergraduatename").val(result.data.undergraducate);
                    $("#EDU_undergraducatedegree").val(result.data.undergraducatedegree);
                    $("#EDU_graduatename").val(result.data.graduate);
                    $("#EDU_graducatedegree").val(result.data.graducatedegree);
                    

                    // checkbox review
                    result.data.EduHSGraduated == 'Y'? $("#EDU_EduHSGraduated").prop('checked', true):$("#EDU_EduHSGraduated").prop('checked', false);
                    result.data.undergraducatedegreecheck == 'Y'? $("#EDU_undergraducatedegreecheck").prop('checked', true):$("#EDU_undergraducatedegreecheck").prop('checked', false);
                    result.data.graducatedegreecheck == 'Y'? $("#EDU_graducatedegreecheck").prop('checked', true):$("#EDU_graducatedegreecheck").prop('checked', false);                    
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#PAT_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_parentdeceased").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#PAT_ParentDeceasedFathersDOB").val(result.data.ParentDeceasedFathersDOB);
                    $("#PAT_ParentsDeceasedFathersDOD").val(result.data.ParentsDeceasedFathersDOD);
                    $("#PAT_ParentsDeceasedMothersDOB").val(result.data.ParentsDeceasedMothersDOB);
                    $("#PAT_ParentsDeceasedMothersDOD").val(result.data.ParentsDeceasedMothersDOD);
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#PAI_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_parentinfo").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#PAI_fatherName").val(result.data.FathersName);
                    $("#PAI_FDOB").val(result.data.FDOB);
                    $("#PAI_FPlaceOfBirth").val(result.data.FPlaceOfBirth);
                    $("#PAI_motherName").val(result.data.MothersName);
                    $("#PAI_maidenName").val(result.data.MothersMaidenName);
                    $("#PAI_MDOB").val(result.data.MDOB);
                    $("#PAI_MPlaceOfBirth").val(result.data.MPlaceOfBirth);
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#FDP_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_finaldisposition").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#FDP_DateOfFinalDisposition").val(result.data.DateOfFinalDisposition);
                    $("#FDP_FinalDisposition").val(result.data.FinalDisposition);
                    $("#FDP_cemetery").val(result.data.CemeteryID);
                    $("#FDP_Location").val(result.data.Location);
                    $("#FDP_Section").val(result.data.Section);
                    $("#FDP_FuneralOrMemorialServiceAtID").val(result.data.FuneralOrMemorialServiceAtID);
                    $("#FDP_NameLotRegisteredTo").val(result.data.NameLotRegisteredTo);
                    $("#FDP_WhereInLotIsGraveToBeOpened").val(result.data.WhereInLotIsGraveToBeOpened);
                    $("#FDP_LotNo").val(result.data.LotNo);
                    $("#FDP_GraveNo").val(result.data.GraveNo);

                    // checkbox review
                    result.data.Burial == 'Y'? $("#FDP_Burial").prop('checked', true):$("#FDP_Burial").prop('checked', false);
                    result.data.Entombment == 'Y'? $("#FDP_Entombment").prop('checked', true):$("#FDP_Entombment").prop('checked', false);
                    result.data.Cremation == 'Y'? $("#FDP_Cremation").prop('checked', true):$("#FDP_Cremation").prop('checked', false);
                    result.data.BurialAtSea == 'Y'? $("#FDP_BurialAtSea").prop('checked', true):$("#FDP_BurialAtSea").prop('checked', false);
                    
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });

    $(document).on("change","#SUREL_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_survivingrelative").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#SUREL_Name").val(result.data.fullname);
                    $("#SUREL_Email").val(result.data.email);
                    $("#SUREL_Address1").val(result.data.address1);
                    $("#SUREL_City").val(result.data.city);
                    $("#SUREL_State").val(result.data.states);
                    $("#SUREL_Zip").val(result.data.zip);
                    $("#SUREL_phone").val(result.data.phone);
                    $("#SUREL_relationship").val(result.data.relationship);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });

    $(document).on("change","#CNTR_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table").val();
        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#CNTR_funeralhome").val(result.data.funeralhome);
                    $("#CNTR_fullname").val(result.data.fullname);
                    $("#CNTR_address1").val(result.data.address1);
                    $("#CNTR_address2").val(result.data.address2);
                    $("#CNTR_city").val(parseInt(result.data.city));
                    $("#CNTR_state").val(result.data.states);
                    $("#CNTR_zip").val(parseInt(result.data.zip));
                    $("#CNTR_statelicense").val(result.data.statelicense);
                    $("#CNTR_stateissued").val(result.data.stateissued);
                    $("#CNTR_email").val(result.data.email);
                    $("#CNTR_phone").val(result.data.phone);
                    $("#CNTR_phone2").val(result.data.phone2);

                    result.data.bodypickkup == 'Y'? $("#CNTR_bodypickkup").prop('checked', true):$("#CNTR_bodypickkup").prop('checked', false);
                    result.data.embalm == 'Y'? $("#CNTR_embalm").prop('checked', true):$("#CNTR_embalm").prop('checked', false);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });

    $(document).on("change","#PWC_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_personwhocalled").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#PWC_FullName").val(result.data.WhoCalled);
                    $("#PWC_Address1").val(result.data.Address1);
                    $("#PWC_Address2").val(result.data.Address2);
                    $("#PWC_City").val(result.data.City);
                    $("#PWC_State").val(result.data.States);
                    $("#PWC_Zip").val(result.data.Zip);
                    $("#PWC_Email").val(result.data.Email);
                    $("#PWC_dayphone").val(result.data.dayphone);
                    $("#PWC_evephone").val(result.data.eveningphone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#POD_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_placeofdeath").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#POD_Physician").val(result.data.Physician);
                    $("#POD_Contact").val(result.data.ContactName);
                    $("#POD_Address1").val(result.data.Address1);
                    $("#POD_Address2").val(result.data.Address2);
                    $("#POD_city").val(result.data.City);
                    $("#POD_state").val(result.data.States);
                    $("#POD_zip").val(result.data.Zip);
                    $("#POD_Email").val(result.data.Email);
                    $("#POD_officephone").val(result.data.officephone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#LOC_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_location").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#LOC_Location").val(result.data.location);
                    $("#LOC_Contact").val(result.data.contact);
                    $("#LOC_Address1").val(result.data.Address1);
                    $("#LOC_Address2").val(result.data.Address2);
                    $("#LOC_city").val(result.data.City);
                    $("#LOC_state").val(result.data.States);
                    $("#LOC_zip").val(result.data.Zip);
                    $("#LOC_Email").val(result.data.Email);
                    $("#LOC_phone").val(result.data.phone);
                    $("#LOC_dod").val(result.data.dod);
                    $("#LOC_tode").val(result.data.tode);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#PHY_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_physician").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#PHY_Physician").val(result.data.Physician);
                    $("#PHY_Contact").val(result.data.ContactName);
                    $("#PHY_Address1").val(result.data.Address1);
                    $("#PHY_Address2").val(result.data.Address2);
                    $("#PHY_city").val(result.data.City);
                    $("#PHY_state").val(result.data.States);
                    $("#PHY_zip").val(result.data.Zip);
                    $("#PHY_Email").val(result.data.Email);
                    $("#PHY_officephone").val(result.data.officephone);
                    $("#PHY_cellphone").val(result.data.cellphone);
                    $("#PHY_pager").val(result.data.pager);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });

    $(document).on("change","#CLD_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_children").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#CLD_FullName").val(result.data.fullname);
                    $("#CLD_Address1").val(result.data.address1);
                    $("#CLD_Address2").val(result.data.address2);
                    $("#CLD_City").val(result.data.city);
                    $("#CLD_State").val(result.data.states);
                    $("#CLD_Zip").val(result.data.zip);
                    $("#CLD_DOB").val(result.data.dob);
                    $("#CLD_relationship").val(result.data.relationship);
                    $("#CLD_Email").val(result.data.email);
                    $("#CLD_phone2").val(result.data.phone2);
                    $("#CLD_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    
    $(document).on("change","#GCLD_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_grandchildren").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#GCLD_FullName").val(result.data.fullname);
                    $("#GCLD_Address1").val(result.data.address1);
                    $("#GCLD_Address2").val(result.data.address2);
                    $("#GCLD_City").val(result.data.city);
                    $("#GCLD_State").val(result.data.states);
                    $("#GCLD_Zip").val(result.data.zip);
                    $("#GCLD_DOB").val(result.data.dob);
                    $("#GCLD_relationship").val(result.data.relationship);
                    $("#GCLD_Email").val(result.data.email);
                    $("#GCLD_phone2").val(result.data.phone2);
                    $("#GCLD_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#GGCLD_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_ggchildren").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#GGCLD_FullName").val(result.data.fullname);
                    $("#GGCLD_Address1").val(result.data.address1);
                    $("#GGCLD_Address2").val(result.data.address2);
                    $("#GGCLD_City").val(result.data.city);
                    $("#GGCLD_State").val(result.data.states);
                    $("#GGCLD_Zip").val(result.data.zip);
                    $("#GGCLD_DOB").val(result.data.dob);
                    $("#GGCLD_relationship").val(result.data.relationship);
                    $("#GGCLD_Email").val(result.data.email);
                    $("#GGCLD_phone2").val(result.data.phone2);
                    $("#GGCLD_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#GGGCLD_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_gggchildren").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#GGGCLD_FullName").val(result.data.fullname);
                    $("#GGGCLD_Address1").val(result.data.address1);
                    $("#GGGCLD_Address2").val(result.data.address2);
                    $("#GGGCLD_City").val(result.data.city);
                    $("#GGGCLD_State").val(result.data.states);
                    $("#GGGCLD_Zip").val(result.data.zip);
                    $("#GGGCLD_DOB").val(result.data.dob);
                    $("#GGGCLD_relationship").val(result.data.relationship);
                    $("#GGGCLD_Email").val(result.data.email);
                    $("#GGGCLD_phone2").val(result.data.phone2);
                    $("#GGGCLD_phone").val(result.data.phone);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });

    //for converting sub-forms in Pre-Need
    $(document).on("change","#PI_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_preneedpi").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#caseID").val(result.data.caseID);

                    $("#PI_honorificID").val(result.data.honorific);
                    $("#PI_firstname").val(result.data.firstName);
                    $("#PI_middlename").val(result.data.middleName);
                    $("#PI_lastname").val(result.data.lastName);
                    $("#PI_suffix").val(result.data.suffix);
                    $("#PI_address1").val(result.data.address1);
                    $("#PI_address2").val(result.data.address2);
                    $("#PI_township").val(result.data.township);
                    $("#PI_city").val(result.data.city);
                    $("#PI_state").val(result.data.states);
                    $("#PI_zip").val(result.data.zipCode);
                    $("#PI_county").val(result.data.country);
                    $("#PI_nickname").val(result.data.nickName);
                    $("#PI_gender").val(result.data.gender);
                    $("#PI_ssn").val(result.data.SSN);
                    $("#PI_email").val(result.data.email);
                    $("#PI_phone").val(result.data.phone);
                    $("#PI_dob").val(result.data.dateOfBirth);

                    $("#PI_dod").val(result.data.dateOfDeath);
                    $("#PI_tode").val(result.data.timeOfDeath);
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#PF_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_atneedpi").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#caseID").val(result.data.caseID);
                    $("#PF_honorific").val(result.data.honorific);
                    $("#PF_firstname").val(result.data.firstName);
                    $("#PF_middlename").val(result.data.middleName);
                    $("#PF_lastName").val(result.data.lastName);
                    $("#PF_suffix").val(result.data.suffix);
                    $("#PF_address1").val(result.data.address1);
                    $("#PF_address2").val(result.data.address2);
                    $("#PF_township").val(result.data.township);
                    $("#PF_city").val(result.data.city);
                    $("#PF_state").val(result.data.states);
                    $("#PF_zip").val(result.data.zipCode);
                    $("#PF_county").val(result.data.country);
                    $("#PF_nickname").val(result.data.nickName);
                    $("#PF_gender").val(result.data.gender);
                    $("#PF_ssn").val(result.data.SSN);
                    $("#PF_email").val(result.data.email);
                    $("#PF_phone").val(result.data.phone);
                    $("#PF_dob").val(result.data.dateOfBirth);
                    $("#PF_dod").val(result.data.dateOfDeath);
                    $("#PF_tode").val(result.data.timeOfDeath);
                    //show header line information
                    $fullname = $("#PF_firstname").val();
                    $DOB = $("#PF_dob").val();
                    $DOD = $("#PF_dod").val();
                    $ageAtDeath = new Date(new Date($DOD) - new Date($DOB)).getFullYear() - 1970;
                    $(".greyHeaderInformations").html($fullname + ':  ' + $DOB + ' to '+ $DOD + ' ( Death at  '+$ageAtDeath + '  years old )' );
                    
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#NOK_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_nextofkin").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#NOK_fullname").val(result.data.fullname);
                    $("#NOK_address1").val(result.data.address1);
                    $("#NOK_address2").val(result.data.address2);
                    $("#NOK_city").val(result.data.city);
                    $("#NOK_state").val(result.data.states);
                    $("#NOK_zip").val(result.data.zip);
                    $("#NOK_relationship").val(result.data.relationship);
                    $("#NOK_phone").val(result.data.phone);
                    $("#NOK_phone2").val(result.data.phone2);
                    $("#NOK_email").val(result.data.email);

                }else{
                    alert('wrong table name/sql'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    
    $(document).on("change","#MS_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_marital").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#MS_MaritalStatus").val(result.data.maritalstatus);
                    $("#MS_PlaceOfMarriage").val(result.data.placeofmarriage);
                    $("#MS_DateOfMarriage").val(result.data.dateofmarriage);
                    $("#MS_SpousesName").val(result.data.spousesname);
                    $("#MS_SDateOfDeath").val(result.data.dateofdeath);
                    $("#MS_SpousesPlaceOfDeath").val(result.data.spousesplaceofdeath);
                    // checkbox review
                    result.data.Spousedeceased == 'Y'? $("#MS_SpouseDeceased").prop('checked', true):$("#MS_SpouseDeceased").prop('checked', false);
                    
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#MLT_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_mlt").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#MLT_BranchID").val(result.data.BranchID);
                    $("#MLT_warcampaign").val(result.data.WarCampaignID);
                    $("#MLT_SerialNumber").val(result.data.SerialNumber);
                    $("#MLT_rank").val(result.data.Rank);
                    $("#MLT_EnlistmentDate").val(result.data.EnlistmentDate);
                    $("#MLT_DischargeDate").val(result.data.DischargeDate);
                    $("#MLT_typeofdischarge").val(result.data.TypeOfDischargeID);

                    // checkbox review
                    result.data.DD214 == 'Y'? $("#MLT_DD214").prop('checked', true):$("#MLT_DD214").prop('checked', false);
                    result.data.Headstone == 'Y'? $("#MLT_Headstone").prop('checked', true):$("#MLT_Headstone").prop('checked', false);
                    result.data.ApplicationForBurial == 'Y'? $("#MLT_ApplicationForBurial").prop('checked', true):$("#MLT_ApplicationForBurial").prop('checked', false);
                    result.data.ApplicationForFlag == 'Y'? $("#MLT_ApplicationForFlag").prop('checked', true):$("#MLT_ApplicationForFlag").prop('checked', false);
                    result.data.HonorGuard == 'Y'? $("#MLT_HonorGuard").prop('checked', true):$("#MLT_HonorGuard").prop('checked', false);

                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });

    $(document).on("change","#STFF_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#hasphoto_table_adminstaff").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    // alert(result.signinRole);
                    console.log(result.data);
                    //show the data via form
                    $("#STFF_name").val(result.data.username);
                    $("#STFF_email").val(result.data.email);
                    $("#STFF_email2").val(result.data.contactemail);
                    $("#STFF_address1").val(result.data.address1);
                    $("#STFF_address2").val(result.data.address2);
                    $("#STFF_city").val(result.data.city);
                    $("#STFF_state").val(result.data.states);
                    $("#STFF_zip").val(result.data.zip);
                    $("#STFF_phone").val(result.data.phone);
                    $("#STFF_hiredate").val(result.data.HireDate);
                    $("#STFF_termidate").val(result.data.TerminationDate);
                    $("#STFF_license").val(result.data.license);
                    $("#STFF_licenseddate").val(result.data.LicValidDate);
                    $("#STFF_state2").val(result.data.StateLicensed);
                    $("#STFF_note").val(result.data.note);

                    // checkbox review
                    result.data.cancreate == 'Y'? $("#STFF_canC").prop('checked', true):$("#STFF_canC").prop('checked', false);
                    result.data.canread == 'Y'? $("#STFF_canR").prop('checked', true):$("#STFF_canR").prop('checked', false);
                    result.data.canupdate == 'Y'? $("#STFF_canU").prop('checked', true):$("#STFF_canU").prop('checked', false);
                    result.data.candelete == 'Y'? $("#STFF_canD").prop('checked', true):$("#STFF_canD").prop('checked', false);

                    //show photo
                    $(".uploadedFile_staffphoto").css("background", "url(uploads/userphotos/"+result.data.photo+") no-repeat center center");
                    $(".uploadedFile_staffphoto").css("background-size", "auto 100%");

                    //disabled if the funeral home has already been activated by Superadmin.signinRole and if signinRole is not superadmin.
                    if (result.data.funstatus == 'Paid' && result.signinRole != 'superadmin') {
                        $("#STFF_name").prop('disabled', true);
                        $("#STFF_email").prop('disabled', true);
                        $("#STFF_email2").prop('disabled', true);
                        $("#STFF_address1").prop('disabled', true);
                        $("#STFF_address2").prop('disabled', true);
                        $("#STFF_city").prop('disabled', true);
                        $("#STFF_state").prop('disabled', true);
                        $("#STFF_zip").prop('disabled', true);
                        $("#STFF_phone").prop('disabled', true);
                        $("#STFF_hiredate").prop('disabled', true);
                        $("#STFF_termidate").prop('disabled', true);
                        $("#STFF_license").prop('disabled', true);
                        $("#STFF_licenseddate").prop('disabled', true);
                        $("#STFF_state2").prop('disabled', true); 
                        $("#STFF_canC").prop('disabled', true);
                        $("#STFF_canR").prop('disabled', true);
                        $("#STFF_canU").prop('disabled', true);
                        $("#STFF_canD").prop('disabled', true);
                        $('input[type=submit]').prop('disabled', true);
                    }else{
                        $("#STFF_name").prop('disabled', false);
                        $("#STFF_email").prop('disabled', false);
                        $("#STFF_email2").prop('disabled', false);
                        $("#STFF_address1").prop('disabled', false);
                        $("#STFF_address2").prop('disabled', false);
                        $("#STFF_city").prop('disabled', false);
                        $("#STFF_state").prop('disabled', false);
                        $("#STFF_zip").prop('disabled', false);
                        $("#STFF_phone").prop('disabled', false);
                        $("#STFF_hiredate").prop('disabled', false);
                        $("#STFF_termidate").prop('disabled', false);
                        $("#STFF_license").prop('disabled', false);
                        $("#STFF_licenseddate").prop('disabled', false);
                        $("#STFF_state2").prop('disabled', false); 
                        $("#STFF_canC").prop('disabled', false);
                        $("#STFF_canR").prop('disabled', false);
                        $("#STFF_canU").prop('disabled', false);
                        $("#STFF_canD").prop('disabled', false);
                        $('input[type=submit]').prop('disabled', false);
                    }
                }else{
                    alert('unknown error'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });

    $(document).on("change","#VISITOR_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_visitor").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#VISITOR_name").val(result.data.Name);
                    $("#VISITOR_email").val(result.data.Email);
                    $("#VISITOR_address1").val(result.data.Address1);
                    $("#VISITOR_address2").val(result.data.Address2);
                    $("#VISITOR_city").val(result.data.City);
                    $("#VISITOR_state").val(result.data.States);
                    $("#VISITOR_zip").val(result.data.Zip);
                    $("#VISITOR_phone").val(result.data.phone);
                    $("input[name=VISITOR_gift][value=" + result.data.gift + "]").prop('checked', true);

                }else{
                    alert('wrong table name/sql'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    
    $(document).on("change","#MSP_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_membership").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#MSP_name").val(result.data.Name);
                    $("#MSP_contact").val(result.data.Contact);
                    $("#MSP_address1").val(result.data.Address1);
                    $("#MSP_address2").val(result.data.Address2);
                    $("#MSP_city").val(result.data.City);
                    $("#MSP_state").val(result.data.States);
                    $("#MSP_zip").val(result.data.Zip);
                    $("#MSP_phone").val(result.data.phone);
                    $("#MSP_url").val(result.data.URL);
                }else{
                    alert('wrong table name/sql'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    $(document).on("change","#ORGAN_select", function()
    {
        optionID = $(this).val();
        var recurringTable = $("#recurrings_table_organization").val();

        $.ajax({
            type: "POST",
            url: "getRecurrings.php",
            dataType: 'json',
            data: { optionID: optionID, recurrings_table: recurringTable},
            success: function(result) {
                if(result.status == 'selected'){
                    console.log(result.data);
                    //show the data via form
                    $("#ORGAN_name").val(result.data.Name);
                    $("#ORGAN_contact").val(result.data.Contact);
                    $("#ORGAN_address1").val(result.data.Address1);
                    $("#ORGAN_address2").val(result.data.Address2);
                    $("#ORGAN_city").val(result.data.City);
                    $("#ORGAN_state").val(result.data.States);
                    $("#ORGAN_zip").val(result.data.Zip);
                    $("#ORGAN_phone").val(result.data.phone);
                    $("#ORGAN_url").val(result.data.URL);
                }else{
                    alert('wrong table name/sql'); 
                }
            },
            error: function(result) {
                console.log(result);
            }
        })
    });
    
    $('button[type=submit]').click(function(e) {
        subm = e.currentTarget.value;
    });
    $(".forms_recurring").submit(function(e) {
        e.preventDefault();
        var actionurl = e.currentTarget.action;
        var btn_submit_recurring = $(this).find(':button[type=submit]');
        btn_submit_recurring.prop('disabled', true);
        if(typeof($(".rowId").val())!='undefined')
        {
            optionID=$(".rowId").val();
        }
        var formserial = $(this).serialize() + '&postaction=' + subm + '&rowId=' + optionID;
        // var formData = new FormData($(this)[0]);
        console.log(formserial);
        $.ajax({
            type: "POST",
            url: actionurl,
            dataType: 'json',
            data: formserial,
            success: function(result) {
                console.log(result);
                if(result.status == 'exist'){
                    alert('There is already same option. Please create others.');
                }else if(result.status == 'created'){
                    alert('Successfully saved !');
                    location.reload();
                }else if(result.status == 'updated'){
                    alert('Successfully updated !');
                    location.reload();
                }else if(result.status == 'deleted'){
                    alert('Successfully deleted !');
                    location.reload();
                }else if(result.status == 'converted'){
                    alert('Successfully converted !');
                    location.reload();
                }else if(result.status == 'nocaseid'){
                    alert('No caseID created for further processing !');
                    location.reload();
                }else if(result.status == 'existcase'){
                    alert('there is already same caseID=' +result.existcaseID +' registered so only possible to Edit/Delete,please. !');
                    btn_submit_recurring.prop('disabled', false);
                }
            },
            error: function(result) {
                alert(result.status);
                console.log(result);
            }
        })
    });
    
    $(".forms_hasphoto").submit(function(e) {
        e.preventDefault();
        var actionurl = e.currentTarget.action;
        $(this).find(':input[type=submit]').prop('disabled', true);
        // $(this).find(':input[type=submit]').html('Processing …');
        if(typeof($(".rowId").val())!='undefined')
        {
            optionID=$(".rowId").val();
        }
        var formData = new FormData($(this)[0]);
        formData.append("postaction", subm);
        formData.append("rowId", optionID);
        console.log(formData);

        $.ajax({
            type: "POST",
            url: actionurl,
            dataType: 'json',
            data: formData,
            processData: false,
            contentType: false,
            enctype: 'multipart/form-data',
            success: function(result) {
                console.log(result);
                if(result.status == 'created'){
                    alert('Successfully saved to caseID = '+ result.caseID +' !');
                }else if(result.status == 'updated'){
                    alert('Successfully updated !');
                }else if(result.status == 'deleted'){
                    alert('Successfully deleted !');
                }else if(result.status == 'existcase'){
                    alert('There is already file for caseID=' +result.existcaseID +' registered so choose another caseID,please.');
                    btn_submit_recurring.prop('disabled', false);
                }else if(result.status == 'sessionexpired'){
                    alert('Session has been expired!');
                }
                // $(".btn_managedropdowns").prop('disabled', false);
                location.reload();
                
                $("#btn_deceasedInfo").prop('disabled', false);
                $("#btn_deceasedInfo").html('Update');
            },
            error: function(result) {
                // $value = JSON.parse(result);
                console.log(result);
                if(result.status == 'nodata'){
                    alert('Please insert all data correctly!');
                }
            }
        })
    
    });

    $(".forms_superrow").submit(function(e) {
        e.preventDefault();
        var actionurl = e.currentTarget.action;
        $(this).find(':input[type=submit]').prop('disabled', true);
        var formData = new FormData($(this)[0]);
        formData.append("postaction", subm);
        console.log(formData);

        $.ajax({
            type: "POST",
            url: actionurl,
            dataType: 'json',
            data: formData,
            processData: false,
            contentType: false,
            success: function(result) {
                console.log(result);
                if(result.status == 'created'){
                    alert('Successfully saved !');
                    location.reload();
                }else if(result.status == 'updated'){
                    alert('Successfully updated !');
                    location.reload();
                }else if(result.status == 'deleted'){
                    alert('Successfully deleted !');
                    location.reload();
                }else if(result.status == 'sessionexpired'){
                    alert('Session has been expired!');
                    location.reload();
                }else if(result.status == 'setcaseid'){
                    alert('You will redirect to selected status: '+result.casestatus+' with caseID:'+result.caseid+'.');
                    switch (result.casestatus) {
                        case 'Pre-Need':
                            
                            location.assign("pre_need.php");
                            break;
                        case 'At-Need':
                            
                            location.assign("at_need.php");
                            break;
                        case 'First-Call':
                            
                            location.assign("first_call.php");
                            break;
                        case 'Case-Bio':
                            
                            location.assign("case_bio.php");
                            break;
                    
                        default:
                            break;
                    }
                }
            },
            error: function(result) {
                // $value = JSON.parse(result);
                console.log(result);
                if(result.status == 'nodata'){
                    alert('Please insert all data correctly!');
                }
                location.reload();
            }
        })
    
    });
    $('.form_todolist').submit(function(e){
        e.preventDefault();
        if (subm=='sbm_completetask_Y') {
            alert('Already Completed! Try another one.');
        } else {
            var actionurl = e.currentTarget.action;
            var btn_submit_SOGS = $(this).find(':input[type=submit]');
            $(this).find(':input[type=submit]').prop('disabled', true);
            var cachedData = localStorage.getItem("caseID");
            var formserial = $(this).serialize() + '&caseId=' + cachedData + '&postaction=' + subm;
            $.ajax({
                type: "POST",
                url: actionurl,
                dataType: 'json',
                data: formserial,
                success: function(result) {
                    console.log(result);
                    if(result.status == 'exist'){
                        btn_submit_SOGS.prop('disabled', false);
                        $(".modal_todolist").hide();
                        alert('There is already same option. Please create another.');
                    }else if(result.status == 'created'){
                        btn_submit_SOGS.prop('disabled', false);
                        alert('Successfully saved !');
                        location.reload();
                    }else if(result.status == 'updated'){
                        btn_submit_SOGS.prop('disabled', false);
                        alert('Successfully updated !');
                        location.reload();
                    }else if(result.status == 'deleted'){
                        alert('Successfully deleted !');
                        location.reload();
                    }else if(result.status == 'completed'){
                        alert('Successfully completed !');
                        location.reload();
                    }
                },
                error: function(result) {
                    alert(result.status);
                    console.log(result);
                }
            })
        }
        
    })
});


