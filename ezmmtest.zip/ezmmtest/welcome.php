<?php 
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';

        $flag_dash = true;
        //get superadmin's ID
        $sql = "SELECT * FROM users WHERE role='superadmin';";
        $result = mysqli_fetch_array($conn->query($sql));
        $superadminID = $result['id'];

        $sql = "SELECT * FROM users WHERE role='superadmin';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $super_funData = mysqli_fetch_assoc($result);
        }

        $sql = "SELECT * FROM users WHERE role !='superadmin' AND crematory != '';";
        $funhomeResult = $conn->query($sql);
        $funhomeResultCount = mysqli_num_rows($funhomeResult);

        switch ($_SESSION['userrole']) {
            case 'superadmin':
                $sql = "SELECT * FROM cases;";
                break;
            case 'adminstaff':
                $sql = "SELECT * FROM cases WHERE staffID != '".$superadminID."' ORDER BY id DESC;";
                break;
            case 'staff':
                $sql = "SELECT * FROM cases WHERE staffID='".$_SESSION['userid']."';";
                break;
            default:
                break;
        }
        $casesResult = $conn->query($sql);
        $casesResultCount = mysqli_num_rows($casesResult);
        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
<style>
    .modal-backdrop.show {
            opacity: 0;
    }
    .modal-backdrop {
        z-index: unset;
    }
    .modal.show {
        background: #000000a3;
    }
    .modal-content {
        margin-top: 50%;
    }
    .modal .modal-body img {
        max-width: -webkit-fill-available;
        width: 100%;
    }
</style>
        <div class="page-title-heading">
            <div><h3>Existing Cases</h3></div>
        </div>
    </div>
</div>            
<div class="row">
    <div class="col-md-12">
        <div class="main-card mb-3 card">
        <?php if (isset($_SESSION['userrole']) && $_SESSION['userrole'] == 'superadmin') {
            include('inc/superdash.php');
        } else{ include('inc/userdash.php');}?>
        </div>
    </div>
</div>
</div>
<?php include('inc/footer.php'); ?>
