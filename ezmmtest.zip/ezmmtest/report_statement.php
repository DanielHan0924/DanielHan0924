<?php
    session_start();
    if (isset($_SESSION['userid'])) {
        require 'database/connectDatabase.php';
        require_once __DIR__ . '/vendor/autoload.php';

        $sql = "SELECT * FROM users WHERE id='".$_SESSION['userid']."';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $user_info = mysqli_fetch_assoc($result);
            $sql = "SELECT name FROM dropdown_city WHERE id='".$user_info['city']."';";
            $user_info_city = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_state WHERE id='".$user_info['states']."';";
            $user_info_state = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_zip WHERE id='".$user_info['zip']."';";
            $user_info_zip = mysqli_fetch_array($conn->query($sql));
        }

        $sql = "SELECT * FROM cases WHERE id='".$_SESSION['selectedcaseID']."';";
        $result = $conn->query($sql);
        $case_info = mysqli_fetch_assoc($result);
        $tbl_name = 'pre_need_pi';
        switch ($case_info['status']) {
            case 'At-Need':
                $tbl_name = 'at_need_pi';
                break;
            case 'First-Call':
                $tbl_name = 'first_call_pi';
                break;
            case 'Case-Bio':
                $tbl_name = 'case_bio_deceased_info';
                break;
            default://how can the pre-need have visitors before it move onto next step like at-need etc?
                break;
        }
        $sql = "SELECT * FROM ".$tbl_name." WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $result = $conn->query($sql);
        $deceased_info = mysqli_fetch_assoc($result);
        $firstName = $deceased_info['firstName'];
        $lastNameID = $deceased_info['lastName'];
            $sql = "SELECT * FROM dropdown_lastname WHERE id='".$lastNameID."';";
            $lastName = mysqli_fetch_array($conn->query($sql))['name'];

        // $conn->close();
        $reportdate = date("d/m/y");
        $reporttime = date("h:i:sa");

        $header = '<div style="margin-top: 2.5cm; margin-bottom: 0.5cm;margin-left: 0cm; margin-right: 0cm;">
                        <table width="100%" style=" font-family: sans-serif;">
                            <tr>
                                <td width="80%" style="color:#0000BB;">
                                    <span style="font-weight: bold; font-size: 14pt;">Pre-Need Funeral/Crematory Arrangements Agreement</span><br /><br/>
                                    '.$user_info['crematory'].'<br />'.$user_info['address1'].'<br />'.$user_info['address2'].'<br />
                                    '.$user_info_city['name'].', '.$user_info_state['name'].', '.$user_info_zip['name'].'
                                    <span style="font-size: 15pt;">☎</span>'.$user_info['phone'].' , '.$user_info['contactemail'].'
                                </td>
                                <td width="20%" style="text-align: right; vertical-align: top;">
                                    Case ID.<br />
                                    <span style="font-weight: bold; font-size: 12pt;">'.$_SESSION['selectedcaseID'].'</span><br/><br/>
                                    '.$reportdate.'<br/>'.$reporttime.'
                                </td>
                            </tr>
                        </table>   
                    </div>';
        require __DIR__ . '/vendor/autoload.php';
        $mpdf = new \Mpdf\Mpdf();
        $mpdf->setFooter('{PAGENO}');
        $mpdf->WriteHTML($header);
        $report_informants_header = '<div style="border: 1px solid red; margin-top: 0.5cm;">
                                        <div style="text-align: left; margin-left:4cm; font-family: sans-serif;">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Informants (responsible paying parties)<h3>&nbsp;&nbsp;'.$firstName.'&nbsp;'.$lastName.' / CaseID = '.$_SESSION['selectedcaseID'].'</h3>
                                        </div><br/>';

        $sql = "SELECT * FROM statement_informants WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $informants = $conn->query($sql);
        $report_informants_body = '';
        $report_informants_footer = '</div>';
        if (mysqli_num_rows($informants) > 0) {
            $rowcount = 0;
            while ($informantsResult_row = mysqli_fetch_assoc($informants)) {
                $rowcount ++;
                $sql = "SELECT name FROM dropdown_city WHERE id='".$informantsResult_row['City']."';";
                $informantsResult_row_city = mysqli_fetch_array($conn->query($sql));
                $sql = "SELECT name FROM dropdown_state WHERE id='".$informantsResult_row['States']."';";
                $informantsResult_row_state = mysqli_fetch_array($conn->query($sql));
                $sql = "SELECT name FROM dropdown_zip WHERE id='".$informantsResult_row['Zip']."';";
                $informantsResult_row_zip = mysqli_fetch_array($conn->query($sql));
                $informantsResult_row_address2 = $informantsResult_row['Address2']!=''?$informantsResult_row['Address2']:'--';
                $report_informants_body .= '
                                        <table width="100%" style=" font-family: sans-serif;">
                                            <thead>
                                            <tr>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Name</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">SSN</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Email</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Phone</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row['InformantName'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row['SSN'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row['Email'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row['Phone'].'</span>
                                                </td>

                                            </tr>
                                            </tbody>
                                            <thead>
                                            <tr>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Invoice Date</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Due Date</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address1</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address2</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row['InvoiceDate'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row['DueDate'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row['Address1'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row_address2.'</span>
                                                </td>

                                            </tr>
                                            </tbody>
                                            <thead>
                                            <tr>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">City</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">State</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Zip</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row_city['name'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row_state['name'].'</span>
                                                </td>

                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row_zip['name'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_row['phone'].'</span>
                                                </td>
                                            </tr>
                                            </tbody>
                                            <thead>
                                            <tr>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Note</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$informantsResult_city['note'].'</span>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table><br/>
                                        <div style="margin-left:5cm;">Sign ________________  Date __________________</div><br/>';
       
            }
            $report_informants_total = $report_informants_header.$report_informants_body.$report_informants_footer;
            $mpdf->WriteHTML($report_informants_total);
        } else {
            $mpdf->WriteHTML('There is no informants for this caseID.');  
        }

        $report_proser = '<div style="border: 1px solid blue; margin-top: 0.2cm;">
                    <div style="text-align: left; font-family: sans-serif;">
                        Professional Services:
                    </div><br/>
                    </div>';

        $report_footer = '<div style="border: 1px solid green; margin-top: 0.2cm;">
                <div style="text-align: left; font-family: sans-serif;">
                    Terms and Conditions from Statement of Goods & Services<br/>
                </div><br/>
                <div style="text-align: left; margin-left:2cm; font-family: sans-serif;">
                Sign by CLIENT_______________________ <br/><br/>Sign HOME agent or representative   __________________________<br/>
                                    
                </div><br/>
                <div style="text-align: left; margin-left:6cm; font-family: sans-serif;">
                Sign date: _____/_____/____________ <br/>
                                    
                </div><br/></div>';
        $mpdf->WriteHTML($report_footer);  
        $mpdf->Output();
    } else {
        header('Location: login.php');
    }
?>
    