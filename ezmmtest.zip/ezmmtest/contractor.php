<?php 
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';
        $flag_addBtn = true;

        $sql = "SELECT * FROM contractor WHERE username='".$_SESSION['username']."';";
        $result = $conn->query($sql);
        $resultCount = mysqli_num_rows($result);

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
            <div class="page-title-heading">
                <div><h3>CONTRACTOR</h3></div>    
            </div>
                </div>
    </div>     
    <div class="row">
        <div class="col-md-12">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <h5 class="card-title custom-head">CONTRACTOR</h5>
                        </div>
                        <!-- <div class="col-lg-2">
                            <div class="image-holder">
                                <img src="assets/images/oldman.jpeg" />
                                <div class="d-block text-center card-footer">
                                <button class="btn-sm btn-block btn btn-success" onclick="saveContractorForm()">Save</button>
                            </div>
                            </div>
                        </div> -->
                    </div>      
                </div>
                <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                    <div class="card">
                        <div id="headingOne" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">CONTRACTOR INFORMATION</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                            <div class="card-body" id="contractor-section">
                            
                            <?php if ($resultCount > 0) { ?>
                                <select name="CNTR_select" id="CNTR_select" class="form-control required" required>
                                    <option hidden>Select any contractor or Add new one below:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" ><?php echo ($dropdown_city_cld['funeralhome']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/contractors.php'); ?>
                            </div> 
                        </div>
                    </div>                                         
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('inc/footer.php'); ?>
