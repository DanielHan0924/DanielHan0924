<?php 
    session_start();
    if (isset($_SESSION['userid'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';
        
        $flag_addBtn = true;
        $flag_final = true;

        $sql = "SELECT * FROM final_arrange_visitation WHERE staffID='".$_SESSION['userid']."';";
        $visitationResult = $conn->query($sql);
        $visitationResultCount = mysqli_num_rows($visitationResult);

        $sql = "SELECT * FROM final_arrange_service WHERE staffID='".$_SESSION['userid']."';";
        $serviceResult = $conn->query($sql);
        $serviceResultCount = mysqli_num_rows($serviceResult);

        $sql = "SELECT * FROM final_arrange_vocalist WHERE staffID='".$_SESSION['userid']."';";
        $vocalistResult = $conn->query($sql);
        $vocalistResultCount = mysqli_num_rows($vocalistResult);

        $sql = "SELECT * FROM final_arrange_clergy WHERE staffID='".$_SESSION['userid']."';";
        $clergyResult = $conn->query($sql);
        $clergyResultCount = mysqli_num_rows($clergyResult);

        $sql = "SELECT * FROM final_arrange_driver WHERE staffID='".$_SESSION['userid']."';";
        $driverResult = $conn->query($sql);
        $driverResultCount = mysqli_num_rows($driverResult);

        $sql = "SELECT * FROM final_arrange_escort WHERE staffID='".$_SESSION['userid']."';";
        $escortResult = $conn->query($sql);
        $escortResultCount = mysqli_num_rows($escortResult);

        $sql = "SELECT * FROM final_arrange_florist WHERE staffID='".$_SESSION['userid']."' GROUP BY caseID;";
        $floristResult = $conn->query($sql);
        $floristResultCount = mysqli_num_rows($floristResult);

        $sql = "SELECT * FROM final_arrange_sexton WHERE staffID='".$_SESSION['userid']."';";
        $sextonResult = $conn->query($sql);
        $sextonResultCount = mysqli_num_rows($sextonResult);

        $sql = "SELECT * FROM final_arrange_organist WHERE staffID='".$_SESSION['userid']."';";
        $organistResult = $conn->query($sql);
        $organistResultCount = mysqli_num_rows($organistResult);

        $sql = "SELECT * FROM final_arrange_cosmetologist WHERE staffID='".$_SESSION['userid']."';";
        $cosmetologistResult = $conn->query($sql);
        $cosmetologistResultCount = mysqli_num_rows($cosmetologistResult);

        $sql = "SELECT * FROM final_arrange_beauticianbarber WHERE staffID='".$_SESSION['userid']."';";
        $beauticianbarberResult = $conn->query($sql);
        $beauticianbarberResultCount = mysqli_num_rows($beauticianbarberResult);

        $sql = "SELECT * FROM final_arrange_pallbearer WHERE staffID='".$_SESSION['userid']."' GROUP BY caseID;";
        $pallbearerResult = $conn->query($sql);
        $pallbearerResultCount = mysqli_num_rows($pallbearerResult);

        $sql = "SELECT * FROM final_arrange_honorarypallbearer WHERE staffID='".$_SESSION['userid']."' GROUP BY caseID;";
        $honorarypallbearerResult = $conn->query($sql);
        $honorarypallbearerResultCount = mysqli_num_rows($honorarypallbearerResult);

        $sql = "SELECT * FROM final_arrange_funeral_home WHERE staffID='".$_SESSION['userid']."';";
        $FUNHOMCREResult = $conn->query($sql);
        $FUNHOMCREResultCount = mysqli_num_rows($FUNHOMCREResult);

        $sql = "SELECT * FROM final_arrange_military_service WHERE staffID='".$_SESSION['userid']."' GROUP BY caseID;";
        $militaryserviceResult = $conn->query($sql);
        $militaryserviceResultCount = mysqli_num_rows($militaryserviceResult);

        $sql = "SELECT * FROM final_arrange_volunteer WHERE staffID='".$_SESSION['userid']."';";
        $volunteerResult = $conn->query($sql);
        $volunteerResultCount = mysqli_num_rows($volunteerResult);

        $sql = "SELECT * FROM final_arrange_marital WHERE staffID='".$_SESSION['userid']."' GROUP BY caseID;";
        $maritalResult = $conn->query($sql);
        $maritalResultCount = mysqli_num_rows($maritalResult);

        $sql = "SELECT * FROM final_arrange_children WHERE staffID='".$_SESSION['userid']."';";
        $childrenResult = $conn->query($sql);
        $childrenResultCount = mysqli_num_rows($childrenResult);

        $sql = "SELECT * FROM final_arrange_church WHERE staffID='".$_SESSION['userid']."';";
        $churchResult = $conn->query($sql);
        $churchResultCount = mysqli_num_rows($churchResult);

        $sql = "SELECT * FROM final_arrange_place_of_worship WHERE staffID='".$_SESSION['userid']."';";
        $placeofworshipResult = $conn->query($sql);
        $placeofworshipResultCount = mysqli_num_rows($placeofworshipResult);

        $sql = "SELECT * FROM final_arrange_education WHERE staffID='".$_SESSION['userid']."';";
        $educationResult = $conn->query($sql);
        $educationResultCount = mysqli_num_rows($educationResult);

        $sql = "SELECT * FROM final_arrange_parents WHERE staffID='".$_SESSION['userid']."';";
        $parentsResult = $conn->query($sql);
        $parentsResultCount = mysqli_num_rows($parentsResult);

        $sql = "SELECT * FROM final_arrange_final_disposition WHERE staffID='".$_SESSION['userid']."';";
        $finaldispositionResult = $conn->query($sql);
        $finaldispositionResultCount = mysqli_num_rows($finaldispositionResult);

        $sql = "SELECT * FROM final_arrange_final_crematory WHERE staffID='".$_SESSION['userid']."';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $final_crematory = mysqli_fetch_assoc($result);
        }

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
<div class="page-title-heading">
    <div>
        <h3>FINAL ARRANGEMENTS</h3>
    </div>
</div>
</div>
</div>

<div class="row">
    <div class="col-md-12">
        <!-- <form class="longforms" id="final-arrangement-form"> -->
        <div class="main-card mb-3 card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        
                        <h5 class="card-title custom-head">FINAL ARRANGEMENTS </h5>
                    </div>
                    <!-- <div class="col-lg-2">
                        <div class="image-holder">
                            <img src="assets/images/oldman.jpeg" />
                            <div class="d-block text-center card-footer">
                                <button class="btn-sm btn-block btn btn-success" onclick="saveFinalArrangeForm()">Save</button>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>
            <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                <div class="card">
                    <div id="headingOne" class="card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">VISITATION</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                        <div class="card-body" id="visitation-section">
                        
                            <?php if ($visitationResultCount > 0) { ?>
                                <select name="VIS_select" id="VIS_select" class="form-control required" required>
                                    <option hidden>Select any visitation:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($visitationResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>">caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['VisitationName']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/visitation.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne2" aria-expanded="false" aria-controls="collapseTwo" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">SERVICES</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne2" class="collapse">
                        <div class="card-body" id="service-section">
                            
                            <?php if ($serviceResultCount > 0) { ?>
                                <select name="SER_select" id="SER_select" class="form-control required" required>
                                    <option hidden>Select any service:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($serviceResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['ServiceName']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/service.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingOne" class="card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseVocalist" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">Vocalists</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseVocalist" aria-labelledby="headingOne" class="collapse">
                        <div class="card-body" id="vocalist-section">
                        
                        <?php if ($vocalistResultCount > 0) { ?>
                            <select name="VOC_select" id="VOC_select" class="form-control required" required>
                                <option hidden>Select any vocalist:</option>
                                <?php 
                                while($dropdown_city_cld = mysqli_fetch_assoc($vocalistResult)) {                 
                                    ?>
                                    <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['fullname']); ?></option>
                                <?php }?>
                            </select>
                            <br>
                        <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/vocalist.php'); ?>
                        </div>
                    </div>
                </div>  
                <div class="card">
                    <div id="headingOne" class="card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOrganist" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">Organist</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOrganist" aria-labelledby="headingOne" class="collapse">
                        <div class="card-body" id="organist-section">
                        
                            <?php if ($organistResultCount > 0) { ?>
                                <select name="ORG_select" id="ORG_select" class="form-control required" required>
                                    <option hidden>Select any organist.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($organistResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['fullname']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/organist.php'); ?>
                        </div>
                        <!-- <div class="row">
                            <div class="col-md-12">
                                <div class="d-block text-center card-footer">
                                    <button type="button" class="btn-wide btn btn-warning pull-left" onclick="addContrators()">Add Contractor</button>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
                <div class="card">
                    <div id="headingOne" class="card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne3" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">PALLBEARER</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne3" aria-labelledby="headingOne" class="collapse">
                        <div class="card-body">
                            <?php if ($pallbearerResultCount > 0) { ?>
                                <select name="PB_case_select" id="PB_case_select" class="form-control" required>
                                    <option hidden>Select any pallbearer:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($pallbearerResult)) { ?>
                                        
                                        <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" > CaseID: <?php echo ($dropdown_city_cld["caseID"]); ?></option>
                                    <?php } ?>
                                </select>
                                <br>
                                <div class="row multi-select-custom"></div> 
                            <?php } else{echo ('no personal information');} ?>
                            <?php include('inc/pallbearer.php'); ?> 
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne4" aria-expanded="false" aria-controls="collapseTwo" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">HONORARY PALLBEARER</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne4" class="collapse">
                        <div class="card-body">
                        <?php if ($honorarypallbearerResultCount > 0) { ?>
                                <select name="HPB_case_select" id="HPB_case_select" class="form-control" required>
                                    <option hidden>Select any honorary pallbearer:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($honorarypallbearerResult)) { ?>
                                        
                                        <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" > CaseID: <?php echo ($dropdown_city_cld["caseID"]); ?></option>
                                    <?php } ?>
                                </select>
                                <br>
                                <div class="row multi-select-custom"></div> 
                            <?php } else{echo ('no personal information');} ?>
                            <?php include('inc/honorary_pallbearer.php'); ?> 
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne5" aria-expanded="false" aria-controls="collapseThree" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">BEAUTICIAN/BARBER</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne5" class="collapse">
                        <div class="card-body">
                            <!--Placeholder for inc file-->
                            <?php if ($beauticianbarberResultCount > 0) { ?>
                                <select name="BB_select" id="BB_select" class="form-control required" required>
                                    <option hidden>Select any beautician / barber.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($beauticianbarberResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['fullname']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/beautician_barber.php'); ?>
                            
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne6" aria-expanded="false" aria-controls="collapseFour" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">COSMETOLOGIST</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne6" class="collapse">
                        <div class="card-body">
                        <!--Placeholder for inc file-->
                            <?php if ($cosmetologistResultCount > 0) { ?>
                                <select name="COS_select" id="COS_select" class="form-control required" required>
                                    <option hidden>Select any cosmetologist.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($cosmetologistResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['fullname']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/cosmetologist.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne7" aria-expanded="false" aria-controls="collapseFiv" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">DRIVER</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne7" class="collapse">
                        <div class="card-body">
                            <!--REPLACE WITH INC FORM -->
                            <?php if ($driverResultCount > 0) { ?>
                                <select name="DRV_select" id="DRV_select" class="form-control required" required>
                                    <option hidden>Select any driver.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($driverResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['fullname']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/driver.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne8" aria-expanded="false" aria-controls="collapseSix" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">SEXTON</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne8" class="collapse">
                        <div class="card-body">
                            <!--REPLACE WITH INC FORM -->
                            <?php if ($sextonResultCount > 0) { ?>
                                <select name="SEX_select" id="SEX_select" class="form-control required" required>
                                    <option hidden>Select any sexton.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($sextonResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['fullname']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/sexton.php'); ?>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne9" aria-expanded="false" aria-controls="collapseEleven" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">ESCORT</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne9" class="collapse">
                        <div class="card-body">
                            <!--REPLACE WITH INC FORM -->
                            <?php if ($escortResultCount > 0) { ?>
                                <select name="ESC_select" id="ESC_select" class="form-control required" required>
                                    <option hidden>Select any escort.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($escortResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['fullname']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/escort.php'); ?>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne10" aria-expanded="false" aria-controls="collapseSeven" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">CLERGY</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne10" class="collapse">
                        <div class="card-body">
                            <!--REPLACE WITH INC FORM -->
                            <?php if ($clergyResultCount > 0) { ?>
                                <select name="CHUR_select" id="CHUR_select" class="form-control required" required>
                                    <option hidden>Select any clergy.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($clergyResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['fullname']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/clergy.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne11" aria-expanded="false" aria-controls="collapseSeven" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">FLORIST</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne11" class="collapse">
                        <div class="card-body">
                            <!--REPLACE WITH INC FORM -->
                            <?php if ($floristResultCount > 0) { ?>
                                <select name="FLOR_case_select" id="FLOR_case_select" class="form-control" required>
                                    <option hidden>Select any florist.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($floristResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" >CaseID: <?php echo ($dropdown_city_cld['caseID']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <div class="row multi-select-custom"></div> 

                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/florist.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne12" aria-expanded="false" aria-controls="collapseThree" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">MARITAL STATUS</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne12" class="collapse">
                        <div class="card-body">
                            <?php if ($maritalResultCount > 0) { ?>
                                <select name="MS_case_select" id="MS_case_select" class="form-control" required>
                                    <option hidden>Select any place of marriage.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($maritalResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" >CaseID: <?php echo ($dropdown_city_cld['caseID']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <div class="row multi-select-custom"></div> 
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/marital.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne13" aria-expanded="false" aria-controls="collapseFour" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">CHILDREN</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne13" class="collapse">
                        <div class="card-body">
                            <?php if ($childrenResultCount > 0) { ?>
                            <select name="CLD_case_select" id="CLD_case_select" class="form-control" required>
                                <option hidden>Select any children per case.</option>
                                <?php 
                                while($dropdown_city_cld = mysqli_fetch_assoc($childrenResult)) {                 
                                    ?>
                                    <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" >CaseID: <?php echo ($dropdown_city_cld['caseID']); ?></option>
                                <?php } ?>
                            </select>
                            <br>
                            <div class="row multi-select-custom"></div> 
                            <?php } else{echo ('no case to be selected');} ?>
                            <?php include('inc/children.php'); ?>
                        </div>
                    </div>
                </div>
            
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne15" aria-expanded="false" aria-controls="collapseFiv" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">MILITARY SERVICE HONORS</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne15" class="collapse">
                        <div class="card-body">
                            <?php if ($militaryserviceResultCount > 0) { ?>
                                <select name="MSH_case_select" id="MSH_case_select" class="form-control" required>
                                    <option hidden>Select any military service honor:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($militaryserviceResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" >CaseID: <?php echo ($dropdown_city_cld['caseID']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <div class="row multi-select-custom"></div> 
                            <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/military_service_honors.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne16" aria-expanded="false" aria-controls="collapseSix" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">CHURCH</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne16" class="collapse">
                        <div class="card-body">
                            <?php if ($churchResultCount > 0) { ?>
                                <select name="CHU_select" id="CHU_select" class="form-control required" required>
                                    <option hidden>Select any church.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($churchResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['Church']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/church.php'); ?>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne17" aria-expanded="false" aria-controls="collapseEleven" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">PLACE OF WORSHIP</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne17" class="collapse">
                        <div class="card-body">
                            <?php if ($placeofworshipResultCount > 0) { ?>
                                <select name="POW_select" id="POW_select" class="form-control required" required>
                                    <option hidden>Select any place of worship.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($placeofworshipResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['PlaceOfWorship']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/place_of_worship.php'); ?>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne18" aria-expanded="false" aria-controls="collapseSeven" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">EDUCATION</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne18" class="collapse">
                        <div class="card-body">
                            <?php if ($educationResultCount > 0) { ?>
                                <select name="EDU_select" id="EDU_select" class="form-control required" required>
                                    <option hidden>Select any education info.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($educationResult)) { ?>
                                        <?php  
                                            $sql = "SELECT name FROM dropdown_highschool WHERE id='".$dropdown_city_cld['EduHighSchool']."';";
                                            $result = mysqli_fetch_array($conn->query($sql));
                                            $sql1 = "SELECT name FROM dropdown_graduatename WHERE id='".$dropdown_city_cld['graduate']."';";
                                            $result1 = mysqli_fetch_array($conn->query($sql1));
                                            $sql2 = "SELECT name FROM dropdown_undergraduatename WHERE id='".$dropdown_city_cld['undergraducate']."';";
                                            $result2 = mysqli_fetch_array($conn->query($sql2));
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($result["name"]); ?>, <?php echo ($result2["name"]); ?>, <?php echo ($result1["name"]); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/education.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne19" aria-expanded="false" aria-controls="collapseEight" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">PARENTS DECEASED</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne19" class="collapse">
                        <div class="card-body">
                            <div class="row">
                            <?php if ($parentsResultCount > 0) { ?>
                                <?php $order = 1; while($dropdown_city_cld = mysqli_fetch_assoc($parentsResult)) {?>
                                <div class="col-md-2">
                                    <select name="PAT_select" id="PAT_select"  class="form-control PB_select" required>
                                        <option hidden>Number <?php echo ($order); ?> </option>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['id']); ?></option>
                                    </select>
                                </div>
                            <?php $order ++;}?>
                            <?php } else{echo ('no option to be selected');}?>
                            </div>
                                <br>
                                <br>  
                            <?php include('inc/parent_deceased.php'); ?> 
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne20" aria-expanded="false" aria-controls="collapseNine" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">FINAL DISPOSITION</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne20" class="collapse">
                        <div class="card-body">
                            <?php if ($finaldispositionResultCount > 0) { ?>
                                <select name="FDP_select" id="FDP_select" class="form-control required" required>
                                    <option hidden>Select any final disposition.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($finaldispositionResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['FinalDisposition']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/final_disposition.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div  class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne21" aria-expanded="false" aria-controls="collapseNine" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">FUNERAL HOME / CREMATORY</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne21" class="collapse">
                        <div class="card-body">
                            <!--REPLACE WITH INC FORM -->
                            <?php if ($FUNHOMCREResultCount > 0) { ?>
                                <select name="FUNHOMCRE_select" id="FUNHOMCRE_select" class="form-control required" required>
                                    <option hidden>Select any Funeral home / crematory.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($FUNHOMCREResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['fullname']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/funeral_home_crematory_registration.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne22" aria-expanded="false" aria-controls="collapseNine" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">volunteer</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne22" class="collapse">
                        <div class="card-body">
                            <!--REPLACE WITH INC FORM -->
                            <?php if ($volunteerResultCount > 0) { ?>
                                <select name="VOLN_select" id="VOLN_select" class="form-control required" required>
                                    <option hidden>Select any volunteer.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($volunteerResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['fullname']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/volunteer.php'); ?>
                        </div>
                    </div>
                </div>

            </div>
            <!-- <div class="d-block text-center card-footer">
                <button type="button" class="btn-wide btn btn-primary pull-left">Back to Home</button>
                <button class="btn-wide btn btn-success pull-right" onclick="saveFinalArrangeForm()">Save</button>
            </div> -->
        </div>
        <!-- </form> -->
    </div>
</div>
</div>
<?php include('inc/footer.php'); ?>

