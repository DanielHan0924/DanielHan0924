<?php 
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';

        $sql = "SELECT * FROM vital_statistics_district WHERE username='".$_SESSION['username']."';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $distric = mysqli_fetch_assoc($result);
        }

        $conn->close();
    } else {
        header('Location: login.php');
    }
?>
                                <div class="page-title-heading">
                                    <div><h3>Vital Statistics</h3></div>    
                                </div>
                                   </div>
                        </div>    
                        
                        <div class="row">
                            <div class="col-md-12">
                                <form class="longforms" id="vitalstatistics-form">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                       <div class="row">
                                            <div class="col-md-12">
                                            
                                            <h5 class="card-title custom-head">Vital Statistics</h5>
                                            </div>
                                            
                                        </div>
                                        
                                    </div>
                                    <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                                        <div class="card">
                                            <div id="headingOne" class="card-header">
                                                <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                                    <h5 class="m-0 p-0">SELECT STATE/PROVINCE/DISTRICT</h5>
                                                </button>
                                            </div>
                                            <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                                                <div class="card-body">
                                                 <?php include('inc/vital_statistics_sd.php'); ?>
                                                
                                            </div>
                                        </div>
                                        </div>
                                        <div class="card">

                                                                                
                                    </div>
                                    
                                    <div class="d-block text-center card-footer">
                                        <button type="button" class="btn-wide btn btn-primary pull-left">Back to Home</button>
                                        <button class="btn-wide btn btn-success pull-right" onclick="saveVitalStatisticsForm()">Save</button>
                                    </div>
                                    
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php include('inc/footer.php'); ?>
