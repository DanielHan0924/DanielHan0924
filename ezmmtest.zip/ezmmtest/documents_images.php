<?php 
    session_start();
    if (isset($_SESSION['userid'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';
        
        $flag_addBtn = true;
        $flag_docimg = true;

        $sql = "SELECT * FROM documents WHERE staffID='".$_SESSION['userid']."';";
        $documentResult = $conn->query($sql);
        $documentResultCount = mysqli_num_rows($documentResult);

        $sql = "SELECT * FROM images WHERE staffID='".$_SESSION['userid']."';";
        $imageResult = $conn->query($sql);
        $imageResultCount = mysqli_num_rows($imageResult);

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
<style>
    .btn-primary
    {
    display:block;
    border-radius:0px;
    box-shadow:0px 4px 6px 2px rgba(0,0,0,0.2);
    margin-top:-5px;
    }
    .modal-backdrop.show {
        opacity: 0;
    }
    .modal-backdrop {
        z-index: unset;
    }
    .modal.show {
        background: #000000a3;
    }
    .modal-content {
        margin-top: 30%;
        width: 700px;
    }
    .modal .modal-body img {
        max-width: -webkit-fill-available;
        width: 100%;
    }
</style>
            <div class="page-title-heading">
                <div><h3>DOCUMENTS &AMP; IMAGES</h3></div>    
            </div>
                </div>
    </div>    
    
    <div class="row">
        <div class="col-md-12">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                        <!-- <nav class="" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item" aria-current="page">John - Doe - 12/18/1997 - 02/17/2020</li>
                                        </ol>
                        </nav> -->
                        <h5 class="card-title custom-head">DOCUMENTS &amp; IMAGES</h5>
                        </div>
                        <!-- <div class="col-lg-2">
                            <div class="image-holder">
                                <img src="assets/images/oldman.jpeg" />
                                <div class="d-block text-center card-footer">
                                <button class="btn-sm btn-block btn btn-success">Save</button>
                            </div>
                            </div>
                        </div> -->
                    </div>
                    
                </div>
                <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                    <div class="card">
                        <div id="headingOne" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">DOCUMENTS</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                            <div class="card-body">
                                <?php if ($documentResultCount > 0) { ?>
                                <select name="DOCU_select" id="DOCU_select" class="form-control" required>
                                    <option hidden>Select any document:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($documentResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['filename']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                                <?php } else {echo ('no option to be selected');}?>
                                <?php include('inc/document.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingTwo" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne2" aria-expanded="false" aria-controls="collapseTwo" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">IMAGES</h5></button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne2" class="collapse">
                            <div class="card-body">
                                <?php if ($imageResultCount > 0) { ?>
                                <select name="IMAGE_select" id="IMAGE_select" class="form-control" required>
                                    <option hidden>Select any image:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($imageResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['filename']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                                <?php } else {echo ('no option to be selected');}?>
                                <?php include('inc/image.php'); ?>
                                
                            </div>
                        </div>
                    </div>
                                                            
                </div>
<!--                 
                <div class="d-block text-center card-footer">
                    <button type="button" class="btn-wide btn btn-primary pull-left">Back to Home</button>
                    <button type="button" class="btn-wide btn btn-success pull-right">Save</button>
                </div>
                 -->
            </div>
        </div>
    </div>
</div>
<?php include('inc/footer.php'); ?>
