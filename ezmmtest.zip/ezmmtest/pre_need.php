<?php 
    session_start();
    if (isset($_SESSION['userid'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';
        require 'database/managedropdown.php';

        $flag_addBtn = true;
        $flag_convert  = true;
        $flag_preneed = true;
        
        $sql = "SELECT * FROM pre_need_pi WHERE staffID='".$_SESSION['userid']."';";
        $piResult = $conn->query($sql);
        $piResultCount = mysqli_num_rows($piResult);

        $sql = "SELECT * FROM pre_need_nok WHERE staffID='".$_SESSION['userid']."' GROUP BY caseID;";
        $nokResult = $conn->query($sql);
        $nokResultCount = mysqli_num_rows($nokResult);

        $sql = "SELECT * FROM pre_need_marital WHERE staffID='".$_SESSION['userid']."' GROUP BY caseID;";
        $maritalResult = $conn->query($sql);
        $maritalResultCount = mysqli_num_rows($maritalResult);

        $sql = "SELECT * FROM pre_need_children WHERE staffID='".$_SESSION['userid']."' GROUP BY caseID;";
        $childcasesResult = $conn->query($sql);
        $childcasesResultCount = mysqli_num_rows($childcasesResult);

        $sql = "SELECT * FROM pre_need_military_service WHERE staffID='".$_SESSION['userid']."';";
        $mltResult = $conn->query($sql);
        $mltResultCount = mysqli_num_rows($mltResult);

        $sql = "SELECT * FROM pre_need_church WHERE staffID='".$_SESSION['userid']."';";
        $churchResult = $conn->query($sql);
        $churchResultCount = mysqli_num_rows($churchResult);

        $sql = "SELECT * FROM pre_need_place_of_worship WHERE staffID='".$_SESSION['userid']."';";
        $powResult = $conn->query($sql);
        $powResultCount = mysqli_num_rows($powResult);

        $sql = "SELECT * FROM pre_need_education WHERE staffID='".$_SESSION['userid']."';";
        $educationResult = $conn->query($sql);
        $educationResultCount = mysqli_num_rows($educationResult);

        $sql = "SELECT * FROM pre_need_parents WHERE staffID='".$_SESSION['userid']."';";
        $parentsResult = $conn->query($sql);
        $parentsResultCount = mysqli_num_rows($parentsResult);

        $sql = "SELECT * FROM pre_need_final_disposition WHERE staffID='".$_SESSION['userid']."';";
        $finaldispositionResult = $conn->query($sql);
        $finaldispositionResultCount = mysqli_num_rows($finaldispositionResult);

        $sql = "SELECT * FROM pre_need_final_crematory WHERE staffID='".$_SESSION['userid']."';";
        $finalcrematoryResult = $conn->query($sql);
        $finalcrematoryResultCount = mysqli_num_rows($finalcrematoryResult);

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
            <div class="page-title-heading">
                <div><h3>PRE NEED STATUS</h3></div>    
            </div>
        </div>
    </div>    
    
<div class="row">
    <div class="col-md-12">
        <!-- <form class="longforms" id="preneed-form"> -->
        <div class="main-card mb-3 card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-11">
                    
                    <h5 class="card-title custom-head">PRE NEED </h5>
                    </div>
                    <div class="col-md-1">
                        <button id="btn_preneedreport" class="btn btn-block btn btn-info">Report</button>
                    </div>
                </div>
                
            </div>
            <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                <div class="card">
                    <div id="headingOne" class="card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">PERSONAL INFORMATION</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                        <div class="card-body">
                            <?php if ($piResultCount > 0) { ?>
                                <select name="PI_select" id="PI_select" class="form-control" required>
                                    <option hidden>Select any personal information:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($piResult)) { ?>
                                        <?php  
                                            $sql = "SELECT name FROM dropdown_honorific WHERE id='".$dropdown_city_cld['honorific']."';";
                                            $result = mysqli_fetch_array($conn->query($sql));
                                            $sql1 = "SELECT name FROM dropdown_lastname WHERE id='".$dropdown_city_cld['lastName']."';";
                                            $result1 = mysqli_fetch_array($conn->query($sql1));
                                            $sql2 = "SELECT name FROM dropdown_suffix WHERE id='".$dropdown_city_cld['suffix']."';";
                                            $result2 = mysqli_fetch_array($conn->query($sql2));
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($result["name"]); ?>, <?php echo ($dropdown_city_cld['firstName'] ); ?> <?php echo ($dropdown_city_cld['middleName'] ); ?>, <?php echo ($result1['name'] ); ?>, <?php echo ($result2['name'] ); ?> </option>
                                    <?php } ?>
                                </select>
                                <br>
                            <?php } else{echo ('no personal information');} ?>
                            <?php include('inc/personalT_info.php'); ?> 
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne2" aria-expanded="false" aria-controls="collapseTwo" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">NEXT OF KIN</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne2" class="collapse">
                        <div class="card-body">
                            <?php if ($nokResultCount > 0) { ?>
                                <select name="NOK_case_select" id="NOK_case_select" class="form-control" required>
                                    <option hidden>Select any next of kin:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($nokResult)) { ?>
                                        
                                        <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" > CaseID: <?php echo ($dropdown_city_cld["caseID"]); ?></option>
                                    <?php } ?>
                                </select>
                                <br>
                                <div class="row multi-select-custom"></div> 
                            <?php } else{echo ('no personal information');} ?>
                            <?php include('inc/next_of_kin.php'); ?> 
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne3" aria-expanded="false" aria-controls="collapseThree" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">MARITAL STATUS</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne3" class="collapse">
                        <div class="card-body">
                            <?php if ($maritalResultCount > 0) { ?>
                                <select name="MS_case_select" id="MS_case_select" class="form-control" required>
                                    <option hidden>Select any Marital status:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($maritalResult)) { ?>
                                        
                                        <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" >caseID: <?php echo ($dropdown_city_cld["caseID"]); ?></option>
                                    <?php } ?>
                                </select>
                                <br>
                                <div class="row multi-select-custom"></div> 
                            <?php } else{echo ('no marital status information');} ?>
                            <?php include('inc/marital.php'); ?> 
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne4" aria-expanded="false" aria-controls="collapseFour" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">CHILDREN</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne4" class="collapse">
                        <div class="card-body">
                        <?php if ($childcasesResultCount > 0) { ?>
                            <select name="CLD_case_select" id="CLD_case_select" class="form-control" required>
                                <option hidden>Select any children per case.</option>
                                <?php 
                                while($dropdown_city_cld = mysqli_fetch_assoc($childcasesResult)) {                 
                                    ?>
                                    <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" >CaseID: <?php echo ($dropdown_city_cld['caseID']); ?></option>
                                <?php } ?>
                            </select>
                            <br>
                            <div class="row multi-select-custom"></div> 
                            <?php } else{echo ('no case to be selected');} ?>
                        <?php include('inc/children.php'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne5" aria-expanded="false" aria-controls="collapseFiv" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">MILITARY SERVICE</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne5" class="collapse">
                        <div class="card-body">
                            <?php if ($mltResultCount > 0) { ?>
                            <select name="MLT_select" id="MLT_select" class="form-control required" required>
                                <option hidden>Select any military service:</option>
                                <?php 
                                while($dropdown_city_cld = mysqli_fetch_assoc($mltResult)) {                 
                                    ?>
                                    <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['SerialNumber']); ?></option>
                                <?php }?>
                            </select>
                            <br>
                            <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/military_service.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne6" aria-expanded="false" aria-controls="collapseSix" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">CHURCH</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne6" class="collapse">
                        <div class="card-body">
                            <?php if ($churchResultCount > 0) { ?>
                            <select name="CHU_select" id="CHU_select" class="form-control required" required>
                                <option hidden>Select any church:</option>
                                <?php 
                                while($dropdown_city_cld = mysqli_fetch_assoc($churchResult)) {                 
                                    ?>
                                    <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['Church']); ?></option>
                                <?php }?>
                            </select>
                            <br>
                            <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/church.php'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne11" aria-expanded="false" aria-controls="collapseEleven" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">PLACE OF WORSHIP</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne11" class="collapse">
                        <div class="card-body">
                            <?php if ($powResultCount > 0) { ?>
                            <select name="POW_select" id="POW_select" class="form-control required" required>
                                <option hidden>Select any place of worship:</option>
                                <?php 
                                while($dropdown_city_cld = mysqli_fetch_assoc($powResult)) {                 
                                    ?>
                                    <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['PlaceOfWorship']); ?></option>
                                <?php }?>
                            </select>
                            <br>
                            <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/place_of_worship.php'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne7" aria-expanded="false" aria-controls="collapseSeven" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">EDUCATION</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne7" class="collapse">
                        <div class="card-body">
                            <?php if ($educationResultCount > 0) { ?>
                            <select name="EDU_select" id="EDU_select" class="form-control" required>
                                <option hidden>Select any education information:</option>
                                <?php 
                                while($dropdown_city_cld = mysqli_fetch_assoc($educationResult)) { ?>
                                        <?php  
                                            $sql = "SELECT name FROM dropdown_highschool WHERE id='".$dropdown_city_cld['EduHighSchool']."';";
                                            $result = mysqli_fetch_array($conn->query($sql));
                                            $sql1 = "SELECT name FROM dropdown_graduatename WHERE id='".$dropdown_city_cld['graduate']."';";
                                            $result1 = mysqli_fetch_array($conn->query($sql1));
                                            $sql2 = "SELECT name FROM dropdown_undergraduatename WHERE id='".$dropdown_city_cld['undergraducate']."';";
                                            $result2 = mysqli_fetch_array($conn->query($sql2));
                                        ?>
                                    <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($result["name"]); ?>, <?php echo ($result2["name"]); ?>, <?php echo ($result1["name"]); ?></option>
                                <?php }?>
                            </select>
                            <br>
                            <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/education.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne8" aria-expanded="false" aria-controls="collapseEight" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">PARENTS Deceased</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne8" class="collapse">
                        <div class="card-body">
                            <div class="row">
                            <?php if ($parentsResultCount > 0) { ?>
                                <?php $order = 1; while($dropdown_city_cld = mysqli_fetch_assoc($parentsResult)) {?>
                                <div class="col-md-2">
                                    <select name="PAT_select" id="PAT_select"  class="form-control PB_select" required>
                                        <option hidden>Number <?php echo ($order); ?> </option>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['id']); ?></option>
                                    </select>
                                </div>
                            <?php $order ++;}?>
                            <?php } else{echo ('no option to be selected');}?>
                            </div>
                                <br>
                                <br>  
                            <?php include('inc/parent_deceased.php'); ?> 
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne9" aria-expanded="false" aria-controls="collapseNine" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">FINAL DISPOSITION</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne9" class="collapse">
                        <div class="card-body">
                            <?php if ($finaldispositionResultCount > 0) { ?>
                            <select name="FDP_select" id="FDP_select" class="form-control" required>
                                <option hidden>Select any final disposition:</option>
                                <?php 
                                while($dropdown_city_cld = mysqli_fetch_assoc($finaldispositionResult)) {                 
                                    ?>
                                    <option value="<?php echo ($dropdown_city_cld['id']); ?>">caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['FinalDisposition']); ?></option>
                                <?php }?>
                            </select>
                            <br>
                            <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/final_disposition.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne13" aria-expanded="false" aria-controls="collapseNine" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">FUNERAL HOME / CREMATORY</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne13" class="collapse">
                        <div class="card-body">
                            <?php if ($finalcrematoryResultCount > 0) { ?>
                            <select name="FDP_select" id="FDP_select" class="form-control" required>
                                <option hidden>Select any final crematory:</option>
                                <?php 
                                while($dropdown_city_cld = mysqli_fetch_assoc($finalcrematoryResult)) {                 
                                    ?>
                                    <option value="<?php echo ($dropdown_city_cld['id']); ?>">caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['PartyOfInformant']); ?></option>
                                <?php }?>
                            </select>
                            <br>
                            <br>
                            <?php } else{echo ('no option to be selected');}?>
                            <?php include('inc/crematory.php'); ?>
                        </div>
                    </div>
                </div>
                
            </div>
            
            <!-- <div class="d-block text-center card-footer">
                <button type="button" class="btn-wide btn btn-primary pull-left">Back to Home</button>
                <button class="btn-wide btn btn-success pull-right" onclick="savePreNeedForm()">Save</button>
            </div> -->
            
        </div>
        <!-- </form> -->
    </div>
</div>
</div>
<?php include('inc/footer.php'); ?>
