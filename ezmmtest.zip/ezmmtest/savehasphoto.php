<?php 
/** This file is used to manage sections which include photo/logo */ 

session_start();
require 'database/connectDatabase.php';
$reTable = $_POST['recurrings_table'];
$selcaseID = $_SESSION['selectedcaseID'];
if( isset($_SESSION['userid'])){
    if (isset($_FILES['uploadedFile']) && $_FILES['uploadedFile']['error'] === UPLOAD_ERR_OK) {
        # code...
        $fileTmpPath = $_FILES['uploadedFile']['tmp_name'];
        $fileName = $_FILES['uploadedFile']['name'];
        $fileSize = $_FILES['uploadedFile']['size'];
        $fileType = $_FILES['uploadedFile']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));
        $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
        if (!file_exists('./uploads/casebiophoto')) {
            mkdir('./uploads/casebiophoto', 0777, true);
        }
        if (!file_exists('./uploads/companylogs')) {
            mkdir('./uploads/companylogs', 0777, true);
        }
        if (!file_exists('./uploads/userphotos')) {
            mkdir('./uploads/userphotos', 0777, true);
        }
        if (!file_exists('./uploads/documents')) {
            mkdir('./uploads/documents', 0777, true);
        }
        if (!file_exists('./uploads/images')) {
            mkdir('./uploads/images', 0777, true);
        }

        switch ($_POST['postaction']) {
            case 'subm_savedeceasedinfo':
                $uploadFileDir = './uploads/casebiophoto/';//case-bio photos
                break;
            case 'subm_editdeceasedinfo':
                $uploadFileDir = './uploads/casebiophoto/';//case-bio photos
                break;
            case 'subm_savenewuserinfo':
                $uploadFileDir = './uploads/companylogs/';//user's company log image by himself/herself
                break;
            case 'subm_editrecurring':
                $uploadFileDir = './uploads/userphotos/';//user's photo by userAdmin/superAdmin
                break;
            case 'subm_savedoc':
                $uploadFileDir = './uploads/documents/';//documents
                break;
            case 'subm_saveimage':
                $uploadFileDir = './uploads/images/';//images
                break;
            default:
                $uploadFileDir = './uploads/';//default upload path
                break;
        }
        $dest_path = $uploadFileDir . $newFileName;
        if(move_uploaded_file($fileTmpPath, $dest_path))
        {
            $message = true;
        }else
        {
            $message = false;
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }
    
    if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_savedeceasedinfo' ){ // Not used until now but save new deceased person;
        $sql = "INSERT INTO cases (staffID, status, createddate) VALUES ('".$_SESSION['userid']."','Case-Bio',curdate())";
        if ($conn->query($sql) === TRUE) {
            $caseID = $conn->insert_id;
            $sql = "INSERT INTO ".$reTable." (caseID, username, firstName, lastName, dateOfBirth, dateOfDeath, Citizenship, Race, Religion, PlaceOfBirth, Ancestry, Business, States, InCommunitySInce, MovedFrom, Photo ) VALUES ('".$caseID."','".$_SESSION['username']."','". $_POST['DES_firstname']."','". $_POST['DES_lastname']."','". $_POST['DES_DOB']."','". $_POST['DES_DOD']."','". $_POST['DES_DOB']."','". $_POST['DES_citizenship']."','". $_POST['DES_race']."','". $_POST['DES_religion']."','". $_POST['DES_PlaceOfBirth']."','". $_POST['DES_ancestry']."','". $_POST['DES_Business']."','".$_POST['DES_occupation']."','".$_POST['DES_InCommunitySInce']."','".$_POST['DES_MovedFrom']."','".$newFileName."')";            
            if ($conn->query($sql) === TRUE) {    
                $response = array('status' => 'created');
                echo json_encode($response); return;
            } else {
                $response = array('status' => 'error');
                echo json_encode($response); return;
            } 
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_editdeceasedinfo' ){ // update recent deceased person
        if (isset($newFileName)) {
            # code...
            $sql = "UPDATE ".$reTable." SET firstName='".$_POST['DES_firstname']."',lastName='".$_POST['DES_lastname']."',dateOfBirth='".$_POST['DES_DOB']."',dateOfDeath='".$_POST['DES_DOD']."',Citizenship='".$_POST['DES_citizenship']."',Race='".$_POST['DES_race']."',Religion='".$_POST['DES_religion']."',PlaceOfBirth='".$_POST['DES_PlaceOfBirth']."',Ancestry='".$_POST['DES_ancestry']."',Business='".$_POST['DES_Business']."',States='".$_POST['DES_occupation']."',InCommunitySInce='".$_POST['DES_InCommunitySInce']."',MovedFrom='".$_POST['DES_MovedFrom']."',Photo='".$newFileName."' WHERE id='".$_POST['rowId']."'";
        }else{
            $sql = "UPDATE ".$reTable." SET firstName='".$_POST['DES_firstname']."',lastName='".$_POST['DES_lastname']."',dateOfBirth='".$_POST['DES_DOB']."',dateOfDeath='".$_POST['DES_DOD']."',Citizenship='".$_POST['DES_citizenship']."',Race='".$_POST['DES_race']."',Religion='".$_POST['DES_religion']."',PlaceOfBirth='".$_POST['DES_PlaceOfBirth']."',Ancestry='".$_POST['DES_ancestry']."',Business='".$_POST['DES_Business']."',States='".$_POST['DES_occupation']."',InCommunitySInce='".$_POST['DES_InCommunitySInce']."',MovedFrom='".$_POST['DES_MovedFrom']."' WHERE id='".$_POST['rowId']."'";
        }

        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'updated');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }

    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_deldeceasedinfo' ){ // Delect selected deceased person
        $sql = "DELETE FROM ".$reTable." WHERE id='".$_POST['rowId']."'"; 
        
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'deleted');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_savenewuserinfo' ){ // save new user's funeral home/crematory by himself/herself with his/her companyLog after first login
        $role = $_SESSION['userrole'] == 'adminstaff'? $_SESSION['userrole']:'staff';
        if (isset($newFileName)) { //if photo has its object
            # code...
            $sql = "UPDATE ".$reTable." SET crematory='".$_POST['FUNHOMCRE_FullName']."', address1='".$_POST['FUNHOMCRE_Address1']."', address2='".$_POST['FUNHOMCRE_Address2']."', city='".$_POST['FUNHOMCRE_City']."', states='".$_POST['FUNHOMCRE_State']."', zip='".$_POST['FUNHOMCRE_Zip']."', contactemail='".$_POST['FUNHOMCRE_Email']."', phone='".$_POST['FUNHOMCRE_phone']."', contact='".$_POST['FUNHOMCRE_Contact']."', license='".$_POST['FUNHOMCRE_l']."', role='".$role."', StateLicensed='".$_POST['FUNHOMCRE_State']."', companylogo='".$newFileName."' WHERE id='".$_SESSION['userid']."'";           
        } else{// if no photo object
            $sql = "UPDATE ".$reTable." SET crematory='".$_POST['FUNHOMCRE_FullName']."', address1='".$_POST['FUNHOMCRE_Address1']."', address2='".$_POST['FUNHOMCRE_Address2']."', city='".$_POST['FUNHOMCRE_City']."', states='".$_POST['FUNHOMCRE_State']."', zip='".$_POST['FUNHOMCRE_Zip']."', contactemail='".$_POST['FUNHOMCRE_Email']."', phone='".$_POST['FUNHOMCRE_phone']."', contact='".$_POST['FUNHOMCRE_Contact']."', license='".$_POST['FUNHOMCRE_l']."', role='".$role."', StateLicensed='".$_POST['FUNHOMCRE_State']."' WHERE id='".$_SESSION['userid']."'";           
        }
        
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'created');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_editrecurring' ){ // Control new staff with its permission etc
        $STFF_canC = (isset($_POST['STFF_canC']) ) ? 'Y': 'N';
        $STFF_canR = (isset($_POST['STFF_canR']) ) ? 'Y': 'N';
        $STFF_canU = (isset($_POST['STFF_canU']) ) ? 'Y': 'N';
        $STFF_canD = (isset($_POST['STFF_canD']) ) ? 'Y': 'N';
        if (isset($newFileName)) {
            # code...
            $sql = "UPDATE ".$reTable." SET useradminid='".$_SESSION['userid']."', username='".$_POST['STFF_name']."', email='".$_POST['STFF_email']."', address1='".$_POST['STFF_address1']."', cancreate='".$STFF_canC."', canread='".$STFF_canR."', canupdate='".$STFF_canU."', candelete='".$STFF_canD."', address2='".$_POST['STFF_address2']."', city='".$_POST['STFF_city']."', states='".$_POST['STFF_state']."', zip='".$_POST['STFF_zip']."', phone='".$_POST['STFF_phone']."', HireDate='".$_POST['STFF_hiredate']."', TerminationDate='".$_POST['STFF_termidate']."', license='".$_POST['STFF_license']."', LicValidDate='".$_POST['STFF_licenseddate']."', StateLicensed='".$_POST['STFF_state2']."', note='".$_POST['STFF_note']."', photo='".$newFileName."' WHERE id='".$_POST['rowId']."'";           
        } else{
            $sql = "UPDATE ".$reTable." SET useradminid='".$_SESSION['userid']."', username='".$_POST['STFF_name']."', email='".$_POST['STFF_email']."', address1='".$_POST['STFF_address1']."', cancreate='".$STFF_canC."', canread='".$STFF_canR."', canupdate='".$STFF_canU."', candelete='".$STFF_canD."', address2='".$_POST['STFF_address2']."', city='".$_POST['STFF_city']."', states='".$_POST['STFF_state']."', zip='".$_POST['STFF_zip']."', phone='".$_POST['STFF_phone']."', HireDate='".$_POST['STFF_hiredate']."', TerminationDate='".$_POST['STFF_termidate']."', license='".$_POST['STFF_license']."', LicValidDate='".$_POST['STFF_licenseddate']."', StateLicensed='".$_POST['STFF_state2']."', note='".$_POST['STFF_note']."' WHERE id='".$_POST['rowId']."'";           
        }
        
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'updated');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_delrecurring' ){ // Delect selected staff
        $sql = "DELETE FROM ".$reTable." WHERE id='".$_POST['rowId']."'"; 
        
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'deleted');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && ($_POST['postaction'] == 'subm_savedoc' || $_POST['postaction'] == 'subm_saveimage' ) ){ // save new document/image per recent caseID
        $sql = "SELECT * FROM ".$reTable." WHERE caseID='".$selcaseID."';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {   //there is already same caseID as selectedCaseID in the non-mulit table.
            $response = array('status' => 'existcase','existcaseID'=>$selcaseID);
            echo json_encode($response); return;
        }  

        if (isset($newFileName)) { //if doc has its object
            $sql = "INSERT INTO ".$reTable." (caseID, staffID, filename) VALUES ('".$selcaseID ."','".$_SESSION['userid']."','".$newFileName."')";
        } else{// if no photo object
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
        
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'created', 'caseID'=>$selcaseID );
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && ($_POST['postaction'] == 'subm_deldoc' || $_POST['postaction'] == 'subm_delimage' ) ){ // Delect selected staff
        $sql = "DELETE FROM ".$reTable." WHERE id='".$_POST['rowId']."'"; 
        
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'deleted');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }
}
else{ 
    $response = array('status' => 'sessionexpired');
    echo json_encode($response); return;
}
?>