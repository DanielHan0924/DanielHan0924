jQuery(document).ready(function() {
    
    // Required field validation
    $('.required').on('blur',function(){
        if($(this).val() == '') {
            $(this).parent(".form-group").children( ".invalid-feedback" ).show().text('This is required field');
            $(this).parent(".form-group").children( ".valid-feedback" ).hide().text('');
        } else {
            $(this).parent(".form-group").children( ".invalid-feedback" ).hide().text('');
            $(this).parent(".form-group").children( ".valid-feedback" ).show().text('Looks Good!');
        }
    });
    
     // SSN Validate
     var ssn_pattern = /^\d{3}-\d{2}-\d{4}$/;
     $(".mask_ssn").inputmask("999-99-9999", {
            placeholder: "",
            clearMaskOnLostFocus: true,
        });
    $(".mask_ssn").on('blur',function(){
        
        if($(this).val().match(ssn_pattern) == null) {
            $(this).parent(".form-group").children( ".invalid-feedback" ).show().text('Invalid or missing SSN');
            $(this).parent(".form-group").children( ".valid-feedback" ).hide().text('');
        } else {
            $(this).parent(".form-group").children( ".invalid-feedback" ).hide().text('');
            $(this).parent(".form-group").children( ".valid-feedback" ).show().text('Looks Good!');
        }
    });
    
    // Phone Validate
     var phone_pattern = /^\([0-9]{3}\) [0-9]{3}-[0-9]{4}$/;
     $(".mask_phone").inputmask("mask", {
            "mask": "(999) 999-9999"
        });
        
    $(".mask_phone").on('blur',function(){
        
        if($(this).val().match(phone_pattern) == null) {
            $(this).parent(".form-group").children( ".invalid-feedback" ).show().text('Invalid or missing Phone');
            $(this).parent(".form-group").children( ".valid-feedback" ).hide().text('');
        } else {
            $(this).parent(".form-group").children( ".invalid-feedback" ).hide().text('');
            $(this).parent(".form-group").children( ".valid-feedback" ).show().text('Looks Good!');
        }
    });
    
    // Phone2 Mask Only
     $(".mask_phone2").inputmask("mask", {
            "mask": "(999) 999-9999",
            "clearIncomplete":true
        });
        
    
    // Zip Validate
    var zip_pattern = /^[0-9]{5}$/;
     $(".mask_zip").inputmask("mask", {
            "mask": "99999"
        });
        
    $(".mask_zip").on('blur',function(){
        
         if($(this).val().match(zip_pattern) == null) {
            $(this).parent(".form-group").children( ".invalid-feedback" ).show().text('Invalid or missing Zip');
            $(this).parent(".form-group").children( ".valid-feedback" ).hide().text('');
        } else {
            $(this).parent(".form-group").children( ".invalid-feedback" ).hide().text('');
            $(this).parent(".form-group").children( ".valid-feedback" ).show().text('Looks Good!');
        }
    });
    
    // Email validate
    
    
    var email_pattern = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
     $("input[type=email]").on('blur',function(){
        
         if($(this).val().match(email_pattern) == null) {
            $(this).parent(".form-group").children( ".invalid-feedback" ).show().text('Invalid or missing Email');
            $(this).parent(".form-group").children( ".valid-feedback" ).hide().text('');
        } else {
            $(this).parent(".form-group").children( ".invalid-feedback" ).hide().text('');
            $(this).parent(".form-group").children( ".valid-feedback" ).show().text('Looks Good!');
        }
    });
    
    $("#martialstatus").on("change",function(){
       if($(this).val() != 'Single') {
           $(".hidden-martial-status").show();
       } else {
           $(".hidden-martial-status").hide();
       }
    });
    
    $("#spousedeceased").on("change",function(){
       if($(this).val() == 'Yes') {
           $(".hidden-deceased-status").show();
       } else {
           $(".hidden-deceased-status").hide();
       }
    });
 });

function isJson(data) {
    if (/^[\],:{}\s]*$/.test(data.replace(/\\["\\\/bfnrtu]/g, '@').
        replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
        replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
    
      return true;    
    }else{
    
      return false;    
    }   
}

function logout() {
    var data = "signout=true";
    $.post(
        'database/login.php',
        data,
        function (data) {
        var result = JSON.parse(data);
        if (result.status == "OK") {
            window.location = "login.php";
        }
    });
}

function registerButton() {
    var username =  document.getElementById("username").value;
    var email =  document.getElementById("email").value;
    var new_password =  document.getElementById("new_password").value;
    var confirm_password =  document.getElementById("confirm_password").value;

    if (new_password != confirm_password) {
        alert("Passwords Do Not Match!")
		throw "Passwords Do Not Match!"
    } else if ((username == "") || (email == "") || (new_password == "") || (confirm_password == "")) {
        alert("Please fill out all fields!")
		throw "Please fill out all fields!"
    } else {
        var form = $(".singup_form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/saveuser.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            window.location = "login.php";
                        }else {
                            if (result.error == "name") {
                                alert("This UserName is already taken.");
                            } else if (result.error == "email") {
                                alert("This email is already taken.");
                            } else if (result.error == "captcha") {
                                alert("Captcha Validation Required!");
                            }
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    }
}

function loginButton() {
    var form = $(".login_form")[0];
    var formData = new FormData(form);

    $.ajax(
        {
            url: "database/login.php",
            type: 'POST',
            async: true,
            data: formData,
            success: function (response) {
                if (isJson(response)) {
                    var result = JSON.parse(response);
                    if (result.status == "OK") {
                        window.location = "welcome.php";
                    } else if(result.status == "NEWUSER"){
                        window.location = "admin.php";
                    }else if(result.status == "CaptchaERROR"){
                        alert("Captcha Validation Required!");
                    }else {
                        alert("Invalid User");
                    }
                } else {
                    console.log("Response is not json", response);
                }
            },
            error: function (error) {
                console.log(error);
            },
            cache: false,
            contentType: false,
            processData: false
        }
    );
}

function addChildren() {
    var card = $("#pre-need-child");
    var validate_data = true;
    document.getElementById("pre-need-child").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
        }
    });

    if (validate_data) {
        var html = "<div class='card-body' id='pre-need-child'>" + $(card).html() + "</div>";
        $(card).removeAttr("id");
        $(card).after(html);
        var card = $("#pre-need-child");
        $(card).find("input").val("");
    } else {
        alert("Please input full name.");
    }
}

function addGrandChildren() {
    var card = $("#pre-need-grandchild");
    var validate_data = true;
    document.getElementById("pre-need-grandchild").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
        }
    });

    if (validate_data) {
        var html = "<div class='card-body' id='pre-need-grandchild'>" + $(card).html() + "</div>";
        $(card).removeAttr("id");
        $(card).after(html);
        var card = $("#pre-need-grandchild");
        $(card).find("input").val("");
    } else {
        alert("Please input full name.");
    }
}

function savePreNeedForm() {
    var validate_data = true;
    document.getElementById("preneed-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });

    if (validate_data) {
        var form = $("#preneed-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/pre-need.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function saveAtNeedForm() {
    var validate_data = true;
    document.getElementById("atneed-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });

    if (validate_data) {
        var form = $("#atneed-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/at-need.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function addContrators() {
    var card = $("#contractor-section");
    var validate_data = true;
    document.getElementById("contractor-section").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
        }
    });

    if (validate_data) {
        var html = "<div class='card-body' id='contractor-section'>" + $(card).html() + "</div>";
        $(card).removeAttr("id");
        $(card).after(html);
        var card = $("#contractor-section");
        $(card).find("input").val("");
    } else {
        alert("Please input full name.");
    }
}

function saveContractorForm() {
    var validate_data = true;
    document.getElementById("contractor-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });

    var checkBox = $("input[type='checkbox']");
    for(var i = 0; i < $(checkBox).length; i ++) {
        if (!$(checkBox[i]).prop("checked")) {
            $(checkBox[i]).val("N");
            $(checkBox[i]).prop('checked', true);
        }
    }
    
    if (validate_data) {
        var form = $("#contractor-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/contractor.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function saveFirstCallForm() {
    var validate_data = true;
    document.getElementById("firstcall-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });
    
    if (validate_data) {
        var form = $("#firstcall-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/first-call.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function addGreatChild() {
    var card = $("#great_grand_child");
    var validate_data = true;
    document.getElementById("great_grand_child").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
        }
    });

    if (validate_data) {
        var html = "<div class='card-body' id='great_grand_child'>" + $(card).html() + "</div>";
        $(card).removeAttr("id");
        $(card).after(html);
        var card = $("#great_grand_child");
        $(card).find("input").val("");
    } else {
        alert("Please input full name.");
    }
}

function addGreatGreatChild() {
    var card = $("#great_great_grand_child");
    var validate_data = true;
    document.getElementById("great_great_grand_child").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
        }
    });

    if (validate_data) {
        var html = "<div class='card-body' id='great_great_grand_child'>" + $(card).html() + "</div>";
        $(card).removeAttr("id");
        $(card).after(html);
        var card = $("#great_great_grand_child");
        $(card).find("input").val("");
    } else {
        alert("Please input full name.");
    }
}

function saveCaseBioForm() {
    var validate_data = true;
    document.getElementById("casebio-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });
    
    if (validate_data) {
        var form = $("#casebio-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/case-bio.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function saveVitalStatisticsForm() {
    var validate_data = true;
    document.getElementById("vitalstatistics-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });
    
    if (validate_data) {
        var form = $("#vitalstatistics-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/vital-statistics.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function addSurviving() {
    var card = $("#surviving_child");
    var validate_data = true;
    document.getElementById("surviving_child").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
        }
    });

    var items = $(card).find(".valid-feedback");

    if (validate_data) {
        var html = "<div class='card-body' id='surviving_child'>" + $(card).html() + "</div>";
        $(card).removeAttr("id");
        $(card).after(html);
        var card = $("#surviving_child");
        $(card).find("input").val("");
        $(card).find(".valid-feedback").text("");
        $(card).find(".invalid-feedback").text("");
        
    } else {
        alert("Please input required fileds.");
    }
}

function saveSurvivingForm() {
    var validate_data = true;
    document.getElementById("surviving-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });
    
    if (validate_data) {
        var form = $("#surviving-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/suviving-relatives.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function addVisitation() {
    var card = $("#visitation_child");
    var validate_data = true;
    document.getElementById("visitation_child").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
        }
    });

    var items = $(card).find(".valid-feedback");

    if (validate_data) {
        var html = "<div class='card-body' id='visitation_child'>" + $(card).html() + "</div>";
        $(card).removeAttr("id");
        $(card).after(html);
        var card = $("#visitation_child");
        $(card).find("input").val("");
        $(card).find(".valid-feedback").text("");
        $(card).find(".invalid-feedback").text("");
        
    } else {
        alert("Please input required fileds.");
    }
}

function addService() {
    var card = $("#service_child");
    var validate_data = true;
    document.getElementById("service_child").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
        }
    });

    var items = $(card).find(".valid-feedback");

    if (validate_data) {
        var html = "<div class='card-body' id='service_child'>" + $(card).html() + "</div>";
        $(card).removeAttr("id");
        $(card).after(html);
        var card = $("#service_child");
        $(card).find("input").val("");
        $(card).find(".valid-feedback").text("");
        $(card).find(".invalid-feedback").text("");
        
    } else {
        alert("Please input required fileds.");
    }
}

function saveFinalArrangeForm() {
    var validate_data = true;
    document.getElementById("final-arrangement-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });
    
    if (validate_data) {
        var form = $("#final-arrangement-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/final-arrangement.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function addChildForm(e) {
    var id = "#" + e;
    var card = $(id);
    var validate_data = true;
    document.getElementById(e).querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
        }
    });

    if (validate_data) {
        var html = "<div class='card-body' id='" + e + "'>" + $(card).html() + "</div>";
        $(card).removeAttr("id");
        $(card).after(html);
        var card = $(id);
        $(card).find("input[type='text']").val("");
        $(card).find("input[type='email']").val("");
        $(card).find("input[type='date']").val("");
        $(card).find("input[type='time']").val("");
        $(card).find("textarea").val("");
        $(card).find("input[type='checkbox']").prop('checked', false);
        $(card).find(".valid-feedback").text("");
        $(card).find(".invalid-feedback").text("");
        
    } else {
        alert("Please input required fileds.");
    }
}

function saveStatementForm() {
    var validate_data = true;
    document.getElementById("statement-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });
    
    var checkBox = $("input[type='checkbox']");
    for(var i = 0; i < $(checkBox).length; i ++) {
        if (!$(checkBox[i]).prop("checked")) {
            $(checkBox[i]).val("N");
            $(checkBox[i]).prop('checked', true);
        }
    }

    if (validate_data) {
        var form = $("#statement-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/statement.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function saveMembershipForm() {
    var validate_data = true;
    document.getElementById("membership-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });

    if (validate_data) {
        var form = $("#membership-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/membership.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function saveOrganizationForm() {
    var validate_data = true;
    document.getElementById("organization-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });

    if (validate_data) {
        var form = $("#organization-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/organization.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function saveVisitorForm() {
    var validate_data = true;
    document.getElementById("visitor-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });

    if (validate_data) {
        var form = $("#visitor-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/visitor.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function saveStaffForm() {
    var validate_data = true;
    document.getElementById("staff-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });

    if (validate_data) {
        var form = $("#staff-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/staff.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}

function saveMediaForm() {
    var validate_data = true;
    document.getElementById("media-form").querySelectorAll("[required]").forEach(function(i) {
        if (!i.value) {
            validate_data = false;
            return;
        }
    });

    if (validate_data) {
        var form = $("#media-form")[0];
        var formData = new FormData(form);

        $.ajax(
            {
                url: "database/media.php",
                type: 'POST',
                async: true,
                data: formData,
                success: function (response) {
                    if (isJson(response)) {
                        var result = JSON.parse(response);
                        if (result.status == "OK") {
                            location.reload();
                        } else {
                            alert("Form data is not available");
                        }
                    } else {
                        console.log("Response is not json", response);
                    }
                },
                error: function (error) {
                    console.log(error);
                },
                cache: false,
                contentType: false,
                processData: false
            }
        );
    } else {
        alert("Please input required fields");
    }
}