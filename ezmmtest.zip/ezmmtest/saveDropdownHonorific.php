<?php 
session_start();
require 'database/connectDatabase.php';
if( isset($_SESSION['username'])){
    
    if(isset($_POST['MD_dropdown_add']) && $_POST['MD_dropdown_add'] != '' ){ // save new one
        // check if there is already same option
        $sql = "SELECT * FROM ".$_POST['MD_dropdown_table']." WHERE name='".$_POST['MD_dropdown_add']."';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $response = array('status' => 'exist');
            echo json_encode($response); return;
        }

        $sql = "INSERT INTO ".$_POST['MD_dropdown_table']." (name) VALUES ('".$_POST['MD_dropdown_add']."')";
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'created');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }

    }else if(isset($_POST['MD_dropdown_edit']) && $_POST['MD_dropdown_edit'] != ''){ // update recent one
        $sql = "UPDATE ".$_POST['MD_dropdown_table']." SET name='".$_POST['MD_dropdown_edit']."' WHERE name='".$_POST['MD_dropdown_org']."'";

        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'updated');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else { //delete recent one
        $sql = "DELETE FROM ".$_POST['MD_dropdown_table']." WHERE name='".$_POST['MD_dropdown_del']."'";
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'deleted');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }
}
else{ // session expired
    $response = array('status' => 'sessionExpired');
    echo json_encode($response); return;
}
?>