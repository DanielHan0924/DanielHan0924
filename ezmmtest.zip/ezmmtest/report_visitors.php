<?php
    session_start();
    if (isset($_SESSION['userid'])) {
        require 'database/connectDatabase.php';
        require_once __DIR__ . '/vendor/autoload.php';

        $sql = "SELECT * FROM users WHERE id='".$_SESSION['userid']."';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $user_info = mysqli_fetch_assoc($result);
            $sql = "SELECT name FROM dropdown_city WHERE id='".$user_info['city']."';";
            $user_info_city = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_state WHERE id='".$user_info['states']."';";
            $user_info_state = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_zip WHERE id='".$user_info['zip']."';";
            $user_info_zip = mysqli_fetch_array($conn->query($sql));
        }

        $sql = "SELECT * FROM cases WHERE id='".$_SESSION['selectedcaseID']."';";
        $result = $conn->query($sql);
        $case_info = mysqli_fetch_assoc($result);
        $tbl_name = 'pre_need_pi';
        switch ($case_info['status']) {
            case 'At-Need':
                $tbl_name = 'at_need_pi';
                break;
            case 'First-Call':
                $tbl_name = 'first_call_pi';
                break;
            case 'Case-Bio':
                $tbl_name = 'case_bio_deceased_info';
                break;
            default://how can the pre-need have visitors before it move onto next step like at-need etc?
                break;
        }
        $sql = "SELECT * FROM ".$tbl_name." WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $result = $conn->query($sql);
        $deceased_info = mysqli_fetch_assoc($result);
        $firstName = $deceased_info['firstName'];
        $lastNameID = $deceased_info['lastName'];
            $sql = "SELECT * FROM dropdown_lastname WHERE id='".$lastNameID."';";
            $lastName = mysqli_fetch_array($conn->query($sql))['name'];

        $dob = $deceased_info['dateOfBirth'];
        $dod = isset($deceased_info['dateOfDeath'])?$deceased_info['dateOfDeath']:'--';
        $ageAtDeath = 'Still surviving';
        if ($dod!='--') {
            $dateOfDeath_obj = new DateTime($dod);
            $dateOfBirth_obj = new DateTime($dob);
            $ageAtDeath = $dateOfBirth_obj->diff($dateOfDeath_obj)->format('%y years old');
        }
    
        $sql = "SELECT * FROM visitor WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $visitors = $conn->query($sql);

        $reportdate = date("d/m/y");
        $reporttime = date("h:i:sa");

        $header = '<div style="margin-top: 2.5cm; margin-bottom: 0.5cm;margin-left: 0.5cm;">
                        <table width="100%" style=" font-family: sans-serif;">
                            <tr>
                                <td width="80%" style="color:#0000BB;">
                                    <span style="font-weight: bold; font-size: 14pt;">Visitors (log of all visitors to funeral services) for family to thank</span><br /><br/>
                                    '.$user_info['crematory'].'<br />'.$user_info['address1'].'<br />'.$user_info['address2'].'<br />
                                    '.$user_info_city['name'].', '.$user_info_state['name'].', '.$user_info_zip['name'].'
                                    <span style="font-size: 15pt;">☎</span>'.$user_info['phone'].' , '.$user_info['contactemail'].'
                                </td>
                                <td width="20%" style="text-align: right; vertical-align: top;">
                                    Case ID.<br />
                                    <span style="font-weight: bold; font-size: 12pt;">'.$_SESSION['selectedcaseID'].'</span><br/><br/>
                                    '.$reportdate.'<br/>'.$reporttime.'
                                </td>
                            </tr>
                        </table>   
                    </div>';
        $title = '<div style="margin-top: 0.5cm;margin-bottom: 0cm;margin-left: 2cm; color: red;">
                        <div style="text-align: left; font-family: sans-serif;">
                            Visitors for '.$firstName.' '.$lastName.' ( '.$dob.' To '.$dod.' , '.$ageAtDeath.' )
                        </div><br/>
                    </div>';
        require __DIR__ . '/vendor/autoload.php';
        $mpdf = new \Mpdf\Mpdf();
        $mpdf->setFooter('{PAGENO}');

        $mpdf->WriteHTML($header);
        $mpdf->WriteHTML($title);
        $report_visitors_header = '<div style="border: 1px solid red; margin-top: 0.5cm;"><br/>';
        $report_visitors_body = '';
        $report_visitors_footer = '</div>';
        if (mysqli_num_rows($visitors) > 0) {
            $rowcount = 0;
            while ($visitorsResult_row = mysqli_fetch_assoc($visitors)) {
                $rowcount ++;
                $sql = "SELECT name FROM dropdown_city WHERE id='".$visitorsResult_row['City']."';";
                $visitorsResult_row_city = mysqli_fetch_array($conn->query($sql));
                $sql = "SELECT name FROM dropdown_state WHERE id='".$visitorsResult_row['States']."';";
                $visitorsResult_row_state = mysqli_fetch_array($conn->query($sql));
                $sql = "SELECT name FROM dropdown_zip WHERE id='".$visitorsResult_row['Zip']."';";
                $visitorsResult_row_zip = mysqli_fetch_array($conn->query($sql));
                $visitorsResult_row_address2 = $visitorsResult_row['address2']!=''?$visitorsResult_row['address2']:'--';
                $report_visitors_body .= '
                    <table width="100%" style=" font-family: sans-serif;">
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Fullname</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Email</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Gift</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$visitorsResult_row['Name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$visitorsResult_row['Email'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$visitorsResult_row['gift'].'</span>
                            </td>

                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address1</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address2</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$visitorsResult_row['Address1'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$visitorsResult_row_address2.'</span>
                            </td>

                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">City</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">State</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Zip</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Phone</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$visitorsResult_row_city['name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$visitorsResult_row_state['name'].'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$visitorsResult_row_zip['name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$visitorsResult_row['phone'].'</span>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_____________________________________________________________________________________________';
            }
            $report_visitors_total = $report_visitors_header.$report_visitors_body.$report_visitors_footer;
            $mpdf->WriteHTML($report_visitors_total);
        } else {
            $mpdf->WriteHTML('There is no visitor for this caseID.');  
        }

        $report_footer = '<div style="border: 1px solid green; margin-top: 0.2cm;">
                    <div style="text-align: left; font-family: sans-serif;">
                    </div><br/>
                    <div style="text-align: left; margin-left:2cm; font-family: sans-serif;">
                    Sign by CLIENT_______________________ <br/><br/>Sign HOME agent or representative   __________________________<br/>
                                      
                    </div><br/>
                    <div style="text-align: left; margin-left:6cm; font-family: sans-serif;">
                    Sign date: _____/_____/____________ <br/>
                                      
                    </div><br/></div>';
        $mpdf->WriteHTML($report_footer);  
        $mpdf->Output();
    } else {
        header('Location: login.php');
    }
?>
    