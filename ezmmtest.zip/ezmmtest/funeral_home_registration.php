<?php 
    include('inc/header.php');
?>
                                <div class="page-title-heading">
                                    <div><h3>REGISTRATION</h3></div>    
                                </div>
                                   </div>
                        </div>    
                        
                        <div class="row">
                            <div class="col-md-12">
                                <form class="longforms" novalidate action="javascript:" method="POST">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                       <div class="row">
                                            <div class="col-lg-10">
                                            <nav class="" aria-label="breadcrumb">
                                                            <ol class="breadcrumb">
                                                                <li class="breadcrumb-item" aria-current="page">John - Doe - 12/18/1997 - 02/17/2020</li>
                                                            </ol>
                                            </nav>
                                            <h5 class="card-title custom-head">FUNERAL HOME/CREMATORY </h5>
                                            </div>
                                            <div class="col-lg-2">
                                                <div class="image-holder">
                                                    <img src="assets/images/oldman.jpeg" />
                                                    <div class="d-block text-center card-footer">
                                                    <button class="btn-sm btn-block btn btn-success">Save</button>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                                        <div class="card">
                                            <div id="headingOne" class="card-header">
                                                <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                                    <h5 class="m-0 p-0">FUNERAL HOME/CREMATORY</h5>
                                                </button>
                                            </div>
                                            <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                                                <div class="card-body">
                                                    <?php include('inc/funeral_home_crematory_registration.php'); ?>
                                                
                                            </div>
                                        </div>
                                        </div>
                                        <div class="card">
                                            <div id="headingTwo" class="b-radius-0 card-header">
                                                <button type="button" data-toggle="collapse" data-target="#collapseOne2" aria-expanded="false" aria-controls="collapseTwo" class="text-left m-0 p-0 btn btn-link btn-block">
                                                    <h5 class="m-0 p-0">STAFF</h5></button>
                                            </div>
                                            <div data-parent="#accordion" id="collapseOne2" class="collapse">
                                                <div class="card-body">
                                                    <?php include('inc/staff.php'); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <div id="headingTwo" class="b-radius-0 card-header">
                                                <button type="button" data-toggle="collapse" data-target="#collapseOne3" aria-expanded="false" aria-controls="collapseThree" class="text-left m-0 p-0 btn btn-link btn-block">
                                                    <h5 class="m-0 p-0">VISITATION ROOMS</h5></button>
                                            </div>
                                            <div data-parent="#accordion" id="collapseOne3" class="collapse">
                                                <div class="card-body">
                                                    <!--REPLACE WITH INC FORM -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <div id="headingTwo" class="b-radius-0 card-header">
                                                <button type="button" data-toggle="collapse" data-target="#collapseOne4" aria-expanded="false" aria-controls="collapseFour" class="text-left m-0 p-0 btn btn-link btn-block">
                                                    <h5 class="m-0 p-0">CHAPEL</h5></button>
                                            </div>
                                            <div data-parent="#accordion" id="collapseOne4" class="collapse">
                                                <div class="card-body">
                                                <!--REPLACE WITH INC FORM -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <div id="headingTwo" class="b-radius-0 card-header">
                                                <button type="button" data-toggle="collapse" data-target="#collapseOne10" aria-expanded="false" aria-controls="collapseFour" class="text-left m-0 p-0 btn btn-link btn-block">
                                                    <h5 class="m-0 p-0">PREPARATION ROOMS</h5></button>
                                            </div>
                                            <div data-parent="#accordion" id="collapseOne10" class="collapse">
                                                <div class="card-body">
                                                <!--REPLACE WITH INC FORM -->
                                                </div>
                                            </div>
                                        </div>
                                       
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="d-block text-center card-footer">
                                        <button type="button" class="btn-wide btn btn-primary pull-left">Back to Home</button>
                                        <button type="button" class="btn-wide btn btn-success pull-right">Save</button>
                                    </div>
                                    
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php include('inc/footer.php'); ?>
