<!DOCTYPE html>
<html>
<head>
	<title>Login :: EZM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
	
	<!-- <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> -->
	<!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" > -->
    
    <link href="./assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="./assets/css/all.css" rel="stylesheet">

    <!--Fontawesome CDN-->
    
	<!--Custom styles-->
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="overlay"></div>
<div class="container">
<?php 
	$site_key = '6LcnP6kUAAAAAG28XmCbMXAbbtkxfsO0ckr9obJO';
?>
	<div class="d-flex justify-content-center h-100">
		<div class="card">
			<div class="card-header">
				<h3>Log In</h3>
				<div class="d-flex justify-content-end social_icon">
					<span><img src="assets/images/ezm-logo.png" style="width:120px;"></span>
				</div>
			</div>
			<div class="card-body">
			    <div class="alert alert-danger d-none" id="message"></div>
				<form class="login_form">
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="text" class="form-control" placeholder="username" name="username">
						
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-key"></i></span>
						</div>
						<input type="password" class="form-control" placeholder="password" name="password">
					</div>
					<div class="row align-items-center remember">
						<input type="checkbox">Remember Me
					</div>
					<div class="g-recaptcha" data-sitekey="<?php echo $site_key; ?>"></div>
					<div id="mail-status"></div>
					<div class="form-group">
						<input type="button" value="Login" class="btn float-right" onclick="loginButton()">
					</div>
				</form>
			</div>
			<div class="card-footer">
				<div class="d-flex justify-content-center links">
					Don't have an account?<a href="register.php">Sign Up</a>
				</div>
				<div class="d-flex justify-content-center links">
					<a href="#">Forgot your password?</a>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script> -->
<script src="./assets/js/jquery-2.2.4.min.js"></script>
<script src="scripts/database.js"></script>
<script src="https://www.google.com/recaptcha/api.js"></script>

</body>
</html>