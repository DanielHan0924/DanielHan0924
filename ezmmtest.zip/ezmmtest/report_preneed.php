<?php
    session_start();
    if (isset($_SESSION['userid'])) {
        require 'database/connectDatabase.php';
        require_once __DIR__ . '/vendor/autoload.php';

        $sql = "SELECT * FROM users WHERE id='".$_SESSION['userid']."';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $user_info = mysqli_fetch_assoc($result);
        }
            $sql = "SELECT name FROM dropdown_city WHERE id='".$user_info['city']."';";
            $user_info_city = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_state WHERE id='".$user_info['states']."';";
            $user_info_state = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_zip WHERE id='".$user_info['zip']."';";
            $user_info_zip = mysqli_fetch_array($conn->query($sql));

        $sql = "SELECT * FROM pre_need_pi WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $pi = $conn->query($sql);
        if (mysqli_num_rows($pi) > 0) {
            $piResult = mysqli_fetch_assoc($pi);

            $sql = "SELECT name FROM dropdown_honorific WHERE id='".$piResult['honorific']."';";
            $piResult_honor = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_lastname WHERE id='".$piResult['lastName']."';";
            $piResult_last = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_suffix WHERE id='".$piResult['suffix']."';";
            $piResult_suf = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_city WHERE id='".$piResult['city']."';";
            $piResult_city = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_state WHERE id='".$piResult['states']."';";
            $piResult_state = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_zip WHERE id='".$piResult['zipCode']."';";
            $piResult_zip = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_township WHERE id='".$piResult['township']."';";
            $piResult_township = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_county WHERE id='".$piResult['country']."';";
            $piResult_county = mysqli_fetch_array($conn->query($sql));
            $piResult_middlename = $piResult['middleName']!=''?$piResult['middleName']:'--';
            $piResult_address2 = $piResult['address2']!=''?$piResult['address2']:'--';
        }
            
        
        $sql = "SELECT * FROM pre_need_nok WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $nokResult = $conn->query($sql);
        $nokResultCount = mysqli_num_rows($nokResult);

        $sql = "SELECT * FROM pre_need_marital WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $maritalResult = $conn->query($sql);
        $maritalResultCount = mysqli_num_rows($maritalResult);

        $sql = "SELECT * FROM pre_need_children WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $childResult = $conn->query($sql);
        $childResultCount = mysqli_num_rows($childResult);

        $sql = "SELECT * FROM pre_need_military_service WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $mltResult = $conn->query($sql);
        
        $sql = "SELECT * FROM pre_need_church WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $churchResult = $conn->query($sql);

        $sql = "SELECT * FROM pre_need_place_of_worship WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $powResult = $conn->query($sql);

        $sql = "SELECT * FROM pre_need_education WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $educationResult = $conn->query($sql);

        $sql = "SELECT * FROM pre_need_parents WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $parentsResult = $conn->query($sql);

        $sql = "SELECT * FROM pre_need_final_disposition WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $finaldispositionResult = $conn->query($sql);

        $sql = "SELECT * FROM pre_need_final_crematory WHERE staffID='".$_SESSION['userid']."' AND caseID='".$_SESSION['selectedcaseID']."';";
        $finalcrematoryResult = $conn->query($sql);

        // $conn->close();
        $reportdate = date("d/m/y");
        $reporttime = date("h:i:sa");

        $header = '<div style="margin-top: 2.5cm;margin-bottom: 0.5cm;margin-left: 0cm;margin-right: 0cm;">
                        <table width="100%" style=" font-family: sans-serif;">
                            <tr>
                                <td width="80%" style="color:#0000BB;">
                                    <span style="font-weight: bold; font-size: 14pt;">Pre-Need Funeral/Crematory Arrangements Agreement</span><br /><br/>
                                    '.$user_info['crematory'].'<br />'.$user_info['address1'].'<br />'.$user_info['address2'].'<br />
                                    '.$user_info_city['name'].', '.$user_info_state['name'].', '.$user_info_zip['name'].'
                                    <span style="font-size: 15pt;">☎</span>'.$user_info['phone'].' , '.$user_info['contactemail'].'
                                </td>
                                <td width="20%" style="text-align: right; vertical-align: top;">
                                    Case ID.<br />
                                    <span style="font-weight: bold; font-size: 12pt;">'.$_SESSION['selectedcaseID'].'</span><br/><br/>
                                    '.$reportdate.'<br/>'.$reporttime.'
                                </td>
                            </tr>
                        </table>   
                    </div>';

        $report_PI = '<div style="border: 1px solid red; margin-top: 0.2cm;">
                    <div style="text-align: left; font-family: sans-serif;">
                        ______Initial Personal Information:
                    </div><br/>
                    <table width="100%" style=" font-family: sans-serif;">
                        <thead >
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Honorific</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">First Name</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Middel Name</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Last Name</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Suffix</th> 
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult_honor['name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult['firstName'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult_middlename.'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult_last['name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult_suf['name'].'</span>
                            </td>

                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address1</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address2</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Birthday</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Township</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult['address1'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult_address2.'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult['dateOfBirth'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult_township['name'].'</span>
                            </td>
                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">City</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">State</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Zip</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">County</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Nickname</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult_city['name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult_state['name'].'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult_zip['name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult_county['name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult['nickName'].'</span>
                            </td>
                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Gender</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">SSN</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Email</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Phone</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult['gender'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult['SSN'].'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult['email'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$piResult['phone'].'</span>
                            </td>

                        </tr>
                        </tbody>
                    </table>
                    </div>';

        require __DIR__ . '/vendor/autoload.php';
        $mpdf = new \Mpdf\Mpdf();
        $mpdf->setFooter('{PAGENO}');

        $mpdf->WriteHTML($header);
        if ($piResult) {
            $mpdf->WriteHTML($report_PI);
        }else{
            $mpdf->WriteHTML('----------------There is no data to report.-----------------');
        }

        $report_nok_header = '<div style="border: 1px solid red; margin-top: 0.5cm;">
                                <div style="text-align: left; font-family: sans-serif;">
                                    ______Initial Next of Kin (each):
                                </div><br/>';
        $report_nok_body = '';
        $report_nok_footer = '</div>';
        if ($nokResultCount > 0) {
            $rowcount = 0;
            while ($nokResult_row = mysqli_fetch_assoc($nokResult)) {
                $rowcount ++;
                $sql = "SELECT name FROM dropdown_city WHERE id='".$nokResult_row['city']."';";
                    $nokResult_row_city = mysqli_fetch_array($conn->query($sql));
                $sql = "SELECT name FROM dropdown_state WHERE id='".$nokResult_row['states']."';";
                    $nokResult_row_state = mysqli_fetch_array($conn->query($sql));
                $sql = "SELECT name FROM dropdown_zip WHERE id='".$nokResult_row['zip']."';";
                    $nokResult_row_zip = mysqli_fetch_array($conn->query($sql));
                $sql = "SELECT name FROM dropdown_relationship WHERE id='".$nokResult_row['relationship']."';";
                    $nokResult_row_relationship = mysqli_fetch_array($conn->query($sql));
                    $report_nok_body .= '<br/><div style="text-align: left; font-family: sans-serif;">
                                            _______________Number '.$rowcount.':
                                        </div><br/>
                                        <table width="100%" style=" font-family: sans-serif;">
                                            <thead >
                                            <tr>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Fullname</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address1</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address2</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$nokResult_row['fullname'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$nokResult_row['address1'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$nokResult_row['address2'].'</span>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" style=" font-family: sans-serif;">
                                            <thead>
                                            <tr>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">City</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">State</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Zip</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Relationship</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$nokResult_row_city['name'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$nokResult_row_state['name'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$nokResult_row_zip['name'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$nokResult_row_relationship['name'].'</span>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" style=" font-family: sans-serif;">
                                            <thead>
                                            <tr>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Primary Phone</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Secondary Phone</th>
                                                <th class="text-center" style="font-weight: bold; font-size: 14pt;">Email</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$nokResult_row['phone'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$nokResult_row['phone2'].'</span>
                                                </td>
                                                <td width="12%" style="text-align: center; vertical-align: top;">
                                                    <span style="font-weight: bold; font-size: 10pt;">'.$nokResult_row['email'].'</span>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>';
                // $rowcount ++;
                // if ($rowcount >= 4) {
                //     $flag_nok_rowlessthan2 = false;
                //     $rowcount = 0;
                //     $report_nok_total = $report_nok_header.$report_nok_body.$report_nok_footer;
                //     $mpdf->WriteHTML($report_nok_total);
                //     $report_nok_body = '';
                //     $report_nok_body .= '';
                // }else {
                //     $flag_nok_rowlessthan2 = true;
                //     $report_nok_body .= '';
                // }
            }
            $report_nok_total = $report_nok_header.$report_nok_body.$report_nok_footer;
            $mpdf->WriteHTML($report_nok_total);
            // $mpdf->WriteHTML('<pagebreak resetpagenum="2" pagenumstyle="2" suppress="off" />');
        } 

        $report_marital_header = '<div style="border: 1px solid red; margin-top: 0.5cm;">
                                <div style="text-align: left; font-family: sans-serif;">
                                    ______Initial Marital Status (each):
                                </div><br/>';
        $report_marital_body = '';
        $report_marital_footer = '</div>';
        if ($maritalResultCount > 0) {
            $rowcount = 0;
            while ($maritalResult_row = mysqli_fetch_assoc($maritalResult)) {
                $rowcount ++;
                $Spousedeceased = $maritalResult_row['Spousedeceased'] === 'Y'?'Yes':'No';
                $dateofdeath = $maritalResult_row['Spousedeceased'] === 'Y'?$maritalResult_row['dateofdeath']:'--';
                $spousesplaceofdeath = $maritalResult_row['Spousedeceased'] === 'Y'?$maritalResult_row['spousesplaceofdeath']:'--';

                $report_marital_body .= '<br/><div style="text-align: left; font-family: sans-serif;">
                                        _______________Number '.$rowcount.':
                                    </div><br/>
                                    <table width="100%" style=" font-family: sans-serif;">
                                        <thead >
                                        <tr>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Marital Status</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Place of Marriage</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Date of Marriage</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$maritalResult_row['maritalstatus'].'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$maritalResult_row['placeofmarriage'].'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$maritalResult_row['dateofmarriage'].'</span>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <table width="100%" style=" font-family: sans-serif;">
                                        <thead>
                                        <tr>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Spouse Name</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Spouse Deceased</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Spouse Date of Death</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Spouse Place of Death</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$maritalResult_row['spousesname'].'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$Spousedeceased.'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$dateofdeath.'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$spousesplaceofdeath.'</span>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>';
            }
            $report_marital_total = $report_marital_header.$report_marital_body.$report_marital_footer;
            $mpdf->WriteHTML($report_marital_total);
        } 

        $report_child_header = '<div style="border: 1px solid red; margin-top: 0.5cm;">
                                <div style="text-align: left; font-family: sans-serif;">
                                    ______Initial Children (each):
                                </div><br/>';
        $report_child_body = '';
        $report_child_footer = '</div>';
        if ($childResultCount > 0) {
            $rowcount = 0;
            while ($childResult_row = mysqli_fetch_assoc($childResult)) {
                $rowcount ++;
                $sql = "SELECT name FROM dropdown_city WHERE id='".$childResult_row['city']."';";
                    $childResult_row_city = mysqli_fetch_array($conn->query($sql));
                $sql = "SELECT name FROM dropdown_state WHERE id='".$childResult_row['states']."';";
                    $childResult_row_state = mysqli_fetch_array($conn->query($sql));
                $sql = "SELECT name FROM dropdown_zip WHERE id='".$childResult_row['zip']."';";
                    $childResult_row_zip = mysqli_fetch_array($conn->query($sql));
                $sql = "SELECT name FROM dropdown_relationship WHERE id='".$childResult_row['relationship']."';";
                    $childResult_row_relationship = mysqli_fetch_array($conn->query($sql));
                $report_child_body .= '<br/><div style="text-align: left; font-family: sans-serif;">
                                        _______________Number '.$rowcount.':
                                    </div><br/>
                                    <table width="100%" style=" font-family: sans-serif;">
                                        <thead >
                                        <tr>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Fullname</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address1</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address2</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$childResult_row['fullname'].'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$childResult_row['address1'].'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$childResult_row['address2'].'</span>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <table width="100%" style=" font-family: sans-serif;">
                                        <thead>
                                        <tr>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">City</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">State</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Zip</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Relationship</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$childResult_row_city['name'].'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$childResult_row_state['name'].'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$childResult_row_zip['name'].'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$childResult_row_relationship['name'].'</span>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <table width="100%" style=" font-family: sans-serif;">
                                        <thead>
                                        <tr>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Date of Birth</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Primary Phone</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Secondary Phone</th>
                                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Email</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$childResult_row['dob'].'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$childResult_row['phone'].'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$childResult_row['phone2'].'</span>
                                            </td>
                                            <td width="12%" style="text-align: center; vertical-align: top;">
                                                <span style="font-weight: bold; font-size: 10pt;">'.$childResult_row['email'].'</span>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>';
            }
            $report_child_total = $report_child_header.$report_child_body.$report_child_footer;
            $mpdf->WriteHTML($report_child_total);
        } 

        if (mysqli_num_rows($mltResult) > 0) {
            $mltResult = mysqli_fetch_assoc($mltResult);

            $sql = "SELECT name FROM dropdown_militarybranch WHERE id='".$mltResult['BranchID']."';";
            $mltResult_branch = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_warcampaign WHERE id='".$mltResult['WarCampaignID']."';";
            $mltResult_war = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_rank WHERE id='".$mltResult['Rank']."';";
            $mltResult_rank = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_typeofdischarge WHERE id='".$mltResult['TypeOfDischargeID']."';";
            $mltResult_typeofdis = mysqli_fetch_array($conn->query($sql));

            $dd_214 = $mltResult['DD214'] === 'Y'?'Yes':'No';
            $headstone = $mltResult['Headstone'] === 'Y'?'Yes':'No';
            $burial = $mltResult['ApplicationForBurial'] === 'Y'?'Yes':'No';
            $flag = $mltResult['ApplicationForFlag'] === 'Y'?'Yes':'No';
            $honorguard = $mltResult['HonorGuard'] === 'Y'?'Yes':'No';

            $report_mlt = '<div style="border: 1px solid red; margin-top: 0.2cm;">
                    <div style="text-align: left; font-family: sans-serif;">
                        ______Initial Military Service:
                    </div><br/>
                    <table width="100%" style=" font-family: sans-serif;">
                        <thead >
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Branch</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">War/Campaign</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Rank</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Type of Discharge</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$mltResult_branch['name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$mltResult_war['name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$mltResult_rank['name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$mltResult_typeofdis['name'].'</span>
                            </td>
                           
                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Service/Serial number</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Enlistment Date</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Discharge Date</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">DD-214</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$mltResult['SerialNumber'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$mltResult['EnlistmentDate'].'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$mltResult['DischargeDate'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$dd_214.'</span>
                            </td>
                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Headstone/Marker</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">App for Burial Benefits</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">App for Flag</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Honor Guard</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$headstone.'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$burial.'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$flag.'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$honorguard.'</span>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    </div>';
            $mpdf->WriteHTML($report_mlt);  
        }

        $report_churchworship_header = '<div style="border: 1px solid red; margin-top: 0.2cm;">
                                        <div style="text-align: left; font-family: sans-serif;">
                                            ______Initial Church & Place of Worship:
                                        </div><br/>';
        $report_churchworship_footer = '</div>';
        $report_church = '';
        $report_pow = '';
        if (mysqli_num_rows($churchResult) > 0) {
            $churchResult = mysqli_fetch_assoc($churchResult);

            $sql = "SELECT name FROM dropdown_city WHERE id='".$churchResult['city']."';";
                $churchResult_city = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_state WHERE id='".$churchResult['states']."';";
                $churchResult_state = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_zip WHERE id='".$churchResult['zip']."';";
                $churchResult_zip = mysqli_fetch_array($conn->query($sql));
            $churchResult_address2 = $churchResult['Address2']!=''?$churchResult['Address2']:'--';

            $report_church = '<div style="text-align: left; font-family: sans-serif;">
                                    _______________Church:
                                </div><br/>
                            <table width="100%" style=" font-family: sans-serif;">
                                <thead >
                                <tr>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Church</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Clergy Name</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address1</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address2</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$churchResult['Church'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$churchResult['ClergyName'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$churchResult['Address1'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$churchResult_address2.'</span>
                                    </td>
                                </tr>
                                </tbody>
                            
                                <thead>
                                <tr>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">City</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">State</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Zip</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Email</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$churchResult_city['name'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$churchResult_state['name'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$churchResult_zip['name'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$churchResult['Email'].'</span>
                                    </td>
                                </tr>
                                </tbody>
                            
                                <thead>
                                <tr>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Primary Phone</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Secondary Phone</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$churchResult['phone'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$churchResult['phone2'].'</span>
                                    </td>
                                </tr>
                                </tbody>
                            </table><br/>';
        }

        if (mysqli_num_rows($powResult) > 0) {
            $powResult = mysqli_fetch_assoc($powResult);

            $sql = "SELECT name FROM dropdown_city WHERE id='".$powResult['city']."';";
                $powResult_city = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_state WHERE id='".$powResult['states']."';";
                $powResult_state = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_zip WHERE id='".$powResult['zip']."';";
                $powResult_zip = mysqli_fetch_array($conn->query($sql));
            $powResult_address2 = $powResult['Address2']!=''?$powResult['Address2']:'--';

            $report_pow = '<div style="text-align: left; font-family: sans-serif;">
                                    _______________Place of Worship:
                                </div><br/>
                            <table width="100%" style=" font-family: sans-serif;">
                                <thead >
                                <tr>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Place of Worship</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Clergy Name</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address1</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Address2</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$powResult['PlaceOfWorship'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$powResult['ClergyName'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$powResult['Address1'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$powResult_address2.'</span>
                                    </td>
                                </tr>
                                </tbody>
                            
                                <thead>
                                <tr>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">City</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">State</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Zip</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Email</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$powResult_city['name'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$powResult_state['name'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$powResult_zip['name'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$powResult['Email'].'</span>
                                    </td>
                                </tr>
                                </tbody>
                            
                                <thead>
                                <tr>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Primary Phone</th>
                                    <th class="text-center" style="font-weight: bold; font-size: 14pt;">Secondary Phone</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$powResult['phone'].'</span>
                                    </td>
                                    <td width="12%" style="text-align: center; vertical-align: top;">
                                        <span style="font-weight: bold; font-size: 10pt;">'.$powResult['phone2'].'</span>
                                    </td>
                                </tr>
                                </tbody>
                            </table>';
        }
        if ($report_church != '' || $report_pow != '') {
            $report_churchworship_total = $report_churchworship_header.$report_church.$report_pow.$report_churchworship_footer;
            $mpdf->WriteHTML($report_churchworship_total);  
        }else{
            $report_churchworship_empty = '<div style="text-align: left; margin-left:4cm; font-family: sans-serif;">
                                                ----------No data for the caseID----------
                                            </div><br/>';
            $report_churchworship_total = $report_churchworship_header.$report_churchworship_empty.$report_churchworship_footer;
            $mpdf->WriteHTML($report_churchworship_total);  
        }

        if (mysqli_num_rows($educationResult) > 0) {
            $educationResult = mysqli_fetch_assoc($educationResult);

            $sql = "SELECT name FROM dropdown_highschool WHERE id='".$educationResult['EduHighSchool']."';";
            $educationResult_eduHs = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_warcampaign WHERE id='".$educationResult['dropdown_undergraduatename']."';";
            $educationResult_under = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_graduatename WHERE id='".$educationResult['graduate']."';";
            $educationResult_grad = mysqli_fetch_array($conn->query($sql));

            $EduHSGraduated = $educationResult['EduHSGraduated'] === 'Y'?'Yes':'No';
            $undercheck = $educationResult['undergraducatedegreecheck'] === 'Y'?'Yes':'No';
            $gradcheck = $educationResult['graducatedegreecheck'] === 'Y'?'Yes':'No';

            $report_edu = '<div style="border: 1px solid red; margin-top: 0.2cm;">
                    <div style="text-align: left; font-family: sans-serif;">
                        ______Initial Education:
                    </div><br/>
                    <table width="100%" style=" font-family: sans-serif;">
                        <thead >
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">High School</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Graduated</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$educationResult_eduHs.'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$EduHSGraduated.'</span>
                            </td>
                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Undergraduate Name</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Undergraduate Degree</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Graduated</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$educationResult_under.'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$educationResult['undergraducatedegree'].'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$undercheck.'</span>
                            </td>
                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Graduate Name</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Graduate Degree</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Graduated</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$educationResult_grad.'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$educationResult['graducatedegree'].'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$gradcheck.'</span>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    </div>';
            $mpdf->WriteHTML($report_edu);  
        }
        
        if (mysqli_num_rows($parentsResult) > 0) {
            $parentsResult = mysqli_fetch_assoc($parentsResult);

            $report_parent = '<div style="border: 1px solid red; margin-top: 0.2cm;">
                    <div style="text-align: left; font-family: sans-serif;">
                        ______Initial Education:
                    </div><br/>
                    <table width="100%" style=" font-family: sans-serif;">
                        <thead >
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Father`s date of Birth</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Father`s date of Death</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$parentsResult['ParentDeceasedFathersDOB'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$parentsResult['ParentDeceasedFathersDOD'].'</span>
                            </td>
                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Mother`s date of Birth</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Mother`s date of Death</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                        <td width="12%" style="text-align: center; vertical-align: top;">
                            <span style="font-weight: bold; font-size: 10pt;">'.$parentsResult['ParentDeceasedMothersDOB'].'</span>
                        </td>
                        <td width="12%" style="text-align: center; vertical-align: top;">
                            <span style="font-weight: bold; font-size: 10pt;">'.$parentsResult['ParentDeceasedMothersDOD'].'</span>
                        </td>
                        </tr>
                        </tbody>
                    </table>
                    </div>';
            $mpdf->WriteHTML($report_parent);  
        }

        if (mysqli_num_rows($finaldispositionResult) > 0) {
            $finaldispositionResult = mysqli_fetch_assoc($finaldispositionResult);

            $sql = "SELECT name FROM dropdown_militarybranch WHERE id='".$finaldispositionResult['CemeteryID']."';";
            $finaldis_cemetery = mysqli_fetch_array($conn->query($sql));
            $sql = "SELECT name FROM dropdown_warcampaign WHERE id='".$finaldispositionResult['FuneralOrMemorialServiceAtID']."';";
            $finaldis_serviceat = mysqli_fetch_array($conn->query($sql));

            $Burial = $finaldispositionResult['Burial'] === 'Y'?'Yes':'No';
            $Entombment = $finaldispositionResult['Entombment'] === 'Y'?'Yes':'No';
            $Cremation = $finaldispositionResult['Cremation'] === 'Y'?'Yes':'No';
            $Burial_at_Sea = $finaldispositionResult['BurialAtSea'] === 'Y'?'Yes':'No';

            $report_finaldis = '<div style="border: 1px solid red; margin-top: 0.2cm;">
                    <div style="text-align: left; font-family: sans-serif;">
                        ______Initial Final Disposition:
                    </div><br/>
                    <table width="100%" style=" font-family: sans-serif;">
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Burial</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Entombment</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Cremation</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Burial at Sea</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$Burial.'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$Entombment.'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$Cremation.'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$Burial_at_Sea.'</span>
                            </td>
                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Date of Final Disposition</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Final Disposition</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Cemetery/Crematory name</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Location</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Lot #</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finaldispositionResult['DateOfFinalDisposition'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finaldispositionResult['FinalDisposition'].'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finaldis_cemetery['name'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finaldispositionResult['Location'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finaldispositionResult['LotNo'].'</span>
                            </td>
                        </tr>
                        </tbody>
                        <thead >
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Section</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Funeral/Memorial</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Name Lot Registered</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Grave to Be Opened</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Grave #</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finaldispositionResult['Section'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finaldis_serviceat['name'].'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finaldispositionResult['NameLotRegisteredTo'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finaldispositionResult['WhereInLotIsGraveToBeOpened'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finaldispositionResult['GraveNo'].'</span>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    </div>';
            $mpdf->WriteHTML($report_finaldis);  
        }

        if (mysqli_num_rows($finalcrematoryResult) > 0) {
            $finalcrematoryResult = mysqli_fetch_assoc($finalcrematoryResult);

            $WaitTimeMet = $finalcrematoryResult['WaitTimeMet'] === 'Y'?'Yes':'No';

            $report_funhome = '<div style="border: 1px solid red; margin-top: 0.2cm;">
                    <div style="text-align: left; font-family: sans-serif;">
                        ______Initial Funeral Home/Crematory:
                    </div><br/>
                    <table width="100%" style=" font-family: sans-serif;">
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Responsible Party/ Informant</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Date of Cremation</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Time of Cremation</th>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Wait Time Met</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finalcrematoryResult['PartyOfInformant'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finalcrematoryResult['DateOfCremation'].'</span>
                            </td>

                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finalcrematoryResult['TimeOfCremation'].'</span>
                            </td>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$WaitTimeMet.'</span>
                            </td>
                        </tr>
                        </tbody>
                        <thead>
                        <tr>
                            <th class="text-center" style="font-weight: bold; font-size: 14pt;">Date of Final Disposition</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td width="12%" style="text-align: center; vertical-align: top;">
                                <span style="font-weight: bold; font-size: 10pt;">'.$finalcrematoryResult['DirectorNote'].'</span>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    </div>';
            $mpdf->WriteHTML($report_funhome);  
        }
        $report_footer = '<div style="border: 1px solid green; margin-top: 0.2cm;">
                    <div style="text-align: left; font-family: sans-serif;">
                        Total for Pre-Needs insurance and terms of Agreement from Statement of Goods<br/>
                    </div><br/>
                    <div style="text-align: left; margin-left:2cm; font-family: sans-serif;">
                    Sign by CLIENT  _______________________ <br/><br/>Sign by HOME agent/representative   __________________________<br/>
                                      
                    </div><br/>
                    <div style="text-align: left; margin-left:6cm; font-family: sans-serif;">
                    Sign date: _____/_____/____________ <br/>
                                      
                    </div><br/></div>';
        $mpdf->WriteHTML($report_footer);  
        $mpdf->Output();
    } else {
        header('Location: login.php');
    }
?>
    