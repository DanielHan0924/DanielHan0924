<?php
    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];

    $funeralhome = $_POST['funeralhome'];
    $fullname = $_POST['fullname'];
    $address1 = $_POST['address1'];
    $address2 = $_POST['address2'];
    $city = $_POST['city'];
    $states = $_POST['states'];
    $zip = $_POST['zip'];
    $statelicense = $_POST['statelicense'];
    $stateissued = $_POST['stateissued'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $phone2 = $_POST['phone2'];
    $bodypickkup = $_POST['bodypickkup'];
    $embalm = $_POST['embalm'];
    
    $sql = "SELECT * FROM contractor WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE contractor SET funeralhome='".$funeralhome[$i]."', fullname='".$fullname[$i]."', address1='".$address1[$i]."', address2='".$address2[$i]."', 
                city='".$city[$i]."', states='".$states[$i]."', zip='".$zip[$i]."', statelicense='".$statelicense[$i]."', stateissued='".$stateissued[$i]."', email='".$email[$i]."', 
                phone='".$phone[$i]."', phone2='".$phone2[$i]."', bodypickkup='".$bodypickkup[$i]."', embalm='".$embalm[$i]."' WHERE username='".$username."' AND contractorid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($fullname); $i ++) {
            $sql = "INSERT INTO contractor (username, contractorid, funeralhome, fullname, address1, address2, city, states, zip, statelicense, stateissued, email, phone, phone2, bodypickkup, embalm)

            VALUES ('".$username."', '".$i."', '".$funeralhome[$i]."', '".$fullname[$i]."', '".$address1[$i]."', '".$address2[$i]."', '".$city[$i]."', '".$states[$i]."', 
                '".$zip[$i]."', '".$statelicense[$i]."', '".$stateissued[$i]."', '".$email[$i]."', '".$phone[$i]."', '".$phone2[$i]."', '".$bodypickkup[$i]."', '".$embalm[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($fullname); $i ++) {
            $sql = "INSERT INTO contractor (username, contractorid, funeralhome, fullname, address1, address2, city, states, zip, statelicense, stateissued, email, phone, phone2, bodypickkup, embalm)

            VALUES ('".$username."', '".$i."', '".$funeralhome[$i]."', '".$fullname[$i]."', '".$address1[$i]."', '".$address2[$i]."', '".$city[$i]."', '".$states[$i]."', 
                '".$zip[$i]."', '".$statelicense[$i]."', '".$stateissued[$i]."', '".$email[$i]."', '".$phone[$i]."', '".$phone2[$i]."', '".$bodypickkup[$i]."', '".$embalm[$i]."')";
            $conn->query($sql);
        }
    }

    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>