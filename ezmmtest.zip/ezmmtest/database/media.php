<?php

    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];

    ///////////////////Information Form///////////////////
    $Newspaper = $_POST['Newspaper'];
    $Email = $_POST['Email'];
    $fax = $_POST['fax'];
    $website = $_POST['website'];
    $NUserName = $_POST['NUserName'];
    $Npass = $_POST['Npass'];
    $Nrate = $_POST['Nrate'];
    $WDDeadline = $_POST['WDDeadline'];
    $WDeadline = $_POST['WDeadline'];
    $NContact = $_POST['NContact'];
    $obituraryContent = $_POST['obituraryContent'];
    
    $sql = "SELECT * FROM media WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE media SET Newspaper='".$Newspaper[$i]."', Email='".$Email[$i]."', fax='".$fax[$i]."', 
            website='".$website[$i]."', NUserName='".$NUserName[$i]."', Npass='".$Npass[$i]."', Nrate='".$Nrate[$i]."', WDDeadline='".$WDDeadline[$i]."', WDeadline='".$WDeadline[$i]."', 
            NContact='".$NContact[$i]."', obituraryContent='".$obituraryContent[$i]."' WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($Newspaper); $i ++) {
            $sql = "INSERT INTO media (username, childid, Newspaper, Email, fax, website, NUserName, Npass, Nrate, WDDeadline, WDeadline, NContact,
                    obituraryContent)

            VALUES ('".$username."', '".$i."', '".$Newspaper[$i]."', '".$Email[$i]."', '".$fax[$i]."', '".$website[$i]."', '".$NUserName[$i]."', 
                '".$Npass[$i]."', '".$Nrate[$i]."', '".$WDDeadline[$i]."', '".$WDeadline[$i]."', '".$NContact[$i]."', '".$obituraryContent[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($Newspaper); $i ++) {
            $sql = "INSERT INTO media (username, childid, Newspaper, Email, fax, website, NUserName, Npass, Nrate, WDDeadline, WDeadline, NContact,
                    obituraryContent)

            VALUES ('".$username."', '".$i."', '".$Newspaper[$i]."', '".$Email[$i]."', '".$fax[$i]."', '".$website[$i]."', '".$NUserName[$i]."', 
                '".$Npass[$i]."', '".$Nrate[$i]."', '".$WDDeadline[$i]."', '".$WDeadline[$i]."', '".$NContact[$i]."', '".$obituraryContent[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>