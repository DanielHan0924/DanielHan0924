CREATE TABLE `users` (
    `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    `username` Text(250) NOT NULL,
    `email` Text(250) NOT NULL,
    `passwords` Text(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- /////////Pre Need Page///////////////////
CREATE TABLE `pre_need_pi` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `honorific` varchar(50) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `middleName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `suffix` varchar(25) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `township` varchar(25) NOT NULL,
  `city` varchar(25) NOT NULL,
  `states` varchar(25) NOT NULL,
  `zipCode` varchar(8) NOT NULL,
  `country` varchar(20) NOT NULL,
  `nickName` varchar(20) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `SSN` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `dateOfDeath` date NOT NULL,
  `timeOfDeath` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `pre_need_nok` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `states` varchar(30) NOT NULL,
  `zip` varchar(25) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `pre_need_marital` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `maritalstatus` varchar(50) NOT NULL,
  `placeofmarriage` varchar(50) NOT NULL,
  `dateofmarriage` varchar(50) NOT NULL,
  `spousesname` varchar(50) NOT NULL,
  `Spousedeceased` varchar(50) NOT NULL,
  `sdateofdeath` varchar(50) NOT NULL,
  `spousesplaceofdeath` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `pre_need_children` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childrenid` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `states` varchar(50) NOT NULL,
  `zip` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `pre_need_grand_children` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childrenid` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `states` varchar(50) NOT NULL,
  `zip` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `pre_need_military_service` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `BranchID` varchar(50) NOT NULL,
  `WarCampaignID` varchar(50) NOT NULL,
  `SerialNumber` varchar(50) NOT NULL,
  `Rank` varchar(50) NOT NULL,
  `EnlistmentDate` varchar(50) NOT NULL,
  `DischargeDate` varchar(50) NOT NULL,
  `TypeOfDischargeID` varchar(50) NOT NULL,
  `DD214` varchar(50) NOT NULL,
  `Headstone` varchar(50) NOT NULL,
  `ApplicationForBurial` varchar(50) NOT NULL,
  `ApplicationForFlag` varchar(50) NOT NULL,
  `HonorGuard` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `pre_need_church` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `Church` varchar(50) NOT NULL,
  `ClergyName` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `States` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `pre_need_place_of_worship` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `PlaceOfWorship` varchar(50) NOT NULL,
  `ClergyName` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `States` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `pre_need_education` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `EduHighSchool` varchar(50) NOT NULL,
  `EduHSGraduated` varchar(50) NOT NULL,
  `undergraducate` varchar(50) NOT NULL,
  `undergraducatedegree` varchar(50) NOT NULL,
  `undergraducatedegreecheck` varchar(50) NOT NULL,
  `graduate` varchar(50) NOT NULL,
  `graducatedegree` varchar(50) NOT NULL,
  `graducatedegreecheck` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `pre_need_parents` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `ParentDeceasedFathersDOB` varchar(50) NOT NULL,
  `ParentsDeceasedFathersDOD` varchar(50) NOT NULL,
  `ParentsDeceasedMothersDOB` varchar(50) NOT NULL,
  `ParentsDeceasedMothersDOD` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `pre_need_final_disposition` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `Burial` varchar(50) NOT NULL,
  `Entombment` varchar(50) NOT NULL,
  `Cremation` varchar(50) NOT NULL,
  `BurialAtSea` varchar(50) NOT NULL,
  `DateOfFinalDisposition` varchar(50) NOT NULL,
  `FinalDisposition` varchar(50) NOT NULL,
  `CemeteryID` varchar(50) NOT NULL,
  `Location` varchar(50) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `FuneralOrMemorialServiceAtID` varchar(50) NOT NULL,
  `NameLotRegisteredTo` varchar(50) NOT NULL,
  `WhereInLotIsGraveToBeOpened` varchar(50) NOT NULL,
  `LotNo` varchar(50) NOT NULL,
  `GraveNo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `pre_need_final_crematory` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `PartyOfInformant` varchar(50) NOT NULL,
  `DateOfCremation` varchar(50) NOT NULL,
  `TimeOfCremation` varchar(50) NOT NULL,
  `WaitTimeMet` varchar(50) NOT NULL,
  `DirectorNote` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


-- /////////At Need Page///////////////////

CREATE TABLE `at_need_pi` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `honorific` varchar(50) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `middleName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `suffix` varchar(25) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `township` varchar(25) NOT NULL,
  `city` varchar(25) NOT NULL,
  `states` varchar(25) NOT NULL,
  `zipCode` varchar(8) NOT NULL,
  `country` varchar(20) NOT NULL,
  `nickName` varchar(20) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `SSN` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `dateOfDeath` date NOT NULL,
  `timeOfDeath` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `at_need_nok` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `states` varchar(30) NOT NULL,
  `zip` varchar(25) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- /////////Contractor Page///////////////////
CREATE TABLE `contractor` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `contractorid` varchar(50) NOT NULL,
  `funeralhome` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `states` varchar(30) NOT NULL,
  `zip` varchar(25) NOT NULL,
  `statelicense` varchar(50) NOT NULL,
  `stateissued` varchar(50) NOT NULL,
  `email` varchar(25) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `phone2` varchar(25) NOT NULL,
  `bodypickkup` varchar(25) NOT NULL,
  `embalm` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- /////////First Call Page///////////////////
CREATE TABLE `first_call_pi` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `honorific` varchar(50) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `middleName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `suffix` varchar(25) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `township` varchar(25) NOT NULL,
  `city` varchar(25) NOT NULL,
  `states` varchar(25) NOT NULL,
  `zipCode` varchar(8) NOT NULL,
  `country` varchar(20) NOT NULL,
  `nickName` varchar(20) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `SSN` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `dateOfDeath` date NOT NULL,
  `timeOfDeath` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `first_call_person_call` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `WhoCalled` varchar(50) NOT NULL,
  `Address1` varchar(30) NOT NULL,
  `Address2` varchar(30) NOT NULL,
  `City` varchar(30) NOT NULL,
  `States` varchar(25) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `dayphone` varchar(25) NOT NULL,
  `eveningphone` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `first_call_place_of_death` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `Physician` varchar(50) NOT NULL,
  `ContactName` varchar(50) NOT NULL,
  `Address1` varchar(30) NOT NULL,
  `Address2` varchar(30) NOT NULL,
  `City` varchar(30) NOT NULL,
  `States` varchar(25) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `officephone` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `first_call_location` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `LocationOfTheBody` varchar(50) NOT NULL,
  `ContactName` varchar(50) NOT NULL,
  `Address1` varchar(30) NOT NULL,
  `Address2` varchar(30) NOT NULL,
  `City` varchar(30) NOT NULL,
  `States` varchar(25) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `dod` varchar(25) NOT NULL,
  `tode` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `first_call_physician` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `Physician` varchar(50) NOT NULL,
  `ContactName` varchar(50) NOT NULL,
  `Address1` varchar(30) NOT NULL,
  `Address2` varchar(30) NOT NULL,
  `City` varchar(30) NOT NULL,
  `States` varchar(25) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `officephone` varchar(25) NOT NULL,
  `cellphone` varchar(25) NOT NULL,
  `pager` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `first_call_permission` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `pickup` varchar(50) NOT NULL,
  `embalm` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- /////////Case Bio Page///////////////////
CREATE TABLE `case_bio_deceased_info` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(30) NOT NULL,
  `FullName` varchar(30) NOT NULL,
  `DOB` varchar(30) NOT NULL,
  `Citizenship` varchar(30) NOT NULL,
  `Race` varchar(30) NOT NULL,
  `Religion` varchar(30) NOT NULL,
  `PlaceOfBirth` varchar(30) NOT NULL,
  `Ancestry` varchar(30) NOT NULL,
  `Business` varchar(30) NOT NULL,
  `States` varchar(30) NOT NULL,
  `InCommunitySInce` varchar(30) NOT NULL,
  `MovedFrom` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `case_bio_parents` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(30) NOT NULL,
  `FathersName` varchar(30) NOT NULL,
  `FDOB` varchar(30) NOT NULL,
  `FPlaceOfBirth` varchar(30) NOT NULL,
  `MothersName` varchar(30) NOT NULL,
  `MothersMaidenName` varchar(30) NOT NULL,
  `MDOB` varchar(30) NOT NULL,
  `MPlaceOfBirth` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `case_bio_children` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childrenid` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `states` varchar(50) NOT NULL,
  `zip` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `case_bio_grand_children` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childrenid` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `states` varchar(50) NOT NULL,
  `zip` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `case_bio_great_grand_children` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childrenid` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `states` varchar(50) NOT NULL,
  `zip` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `case_bio_great_great_grand_children` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childrenid` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `states` varchar(50) NOT NULL,
  `zip` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `case_bio_marital` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `maritalstatus` varchar(50) NOT NULL,
  `placeofmarriage` varchar(50) NOT NULL,
  `dateofmarriage` varchar(50) NOT NULL,
  `spousesname` varchar(50) NOT NULL,
  `Spousedeceased` varchar(50) NOT NULL,
  `sdateofdeath` varchar(50) NOT NULL,
  `spousesplaceofdeath` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `case_bio_military_service` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `BranchID` varchar(50) NOT NULL,
  `WarCampaignID` varchar(50) NOT NULL,
  `SerialNumber` varchar(50) NOT NULL,
  `Rank` varchar(50) NOT NULL,
  `EnlistmentDate` varchar(50) NOT NULL,
  `DischargeDate` varchar(50) NOT NULL,
  `TypeOfDischargeID` varchar(50) NOT NULL,
  `DD214` varchar(50) NOT NULL,
  `Headstone` varchar(50) NOT NULL,
  `ApplicationForBurial` varchar(50) NOT NULL,
  `ApplicationForFlag` varchar(50) NOT NULL,
  `HonorGuard` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `case_bio_church` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `Church` varchar(50) NOT NULL,
  `ClergyName` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `States` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `case_bio_place_of_worship` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `PlaceOfWorship` varchar(50) NOT NULL,
  `ClergyName` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `States` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `case_bio_education` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `EduHighSchool` varchar(50) NOT NULL,
  `EduHSGraduated` varchar(50) NOT NULL,
  `undergraducate` varchar(50) NOT NULL,
  `undergraducatedegree` varchar(50) NOT NULL,
  `undergraducatedegreecheck` varchar(50) NOT NULL,
  `graduate` varchar(50) NOT NULL,
  `graducatedegree` varchar(50) NOT NULL,
  `graducatedegreecheck` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- /////////Vital Statistics Page///////////////////
CREATE TABLE `vital_statistics_district` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(30) NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `MiddleName` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `Suffix` varchar(30) NOT NULL,
  `NickName` varchar(30) NOT NULL,
  `GenderID` varchar(30) NOT NULL,
  `SSN` varchar(30) NOT NULL,
  `TimeOfDeath` varchar(30) NOT NULL,
  `RangeTimeOfDead` varchar(30) NOT NULL,
  `TimeFound` varchar(30) NOT NULL,
  `DateOfDeath` varchar(30) NOT NULL,
  `Indicator` varchar(30) NOT NULL,
  `dateOfBirth` varchar(30) NOT NULL,
  `age` varchar(30) NOT NULL,
  `PlaceOfDeathID` varchar(30) NOT NULL,
  `Place` varchar(30) NOT NULL,
  `facility_name` varchar(30) NOT NULL,
  `CityID` varchar(30) NOT NULL,
  `City` varchar(30) NOT NULL,
  `StateID` varchar(30) NOT NULL,
  `State` varchar(30) NOT NULL,
  `ZipCodeID` varchar(30) NOT NULL,
  `CountryID` varchar(30) NOT NULL,
  `CountryFIPS` varchar(30) NOT NULL,
  `armed_service` varchar(30) NOT NULL,
  `dispositioni_method_of_disposition` varchar(30) NOT NULL,
  `disposition_crematory_name` varchar(30) NOT NULL,
  `disposition_crematory_name2` varchar(30) NOT NULL,
  `disposition_city1` varchar(30) NOT NULL,
  `disposition_country1` varchar(30) NOT NULL,
  `disposition_state1` varchar(30) NOT NULL,
  `disposition_place_of_disposition` varchar(30) NOT NULL,
  `disposition_place_of_disposition2` varchar(30) NOT NULL,
  `disposition_city2` varchar(30) NOT NULL,
  `disposition_country2` varchar(30) NOT NULL,
  `disposition_state2` varchar(30) NOT NULL,
  `funeral_home1` varchar(30) NOT NULL,
  `funeral_home2` varchar(30) NOT NULL,
  `funeral_city` varchar(30) NOT NULL,
  `funeral_country` varchar(30) NOT NULL,
  `funeral_state` varchar(30) NOT NULL,
  `funeral_director1` varchar(30) NOT NULL,
  `funeral_director2` varchar(30) NOT NULL,
  `funeral_director_license` varchar(30) NOT NULL,
  `funeral_home_number` varchar(30) NOT NULL,
  `assignment_certifier_type` varchar(30) NOT NULL,
  `assignment_coroner_location` varchar(30) NOT NULL,
  `assignment_physician1` varchar(30) NOT NULL,
  `assignment_physician2` varchar(30) NOT NULL,
  `assignment_dropped_to_papaer` varchar(30) NOT NULL,
  `assignment_email_notify` varchar(30) NOT NULL,
  `assignment_date_sent` varchar(30) NOT NULL,
  `assignment_certifier_location` varchar(30) NOT NULL,
  `assignment_certifier_country` varchar(30) NOT NULL,
  `residence_street_number` varchar(30) NOT NULL,
  `residence_apt` varchar(30) NOT NULL,
  `residence_city_limits` varchar(30) NOT NULL,
  `residence_zipcode` varchar(30) NOT NULL,
  `residence_city_township` varchar(30) NOT NULL,
  `residence_country1` varchar(30) NOT NULL,
  `residence_country2` varchar(30) NOT NULL,
  `residence_state` varchar(30) NOT NULL,
  `demographics_country_birth1` varchar(30) NOT NULL,
  `demographics_country_birth2` varchar(30) NOT NULL,
  `demographics_state_birth` varchar(30) NOT NULL,
  `demographics_marital_status` varchar(30) NOT NULL,
  `surviving_firstname` varchar(30) NOT NULL,
  `surviving_middlename` varchar(30) NOT NULL,
  `surviving_lastname` varchar(30) NOT NULL,
  `surviving_suffix` varchar(30) NOT NULL,
  `parents_firstname` varchar(30) NOT NULL,
  `parents_middlename` varchar(30) NOT NULL,
  `parents_lastname` varchar(30) NOT NULL,
  `parents_suffix` varchar(30) NOT NULL,
  `mother_firstname` varchar(30) NOT NULL,
  `mother_middlename` varchar(30) NOT NULL,
  `mother_lastname` varchar(30) NOT NULL,
  `informant_firstname` varchar(30) NOT NULL,
  `informant_middlename` varchar(30) NOT NULL,
  `informant_lastname` varchar(30) NOT NULL,
  `informant_suffix` varchar(30) NOT NULL,
  `informant_relationship1` varchar(30) NOT NULL,
  `informant_relationship2` varchar(30) NOT NULL,
  `informant_mailing_address` varchar(30) NOT NULL,
  `informant_city` varchar(30) NOT NULL,
  `informant_state` varchar(30) NOT NULL,
  `informant_zipcode` varchar(30) NOT NULL,
  `demographics_education` varchar(30) NOT NULL,
  `demographics_hispanic` varchar(30) NOT NULL,
  `demographics_mexian` varchar(30) NOT NULL,
  `demographics_puerto` varchar(30) NOT NULL,
  `demographics_cuban` varchar(30) NOT NULL,
  `demographics_specify` varchar(30) NOT NULL,
  `demographics_other` varchar(30) NOT NULL,
  `race_white` varchar(30) NOT NULL,
  `race_black` varchar(30) NOT NULL,
  `race_asian` varchar(30) NOT NULL,
  `race_chinese` varchar(30) NOT NULL,
  `race_filipino` varchar(30) NOT NULL,
  `race_vietnamese` varchar(30) NOT NULL,
  `race_japanese` varchar(30) NOT NULL,
  `race_korean` varchar(30) NOT NULL,
  `race_hawaiian` varchar(30) NOT NULL,
  `race_samoan` varchar(30) NOT NULL,
  `race_guamanian` varchar(30) NOT NULL,
  `race_american` varchar(30) NOT NULL,
  `race_native_desc` varchar(30) NOT NULL,
  `race_native_chk` varchar(30) NOT NULL,
  `race_other_asian_desc` varchar(30) NOT NULL,
  `race_other_asian_chk` varchar(30) NOT NULL,
  `race_other_pacific_desc` varchar(30) NOT NULL,
  `race_other_pacific_chk` varchar(30) NOT NULL,
  `race_native_desc2` varchar(30) NOT NULL,
  `race_other_asian_chk2` varchar(30) NOT NULL,
  `race_other_asian_desc2` varchar(30) NOT NULL,
  `race_other_pacific_chk2` varchar(30) NOT NULL,
  `race_other_pacific_desc2` varchar(30) NOT NULL,
  `demographics_occupation` varchar(30) NOT NULL,
  `demographics_industry` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- /////////Vital Statistics Page///////////////////
CREATE TABLE `surviving_relatives` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `survivingid` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `State` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Relationship` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- /////////Final Arrangement Page///////////////////
CREATE TABLE `final_arrange_visitation` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `visitationid` varchar(50) NOT NULL,
  `StartDate` varchar(50) NOT NULL,
  `StartTime` varchar(50) NOT NULL,
  `EndDate` varchar(50) NOT NULL,
  `EndTime` varchar(50) NOT NULL,
  `Visitation` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `State` varchar(50) NOT NULL,
  `Telephone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `final_arrange_service` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `serviceid` varchar(50) NOT NULL,
  `StartDate` varchar(50) NOT NULL,
  `StartTime` varchar(50) NOT NULL,
  `EndDate` varchar(50) NOT NULL,
  `EndTime` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `State` varchar(50) NOT NULL,
  `Telephone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `final_arrange_marital` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `maritalstatus` varchar(50) NOT NULL,
  `placeofmarriage` varchar(50) NOT NULL,
  `dateofmarriage` varchar(50) NOT NULL,
  `spousesname` varchar(50) NOT NULL,
  `Spousedeceased` varchar(50) NOT NULL,
  `sdateofdeath` varchar(50) NOT NULL,
  `spousesplaceofdeath` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `final_arrange_children` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childrenid` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `states` varchar(50) NOT NULL,
  `zip` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `final_arrange_grand_children` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childrenid` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `states` varchar(50) NOT NULL,
  `zip` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `final_arrange_military_service` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `BranchID` varchar(50) NOT NULL,
  `WarCampaignID` varchar(50) NOT NULL,
  `SerialNumber` varchar(50) NOT NULL,
  `Rank` varchar(50) NOT NULL,
  `EnlistmentDate` varchar(50) NOT NULL,
  `DischargeDate` varchar(50) NOT NULL,
  `TypeOfDischargeID` varchar(50) NOT NULL,
  `DD214` varchar(50) NOT NULL,
  `Headstone` varchar(50) NOT NULL,
  `ApplicationForBurial` varchar(50) NOT NULL,
  `ApplicationForFlag` varchar(50) NOT NULL,
  `HonorGuard` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `final_arrange_church` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `Church` varchar(50) NOT NULL,
  `ClergyName` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `States` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `final_arrange_place_of_worship` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `PlaceOfWorship` varchar(50) NOT NULL,
  `ClergyName` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `States` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `final_arrange_education` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `EduHighSchool` varchar(50) NOT NULL,
  `EduHSGraduated` varchar(50) NOT NULL,
  `undergraducate` varchar(50) NOT NULL,
  `undergraducatedegree` varchar(50) NOT NULL,
  `undergraducatedegreecheck` varchar(50) NOT NULL,
  `graduate` varchar(50) NOT NULL,
  `graducatedegree` varchar(50) NOT NULL,
  `graducatedegreecheck` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `final_arrange_parents` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `ParentDeceasedFathersDOB` varchar(50) NOT NULL,
  `ParentsDeceasedFathersDOD` varchar(50) NOT NULL,
  `ParentsDeceasedMothersDOB` varchar(50) NOT NULL,
  `ParentsDeceasedMothersDOD` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `final_arrange_final_disposition` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `Burial` varchar(50) NOT NULL,
  `Entombment` varchar(50) NOT NULL,
  `Cremation` varchar(50) NOT NULL,
  `BurialAtSea` varchar(50) NOT NULL,
  `DateOfFinalDisposition` varchar(50) NOT NULL,
  `FinalDisposition` varchar(50) NOT NULL,
  `CemeteryID` varchar(50) NOT NULL,
  `Location` varchar(50) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `FuneralOrMemorialServiceAtID` varchar(50) NOT NULL,
  `NameLotRegisteredTo` varchar(50) NOT NULL,
  `WhereInLotIsGraveToBeOpened` varchar(50) NOT NULL,
  `LotNo` varchar(50) NOT NULL,
  `GraveNo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `final_arrange_final_crematory` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `PartyOfInformant` varchar(50) NOT NULL,
  `DateOfCremation` varchar(50) NOT NULL,
  `TimeOfCremation` varchar(50) NOT NULL,
  `WaitTimeMet` varchar(50) NOT NULL,
  `DirectorNote` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- /////////Statement Page///////////////////
CREATE TABLE `statement_information` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `informationid` varchar(50) NOT NULL,
  `InformantName` varchar(50) NOT NULL,
  `AcceptedBy` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `States` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `SSN` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `InvoiceDate` varchar(50) NOT NULL,
  `DueDate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `statement_professional` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `Permanent` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `statement_facilities` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `Permanent` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `statement_automotive` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `Permanent` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `statement_charges` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `Permanent` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `statement_charges_select` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `Permanent` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `statement_totoal_special_charges` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `Permanent` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `statement_cash_advance` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `Permanent` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `statement_summary_charge` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `Permanent` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `statement_total_amount_due` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `Permanent` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `statement_reasons_for` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `Permanent` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `statement_terms_of_agreement` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `Price1` varchar(50) NOT NULL,
  `Price2` varchar(50) NOT NULL,
  `Price3` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `membership` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `MembershipName` varchar(50) NOT NULL,
  `ContactName` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `States` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `URL` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `organization` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `OrganizationName` varchar(50) NOT NULL,
  `ContactName` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `States` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `URL` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `visitor` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `States` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `staff` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `PersonalEmail` varchar(50) NOT NULL,
  `CompanyEmail` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `States` varchar(50) NOT NULL,
  `Zip` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `HireDate` varchar(50) NOT NULL,
  `TerminationDate` varchar(50) NOT NULL,
  `License` varchar(50) NOT NULL,
  `LicValidDate` varchar(50) NOT NULL,
  `StateLicensed` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `media` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `childid` varchar(50) NOT NULL,
  `Newspaper` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `fax` varchar(50) NOT NULL,
  `website` varchar(50) NOT NULL,
  `NUserName` varchar(50) NOT NULL,
  `Npass` varchar(50) NOT NULL,
  `Nrate` varchar(50) NOT NULL,
  `WDDeadline` varchar(50) NOT NULL,
  `WDeadline` varchar(50) NOT NULL,
  `NContact` varchar(50) NOT NULL,
  `obituraryContent` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;