<?php

    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];
    ///////////////////Personal Information Form///////////////////
    $PI_honorificID = (isset($_POST['PI_honorificID']) ) ? trim($_POST['PI_honorificID']) : '';
    $PI_firstname = (isset($_POST['PI_firstname']) ) ? trim($_POST['PI_firstname']) : '';
    $PI_middlename = (isset($_POST['PI_middlename']) ) ? trim($_POST['PI_middlename']) : '';
    $PI_lastname = (isset($_POST['PI_lastname']) ) ? trim($_POST['PI_lastname']) : '';
    $PI_suffix = (isset($_POST['PI_suffix']) ) ? trim($_POST['PI_suffix']) : '';
    $PI_address1 = (isset($_POST['PI_address1']) ) ? trim($_POST['PI_address1']) : '';
    $PI_address2 = (isset($_POST['PI_address2']) ) ? trim($_POST['PI_address2']) : '';
    $PI_township = (isset($_POST['PI_township']) ) ? trim($_POST['PI_township']) : '';
    $PI_city = (isset($_POST['PI_city']) ) ? trim($_POST['PI_city']) : '';
    $PI_states = (isset($_POST['PI_states']) ) ? trim($_POST['PI_states']) : '';
    $PI_zip = (isset($_POST['PI_zip']) ) ? trim($_POST['PI_zip']) : '';
    $PI_county = (isset($_POST['PI_county']) ) ? trim($_POST['PI_county']) : '';
    $PI_nickname = (isset($_POST['PI_nickname']) ) ? trim($_POST['PI_nickname']) : '';
    $PI_gender = (isset($_POST['PI_gender']) ) ? trim($_POST['PI_gender']) : '';
    $PI_ssn = (isset($_POST['PI_ssn']) ) ? trim($_POST['PI_ssn']) : '';
    $PI_email = (isset($_POST['PI_email']) ) ? trim($_POST['PI_email']) : '';
    $PI_phone = (isset($_POST['PI_phone']) ) ? trim($_POST['PI_phone']) : '';
    $PI_dod = (isset($_POST['PI_dod']) ) ? trim($_POST['PI_dod']) : '';
    $PI_tode = (isset($_POST['PI_tode']) ) ? trim($_POST['PI_tode']) : '';
    
    $sql = "SELECT * FROM pre_need_pi WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE pre_need_pi SET honorific='".$PI_honorificID."', firstName='".$PI_firstname."', middleName='".$PI_middlename."', lastName='".$PI_lastname."', 
            suffix='".$PI_suffix."', address1='".$PI_address1."', address2='".$PI_address2."', township='".$PI_township."', city='".$PI_city."', states='".$PI_states."', 
            zipCode='".$PI_zip."', country='".$PI_county."', nickName='".$PI_nickname."', gender='".$PI_gender."', SSN='".$PI_ssn."', email='".$PI_email."', 
            phone='".$PI_phone."', dateOfDeath='".$PI_dod."', timeOfDeath='".$PI_tode."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO pre_need_pi (username, honorific, firstName, middleName, lastName, suffix, address1, address2, township, city, 
                                    states, zipCode, country, nickName, gender, SSN, email, phone, dateOfDeath, timeOfDeath)

        VALUES ('".$username."', '".$PI_honorificID."', '".$PI_firstname."', '".$PI_middlename."', '".$PI_lastname."', '".$PI_suffix."', '".$PI_address1."', '".$PI_address2."', 
                '".$PI_township."', '".$PI_city."', '".$PI_states."', '".$PI_zip."', '".$PI_county."', '".$PI_nickname."', '".$PI_gender."', '".$PI_ssn."', '".$PI_email."', 
                '".$PI_phone."', '".$PI_dod."', '".$PI_tode."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Next Of Kin Form///////////////////
    $NOK_fullname = (isset($_POST['NOK_fullname']) ) ? trim($_POST['NOK_fullname']) : '';
    $NOK_address1 = (isset($_POST['NOK_address1']) ) ? trim($_POST['NOK_address1']) : '';
    $NOK_address2 = (isset($_POST['NOK_address2']) ) ? trim($_POST['NOK_address2']) : '';
    $NOK_city = (isset($_POST['NOK_city']) ) ? trim($_POST['NOK_city']) : '';
    $NOK_states = (isset($_POST['NOK_states']) ) ? trim($_POST['NOK_states']) : '';
    $NOK_zip = (isset($_POST['NOK_zip']) ) ? trim($_POST['NOK_zip']) : '';
    $NOK_relationship = (isset($_POST['NOK_relationship']) ) ? trim($_POST['NOK_relationship']) : '';
    $NOK_phone = (isset($_POST['NOK_phone']) ) ? trim($_POST['NOK_phone']) : '';
    $NOK_phone2 = (isset($_POST['NOK_phone2']) ) ? trim($_POST['NOK_phone2']) : '';
    $NOK_email = (isset($_POST['NOK_email']) ) ? trim($_POST['NOK_email']) : '';
    
    $sql = "SELECT * FROM pre_need_nok WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE pre_need_nok SET fullname='".$NOK_fullname."', address1='".$NOK_address1."', address2='".$NOK_address2."', city='".$NOK_city."', 
            states='".$NOK_states."', zip='".$NOK_zip."', relationship='".$NOK_relationship."', phone='".$NOK_phone."', phone2='".$NOK_phone2."', email='".$NOK_email."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO pre_need_nok (username, fullname, address1, address2, city, states, zip, relationship, phone, phone2, email)

        VALUES ('".$username."', '".$NOK_fullname."', '".$NOK_address1."', '".$NOK_address2."', '".$NOK_city."', '".$NOK_states."', '".$NOK_zip."', '".$NOK_relationship."', 
                '".$NOK_phone."', '".$NOK_phone2."', '".$NOK_email."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Marital Status Form///////////////////
    $MS_MaritalStatus = (isset($_POST['MS_MaritalStatus']) ) ? trim($_POST['MS_MaritalStatus']) : '';
    $MS_PlaceOfMarriage = (isset($_POST['MS_PlaceOfMarriage']) ) ? trim($_POST['MS_PlaceOfMarriage']) : '';
    $MS_DateOfMarriage = (isset($_POST['MS_DateOfMarriage']) ) ? trim($_POST['MS_DateOfMarriage']) : '';
    $MS_SpousesName = (isset($_POST['MS_SpousesName']) ) ? trim($_POST['MS_SpousesName']) : '';
    $MS_SpouseDeceased = (isset($_POST['MS_SpouseDeceased']) ) ? trim($_POST['MS_SpouseDeceased']) : '';
    $MS_SDateOfDeath = (isset($_POST['MS_SDateOfDeath']) ) ? trim($_POST['MS_SDateOfDeath']) : '';
    $MS_SpousesPlaceOfDeath = (isset($_POST['MS_SpousesPlaceOfDeath']) ) ? trim($_POST['MS_SpousesPlaceOfDeath']) : '';
    
    $sql = "SELECT * FROM pre_need_marital WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE pre_need_marital SET maritalstatus='".$MS_MaritalStatus."', placeofmarriage='".$MS_PlaceOfMarriage."', dateofmarriage='".$MS_DateOfMarriage."', 
            spousesname='".$MS_SpousesName."', Spousedeceased='".$MS_SpouseDeceased."', sdateofdeath='".$MS_SDateOfDeath."', spousesplaceofdeath='".$MS_SpousesPlaceOfDeath."' 
            WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO pre_need_marital (username, maritalstatus, placeofmarriage, dateofmarriage, spousesname, Spousedeceased, sdateofdeath, spousesplaceofdeath)

        VALUES ('".$username."', '".$MS_MaritalStatus."', '".$MS_PlaceOfMarriage."', '".$MS_DateOfMarriage."', '".$MS_SpousesName."', '".$MS_SpouseDeceased."', 
                '".$MS_SDateOfDeath."', '".$MS_SpousesPlaceOfDeath."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Children Form///////////////////
    $CLD_FullName = $_POST['CLD_FullName'];
    $CLD_Address1 = $_POST['CLD_Address1'];
    $CLD_Address2 = $_POST['CLD_Address2'];
    $CLD_City = $_POST['CLD_City'];
    $CLD_States = $_POST['CLD_States'];
    $CLD_Zip = $_POST['CLD_Zip'];
    $CLD_DOB = $_POST['CLD_DOB'];
    $CLD_Relationship = $_POST['CLD_Relationship'];
    $CLD_Email = $_POST['CLD_Email'];
    $CLD_phone = $_POST['CLD_phone'];
    $CLD_phone2 = $_POST['CLD_phone2'];
    
    $sql = "SELECT * FROM pre_need_children WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE pre_need_children SET fullname='".$CLD_FullName[$i]."', address1='".$CLD_Address1[$i]."', address2='".$CLD_Address2[$i]."', 
                city='".$CLD_City[$i]."', states='".$CLD_States[$i]."', zip='".$CLD_Zip[$i]."', dob='".$CLD_DOB[$i]."', relationship='".$CLD_Relationship[$i]."', email='".$CLD_Email[$i]."', 
                phone='".$CLD_phone[$i]."', phone2='".$CLD_phone2[$i]."' WHERE username='".$username."' AND childrenid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($CLD_FullName); $i ++) {
            $sql = "INSERT INTO pre_need_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$CLD_FullName[$i]."', '".$CLD_Address1[$i]."', '".$CLD_Address2[$i]."', '".$CLD_City[$i]."', '".$CLD_States[$i]."', 
                '".$CLD_Zip[$i]."', '".$CLD_DOB[$i]."', '".$CLD_Relationship[$i]."', '".$CLD_Email[$i]."', '".$CLD_phone[$i]."', '".$CLD_phone2[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($CLD_FullName); $i ++) {
            $sql = "INSERT INTO pre_need_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$CLD_FullName[$i]."', '".$CLD_Address1[$i]."', '".$CLD_Address2[$i]."', '".$CLD_City[$i]."', '".$CLD_States[$i]."', 
                '".$CLD_Zip[$i]."', '".$CLD_DOB[$i]."', '".$CLD_Relationship[$i]."', '".$CLD_Email[$i]."', '".$CLD_phone[$i]."', '".$CLD_phone2[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Grand Children Form///////////////////
    $GCLD_FullName = $_POST['GCLD_FullName'];
    $GCLD_Address1 = $_POST['GCLD_Address1'];
    $GCLD_Address2 = $_POST['GCLD_Address2'];
    $GCLD_City = $_POST['GCLD_City'];
    $GCLD_States = $_POST['GCLD_States'];
    $GCLD_Zip = $_POST['GCLD_Zip'];
    $GCLD_DOB = $_POST['GCLD_DOB'];
    $GCLD_Relationship = $_POST['GCLD_Relationship'];
    $GCLD_Email = $_POST['GCLD_Email'];
    $GCLD_phone = $_POST['GCLD_phone'];
    $GCLD_phone2 = $_POST['GCLD_phone2'];
    
    $sql = "SELECT * FROM pre_need_grand_children WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE pre_need_grand_children SET fullname='".$GCLD_FullName[$i]."', address1='".$GCLD_Address1[$i]."', address2='".$GCLD_Address2[$i]."', 
                city='".$GCLD_City[$i]."', states='".$GCLD_States[$i]."', zip='".$GCLD_Zip[$i]."', dob='".$GCLD_DOB[$i]."', relationship='".$GCLD_Relationship[$i]."', email='".$GCLD_Email[$i]."', 
                phone='".$GCLD_phone[$i]."', phone2='".$GCLD_phone2[$i]."' WHERE username='".$username."' AND childrenid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($GCLD_FullName); $i ++) {
            $sql = "INSERT INTO pre_need_grand_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$GCLD_FullName[$i]."', '".$GCLD_Address1[$i]."', '".$GCLD_Address2[$i]."', '".$GCLD_City[$i]."', '".$GCLD_States[$i]."', 
                '".$GCLD_Zip[$i]."', '".$GCLD_DOB[$i]."', '".$GCLD_Relationship[$i]."', '".$GCLD_Email[$i]."', '".$GCLD_phone[$i]."', '".$GCLD_phone2[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($GCLD_FullName); $i ++) {
            $sql = "INSERT INTO pre_need_grand_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$GCLD_FullName[$i]."', '".$GCLD_Address1[$i]."', '".$GCLD_Address2[$i]."', '".$GCLD_City[$i]."', '".$GCLD_States[$i]."', 
                '".$GCLD_Zip[$i]."', '".$GCLD_DOB[$i]."', '".$GCLD_Relationship[$i]."', '".$GCLD_Email[$i]."', '".$GCLD_phone[$i]."', '".$GCLD_phone2[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Military Service Form///////////////////
    $MLT_BranchID = (isset($_POST['MLT_BranchID']) ) ? trim($_POST['MLT_BranchID']) : '';
    $MLT_WarCampaignID = (isset($_POST['MLT_WarCampaignID']) ) ? trim($_POST['MLT_WarCampaignID']) : '';
    $MLT_SerialNumber = (isset($_POST['MLT_SerialNumber']) ) ? trim($_POST['MLT_SerialNumber']) : '';
    $MLT_Rank = (isset($_POST['MLT_Rank']) ) ? trim($_POST['MLT_Rank']) : '';
    $MLT_EnlistmentDate = (isset($_POST['MLT_EnlistmentDate']) ) ? trim($_POST['MLT_EnlistmentDate']) : '';
    $MLT_DischargeDate = (isset($_POST['MLT_DischargeDate']) ) ? trim($_POST['MLT_DischargeDate']) : '';
    $MLT_TypeOfDischargeID = (isset($_POST['MLT_TypeOfDischargeID']) ) ? trim($_POST['MLT_TypeOfDischargeID']) : '';
    $MLT_DD214 = (isset($_POST['MLT_DD214']) ) ? trim($_POST['MLT_DD214']) : '';
    $MLT_Headstone = (isset($_POST['MLT_Headstone']) ) ? trim($_POST['MLT_Headstone']) : '';
    $MLT_ApplicationForBurial = (isset($_POST['MLT_ApplicationForBurial']) ) ? trim($_POST['MLT_ApplicationForBurial']) : '';
    $MLT_ApplicationForFlag = (isset($_POST['MLT_ApplicationForFlag']) ) ? trim($_POST['MLT_ApplicationForFlag']) : '';
    $MLT_HonorGuard = (isset($_POST['MLT_HonorGuard']) ) ? trim($_POST['MLT_HonorGuard']) : '';
    
    $sql = "SELECT * FROM pre_need_military_service WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE pre_need_military_service SET BranchID='".$MLT_BranchID."', WarCampaignID='".$MLT_WarCampaignID."', SerialNumber='".$MLT_SerialNumber."', 
            Rank='".$MLT_Rank."', EnlistmentDate='".$MLT_EnlistmentDate."', DischargeDate='".$MLT_DischargeDate."', TypeOfDischargeID='".$MLT_TypeOfDischargeID."', 
            DD214='".$MLT_DD214."', Headstone='".$MLT_Headstone."', ApplicationForBurial='".$MLT_ApplicationForBurial."', ApplicationForFlag='".$MLT_ApplicationForFlag."', 
            HonorGuard='".$MLT_HonorGuard."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO pre_need_military_service (username, BranchID, WarCampaignID, SerialNumber, Rank, EnlistmentDate, DischargeDate, TypeOfDischargeID, DD214, 
                Headstone, ApplicationForBurial, ApplicationForFlag, HonorGuard)

        VALUES ('".$username."', '".$MLT_BranchID."', '".$MLT_WarCampaignID."', '".$MLT_SerialNumber."', '".$MLT_Rank."', '".$MLT_EnlistmentDate."', 
                '".$MLT_DischargeDate."', '".$MLT_TypeOfDischargeID."', '".$MLT_DD214."', '".$MLT_Headstone."', '".$MLT_ApplicationForBurial."', 
                '".$MLT_ApplicationForFlag."', '".$MLT_HonorGuard."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Church Form///////////////////
    $CHU_Church = (isset($_POST['CHU_Church']) ) ? trim($_POST['CHU_Church']) : '';
    $CHU_ClergyName = (isset($_POST['CHU_ClergyName']) ) ? trim($_POST['CHU_ClergyName']) : '';
    $CHU_Address1 = (isset($_POST['CHU_Address1']) ) ? trim($_POST['CHU_Address1']) : '';
    $CHU_Address2 = (isset($_POST['CHU_Address2']) ) ? trim($_POST['CHU_Address2']) : '';
    $CHU_City = (isset($_POST['CHU_City']) ) ? trim($_POST['CHU_City']) : '';
    $CHU_States = (isset($_POST['CHU_States']) ) ? trim($_POST['CHU_States']) : '';
    $CHU_Zip = (isset($_POST['CHU_Zip']) ) ? trim($_POST['CHU_Zip']) : '';
    $CHU_Email = (isset($_POST['CHU_Email']) ) ? trim($_POST['CHU_Email']) : '';
    $CHU_phone = (isset($_POST['CHU_phone']) ) ? trim($_POST['CHU_phone']) : '';
    $CHU_phone2 = (isset($_POST['CHU_phone2']) ) ? trim($_POST['CHU_phone2']) : '';
    
    $sql = "SELECT * FROM pre_need_church WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE pre_need_church SET Church='".$CHU_Church."', ClergyName='".$CHU_ClergyName."', Address1='".$CHU_Address1."', 
            Address2='".$CHU_Address2."', City='".$CHU_City."', States='".$CHU_States."', Zip='".$CHU_Zip."', 
            Email='".$CHU_Email."', phone='".$CHU_phone."', phone2='".$CHU_phone2."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO pre_need_church (username, Church, ClergyName, Address1, Address2, City, States, Zip, Email, phone, phone2)

        VALUES ('".$username."', '".$CHU_Church."', '".$CHU_ClergyName."', '".$CHU_Address1."', '".$CHU_Address2."', '".$CHU_City."', 
                '".$CHU_States."', '".$CHU_Zip."', '".$CHU_Email."', '".$CHU_phone."', '".$CHU_phone2."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Place of worship Form///////////////////
    $POW_PlaceOfWorship = (isset($_POST['POW_PlaceOfWorship']) ) ? trim($_POST['POW_PlaceOfWorship']) : '';
    $POW_ClergyName = (isset($_POST['POW_ClergyName']) ) ? trim($_POST['POW_ClergyName']) : '';
    $POW_Address1 = (isset($_POST['POW_Address1']) ) ? trim($_POST['POW_Address1']) : '';
    $POW_Address2 = (isset($_POST['POW_Address2']) ) ? trim($_POST['POW_Address2']) : '';
    $POW_City = (isset($_POST['POW_City']) ) ? trim($_POST['POW_City']) : '';
    $POW_States = (isset($_POST['POW_States']) ) ? trim($_POST['POW_States']) : '';
    $POW_Zip = (isset($_POST['POW_Zip']) ) ? trim($_POST['POW_Zip']) : '';
    $POW_Email = (isset($_POST['POW_Email']) ) ? trim($_POST['POW_Email']) : '';
    $POW_phone = (isset($_POST['POW_phone']) ) ? trim($_POST['POW_phone']) : '';
    $POW_phone2 = (isset($_POST['POW_phone2']) ) ? trim($_POST['POW_phone2']) : '';
    
    $sql = "SELECT * FROM pre_need_place_of_worship WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE pre_need_place_of_worship SET PlaceOfWorship='".$POW_PlaceOfWorship."', ClergyName='".$POW_ClergyName."', Address1='".$POW_Address1."', 
            Address2='".$POW_Address2."', City='".$POW_City."', States='".$POW_States."', Zip='".$POW_Zip."', 
            Email='".$POW_Email."', phone='".$POW_phone."', phone2='".$POW_phone2."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO pre_need_place_of_worship (username, PlaceOfWorship, ClergyName, Address1, Address2, City, States, Zip, Email, phone, phone2)

        VALUES ('".$username."', '".$POW_PlaceOfWorship."', '".$POW_ClergyName."', '".$POW_Address1."', '".$POW_Address2."', '".$POW_City."', 
                '".$POW_States."', '".$POW_Zip."', '".$POW_Email."', '".$POW_phone."', '".$POW_phone2."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Education Form///////////////////
    $EDU_EduHighSchool = (isset($_POST['EDU_EduHighSchool']) ) ? trim($_POST['EDU_EduHighSchool']) : '';
    $EDU_EduHSGraduated = (isset($_POST['EDU_EduHSGraduated']) ) ? trim($_POST['EDU_EduHSGraduated']) : '';
    $EDU_undergraducate = (isset($_POST['EDU_undergraducate']) ) ? trim($_POST['EDU_undergraducate']) : '';
    $EDU_undergraducatedegree = (isset($_POST['EDU_undergraducatedegree']) ) ? trim($_POST['EDU_undergraducatedegree']) : '';
    $EDU_undergraducatedegreecheck = (isset($_POST['EDU_undergraducatedegreecheck']) ) ? trim($_POST['EDU_undergraducatedegreecheck']) : '';
    $EDU_graduate = (isset($_POST['EDU_graduate']) ) ? trim($_POST['EDU_graduate']) : '';
    $EDU_graducatedegree = (isset($_POST['EDU_graducatedegree']) ) ? trim($_POST['EDU_graducatedegree']) : '';
    $EDU_graducatedegreecheck = (isset($_POST['EDU_graducatedegreecheck']) ) ? trim($_POST['EDU_graducatedegreecheck']) : '';
    $POW_phone = (isset($_POST['POW_phone']) ) ? trim($_POST['POW_phone']) : '';
    $POW_phone2 = (isset($_POST['POW_phone2']) ) ? trim($_POST['POW_phone2']) : '';
    
    $sql = "SELECT * FROM pre_need_education WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE pre_need_education SET EduHighSchool='".$EDU_EduHighSchool."', EduHSGraduated='".$EDU_EduHSGraduated."', undergraducate='".$EDU_undergraducate."', 
            undergraducatedegree='".$EDU_undergraducatedegree."', undergraducatedegreecheck='".$EDU_undergraducatedegreecheck."', graduate='".$EDU_graduate."', 
            graducatedegree='".$EDU_graducatedegree."', graducatedegreecheck='".$EDU_graducatedegreecheck."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO pre_need_education (username, EduHighSchool, EduHSGraduated, undergraducate, undergraducatedegree, undergraducatedegreecheck, graduate, 
                graducatedegree, graducatedegreecheck)

        VALUES ('".$username."', '".$EDU_EduHighSchool."', '".$EDU_EduHSGraduated."', '".$EDU_undergraducate."', '".$EDU_undergraducatedegree."', '".$EDU_undergraducatedegreecheck."', 
                '".$EDU_graduate."', '".$EDU_graducatedegree."', '".$EDU_graducatedegreecheck."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Parents Form///////////////////
    $PAT_ParentDeceasedFathersDOB = (isset($_POST['PAT_ParentDeceasedFathersDOB']) ) ? trim($_POST['PAT_ParentDeceasedFathersDOB']) : '';
    $PAT_ParentsDeceasedFathersDOD = (isset($_POST['PAT_ParentsDeceasedFathersDOD']) ) ? trim($_POST['PAT_ParentsDeceasedFathersDOD']) : '';
    $PAT_ParentsDeceasedMothersDOB = (isset($_POST['PAT_ParentsDeceasedMothersDOB']) ) ? trim($_POST['PAT_ParentsDeceasedMothersDOB']) : '';
    $PAT_ParentsDeceasedMothersDOD = (isset($_POST['PAT_ParentsDeceasedMothersDOD']) ) ? trim($_POST['PAT_ParentsDeceasedMothersDOD']) : '';
    
    $sql = "SELECT * FROM pre_need_parents WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE pre_need_parents SET ParentDeceasedFathersDOB='".$PAT_ParentDeceasedFathersDOB."', ParentsDeceasedFathersDOD='".$PAT_ParentsDeceasedFathersDOD."', 
            ParentsDeceasedMothersDOB='".$PAT_ParentsDeceasedMothersDOB."', ParentsDeceasedMothersDOD='".$PAT_ParentsDeceasedMothersDOD."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO pre_need_parents (username, ParentDeceasedFathersDOB, ParentsDeceasedFathersDOD, ParentsDeceasedMothersDOB, ParentsDeceasedMothersDOD)

        VALUES ('".$username."', '".$PAT_ParentDeceasedFathersDOB."', '".$PAT_ParentsDeceasedFathersDOD."', '".$PAT_ParentsDeceasedMothersDOB."', '".$PAT_ParentsDeceasedMothersDOD."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Parents Form///////////////////
    $FDP_Burial = (isset($_POST['FDP_Burial']) ) ? trim($_POST['FDP_Burial']) : '';
    $FDP_Entombment = (isset($_POST['FDP_Entombment']) ) ? trim($_POST['FDP_Entombment']) : '';
    $FDP_Cremation = (isset($_POST['FDP_Cremation']) ) ? trim($_POST['FDP_Cremation']) : '';
    $FDP_BurialAtSea = (isset($_POST['FDP_BurialAtSea']) ) ? trim($_POST['FDP_BurialAtSea']) : '';
    $FDP_DateOfFinalDisposition = (isset($_POST['FDP_DateOfFinalDisposition']) ) ? trim($_POST['FDP_DateOfFinalDisposition']) : '';
    $FDP_FinalDisposition = (isset($_POST['FDP_FinalDisposition']) ) ? trim($_POST['FDP_FinalDisposition']) : '';
    $FDP_CemeteryID = (isset($_POST['FDP_CemeteryID']) ) ? trim($_POST['FDP_CemeteryID']) : '';
    $FDP_Location = (isset($_POST['FDP_Location']) ) ? trim($_POST['FDP_Location']) : '';
    $FDP_Section = (isset($_POST['FDP_Section']) ) ? trim($_POST['FDP_Section']) : '';
    $FDP_FuneralOrMemorialServiceAtID = (isset($_POST['FDP_FuneralOrMemorialServiceAtID']) ) ? trim($_POST['FDP_FuneralOrMemorialServiceAtID']) : '';
    $FDP_NameLotRegisteredTo = (isset($_POST['FDP_NameLotRegisteredTo']) ) ? trim($_POST['FDP_NameLotRegisteredTo']) : '';
    $FDP_WhereInLotIsGraveToBeOpened = (isset($_POST['FDP_WhereInLotIsGraveToBeOpened']) ) ? trim($_POST['FDP_WhereInLotIsGraveToBeOpened']) : '';
    $FDP_LotNo = (isset($_POST['FDP_LotNo']) ) ? trim($_POST['FDP_LotNo']) : '';
    $FDP_GraveNo = (isset($_POST['FDP_GraveNo']) ) ? trim($_POST['FDP_GraveNo']) : '';

    
    $sql = "SELECT * FROM pre_need_final_disposition WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE pre_need_final_disposition SET Burial='".$FDP_Burial."', Entombment='".$FDP_Entombment."', Cremation='".$FDP_Cremation."', BurialAtSea='".$FDP_BurialAtSea."',
            DateOfFinalDisposition='".$FDP_DateOfFinalDisposition."', FinalDisposition='".$FDP_FinalDisposition."',CemeteryID='".$FDP_CemeteryID."', 
            Location='".$FDP_Location."',Section='".$FDP_Section."', FuneralOrMemorialServiceAtID='".$FDP_FuneralOrMemorialServiceAtID."',
            NameLotRegisteredTo='".$FDP_NameLotRegisteredTo."', WhereInLotIsGraveToBeOpened='".$FDP_WhereInLotIsGraveToBeOpened."',LotNo='".$FDP_LotNo."', 
            GraveNo='".$FDP_GraveNo."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO pre_need_final_disposition (username, Burial, Entombment, Cremation, BurialAtSea,DateOfFinalDisposition, FinalDisposition, CemeteryID, Location,
                Section, FuneralOrMemorialServiceAtID, NameLotRegisteredTo, WhereInLotIsGraveToBeOpened, LotNo, GraveNo)

        VALUES ('".$username."', '".$FDP_Burial."', '".$FDP_Entombment."', '".$FDP_Cremation."', '".$FDP_BurialAtSea."', '".$FDP_DateOfFinalDisposition."', 
                '".$FDP_FinalDisposition."', '".$FDP_CemeteryID."', '".$FDP_Location."', '".$FDP_Section."', '".$FDP_FuneralOrMemorialServiceAtID."', 
                '".$FDP_NameLotRegisteredTo."', '".$FDP_WhereInLotIsGraveToBeOpened."', '".$FDP_LotNo."', '".$FDP_GraveNo."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Crematory Form///////////////////
    $CRM_PartyOfInformant = (isset($_POST['CRM_FuneralHomeCrematoryResponsiblePartyOfInformant']) ) ? trim($_POST['CRM_FuneralHomeCrematoryResponsiblePartyOfInformant']) : '';
    $CRM_DateOfCremation = (isset($_POST['CRM_FuneralHomeCrematoryDateOfCremation']) ) ? trim($_POST['CRM_FuneralHomeCrematoryDateOfCremation']) : '';
    $CRM_TimeOfCremation = (isset($_POST['CRM_FuneralHomeCrematoryTimeOfCremation']) ) ? trim($_POST['CRM_FuneralHomeCrematoryTimeOfCremation']) : '';
    $CRM_WaitTimeMet = (isset($_POST['CRM_FuneralHomeCrematoryWaitTimeMet']) ) ? trim($_POST['CRM_FuneralHomeCrematoryWaitTimeMet']) : '';
    $CRM_DirectorNote = (isset($_POST['CRM_FuneralDirectorNote']) ) ? trim($_POST['CRM_FuneralDirectorNote']) : '';
    
    $sql = "SELECT * FROM pre_need_final_crematory WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE pre_need_final_crematory SET PartyOfInformant='".$CRM_PartyOfInformant."', DateOfCremation='".$CRM_DateOfCremation."', TimeOfCremation='".$CRM_TimeOfCremation."', 
                WaitTimeMet='".$CRM_WaitTimeMet."', DirectorNote='".$CRM_DirectorNote."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO pre_need_final_crematory (username, PartyOfInformant, DateOfCremation, TimeOfCremation, WaitTimeMet, DirectorNote)

        VALUES ('".$username."', '".$CRM_PartyOfInformant."', '".$CRM_DateOfCremation."', '".$CRM_TimeOfCremation."', '".$CRM_WaitTimeMet."', '".$CRM_DirectorNote."')";
    }
    $conn->query($sql);
    //////////////////////////////////////
    
    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>