<?php

    require 'connectDatabase.php';
    require('constant.php');

    //reCAPTCHA validation
	if (isset($_POST['g-recaptcha-response'])) {
		
		require('component/recaptcha/src/autoload.php');		
		
		$recaptcha = new \ReCaptcha\ReCaptcha(SECRET_KEY);

		$resp = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);

		  if (!$resp->isSuccess()) {
				// $output = json_encode(array('type'=>'error', 'text' => '<b>Captcha</b> Validation Required!'));
                // die($output);
                $response['status'] = "CaptchaERROR";
                $response['error'] = "captcha";
                $conn->close();
                echo json_encode($response);return;
            		
		  }	
	}
    
    $username = (isset($_POST['username']) ) ? trim($_POST['username']) : '';
    $email = (isset($_POST['email']) ) ? trim($_POST['email']) : '';
    $password = md5((isset($_POST['new_password']) ) ? trim($_POST['new_password']) : '');

    $name_sql = "SELECT * FROM users WHERE username='".$username."';";
    $email_sql = "SELECT * FROM users WHERE email='".$email."';";
    $name_result = $conn->query($name_sql);
    $email_result = $conn->query($email_sql);

    if (mysqli_num_rows($name_result) > 0) {
        $response['status'] = "ERROR";
        $response['error'] = "name";
    } else if (mysqli_num_rows($email_result) > 0) {
        $response['status'] = "ERROR";
        $response['error'] = "email";
    } else {
        $sql = "INSERT INTO users (username, email, passwords)
                VALUES ('".$username."', '".$email."', '".$password."')";

        if ($conn->query($sql) === TRUE) {
            $response['status'] = "OK";
        } else {
            $response['status'] = "ERROR";
            $response['error'] = "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    
    $conn->close();
    echo json_encode($response);
?>