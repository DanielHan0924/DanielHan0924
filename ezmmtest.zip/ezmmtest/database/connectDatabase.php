<?php
    $db_server = 'localhost';
    $db_user = 'root';
    $db_pass = '';
    $db_name = 'ezmm';

    //for live site
    // $db_server = 'localhost';
    // $db_user = 'ezmort5_ezmm';
    // $db_pass = 'qwe123!@#';
    // $db_name = 'ezmort5_ezmm';
    $conn = new mysqli($db_server, $db_user, $db_pass, $db_name);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>