<?php

    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];

    ///////////////////Information Form///////////////////
    $OrganizationName = $_POST['OrganizationName'];
    $ContactName = $_POST['ContactName'];
    $Address1 = $_POST['Address1'];
    $Address2 = $_POST['Address2'];
    $City = $_POST['City'];
    $States = $_POST['States'];
    $Zip = $_POST['Zip'];
    $phone = $_POST['phone'];
    $URL = $_POST['URL'];
    
    $sql = "SELECT * FROM organization WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE organization SET OrganizationName='".$OrganizationName[$i]."', ContactName='".$ContactName[$i]."', Address1='".$Address1[$i]."', 
                Address2='".$Address2[$i]."', City='".$City[$i]."', States='".$States[$i]."', Zip='".$Zip[$i]."', phone='".$phone[$i]."', Email='".$URL[$i]."' 
                WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($OrganizationName); $i ++) {
            $sql = "INSERT INTO organization (username, childid, OrganizationName, ContactName, Address1, Address2, City, States, Zip, phone, URL)

            VALUES ('".$username."', '".$i."', '".$OrganizationName[$i]."', '".$ContactName[$i]."', '".$Address1[$i]."', '".$Address2[$i]."', '".$City[$i]."', 
                '".$States[$i]."', '".$Zip[$i]."', '".$phone[$i]."', '".$URL[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($OrganizationName); $i ++) {
            $sql = "INSERT INTO organization (username, childid, OrganizationName, ContactName, Address1, Address2, City, States, Zip, phone, URL)

            VALUES ('".$username."', '".$i."', '".$OrganizationName[$i]."', '".$ContactName[$i]."', '".$Address1[$i]."', '".$Address2[$i]."', '".$City[$i]."', 
                '".$States[$i]."', '".$Zip[$i]."', '".$phone[$i]."', '".$URL[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>