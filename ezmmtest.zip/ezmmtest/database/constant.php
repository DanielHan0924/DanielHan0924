<?php
//reCAPTCHA Configuration - go to Google and get the below keys http://www.google.com/recaptcha/admin
define('SITE_KEY',"6LcnP6kUAAAAAG28XmCbMXAbbtkxfsO0ckr9obJO"); 
define('SECRET_KEY',"6LcnP6kUAAAAAAp28ZxSExKdCZGGiM2Ym3TPBSiw");
?>