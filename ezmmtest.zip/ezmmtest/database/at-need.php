<?php
    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];

    ///////////////////Deceased Information Form///////////////////
    $PI_honorificID = (isset($_POST['PI_honorificID']) ) ? trim($_POST['PI_honorificID']) : '';
    $PI_firstname = (isset($_POST['PI_firstname']) ) ? trim($_POST['PI_firstname']) : '';
    $PI_middlename = (isset($_POST['PI_middlename']) ) ? trim($_POST['PI_middlename']) : '';
    $PI_lastname = (isset($_POST['PI_lastname']) ) ? trim($_POST['PI_lastname']) : '';
    $PI_suffix = (isset($_POST['PI_suffix']) ) ? trim($_POST['PI_suffix']) : '';
    $PI_address1 = (isset($_POST['PI_address1']) ) ? trim($_POST['PI_address1']) : '';
    $PI_address2 = (isset($_POST['PI_address2']) ) ? trim($_POST['PI_address2']) : '';
    $PI_township = (isset($_POST['PI_township']) ) ? trim($_POST['PI_township']) : '';
    $PI_city = (isset($_POST['PI_city']) ) ? trim($_POST['PI_city']) : '';
    $PI_states = (isset($_POST['PI_states']) ) ? trim($_POST['PI_states']) : '';
    $PI_zip = (isset($_POST['PI_zip']) ) ? trim($_POST['PI_zip']) : '';
    $PI_county = (isset($_POST['PI_county']) ) ? trim($_POST['PI_county']) : '';
    $PI_nickname = (isset($_POST['PI_nickname']) ) ? trim($_POST['PI_nickname']) : '';
    $PI_gender = (isset($_POST['PI_gender']) ) ? trim($_POST['PI_gender']) : '';
    $PI_ssn = (isset($_POST['PI_ssn']) ) ? trim($_POST['PI_ssn']) : '';
    $PI_email = (isset($_POST['PI_email']) ) ? trim($_POST['PI_email']) : '';
    $PI_phone = (isset($_POST['PI_phone']) ) ? trim($_POST['PI_phone']) : '';
    $PI_dod = (isset($_POST['PI_dod']) ) ? trim($_POST['PI_dod']) : '';
    $PI_tode = (isset($_POST['PI_tode']) ) ? trim($_POST['PI_tode']) : '';
    
    $sql = "SELECT * FROM at_need_pi WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE at_need_pi SET honorific='".$PI_honorificID."', firstName='".$PI_firstname."', middleName='".$PI_middlename."', lastName='".$PI_lastname."', 
            suffix='".$PI_suffix."', address1='".$PI_address1."', address2='".$PI_address2."', township='".$PI_township."', city='".$PI_city."', states='".$PI_states."', 
            zipCode='".$PI_zip."', country='".$PI_county."', nickName='".$PI_nickname."', gender='".$PI_gender."', SSN='".$PI_ssn."', email='".$PI_email."', 
            phone='".$PI_phone."', dateOfDeath='".$PI_dod."', timeOfDeath='".$PI_tode."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO at_need_pi (username, honorific, firstName, middleName, lastName, suffix, address1, address2, township, city, 
                                    states, zipCode, country, nickName, gender, SSN, email, phone, dateOfDeath, timeOfDeath)

        VALUES ('".$username."', '".$PI_honorificID."', '".$PI_firstname."', '".$PI_middlename."', '".$PI_lastname."', '".$PI_suffix."', '".$PI_address1."', '".$PI_address2."', 
                '".$PI_township."', '".$PI_city."', '".$PI_states."', '".$PI_zip."', '".$PI_county."', '".$PI_nickname."', '".$PI_gender."', '".$PI_ssn."', '".$PI_email."', 
                '".$PI_phone."', '".$PI_dod."', '".$PI_tode."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Next Of Kin Form///////////////////
    $NOK_fullname = (isset($_POST['NOK_fullname']) ) ? trim($_POST['NOK_fullname']) : '';
    $NOK_address1 = (isset($_POST['NOK_address1']) ) ? trim($_POST['NOK_address1']) : '';
    $NOK_address2 = (isset($_POST['NOK_address2']) ) ? trim($_POST['NOK_address2']) : '';
    $NOK_city = (isset($_POST['NOK_city']) ) ? trim($_POST['NOK_city']) : '';
    $NOK_states = (isset($_POST['NOK_states']) ) ? trim($_POST['NOK_states']) : '';
    $NOK_zip = (isset($_POST['NOK_zip']) ) ? trim($_POST['NOK_zip']) : '';
    $NOK_relationship = (isset($_POST['NOK_relationship']) ) ? trim($_POST['NOK_relationship']) : '';
    $NOK_phone = (isset($_POST['NOK_phone']) ) ? trim($_POST['NOK_phone']) : '';
    $NOK_phone2 = (isset($_POST['NOK_phone2']) ) ? trim($_POST['NOK_phone2']) : '';
    $NOK_email = (isset($_POST['NOK_email']) ) ? trim($_POST['NOK_email']) : '';
    
    $sql = "SELECT * FROM at_need_nok WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE at_need_nok SET fullname='".$NOK_fullname."', address1='".$NOK_address1."', address2='".$NOK_address2."', city='".$NOK_city."', 
            states='".$NOK_states."', zip='".$NOK_zip."', relationship='".$NOK_relationship."', phone='".$NOK_phone."', phone2='".$NOK_phone2."', email='".$NOK_email."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO at_need_nok (username, fullname, address1, address2, city, states, zip, relationship, phone, phone2, email)

        VALUES ('".$username."', '".$NOK_fullname."', '".$NOK_address1."', '".$NOK_address2."', '".$NOK_city."', '".$NOK_states."', '".$NOK_zip."', '".$NOK_relationship."', 
                '".$NOK_phone."', '".$NOK_phone2."', '".$NOK_email."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>