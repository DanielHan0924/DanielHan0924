<?php

    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];
    ///////////////////Personal Information Form///////////////////
    $FirstName = (isset($_POST['FirstName']) ) ? trim($_POST['FirstName']) : '';
    $MiddleName = (isset($_POST['MiddleName']) ) ? trim($_POST['MiddleName']) : '';
    $LastName = (isset($_POST['LastName']) ) ? trim($_POST['LastName']) : '';
    $Suffix = (isset($_POST['Suffix']) ) ? trim($_POST['Suffix']) : '';
    $NickName = (isset($_POST['NickName']) ) ? trim($_POST['NickName']) : '';
    $GenderID = (isset($_POST['GenderID']) ) ? trim($_POST['GenderID']) : '';
    $SSN = (isset($_POST['SSN']) ) ? trim($_POST['SSN']) : '';
    $TimeOfDeath = (isset($_POST['TimeOfDeath']) ) ? trim($_POST['TimeOfDeath']) : '';
    $RangeTimeOfDead = (isset($_POST['RangeTimeOfDead']) ) ? trim($_POST['RangeTimeOfDead']) : '';
    $TimeFound = (isset($_POST['TimeFound']) ) ? trim($_POST['TimeFound']) : '';
    $DateOfDeath = (isset($_POST['DateOfDeath']) ) ? trim($_POST['DateOfDeath']) : '';
    $Indicator = (isset($_POST['Indicator']) ) ? trim($_POST['Indicator']) : '';
    $dateOfBirth = (isset($_POST['dateOfBirth']) ) ? trim($_POST['dateOfBirth']) : '';
    $age = (isset($_POST['age']) ) ? trim($_POST['age']) : '';
    $PlaceOfDeathID = (isset($_POST['PlaceOfDeathID']) ) ? trim($_POST['PlaceOfDeathID']) : '';
    $Place = (isset($_POST['Place']) ) ? trim($_POST['Place']) : '';
    $facility_name = (isset($_POST['facility_name']) ) ? trim($_POST['facility_name']) : '';
    $CityID = (isset($_POST['CityID']) ) ? trim($_POST['CityID']) : '';
    $City = (isset($_POST['City']) ) ? trim($_POST['City']) : '';
    $StateID = (isset($_POST['StateID']) ) ? trim($_POST['StateID']) : '';

    $State = (isset($_POST['State']) ) ? trim($_POST['State']) : '';
    $ZipCodeID = (isset($_POST['ZipCodeID']) ) ? trim($_POST['ZipCodeID']) : '';
    $CountryID = (isset($_POST['CountryID']) ) ? trim($_POST['CountryID']) : '';
    $CountryFIPS = (isset($_POST['CountryFIPS']) ) ? trim($_POST['CountryFIPS']) : '';
    $armed_service = (isset($_POST['armed_service']) ) ? trim($_POST['armed_service']) : '';
    $dispositioni_method_of_disposition = (isset($_POST['dispositioni_method_of_disposition']) ) ? trim($_POST['dispositioni_method_of_disposition']) : '';
    $disposition_crematory_name = (isset($_POST['disposition_crematory_name']) ) ? trim($_POST['disposition_crematory_name']) : '';
    $disposition_crematory_name2 = (isset($_POST['disposition_crematory_name2']) ) ? trim($_POST['disposition_crematory_name2']) : '';
    $disposition_city1 = (isset($_POST['disposition_city1']) ) ? trim($_POST['disposition_city1']) : '';
    $disposition_country1 = (isset($_POST['disposition_country1']) ) ? trim($_POST['disposition_country1']) : '';
    $disposition_state1 = (isset($_POST['disposition_state1']) ) ? trim($_POST['disposition_state1']) : '';
    $disposition_place_of_disposition = (isset($_POST['disposition_place_of_disposition']) ) ? trim($_POST['disposition_place_of_disposition']) : '';
    $disposition_place_of_disposition2 = (isset($_POST['disposition_place_of_disposition2']) ) ? trim($_POST['disposition_place_of_disposition2']) : '';
    $disposition_city2 = (isset($_POST['disposition_city2']) ) ? trim($_POST['disposition_city2']) : '';
    $disposition_country2 = (isset($_POST['disposition_country2']) ) ? trim($_POST['disposition_country2']) : '';
    $disposition_state2 = (isset($_POST['disposition_state2']) ) ? trim($_POST['disposition_state2']) : '';


    $funeral_home1 = (isset($_POST['funeral_home1']) ) ? trim($_POST['funeral_home1']) : '';
    $funeral_home2 = (isset($_POST['funeral_home2']) ) ? trim($_POST['funeral_home2']) : '';
    $funeral_city = (isset($_POST['funeral_city']) ) ? trim($_POST['funeral_city']) : '';
    $funeral_country = (isset($_POST['funeral_country']) ) ? trim($_POST['funeral_country']) : '';
    $funeral_state = (isset($_POST['funeral_state']) ) ? trim($_POST['funeral_state']) : '';
    $funeral_director1 = (isset($_POST['funeral_director1']) ) ? trim($_POST['funeral_director1']) : '';
    $funeral_director2 = (isset($_POST['funeral_director2']) ) ? trim($_POST['funeral_director2']) : '';
    $funeral_director_license = (isset($_POST['funeral_director_license']) ) ? trim($_POST['funeral_director_license']) : '';
    $funeral_home_number = (isset($_POST['funeral_home_number']) ) ? trim($_POST['funeral_home_number']) : '';


    $assignment_certifier_type = (isset($_POST['assignment_certifier_type']) ) ? trim($_POST['assignment_certifier_type']) : '';
    $assignment_coroner_location = (isset($_POST['assignment_coroner_location']) ) ? trim($_POST['assignment_coroner_location']) : '';
    $assignment_physician1 = (isset($_POST['assignment_physician1']) ) ? trim($_POST['assignment_physician1']) : '';
    $assignment_physician2 = (isset($_POST['assignment_physician2']) ) ? trim($_POST['assignment_physician2']) : '';
    $assignment_dropped_to_papaer = (isset($_POST['assignment_dropped_to_papaer']) ) ? trim($_POST['assignment_dropped_to_papaer']) : '';
    $assignment_email_notify = (isset($_POST['assignment_email_notify']) ) ? trim($_POST['assignment_email_notify']) : '';
    $assignment_date_sent = (isset($_POST['assignment_date_sent']) ) ? trim($_POST['assignment_date_sent']) : '';
    $assignment_certifier_location = (isset($_POST['assignment_certifier_location']) ) ? trim($_POST['assignment_certifier_location']) : '';
    $assignment_certifier_country = (isset($_POST['assignment_certifier_country']) ) ? trim($_POST['assignment_certifier_country']) : '';

    $residence_street_number = (isset($_POST['residence_street_number']) ) ? trim($_POST['residence_street_number']) : '';
    $residence_apt = (isset($_POST['residence_apt']) ) ? trim($_POST['residence_apt']) : '';
    $residence_city_limits = (isset($_POST['residence_city_limits']) ) ? trim($_POST['residence_city_limits']) : '';
    $residence_zipcode = (isset($_POST['residence_zipcode']) ) ? trim($_POST['residence_zipcode']) : '';
    $residence_city_township = (isset($_POST['residence_city_township']) ) ? trim($_POST['residence_city_township']) : '';
    $residence_country1 = (isset($_POST['residence_country1']) ) ? trim($_POST['residence_country1']) : '';
    $residence_country2 = (isset($_POST['residence_country2']) ) ? trim($_POST['residence_country2']) : '';
    $residence_state = (isset($_POST['residence_state']) ) ? trim($_POST['residence_state']) : '';

    $demographics_country_birth1 = (isset($_POST['demographics_country_birth1']) ) ? trim($_POST['demographics_country_birth1']) : '';
    $demographics_country_birth2 = (isset($_POST['demographics_country_birth2']) ) ? trim($_POST['demographics_country_birth2']) : '';
    $demographics_state_birth = (isset($_POST['demographics_state_birth']) ) ? trim($_POST['demographics_state_birth']) : '';
    $demographics_marital_status = (isset($_POST['demographics_marital_status']) ) ? trim($_POST['demographics_marital_status']) : '';
    $surviving_firstname = (isset($_POST['surviving_firstname']) ) ? trim($_POST['surviving_firstname']) : '';
    $surviving_middlename = (isset($_POST['surviving_middlename']) ) ? trim($_POST['surviving_middlename']) : '';
    $surviving_lastname = (isset($_POST['surviving_lastname']) ) ? trim($_POST['surviving_lastname']) : '';
    $surviving_suffix = (isset($_POST['surviving_suffix']) ) ? trim($_POST['surviving_suffix']) : '';
    $parents_firstname = (isset($_POST['parents_firstname']) ) ? trim($_POST['parents_firstname']) : '';
    $parents_middlename = (isset($_POST['parents_middlename']) ) ? trim($_POST['parents_middlename']) : '';
    $parents_lastname = (isset($_POST['parents_lastname']) ) ? trim($_POST['parents_lastname']) : '';
    $parents_suffix = (isset($_POST['parents_suffix']) ) ? trim($_POST['parents_suffix']) : '';
    $mother_firstname = (isset($_POST['mother_firstname']) ) ? trim($_POST['mother_firstname']) : '';
    $mother_middlename = (isset($_POST['mother_middlename']) ) ? trim($_POST['mother_middlename']) : '';
    $mother_lastname = (isset($_POST['mother_lastname']) ) ? trim($_POST['mother_lastname']) : '';

    $informant_firstname = (isset($_POST['informant_firstname']) ) ? trim($_POST['informant_firstname']) : '';
    $informant_middlename = (isset($_POST['informant_middlename']) ) ? trim($_POST['informant_middlename']) : '';
    $informant_lastname = (isset($_POST['informant_lastname']) ) ? trim($_POST['informant_lastname']) : '';
    $informant_suffix = (isset($_POST['informant_suffix']) ) ? trim($_POST['informant_suffix']) : '';
    $informant_relationship1 = (isset($_POST['informant_relationship1']) ) ? trim($_POST['informant_relationship1']) : '';
    $informant_relationship2 = (isset($_POST['informant_relationship2']) ) ? trim($_POST['informant_relationship2']) : '';
    $informant_mailing_address = (isset($_POST['informant_mailing_address']) ) ? trim($_POST['informant_mailing_address']) : '';
    $informant_city = (isset($_POST['informant_city']) ) ? trim($_POST['informant_city']) : '';
    $informant_state = (isset($_POST['informant_state']) ) ? trim($_POST['informant_state']) : '';
    $informant_zipcode = (isset($_POST['informant_zipcode']) ) ? trim($_POST['informant_zipcode']) : '';

    $demographics_education = (isset($_POST['demographics_education']) ) ? trim($_POST['demographics_education']) : '';
    $demographics_hispanic = (isset($_POST['demographics_hispanic']) ) ? trim($_POST['demographics_hispanic']) : '';
    $demographics_mexian = (isset($_POST['demographics_mexian']) ) ? trim($_POST['demographics_mexian']) : '';
    $demographics_puerto = (isset($_POST['demographics_puerto']) ) ? trim($_POST['demographics_puerto']) : '';
    $demographics_cuban = (isset($_POST['demographics_cuban']) ) ? trim($_POST['demographics_cuban']) : '';
    $demographics_specify = (isset($_POST['demographics_specify']) ) ? trim($_POST['demographics_specify']) : '';
    $demographics_other = (isset($_POST['demographics_other']) ) ? trim($_POST['demographics_other']) : '';

    $race_white = (isset($_POST['race_white']) ) ? trim($_POST['race_white']) : '';
    $race_black = (isset($_POST['race_black']) ) ? trim($_POST['race_black']) : '';
    $race_asian = (isset($_POST['race_asian']) ) ? trim($_POST['race_asian']) : '';
    $race_chinese = (isset($_POST['race_chinese']) ) ? trim($_POST['race_chinese']) : '';
    $race_filipino = (isset($_POST['race_filipino']) ) ? trim($_POST['race_filipino']) : '';
    $race_vietnamese = (isset($_POST['race_vietnamese']) ) ? trim($_POST['race_vietnamese']) : '';
    $race_japanese = (isset($_POST['race_japanese']) ) ? trim($_POST['race_japanese']) : '';
    $race_korean = (isset($_POST['race_korean']) ) ? trim($_POST['race_korean']) : '';
    $race_hawaiian = (isset($_POST['race_hawaiian']) ) ? trim($_POST['race_hawaiian']) : '';
    $race_samoan = (isset($_POST['race_samoan']) ) ? trim($_POST['race_samoan']) : '';
    $race_guamanian = (isset($_POST['race_guamanian']) ) ? trim($_POST['race_guamanian']) : '';
    $race_american = (isset($_POST['race_american']) ) ? trim($_POST['race_american']) : '';
    $race_native_desc = (isset($_POST['race_native_desc']) ) ? trim($_POST['race_native_desc']) : '';
    $race_native_chk = (isset($_POST['race_native_chk']) ) ? trim($_POST['race_native_chk']) : '';
    $race_other_asian_desc = (isset($_POST['race_other_asian_desc']) ) ? trim($_POST['race_other_asian_desc']) : '';
    $race_other_asian_chk = (isset($_POST['race_other_asian_chk']) ) ? trim($_POST['race_other_asian_chk']) : '';
    $race_other_pacific_desc = (isset($_POST['race_other_pacific_desc']) ) ? trim($_POST['race_other_pacific_desc']) : '';
    $race_other_pacific_chk = (isset($_POST['race_other_pacific_chk']) ) ? trim($_POST['race_other_pacific_chk']) : '';
    $race_native_desc2 = (isset($_POST['race_native_desc2']) ) ? trim($_POST['race_native_desc2']) : '';
    $race_other_asian_chk2 = (isset($_POST['race_other_asian_chk2']) ) ? trim($_POST['race_other_asian_chk2']) : '';
    $race_other_asian_desc2 = (isset($_POST['race_other_asian_desc2']) ) ? trim($_POST['race_other_asian_desc2']) : '';
    $race_other_pacific_chk2 = (isset($_POST['race_other_pacific_chk2']) ) ? trim($_POST['race_other_pacific_chk2']) : '';
    $race_other_pacific_desc2 = (isset($_POST['race_other_pacific_desc2']) ) ? trim($_POST['race_other_pacific_desc2']) : '';
    $demographics_occupation = (isset($_POST['demographics_occupation']) ) ? trim($_POST['demographics_occupation']) : '';
    $demographics_industry = (isset($_POST['demographics_industry']) ) ? trim($_POST['demographics_industry']) : '';
    
    $sql = "SELECT * FROM vital_statistics_district WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE vital_statistics_district SET FirstName='".$FirstName."', MiddleName='".$MiddleName."', LastName='".$LastName."', Suffix='".$Suffix."', NickName='".$NickName."', 
                    GenderID='".$GenderID."', SSN='".$SSN."', TimeOfDeath='".$TimeOfDeath."', RangeTimeOfDead='".$RangeTimeOfDead."', TimeFound='".$TimeFound."', DateOfDeath='".$DateOfDeath."', 
                    Indicator='".$Indicator."', dateOfBirth='".$dateOfBirth."', age='".$age."', PlaceOfDeathID='".$PlaceOfDeathID."', Place='".$Place."', facility_name='".$facility_name."', 
                    CityID='".$CityID."', City='".$City."', StateID='".$StateID."', State='".$State."', ZipCodeID='".$ZipCodeID."', CountryID='".$CountryID."', CountryFIPS='".$CountryFIPS."', 
                    armed_service='".$armed_service."', dispositioni_method_of_disposition='".$dispositioni_method_of_disposition."', disposition_crematory_name='".$disposition_crematory_name."', 
                    disposition_crematory_name2='".$disposition_crematory_name2."', disposition_city1='".$disposition_city1."', disposition_country1='".$disposition_country1."', 
                    disposition_state1='".$disposition_state1."', disposition_place_of_disposition='".$disposition_place_of_disposition."', disposition_place_of_disposition2='".$disposition_place_of_disposition2."', 
                    disposition_city2='".$disposition_city2."', disposition_country2='".$disposition_country2."', disposition_state2='".$disposition_state2."', 
                    funeral_home1='".$funeral_home1."', funeral_home2='".$funeral_home2."', funeral_city='".$funeral_city."', funeral_country='".$funeral_country."', funeral_state='".$funeral_state."', 
                    funeral_director1='".$funeral_director1."', funeral_director2='".$funeral_director2."', funeral_director_license='".$funeral_director_license."', 
                    funeral_home_number='".$funeral_home_number."', assignment_certifier_type='".$assignment_certifier_type."', assignment_coroner_location='".$assignment_coroner_location."', 
                    assignment_physician1='".$assignment_physician1."', assignment_physician2='".$assignment_physician2."', assignment_dropped_to_papaer='".$assignment_dropped_to_papaer."', 
                    assignment_email_notify='".$assignment_email_notify."', assignment_date_sent='".$assignment_date_sent."', assignment_certifier_location='".$assignment_certifier_location."', 
                    assignment_certifier_country='".$assignment_certifier_country."', residence_street_number='".$residence_street_number."', residence_apt='".$residence_apt."', 
                    residence_city_limits='".$residence_city_limits."', residence_zipcode='".$residence_zipcode."', residence_city_township='".$residence_city_township."', 
                    residence_country1='".$residence_country1."', residence_country2='".$residence_country2."', residence_state='".$residence_state."', demographics_country_birth1='".$demographics_country_birth1."', 
                    demographics_country_birth2='".$demographics_country_birth2."', demographics_state_birth='".$demographics_state_birth."', 
                    demographics_marital_status='".$demographics_marital_status."', surviving_firstname='".$surviving_firstname."', surviving_middlename='".$surviving_middlename."', 
                    surviving_lastname='".$surviving_lastname."', surviving_suffix='".$surviving_suffix."', parents_firstname='".$parents_firstname."', parents_middlename='".$parents_middlename."', 
                    parents_lastname='".$parents_lastname."', parents_suffix='".$parents_suffix."', mother_firstname='".$mother_firstname."', mother_middlename='".$mother_middlename."', 
                    mother_lastname='".$mother_lastname."', informant_firstname='".$informant_firstname."', informant_middlename='".$informant_middlename."', informant_lastname='".$informant_lastname."', 
                    informant_suffix='".$informant_suffix."', informant_relationship1='".$informant_relationship1."', informant_relationship2='".$informant_relationship2."', 
                    informant_mailing_address='".$informant_mailing_address."', informant_city='".$informant_city."', informant_state='".$informant_state."', 
                    informant_zipcode='".$informant_zipcode."', demographics_education='".$demographics_education."', demographics_hispanic='".$demographics_hispanic."', 
                    demographics_mexian='".$demographics_mexian."', demographics_puerto='".$demographics_puerto."', demographics_cuban='".$demographics_cuban."', 
                    demographics_specify='".$demographics_specify."', demographics_other='".$demographics_other."', race_white='".$race_white."', race_black='".$race_black."', 
                    race_asian='".$race_asian."', race_chinese='".$race_chinese."', race_filipino='".$race_filipino."', race_vietnamese='".$race_vietnamese."', 
                    race_japanese='".$race_japanese."', race_korean='".$race_korean."', race_hawaiian='".$race_hawaiian."', race_samoan='".$race_samoan."', race_guamanian='".$race_guamanian."', 
                    race_american='".$race_american."', race_native_desc='".$race_native_desc."', race_native_chk='".$race_native_chk."', race_other_asian_desc='".$race_other_asian_desc."', 
                    race_other_asian_chk='".$race_other_asian_chk."', race_other_pacific_desc='".$race_other_pacific_desc."', race_other_pacific_chk='".$race_other_pacific_chk."', 
                    race_native_desc2='".$race_native_desc2."', race_other_asian_chk2='".$race_other_asian_chk2."', race_other_asian_desc2='".$race_other_asian_desc2."', 
                    race_other_pacific_chk2='".$race_other_pacific_chk2."', race_other_pacific_desc2='".$race_other_pacific_desc2."', demographics_occupation='".$demographics_occupation."', 
                    demographics_industry='".$demographics_industry."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO vital_statistics_district (username, FirstName, MiddleName, LastName, Suffix, NickName, GenderID, SSN, TimeOfDeath, RangeTimeOfDead, TimeFound,
                DateOfDeath, Indicator, dateOfBirth, age, PlaceOfDeathID, Place, facility_name, CityID, City, StateID, State, ZipCodeID, CountryID, CountryFIPS, armed_service,
                dispositioni_method_of_disposition, disposition_crematory_name, disposition_crematory_name2, disposition_city1, disposition_country1, disposition_state1,
                disposition_place_of_disposition, disposition_place_of_disposition2, disposition_city2, disposition_country2, disposition_state2, funeral_home1, funeral_home2,
                funeral_city, funeral_country, funeral_state, funeral_director1, funeral_director2, funeral_director_license, funeral_home_number, assignment_certifier_type,
                assignment_coroner_location, assignment_physician1, assignment_physician2, assignment_dropped_to_papaer, assignment_email_notify, assignment_date_sent,
                assignment_certifier_location, assignment_certifier_country, residence_street_number, residence_apt, residence_city_limits, residence_zipcode, residence_city_township,
                residence_country1, residence_country2, residence_state, demographics_country_birth1, demographics_country_birth2, demographics_state_birth, demographics_marital_status,
                surviving_firstname, surviving_middlename, surviving_lastname, surviving_suffix, parents_firstname, parents_middlename, parents_lastname, parents_suffix,
                mother_firstname, mother_middlename, mother_lastname, informant_firstname, informant_middlename, informant_lastname, informant_suffix, informant_relationship1,
                informant_relationship2, informant_mailing_address, informant_city, informant_state, informant_zipcode, demographics_education, demographics_hispanic, 
                demographics_mexian, demographics_puerto, demographics_cuban, demographics_specify, demographics_other, race_white, race_black, race_asian, race_chinese,
                race_filipino, race_vietnamese, race_japanese, race_korean, race_hawaiian, race_samoan, race_guamanian, race_american, race_native_desc, race_native_chk, 
                race_other_asian_desc, race_other_asian_chk, race_other_pacific_desc, race_other_pacific_chk, race_native_desc2, race_other_asian_chk2, race_other_asian_desc2,
                race_other_pacific_chk2, race_other_pacific_desc2, demographics_occupation, demographics_industry)

        VALUES ('".$username."', '".$FirstName."', '".$MiddleName."', '".$LastName."', '".$Suffix."', '".$NickName."', '".$GenderID."', '".$SSN."', '".$TimeOfDeath."', 
                '".$RangeTimeOfDead."', '".$TimeFound."', '".$DateOfDeath."', '".$Indicator."', '".$dateOfBirth."', '".$age."', '".$PlaceOfDeathID."', '".$Place."', 
                '".$facility_name."', '".$CityID."', '".$City."', '".$StateID."', '".$State."', '".$ZipCodeID."', '".$CountryID."', '".$CountryFIPS."', '".$armed_service."', 
                '".$dispositioni_method_of_disposition."', '".$disposition_crematory_name."', '".$disposition_crematory_name2."', '".$disposition_city1."', '".$disposition_country1."', 
                '".$disposition_state1."', '".$disposition_place_of_disposition."', '".$disposition_place_of_disposition2."', '".$disposition_city2."', '".$disposition_country2."', 
                '".$disposition_state2."', '".$funeral_home1."', '".$funeral_home2."', '".$funeral_city."', '".$funeral_country."', '".$funeral_state."', '".$funeral_director1."', 
                '".$funeral_director2."', '".$funeral_director_license."', '".$funeral_home_number."', '".$assignment_certifier_type."', '".$assignment_coroner_location."', 
                '".$assignment_physician1."', '".$assignment_physician2."', '".$assignment_dropped_to_papaer."', '".$assignment_email_notify."', '".$assignment_date_sent."', 
                '".$assignment_certifier_location."', '".$assignment_certifier_country."', '".$residence_street_number."', '".$residence_apt."', '".$residence_city_limits."', 
                '".$residence_zipcode."', '".$residence_city_township."', '".$residence_country1."', '".$residence_country2."', '".$residence_state."', '".$demographics_country_birth1."', 
                '".$demographics_country_birth2."', '".$demographics_state_birth."', '".$demographics_marital_status."', '".$surviving_firstname."', '".$surviving_middlename."', 
                '".$surviving_lastname."', '".$surviving_suffix."', '".$parents_firstname."', '".$parents_middlename."', '".$parents_lastname."', '".$parents_suffix."', '".$mother_firstname."', 
                '".$mother_middlename."', '".$mother_lastname."', '".$informant_firstname."', '".$informant_middlename."', '".$informant_lastname."', '".$informant_suffix."', 
                '".$informant_relationship1."', '".$informant_relationship2."', '".$informant_mailing_address."', '".$informant_city."', '".$informant_state."', '".$informant_zipcode."', 
                '".$demographics_education."', '".$demographics_hispanic."', '".$demographics_mexian."', '".$demographics_puerto."', '".$demographics_cuban."', '".$demographics_specify."', 
                '".$demographics_other."', '".$race_white."', '".$race_black."', '".$race_asian."', '".$race_chinese."', '".$race_filipino."', '".$race_vietnamese."', '".$race_japanese."', 
                '".$race_korean."', '".$race_hawaiian."', '".$race_samoan."', '".$race_guamanian."', '".$race_american."', '".$race_native_desc."', '".$race_native_chk."', 
                '".$race_other_asian_desc."', '".$race_other_asian_chk."', '".$race_other_pacific_desc."', '".$race_other_pacific_chk."', '".$race_native_desc2."', 
                '".$race_other_asian_chk2."', '".$race_other_asian_desc2."', '".$race_other_pacific_chk2."', '".$race_other_pacific_desc2."', '".$demographics_occupation."', '".$demographics_industry."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>