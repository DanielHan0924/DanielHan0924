<?php
    session_start();
    require 'connectDatabase.php';
    require('constant.php');

    $response['status'] = "OK";

    if (isset($_REQUEST['signout'])) {
        // unset($_SESSION["username"]);
        // remove all session variables
        session_unset();
        // destroy the session
        session_destroy();
    } else {
        $username = (isset($_POST['username']) ) ? trim($_POST['username']) : '';
        $password = md5((isset($_POST['password']) ) ? trim($_POST['password']) : '');

        $sql = "SELECT * FROM users WHERE username='".$username."';";
        $result = $conn->query($sql);
        $resultCheck = mysqli_num_rows($result);

        if ($resultCheck > 0) {
            $row = mysqli_fetch_assoc($result);
            if ($row['passwords'] != $password) {
                $response['status'] = "ERROR";
            } else {
                $_SESSION['username'] = $username;
                $_SESSION['userid'] = $row['id'];
                $_SESSION['userrole'] = $row['role'];
                $_SESSION['photo'] = $row['photo'];

                $_SESSION['cancreate'] = $row['cancreate'];
                $_SESSION['canread']   = $row['canread'];
                $_SESSION['canupdate'] = $row['canupdate'];
                $_SESSION['candelete'] = $row['candelete'];

                if ($row['crematory'] == NULL){
                    $response['status'] = "NEWUSER";
                }
            }
        } else {
            $response['status'] = "ERROR";
        }
    }
    //reCAPTCHA validation
	if (isset($_POST['g-recaptcha-response'])) {
		
		require('component/recaptcha/src/autoload.php');		
		
		$recaptcha = new \ReCaptcha\ReCaptcha(SECRET_KEY);

		$resp = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);

		  if (!$resp->isSuccess()) {
				// $output = json_encode(array('type'=>'error', 'text' => '<b>Captcha</b> Validation Required!'));
                // die($output);
                $response['status'] = "CaptchaERROR";				
		  }	
	}
    
    $conn->close();
    echo json_encode($response);
?>