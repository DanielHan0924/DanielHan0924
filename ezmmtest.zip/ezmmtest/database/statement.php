<?php

    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];

    ///////////////////Information Form///////////////////
    $INF_InformantName = $_POST['INF_InformantName'];
    $INF_AcceptedBy = $_POST['INF_AcceptedBy'];
    $INF_Address1 = $_POST['INF_Address1'];
    $INF_Address2 = $_POST['INF_Address2'];
    $INF_City = $_POST['INF_City'];
    $INF_States = $_POST['INF_States'];
    $INF_Zip = $_POST['INF_Zip'];
    $INF_SSN = $_POST['INF_SSN'];
    $INF_Email = $_POST['INF_Email'];
    $INF_phone = $_POST['INF_phone'];
    $INF_InvoiceDate = $_POST['INF_InvoiceDate'];
    $INF_DueDate = $_POST['INF_DueDate'];
    
    $sql = "SELECT * FROM statement_information WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE statement_information SET InformantName='".$INF_InformantName[$i]."', AcceptedBy='".$INF_AcceptedBy[$i]."', Address1='".$INF_Address1[$i]."', 
                Address2='".$INF_Address2[$i]."', City='".$INF_City[$i]."', States='".$INF_States[$i]."', Zip='".$INF_Zip[$i]."', SSN='".$INF_SSN[$i]."', Email='".$INF_Email[$i]."', 
                Phone='".$INF_phone[$i]."', InvoiceDate='".$INF_InvoiceDate[$i]."', DueDate='".$INF_DueDate[$i]."' WHERE username='".$username."' AND informationid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($INF_InformantName); $i ++) {
            $sql = "INSERT INTO statement_information (username, informationid, InformantName, AcceptedBy, Address1, Address2, City, States, Zip, SSN, Email, Phone, InvoiceDate, DueDate)

            VALUES ('".$username."', '".$i."', '".$INF_InformantName[$i]."', '".$INF_AcceptedBy[$i]."', '".$INF_Address1[$i]."', '".$INF_Address2[$i]."', '".$INF_City[$i]."', 
                '".$INF_States[$i]."', '".$INF_Zip[$i]."', '".$INF_SSN[$i]."', '".$INF_Email[$i]."', '".$INF_phone[$i]."', '".$INF_InvoiceDate[$i]."', '".$INF_DueDate[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($INF_InformantName); $i ++) {
            $sql = "INSERT INTO statement_information (username, informationid, InformantName, AcceptedBy, Address1, Address2, City, States, Zip, SSN, Email, Phone, InvoiceDate, DueDate)

            VALUES ('".$username."', '".$i."', '".$INF_InformantName[$i]."', '".$INF_AcceptedBy[$i]."', '".$INF_Address1[$i]."', '".$INF_Address2[$i]."', '".$INF_City[$i]."', 
                '".$INF_States[$i]."', '".$INF_Zip[$i]."', '".$INF_SSN[$i]."', '".$INF_Email[$i]."', '".$INF_phone[$i]."', '".$INF_InvoiceDate[$i]."', '".$INF_DueDate[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Professional Form///////////////////
    $PRO_Service = $_POST['PRO_Service'];
    $PRO_Price = $_POST['PRO_Price'];
    $PRO_Permanent = $_POST['PRO_Permanent'];
    
    $sql = "SELECT * FROM statement_professional WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE statement_professional SET Service='".$PRO_Service[$i]."', Price='".$PRO_Price[$i]."', Permanent='".$PRO_Permanent[$i]."'
            WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($PRO_Service); $i ++) {
            $sql = "INSERT INTO statement_professional (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$PRO_Service[$i]."', '".$PRO_Price[$i]."', '".$PRO_Permanent[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($PRO_Service); $i ++) {
            $sql = "INSERT INTO statement_professional (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$PRO_Service[$i]."', '".$PRO_Price[$i]."', '".$PRO_Permanent[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Facilities Form///////////////////
    $FAC_Service = $_POST['FAC_Service'];
    $FAC_Price = $_POST['FAC_Price'];
    $FAC_Permanent = $_POST['FAC_Permanent'];
    
    $sql = "SELECT * FROM statement_facilities WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE statement_facilities SET Service='".$FAC_Service[$i]."', Price='".$FAC_Price[$i]."', Permanent='".$FAC_Permanent[$i]."'
            WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($FAC_Service); $i ++) {
            $sql = "INSERT INTO statement_facilities (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$FAC_Service[$i]."', '".$FAC_Price[$i]."', '".$FAC_Permanent[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($FAC_Service); $i ++) {
            $sql = "INSERT INTO statement_facilities (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$FAC_Service[$i]."', '".$FAC_Price[$i]."', '".$FAC_Permanent[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Automotive Form///////////////////
    $AUT_Service = $_POST['AUT_Service'];
    $AUT_Price = $_POST['AUT_Price'];
    $AUT_Permanent = $_POST['AUT_Permanent'];
    
    $sql = "SELECT * FROM statement_automotive WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE statement_automotive SET Service='".$AUT_Service[$i]."', Price='".$AUT_Price[$i]."', Permanent='".$AUT_Permanent[$i]."'
            WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($AUT_Service); $i ++) {
            $sql = "INSERT INTO statement_automotive (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$AUT_Service[$i]."', '".$AUT_Price[$i]."', '".$AUT_Permanent[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($AUT_Service); $i ++) {
            $sql = "INSERT INTO statement_automotive (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$AUT_Service[$i]."', '".$AUT_Price[$i]."', '".$AUT_Permanent[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Charges Form///////////////////
    $CHA_Service = $_POST['CHA_Service'];
    $CHA_Price = $_POST['CHA_Price'];
    $CHA_Permanent = $_POST['CHA_Permanent'];
    
    $sql = "SELECT * FROM statement_charges WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE statement_charges SET Service='".$CHA_Service[$i]."', Price='".$CHA_Price[$i]."', Permanent='".$CHA_Permanent[$i]."'
            WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($CHA_Service); $i ++) {
            $sql = "INSERT INTO statement_charges (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$CHA_Service[$i]."', '".$CHA_Price[$i]."', '".$CHA_Permanent[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($CHA_Service); $i ++) {
            $sql = "INSERT INTO statement_charges (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$CHA_Service[$i]."', '".$CHA_Price[$i]."', '".$CHA_Permanent[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Charges Service Form///////////////////
    $CHS_Service = $_POST['CHS_Service'];
    $CHS_Price = $_POST['CHS_Price'];
    $CHS_Permanent = $_POST['CHS_Permanent'];
    
    $sql = "SELECT * FROM statement_charges_select WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE statement_charges_select SET Service='".$CHS_Service[$i]."', Price='".$CHS_Price[$i]."', Permanent='".$CHS_Permanent[$i]."'
            WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($CHS_Service); $i ++) {
            $sql = "INSERT INTO statement_charges_select (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$CHS_Service[$i]."', '".$CHS_Price[$i]."', '".$CHS_Permanent[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($CHS_Service); $i ++) {
            $sql = "INSERT INTO statement_charges_select (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$CHS_Service[$i]."', '".$CHS_Price[$i]."', '".$CHS_Permanent[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Total Special Charge Form///////////////////
    $TSC_Service = $_POST['TSC_Service'];
    $TSC_Price = $_POST['TSC_Price'];
    $TSC_Permanent = $_POST['TSC_Permanent'];
    
    $sql = "SELECT * FROM statement_totoal_special_charges WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE statement_totoal_special_charges SET Service='".$TSC_Service[$i]."', Price='".$TSC_Price[$i]."', Permanent='".$TSC_Permanent[$i]."'
            WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($TSC_Service); $i ++) {
            $sql = "INSERT INTO statement_totoal_special_charges (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$TSC_Service[$i]."', '".$TSC_Price[$i]."', '".$TSC_Permanent[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($TSC_Service); $i ++) {
            $sql = "INSERT INTO statement_totoal_special_charges (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$TSC_Service[$i]."', '".$TSC_Price[$i]."', '".$TSC_Permanent[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Cash Advance Charge Form///////////////////
    $CAS_Service = $_POST['CAS_Service'];
    $CAS_Price = $_POST['CAS_Price'];
    $CAS_Permanent = $_POST['CAS_Permanent'];
    
    $sql = "SELECT * FROM statement_cash_advance WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE statement_cash_advance SET Service='".$CAS_Service[$i]."', Price='".$CAS_Price[$i]."', Permanent='".$CAS_Permanent[$i]."'
            WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($CAS_Service); $i ++) {
            $sql = "INSERT INTO statement_cash_advance (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$CAS_Service[$i]."', '".$CAS_Price[$i]."', '".$CAS_Permanent[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($CAS_Service); $i ++) {
            $sql = "INSERT INTO statement_cash_advance (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$CAS_Service[$i]."', '".$CAS_Price[$i]."', '".$CAS_Permanent[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Summary of Charge Charge Form///////////////////
    $SUM_Service = $_POST['SUM_Service'];
    $SUM_Price = $_POST['SUM_Price'];
    $SUM_Permanent = $_POST['SUM_Permanent'];
    
    $sql = "SELECT * FROM statement_summary_charge WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE statement_summary_charge SET Service='".$SUM_Service[$i]."', Price='".$SUM_Price[$i]."', Permanent='".$SUM_Permanent[$i]."'
            WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($SUM_Service); $i ++) {
            $sql = "INSERT INTO statement_summary_charge (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$SUM_Service[$i]."', '".$SUM_Price[$i]."', '".$SUM_Permanent[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($SUM_Service); $i ++) {
            $sql = "INSERT INTO statement_summary_charge (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$SUM_Service[$i]."', '".$SUM_Price[$i]."', '".$SUM_Permanent[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Total amount Form///////////////////
    $AMO_Service = $_POST['AMO_Service'];
    $AMO_Price = $_POST['AMO_Price'];
    $AMO_Permanent = $_POST['AMO_Permanent'];
    
    $sql = "SELECT * FROM statement_total_amount_due WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE statement_total_amount_due SET Service='".$AMO_Service[$i]."', Price='".$AMO_Price[$i]."', Permanent='".$AMO_Permanent[$i]."'
            WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($AMO_Service); $i ++) {
            $sql = "INSERT INTO statement_total_amount_due (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$AMO_Service[$i]."', '".$AMO_Price[$i]."', '".$AMO_Permanent[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($AMO_Service); $i ++) {
            $sql = "INSERT INTO statement_total_amount_due (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$AMO_Service[$i]."', '".$AMO_Price[$i]."', '".$AMO_Permanent[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Reason Form///////////////////
    $REA_Service = $_POST['REA_Service'];
    $REA_Price = $_POST['REA_Price'];
    $REA_Permanent = $_POST['REA_Permanent'];
    
    $sql = "SELECT * FROM statement_reasons_for WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE statement_reasons_for SET Service='".$REA_Service[$i]."', Price='".$REA_Price[$i]."', Permanent='".$REA_Permanent[$i]."'
            WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($REA_Service); $i ++) {
            $sql = "INSERT INTO statement_reasons_for (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$REA_Service[$i]."', '".$REA_Price[$i]."', '".$REA_Permanent[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($REA_Service); $i ++) {
            $sql = "INSERT INTO statement_reasons_for (username, childid, Service, Price, Permanent)

            VALUES ('".$username."', '".$i."', '".$REA_Service[$i]."', '".$REA_Price[$i]."', '".$REA_Permanent[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Terms of Agreement Form///////////////////
    $TERM_Price1 = (isset($_POST['TERM_Price1']) ) ? trim($_POST['TERM_Price1']) : '';
    $TERM_Price2 = (isset($_POST['TERM_Price2']) ) ? trim($_POST['TERM_Price2']) : '';
    $TERM_Price3 = (isset($_POST['TERM_Price3']) ) ? trim($_POST['TERM_Price3']) : '';
    
    $sql = "SELECT * FROM statement_terms_of_agreement WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE statement_terms_of_agreement SET Price1='".$TERM_Price1."', Price2='".$TERM_Price2."', Price3='".$TERM_Price3."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO statement_terms_of_agreement (username, Price1, Price2, Price3)

        VALUES ('".$username."', '".$TERM_Price1."', '".$TERM_Price2."', '".$TERM_Price3."')";
    }
    $conn->query($sql);
    //////////////////////////////////////


    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>