<?php
     $sql = "SELECT * FROM dropdodwn_race";
     $result_dropdownrace = $conn->query($sql);
     $resultCount_race = mysqli_num_rows($result_dropdownrace);

     $sql = "SELECT * FROM dropdown_ancestry";
     $result_dropdownancestry = $conn->query($sql);
     $resultCount_ancestry = mysqli_num_rows($result_dropdownancestry);

     $sql = "SELECT * FROM dropdown_cemetery";
     $result_dropdowncemetery = $conn->query($sql);
     $resultCount_cemetery = mysqli_num_rows($result_dropdowncemetery);

     $sql = "SELECT * FROM dropdown_citizenship";
     $result_dropdowncitizenship = $conn->query($sql);
     $resultCount_citizenship = mysqli_num_rows($result_dropdowncitizenship);

     $sql = "SELECT * FROM dropdown_city";
     $result_dropdowncity = $conn->query($sql);
     $resultCount_city = mysqli_num_rows($result_dropdowncity);
     $result_dropdowncity_nok = $conn->query($sql);
     $resultCount_city_nok = mysqli_num_rows($result_dropdowncity_nok);
     $result_dropdowncity_church = $conn->query($sql);
     $resultCount_city_church = mysqli_num_rows($result_dropdowncity_church);

     $sql = "SELECT * FROM dropdown_college";
     $result_dropdowncollege = $conn->query($sql);
     $resultCount_college = mysqli_num_rows($result_dropdowncollege);

     $sql = "SELECT * FROM dropdown_county";
     $result_dropdowncounty = $conn->query($sql);
     $resultCount_county = mysqli_num_rows($result_dropdowncounty);

     $sql = "SELECT * FROM dropdown_funeralmemorial";
     $result_dropdownfuneralmemorial = $conn->query($sql);
     $resultCount_funeralmemorial = mysqli_num_rows($result_dropdownfuneralmemorial);

     $sql = "SELECT * FROM dropdown_highschool";
     $result_dropdownhighschool = $conn->query($sql);
     $resultCount_highschool = mysqli_num_rows($result_dropdownhighschool);

     $sql = "SELECT * FROM dropdown_undergraduatename";
     $result_dropdownundergraduatename = $conn->query($sql);
     $resultCount_undergraduatename = mysqli_num_rows($result_dropdownundergraduatename);

     $sql = "SELECT * FROM dropdown_graduatename";
     $result_dropdowngraduatename = $conn->query($sql);
     $resultCount_graduatename = mysqli_num_rows($result_dropdowngraduatename);

     $sql = "SELECT * FROM dropdown_honorific";
     $result_dropdownhonorific = $conn->query($sql);
     $resultCount = mysqli_num_rows($result_dropdownhonorific);
     $result_dropdownhonorific_del = $conn->query($sql);
     $resultCount_honorific_del = mysqli_num_rows($result_dropdownhonorific);

     $sql = "SELECT * FROM dropdown_lastname";
     $result_dropdownlastname = $conn->query($sql);
     $resultCount_lastname = mysqli_num_rows($result_dropdownlastname);

     $sql = "SELECT * FROM dropdown_militarybranch";
     $result_dropdownmilitarybranch = $conn->query($sql);
     $resultCount_militarybranch = mysqli_num_rows($result_dropdownmilitarybranch);

     $sql = "SELECT * FROM dropdown_militaryservicehonors";
     $result_dropdownmilitaryservicehonors = $conn->query($sql);
     $resultCount_militaryservicehonors = mysqli_num_rows($result_dropdownmilitaryservicehonors);

     $sql = "SELECT * FROM dropdown_occupation";
     $result_dropdownoccupation = $conn->query($sql);
     $resultCount_occupation = mysqli_num_rows($result_dropdownoccupation);

     $sql = "SELECT * FROM dropdown_rank";
     $result_dropdownrank = $conn->query($sql);
     $resultCount_rank = mysqli_num_rows($result_dropdownrank);

     $sql = "SELECT * FROM dropdown_relationship";
     $result_dropdownrelationship = $conn->query($sql);
     $resultCount_relationship = mysqli_num_rows($result_dropdownrelationship);
     $result_dropdownrelationship_nok = $conn->query($sql);
     $resultCount_relationship_nok = mysqli_num_rows($result_dropdownrelationship_nok);

     $sql = "SELECT * FROM dropdown_religion";
     $result_dropdownreligion = $conn->query($sql);
     $resultCount_religion = mysqli_num_rows($result_dropdownreligion);

     $sql = "SELECT * FROM dropdown_state";
     $result_dropdownstate = $conn->query($sql);
     $resultCount_state = mysqli_num_rows($result_dropdownstate);
     $result_dropdownstate_nok = $conn->query($sql);
     $resultCount_state_nok = mysqli_num_rows($result_dropdownstate_nok);

     $sql = "SELECT * FROM dropdown_suffix ;";
     $result_dropdownsuffix = $conn->query($sql);
     $resultCount_suffix = mysqli_num_rows($result_dropdownsuffix);

     $sql = "SELECT * FROM dropdown_township";
      $result_dropdowntownship = $conn->query($sql);
     $resultCount_township = mysqli_num_rows($result_dropdowntownship);

     $sql = "SELECT * FROM dropdown_typeofdischarge";
      $result_dropdowntypeofdischarge = $conn->query($sql);
     $resultCount_typeofdischarge = mysqli_num_rows($result_dropdowntypeofdischarge);

     $sql = "SELECT * FROM dropdown_warcampaign";
      $result_dropdownwarcampaign = $conn->query($sql);
     $resultCount_warcampaign = mysqli_num_rows($result_dropdownwarcampaign);

     $sql = "SELECT * FROM dropdown_zip";
      $result_dropdownzip = $conn->query($sql);
     $resultCount_zip = mysqli_num_rows($result_dropdownzip);
      $result_dropdownzip_nok = $conn->query($sql);
     $resultCount_zip_nok = mysqli_num_rows($result_dropdownzip_nok);

     $sql = "SELECT * FROM dropdown_reasonfor";
      $result_dropdownreasonfor = $conn->query($sql);
     $resultCount_reasonfor = mysqli_num_rows($result_dropdownreasonfor);
 
?>