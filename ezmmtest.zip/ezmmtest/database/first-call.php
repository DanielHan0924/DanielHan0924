<?php

    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];
    ///////////////////Personal Information Form///////////////////
    $PI_honorificID = (isset($_POST['PI_honorificID']) ) ? trim($_POST['PI_honorificID']) : '';
    $PI_firstname = (isset($_POST['PI_firstname']) ) ? trim($_POST['PI_firstname']) : '';
    $PI_middlename = (isset($_POST['PI_middlename']) ) ? trim($_POST['PI_middlename']) : '';
    $PI_lastname = (isset($_POST['PI_lastname']) ) ? trim($_POST['PI_lastname']) : '';
    $PI_suffix = (isset($_POST['PI_suffix']) ) ? trim($_POST['PI_suffix']) : '';
    $PI_address1 = (isset($_POST['PI_address1']) ) ? trim($_POST['PI_address1']) : '';
    $PI_address2 = (isset($_POST['PI_address2']) ) ? trim($_POST['PI_address2']) : '';
    $PI_township = (isset($_POST['PI_township']) ) ? trim($_POST['PI_township']) : '';
    $PI_city = (isset($_POST['PI_city']) ) ? trim($_POST['PI_city']) : '';
    $PI_states = (isset($_POST['PI_states']) ) ? trim($_POST['PI_states']) : '';
    $PI_zip = (isset($_POST['PI_zip']) ) ? trim($_POST['PI_zip']) : '';
    $PI_county = (isset($_POST['PI_county']) ) ? trim($_POST['PI_county']) : '';
    $PI_nickname = (isset($_POST['PI_nickname']) ) ? trim($_POST['PI_nickname']) : '';
    $PI_gender = (isset($_POST['PI_gender']) ) ? trim($_POST['PI_gender']) : '';
    $PI_ssn = (isset($_POST['PI_ssn']) ) ? trim($_POST['PI_ssn']) : '';
    $PI_email = (isset($_POST['PI_email']) ) ? trim($_POST['PI_email']) : '';
    $PI_phone = (isset($_POST['PI_phone']) ) ? trim($_POST['PI_phone']) : '';
    $PI_dod = (isset($_POST['PI_dod']) ) ? trim($_POST['PI_dod']) : '';
    $PI_tode = (isset($_POST['PI_tode']) ) ? trim($_POST['PI_tode']) : '';
    
    $sql = "SELECT * FROM first_call_pi WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE first_call_pi SET honorific='".$PI_honorificID."', firstName='".$PI_firstname."', middleName='".$PI_middlename."', lastName='".$PI_lastname."', 
            suffix='".$PI_suffix."', address1='".$PI_address1."', address2='".$PI_address2."', township='".$PI_township."', city='".$PI_city."', states='".$PI_states."', 
            zipCode='".$PI_zip."', country='".$PI_county."', nickName='".$PI_nickname."', gender='".$PI_gender."', SSN='".$PI_ssn."', email='".$PI_email."', 
            phone='".$PI_phone."', dateOfDeath='".$PI_dod."', timeOfDeath='".$PI_tode."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO first_call_pi (username, honorific, firstName, middleName, lastName, suffix, address1, address2, township, city, 
                                    states, zipCode, country, nickName, gender, SSN, email, phone, dateOfDeath, timeOfDeath)

        VALUES ('".$username."', '".$PI_honorificID."', '".$PI_firstname."', '".$PI_middlename."', '".$PI_lastname."', '".$PI_suffix."', '".$PI_address1."', '".$PI_address2."', 
                '".$PI_township."', '".$PI_city."', '".$PI_states."', '".$PI_zip."', '".$PI_county."', '".$PI_nickname."', '".$PI_gender."', '".$PI_ssn."', '".$PI_email."', 
                '".$PI_phone."', '".$PI_dod."', '".$PI_tode."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Personal Who Called Form///////////////////
    $PWC_WhoCalled = (isset($_POST['PWC_WhoCalled']) ) ? trim($_POST['PWC_WhoCalled']) : '';
    $PWC_Address1 = (isset($_POST['PWC_Address1']) ) ? trim($_POST['PWC_Address1']) : '';
    $PWC_Address2 = (isset($_POST['PWC_Address2']) ) ? trim($_POST['PWC_Address2']) : '';
    $PWC_City = (isset($_POST['PWC_City']) ) ? trim($_POST['PWC_City']) : '';
    $PWC_States = (isset($_POST['PWC_States']) ) ? trim($_POST['PWC_States']) : '';
    $PWC_Zip = (isset($_POST['PWC_Zip']) ) ? trim($_POST['PWC_Zip']) : '';
    $PWC_Email = (isset($_POST['PWC_Email']) ) ? trim($_POST['PWC_Email']) : '';
    $PWC_dayphone = (isset($_POST['PWC_dayphone']) ) ? trim($_POST['PWC_dayphone']) : '';
    $PWC_eveningphone = (isset($_POST['PWC_eveningphone']) ) ? trim($_POST['PWC_eveningphone']) : '';
    
    $sql = "SELECT * FROM first_call_person_call WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE first_call_person_call SET WhoCalled='".$PWC_WhoCalled."', Address1='".$PWC_Address1."', Address2='".$PWC_Address2."', City='".$PWC_City."', 
            States='".$PWC_States."', Zip='".$PWC_Zip."', Email='".$PWC_Email."', dayphone='".$PWC_dayphone."', eveningphone='".$PWC_eveningphone."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO first_call_person_call (username, WhoCalled, Address1, Address2, City, States, Zip, Email, dayphone, eveningphone)

        VALUES ('".$username."', '".$PWC_WhoCalled."', '".$PWC_Address1."', '".$PWC_Address2."', '".$PWC_City."', '".$PWC_States."', '".$PWC_Zip."', '".$PWC_Email."', 
                '".$PWC_dayphone."', '".$PWC_eveningphone."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Place Of Death Form///////////////////
    $POD_Physician = (isset($_POST['POD_Physician']) ) ? trim($_POST['POD_Physician']) : '';
    $POD_ContactName = (isset($_POST['POD_ContactName']) ) ? trim($_POST['POD_ContactName']) : '';
    $POD_Address1 = (isset($_POST['POD_Address1']) ) ? trim($_POST['POD_Address1']) : '';
    $POD_Address2 = (isset($_POST['POD_Address2']) ) ? trim($_POST['POD_Address2']) : '';
    $POD_City = (isset($_POST['POD_City']) ) ? trim($_POST['POD_City']) : '';
    $POD_States = (isset($_POST['POD_States']) ) ? trim($_POST['POD_States']) : '';
    $POD_Zip = (isset($_POST['POD_Zip']) ) ? trim($_POST['POD_Zip']) : '';
    $POD_Email = (isset($_POST['POD_Email']) ) ? trim($_POST['POD_Email']) : '';
    $POD_officephone = (isset($_POST['POD_officephone']) ) ? trim($_POST['POD_officephone']) : '';
    
    $sql = "SELECT * FROM first_call_place_of_death WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE first_call_place_of_death SET Physician='".$POD_Physician."', ContactName='".$POD_ContactName."', Address1='".$POD_Address1."', Address2='".$POD_Address2."', 
            City='".$POD_City."', States='".$POD_States."', Zip='".$POD_Zip."', Email='".$POD_Email."', officephone='".$POD_officephone."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO first_call_place_of_death (username, Physician, ContactName, Address1, Address2, City, States, Zip, Email, officephone)

        VALUES ('".$username."', '".$POD_Physician."', '".$POD_ContactName."', '".$POD_Address1."', '".$POD_Address2."', '".$POD_City."', '".$POD_States."', '".$POD_Zip."', '".$POD_Email."', 
                '".$POD_officephone."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Location Of the Body Form///////////////////
    $LOC_LocationOfTheBody = (isset($_POST['LOC_LocationOfTheBody']) ) ? trim($_POST['LOC_LocationOfTheBody']) : '';
    $LOC_ContactName = (isset($_POST['LOC_ContactName']) ) ? trim($_POST['LOC_ContactName']) : '';
    $LOC_Address1 = (isset($_POST['LOC_Address1']) ) ? trim($_POST['LOC_Address1']) : '';
    $LOC_Address2 = (isset($_POST['LOC_Address2']) ) ? trim($_POST['LOC_Address2']) : '';
    $LOC_City = (isset($_POST['LOC_City']) ) ? trim($_POST['LOC_City']) : '';
    $LOC_States = (isset($_POST['LOC_States']) ) ? trim($_POST['LOC_States']) : '';
    $LOC_Zip = (isset($_POST['LOC_Zip']) ) ? trim($_POST['LOC_Zip']) : '';
    $LOC_Email = (isset($_POST['LOC_Email']) ) ? trim($_POST['LOC_Email']) : '';
    $LOC_phone = (isset($_POST['LOC_phone']) ) ? trim($_POST['LOC_phone']) : '';
    $LOC_dod = (isset($_POST['LOC_dod']) ) ? trim($_POST['LOC_dod']) : '';
    $LOC_tode = (isset($_POST['LOC_tode']) ) ? trim($_POST['LOC_tode']) : '';
    
    $sql = "SELECT * FROM first_call_location WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE first_call_location SET LocationOfTheBody='".$LOC_LocationOfTheBody."', ContactName='".$LOC_ContactName."', Address1='".$LOC_Address1."', Address2='".$LOC_Address2."', 
            City='".$LOC_City."', States='".$LOC_States."', Zip='".$LOC_Zip."', Email='".$LOC_Email."', phone='".$LOC_phone."', dod='".$LOC_dod."', 
            tode='".$LOC_tode."'  WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO first_call_location (username, LocationOfTheBody, ContactName, Address1, Address2, City, States, Zip, Email, phone, dod, tode)

        VALUES ('".$username."', '".$LOC_LocationOfTheBody."', '".$LOC_ContactName."', '".$LOC_Address1."', '".$LOC_Address2."', '".$LOC_City."', '".$LOC_States."', 
                '".$LOC_Zip."', '".$LOC_Email."', '".$LOC_phone."', '".$LOC_dod."', '".$LOC_tode."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Physician Form///////////////////
    $PHY_Physician = (isset($_POST['PHY_Physician']) ) ? trim($_POST['PHY_Physician']) : '';
    $PHY_ContactName = (isset($_POST['PHY_ContactName']) ) ? trim($_POST['PHY_ContactName']) : '';
    $PHY_Address1 = (isset($_POST['PHY_Address1']) ) ? trim($_POST['PHY_Address1']) : '';
    $PHY_Address2 = (isset($_POST['PHY_Address2']) ) ? trim($_POST['PHY_Address2']) : '';
    $PHY_City = (isset($_POST['PHY_City']) ) ? trim($_POST['PHY_City']) : '';
    $PHY_States = (isset($_POST['PHY_States']) ) ? trim($_POST['PHY_States']) : '';
    $PHY_Zip = (isset($_POST['PHY_Zip']) ) ? trim($_POST['PHY_Zip']) : '';
    $PHY_Email = (isset($_POST['PHY_Email']) ) ? trim($_POST['PHY_Email']) : '';
    $PHY_officephone = (isset($_POST['PHY_officephone']) ) ? trim($_POST['PHY_officephone']) : '';
    $PHY_cellphone = (isset($_POST['PHY_cellphone']) ) ? trim($_POST['PHY_cellphone']) : '';
    $PHY_pager = (isset($_POST['PHY_pager']) ) ? trim($_POST['PHY_pager']) : '';
    
    $sql = "SELECT * FROM first_call_physician WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE first_call_physician SET Physician='".$PHY_Physician."', ContactName='".$PHY_ContactName."', Address1='".$PHY_Address1."', Address2='".$PHY_Address2."', 
            City='".$PHY_City."', States='".$PHY_States."', Zip='".$PHY_Zip."', Email='".$PHY_Email."', officephone='".$PHY_officephone."', cellphone='".$PHY_cellphone."', 
            pager='".$PHY_pager."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO first_call_physician (username, Physician, ContactName, Address1, Address2, City, States, Zip, Email, officephone, cellphone, pager)

        VALUES ('".$username."', '".$PHY_Physician."', '".$PHY_ContactName."', '".$PHY_Address1."', '".$PHY_Address2."', '".$PHY_City."', '".$PHY_States."', '".$PHY_Zip."', 
                '".$PHY_Email."', '".$PHY_officephone."', '".$PHY_cellphone."', '".$PHY_pager."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Permission Form///////////////////
    $pickup = (isset($_POST['pickup']) ) ? trim($_POST['pickup']) : '';
    $embalm = (isset($_POST['embalm']) ) ? trim($_POST['embalm']) : '';
    
    
    $sql = "SELECT * FROM first_call_permission WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE first_call_permission SET pickup='".$pickup."', embalm='".$embalm."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO first_call_permission (username, pickup, embalm)

        VALUES ('".$username."', '".$pickup."', '".$embalm."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>