<?php

    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];
    ///////////////////Surviving Relatives Form///////////////////
    $Name = $_POST['Name'];
    $Address1 = $_POST['Address1'];
    $City = $_POST['City'];
    $State = $_POST['State'];
    $Zip = $_POST['Zip'];
    $Phone = $_POST['Phone'];
    $Email = $_POST['Email'];
    $Relationship = $_POST['Relationship'];
    
    $sql = "SELECT * FROM surviving_relatives WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE surviving_relatives SET Name='".$Name[$i]."', Address1='".$Address1[$i]."', City='".$City[$i]."', State='".$State[$i]."', Zip='".$Zip[$i]."', 
            Phone='".$Phone[$i]."', Email='".$Email[$i]."', Relationship='".$Relationship[$i]."' WHERE username='".$username."' AND survivingid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($Name); $i ++) {
            $sql = "INSERT INTO surviving_relatives (username, survivingid, Name, Address1, City, State, Zip, Phone, Email, Relationship)

            VALUES ('".$username."', '".$i."', '".$Name[$i]."', '".$Address1[$i]."', '".$City[$i]."', '".$State[$i]."', '".$Zip[$i]."', 
                '".$Phone[$i]."', '".$Email[$i]."', '".$Relationship[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($Name); $i ++) {
            $sql = "INSERT INTO surviving_relatives (username, survivingid, Name, Address1, City, State, Zip, Phone, Email, Relationship)

            VALUES ('".$username."', '".$i."', '".$Name[$i]."', '".$Address1[$i]."', '".$City[$i]."', '".$State[$i]."', '".$Zip[$i]."', 
                '".$Phone[$i]."', '".$Email[$i]."', '".$Relationship[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>