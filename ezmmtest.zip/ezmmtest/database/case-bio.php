<?php

    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];
    ///////////////////Deceased Information Form///////////////////
    $DES_FullName = (isset($_POST['DES_FullName']) ) ? trim($_POST['DES_FullName']) : '';
    $DES_DOB = (isset($_POST['DES_DOB']) ) ? trim($_POST['DES_DOB']) : '';
    $DES_Citizenship = (isset($_POST['DES_Citizenship']) ) ? trim($_POST['DES_Citizenship']) : '';
    $DES_Race = (isset($_POST['DES_Race']) ) ? trim($_POST['DES_Race']) : '';
    $DES_Religion = (isset($_POST['DES_Religion']) ) ? trim($_POST['DES_Religion']) : '';
    $DES_PlaceOfBirth = (isset($_POST['DES_PlaceOfBirth']) ) ? trim($_POST['DES_PlaceOfBirth']) : '';
    $DES_Ancestry = (isset($_POST['DES_Ancestry']) ) ? trim($_POST['DES_Ancestry']) : '';
    $DES_Business = (isset($_POST['DES_Business']) ) ? trim($_POST['DES_Business']) : '';
    $DES_States = (isset($_POST['DES_States']) ) ? trim($_POST['DES_States']) : '';
    $DES_InCommunitySInce = (isset($_POST['DES_InCommunitySInce']) ) ? trim($_POST['DES_InCommunitySInce']) : '';
    $DES_MovedFrom = (isset($_POST['DES_MovedFrom']) ) ? trim($_POST['DES_MovedFrom']) : '';
    
    $sql = "SELECT * FROM case_bio_deceased_info WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE case_bio_deceased_info SET FullName='".$DES_FullName."', DOB='".$DES_DOB."', Citizenship='".$DES_Citizenship."', Race='".$DES_Race."', 
            Religion='".$DES_Religion."', PlaceOfBirth='".$DES_PlaceOfBirth."', Ancestry='".$DES_Ancestry."', Business='".$DES_Business."', States='".$DES_States."', 
            InCommunitySInce='".$DES_InCommunitySInce."', MovedFrom='".$DES_MovedFrom."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO case_bio_deceased_info (username, FullName, DOB, Citizenship, Race, Religion, PlaceOfBirth, Ancestry, Business, States, 
                                    InCommunitySInce, MovedFrom)

        VALUES ('".$username."', '".$DES_FullName."', '".$DES_DOB."', '".$DES_Citizenship."', '".$DES_Race."', '".$DES_Religion."', '".$DES_PlaceOfBirth."', '".$DES_Ancestry."', 
                '".$DES_Business."', '".$DES_States."', '".$DES_InCommunitySInce."', '".$DES_MovedFrom."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Parents Form///////////////////
    $PAT_FathersName = (isset($_POST['PAT_FathersName']) ) ? trim($_POST['PAT_FathersName']) : '';
    $PAT_FDOB = (isset($_POST['PAT_FDOB']) ) ? trim($_POST['PAT_FDOB']) : '';
    $PAT_FPlaceOfBirth = (isset($_POST['PAT_FPlaceOfBirth']) ) ? trim($_POST['PAT_FPlaceOfBirth']) : '';
    $PAT_MothersName = (isset($_POST['PAT_MothersName']) ) ? trim($_POST['PAT_MothersName']) : '';
    $PAT_MothersMaidenName = (isset($_POST['PAT_MothersMaidenName']) ) ? trim($_POST['PAT_MothersMaidenName']) : '';
    $PAT_MDOB = (isset($_POST['PAT_MDOB']) ) ? trim($_POST['PAT_MDOB']) : '';
    $PAT_MPlaceOfBirth = (isset($_POST['PAT_MPlaceOfBirth']) ) ? trim($_POST['PAT_MPlaceOfBirth']) : '';
    $DES_Business = (isset($_POST['DES_Business']) ) ? trim($_POST['DES_Business']) : '';
    $DES_States = (isset($_POST['DES_States']) ) ? trim($_POST['DES_States']) : '';
    $DES_InCommunitySInce = (isset($_POST['DES_InCommunitySInce']) ) ? trim($_POST['DES_InCommunitySInce']) : '';
    $DES_MovedFrom = (isset($_POST['DES_MovedFrom']) ) ? trim($_POST['DES_MovedFrom']) : '';
    
    $sql = "SELECT * FROM case_bio_parents WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE case_bio_parents SET FathersName='".$PAT_FathersName."', FDOB='".$PAT_FDOB."', FPlaceOfBirth='".$PAT_FPlaceOfBirth."', MothersName='".$PAT_MothersName."', 
            MothersMaidenName='".$PAT_MothersMaidenName."', MDOB='".$PAT_MDOB."', MPlaceOfBirth='".$PAT_MPlaceOfBirth."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO case_bio_parents (username, FathersName, FDOB, FPlaceOfBirth, MothersName, MothersMaidenName, MDOB, MPlaceOfBirth)

        VALUES ('".$username."', '".$PAT_FathersName."', '".$PAT_FDOB."', '".$PAT_FPlaceOfBirth."', '".$PAT_MothersName."', '".$PAT_MothersMaidenName."', '".$PAT_MDOB."', 
                '".$PAT_MPlaceOfBirth."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Children Form///////////////////
    $CLD_FullName = $_POST['CLD_FullName'];
    $CLD_Address1 = $_POST['CLD_Address1'];
    $CLD_Address2 = $_POST['CLD_Address2'];
    $CLD_City = $_POST['CLD_City'];
    $CLD_States = $_POST['CLD_States'];
    $CLD_Zip = $_POST['CLD_Zip'];
    $CLD_DOB = $_POST['CLD_DOB'];
    $CLD_Relationship = $_POST['CLD_Relationship'];
    $CLD_Email = $_POST['CLD_Email'];
    $CLD_phone = $_POST['CLD_phone'];
    $CLD_phone2 = $_POST['CLD_phone2'];
    
    $sql = "SELECT * FROM case_bio_children WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE case_bio_children SET childrenid='".$i."', fullname='".$CLD_FullName[$i]."', address1='".$CLD_Address1[$i]."', address2='".$CLD_Address2[$i]."', 
                city='".$CLD_City[$i]."', states='".$CLD_States[$i]."', zip='".$CLD_Zip[$i]."', dob='".$CLD_DOB[$i]."', relationship='".$CLD_Relationship[$i]."', email='".$CLD_Email[$i]."', 
                phone='".$CLD_phone[$i]."', phone2='".$CLD_phone2[$i]."' WHERE username='".$username."' AND childrenid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($CLD_FullName); $i ++) {
            $sql = "INSERT INTO case_bio_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$CLD_FullName[$i]."', '".$CLD_Address1[$i]."', '".$CLD_Address2[$i]."', '".$CLD_City[$i]."', '".$CLD_States[$i]."', 
                '".$CLD_Zip[$i]."', '".$CLD_DOB[$i]."', '".$CLD_Relationship[$i]."', '".$CLD_Email[$i]."', '".$CLD_phone[$i]."', '".$CLD_phone2[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($CLD_FullName); $i ++) {
            $sql = "INSERT INTO case_bio_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$CLD_FullName[$i]."', '".$CLD_Address1[$i]."', '".$CLD_Address2[$i]."', '".$CLD_City[$i]."', '".$CLD_States[$i]."', 
                '".$CLD_Zip[$i]."', '".$CLD_DOB[$i]."', '".$CLD_Relationship[$i]."', '".$CLD_Email[$i]."', '".$CLD_phone[$i]."', '".$CLD_phone2[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Grand Children Form///////////////////
    $GCLD_FullName = $_POST['GCLD_FullName'];
    $GCLD_Address1 = $_POST['GCLD_Address1'];
    $GCLD_Address2 = $_POST['GCLD_Address2'];
    $GCLD_City = $_POST['GCLD_City'];
    $GCLD_States = $_POST['GCLD_States'];
    $GCLD_Zip = $_POST['GCLD_Zip'];
    $GCLD_DOB = $_POST['GCLD_DOB'];
    $GCLD_Relationship = $_POST['GCLD_Relationship'];
    $GCLD_Email = $_POST['GCLD_Email'];
    $GCLD_phone = $_POST['GCLD_phone'];
    $GCLD_phone2 = $_POST['GCLD_phone2'];
    
    $sql = "SELECT * FROM case_bio_grand_children WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE case_bio_grand_children SET fullname='".$GCLD_FullName[$i]."', address1='".$GCLD_Address1[$i]."', address2='".$GCLD_Address2[$i]."', 
                city='".$GCLD_City[$i]."', states='".$GCLD_States[$i]."', zip='".$GCLD_Zip[$i]."', dob='".$GCLD_DOB[$i]."', relationship='".$GCLD_Relationship[$i]."', email='".$GCLD_Email[$i]."', 
                phone='".$GCLD_phone[$i]."', phone2='".$GCLD_phone2[$i]."' WHERE username='".$username."' AND childrenid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($GCLD_FullName); $i ++) {
            $sql = "INSERT INTO case_bio_grand_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$GCLD_FullName[$i]."', '".$GCLD_Address1[$i]."', '".$GCLD_Address2[$i]."', '".$GCLD_City[$i]."', '".$GCLD_States[$i]."', 
                '".$GCLD_Zip[$i]."', '".$GCLD_DOB[$i]."', '".$GCLD_Relationship[$i]."', '".$GCLD_Email[$i]."', '".$GCLD_phone[$i]."', '".$GCLD_phone2[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($GCLD_FullName); $i ++) {
            $sql = "INSERT INTO case_bio_grand_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$GCLD_FullName[$i]."', '".$GCLD_Address1[$i]."', '".$GCLD_Address2[$i]."', '".$GCLD_City[$i]."', '".$GCLD_States[$i]."', 
                '".$GCLD_Zip[$i]."', '".$GCLD_DOB[$i]."', '".$GCLD_Relationship[$i]."', '".$GCLD_Email[$i]."', '".$GCLD_phone[$i]."', '".$GCLD_phone2[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Great Grand Children Form///////////////////
    $GGCLD_FullName = $_POST['GGCLD_FullName'];
    $GGCLD_Address1 = $_POST['GGCLD_Address1'];
    $GGCLD_Address2 = $_POST['GGCLD_Address2'];
    $GGCLD_City = $_POST['GGCLD_City'];
    $GGCLD_States = $_POST['GGCLD_States'];
    $GGCLD_Zip = $_POST['GGCLD_Zip'];
    $GGCLD_DOB = $_POST['GGCLD_DOB'];
    $GGCLD_Relationship = $_POST['GGCLD_Relationship'];
    $GGCLD_Email = $_POST['GGCLD_Email'];
    $GGCLD_phone = $_POST['GGCLD_phone'];
    $GGCLD_phone2 = $_POST['GGCLD_phone2'];
    
    $sql = "SELECT * FROM case_bio_great_grand_children WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE case_bio_great_grand_children SET fullname='".$GGCLD_FullName[$i]."', address1='".$GGCLD_Address1[$i]."', address2='".$GGCLD_Address2[$i]."', 
                city='".$GGCLD_City[$i]."', states='".$GGCLD_States[$i]."', zip='".$GGCLD_Zip[$i]."', dob='".$GGCLD_DOB[$i]."', relationship='".$GGCLD_Relationship[$i]."', email='".$GGCLD_Email[$i]."', 
                phone='".$GGCLD_phone[$i]."', phone2='".$GGCLD_phone2[$i]."' WHERE username='".$username."' AND childrenid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($GGCLD_FullName); $i ++) {
            $sql = "INSERT INTO case_bio_great_grand_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$GGCLD_FullName[$i]."', '".$GGCLD_Address1[$i]."', '".$GGCLD_Address2[$i]."', '".$GGCLD_City[$i]."', '".$GGCLD_States[$i]."', 
                '".$GGCLD_Zip[$i]."', '".$GGCLD_DOB[$i]."', '".$GGCLD_Relationship[$i]."', '".$GGCLD_Email[$i]."', '".$GGCLD_phone[$i]."', '".$GGCLD_phone2[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($GGCLD_FullName); $i ++) {
            $sql = "INSERT INTO case_bio_great_grand_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$GGCLD_FullName[$i]."', '".$GGCLD_Address1[$i]."', '".$GGCLD_Address2[$i]."', '".$GGCLD_City[$i]."', '".$GGCLD_States[$i]."', 
                '".$GGCLD_Zip[$i]."', '".$GGCLD_DOB[$i]."', '".$GGCLD_Relationship[$i]."', '".$GGCLD_Email[$i]."', '".$GGCLD_phone[$i]."', '".$GGCLD_phone2[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Great Great Grand Children Form///////////////////
    $GGGCLD_FullName = $_POST['GGGCLD_FullName'];
    $GGGCLD_Address1 = $_POST['GGGCLD_Address1'];
    $GGGCLD_Address2 = $_POST['GGGCLD_Address2'];
    $GGGCLD_City = $_POST['GGGCLD_City'];
    $GGGCLD_States = $_POST['GGGCLD_States'];
    $GGGCLD_Zip = $_POST['GGGCLD_Zip'];
    $GGGCLD_DOB = $_POST['GGGCLD_DOB'];
    $GGGCLD_Relationship = $_POST['GGGCLD_Relationship'];
    $GGGCLD_Email = $_POST['GGGCLD_Email'];
    $GGGCLD_phone = $_POST['GGGCLD_phone'];
    $GGGCLD_phone2 = $_POST['GGGCLD_phone2'];
    
    $sql = "SELECT * FROM case_bio_great_great_grand_children WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE case_bio_great_great_grand_children SET fullname='".$GGGCLD_FullName[$i]."', address1='".$GGGCLD_Address1[$i]."', address2='".$GGGCLD_Address2[$i]."', 
                city='".$GGGCLD_City[$i]."', states='".$GGGCLD_States[$i]."', zip='".$GGGCLD_Zip[$i]."', dob='".$GGGCLD_DOB[$i]."', relationship='".$GGGCLD_Relationship[$i]."', email='".$GGGCLD_Email[$i]."', 
                phone='".$GGGCLD_phone[$i]."', phone2='".$GGGCLD_phone2[$i]."' WHERE username='".$username."' AND childrenid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($GGGCLD_FullName); $i ++) {
            $sql = "INSERT INTO case_bio_great_great_grand_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$GGGCLD_FullName[$i]."', '".$GGGCLD_Address1[$i]."', '".$GGGCLD_Address2[$i]."', '".$GGGCLD_City[$i]."', '".$GGGCLD_States[$i]."', 
                '".$GGGCLD_Zip[$i]."', '".$GGGCLD_DOB[$i]."', '".$GGGCLD_Relationship[$i]."', '".$GGGCLD_Email[$i]."', '".$GGGCLD_phone[$i]."', '".$GGGCLD_phone2[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($GGGCLD_FullName); $i ++) {
            $sql = "INSERT INTO case_bio_great_great_grand_children (username, childrenid, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2)

            VALUES ('".$username."', '".$i."', '".$GGGCLD_FullName[$i]."', '".$GGGCLD_Address1[$i]."', '".$GGGCLD_Address2[$i]."', '".$GGGCLD_City[$i]."', '".$GGGCLD_States[$i]."', 
                '".$GGGCLD_Zip[$i]."', '".$GGGCLD_DOB[$i]."', '".$GGGCLD_Relationship[$i]."', '".$GGGCLD_Email[$i]."', '".$GGGCLD_phone[$i]."', '".$GGGCLD_phone2[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    ///////////////////Marital Status Form///////////////////
    $MS_MaritalStatus = (isset($_POST['MS_MaritalStatus']) ) ? trim($_POST['MS_MaritalStatus']) : '';
    $MS_PlaceOfMarriage = (isset($_POST['MS_PlaceOfMarriage']) ) ? trim($_POST['MS_PlaceOfMarriage']) : '';
    $MS_DateOfMarriage = (isset($_POST['MS_DateOfMarriage']) ) ? trim($_POST['MS_DateOfMarriage']) : '';
    $MS_SpousesName = (isset($_POST['MS_SpousesName']) ) ? trim($_POST['MS_SpousesName']) : '';
    $MS_SpouseDeceased = (isset($_POST['MS_SpouseDeceased']) ) ? trim($_POST['MS_SpouseDeceased']) : '';
    $MS_SDateOfDeath = (isset($_POST['MS_SDateOfDeath']) ) ? trim($_POST['MS_SDateOfDeath']) : '';
    $MS_SpousesPlaceOfDeath = (isset($_POST['MS_SpousesPlaceOfDeath']) ) ? trim($_POST['MS_SpousesPlaceOfDeath']) : '';
    
    $sql = "SELECT * FROM case_bio_marital WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE case_bio_marital SET maritalstatus='".$MS_MaritalStatus."', placeofmarriage='".$MS_PlaceOfMarriage."', dateofmarriage='".$MS_DateOfMarriage."', 
            spousesname='".$MS_SpousesName."', Spousedeceased='".$MS_SpouseDeceased."', sdateofdeath='".$MS_SDateOfDeath."', spousesplaceofdeath='".$MS_SpousesPlaceOfDeath."' 
            WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO case_bio_marital (username, maritalstatus, placeofmarriage, dateofmarriage, spousesname, Spousedeceased, sdateofdeath, spousesplaceofdeath)

        VALUES ('".$username."', '".$MS_MaritalStatus."', '".$MS_PlaceOfMarriage."', '".$MS_DateOfMarriage."', '".$MS_SpousesName."', '".$MS_SpouseDeceased."', 
                '".$MS_SDateOfDeath."', '".$MS_SpousesPlaceOfDeath."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Military Service Form///////////////////
    $MLT_BranchID = (isset($_POST['MLT_BranchID']) ) ? trim($_POST['MLT_BranchID']) : '';
    $MLT_WarCampaignID = (isset($_POST['MLT_WarCampaignID']) ) ? trim($_POST['MLT_WarCampaignID']) : '';
    $MLT_SerialNumber = (isset($_POST['MLT_SerialNumber']) ) ? trim($_POST['MLT_SerialNumber']) : '';
    $MLT_Rank = (isset($_POST['MLT_Rank']) ) ? trim($_POST['MLT_Rank']) : '';
    $MLT_EnlistmentDate = (isset($_POST['MLT_EnlistmentDate']) ) ? trim($_POST['MLT_EnlistmentDate']) : '';
    $MLT_DischargeDate = (isset($_POST['MLT_DischargeDate']) ) ? trim($_POST['MLT_DischargeDate']) : '';
    $MLT_TypeOfDischargeID = (isset($_POST['MLT_TypeOfDischargeID']) ) ? trim($_POST['MLT_TypeOfDischargeID']) : '';
    $MLT_DD214 = (isset($_POST['MLT_DD214']) ) ? trim($_POST['MLT_DD214']) : '';
    $MLT_Headstone = (isset($_POST['MLT_Headstone']) ) ? trim($_POST['MLT_Headstone']) : '';
    $MLT_ApplicationForBurial = (isset($_POST['MLT_ApplicationForBurial']) ) ? trim($_POST['MLT_ApplicationForBurial']) : '';
    $MLT_ApplicationForFlag = (isset($_POST['MLT_ApplicationForFlag']) ) ? trim($_POST['MLT_ApplicationForFlag']) : '';
    $MLT_HonorGuard = (isset($_POST['MLT_HonorGuard']) ) ? trim($_POST['MLT_HonorGuard']) : '';
    
    $sql = "SELECT * FROM case_bio_military_service WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE case_bio_military_service SET BranchID='".$MLT_BranchID."', WarCampaignID='".$MLT_WarCampaignID."', SerialNumber='".$MLT_SerialNumber."', 
            Rank='".$MLT_Rank."', EnlistmentDate='".$MLT_EnlistmentDate."', DischargeDate='".$MLT_DischargeDate."', TypeOfDischargeID='".$MLT_TypeOfDischargeID."', 
            DD214='".$MLT_DD214."', Headstone='".$MLT_Headstone."', ApplicationForBurial='".$MLT_ApplicationForBurial."', ApplicationForFlag='".$MLT_ApplicationForFlag."', 
            HonorGuard='".$MLT_HonorGuard."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO case_bio_military_service (username, BranchID, WarCampaignID, SerialNumber, Rank, EnlistmentDate, DischargeDate, TypeOfDischargeID, DD214, 
                Headstone, ApplicationForBurial, ApplicationForFlag, HonorGuard)

        VALUES ('".$username."', '".$MLT_BranchID."', '".$MLT_WarCampaignID."', '".$MLT_SerialNumber."', '".$MLT_Rank."', '".$MLT_EnlistmentDate."', 
                '".$MLT_DischargeDate."', '".$MLT_TypeOfDischargeID."', '".$MLT_DD214."', '".$MLT_Headstone."', '".$MLT_ApplicationForBurial."', 
                '".$MLT_ApplicationForFlag."', '".$MLT_HonorGuard."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Church Form///////////////////
    $CHU_Church = (isset($_POST['CHU_Church']) ) ? trim($_POST['CHU_Church']) : '';
    $CHU_ClergyName = (isset($_POST['CHU_ClergyName']) ) ? trim($_POST['CHU_ClergyName']) : '';
    $CHU_Address1 = (isset($_POST['CHU_Address1']) ) ? trim($_POST['CHU_Address1']) : '';
    $CHU_Address2 = (isset($_POST['CHU_Address2']) ) ? trim($_POST['CHU_Address2']) : '';
    $CHU_City = (isset($_POST['CHU_City']) ) ? trim($_POST['CHU_City']) : '';
    $CHU_States = (isset($_POST['CHU_States']) ) ? trim($_POST['CHU_States']) : '';
    $CHU_Zip = (isset($_POST['CHU_Zip']) ) ? trim($_POST['CHU_Zip']) : '';
    $CHU_Email = (isset($_POST['CHU_Email']) ) ? trim($_POST['CHU_Email']) : '';
    $CHU_phone = (isset($_POST['CHU_phone']) ) ? trim($_POST['CHU_phone']) : '';
    $CHU_phone2 = (isset($_POST['CHU_phone2']) ) ? trim($_POST['CHU_phone2']) : '';
    
    $sql = "SELECT * FROM case_bio_church WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE case_bio_church SET Church='".$CHU_Church."', ClergyName='".$CHU_ClergyName."', Address1='".$CHU_Address1."', 
            Address2='".$CHU_Address2."', City='".$CHU_City."', States='".$CHU_States."', Zip='".$CHU_Zip."', 
            Email='".$CHU_Email."', phone='".$CHU_phone."', phone2='".$CHU_phone2."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO case_bio_church (username, Church, ClergyName, Address1, Address2, City, States, Zip, Email, phone, phone2)

        VALUES ('".$username."', '".$CHU_Church."', '".$CHU_ClergyName."', '".$CHU_Address1."', '".$CHU_Address2."', '".$CHU_City."', 
                '".$CHU_States."', '".$CHU_Zip."', '".$CHU_Email."', '".$CHU_phone."', '".$CHU_phone2."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Place of worship Form///////////////////
    $POW_PlaceOfWorship = (isset($_POST['POW_PlaceOfWorship']) ) ? trim($_POST['POW_PlaceOfWorship']) : '';
    $POW_ClergyName = (isset($_POST['POW_ClergyName']) ) ? trim($_POST['POW_ClergyName']) : '';
    $POW_Address1 = (isset($_POST['POW_Address1']) ) ? trim($_POST['POW_Address1']) : '';
    $POW_Address2 = (isset($_POST['POW_Address2']) ) ? trim($_POST['POW_Address2']) : '';
    $POW_City = (isset($_POST['POW_City']) ) ? trim($_POST['POW_City']) : '';
    $POW_States = (isset($_POST['POW_States']) ) ? trim($_POST['POW_States']) : '';
    $POW_Zip = (isset($_POST['POW_Zip']) ) ? trim($_POST['POW_Zip']) : '';
    $POW_Email = (isset($_POST['POW_Email']) ) ? trim($_POST['POW_Email']) : '';
    $POW_phone = (isset($_POST['POW_phone']) ) ? trim($_POST['POW_phone']) : '';
    $POW_phone2 = (isset($_POST['POW_phone2']) ) ? trim($_POST['POW_phone2']) : '';
    
    $sql = "SELECT * FROM case_bio_place_of_worship WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE case_bio_place_of_worship SET PlaceOfWorship='".$POW_PlaceOfWorship."', ClergyName='".$POW_ClergyName."', Address1='".$POW_Address1."', 
            Address2='".$POW_Address2."', City='".$POW_City."', States='".$POW_States."', Zip='".$POW_Zip."', 
            Email='".$POW_Email."', phone='".$POW_phone."', phone2='".$POW_phone2."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO case_bio_place_of_worship (username, PlaceOfWorship, ClergyName, Address1, Address2, City, States, Zip, Email, phone, phone2)

        VALUES ('".$username."', '".$POW_PlaceOfWorship."', '".$POW_ClergyName."', '".$POW_Address1."', '".$POW_Address2."', '".$POW_City."', 
                '".$POW_States."', '".$POW_Zip."', '".$POW_Email."', '".$POW_phone."', '".$POW_phone2."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    ///////////////////Education Form///////////////////
    $EDU_EduHighSchool = (isset($_POST['EDU_EduHighSchool']) ) ? trim($_POST['EDU_EduHighSchool']) : '';
    $EDU_EduHSGraduated = (isset($_POST['EDU_EduHSGraduated']) ) ? trim($_POST['EDU_EduHSGraduated']) : '';
    $EDU_undergraducate = (isset($_POST['EDU_undergraducate']) ) ? trim($_POST['EDU_undergraducate']) : '';
    $EDU_undergraducatedegree = (isset($_POST['EDU_undergraducatedegree']) ) ? trim($_POST['EDU_undergraducatedegree']) : '';
    $EDU_undergraducatedegreecheck = (isset($_POST['EDU_undergraducatedegreecheck']) ) ? trim($_POST['EDU_undergraducatedegreecheck']) : '';
    $EDU_graduate = (isset($_POST['EDU_graduate']) ) ? trim($_POST['EDU_graduate']) : '';
    $EDU_graducatedegree = (isset($_POST['EDU_graducatedegree']) ) ? trim($_POST['EDU_graducatedegree']) : '';
    $EDU_graducatedegreecheck = (isset($_POST['EDU_graducatedegreecheck']) ) ? trim($_POST['EDU_graducatedegreecheck']) : '';
    $POW_phone = (isset($_POST['POW_phone']) ) ? trim($_POST['POW_phone']) : '';
    $POW_phone2 = (isset($_POST['POW_phone2']) ) ? trim($_POST['POW_phone2']) : '';
    
    $sql = "SELECT * FROM case_bio_education WHERE username='".$username."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE case_bio_education SET EduHighSchool='".$EDU_EduHighSchool."', EduHSGraduated='".$EDU_EduHSGraduated."', undergraducate='".$EDU_undergraducate."', 
            undergraducatedegree='".$EDU_undergraducatedegree."', undergraducatedegreecheck='".$EDU_undergraducatedegreecheck."', graduate='".$EDU_graduate."', 
            graducatedegree='".$EDU_graducatedegree."', graducatedegreecheck='".$EDU_graducatedegreecheck."' WHERE username='".$username."'";
    } else {
        $sql = "INSERT INTO case_bio_education (username, EduHighSchool, EduHSGraduated, undergraducate, undergraducatedegree, undergraducatedegreecheck, graduate, 
                graducatedegree, graducatedegreecheck)

        VALUES ('".$username."', '".$EDU_EduHighSchool."', '".$EDU_EduHSGraduated."', '".$EDU_undergraducate."', '".$EDU_undergraducatedegree."', '".$EDU_undergraducatedegreecheck."', 
                '".$EDU_graduate."', '".$EDU_graducatedegree."', '".$EDU_graducatedegreecheck."')";
    }
    $conn->query($sql);
    //////////////////////////////////////

    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>