<?php

    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];

    ///////////////////Information Form///////////////////
    $FirstName = $_POST['FirstName'];
    $PersonalEmail = $_POST['PersonalEmail'];
    $CompanyEmail = $_POST['CompanyEmail'];
    $Address1 = $_POST['Address1'];
    $Address2 = $_POST['Address2'];
    $City = $_POST['City'];
    $States = $_POST['States'];
    $Zip = $_POST['Zip'];
    $phone = $_POST['phone'];
    $HireDate = $_POST['HireDate'];
    $TerminationDate = $_POST['TerminationDate'];
    $License = $_POST['License'];
    $LicValidDate = $_POST['LicValidDate'];
    $StateLicensed = $_POST['StateLicensed'];
    
    $sql = "SELECT * FROM staff WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE staff SET FirstName='".$FirstName[$i]."', PersonalEmail='".$PersonalEmail[$i]."', CompanyEmail='".$CompanyEmail[$i]."', Address1='".$Address1[$i]."', 
            Address2='".$Address2[$i]."', City='".$City[$i]."', States='".$States[$i]."', Zip='".$Zip[$i]."', phone='".$phone[$i]."', HireDate='".$HireDate[$i]."', 
            TerminationDate='".$TerminationDate[$i]."', License='".$License[$i]."', LicValidDate='".$LicValidDate[$i]."', StateLicensed='".$StateLicensed[$i]."' 
            WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($FirstName); $i ++) {
            $sql = "INSERT INTO staff (username, childid, FirstName, PersonalEmail, CompanyEmail, Address1, Address2, City, States, Zip, phone, HireDate, TerminationDate,
                    License, LicValidDate, StateLicensed)

            VALUES ('".$username."', '".$i."', '".$FirstName[$i]."', '".$PersonalEmail[$i]."', '".$CompanyEmail[$i]."', '".$Address1[$i]."', '".$Address2[$i]."', '".$City[$i]."', 
                '".$States[$i]."', '".$Zip[$i]."', '".$phone[$i]."', '".$HireDate[$i]."', '".$TerminationDate[$i]."', '".$License[$i]."', '".$LicValidDate[$i]."', '".$StateLicensed[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($FirstName); $i ++) {
            $sql = "INSERT INTO staff (username, childid, FirstName, PersonalEmail, CompanyEmail, Address1, Address2, City, States, Zip, phone, HireDate, TerminationDate,
                    License, LicValidDate, StateLicensed)

            VALUES ('".$username."', '".$i."', '".$FirstName[$i]."', '".$PersonalEmail[$i]."', '".$CompanyEmail[$i]."', '".$Address1[$i]."', '".$Address2[$i]."', '".$City[$i]."', 
                '".$States[$i]."', '".$Zip[$i]."', '".$phone[$i]."', '".$HireDate[$i]."', '".$TerminationDate[$i]."', '".$License[$i]."', '".$LicValidDate[$i]."', '".$StateLicensed[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>