<?php

    session_start();
    require 'connectDatabase.php';

    $username = $_SESSION['username'];

    ///////////////////Information Form///////////////////
    $Name = $_POST['Name'];
    $Email = $_POST['Email'];
    $Address1 = $_POST['Address1'];
    $Address2 = $_POST['Address2'];
    $City = $_POST['City'];
    $States = $_POST['States'];
    $Zip = $_POST['Zip'];
    $phone = $_POST['phone'];
    
    $sql = "SELECT * FROM visitor WHERE username='".$username."';";
    $result = $conn->query($sql);
    $resultCount = mysqli_num_rows($result);
    if ($resultCount > 0) {
        for ($i = 0; $i < $resultCount; $i ++) {
            $sql = "UPDATE visitor SET Name='".$Name[$i]."', Email='".$Email[$i]."', Address1='".$Address1[$i]."', Address2='".$Address2[$i]."', 
            City='".$City[$i]."', States='".$States[$i]."', Zip='".$Zip[$i]."', phone='".$phone[$i]."' WHERE username='".$username."' AND childid='".$i."'";
            $conn->query($sql);
        }

        for ($i = $resultCount; $i < count($Name); $i ++) {
            $sql = "INSERT INTO visitor (username, childid, Name, Email, Address1, Address2, City, States, Zip, phone)

            VALUES ('".$username."', '".$i."', '".$Name[$i]."', '".$Email[$i]."', '".$Address1[$i]."', '".$Address2[$i]."', '".$City[$i]."', 
                '".$States[$i]."', '".$Zip[$i]."', '".$phone[$i]."')";
            $conn->query($sql);
        }
    } else {
        for ($i = 0; $i < count($Name); $i ++) {
            $sql = "INSERT INTO visitor (username, childid, Name, Email, Address1, Address2, City, States, Zip, phone)

            VALUES ('".$username."', '".$i."', '".$Name[$i]."', '".$Email[$i]."', '".$Address1[$i]."', '".$Address2[$i]."', '".$City[$i]."', 
                '".$States[$i]."', '".$Zip[$i]."', '".$phone[$i]."')";
            $conn->query($sql);
        }
    }
    //////////////////////////////////////

    $response['status'] = "OK";
    $conn->close();
    echo json_encode($response);
?>