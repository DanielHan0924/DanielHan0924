<?php 
session_start();
require 'database/connectDatabase.php';
if( isset($_SESSION['userid'])){

    $permanent = isset($_POST['SOGS_permanent'])?$_POST['SOGS_permanent']:'N';
    
    if(isset($_POST['SOGS_table']) && $_POST['SOGS_table'] != '' ){ // save new one
        // check if there is already same option
        $sql = "SELECT * FROM ".$_POST['SOGS_Category']." WHERE Service='".$_POST['SOGS_newitem']."';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $response = array('status' => 'exist');
            echo json_encode($response); return;
        }
        //insert new item to statement and new Reason to Reason table
        $sql = "INSERT INTO ".$_POST['SOGS_Category']." (staffID, Service, Price, Permanent) VALUES ('".$_SESSION['userid']."','".$_POST['SOGS_newitem']."','".$_POST['SOGS_newfee']."','".$permanent."')";
        $sql1 = "INSERT INTO dropdown_reasonfor (name) VALUES ('".$_POST['SOGS_newreason']."')";
        if ($_POST['SOGS_newreason'] == ''){
            if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'created');
            echo json_encode($response); return;
            } else {
                $response = array('status' => 'error');
                echo json_encode($response); return;
            }
        } else {
            if ($conn->query($sql) === TRUE && $conn->query($sql1) === TRUE) {
                $response = array('status' => 'created');
                echo json_encode($response); return;
                } else {
                    $response = array('status' => 'error');
                    echo json_encode($response); return;
                }
        }
        
    }else if(isset($_POST['SOGS_table_edit']) && $_POST['SOGS_table_edit'] != ''){ // update recent one
        $sql = "UPDATE ".$_POST['SOGS_table_edit']." SET Service='".$_POST['SOGS_newitem']."', Price='".$_POST['SOGS_newfee']."', Permanent='".$permanent."' WHERE id='".$_POST['SOGS_currentItem']."'";

        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'updated');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else { //delete recent one
        $sql = "DELETE FROM ".$_POST['SOGS_table_del']." WHERE id='".$_POST['SOGS_currentItem']."'";
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'deleted');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }
}
else{ 
    $response = array('status' => 'failed');
    echo json_encode($response); return;
}
?>