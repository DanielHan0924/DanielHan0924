<?php 
    session_start();
    if (isset($_SESSION['userid'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';
        
        $flag_addBtn = true;
        $flag_atneed = true;

        $flag_convert_fc = true; //used to 'convert' button
        $flag_convert_surv  = true; //used to 'convert' button

        $sql = "SELECT * FROM at_need_pi WHERE staffID='".$_SESSION['userid']."';";
        $deceasedResult = $conn->query($sql);
        $deceasedResultCount = mysqli_num_rows($deceasedResult);

        $sql = "SELECT * FROM at_need_nok WHERE staffID='".$_SESSION['userid']."' GROUP BY caseID;";
        $nokResult = $conn->query($sql);
        $nokResultCount = mysqli_num_rows($nokResult);

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
        <div class="page-title-heading">
            <div><h3>AT NEED</h3></div>    
        </div>
            </div>
</div>    

<div class="row">
    <div class="col-md-12">
        <!-- <form class="longforms" id="atneed-form"> -->
        <div class="main-card mb-3 card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                    <nav class="" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item greyHeaderInformations" aria-current="page">***If you select any 'Personal Information' row, you will see his/her age at death.</li>
                        </ol>
                    </nav>
                    <h5 class="card-title custom-head">AT NEED</h5>
                    </div>
                    <!-- <div class="col-lg-2">
                        <div class="image-holder">
                            <img src="assets/images/oldman.jpeg" />
                            <div class="d-block text-center card-footer">
                            <button class="btn-sm btn-block btn btn-success" onclick="saveAtNeedForm()">Save</button>
                            </div>
                        </div>
                    </div> -->
                </div>    
            </div>
            <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                <div class="card">
                    <div id="headingOne" class="card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">DECEASED INFORMATION </h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                        <div class="card-body">
                        
                            <?php if ($deceasedResultCount > 0) { ?>
                                <select name="PF_select" id="PF_select" class="form-control" required>
                                    <option hidden>Select any person deceased information:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($deceasedResult)) { ?>
                                        <?php  
                                            $sql = "SELECT name FROM dropdown_honorific WHERE id='".$dropdown_city_cld['honorific']."';";
                                            $result = mysqli_fetch_array($conn->query($sql));
                                            $sql1 = "SELECT name FROM dropdown_lastname WHERE id='".$dropdown_city_cld['lastName']."';";
                                            $result1 = mysqli_fetch_array($conn->query($sql1));
                                            $sql2 = "SELECT name FROM dropdown_suffix WHERE id='".$dropdown_city_cld['suffix']."';";
                                            $result2 = mysqli_fetch_array($conn->query($sql2));
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($result["name"]); ?>, <?php echo ($dropdown_city_cld['firstName'] ); ?> <?php echo ($dropdown_city_cld['middleName'] ); ?>, <?php echo ($result1['name'] ); ?>, <?php echo ($result2['name'] ); ?></option>
                                    <?php } ?>
                                </select>
                                <br>
                            <?php } else{echo ('no person deceased information');} ?>
                                <?php include('inc/personalF_info.php'); ?> 
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne2" aria-expanded="false" aria-controls="collapseTwo" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">NEXT OF KIN</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne2" class="collapse">
                        <div class="card-body">
                            <?php if ($nokResultCount > 0) { ?>
                                <select name="NOK_case_select" id="NOK_case_select" class="form-control" required>
                                    <option hidden>Select any next of kin:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($nokResult)) { ?>
                                        
                                        <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" >caseID: <?php echo ($dropdown_city_cld["caseID"]); ?></option>
                                    <?php } ?>
                                </select>
                                <br>
                                <div class="row multi-select-custom"></div> 

                            <?php } else{echo ('no personal information');} ?>
                            <?php include('inc/next_of_kin.php'); ?> 
                        </div>
                    </div>
                </div>
                                                        
            </div>
            
            <!-- <div class="d-block text-center card-footer">
                <button type="button" class="btn-wide btn btn-primary pull-left">Back to Home</button>
                <button class="btn-wide btn btn-success pull-right" onclick="saveAtNeedForm()">Save</button>
            </div> -->
            
        </div>
        <!-- </form> -->
    </div>
</div>
</div>
<?php include('inc/footer.php'); ?>
