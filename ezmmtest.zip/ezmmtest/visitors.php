<?php 
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';

        $flag_addBtn = true;
        $flag_visitor = true;

        $sql = "SELECT * FROM visitor WHERE staffID='".$_SESSION['userid']."' GROUP BY caseID;";
        $visitorresult = $conn->query($sql);
        $visitorresultCount = mysqli_num_rows($visitorresult);

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
            <div class="page-title-heading">
                <div><h3>VISITORS</h3></div>    
            </div>
                </div>
    </div>    

    <div class="row">
        <div class="col-md-12">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-11">
                        
                        <h5 class="card-title custom-head">Visitors </h5>
                        </div>
                        <div class="col-md-1">
                            <button id="btn_visitorsreport" class="btn btn-block btn btn-info">Report</button>
                        </div>
                    </div>
                </div>
                <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                    <div class="card">
                        <div id="headingOne" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">VISITORS</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                            <div class="card-body">
                                <?php if ($visitorresultCount > 0) { ?>
                                    <select name="VISITOR_case_select" id="VISITOR_case_select" class="form-control" required>
                                        <option hidden>Select any visitor:</option>
                                        <?php 
                                        while($dropdown_city_cld = mysqli_fetch_assoc($visitorresult)) { ?>
                                            
                                            <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" >CaseID: <?php echo ($dropdown_city_cld["caseID"]); ?></option>
                                        <?php } ?>
                                    </select>
                                    <br>
                                    <div class="row multi-select-custom"></div> 
                                <?php } else{echo ('No Visitors');} ?>
                                <?php include('inc/visitor.php'); ?> 
                            </div>
                        </div>
                    </div>                                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('inc/footer.php'); ?>
