<!-- BEGIN CONTENT -->
<div class="row" id="invoicePagePrint">
    <div class="col-md-12 ">
        <!-- BEGIN SAMPLE FORM PORTLET-->
        <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-gift"></i>Statement of Goods & Services
                </div>
            </div>
            <div class="portlet-body form">
                <!-- BEGIN FORM-->
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Invoice Date</label>
                                    <div class="input-group date date-picker" data-date-format="dd-mm-yyyy">
                                        <span class="input-group-btn">
                                            <button class="btn default" type="button"><i class="fa fa-calendar"></i></button>
                                        </span>
                                        <input type="text" name="invoice_date" value="" class="form-control datepicker">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Due Date</label>
                                    <div class="input-group date date-picker" data-date-format="dd-mm-yyyy">
                                        <span class="input-group-btn">
                                            <button class="btn default" type="button"><i class="fa fa-calendar"></i></button>
                                        </span>
                                        <input type="text" name="due_date" value="" class="form-control datepicker">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="control-label">Deceased Name</label>
                                    <input type="text" class="form-control" value="" name="deceased_name" placeholder="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="control-label">Informant</label>
                                    <input type="text" class="form-control" value="" name="informant" placeholder="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="control-label">Accepted by</label>
                                    <input type="text" class="form-control" value="" name="accepted_by" placeholder="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <h3 class="form-section">Professional Services</h3>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Services Of Funeral Director</label>
                                        <div class="col-md-4">
                                            <input type="text" name="ServiceOfFuneralDirector" value="" class="form-control" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Embalming</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Embalming" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Other Preparation Of Body</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="OtherPreparationOfTheBody" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h3 class="form-section">Facilities & Equipment</h3>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Use of Facilities/ Viewing/ Visitation/ Prayer/ Wake</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="UseOfFacilitiesViewingVisitationPrayerWake" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Use of Facilities & Equipment for Funeral</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="UseOfFacilitiesEquipmentForFuneral" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>






                            <h3 class="form-section">Automotive & Equipment</h3>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Transfer of Remains To Funeral Home</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="TransferOfRemainsToFuneralHome" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Transfer of Remains To Place of Service</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="TransferOfRemainsToPlaceOfService" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Utility Lead Vehicle</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="UtilityLeadVehicle" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Hearse</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Hearse" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>




                            <div class="row" style="padding-top: 5px;">
                                <div class="col-md-12">
                                    <div class="form-group" style="background-color: #9AB8FF">
                                        <label class="col-md-8 control-label">Total Services Selected</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="TotalServices" placeholder="$ 0.00" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>



                           

                            <h3 class="form-section">Changes For Merchandise Selected</h3>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Casket</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="<?php echo $statement['Casket']; ?>" name="Casket" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Outer Burial Container</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="OuterBurialContainer" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Acknowledgement Cards</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="AcknowledgementCards" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>



 


                        <div class="col-md-4">
                            <h3 class="form-section">Charge for Services Selected</h3>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Registry Book</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="RegistryBook" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Memory Folder/ Prayer Cards</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="MemoryFolderPrayerCards" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Clothing</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Clothing" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Cremation Urn</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="CremationUrm" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>





                            <h3 class="form-section">Total Special Charges</h3>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Forwarding of Remains From</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="ForwardingRemainsFromCharge" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Forwarding of Remains To</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="ForwardingRemainsToCharge" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Immediate Burial</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="DirectBurial" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Direct Cremation</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="DircectCremation" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>






                           


                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Total Special Charge</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="TotalSpecialCharges" placeholder="$ 0.00" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            




                            <h3 class="form-section">Cash Advanced</h3>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Opening & Closing Grave</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="OpeningClosingTheGrave" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Cemetery Fee</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="CemeteryFee" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Clergy</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Clergy" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Organist</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Organist" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Vocalist</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Vocalist" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Flowers</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Flowers" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Cert, Death Certificates</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="CertDeathCertificate" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Other Funeral Directors</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="OtherFuneralDirectors" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Hairdress/ Barber</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="BarberHairdresser" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Transportation</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Transportation" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Donations</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Donations" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Other</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Other" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Obituary</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Obituary" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>





                           


                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Total Cash Advanced</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="TotalCashAdvances" placeholder="$ 0.00" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            


                            <h3 class="form-section">Summary Of Charges</h3>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Services Sub Total</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value=" name="ServicesSubTotal" placeholder="$ 0.00" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Merchandise Sub Total</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="<?" name="MerchandiseSubTotal" placeholder="$ 0.00" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Special Charges Sub Total</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="SpecialChargesSubTotal" placeholder="$ 0.00" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Cash Advanced Sub Total</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="CashAdvancedSubTotal" placeholder="$ 0.00" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Summary Sub Total</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="SummarySubTotal" placeholder="$ 0.00" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Write Off</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="WriteOff" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <h3 class="form-section">Total Amount Due</h3>
                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Sales Tax Rate</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="TaxRate" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Tax</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="Tax" placeholder="$ 0.00" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Total Charge</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="TotalCharges" placeholder="$ 0.00" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <div class="row" style="padding-top: 20px;">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Payment Amount</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="payment" placeholder="$ 0.00">
                                        </div>
                                    </div>
                                </div>
                            </div>




                            <div class="row" style="padding-top: 5px">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="col-md-8 control-label">Current Balance</label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" value="" name="balance" placeholder="$ 0.00" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                    <div class="row" style="margin-top: 20px; padding-top: 5px">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="col-md-3 control-label">Reasons For </label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" value="" name="ReasonForEmbalming" placeholder="$ 0.00">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12" style="margin-top: 10px">
                            <div class="form-group">
                                <label class="col-md-3 control-label">Items Listed </label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" value="" name="ItemsListedAboveExplained" placeholder="$ 0.00">
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="row" style="margin-top: 10px">
                        <div class="col-md-12">
                            <li style="font-weight: bold;">Terms:</li> payment total is due <input type="text" style="width: 80px" value="" placeholder="$ 0.00"> days from date,
                            after which a finance charge of <input type="text" style="width: 80px" value="" name="FinanceCharge" placeholder="% 0.00"> per month,
                            annual <input type="text" style="width: 80px" value="" name="Annual" placeholder="% 0.00"> shall be added to the unpaid balance.
                            I/we the have seen the General price list, Casket and outer Burial price list, promise to pay above and have given a signed copy of the statement.

                        </div>
                    </div>
                </div>

                <input type="submit" id="savebtn" style="display:none;" />

                </form>
                <!-- END FORM-->
            </div>
        </div>
        <!-- END SAMPLE FORM PORTLET-->

    </div>
</div>
