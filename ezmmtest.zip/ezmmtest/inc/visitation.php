<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">

            <input type="hidden" name="recurrings_table" id="recurrings_table_visitation" value="final_arrange_visitation">

            <label class="control-label">Visitation start date</label>
            <?php
                $value = (isset($visitation['StartDate']) ) ? trim($visitation['StartDate']) : '';
            ?>
            <input type="date" name="VIS_StartDate" id="VIS_StartDate" value="<?php echo $value ?>"  class="form-control">
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Visitation start time</label>
            <?php
                $value = (isset($visitation['StartTime']) ) ? trim($visitation['StartTime']) : '';
            ?>
            <input type="time" name="VIS_StartTime" id="VIS_StartTime"value="<?php echo $value ?>" class="form-control timepicker timepicker-default">
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Visitation date</label>
            <?php
                $value = (isset($visitation['EndDate']) ) ? trim($visitation['EndDate']) : '';
            ?>
            <input type="date" name="VIS_EndDate" id="VIS_EndDate" value="<?php echo $value ?>"  class="form-control">
                
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Visitation time</label>
            <?php
                $value = (isset($visitation['EndTime']) ) ? trim($visitation['EndTime']) : '';
            ?>
            <input type="time" name="VIS_EndTime" id="VIS_EndTime"value="<?php echo $value ?>" class="form-control timepicker timepicker-default">

        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Place of visitation</label>
            <?php
                $value = (isset($visitation['VisitationName']) ) ? trim($visitation['VisitationName']) : '';
            ?>
            <input type="text" name="VIS_Visitation" id="VIS_Visitation" class="form-control" value="<?php echo $value ?>" required>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Address</label>
            <?php
                $value = (isset($visitation['VisitationAddress']) ) ? trim($visitation['VisitationAddress']) : '';
            ?>
            <input type="text" name="VIS_Address" id="VIS_Address" class="form-control" value="<?php echo $value ?>" required>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">City</label>
            <?php
            $sql = "SELECT * FROM dropdown_city";
            $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="VIS_City" id="VIS_City" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">State</label>
            <?php
            $sql = "SELECT * FROM dropdown_state";
            $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="VIS_State" id="VIS_State" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Telephone</label>
            <?php
                $value = (isset($visitation['Telephone']) ) ? trim($visitation['Telephone']) : '';
            ?>
            <input type="text" name="VIS_Telephone" id="VIS_Telephone" class="mask_phone form-control" value="<?php echo $value ?>" required>
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php }?>
</form>
<!--full-->

<!-- Form One Ends -->
