<div class="table-responsive">
    <table class="align-middle mb-0 table table-borderless table-striped table-hover">
        <thead>
        <tr>
            <th class="text-center">FunHomeID</th>
            <th class="text-center">Funeral Home Name</th>
            <th class="text-center">Contact</th>
            <th class="text-center">Email</th>
            <th class="text-center">Office Phone</th>
            <th class="text-center">CellPhone</th>
            <th class="text-center">Notes</th>
            <th class="text-center">Status</th>
            <th class="text-center">Days Remaining</th>
            <th class="text-center">Unlock (readOnly)</th>
            <th class="text-center">Plan</th>
            <th class="text-center">No Locations</th>
            <th class="text-center">Licensed</th>
            <th class="text-center">User-Admins</th>
            <th class="text-center">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php if ($funhomeResultCount > 0) { while($funhome_row = mysqli_fetch_assoc($funhomeResult)) { ?>

            <form class="forms_superrow" action="saveuserinfo.php" method="POST">    

            <tr>
                <?php
                    $id = (isset($funhome_row['id']) ) ? trim($funhome_row['id']) : '';
                    $funname = (isset($funhome_row['crematory']) ) ? trim($funhome_row['crematory']) : '';
                    $contact = (isset($funhome_row['contact']) ) ? trim($funhome_row['contact']) : '';
                    $contactemail = (isset($funhome_row['contactemail']) ) ? trim($funhome_row['contactemail']) : '';
                    $phone = (isset($funhome_row['phone']) ) ? trim($funhome_row['phone']) : '';
                    $cellphone = (isset($funhome_row['phone']) ) ? trim($funhome_row['phone']) : '';
                    $note = (isset($funhome_row['note']) ) ? trim($funhome_row['note']) : '';

                    $dateOfDeath = (isset($funhome_row['HireDate']) ) ? ($funhome_row['HireDate']) : '';
                    $dateOfBirth = (isset($funhome_row['TerminationDate']) ) ? ($funhome_row['TerminationDate']) : '';
                    $dateOfDeath_obj = new DateTime($dateOfDeath);
                    $dateOfBirth_obj = new DateTime($dateOfBirth);
                    $daysremain = $dateOfBirth_obj->diff($dateOfDeath_obj)->format('%a days'); //If you're using PHP 5.3 >, this is by far the most accurate way of calculating the difference:
                    
                    $statelicensed = (isset($funhome_row['StateLicensed']) ) ? trim($funhome_row['StateLicensed']) : '';
                    $funstatus = (isset($funhome_row['funstatus']) ) ? trim($funhome_row['funstatus']) : '';
                    $plan = (isset($funhome_row['plan']) ) ? trim($funhome_row['plan']) : '';
                    $locations = (isset($funhome_row['locations']) ) ? trim($funhome_row['locations']) : '';  
                    $role = (isset($funhome_row['role']) ) ? trim($funhome_row['role']) : '';  
                ?>
                <input type="hidden" name="SUPER_funid" value="<?php echo $id; ?>">
                <td class="text-center text-muted "><?php echo $id; ?></td>
                <td class="text-center text-muted"><?php echo $funname; ?></td>
                <td class="text-center"><?php echo $contact; ?></td>
                <td class="text-center"><?php echo $contactemail; ?></td>
                <td class="text-center"><?php echo $phone; ?></td>
                <td class="text-center"><?php echo $cellphone; ?></td>
                <td class="text-center">
                    <a href="#" class="mr-2" data-toggle="modal" data-target="#modal-supernote<?php echo $id; ?>">
                        <button type="button" data-placement="bottom" class="btn-shadow  btn btn-primary btn-custom">     
                        </button>
                    </a>    
                </td>
                <td class="text-center">
                    <?php
                        $sql = "SELECT * FROM dropdown_funstatus";
                        $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="SUPER_funstatus" class="form-control SUPER_funstatus" required>
                            <option value="0" hidden>select...</option>
                            <?php 
                            while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                ?>
                                <option value="<?php echo ($dropdown_zip_cld['name']); ?>" <?php if ($funstatus == $dropdown_zip_cld['name']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo ('no option to be selected');}?> 
                </td>
                <td class="text-center"><?php echo '30'; ?></td>

                <td class="text-center">
                    <a href="#" class="mr-2">
                        <button type="button" data-placement="bottom" class="btn-shadow  btn btn-<?php if ($funstatus == 'Paid') { echo ('info');} else {echo ('warning');}?> ">     
                            <?php  if ($funstatus == 'Demo') { echo ('Extend 30');} ?>
                        </button>
                    </a> 
                </td>
                <td class="text-center">
                    <?php
                    $sql = "SELECT * FROM dropdown_plan";
                    $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="SUPER_plan" class="form-control SUPER_plan" required>
                            <option value="0" hidden>select...</option>
                            <?php 
                            while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($plan == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo ('no option to be selected');}?>
                </td>
                <td class="text-center"><?php echo $locations; ?></td>
                <td class="text-center">
                    <?php
                        $sql = "SELECT * FROM dropdown_state";
                        $result = $conn->query($sql);
                        ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SUPER_statelicensed"  class="form-control SUPER_statelicensed" required>
                                <option value="0" hidden>select...</option>
                                <?php 
                                while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                    ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($statelicensed == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                                <?php }?>
                            </select>
                    <?php } else{echo ('no option to be selected');}?>
                </td>
                <td class="text-center">
                    <input type="checkbox" name="SUPER_useradmincheck" class="form-control SUPER_useradmincheck" <?php if ($role == "adminstaff") {echo "checked";}?>>
                </td>
                <td class="text-center">
                    <button type="submit" data-placement="bottom" class="btn btn-info" value="subm_updateuser"> Update </button>
                </td> 
                <div class="modal fade" id="modal-supernote<?php echo $id; ?>">
                    <div class="modal-dialog">
                        <div class="modal-overlay"></div>
                        <div class="modal-content">
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Note by the Admin:</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <!-- Modal body -->
                            <div class="modal-body">
                                <?php
                                    $rownote = (isset($note) ) ? trim($note) : 'There is no note for the funeral home.';
                                ?> 
                                <p><?php echo $rownote ?></p>
                            </div>
                        </div>
                    </div>
                </div> 
            </tr>

            </form>

            <?php }?>
        <?php } else{echo ('no funeral home to be selected');}?>
        </tbody>
    </table>
</div>
<div class="d-block text-center card-footer">  
</div>
