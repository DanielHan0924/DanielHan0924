<!-- Form One Content Starts -->
<form id="form_image" class="forms_hasphoto" action="savehasphoto.php" method="POST" enctype="multipart/form-data">
<input type="hidden" name="recurrings_table" id="hasphoto_table_image" value="images">

<div class = "row">
    <div class = "col-md-3">
        <div class="row">
            <div class="col-sm-10 imgUp">
                <div class="imagePreview uploadedFile_image"></div>
                <label class="btn btn-primary">
                    Select an Image<input type="file" name="uploadedFile" id="uploadedFile_image" class="uploadedFile_image uploadFile img"  style="width: 0px;height: 0px;overflow: hidden;" onchange="PreviewImage();">
                </label>
            </div>
        </div>
    </div>
    <div class = "col-md-3 div_testimageview" hidden>
        <div id="imgpreview">
        </div>
        <a id="" href="" class="" data-toggle="modal" data-target="#modal-imageview">
            <img class="testimageview" src=""  width="150" height="200" alt="image"/>
        </a>
    </div>
            
</div>
<div class="modal fade" id="modal-imageview">
    <div class="modal-dialog">
        <div class="modal-overlay"></div>
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"></h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
               
                <img class="testimageview" src="" />
            </div>
        </div>
    </div>
</div> 
<!-- / -->
<?php if (isset($flag_addbtn) && $flag_addbtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editimage">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delimage">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-7">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-success btn-sm" value="subm_saveimage" id="subm_saveimage" disabled>
           Upload Image
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delimage" id="subm_delimage" disabled>
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>
<script type="text/javascript">
    function PreviewImage() {
        $('#subm_saveimage').prop('disabled',false);
    }
</script>


<!-- Form One Ends -->
