<!-- Form One Content Starts -->
<div class="row">

    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Father's Name</label>
            <?php
                $value = (isset($parents['FathersName']) ) ? trim($parents['FathersName']) : '';
            ?>
            <input type="text" name="PAT_FathersName" id="FathersName" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Date of Birth</label>
            <?php
                $value = (isset($parents['FDOB']) ) ? trim($parents['FDOB']) : '';
            ?>
            <input type="date" name="PAT_FDOB" id="FDOB" value="<?php echo $value ?>" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
        <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Place Of Birth</label>
            <?php
                $value = (isset($parents['FPlaceOfBirth']) ) ? trim($parents['FPlaceOfBirth']) : '';
            ?>
            <input type="text" name="PAT_FPlaceOfBirth" id="FPlaceOfBirth" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
   
</div>
<div class="row">
     <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Mother's Name</label>
            <?php
                $value = (isset($parents['MothersName']) ) ? trim($parents['MothersName']) : '';
            ?>
            <input type="text" name="PAT_MothersName" id="MothersName" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Mother's Maiden Name</label>
            <?php
                $value = (isset($parents['MothersMaidenName']) ) ? trim($parents['MothersMaidenName']) : '';
            ?>
            <input type="text" name="PAT_MothersMaidenName" id="MothersMaidenName" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Date of Birth</label>
            <?php
                $value = (isset($parents['MDOB']) ) ? trim($parents['MDOB']) : '';
            ?>
            <input type="date" name="PAT_MDOB" id="FDOB" value="<?php echo $value ?>" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
        <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Place Of Birth</label>
            <?php
                $value = (isset($parents['MPlaceOfBirth']) ) ? trim($parents['MPlaceOfBirth']) : '';
            ?>
            <input type="text" name="PAT_MPlaceOfBirth" id="MPlaceOfBirth" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    
</div>


<!-- Form One Ends -->
