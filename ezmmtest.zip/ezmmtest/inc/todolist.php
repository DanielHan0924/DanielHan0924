<!-- Form One Content Starts -->
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Date of Marriage</label>
            <?php
                $value = (isset($marital_status['dateofmarriage']) ) ? trim($marital_status['dateofmarriage']) : '';
            ?>
            <input type="date" name="MS_DateOfMarriage" id="DateOfMarriage" value="<?php echo $value ?>" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Date of Marriage</label>
            <?php
                $value = (isset($marital_status['dateofmarriage']) ) ? trim($marital_status['dateofmarriage']) : '';
            ?>
            <input type="time" name="MS_DateOfMarriage" id="DateOfMarriage" value="<?php echo $value ?>" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-1">
        <div class="form-group">
            <label class="control-label">StateID</label>
            <?php
                $value = (isset($marital_status['placeofmarriage']) ) ? trim($marital_status['placeofmarriage']) : '';
            ?>
            <input type="text" name="MS_PlaceOfMarriage" id="PlaceOfMarriage" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-1">
        <div class="form-group">
            <label class="control-label">CaseID</label>
            <?php
                $value = (isset($marital_status['placeofmarriage']) ) ? trim($marital_status['placeofmarriage']) : '';
            ?>
            <input type="text" name="MS_PlaceOfMarriage" id="PlaceOfMarriage" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Date of Marriage</label>
            <?php
                $value = (isset($marital_status['dateofmarriage']) ) ? trim($marital_status['dateofmarriage']) : '';
            ?>
            <input type="date" name="MS_DateOfMarriage" id="DateOfMarriage" value="<?php echo $value ?>" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Date of Marriage</label>
            <?php
                $value = (isset($marital_status['dateofmarriage']) ) ? trim($marital_status['dateofmarriage']) : '';
            ?>
            <input type="time" name="MS_DateOfMarriage" id="DateOfMarriage" value="<?php echo $value ?>" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">???</label>
            <?php
                $value = (isset($personal_info['WhoCalled']) ) ? $personal_info['WhoCalled'] : 1;
            ?>
            <?php if ($resultCount > 0) {?>
            <select name="PI_WhoCalledID" class="form-control required" required>
                <?php while($dropdown_WhoCalled = mysqli_fetch_assoc($result)) { ?>
                    <option value="<?php echo ($dropdown_WhoCalled['id']); ?>" <?php if ($value == $dropdown_WhoCalled['id']) {echo "selected";}?>><?php echo ($dropdown_WhoCalled['WhoCalled']); ?></option>
                <?php }?>
            </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">????</label>
            <?php
                $value = (isset($marital_status['dateofmarriage']) ) ? trim($marital_status['dateofmarriage']) : '';
            ?>
            <input type="number" name="MS_DateOfMarriage" id="DateOfMarriage" value="<?php echo $value ?>" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Requred Date</label>
            <?php
                $value = (isset($marital_status['dateofmarriage']) ) ? trim($marital_status['dateofmarriage']) : '';
            ?>
            <input type="number" name="MS_DateOfMarriage" id="DateOfMarriage" value="<?php echo $value ?>" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">???</label>
            <?php
                $value = (isset($personal_info['WhoCalled']) ) ? $personal_info['WhoCalled'] : 1;
            ?>
            <?php if ($resultCount > 0) {?>
            <select name="PI_WhoCalledID" class="form-control required" required>
                <?php while($dropdown_WhoCalled = mysqli_fetch_assoc($result)) { ?>
                    <option value="<?php echo ($dropdown_WhoCalled['id']); ?>" <?php if ($value == $dropdown_WhoCalled['id']) {echo "selected";}?>><?php echo ($dropdown_WhoCalled['WhoCalled']); ?></option>
                <?php }?>
            </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-1">
        <div class="form-group">
            <label class="control-label">Is Perm</label>
            <?php
                $value = (isset($marital_status['Spousedeceased']) ) ? trim($marital_status['Spousedeceased']) : '';
            ?>
            <input type="checkbox" name="MS_SpouseDeceased" value="Y" id="SpouseDeceased" class="form-control " placeholder="" <?php $checked = $value ? "checked" : ""; echo $checked ?>>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-1">
        <div class="form-group">
            <label class="control-label">Completed</label>
            <?php
                $value = (isset($marital_status['Spousedeceased']) ) ? trim($marital_status['Spousedeceased']) : '';
            ?>
            <input type="checkbox" name="MS_SpouseDeceased" value="Y" id="SpouseDeceased" class="form-control " placeholder="" <?php $checked = $value ? "checked" : ""; echo $checked ?>>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">???</label>
            <?php
                $value = (isset($personal_info['WhoCalled']) ) ? $personal_info['WhoCalled'] : 1;
            ?>
            <?php if ($resultCount > 0) {?>
            <select name="PI_WhoCalledID" class="form-control required" required>
                <?php while($dropdown_WhoCalled = mysqli_fetch_assoc($result)) { ?>
                    <option value="<?php echo ($dropdown_WhoCalled['id']); ?>" <?php if ($value == $dropdown_WhoCalled['id']) {echo "selected";}?>><?php echo ($dropdown_WhoCalled['WhoCalled']); ?></option>
                <?php }?>
            </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Required Date</label>
            <?php
                $value = (isset($marital_status['dateofmarriage']) ) ? trim($marital_status['dateofmarriage']) : '';
            ?>
            <input type="date" name="MS_DateOfMarriage" id="DateOfMarriage" value="<?php echo $value ?>" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>

<!-- Form One Ends -->

