<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">
        <?php if(isset($flag_casebio) && $flag_casebio == true) {
            $tbl_name = 'case_bio_military_service';
        } else { $tbl_name = 'pre_need_military_service';}     
        ?>
            <input type="hidden" name="recurrings_table" id="recurrings_table_mlt" value="<?php echo $tbl_name; ?>">
            <input type="hidden" name="MLT_radio_to" id="MLT_radio_to" value="case_bio_military_service">
            <label class="control-label">Branch</label>
            <?php
            $sql = "SELECT * FROM dropdown_militarybranch";
            $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="MLT_BranchID" id="MLT_BranchID" class="form-control" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">War/campaign</label>
            <?php
            $sql = "SELECT * FROM dropdown_warcampaign";
            $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="MLT_warcampaign" id="MLT_warcampaign" class="form-control" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Service/Serial number</label>
            <input type="text" name="MLT_SerialNumber"  id="MLT_SerialNumber" class="form-control" placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Rank</label>
            <?php
            $sql = "SELECT * FROM dropdown_rank";
            $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="MLT_rank" id="MLT_rank" class="form-control" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <div class="form-group">
            <label class="control-label">Enlistment date</label>
            <?php
                $value = (isset($military_service['EnlistmentDate']) ) ? trim($military_service['EnlistmentDate']) : '';
            ?>
            <input type="date" name="MLT_EnlistmentDate"  id="MLT_EnlistmentDate" class="form-control">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label class="control-label">Discharge date</label>
            <input type="date" name="MLT_DischargeDate"  id="MLT_DischargeDate" class="form-control">
            <div class="valid-feedback"></div>
            <div class="invalid-feedback"></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label class="control-label">Type of discharge</label>
            <?php
            $sql = "SELECT * FROM dropdown_typeofdischarge";
            $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="MLT_typeofdischarge" id="MLT_typeofdischarge" class="form-control" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <p class="control-label"><strong>Veteran Checklist</strong></p>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">
            <input type="checkbox" name="MLT_DD214" id="MLT_DD214" class=""> DD-214
            </label>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">
            <input type="checkbox"  name="MLT_Headstone" id="MLT_Headstone" class=""> Headstone/Marker
            </label>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">
            <input type="checkbox"  name="MLT_ApplicationForBurial" id="MLT_ApplicationForBurial" class="" > Application for Burial Benefits
            </label>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">
            <input type="checkbox"  name="MLT_ApplicationForFlag" id="MLT_ApplicationForFlag" class="" > Application for Flag
            </label>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">
            <input type="checkbox"  name="MLT_HonorGuard" id="MLT_HonorGuard" class="" > Honor Guard
            </label>
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-6">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
    <?php if (isset($flag_convert) && $flag_convert === true) { ?>
        <div class="col-md-1">
            <div class="mt-checkbox-inline">
                <label class="mt-checkbox mt-checkbox-outline">
                <input type="checkbox" name="MS_checkEnable" id="MS_checkEnable" class="convert_checkEnable">  Convert 
                </label>
            </div>
        </div>
        
        <div class="col-md-1">
            <button type="submit" class="btn btn-success btn-sm subm_convert" value="subm_convert" disabled>
                <h5 class="m-0 p-0" style="color: black;">Convert<i class="fa fa-return" style="color: black;"></i></h5>
            </button>
        </div>
    <?php } ?>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>

                                            
<!-- Form One Ends -->
                                                