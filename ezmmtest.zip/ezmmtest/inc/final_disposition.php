<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">
        <?php if(isset($flag_final) && $flag_final == true) {
            $tbl_name = 'final_arrange_final_disposition';
        } else { $tbl_name = 'pre_need_final_disposition';}     
        ?>

            <input type="hidden" name="recurrings_table" id="recurrings_table_finaldisposition"  value="<?php echo $tbl_name; ?>">
            <input type="hidden" name="FDP_radio_to" value="final_arrange_final_disposition">

            <div class="mt-checkbox-inline">
                <label class="mt-checkbox mt-checkbox-outline">
                    <?php
                        $value = (isset($final_disposition['Burial']) ) ? trim($final_disposition['Burial']) : '';
                    ?>
                    <input type="checkbox" value="<?php echo $value;?>" name="FDP_Burial" id="FDP_Burial" <?php if ($value == "Y") {echo "checked";}?>> Burial
                    <span></span>
                </label>
                <label class="mt-checkbox mt-checkbox-outline">
                    <?php
                        $value = (isset($final_disposition['Entombment']) ) ? trim($final_disposition['Entombment']) : '';
                    ?>
                    <input type="checkbox" value="<?php echo $value;?>" name="FDP_Entombment" id="FDP_Entombment"<?php if ($value == "Y") {echo "checked";}?>> Entombment
                    <span></span>
                </label>
                <label class="mt-checkbox mt-checkbox-outline">
                    <?php
                        $value = (isset($final_disposition['Cremation']) ) ? trim($final_disposition['Cremation']) : '';
                    ?>
                    <input type="checkbox" value="<?php echo $value;?>" name="FDP_Cremation" id="FDP_Cremation"<?php if ($value == "Y") {echo "checked";}?>> Cremation
                    <span></span>
                </label>
                <label class="mt-checkbox mt-checkbox-outline">
                    <?php
                        $value = (isset($final_disposition['BurialAtSea']) ) ? trim($final_disposition['BurialAtSea']) : '';
                    ?>
                    <input type="checkbox" value="<?php echo $value;?>" name="FDP_BurialAtSea" id="FDP_BurialAtSea" <?php if ($value == "Y") {echo "checked";}?>> Burial at Sea
                    <span></span>
                </label>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-10">
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Date of Final Disposition</label>
                    
                    <?php
                        $value = (isset($final_disposition['DateOfFinalDisposition']) ) ? trim($final_disposition['DateOfFinalDisposition']) : '';
                    ?>
                    <input type="date" name="FDP_DateOfFinalDisposition" id="FDP_DateOfFinalDisposition" value="<?php echo $value ?>" class="form-control datepicker">
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Final Disposition</label>
                    <?php
                        $value = (isset($final_disposition['FinalDisposition']) ) ? trim($final_disposition['FinalDisposition']) : '';
                    ?>
                    <input type="text" name="FDP_FinalDisposition" id="FDP_FinalDisposition" class="form-control" placeholder="" value="<?php echo $value ?>">

                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Cemetery/Crematory name</label>

                    <?php
                        $value = (isset($final_disposition['CemeteryID']) ) ? trim($final_disposition['CemeteryID']) : '';
                        $sql = "SELECT * FROM dropdown_cemetery";
                        $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="FDP_cemetery" id="FDP_cemetery" class="form-control required" required>
                            <option value="0" hidden>select...</option>
                            <?php 
                            while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($value == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo ('no option to be selected');}?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Location</label>
                    <?php
                        $value = (isset($final_disposition['Location']) ) ? trim($final_disposition['Location']) : '';
                    ?>
                    <input type="text" name="FDP_Location" id="FDP_Location" class="form-control" placeholder="" value="<?php echo $value ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Section</label>
                    <?php
                        $value = (isset($final_disposition['Section']) ) ? trim($final_disposition['Section']) : '';
                    ?>
                    <input type="text" name="FDP_Section" id="FDP_Section" class="form-control" placeholder="" value="<?php echo $value ?>">
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Funeral or Memorial Service at</label>
                    
                    <?php
                        $value = (isset($final_disposition['FuneralOrMemorialServiceAtID']) ) ? trim($final_disposition['FuneralOrMemorialServiceAtID']) : '';
                        $sql = "SELECT * FROM dropdown_funeralmemorial";
                        $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="FDP_FuneralOrMemorialServiceAtID" id="FDP_FuneralOrMemorialServiceAtID" class="form-control" required>
                            <option value="0" hidden>select...</option>
                            <?php 
                            while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($value == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo ('no option to be selected');}?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Name Lot Registered to</label>
                    <?php
                        $value = (isset($final_disposition['NameLotRegisteredTo']) ) ? trim($final_disposition['NameLotRegisteredTo']) : '';
                    ?>
                    <input type="text" name="FDP_NameLotRegisteredTo" id="FDP_NameLotRegisteredTo" class="form-control" placeholder="" value="<?php echo $value ?>">
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Where in Lot is Grave to Be Opened</label>
                    <?php
                        $value = (isset($final_disposition['WhereInLotIsGraveToBeOpened']) ) ? trim($final_disposition['WhereInLotIsGraveToBeOpened']) : '';
                    ?>
                    <input type="text" name="FDP_WhereInLotIsGraveToBeOpened" id="FDP_WhereInLotIsGraveToBeOpened" class="form-control" placeholder="" value="<?php echo $value ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="control-label">Lot #</label>
                    <?php
                        $value = (isset($final_disposition['LotNo']) ) ? trim($final_disposition['LotNo']) : '';
                    ?>
                    <input type="text" name="FDP_LotNo" id="FDP_LotNo" class="form-control" placeholder="" value="<?php echo $value ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="control-label">Grave #</label>
                    <?php
                        $value = (isset($final_disposition['GraveNo']) ) ? trim($final_disposition['GraveNo']) : '';
                    ?>
                    <input type="text" name="FDP_GraveNo" id="FDP_GraveNo" class="form-control" placeholder="" value="<?php echo $value ?>">
                </div>
            </div>
        </div>

    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-6">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
    <?php if (isset($flag_convert) && $flag_convert === true) { ?>
        <div class="col-md-1">
            <div class="mt-checkbox-inline">
                <label class="mt-checkbox mt-checkbox-outline">
                <input type="checkbox" class="convert_checkEnable"> Convert to Final Arrangement
                </label>
            </div>
        </div>
        <div class="col-md-1">
            <button type="submit" class="btn btn-success btn-sm subm_convert" value="subm_convert" disabled>
                <h5 class="m-0 p-0" style="color: black;">Convert<i class="fa fa-return" style="color: black;"></i></h5>
            </button>
        </div>
    <?php } ?>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>

