<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">

            <input type="hidden" name="recurrings_table" id="recurrings_table_placeofdeath" value="first_call_place_of_death">
                <label class="control-label">Place of Death</label>
                <?php
                    $value = (isset($place_of_death['Physician']) ) ? trim($place_of_death['Physician']) : '';
                ?>
                <input type="text" name="POD_Physician" id="POD_Physician" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
                <div class="valid-feedback">
                </div>
                <div class="invalid-feedback">
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label class="control-label">Contact Name</label>
                <?php
                    $value = (isset($place_of_death['ContactName']) ) ? trim($place_of_death['ContactName']) : '';
                ?>
                <input type="text" name="POD_Contact" id="POD_Contact" value="<?php echo $value ?>" class="form-control " placeholder="">
                <div class="valid-feedback">
                </div>
                <div class="invalid-feedback">
                </div>
            </div>
        </div>
    
</div>
<div class="row">
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 1</label>
            <?php
                $value = (isset($place_of_death['Address1']) ) ? trim($place_of_death['Address1']) : '';
            ?>
            <input type="text" name="POD_Address1" value="<?php echo $value ?>" id="POD_Address1" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
                </div>
                <div class="invalid-feedback">
                </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 2</label>
            <?php
                $value = (isset($place_of_death['Address2']) ) ? trim($place_of_death['Address2']) : '';
            ?>
            <input type="text" name="POD_Address2" value="<?php echo $value ?>" id="POD_Address2" class="form-control " placeholder="">
            <div class="valid-feedback">
                </div>
                <div class="invalid-feedback">
                </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">City</label>
            
            <?php
                $value = (isset($place_of_death['City']) ) ? trim($place_of_death['City']) : '';
                $sql = "SELECT * FROM dropdown_city";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="POD_city" id="POD_city" class="form-control required" required>
                    <option hidden>select</option>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">State</label>
            <?php
                $value = (isset($place_of_death['States']) ) ? trim($place_of_death['States']) : '';
            ?>
            <?php
                $value = (isset($place_of_death['States']) ) ? trim($place_of_death['States']) : '';
                $sql = "SELECT * FROM dropdown_state";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="POD_state" id="POD_state" class="form-control required" required>
                    <option hidden>select</option>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Zip</label>
            <?php
                $value = (isset($place_of_death['Zip']) ) ? trim($place_of_death['Zip']) : '';
            ?>
            <?php
                $value = (isset($place_of_death['Zip']) ) ? trim($place_of_death['Zip']) : '';
                $sql = "SELECT * FROM dropdown_zip";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="POD_zip" id="POD_zip" class="form-control required" required>
                    <option hidden>select</option>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<div class="row">
    
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Email</label>
            <?php
                $value = (isset($place_of_death['Email']) ) ? trim($place_of_death['Email']) : '';
            ?>
            <input type="email" name="POD_Email" value="<?php echo $value ?>" id="POD_Email" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
                                                        
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Phone</label>
            <?php
                $value = (isset($place_of_death['officephone']) ) ? trim($place_of_death['officephone']) : '';
            ?>
            <input type="text" name="POD_officephone" value="<?php echo $value ?>" id="POD_officephone" class="form-control required  mask_phone" placeholder="" required>
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>

                                                <!-- Form One Ends -->
                                                
