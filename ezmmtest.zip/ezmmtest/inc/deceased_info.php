<!-- Form One Content Starts -->
<form id="form_deceasedinfo" class="forms_hasphoto" action="savehasphoto.php" method="POST" enctype="multipart/form-data">
<div class = "row">
    <div class = "col-md-9">
        <div class="row">
        <input type="hidden" name="recurrings_table" id="hasphoto_table_deceasedinfo" value="case_bio_deceased_info">
        <input type="hidden" name="caseID" id="caseID">
        <input type="hidden" name="rowId" id="rowId" class="rowId" value="<?php echo ($deceasedResult['id']); ?>">
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">First Name</label>

                    <input type="text" name="DES_firstname" id="DES_firstname" value="<?php echo ($deceasedResult['firstName']); ?>"  class="form-control" required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">Last Name</label>
                    <?php
                        $sql = "SELECT * FROM dropdown_lastname";
                        $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="DES_lastname" id="DES_lastname" class="form-control" required>
                            <option value="0" hidden>select...</option>
                            <?php 
                            while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if($deceasedResult['lastName']===$dropdown_zip_cld['id']){echo 'selected';} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo ('no option to be selected');}?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">Date of Birth</label>
                    
                    <input type="date" name="DES_DOB" id="DES_DOB" value="<?php echo ($deceasedResult['dateOfBirth']); ?>" class="form-control">
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">Date of Death</label>
                    
                    <input type="date" name="DES_DOD" id="DES_DOD" value="<?php echo ($deceasedResult['dateOfDeath']); ?>" class="form-control">
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">Citizenship</label>
            
                    <?php
                    $sql = "SELECT * FROM dropdown_citizenship";
                    $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="DES_citizenship" id="DES_citizenship" class="form-control" required>
                            <option value="0" hidden>select...</option>
                            <?php 
                            while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if($deceasedResult['Citizenship']===$dropdown_zip_cld['id']){echo 'selected';} ?> ><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo ('no option to be selected');}?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">Race</label>
                    
                    <?php
                    $sql = "SELECT * FROM dropdown_race";
                    $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="DES_race" id="DES_race" class="form-control" required>
                            <option value="0" hidden>select...</option>

                            <?php 
                            while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if($deceasedResult['Race']===$dropdown_zip_cld['id']){echo 'selected';} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo (' : no option to be selected');}?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">Religion</label>
                    
                    <?php
                    $sql = "SELECT * FROM dropdown_religion";
                    $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="DES_religion" id="DES_religion" class="form-control" required>
                            <option value="0" hidden>select...</option>
                            <?php 
                            while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if($deceasedResult['Religion']===$dropdown_zip_cld['id']){echo 'selected';} ?> ><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo (' : no option to be selected');}?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Place of Birth</label>
                   
                    <input type="text" name="DES_PlaceOfBirth"  id="DES_PlaceOfBirth" class="form-control" value="<?php echo ($deceasedResult['PlaceOfBirth']); ?>">
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label class="control-label">Ancestry</label>
                    
                    <?php
                    $sql = "SELECT * FROM dropdown_ancestry";
                    $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="DES_ancestry" id="DES_ancestry" class="form-control" required>
                            <option value="0" hidden>select...</option>
                            <?php 
                            while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if($deceasedResult['Ancestry']===$dropdown_zip_cld['id']){echo 'selected';} ?> ><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo (' : no option to be selected');}?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Business</label>
                    
                    <input type="text" name="DES_Business"  id="DES_Business" class="form-control" value="<?php echo ($deceasedResult['Business']); ?>" required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Usual Occupation</label>
                   
                    <?php
                    $sql = "SELECT * FROM dropdown_occupation";
                    $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="DES_occupation" id="DES_occupation" class="form-control" required>
                            <option value="0" hidden>select...</option>
                            <?php 
                            while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if($deceasedResult['States']===$dropdown_zip_cld['id']){echo 'selected';} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo (' : no option to be selected');}?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">In Community Since</label>
                    
                    <input type="text" name="DES_InCommunitySInce"  id="DES_InCommunitySInce" class="form-control" value="<?php echo ($deceasedResult['InCommunitySInce']); ?>" required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Moved From</label>
                
                    <input type="text" name="DES_MovedFrom"  id="DES_MovedFrom" class="form-control" value="<?php echo ($deceasedResult['MovedFrom']); ?>"  required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class = "col-md-3">
        <div class="row">
            <div class="col-sm-12 imgUp">
                <div class="imagePreview uploadedFile_casebiophoto" style="background:url(uploads/casebiophoto/<?php echo ($deceasedResult['Photo']); ?>) no-repeat center center; background-size:auto 100%;"></div>
                <label class="btn btn-primary">
                    Upload<input type="file" name="uploadedFile" id="uploadedFile_casebiophoto" class="uploadedFile_casebiophoto uploadFile img"  style="width: 0px;height: 0px;overflow: hidden;">
                </label>

            </div><!-- col-2 -->
            <!-- <i class="fa fa-plus imgAdd"></i> -->
        </div><!-- row -->
    </div>
</div>
<!-- / -->
<?php if (isset($flag_casebio) && $flag_casebio === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editdeceasedinfo">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_deldeceasedinfo">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-success btn-sm" value="subm_savedeceasedinfo">
           Create
        </button>
    </div>
</div>
<?php } ?>
</form>
<script>
    $(".uploadedFile_casebiophoto").css("background", "url(uploads/casebiophoto/"+<?php echo ($deceasedResult['Photo']); ?>+") no-repeat center center");
    $(".uploadedFile_casebiophoto").css("background-size", "auto 100%");
</script>


<!-- Form One Ends -->
