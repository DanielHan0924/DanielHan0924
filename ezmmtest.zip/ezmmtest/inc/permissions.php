<!--Begin Permissions of First Call-->

<div class="container">
  <h2>Permissions</h2>
  <form>
    <?php
      $value = (isset($permission['pickup']) ) ? trim($permission['pickup']) : '';
    ?>
    <label class="checkbox-inline">
      <input type="checkbox" name="pickup" value="Y" <?php $checked = $value ? "checked" : ""; echo $checked ?>>Body Ready For Pick Up?
    </label>
    
      <?php
      $value = (isset($permission['embalm']) ) ? trim($permission['embalm']) : '';
    ?>
    <label class="checkbox-inline">
      <input type="checkbox" name="embalm" value="Y" <?php $checked = $value ? "checked" : ""; echo $checked ?>>Permission To Embalm?
    </label>
    
      <?php
      $value = (isset($permission['veteran']) ) ? trim($permission['veteran']) : '';
    ?>
    <label class="checkbox-inline">
      <input type="checkbox" name="veteran" value="Y" <?php $checked = $value ? "checked" : ""; echo $checked ?>>Is Veteran?
    </label>
  </form>
</div>