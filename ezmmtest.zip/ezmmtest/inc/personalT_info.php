<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <input type="hidden" name="recurrings_table" id="recurrings_table_preneedpi" value="pre_need_pi">
            <input type="hidden" name="caseID" id="caseID">

            <label class="control-label">Honorific</label>
            <?php
                $sql = "SELECT * FROM dropdown_honorific";
                $result = $conn->query($sql);
                $resultCount = mysqli_num_rows($result);
            ?>
            <?php if ($resultCount > 0) {?>
            <select name="PI_honorificID" id="PI_honorificID" class="form-control required" required>
                <option value="0" hidden>select...</option>
                <?php while($dropdown_honorific = mysqli_fetch_assoc($result)) { ?>
                    <option value="<?php echo ($dropdown_honorific['id']); ?>"><?php echo ($dropdown_honorific['name']); ?></option>
                <?php }?>
            </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">First Name</label>
            <input type="text" name="PI_firstname" id="PI_firstname"  class="form-control"  required>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Middle Name</label>
            <input type="text" name="PI_middlename" id="PI_middlename"  class="form-control " >
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Last Name</label>
            <?php
                $sql = "SELECT * FROM dropdown_lastname";
                $result = $conn->query($sql);
                $resultCount = mysqli_num_rows($result);
            ?>
            <?php if ($resultCount_lastname > 0) {?>
            <select name="PI_lastname" id="PI_lastname" class="form-control" required>
                <option value="0" hidden>select...</option>

                <?php while($dropdown_lastname = mysqli_fetch_assoc($result_dropdownlastname)) { ?>
                    <option value="<?php echo ($dropdown_lastname['id']); ?>"><?php echo ($dropdown_lastname['name']); ?></option>
                <?php }?>
            </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Suffix</label>
            <?php
                $sql = "SELECT * FROM dropdown_suffix";
                $result = $conn->query($sql);
                $resultCount = mysqli_num_rows($result);
            ?>
            <?php if ($resultCount_suffix > 0) {?>
            <select name="PI_suffix" id="PI_suffix" class="form-control required" required>
                <option value="0" hidden>select...</option>
                <?php while($dropdown_suffix = mysqli_fetch_assoc($result_dropdownsuffix)) { ?>
                    <option value="<?php echo ($dropdown_suffix['id']); ?>" ><?php echo ($dropdown_suffix['name']); ?></option>
                <?php }?>
            </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 1</label>
            <input type="text" name="PI_address1"  id="PI_address1" class="form-control" required>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label class="control-label">Date of Birth</label>
            <input type="date" name="PI_dob"  id="PI_dob" class="form-control required mask_date_of_death" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 2</label>
            <?php
                $value = (isset($personal_info['address2']) ) ? trim($personal_info['address2']) : '';
            ?>
            <input type="text" name="PI_address2"  id="PI_address2" class="form-control " >
            <div class="valid-feedback">
                </div>
                <div class="invalid-feedback">
                </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label class="control-label">Township</label>
            <?php
                $sql = "SELECT * FROM dropdown_township";
                $result = $conn->query($sql);
                $resultCount = mysqli_num_rows($result);
            ?>
            <?php if ($resultCount_township > 0) {?>
                <select name="PI_township" id="PI_township" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php while($dropdown_township = mysqli_fetch_assoc($result_dropdowntownship)) { ?>
                        <option value="<?php echo ($dropdown_township['id']); ?>" ><?php echo ($dropdown_township['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">City</label>
            <?php
                $sql = "SELECT * FROM dropdown_city";
                $result = $conn->query($sql);
                $resultCount = mysqli_num_rows($result);
            ?>
            <?php if ($resultCount_city > 0) {?>
                <select name="PI_city" id="PI_city" class="form-control required" required>
                    <option value="0" hidden>select...</option> 
                    <?php while($dropdown_city = mysqli_fetch_assoc($result_dropdowncity)) { ?>
                        <option value="<?php echo ($dropdown_city['id']); ?>"><?php echo ($dropdown_city['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">State</label>
            <?php
                $sql = "SELECT * FROM dropdown_state";
                $result = $conn->query($sql);
                $resultCount = mysqli_num_rows($result);
            ?>
            <?php if ($resultCount_state > 0) {?>
                <select name="PI_state" id="PI_state" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php while($dropdown_state = mysqli_fetch_assoc($result_dropdownstate)) { ?>
                        <option value="<?php echo ($dropdown_state['id']); ?>" ><?php echo ($dropdown_state['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Zip</label>
            <?php
                $sql = "SELECT * FROM dropdown_zip";
                $result = $conn->query($sql);
                $resultCount = mysqli_num_rows($result);
            ?>
            <?php if ($resultCount_zip > 0) {?>
                <select name="PI_zip" id="PI_zip" class="form-control required" required>
                    <option value="0" hidden>select...</option>

                    <?php while($dropdown_zip = mysqli_fetch_assoc($result_dropdownzip)) { ?>
                        <option value="<?php echo ($dropdown_zip['id']); ?>"><?php echo ($dropdown_zip['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">County</label>
            <?php
                $sql = "SELECT * FROM dropdown_county";
                $result = $conn->query($sql);
                $resultCount = mysqli_num_rows($result);
            ?>
            <?php if ($resultCount_county > 0) {?>
                <select name="PI_county" id="PI_county" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php while($dropdown_county = mysqli_fetch_assoc($result_dropdowncounty)) { ?>
                        <option value="<?php echo ($dropdown_county['id']); ?>"><?php echo ($dropdown_county['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Nickname</label>
            <?php
                $value = (isset($personal_info['nickName']) ) ? trim($personal_info['nickName']) : '';
            ?>
            <input type="text" name="PI_nickname"  id="PI_nickname" class="form-control " >
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Gender</label>
            <?php
                $value = (isset($personal_info['gender']) ) ? trim($personal_info['gender']) : '';
            ?>
            <select name="PI_gender" id="PI_gender" class="form-control" required>
                <option  hidden>Select...</option>
                <option value="Male" <?php if ($value == "Male") {echo "selected";}?>>Male</option>
                <option value="Female" <?php if ($value == "Female") {echo "selected";}?>>Female</option>
                <option value="x" <?php if ($value == "x") {echo "selected";}?>>X</option>
            </select>
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">SSN</label>
            <?php
                $value = (isset($personal_info['SSN']) ) ? trim($personal_info['SSN']) : '';
            ?>
            <input type="text" name="PI_ssn"  id="PI_ssn" class="form-control required  mask_ssn" required>
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Email</label>
            <?php
                $value = (isset($personal_info['email']) ) ? trim($personal_info['email']) : '';
            ?>
            <input type="email" name="PI_email"  id="PI_email" class="form-control"  required>
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
                                                        
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Phone</label>
            <?php
                $value = (isset($personal_info['phone']) ) ? trim($personal_info['phone']) : '';
            ?>
            <input type="text" name="PI_phone"  id="PI_phone" class="form-control required  mask_phone"  required>
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
    
</div>
<div class="row" id="PI_hiddendatetime" hidden>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Date of Death</label>
            <?php
                $value = (isset($personal_info['dateOfDeath']) ) ? trim($personal_info['dateOfDeath']) : '';
            ?>
            <input type="date" name="PI_dod" value=" " id="PI_dod" class="form-control required mask_date_of_death" >
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Time of Death</label>
            <?php
                $value = (isset($personal_info['timeOfDeath']) ) ? trim($personal_info['timeOfDeath']) : '';
            ?>
            <input type="time" name="PI_tode" value=" " id="PI_tode" class="form-control required mask_time_of_death" >
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3" id="PI_radio">
        <fieldset class="form-group">
        <legend class="col-form-legend">To</legend>
        <div>
            <div class="form-check">
            <label class="form-check-label" style="margin-right:50px">
            <input class="form-check-input radio-inline" type="radio" name="PI_radio_to" id="PI_radio_at" value="at_need_pi" checked>
            At-Need</label>
            <label class="form-check-label">
            <input class="form-check-input radio-inline" type="radio" name="PI_radio_to" id="PI_radio_first" value="first_call_pi">
            First Call</label>
            </div>
        </div>
        </fieldset>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-6">
    </div>
    <?php if (isset($_SESSION['cancreate']) && $_SESSION['cancreate'] === 'Y') { ?>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <?php } ?>

    <?php if (isset($_SESSION['canupdate']) && $_SESSION['canupdate'] === 'Y') { ?>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <?php } ?>

    <?php if (isset($_SESSION['candelete']) && $_SESSION['candelete'] === 'Y') { ?>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
    <?php } ?>

    <?php if (isset($flag_convert) && $flag_convert === true) { ?>
        <div class="col-md-1">
            <div class="mt-checkbox-inline">
                <label class="mt-checkbox mt-checkbox-outline">
                <input type="checkbox" name="PI_checkEnable" id="PI_checkEnable">  Convert 
                </label>
            </div>
        </div>
        
        <div class="col-md-1">
            <button type="submit" class="btn btn-success btn-sm subm_convert" value="subm_convert" disabled>
                <h5 class="m-0 p-0" style="color: black;">Convert<i class="fa fa-return" style="color: black;"></i></h5>
            </button>
        </div>
    <?php } ?>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>
<!-- Form One Ends -->
                                                