<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group"> 

            <input type="hidden" name="recurrings_table" id="recurrings_table_atneedpi" value="<?php if(isset($flag_firstcall) && $flag_firstcall == true) {echo ('first_call_pi');} else { echo ('at_need_pi');} ?>">
            <input type="hidden" name="caseID" id="caseID">
            <input type="hidden" name="PF_radio_to" value="case_bio_deceased_info">

            <label class="control-label">Honorific</label>

            <?php
                $sql = "SELECT * FROM dropdown_honorific";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="PF_honorific" id="PF_honorific" class="form-control" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">First Name</label>
            <?php
                $value = (isset($personal_info['firstName']) ) ? trim($personal_info['firstName']) : '';
            ?>
            <input type="text" name="PF_firstname" id="PF_firstname" value="<?php echo $value ?>" class="form-control required "  required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Middle Name</label>
            <?php
                $value = (isset($personal_info['middleName']) ) ? trim($personal_info['middleName']) : '';
            ?>
            <input type="text" name="PF_middlename" id="PF_middlename" value="<?php echo $value ?>" class="form-control " >
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Last Name</label>
            <div class="row">
            <div class="col-md-8">

            <?php
                $sql = "SELECT * FROM dropdown_lastname";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="PF_lastName" id="PF_lastName" class="form-control" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{ ?>
                <select name="PF_lastName" id="PF_lastName" class="form-control" required>
                    <option value="0" hidden>select...</option>
                </select>
            <?php } ?>
            </div>
            <div class="col-md-1">
            <a href="managedropdowns.php" alt="Planets"><i class="fa fa-plus p-1 m-2" style="color: green; background: white; font-size: 15px;"></i></a>

            </div>
            </div>
        </div>

    </div>
    <!-- <div class="col-md-1">
        <label class="control-label" >Add new last name</label>
        <a href="" data-toggle="modal" data-target="#modal_totalspecial"><i class="fa fa-plus p-1 m-2" style="color: white; background: black; font-size: 10px;"></i></a>
    </div> -->
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Suffix</label>
    
            <?php
                $sql = "SELECT * FROM dropdown_suffix";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="PF_suffix" id="PF_suffix" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 1</label>
            <?php
                $value = (isset($personal_info['address1']) ) ? trim($personal_info['address1']) : '';
            ?>
            <input type="text" name="PF_address1" id="PF_address1" value="<?php echo $value ?>" id="Address1" class="form-control"  required>
            <div class="valid-feedback">
                </div>
                <div class="invalid-feedback">
                </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label class="control-label">Date of Birth</label>
            <?php
                $value = (isset($personal_info['dateOfBirth']) ) ? trim($personal_info['dateOfBirth']) : '';
            ?>
            <input type="date" name="PF_dob" value=" " id="PF_dob" class="form-control mask_date_of_death" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 2</label>
            <?php
                $value = (isset($personal_info['address2']) ) ? trim($personal_info['address2']) : '';
            ?>
            <input type="text" name="PF_address2" id="PF_address2" value="<?php echo $value ?>" id="Address2" class="form-control " >
            <div class="valid-feedback">
                </div>
                <div class="invalid-feedback">
                </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label class="control-label">Township</label>
            
            <?php
                $sql = "SELECT * FROM dropdown_township";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="PF_township" id="PF_township" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">City</label>
           
            <?php
                $sql = "SELECT * FROM dropdown_city";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="PF_city" id="PF_city" class="form-control" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">State</label>
            
            <?php
                $sql = "SELECT * FROM dropdown_state";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="PF_state" id="PF_state" class="form-control" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Zip</label>
            
            <?php
                $sql = "SELECT * FROM dropdown_zip";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="PF_zip" id="PF_zip" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">County</label>
           
            <?php
                $sql = "SELECT * FROM dropdown_county";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="PF_county" id="PF_county" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Nickname</label>
            <?php
                $value = (isset($personal_info['nickName']) ) ? trim($personal_info['nickName']) : '';
            ?>
            <input type="text" name="PF_nickname" value="<?php echo $value ?>" id="PF_nickname" class="form-control " >
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Gender</label>
            <?php
                $value = (isset($personal_info['gender']) ) ? trim($personal_info['gender']) : '';
            ?>
            <select name="PF_gender" id="PF_gender" class="form-control required " required>
                <option value="">Select</option>
                <option value="Male" <?php if ($value == "Male") {echo "selected";}?>>Male</option>
                <option value="Female" <?php if ($value == "Female") {echo "selected";}?>>Female</option>
                <option value="x" <?php if ($value == "x") {echo "selected";}?>>X</option>
            </select>
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">SSN</label>
            <?php
                $value = (isset($personal_info['SSN']) ) ? trim($personal_info['SSN']) : '';
            ?>
            <input type="text" name="PF_ssn" value="<?php echo $value ?>" id="PF_ssn" class="form-control required  mask_ssn" required>
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Email</label>
            <?php
                $value = (isset($personal_info['email']) ) ? trim($personal_info['email']) : '';
            ?>
            <input type="email" name="PF_email" value="<?php echo $value ?>" id="PF_email" class="form-control required "  required>
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>                                                    
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Phone</label>
            <?php
                $value = (isset($personal_info['phone']) ) ? trim($personal_info['phone']) : '';
            ?>
            <input type="text" name="PF_phone" value="<?php echo $value ?>" id="PF_phone" class="form-control required  mask_phone"  required>
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Date of Death</label>
            <?php
                $value = (isset($personal_info['dateOfDeath']) ) ? trim($personal_info['dateOfDeath']) : '';
            ?>
            <input type="date" name="PF_dod" value="<?php echo $value ?>" id="PF_dod" class="form-control required mask_date_of_death"  required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Time of Death</label>
            <?php
                $value = (isset($personal_info['timeOfDeath']) ) ? trim($personal_info['timeOfDeath']) : '';
            ?>
            <input type="time" name="PF_tode" value="<?php echo $value ?>" id="PF_tode" class="form-control required mask_time_of_death"  required>
            <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-6">
    </div>
    <?php if (isset($_SESSION['cancreate']) && $_SESSION['cancreate'] === 'Y') { ?>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <?php } ?>

    <?php if (isset($_SESSION['canupdate']) && $_SESSION['canupdate'] === 'Y') { ?>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <?php } ?>

    <?php if (isset($_SESSION['candelete']) && $_SESSION['candelete'] === 'Y') { ?>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
    <?php } ?>
    <?php if (isset($flag_convert_fc) && $flag_convert_fc === true) { ?>
        <div class="col-md-2">
            <button type="submit" class="btn btn-success btn-sm subm_convert_fc" value="subm_convert_firstcall" >
                <h5 class="m-0 p-0" style="color: black;">Convert to First Call<i class="fa fa-return" style="color: black;"></i></h5>
            </button>
        </div>
    <?php } ?>
    <?php if (isset($flag_convert_casebio) && $flag_convert_casebio === true) { ?>
        <div class="col-md-2">
            <button type="submit" class="btn btn-success btn-sm subm_convert" value="subm_convert" >
                <h5 class="m-0 p-0" style="color: black;">Convert to Case Bio<i class="fa fa-return" style="color: black;"></i></h5>
            </button>
        </div>
    <?php } ?>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>
<script>

</script>
<!-- Form One Ends -->
                                                