<form class="forms_hasphoto" action="savehasphoto.php" method="POST" enctype="multipart/form-data">

<div class="row">
        <?php if(isset($flag_setting) && $flag_setting == true) {
            $tbl_name =  'users';
        } else if(isset($flag_final) && $flag_final == true){
            $tbl_name =  'users';
        }   
        ?>
    <input type="hidden" name="recurrings_table" id="hasphoto_table_adminstaff" value="<?php echo $tbl_name; ?>">
    <div class="col-md-4 col-lg-4 col-sm-4">
        <div class="form-group">
            <label>Staff Name</label>
            <input type="text" class="form-control" name="STFF_name" id="STFF_name">
        </div>
    </div>
    <div class="col-md-4 col-lg-4 col-sm-4">
        <div class="form-group">
            <label for="personalemail">Personal Email</label>
            <input type="text" class="form-control" name="STFF_email" id="STFF_email" >
        </div>
    </div>
    <div class="col-md-4 col-lg-4 col-sm-4">
        <div class="form-group">
            <label for="companyemail">Company Email</label>
            <input type="text" class="form-control" name="STFF_email2" id="STFF_email2" >
        </div>
    </div>
</div>
<div class = "row">
    <div class="col-md-9 col-lg-9 col-sm-9">
        <div class="form-group">
            <label for="address1_admin">Address 1</label>
            <input type="text" class="form-control" name="STFF_address1" id="STFF_address1" >
        </div>
    </div>
    <div class="col-md-3 col-lg-3 col-sm-3" style="background-color:gold">
        <label for="permissions">Permissions</label>
        <div class="row">
            <div class="col-md-3 col-lg-3 col-sm-3">
                <input type="checkbox" class="form-control " name="STFF_canC" id="STFF_canC" >
                <small class="form-text  text-center">Create</small>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-3">
                <input type="checkbox" class="form-control " name="STFF_canR" id="STFF_canR" >
                <small class="form-text text-center">Read</small>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-3">
                <input type="checkbox" class="form-control" name="STFF_canU" id="STFF_canU" >
                <small class="form-text text-center">Update</small>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-3">
                <input type="checkbox" class="form-control" name="STFF_canD" id="STFF_canD" >
                <small class="form-text text-center">Delete</small>  
            </div>
        </div>
    </div>
</div>                     
<div class="row">
    <div class="col-md-9">
        <div class = "row">
            <div class="col-md-12 col-lg-12 col-sm-12">
                <div class="form-group">
                    <label for="address2_admin">Address 2</label>
                    <input type="text" class="form-control" name="STFF_address2" id="STFF_address2" >
                </div>
            </div>
        </div>
        <div class = "row">
            <div class="col-md-3 col-lg-3 col-sm-3">
                <div class="form-group">
                    <label for="city">City</label>
                    <?php
                    $sql = "SELECT * FROM dropdown_city";
                    $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="STFF_city" id="STFF_city" class="form-control" >
                            <option value="0" hidden>select...</option>
                            <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo ('no option to be selected');}?>
                </div>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-3">
                <div class="form-group">
                    <label for="stateselectoption">State</label>
                    <?php
                    $sql = "SELECT * FROM dropdown_state";
                    $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="STFF_state" id="STFF_state" class="form-control" >
                            <option value="0" hidden>select...</option>
                            <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo ('no option to be selected');}?>
                </div>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-3">
                <div class="form-group">
                    <label for="zipselectoption">Zip</label>
                    <?php
                    $sql = "SELECT * FROM dropdown_zip";
                    $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="STFF_zip" id="STFF_zip" class="form-control" >
                            <option value="0" hidden>select...</option>
                            <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo ('no option to be selected');}?>
                </div>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-3">
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" name="STFF_phone" id="STFF_phone" >
                </div>
            </div>
        </div>
        <div class = "row">
            <div class="col-md-2 col-lg-2 col-sm-2">
                <div class="form-group">
                    <label class="control-label">Hire Date</label>
                    <input type="date" name="STFF_hiredate" id="STFF_hiredate" class="form-control required mask_date_of_death" required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-lg-2 col-sm-2">
                <div class="form-group">
                    <label class="control-label">Termination Date</label>
                    <input type="date" name="STFF_termidate" id="STFF_termidate" class="form-control required mask_date_of_death" required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-lg-2 col-sm-2">
                <div class="form-group">
                    <label for="license">License</label>
                    <input type="text" class="form-control" name="STFF_license" id="STFF_license" >
                </div>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-3">
                <div class="form-group">
                    <label class="control-label">License Valid Through</label>
                    <input type="date" name="STFF_licenseddate" id="STFF_licenseddate" class="form-control required mask_date_of_death"  required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-3">
                <div class="form-group">
                    <label for="zipselectoption">State Licensed</label>
                    <?php
                    $sql = "SELECT * FROM dropdown_state";
                    $result = $conn->query($sql);
                    ?>
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <select name="STFF_state2" id="STFF_state2" class="form-control" >
                            <option value="0" hidden>select...</option>
                            <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['name']); ?></option>
                            <?php }?>
                        </select>
                    <?php } else{echo ('no option to be selected');}?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-11">
                <div class="form-group">
                    <label class="control-label">Note</label>
                    <textarea id="STFF_note" name="STFF_note" rows="4" style="width: 100%">
                    </textarea>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="row mt-2">
            <div class="col-sm-12 imgUp">
                <div class="imagePreview uploadedFile_staffphoto"></div>
                <label class="btn btn-primary">
                    Upload Photo<input type="file" name="uploadedFile" id="uploadedFile_staffphoto" class="uploadedFile_staffphoto uploadFile img " style="width: 0px;height: 0px;overflow: hidden;">
                </label>
            </div><!-- col-2 -->
            <!-- <i class="fa fa-plus imgAdd"></i> -->
        </div><!-- row -->
    </div>
</div>
 
<?php if (isset($flag_useradmin) && $flag_useradmin === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-success btn-sm" value="subm_saverecurring">
           Create
        </button>
    </div>
</div>
<?php } ?>
</form>