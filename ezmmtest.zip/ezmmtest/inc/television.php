<!-- Form One Content Starts -->
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Television Station</label>
            <input type="text" name="television" id="television" value="" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Email</label>
            <input type="email" name="Email" value="" id="Email" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Fax Number</label>
            <input type="text" name="fax" value="" id="fax" class="form-control required  mask_phone" placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Contact Name</label>
            <input type="text" name="NContact" id="NContact" value="" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label class="control-label">Contact Phone</label>
                <input type="phone" name="NUserName" id="NUserName" value="" class="form-control required " placeholder="" required>
                <div class="valid-feedback">
                </div>
                <div class="invalid-feedback">
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="form-group">
                <label class="control-label">Rate Per Spot</label>
                <input type="text" name="Rrate" id="Rrate" pattern="^\$\d{1,3}(,\d{3})*(\.\d+)?$" value="" data-type="currency" placeholder="$000.00">
                <div class="valid-feedback">
                </div>
                <div class="invalid-feedback">
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label class="control-label">Week Day Deadline</label>
                <input type="time" name="WDeadline" id="WDeadline">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label class="control-label">Weekend Deadline</label>
                <input type="time" name="WDeadline" id="WDeadline">
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="d-block text-center card-footer">
                    <button type="button" class="btn-wide btn btn-warning pull-left">Add Radio Station</button>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>
