<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">

            <input type="hidden" name="recurrings_table" id="recurrings_table_grandchildren" value="case_bio_grand_children">
            <label class="control-label">Full Name</label>
            <?php
                $value = (isset($grandChildren['fullname']) ) ? trim($grandChildren['fullname']) : '';
            ?>
            <input type="text" name="GCLD_FullName" id="GCLD_FullName" value="<?php echo $value ?>" class="form-control" placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>

</div>
<div class="row">
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 1</label>
            <?php
                $value = (isset($grandChildren['address1']) ) ? trim($grandChildren['address1']) : '';
            ?>
            <input type="text" name="GCLD_Address1" value="<?php echo $value ?>" id="GCLD_Address1" class="form-control  " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 2</label>
            <?php
                $value = (isset($grandChildren['address2']) ) ? trim($grandChildren['address2']) : '';
            ?>
            <input type="text" name="GCLD_Address2" value="<?php echo $value ?>" id="GCLD_Address2" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">City</label>

            <?php
                $value = (isset($grandChildren['city']) ) ? trim($grandChildren['city']) : 1;
                $sql = "SELECT * FROM dropdown_city";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="GCLD_City" id="GCLD_City"class="form-control required" required>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">State</label>

            <?php
                $value = (isset($grandChildren['states']) ) ? trim($grandChildren['states']) : 1;
                $sql = "SELECT * FROM dropdown_state";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="GCLD_State" id="GCLD_State" class="form-control required" required>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Zip</label>
        
            <?php
                $value = (isset($grandChildren['zip']) ) ? trim($grandChildren['zip']) : 1;
                $sql = "SELECT * FROM dropdown_zip";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="GCLD_Zip" id="GCLD_Zip" class="form-control required" required>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Date Of Birth</label>
            <?php
                $value = (isset($grandChildren['dob']) ) ? trim($grandChildren['dob']) : '';
            ?>
            <input type="date" name="GCLD_DOB" value="<?php echo $value ?>" id="GCLD_DOB" class="form-control datepicker">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Relationship</label>
        
            <?php
                $value = (isset($grandChildren['relationship']) ) ? trim($grandChildren['relationship']) : 1;
                $sql = "SELECT * FROM dropdown_relationship";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="GCLD_relationship" id="GCLD_relationship" class="form-control required" required>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Email</label>
            <?php
                $value = (isset($grandChildren['email']) ) ? trim($grandChildren['email']) : '';
            ?>
            <input type="email" name="GCLD_Email" value="<?php echo $value ?>" id="GCLD_Email" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Primary Phone</label>
            <?php
                $value = (isset($grandChildren['phone']) ) ? trim($grandChildren['phone']) : '';
            ?>
            <input type="text" name="GCLD_phone" value="<?php echo $value ?>" id="GCLD_phone" class="form-control mask_phone" placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Secondary Phone</label>
            <?php
                $value = (isset($grandChildren['phone2']) ) ? trim($grandChildren['phone2']) : '';
            ?>
            <input type="text" name="GCLD_phone2" value="<?php echo $value ?>" id="GCLD_phone2" class="form-control mask_phone2" placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>

<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>
<!-- Form One Ends -->
