<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">
<style>
.input-group .form-control, .intl-tel-input { width: 100%; }
</style>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <input type="hidden" name="recurrings_table" id="recurrings_table" value="contractor">

            <label class="control-label">Funeral Home</label>
            <?php
                $value = (isset($contractors['funeralhome']) ) ? trim($contractors['funeralhome']) : '';
            ?>
            <input type="text" name="CNTR_funeralhome" id="CNTR_funeralhome" value="<?php echo $value ?>" class="form-control  " required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Full Name</label>
            <?php
                $value = (isset($contractors['fullname']) ) ? trim($contractors['fullname']) : '';
            ?>
            <input type="text" name="CNTR_fullname" id="CNTR_fullname" value="<?php echo $value ?>" class="form-control" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>

</div>
<div class="row">
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 1</label>
            <?php
                $value = (isset($contractors['address1']) ) ? trim($contractors['address1']) : '';
            ?>
            <input type="text" name="CNTR_address1" value="<?php echo $value ?>" id="CNTR_address1" class="form-control  " required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 2</label>
            <?php
                $value = (isset($contractors['address2']) ) ? trim($contractors['address2']) : '';
            ?>
            <input type="text" name="CNTR_address2" value="<?php echo $value ?>" id="CNTR_address2" class="form-control "required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">City</label>
            
            <?php
                $value = (isset($contractors['city']) ) ? trim($contractors['city']) : '';
                $sql = "SELECT * FROM dropdown_city";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="CNTR_city" id="CNTR_city"  class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($value == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">State</label>
           
            <?php
                $value = (isset($contractors['states']) ) ? trim($contractors['states']) : '';
                $sql = "SELECT * FROM dropdown_state";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="CNTR_state" id="CNTR_state" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($value == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Zip</label>
            
            <?php
                $value = (isset($contractors['zip']) ) ? trim($contractors['zip']) : '';
                $sql = "SELECT * FROM dropdown_zip";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="CNTR_zip" id="CNTR_zip" class="form-control required" required>
                    <option value="test" hidden>select...</option>
                    <option value="test1" hidden>tst</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($value == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">State License</label>
            <?php
                $value = (isset($contractors['statelicense']) ) ? trim($contractors['statelicense']) : '';
            ?>
            <input type="text" name="CNTR_statelicense" value="<?php echo $value ?>" id="CNTR_statelicense" class="form-control datepicker" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">State Issued</label>
            <?php
                $value = (isset($contractors['stateissued']) ) ? trim($contractors['stateissued']) : '';
            ?>
            <input type="text" name="CNTR_stateissued" value="<?php echo $value ?>" id="CNTR_stateissued" class="form-control" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Email</label>
            <?php
                $value = (isset($contractors['email']) ) ? trim($contractors['email']) : '';
            ?>
            <input type="email" name="CNTR_email" value="<?php echo $value ?>" id="CNTR_email" class="form-control " required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Primary Phone</label>
            <?php
                $value = (isset($contractors['phone']) ) ? trim($contractors['phone']) : '';
            ?>
            <input type="tel" name="CNTR_phone" value="<?php echo $value ?>" id="CNTR_phone" class="form-control mask_phone" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Secondary Phone</label>
            <?php
                $value = (isset($contractors['phone2']) ) ? trim($contractors['phone2']) : '';
            ?>
            <input type="tel" name="CNTR_phone2" value="<?php echo $value ?>" id="CNTR_phone2" class="form-control mask_phone2" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="container">
        <h2>Type of Contractor</h2>
        <div>
            <?php
            $value = (isset($contractors['bodypickkup']) ) ? trim($contractors['bodypickkup']) : '';
            ?>
            <label class="checkbox-inline">  
                <input type="checkbox" name="CNTR_bodypickkup" id="CNTR_bodypickkup" value="" padding="10px" > Body Pick Up?
            </label>
            <?php
            $value = (isset($contractors['embalm']) ) ? trim($contractors['embalm']) : '';
            ?>
            <label class="checkbox-inline">
                <input type="checkbox" name="CNTR_embalm" id="CNTR_embalm" value="" padding="10px" > Embalm?
            </label>
    
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>
<!-- Form One Ends -->
