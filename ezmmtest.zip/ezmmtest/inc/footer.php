<div class="app-wrapper-footer " >
                <div class="app-footer">
                    <div class="app-footer__inner">
                        <div class="app-footer-left">
                            <ul class="nav">
                                <li class="nav-item">
                                    
                                        &copy; <?php echo date('Y',time()); ?> All rights reserved.
                                    
                                </li>
                            </ul>
                        </div>
                        <div class="app-footer-right">
                            <ul class="nav">
                                <li class="nav-item">
                                    Developed By
                                    <a href="https://www.ezmmsoftware.com">
                                        EZMM Software, LLC
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>    
        </div>
    </div>
</div>

<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script> -->
<!-- <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script> -->

<script src="scripts/database.js"></script>
<script src="./assets/scripts/custom.js"></script>

<!-- <script src="./assets/scripts/database.js"></script>    -->
</body>
</html>