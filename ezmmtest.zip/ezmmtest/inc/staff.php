<!-- Form One Content Starts -->
<div class="row">
    <div class="col-md-9">
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Staff Name</label>
                    <?php
                        $value = (isset($staff['FirstName']) ) ? trim($staff['FirstName']) : '';
                    ?>
                    <input type="text" name="STF_name" id="STF_name" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Personal Email</label>
                    <?php
                        $value = (isset($staff['PersonalEmail']) ) ? trim($staff['PersonalEmail']) : '';
                    ?>
                    <input type="email" name="STF_email" value="<?php echo $value ?>" id="STF_email" class="form-control required " placeholder="" required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">Company Email</label>
                    <?php
                        $value = (isset($staff['CompanyEmail']) ) ? trim($staff['CompanyEmail']) : '';
                    ?>
                    <input type="email" name="STF_email2" value="<?php echo $value ?>" id="STF_email2" class="form-control required " placeholder="" required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8">
                <div class="form-group">
                    <label class="control-label">Address 1</label>
                    <?php
                        $value = (isset($staff['Address1']) ) ? trim($staff['Address1']) : '';
                    ?>
                    <input type="text" name="STF_address1" value="<?php echo $value ?>" id="STF_address1" class="form-control required " placeholder="" required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="form-group">
                    <label class="control-label">Address 2</label>
                    <?php
                        $value = (isset($staff['Address2']) ) ? trim($staff['Address2']) : '';
                    ?>
                    <input type="text" name="STF_address2" value="<?php echo $value ?>" id="STF_address2" class="form-control " placeholder="">
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label">City</label>
                    <?php
                        $sql = "SELECT * FROM dropdown_city";
                        $result = $conn->query($sql);
                        $resultCount = mysqli_num_rows($result);
                    ?>
                    <?php if ($resultCount > 0) {?>
                    <select name="STF_city" id="STF_city" class="form-control" required>
                        <option value="0" hidden>select...</option>
                        <?php while($dropdown_honorific = mysqli_fetch_assoc($result)) { ?>
                            <option value="<?php echo ($dropdown_honorific['id']); ?>" ><?php echo ($dropdown_honorific['name']); ?></option>
                        <?php }?>
                    </select>
                    <?php } else{echo ('no option to be selected');}?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">State</label>
                    <?php
                        $sql = "SELECT * FROM dropdown_state";
                        $result = $conn->query($sql);
                        $resultCount = mysqli_num_rows($result);
                    ?>
                    <?php if ($resultCount > 0) {?>
                    <select name="STF_state" id="STF_state" class="form-control" required>
                        <option value="0" hidden>select...</option>
                        <?php while($dropdown_honorific = mysqli_fetch_assoc($result)) { ?>
                            <option value="<?php echo ($dropdown_honorific['id']); ?>" ><?php echo ($dropdown_honorific['name']); ?></option>
                        <?php }?>
                    </select>
                    <?php } else{echo ('no option to be selected');}?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">Zip</label>
                    <?php
                        $sql = "SELECT * FROM dropdown_zip";
                        $result = $conn->query($sql);
                        $resultCount = mysqli_num_rows($result);
                    ?>
                    <?php if ($resultCount > 0) {?>
                    <select name="STF_zip" id="STF_zip" class="form-control" required>
                        <option value="0" hidden>select...</option>
                        <?php while($dropdown_honorific = mysqli_fetch_assoc($result)) { ?>
                            <option value="<?php echo ($dropdown_honorific['id']); ?>" ><?php echo ($dropdown_honorific['name']); ?></option>
                        <?php }?>
                    </select>
                    <?php } else{echo ('no option to be selected');}?>
                </div>

            </div>

            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">Phone</label>
                    <?php
                        $value = (isset($staff['phone']) ) ? trim($staff['phone']) : '';
                    ?>
                    <input type="text" name="STF_phone" value="<?php echo $value ?>" id="STF_phone" class="form-control required  mask_phone" placeholder="" required>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">Hire Date</label>
                    <?php
                        $value = (isset($staff['HireDate']) ) ? trim($staff['HireDate']) : '';
                    ?>
                    <input type="date" name="STF_hiredate" value="<?php echo $value ?>" id="STF_hiredate" class="form-control required mask_date_of_death" placeholder="" required>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">Termination Date</label>
                    <?php
                        $value = (isset($staff['TerminationDate']) ) ? trim($staff['TerminationDate']) : '';
                    ?>
                    <input type="date" name="STF_termdate" value="<?php echo $value ?>" id="STF_termdate" class="form-control required mask_date_of_death" placeholder="" required>

                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">License</label>
                    <?php
                        $value = (isset($staff['License']) ) ? trim($staff['License']) : '';
                    ?>
                    <input type="text" name="STF_license" value="<?php echo $value ?>" id="STF_license" class="form-control required mask_zip" placeholder="" required>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">License Valid Through</label>
                    <?php
                        $value = (isset($staff['LicValidDate']) ) ? trim($staff['LicValidDate']) : '';
                    ?>
                    <input type="date" name="STF_LicValidDate" value="<?php echo $value ?>" id="STF_LicValidDate" class="form-control required mask_date_of_death" placeholder="" required>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label class="control-label">State Licensed</label>
                    <?php
                        $value = (isset($staff['StateLicensed']) ) ? trim($staff['StateLicensed']) : '';
                    ?>
                    <input type="text" name="STF_statelicensed" value="<?php echo $value ?>" id="STF_statelicensed" class="form-control required mask_zip" placeholder="" required>
                </div>
            </div>         
        </div>
    </div>
    <div class="col-md-3">
        <!-- <div class="image-holder">
            <a id="" href="" class="" data-toggle="modal" data-target="#modal-condizioni">
                <img style="width: 200px;" class="testimageview" src="assets/images/avatars/Member.png" />
            </a>
        </div> -->
    </div>
</div>



    <!-- Form One Ends -->
