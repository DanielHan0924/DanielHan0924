<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">
        <input type="hidden" name="recurrings_table" id="recurrings_table_parentinfo"  value="case_bio_parents">

            <label class="control-label">Father's Name</label>
            <input type="text" name="PAI_fatherName" id="PAI_fatherName"  class="form-control">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Father's date of birth</label>
            <input type="date" name="PAI_FDOB" id="PAI_FDOB" class="form-control datepicker">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Father's Place Of Birth</label>
            <input type="text" name="PAI_FPlaceOfBirth" id="PAI_FPlaceOfBirth"  class="form-control">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Mother's Name</label>
            <input type="text" name="PAI_motherName" id="PAI_motherName"  class="form-control">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Mother's Maiden Name</label>
            <input type="text" name="PAI_maidenName" id="PAI_maidenName"  class="form-control">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Mother's date of birth</label>
            <input type="date" name="PAI_MDOB" id="PAI_MDOB" class="form-control datepicker">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Mother's Place Of Birth</label>
            <input type="text" name="PAI_MPlaceOfBirth" id="PAI_MPlaceOfBirth"  class="form-control">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>

<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php }?>
</form>
