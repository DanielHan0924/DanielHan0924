<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">

            <input type="hidden" name="recurrings_table" id="recurrings_table_nextofkin" value="<?php if(isset($flag_atneed) && $flag_atneed == true) {echo ('at_need_nok');} else { echo ('pre_need_nok');} ?>">
            <label class="control-label">Full Name</label>
            <input type="text" name="NOK_fullname" id="NOK_fullname"  class="form-control" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
    
<div class="row">
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 1</label>
            <input type="text" name="NOK_address1"  id="NOK_address1" class="form-control " required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 2</label>
            <input type="text" name="NOK_address2"  id="NOK_address2" class="form-control ">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">City</label>
        
            <?php
                $sql = "SELECT * FROM dropdown_city";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="NOK_city" id="NOK_city" class="form-control " required>
                <option value="0" hidden>select...</option>

                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">State</label>
         
            <?php
                $sql = "SELECT * FROM dropdown_state";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="NOK_state" id="NOK_state" class="form-control " required>
                <option value="0" hidden>select...</option>

                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Zip</label>
            
            <?php
                $sql = "SELECT * FROM dropdown_zip";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="NOK_zip" id="NOK_zip" class="form-control " required>
                <option value="0" hidden>select...</option>

                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    
  <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Relationship</label>
           
            <?php
                $value = (isset($next_of_kin['relationship']) ) ? trim($next_of_kin['relationship']) : 1;
                $sql = "SELECT * FROM dropdown_relationship";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="NOK_relationship" id="NOK_relationship" class="form-control " required>
                <option value="0" hidden>select...</option>

                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($value == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Primary Phone</label>
            <?php
                $value = (isset($next_of_kin['phone']) ) ? trim($next_of_kin['phone']) : '';
            ?>
            <input type="text" name="NOK_phone"  id="NOK_phone" class="form-control mask_phone" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Secondary Phone</label>
            <?php
                $value = (isset($next_of_kin['phone2']) ) ? trim($next_of_kin['phone2']) : '';
            ?>
            <input type="text" name="NOK_phone2"  id="NOK_phone2" class="form-control mask_phone2">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Email</label>
            <?php
                $value = (isset($next_of_kin['email']) ) ? trim($next_of_kin['email']) : '';
            ?>
            <input type="email" name="NOK_email"  id="NOK_email" class="form-control mask_email" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3" id="NOK_radio" hidden>
        <fieldset class="form-group">
        <legend class="col-form-legend">To</legend>
        <div>
            <div class="form-check">
            <label class="form-check-label" style="margin-right:50px">
            <input class="form-check-input radio-inline" type="radio" name="NOK_radio_to" id="NOK_radio_at" value="at_need_nok" checked>
            At-Need</label>
            <label class="form-check-label">
            <input class="form-check-input radio-inline" type="radio" name="NOK_radio_to" id="NOK_radio_surv" value="surviving_relative">
            Surviving Relative</label>
            </div>
        </div>
        </fieldset>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-6">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
    <?php if (isset($flag_convert) && $flag_convert === true) { ?>
        <div class="col-md-1">
            <div class="mt-checkbox-inline">
                <label class="mt-checkbox mt-checkbox-outline">
                <input type="checkbox" name="NOK_checkEnable" id="NOK_checkEnable">  Convert 
                </label>
            </div>
        </div>
        
        <div class="col-md-1">
            <button type="submit" class="btn btn-success btn-sm subm_convert" value="subm_convert" disabled>
                <h5 class="m-0 p-0" style="color: black;">Convert<i class="fa fa-return" style="color: black;"></i></h5>
            </button>
        </div>
    <?php } else if (isset($flag_convert_surv) && $flag_convert_surv === true) { ?>
        <div class="col-md-2">
            <button type="submit" class="btn btn-success btn-sm subm_convert_fc" value="subm_convert_surv" >
                <h5 class="m-0 p-0" style="color: black;">Convert<i class="fa fa-return" style="color: black;"></i></h5>
            </button>
        </div>
    <?php } ?>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>

<!-- Form One Ends -->
