<!-- Form One Content Starts -->
<div class="row">

    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Facilities &amp; Services</label>
            <?php
                $value = (isset($facilities['Service']) ) ? trim($facilities['Service']) : '';
            ?>
            <input type="text" name="FAC_Service[]" id="ProfessionalService" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Price</label>
            <?php
                $value = (isset($facilities['Price']) ) ? trim($facilities['Price']) : '';
            ?>
            <input type="text" name="FAC_Price[]" id="currency-field" pattern="^\$\d{1,3}(,\d{3})*(\.\d+)?$" value="<?php echo $value ?>" data-type="currency" placeholder="$000.00">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Permanent</label>
            <?php
                $value = (isset($facilities['Permanent']) ) ? trim($facilities['Permanent']) : '';
            ?>
            <input type="checkbox" name="FAC_Permanent[]" id="IsPerm" value="Y" class="form-control required " placeholder="" required <?php $checked = $value=="Y" ? "checked" : ""; echo $checked ?>>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    
</div>
<!-- Form One Ends -->