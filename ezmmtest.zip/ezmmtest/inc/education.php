<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
        <?php if(isset($flag_casebio) && $flag_casebio == true) {
            $tbl_name =  'case_bio_education';
        } else if(isset($flag_final) && $flag_final == true){
            $tbl_name =  'final_arrange_education';
        } else { $tbl_name = 'pre_need_education';}     
        ?>
            <input type="hidden" name="recurrings_table" id="recurrings_table_education" value="<?php echo $tbl_name; ?>">
            <label class="control-label">High School</label>
            <?php
                $value = (isset($education['EduHighSchool']) ) ? trim($education['EduHighSchool']) : '';
                $sql = "SELECT * FROM dropdown_highschool";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="EDU_highschool" id="EDU_highschool" class="form-control required" required>
                    <option hidden>select...</option>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label" for="EduHSGraduated">Graduated</label><br />
            <?php
                $value = (isset($education['EduHSGraduated']) ) ? trim($education['EduHSGraduated']) : '';
            ?>
            <input type="checkbox" value="" name="EDU_EduHSGraduated" id="EDU_EduHSGraduated" <?php if ($value == "Y") {echo "checked";}?>> 
        </div>
    </div>
</div> 
<div class="row">
    <div class="col-md-5">
        <div class="form-group">
            <label class="control-label">Undergraduate Name</label>
            
             <?php
                $value = (isset($education['undergraducate']) ) ? trim($education['undergraducate']) : '';
                $sql = "SELECT * FROM dropdown_undergraduatename";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="EDU_undergraduatename" id="EDU_undergraduatename" class="form-control required" required>
                    <option hidden>select...</option>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-5">
        <div class="form-group">
            <label class="control-label">Undergraduate Degree</label>
            <?php
                $value = (isset($education['undergraducatedegree']) ) ? trim($education['undergraducatedegree']) : '';
            ?>
            <input type="text" name="EDU_undergraducatedegree" id="EDU_undergraducatedegree" value="<?php echo $value ?>" class="form-control  " placeholder="" >
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label" for="undergraducatedegreecheck">Graduated</label><br/>
            <?php
                $value = (isset($education['undergraducatedegreecheck']) ) ? trim($education['undergraducatedegreecheck']) : '';
            ?>
            <input type="checkbox" value="" name="EDU_undergraducatedegreecheck" id="EDU_undergraducatedegreecheck" <?php if ($value == "Y") {echo "checked";}?>>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Graduate Name</label>
           
           <?php
                $value = (isset($education['graduate']) ) ? trim($education['graduate']) : '';
                $sql = "SELECT * FROM dropdown_graduatename";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="EDU_graduatename" id="EDU_graduatename" class="form-control required" required>
                    <option hidden>select...</option>

                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Graduate Degree</label>
            <?php
                $value = (isset($education['graducatedegree']) ) ? trim($education['graducatedegree']) : '';
            ?>
            <input type="text" name="EDU_graducatedegree" id="EDU_graducatedegree" value="<?php echo $value ?>" class="form-control  " placeholder="" >
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label" for="graducatedegreecheck">Graduated</label><br />
            <?php
                $value = (isset($education['graducatedegreecheck']) ) ? trim($education['graducatedegreecheck']) : '';
            ?>
            <input type="checkbox" value="" name="EDU_graducatedegreecheck" id="EDU_graducatedegreecheck" class="" <?php if ($value == "Y") {echo "checked";}?>>
        </div>
    </div>
    <div class="col-md-3 table_radio" hidden>
        <fieldset class="form-group">
        <legend class="col-form-legend">To</legend>
        <div>
            <div class="form-check">
            <label class="form-check-label" style="margin-right:50px">
            <input class="form-check-input radio-inline" type="radio" name="EDU_radio_to" value="case_bio_education" checked>
            Case Bio</label>
            <label class="form-check-label">
            <input class="form-check-input radio-inline" type="radio" name="EDU_radio_to" value="final_arrange_education">
            Final Arrangement</label>
            </div>
        </div>
        </fieldset>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-6">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
    <?php if (isset($flag_convert) && $flag_convert === true) { ?>
        <div class="col-md-1">
            <div class="mt-checkbox-inline">
                <label class="mt-checkbox mt-checkbox-outline">
                <input type="checkbox" class="convert_checkEnable"> Convert 
                </label>
            </div>
        </div>
        <div class="col-md-1">
            <button type="submit" class="btn btn-success btn-sm subm_convert" value="subm_convert" disabled>
                <h5 class="m-0 p-0" style="color: black;">Convert<i class="fa fa-return" style="color: black;"></i></h5>
            </button>
        </div>
    <?php } ?>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>
<!-- Form One Ends -->
                                                