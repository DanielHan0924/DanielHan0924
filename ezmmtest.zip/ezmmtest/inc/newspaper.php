<!-- Form One Content Starts -->
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Newspaper</label>
            <?php
                $value = (isset($media['Newspaper']) ) ? trim($media['Newspaper']) : '';
            ?>
            <input type="text" name="Newspaper[]" id="Newspaper" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Email</label>
            <?php
                $value = (isset($media['Email']) ) ? trim($media['Email']) : '';
            ?>
            <input type="email" name="Email[]" value="<?php echo $value ?>" id="Email" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Fax Number</label>
            <?php
                $value = (isset($media['fax']) ) ? trim($media['fax']) : '';
            ?>
            <input type="text" name="fax[]" value="<?php echo $value ?>" id="fax" class="form-control required  mask_phone" placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Website </label>
            <?php
                $value = (isset($media['website']) ) ? trim($media['website']) : '';
            ?>
            <input type="text" name="website[]" value="<?php echo $value ?>" id="website" class="form-control required  mask_phone" placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">UserName</label>
            <?php
                $value = (isset($media['NUserName']) ) ? trim($media['NUserName']) : '';
            ?>
            <input type="text" name="NUserName[]" id="NUserName" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Password</label>
            <?php
                $value = (isset($media['Npass']) ) ? trim($media['Npass']) : '';
            ?>
            <input type="text" name="Npass[]" value="<?php echo $value ?>" id="Npass" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Rate Per Word</label>
            <?php
                $value = (isset($media['Nrate']) ) ? trim($media['Nrate']) : '';
            ?>
            <input type="text" name="Nrate[]" id="Nrate" pattern="^\$\d{1,3}(,\d{3})*(\.\d+)?$" value="<?php echo $value ?>" data-type="currency" placeholder="$000.00">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label for="img">Select image:</label>
            <input type="file" id="img" name="img" accept="image/*">
        </div>
        <div class="invalid-feedback">
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Week Day Deadline</label>
            <?php
                $value = (isset($media['WDDeadline']) ) ? trim($media['WDDeadline']) : '';
            ?>
            <input type="time" name="WDDeadline[]" id="WDeadline" value="<?php echo $value ?>">
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Weekend Deadline</label>
            <?php
                $value = (isset($media['WDeadline']) ) ? trim($media['WDeadline']) : '';
            ?>
            <input type="time" name="WDeadline[]" id="WDeadline"value="<?php echo $value ?>">
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Contact Name &amp; Phone</label>
            <?php
                $value = (isset($media['NContact']) ) ? trim($media['NContact']) : '';
            ?>
            <input type="text" name="NContact[]" id="NContact" value="<?php echo $value ?>" class="form-control required " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    
</div>
<div class="row">
    <div class="col-md-12"> 
        <?php
            $value = (isset($media['obituraryContent']) ) ? trim($media['obituraryContent']) : '';
        ?>
        <textarea type="text" name="obituraryContent[]" class="form-control" style="width:100%;resize:none;height:80px !important;" placeholder="Enter Obituary Here..."><?php echo $value ?></textarea>
    </div>
</div><br>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
