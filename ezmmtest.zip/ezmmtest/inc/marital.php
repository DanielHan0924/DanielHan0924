<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">
        <?php if(isset($flag_casebio) && $flag_casebio == true) {
            $tbl_name =  'case_bio_marital';
        } else if(isset($flag_final) && $flag_final == true){
            $tbl_name =  'final_arrange_marital';
        } else { $tbl_name = 'pre_need_marital';}     
        ?>
            <input type="hidden" name="recurrings_table" id="recurrings_table_marital" value="<?php echo $tbl_name; ?>">

            <label class="control-label">Marital Status</label>
            <select name="MS_MaritalStatus" id="MS_MaritalStatus" class="form-control" required>
                <option value="0" hidden>Select...</option>
                <option value="Single" >Single</option>
                <option value="Married" >Married</option>
                <option value="Never Marrieds">Never Marrieds</option>
                <option value="Divorced">Divorced</option>
            </select>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Place of Marriage</label>
            <?php
                $value = (isset($marital_status['placeofmarriage']) ) ? trim($marital_status['placeofmarriage']) : '';
            ?>
            <input type="text" name="MS_PlaceOfMarriage" id="MS_PlaceOfMarriage" value="<?php echo $value ?>" class="form-control required " required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Date of Marriage</label>
            <?php
                $value = (isset($marital_status['dateofmarriage']) ) ? trim($marital_status['dateofmarriage']) : '';
            ?>
            <input type="date" name="MS_DateOfMarriage" id="MS_DateOfMarriage" value="<?php echo $value ?>" class="form-control ">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Spouse's Name</label>
            <?php
                $value = (isset($marital_status['spousesname']) ) ? trim($marital_status['spousesname']) : '';
            ?>
            <input type="text" name="MS_SpousesName" value="<?php echo $value ?>" id="MS_SpousesName" class="form-control required " required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Spouse Deceased</label>
            <?php
                $value = (isset($marital_status['Spousedeceased']) ) ? trim($marital_status['Spousedeceased']) : '';
            ?>
            <input type="checkbox" name="MS_SpouseDeceased" value="<?php echo $value;?>" id="MS_SpouseDeceased" class="form-control " <?php if ($value == "Y") {echo "checked";}?>>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>

    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Spouse Date of Death</label>
            <?php
                    $value = (isset($marital_status['dateofdeath']) ) ? trim($marital_status['dateofdeath']) : '';
                ?>
            <input type="date" name="MS_SDateOfDeath" id="MS_SDateOfDeath" value="<?php echo $value ?>" class="form-control ">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Spouse's Place of Death</label>
            <?php
                $value = (isset($marital_status['spousesplaceofdeath']) ) ? trim($marital_status['spousesplaceofdeath']) : '';
            ?>
            <input type="text" name="MS_SpousesPlaceOfDeath" value="<?php echo $value ?>" id="MS_SpousesPlaceOfDeath" class="form-control">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3 table_radio" id="MS_radio" hidden>
        <fieldset class="form-group">
        <legend class="col-form-legend">To</legend>
        <div>
            <div class="form-check">
            <label class="form-check-label" style="margin-right:50px">
            <input class="form-check-input radio-inline" type="radio" name="MS_radio_to" id="MS_radio_cb" value="case_bio_marital" checked>
            Case Bio</label>
            <label class="form-check-label">
            <input class="form-check-input radio-inline" type="radio" name="MS_radio_to" id="MS_radio_final" value="final_arrange_marital">
            Final Arrangement</label>
            </div>
        </div>
        </fieldset>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-6">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
    <?php if (isset($flag_convert) && $flag_convert === true) { ?>
        <div class="col-md-1">
            <div class="mt-checkbox-inline">
                <label class="mt-checkbox mt-checkbox-outline">
                <input type="checkbox" name="MS_checkEnable" id="MS_checkEnable" class="convert_checkEnable">  Convert 
                </label>
            </div>
        </div>
        
        <div class="col-md-1">
            <button type="submit" class="btn btn-success btn-sm subm_convert" value="subm_convert" disabled>
                <h5 class="m-0 p-0" style="color: black;">Convert<i class="fa fa-return" style="color: black;"></i></h5>
            </button>
        </div>
    <?php } ?>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>
<!-- Form One Ends -->
