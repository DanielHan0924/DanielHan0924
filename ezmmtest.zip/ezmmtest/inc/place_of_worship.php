<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">
        <?php if(isset($flag_casebio) && $flag_casebio == true) {
            $tbl_name =  'case_bio_place_of_worship';
        } else if(isset($flag_final) && $flag_final == true){
            $tbl_name =  'final_arrange_place_of_worship';
        } else { $tbl_name = 'pre_need_place_of_worship';}     
        ?>
            <input type="hidden" name="recurrings_table" id="recurrings_table_placeofworship" value="<?php echo $tbl_name; ?>">
            <label class="control-label">Place of Worship</label>
            <?php
                $value = (isset($place_of_worship['PlaceOfWorship']) ) ? trim($place_of_worship['PlaceOfWorship']) : '';
            ?>
            <input type="text" name="POW_PlaceOfWorship" id="POW_PlaceOfWorship" value="<?php echo $value ?>" class="form-control  " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
        <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Clergy Name</label>
            <?php
                $value = (isset($place_of_worship['ClergyName']) ) ? trim($place_of_worship['ClergyName']) : '';
            ?>
            <input type="text" name="POW_ClergyName" id="POW_ClergyName" value="<?php echo $value ?>" class="form-control  " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>

</div>

<div class="row">
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 1</label>
            <?php
                $value = (isset($place_of_worship['Address1']) ) ? trim($place_of_worship['Address1']) : '';
            ?>
            <input type="text" name="POW_Address1" value="<?php echo $value ?>" id="POW_Address1" class="form-control  " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 2</label>
            <?php
                $value = (isset($place_of_worship['Address2']) ) ? trim($place_of_worship['Address2']) : '';
            ?>
            <input type="text" name="POW_Address2" value="<?php echo $value ?>" id="POW_Address2" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">City</label>
            <?php
                $value = (isset($place_of_worship['city']) ) ? trim($place_of_worship['city']) : '';
                $sql = "SELECT * FROM dropdown_city";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="POW_City" id="POW_City" class="form-control required" required>
                    <option hidden>select</option>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">State</label>
            <?php
                $value = (isset($place_of_worship['states']) ) ? trim($place_of_worship['states']) : '';
                $sql = "SELECT * FROM dropdown_state";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="POW_State" id="POW_State" class="form-control required" required>
                    <option hidden>select</option>

                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Zip</label>

            <?php
                $value = (isset($place_of_worship['zip']) ) ? trim($place_of_worship['zip']) : '';
                $sql = "SELECT * FROM dropdown_zip";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="POW_Zip" id="POW_Zip" class="form-control required" required>
                     <option hidden>select</option>

                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Email</label>
            <?php
                $value = (isset($place_of_worship['email']) ) ? trim($place_of_worship['email']) : '';
            ?>
            <input type="email" name="POW_Email" value="<?php echo $value ?>" id="POW_Email" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Primary Phone</label>
            <?php
                $value = (isset($place_of_worship['phone']) ) ? trim($place_of_worship['phone']) : '';
            ?>
            <input type="text" name="POW_phone" value="<?php echo $value ?>" id="POW_phone" class="form-control mask_phone" placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Secondary Phone</label>
            <?php
                $value = (isset($place_of_worship['phone2']) ) ? trim($place_of_worship['phone2']) : '';
            ?>
            <input type="text" name="POW_phone2" value="<?php echo $value ?>" id="POW_phone2" class="form-control mask_phone2" placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3 table_radio" hidden>
        <fieldset class="form-group">
        <legend class="col-form-legend">To</legend>
        <div>
            <div class="form-check">
            <label class="form-check-label" style="margin-right:50px">
            <input class="form-check-input radio-inline" type="radio" name="POW_radio_to" value="case_bio_place_of_worship" checked>
            Case Bio</label>
            <label class="form-check-label">
            <input class="form-check-input radio-inline" type="radio" name="POW_radio_to" value="final_arrange_place_of_worship">
            Final Arrangement</label>
            </div>
        </div>
        </fieldset>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-6">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
    <?php if (isset($flag_convert) && $flag_convert === true) { ?>
        <div class="col-md-1">
            <div class="mt-checkbox-inline">
                <label class="mt-checkbox mt-checkbox-outline">
                <input type="checkbox" class="convert_checkEnable"> Convert 
                </label>
            </div>
        </div>
        <div class="col-md-1">
            <button type="submit" class="btn btn-success btn-sm subm_convert" value="subm_convert" disabled>
                <h5 class="m-0 p-0" style="color: black;">Convert<i class="fa fa-return" style="color: black;"></i></h5>
            </button>
        </div>
    <?php } ?>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>
<!-- Form One Ends -->
