<div class="table-responsive">
<?php if ($casesResultCount > 0) { ?> 

    <table class="align-middle mb-0 table table-borderless table-striped table-hover">
        <thead>
        <tr>
            <th class="text-center">CaseID</th>
            <th class="text-center">Date</th>
            <th class="text-center">First</th>
            <th class="text-center">Last</th>
            <th class="text-center">DOB</th>
            <th class="text-center">DOD</th>
            <th class="text-center">Age</th>
            <th class="text-center">Status</th>
            <th class="text-center">Status DT</th>
            <th class="text-center">Staff ID</th>
            <th class="text-center">ToDo List</th>
            <th class="text-center">Action</th>
            <th class="text-center">CaseBio</th>
        </tr>
        </thead>
        <tbody>
        <?php while($case_row = mysqli_fetch_assoc($casesResult)) { ?>
            <form class="forms_superrow" action="saveuserinfo.php" method="POST"> <?php
            switch ($case_row['status']) {
                case 'Pre-Need':
                    # code...
                    $redirect_filename = 'pre_need.php';
                    $status_table = 'pre_need_pi';
                    $sql = "SELECT * FROM pre_need_pi WHERE caseID='".$case_row['id']."';";
                    break;
                case 'At-Need':
                    # code...
                    $redirect_filename = 'at_need.php';
                    $status_table = 'at_need_pi';
                    $sql = "SELECT * FROM at_need_pi WHERE caseID='".$case_row['id']."';";
                    break;
                case 'First-Call':
                    # code...
                    $redirect_filename = 'first_call.php';
                    $status_table = 'first_call_pi';
                    $sql = "SELECT * FROM first_call_pi WHERE caseID='".$case_row['id']."';";
                    break;
                case 'Case-Bio':
                    # which table is available in this case??? Below will cause error with mismatched field name
                    $redirect_filename = 'case_bio.php';
                    $status_table = 'case_bio_deceased_info';
                    $sql = "SELECT * FROM case_bio_deceased_info WHERE caseID='".$case_row['id']."';";
                    break;
                case 'Final-Arrangements':
                    # which table is available in this case???
                    $redirect_filename = 'final_arrangement.php';
                    $status_table = '';
                    break;
                default:
                    # code...
                    break;
            }
            $result = $conn->query($sql);
            if (mysqli_num_rows($result) > 0) {
                $case_row_info = mysqli_fetch_assoc($result);
            }
            $caseID = (isset($case_row['id']) ) ? trim($case_row['id']) : '';
            $createdDate = (isset($case_row['createddate']) ) ? trim($case_row['createddate']) : '';
            $status = (isset($case_row['status']) ) ? trim($case_row['status']) : '';
            $statusDT = 'Body Pickup';
            $firstName = (isset($case_row_info['firstName']) ) ? trim($case_row_info['firstName']) : '';
            $lastNameID = (isset($case_row_info['lastName']) ) ? trim($case_row_info['lastName']) : '';
                $sql = "SELECT name FROM dropdown_lastname WHERE id='".$lastNameID."';";
                $result = mysqli_fetch_array($conn->query($sql));
                $lastName = $result['name'];
            $dateofBirth = (isset($case_row_info['dateOfBirth']) ) ? trim($case_row_info['dateOfBirth']) : '';
            $dateofDeath = (isset($case_row_info['dateOfDeath']) ) ? trim($case_row_info['dateOfDeath']) : '';
            $ageAtDeath = '--';
            if ($dateofBirth!='' && $dateofDeath!='') {
                $dateOfDeath_obj = new DateTime($dateofDeath);
                $dateOfBirth_obj = new DateTime($dateofBirth);
                $ageAtDeath = $dateOfBirth_obj->diff($dateOfDeath_obj)->format('%y years');
            }  
            ?>
        <tr id="DASH_tr<?php echo $caseID; ?>">
            <input type="hidden" name="DASH_caseid" id="DASH_caseid" value="<?php echo $caseID; ?>">
            <input type="hidden" name="caseinfo_table" id="caseinfo_table_status" value="<?php echo $status_table; ?>">

            <td class="text-center text-muted"><?php echo $caseID; ?></td>
            <td class="text-center text-muted"><?php echo $createdDate; ?></td>
            <td class="text-center"><?php echo $firstName; ?></td>
            <td class="text-center"><?php echo $lastName; ?></td>
            <td class="text-center"><?php echo $dateofBirth; ?></td>
            <td class="text-center"><?php echo $dateofDeath; ?></td>
            <td class="text-center"><?php echo $ageAtDeath; ?></td>
            <td class="text-center">
                <?php
                $sql = "SELECT * FROM dropdown_status";
                $result = $conn->query($sql);
                ?>
                <?php if (mysqli_num_rows($result) > 0) { ?>
                    <select name="DASH_status" class="form-control" required>
                        <option value="0" hidden>select...</option>
                        <?php 
                        while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                            ?>
                            <option value="<?php echo ($dropdown_zip_cld['name']); ?>" <?php if ($status == $dropdown_zip_cld['name']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                        <?php }?>
                    </select>
                <?php } else{echo ('no status to be selected');}?>
            </td>
            <td class="text-center">
            <?php
                $sql = "SELECT * FROM dropdown_statusdt";
                $result = $conn->query($sql);
                ?>
                <?php if (mysqli_num_rows($result) > 0) { ?>
                    <select name="DASH_statusdt" class="form-control" required>
                        <option value="0" hidden>select...</option>
                        <?php 
                        while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                            ?>
                            <option value="<?php echo ($dropdown_zip_cld['name']); ?>" <?php if ($statusDT == $dropdown_zip_cld['name']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                        <?php }?>
                    </select>
                <?php } else{echo ('no status to be selected');}?>
            </td>
            <td class="text-center"><?php echo $case_row['staffID']; ?></td>
            <td class="text-center">
                <button type="button" data-placement="bottom" class="btn-shadow mr-1 btn btn-sm btn-todolist" value="<?php echo $caseID; ?>">
                    <img width="30" class="" src="assets/images/icons/todo.png" alt="Todolist">
                </button>
            </td>
            <td class="text-center">
                <!-- <a href="<?php echo $redirect_filename; ?>" class="mr-2"> -->
                    <button type="submit" data-placement="bottom" class="btn-shadow mr-1 btn btn-success btn-sm btn-editstatus" value="<?php echo $case_row['status']; ?>">
                        <i class="fa fa-pencil fa-1x"></i>
                    </button>
                <!-- </a> -->
                
                <button type="submit" data-placement="bottom" class="btn-shadow mr-1 btn btn-danger btn-sm btn-delcase" value="subm_delcase">
                    <i class="fa fa-trash fa-1x"></i>
                </button>
                <button type="button" data-placement="bottom" class="btn-shadow mr-1 btn btn-primary btn-sm btn-confirmstatus" value="<?php echo $caseID; ?>">
                    <i class="fa fa-check fa-1x"></i>
                </button>
            </td>
            <td class="text-center">
                <a href="#" class="mr-2">
                <?php if (isset($case_row_info['Photo'])) {?>
                    <img width="35" class="" src="uploads/casebiophoto/<?php echo $case_row_info['Photo']; ?>" alt="Case Bio">
                <?php }?>
                </a>
            </td>
        </tr>
        </form>

        <?php }?>
        </tbody>
    </table>
<?php } else {echo ('<h3>    No cases ordered until now.  </h3>');}?>

</div>
<div class="d-block text-center card-footer">
    <a href="first_call.php" class="mr-2">
        <button class="btn-wide btn btn-primary">ADD FIRST CALL</button>
    </a>
    <a href="pre_need.php" class="mr-2">
        <button class="btn-wide btn btn-success">ADD PRE NEED</button>
    </a>
</div>
<script>
    $(".btn-todolist").click(function(e) {
        var status = e.currentTarget.value;
        localStorage.setItem("caseID", status);
        $.ajax({
            type: "POST",
            url: "saveNewtask.php",
            dataType: 'json',
            data: {"selectedcaseID":status, "postaction":"setcaseID"},
            success: function(result) {
                console.log(result);
                if(result.status == 'setcaseid'){
                    alert('You will redirect to ToDolist UI with caseID = '+result.caseid+'.');
                    location.assign("toDoList.php");
                }
            },
            error: function(result) {
                alert(result.status);
                console.log(result);
            }
        })

    });
   
    $(".btn-confirmstatus").click(function(e) {
        var status = e.currentTarget.value;
        alert('The row for caseID = '+status+'will be archived!');
        $("#DASH_tr"+status).prop('hidden', true);
    });
</script>