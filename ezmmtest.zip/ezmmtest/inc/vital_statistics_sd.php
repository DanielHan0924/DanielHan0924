    <!-- BEGIN CONTENT BODY -->
    <div class="page-content" style="min-height:1056px">
        
        
        
        <!-- page mm start-->
        
         <h3 class="form-section">State of South Dakota Vital Statistics</h3>
         <div class="row">
         	<div class="col-md-12"></div>
            <div class="col-md-12">
            	<fieldset>
                	<legend><h5 class="statistics_form_sub_title">Decedent</h5></legend>
                    
                    <div class="row">
                    	<div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">First Name</label>
                                <?php
                                    $value = (isset($distric['FirstName']) ) ? trim($distric['FirstName']) : '';
                                ?>
                                <input type="text" name="FirstName" class="form-control" value="<?php echo $value ?>" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABHklEQVQ4EaVTO26DQBD1ohQWaS2lg9JybZ+AK7hNwx2oIoVf4UPQ0Lj1FdKktevIpel8AKNUkDcWMxpgSaIEaTVv3sx7uztiTdu2s/98DywOw3Dued4Who/M2aIx5lZV1aEsy0+qiwHELyi+Ytl0PQ69SxAxkWIA4RMRTdNsKE59juMcuZd6xIAFeZ6fGCdJ8kY4y7KAuTRNGd7jyEBXsdOPE3a0QGPsniOnnYMO67LgSQN9T41F2QGrQRRFCwyzoIF2qyBuKKbcOgPXdVeY9rMWgNsjf9ccYesJhk3f5dYT1HX9gR0LLQR30TnjkUEcx2uIuS4RnI+aj6sJR0AM8AaumPaM/rRehyWhXqbFAA9kh3/8/NvHxAYGAsZ/il8IalkCLBfNVAAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Middle Name</label>
                                <?php
                                    $value = (isset($distric['MiddleName']) ) ? trim($distric['MiddleName']) : '';
                                ?>
                                <input type="text" name="MiddleName" class="form-control" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Decedent's Last Name</label>
                                <?php
                                    $value = (isset($distric['LastName']) ) ? trim($distric['LastName']) : '';
                                ?>
                                <input type="text" name="LastName" class="form-control" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Suffix</label>
                                <?php
                                    $value = (isset($distric['Suffix']) ) ? trim($distric['Suffix']) : '';
                                ?>
                                <select name="Suffix" class="form-control select2-suffix">
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Nickname/Alias</label>
                                <?php
                                    $value = (isset($distric['NickName']) ) ? trim($distric['NickName']) : '';
                                ?>
                                <input type="text" name="NickName" class="form-control" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Sex</label>
                                <?php
                                    $value = (isset($distric['GenderID']) ) ? trim($distric['GenderID']) : '';
                                ?>
                                <select name="GenderID" class="form-control">
                                	<option value="2" <?php if ($value == "2") {echo "selected";}?>>Male</option>
                                    <option value="1" <?php if ($value == "1") {echo "selected";}?>>Female</option>
                                    <option value="3" <?php if ($value == "3") {echo "selected";}?>>X</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">SSN</label>
                                <?php
                                    $value = (isset($distric['SSN']) ) ? trim($distric['SSN']) : '';
                                ?>
                                <input type="text" name="SSN" class="form-control" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Time of Death</label>
                                <?php
                                    $value = (isset($distric['TimeOfDeath']) ) ? trim($distric['TimeOfDeath']) : '';
                                ?>
                                <input type="text" name="TimeOfDeath" class="form-control timepicker-default" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Range of Time of Death</label>
                                <?php
                                    $value = (isset($distric['RangeTimeOfDead']) ) ? trim($distric['RangeTimeOfDead']) : '';
                                ?>
                                <input type="text" name="RangeTimeOfDead" class="form-control" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Time Found</label>
                                <?php
                                    $value = (isset($distric['TimeFound']) ) ? trim($distric['TimeFound']) : '';
                                ?>
                                <input type="text" name="TimeFound" class="form-control timepicker-default" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Date of Death</label>
                                <?php
                                    $value = (isset($distric['DateOfDeath']) ) ? trim($distric['DateOfDeath']) : '';
                                ?>
                                <input type="text" name="DateOfDeath" class="form-control datepicker" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Indicator</label>
                                <?php
                                    $value = (isset($distric['Indicator']) ) ? trim($distric['Indicator']) : '';
                                ?>
                                <select name="Indicator" class="form-control">
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Date of Birth</label>
                                <?php
                                    $value = (isset($distric['dateOfBirth']) ) ? trim($distric['dateOfBirth']) : '';
                                ?>
                                <input type="text" name="dateOfBirth" class="form-control datepicker" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Age</label>
                                <?php
                                    $value = (isset($distric['age']) ) ? trim($distric['age']) : '';
                                ?>
                                <input type="text" name="age" class="form-control" value="<?php echo $value ?>">
                            </div>
                        </div>
                    </div>
                    
                </fieldset>
                
                
                
                
                
                
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Facility</h5></legend>
                    
                    <div class="row">
                    	<div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Place of Death</label>
                                <?php
                                    $value = (isset($distric['PlaceOfDeathID']) ) ? trim($distric['PlaceOfDeathID']) : '';
                                ?>
                                <select name="PlaceOfDeathID" class="form-control select2-pod">
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">&nbsp;</label>
                                <?php
                                    $value = (isset($distric['Place']) ) ? trim($distric['Place']) : '';
                                ?>
                                <input type="text" name="Place" class="form-control" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Facility Name</label>
                                <?php
                                    $value = (isset($distric['facility_name']) ) ? trim($distric['facility_name']) : '';
                                ?>
                                <input type="text" name="facility_name" class="form-control" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">City</label>
                                <?php
                                    $value = (isset($distric['CityID']) ) ? trim($distric['CityID']) : '';
                                ?>
                                <select name="CityID" class="form-control select2-city select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-t0-container"><span class="select2-selection__rendered" id="select2-CityID-t0-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">&nbsp;</label>
                                <?php
                                    $value = (isset($distric['City']) ) ? trim($distric['City']) : '';
                                ?>
                                <input type="text" name="City" class="form-control" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">State</label>
                                <?php
                                    $value = (isset($distric['StateID']) ) ? trim($distric['StateID']) : '';
                                ?>
                                <select name="StateID" class="form-control select2-state select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-StateID-lc-container"><span class="select2-selection__rendered" id="select2-StateID-lc-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">&nbsp;</label>
                                <?php
                                    $value = (isset($distric['State']) ) ? trim($distric['State']) : '';
                                ?>
                                <input type="text" name="State" class="form-control" value="<?php echo $value ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">ZipCode</label>
                                <?php
                                    $value = (isset($distric['ZipCodeID']) ) ? trim($distric['ZipCodeID']) : '';
                                ?>
                                <select name="ZipCodeID" class="form-control select2-zipcode select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-ZipCodeID-89-container"><span class="select2-selection__rendered" id="select2-ZipCodeID-89-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Country</label>
                                <?php
                                    $value = (isset($distric['CountryID']) ) ? trim($distric['CountryID']) : '';
                                ?>
                                <select name="CountryID" class="form-control select2-country select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CountryID-5d-container"><span class="select2-selection__rendered" id="select2-CountryID-5d-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="form-group">
                                <label class="form-label">Country FIP'S</label>
                                <?php
                                    $value = (isset($distric['CountryFIPS']) ) ? trim($distric['CountryFIPS']) : '';
                                ?>
                                <input type="text" name="CountryFIPS" class="form-control" value="<?php echo $value ?>">
                            </div>
                        </div>
                       
                    </div>
                    
                </fieldset>
                
                
                
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Armed Services?</h5></legend>
                    
                    <div class="row">
                    	<div class="col-md-3">
                        	<div class="form-group">
                                <?php
                                    $value = (isset($distric['armed_service']) ) ? trim($distric['armed_service']) : '';
                                ?>
                                <input type="checkbox" name="armed_service" value="Y" <?php $checked = $value ? "checked" : ""; echo $checked ?>>  &nbsp;&nbsp;<label class="form-label">Armed Services ?</label>
                            </div>
                        </div>
                   </div>
                </fieldset>
                
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Disposition</h5></legend>
                    	<div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Method of Dispostion</label>
                                    <?php
                                        $value = (isset($distric['dispositioni_method_of_disposition']) ) ? trim($distric['dispositioni_method_of_disposition']) : '';
                                    ?>
                                    <select name="dispositioni_method_of_disposition" class="form-control">
                                    </select>
                                </div>
                            </div>
						</div>
                        <div class="row">
                        	<div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Crematory Name</label>
                                    <?php
                                        $value = (isset($distric['disposition_crematory_name']) ) ? trim($distric['disposition_crematory_name']) : '';
                                    ?>
                                    <select name="disposition_crematory_name" class="form-control">
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">&nbsp; </label>
                                    <?php
                                        $value = (isset($distric['disposition_crematory_name2']) ) ? trim($distric['disposition_crematory_name2']) : '';
                                    ?>
                                    <input name="disposition_crematory_name2" value="<?php echo $value ?>" class="form-control" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">City</label>
                                    <?php
                                        $value = (isset($distric['disposition_city1']) ) ? trim($distric['disposition_city1']) : '';
                                    ?>
                                    <select name="disposition_city1" class="form-control select2-city select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                    </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-89-container"><span class="select2-selection__rendered" id="select2-CityID-89-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Country</label>
                                    <?php
                                        $value = (isset($distric['disposition_country1']) ) ? trim($distric['disposition_country1']) : '';
                                    ?>
                                    <select name="disposition_country1" class="form-control select2-country select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                    </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-i3-container"><span class="select2-selection__rendered" id="select2-CityID-i3-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">State</label>
                                    <?php
                                        $value = (isset($distric['disposition_state1']) ) ? trim($distric['disposition_state1']) : '';
                                    ?>
                                    <select name="disposition_state1" class="form-control select2-state select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                    </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-9x-container"><span class="select2-selection__rendered" id="select2-CityID-9x-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                </div>
                            </div>
                        </div>     
                        <div class="row">
                        	<div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Place of Disposition</label>
                                    <?php
                                        $value = (isset($distric['disposition_place_of_disposition']) ) ? trim($distric['disposition_place_of_disposition']) : '';
                                    ?>
                                    <select name="disposition_place_of_disposition" class="form-control">
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">&nbsp; </label>
                                    <?php
                                        $value = (isset($distric['disposition_place_of_disposition2']) ) ? trim($distric['disposition_place_of_disposition2']) : '';
                                    ?>
                                    <input name="disposition_place_of_disposition2" value="<?php echo $value ?>" class="form-control" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">City</label>
                                    <?php
                                        $value = (isset($distric['disposition_city2']) ) ? trim($distric['disposition_city2']) : '';
                                    ?>
                                    <select name="disposition_city2" class="form-control select2-city select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                    </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-tk-container"><span class="select2-selection__rendered" id="select2-CityID-tk-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Country</label>
                                    <?php
                                        $value = (isset($distric['disposition_country2']) ) ? trim($distric['disposition_country2']) : '';
                                    ?>
                                    <select name="disposition_country2" class="form-control select2-country select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                    </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-ab-container"><span class="select2-selection__rendered" id="select2-CityID-ab-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">State</label>
                                    <?php
                                        $value = (isset($distric['disposition_state2']) ) ? trim($distric['disposition_state2']) : '';
                                    ?>
                                    <select name="disposition_state2" class="form-control select2-state select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                    </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-1e-container"><span class="select2-selection__rendered" id="select2-CityID-1e-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                </div>
                            </div>
                        </div>                    
               </fieldset>
               <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Funeral Home Information</h5></legend>
                    <div class="row">
                        	<div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Funeral Home</label>
                                    <?php
                                        $value = (isset($distric['funeral_home1']) ) ? trim($distric['funeral_home1']) : '';
                                    ?>
                                    <select name="funeral_home1" class="form-control">
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">&nbsp; </label>
                                    <?php
                                        $value = (isset($distric['funeral_home2']) ) ? trim($distric['funeral_home2']) : '';
                                    ?>
                                    <input name="funeral_home2" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">City</label>
                                    <?php
                                        $value = (isset($distric['funeral_city']) ) ? trim($distric['funeral_city']) : '';
                                    ?>
                                    <select name="funeral_city" class="form-control select2-city select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                    </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-uv-container"><span class="select2-selection__rendered" id="select2-CityID-uv-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Country</label>
                                    <?php
                                        $value = (isset($distric['funeral_country']) ) ? trim($distric['funeral_country']) : '';
                                    ?>
                                    <select name="funeral_country" class="form-control select2-country select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                    </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-od-container"><span class="select2-selection__rendered" id="select2-CityID-od-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">State</label>
                                    <?php
                                        $value = (isset($distric['funeral_state']) ) ? trim($distric['funeral_state']) : '';
                                    ?>
                                    <select name="funeral_state" class="form-control select2-state select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                    </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 246px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-2m-container"><span class="select2-selection__rendered" id="select2-CityID-2m-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                </div>
                            </div>
                        </div>     
                        <div class="row">
                        	<div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label"> F.Director Assigned</label>
                                    <?php
                                        $value = (isset($distric['funeral_director1']) ) ? trim($distric['funeral_director1']) : '';
                                    ?>
                                    <select name="funeral_director1" class="form-control">
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">&nbsp; </label>
                                    <?php
                                        $value = (isset($distric['funeral_director2']) ) ? trim($distric['funeral_director2']) : '';
                                    ?>
                                    <input name="funeral_director2" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">F.Director's License</label>
                                    <?php
                                        $value = (isset($distric['funeral_director_license']) ) ? trim($distric['funeral_director_license']) : '';
                                    ?>
                                    <input name="funeral_director_license" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Funeral Home Number</label>
                                    <?php
                                        $value = (isset($distric['funeral_home_number']) ) ? trim($distric['funeral_home_number']) : '';
                                    ?>
                                    <input name="funeral_home_number" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                                </div>
                            </div>
                        </div> 
                        
               </fieldset> 
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Assignments</h5></legend>
                    	<div class="row">
                        	<div class="col-md-3">
                                <div class="form-group">
                                    <label class="form-label"> Certifier type (P-Physician C-Coroner)</label>
                                    <?php
                                        $value = (isset($distric['assignment_certifier_type']) ) ? trim($distric['assignment_certifier_type']) : '';
                                    ?>
                                    <input name="assignment_certifier_type" class="form-control" value="<?php echo $value ?>" size="10" style="width: 50px; background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;" autocomplete="off">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="form-label">Coroner Location Description</label>
                                    <?php
                                        $value = (isset($distric['assignment_coroner_location']) ) ? trim($distric['assignment_coroner_location']) : '';
                                    ?>
                                    <input name="assignment_coroner_location" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Physician/Coroner</label>
                                    <?php
                                        $value = (isset($distric['assignment_physician1']) ) ? trim($distric['assignment_physician1']) : '';
                                    ?>
                                    <select name="assignment_physician1" class="form-control">
                                    </select>
                                    
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">&nbsp;</label>
                                    <?php
                                        $value = (isset($distric['assignment_physician2']) ) ? trim($distric['assignment_physician2']) : '';
                                    ?>
                                    <input name="assignment_physician2" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                                </div>
                            </div>
                        </div> 
                        <div class="row">
                        	<div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label"> Dropped to Paper</label>
                                    <?php
                                        $value = (isset($distric['assignment_dropped_to_papaer']) ) ? trim($distric['assignment_dropped_to_papaer']) : '';
                                    ?>
                                    <input name="assignment_dropped_to_papaer" class="form-control" value="<?php echo $value ?>" size="10" style="width: 50px; background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;" autocomplete="off">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Email Notify </label>
                                    <?php
                                        $value = (isset($distric['assignment_email_notify']) ) ? trim($distric['assignment_email_notify']) : '';
                                    ?>
                                    <input name="assignment_email_notify" class="form-control" value="<?php echo $value ?>" style="width: 50px; background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;" autocomplete="off">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Date Sent</label>
                                    <?php
                                        $value = (isset($distric['assignment_date_sent']) ) ? trim($distric['assignment_date_sent']) : '';
                                    ?>
                                    <input name="assignment_date_sent" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                                    
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Certifier Location </label>
                                    <?php
                                        $value = (isset($distric['assignment_certifier_location']) ) ? trim($distric['assignment_certifier_location']) : '';
                                    ?>
                                    <input name="assignment_certifier_location" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label">Certifier County</label>
                                    <?php
                                        $value = (isset($distric['assignment_certifier_country']) ) ? trim($distric['assignment_certifier_country']) : '';
                                    ?>
                                    <input name="assignment_certifier_country" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                                </div>
                            </div>
                        </div> 
                </fieldset> 
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Residence</h5></legend> 
                     <div class="col-md-2">
                        <div class="form-group">
                           <label class="form-label">Street and Number</label>
                           <?php
                                $value = (isset($distric['residence_street_number']) ) ? trim($distric['residence_street_number']) : '';
                            ?>
                           <input name="residence_street_number" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                     <div class="col-md-1">
                        <div class="form-group">
                           <label class="form-label">Apt</label>
                           <?php
                                $value = (isset($distric['residence_apt']) ) ? trim($distric['residence_apt']) : '';
                            ?>
                           <input name="residence_apt" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label class="form-label">In City Limits</label>
                           <?php
                                $value = (isset($distric['residence_city_limits']) ) ? trim($distric['residence_city_limits']) : '';
                            ?>
                           <input name="residence_city_limits" class="form-control" value="<?php echo $value ?>" style="width: 50px; background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;" autocomplete="off">
                         </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label class="form-label"> Zip Code </label>
                           <?php
                                $value = (isset($distric['residence_zipcode']) ) ? trim($distric['residence_zipcode']) : '';
                            ?>
                           <select name="residence_zipcode" class="form-control select2-zipcode select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                           </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 241px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-7q-container"><span class="select2-selection__rendered" id="select2-CityID-7q-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                         </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label class="form-label">City or Township</label>
                           <?php
                                $value = (isset($distric['residence_city_township']) ) ? trim($distric['residence_city_township']) : '';
                            ?>
                           <input name="residence_city_township" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label class="form-label">County</label>
                           <?php
                                $value = (isset($distric['residence_country1']) ) ? trim($distric['residence_country1']) : '';
                            ?>
                           <input name="residence_country1" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label class="form-label"> Country  </label>
                           <?php
                                $value = (isset($distric['residence_country2']) ) ? trim($distric['residence_country2']) : '';
                            ?>
                           <select name="residence_country2" class="form-control select2-country select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                           </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 241px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-jr-container"><span class="select2-selection__rendered" id="select2-CityID-jr-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                         </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label class="form-label"> State  </label>
                           <?php
                                $value = (isset($distric['residence_state']) ) ? trim($distric['residence_state']) : '';
                            ?>
                           <select name="residence_state" class="form-control select2-state select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                           </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 241px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-h3-container"><span class="select2-selection__rendered" id="select2-CityID-h3-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                         </div>
                     </div>
                </fieldset>  
                
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Demographics</h5></legend>
                    <div class="col-md-2">
                        <div class="form-group">
                           <label class="form-label"> Country of Birth  </label>
                           <?php
                                $value = (isset($distric['demographics_country_birth1']) ) ? trim($distric['demographics_country_birth1']) : '';
                            ?>
                           <select name="demographics_country_birth1" class="form-control select2-country select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                           </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 241px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-o5-container"><span class="select2-selection__rendered" id="select2-CityID-o5-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                         </div>
                     </div>
                     <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">&nbsp;</label>
                           <?php
                                $value = (isset($distric['demographics_country_birth2']) ) ? trim($distric['demographics_country_birth2']) : '';
                            ?>
                           <input name="demographics_country_birth2" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label class="form-label"> State of Birth  </label>
                           <?php
                                $value = (isset($distric['demographics_state_birth']) ) ? trim($distric['demographics_state_birth']) : '';
                            ?>
                           <select name="demographics_state_birth" class="form-control select2-state select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                           </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 241px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-42-container"><span class="select2-selection__rendered" id="select2-CityID-42-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                         </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                           <label class="form-label"> Marital Status   </label>
                           <?php
                                $value = (isset($distric['demographics_marital_status']) ) ? trim($distric['demographics_marital_status']) : '';
                            ?>
                           <select name="demographics_marital_status" class="form-control">
                           </select>
                         </div>
                     </div>
                </fieldset>                    
                
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Surviving Spouse (Name prior to first marriage) </h5></legend>
                     <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">First Name </label>
                           <?php
                                $value = (isset($distric['surviving_firstname']) ) ? trim($distric['surviving_firstname']) : '';
                            ?>
                           <input name="surviving_firstname" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Middle Name </label>
                           <?php
                                $value = (isset($distric['surviving_middlename']) ) ? trim($distric['surviving_middlename']) : '';
                            ?>
                           <input name="surviving_middlename" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Last Name </label>
                           <?php
                                $value = (isset($distric['surviving_lastname']) ) ? trim($distric['surviving_lastname']) : '';
                            ?>
                           <input name="surviving_lastname" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Suffix </label>
                           <?php
                                $value = (isset($distric['surviving_suffix']) ) ? trim($distric['surviving_suffix']) : '';
                            ?>
                           <input name="surviving_suffix" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                </fieldset>
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Parents </h5></legend>
                     <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Father's First Name </label>
                           <?php
                                $value = (isset($distric['parents_firstname']) ) ? trim($distric['parents_firstname']) : '';
                            ?>
                           <input name="parents_firstname" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Middle Name </label>
                           <?php
                                $value = (isset($distric['parents_middlename']) ) ? trim($distric['parents_middlename']) : '';
                            ?>
                           <input name="parents_middlename" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Last Name </label>
                           <?php
                                $value = (isset($distric['parents_lastname']) ) ? trim($distric['parents_lastname']) : '';
                            ?>
                           <input name="parents_lastname" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Suffix </label>
                           <?php
                                $value = (isset($distric['parents_suffix']) ) ? trim($distric['parents_suffix']) : '';
                            ?>
                           <input name="parents_suffix" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                </fieldset>
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Mother (Name prior to first marriage)</h5></legend>
                     <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">First Name </label>
                           <?php
                                $value = (isset($distric['mother_firstname']) ) ? trim($distric['mother_firstname']) : '';
                            ?>
                           <input name="mother_firstname" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Middle Name </label>
                           <?php
                                $value = (isset($distric['mother_middlename']) ) ? trim($distric['mother_middlename']) : '';
                            ?>
                           <input name="mother_middlename" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Last Name </label>
                           <?php
                                $value = (isset($distric['mother_lastname']) ) ? trim($distric['mother_lastname']) : '';
                            ?>
                           <input name="mother_lastname" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Suffix </label>
                           <?php
                                $value = (isset($distric['mother_suffix']) ) ? trim($distric['mother_suffix']) : '';
                            ?>
                           <input name="mother_suffix" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                </fieldset>
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Informant (Current legal name) </h5></legend>
                     <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">First Name </label>
                           <?php
                                $value = (isset($distric['informant_firstname']) ) ? trim($distric['informant_firstname']) : '';
                            ?>
                           <input name="informant_firstname" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Middle Name </label>
                           <?php
                                $value = (isset($distric['informant_middlename']) ) ? trim($distric['informant_middlename']) : '';
                            ?>
                           <input name="informant_middlename" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Last Name </label>
                           <?php
                                $value = (isset($distric['informant_lastname']) ) ? trim($distric['informant_lastname']) : '';
                            ?>
                           <input name="informant_lastname" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">Suffix </label>
                           <?php
                                $value = (isset($distric['informant_suffix']) ) ? trim($distric['informant_suffix']) : '';
                            ?>
                           <input name="informant_suffix" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                </fieldset>
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Informant</h5></legend>
                     <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label" style="font-size:12px;">Relationship to Decedent</label>
                           <?php
                                $value = (isset($distric['informant_relationship1']) ) ? trim($distric['informant_relationship1']) : '';
                            ?>
                           <select name="informant_relationship1" class="form-control">
                           </select>
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">&nbsp; </label>
                           <?php
                                $value = (isset($distric['informant_relationship2']) ) ? trim($distric['informant_relationship2']) : '';
                            ?>
                           <input name="informant_relationship2" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-3">
                       	<div class="form-group">
                           <label class="form-label" style="font-size:12px;">Mailing Address - Street and Number</label>
                           <?php
                                $value = (isset($distric['informant_mailing_address']) ) ? trim($distric['informant_mailing_address']) : '';
                            ?>
                           <input name="informant_mailing_address" class="form-control" value="<?php echo $value ?>" autocomplete="off" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">
                         </div>
                     </div>
                      <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">City </label>
                           <?php
                                $value = (isset($distric['informant_city']) ) ? trim($distric['informant_city']) : '';
                            ?>
                           <select name="informant_city" class="form-control select2-city select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                           </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 241px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-hz-container"><span class="select2-selection__rendered" id="select2-CityID-hz-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                         </div>
                     </div>
                     <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">State </label>
                           <?php
                                $value = (isset($distric['informant_state']) ) ? trim($distric['informant_state']) : '';
                            ?>
                           <select name="informant_state" class="form-control select2-state select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                           </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 241px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-1z-container"><span class="select2-selection__rendered" id="select2-CityID-1z-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                         </div>
                     </div>
                     <div class="col-md-2">
                       	<div class="form-group">
                           <label class="form-label">ZipCode </label>
                           <?php
                                $value = (isset($distric['informant_zipcode']) ) ? trim($distric['informant_zipcode']) : '';
                            ?>
                           <select name="informant_zipcode" class="form-control select2-zipcode select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                           </select><span class="select2 select2-container select2-container--bootstrap" dir="ltr" style="width: 241px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-CityID-yj-container"><span class="select2-selection__rendered" id="select2-CityID-yj-container"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                         </div>
                     </div>
                </fieldset>   
                
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Demographics</h5></legend>
                    <div class="row">
                    
                    	<div class="col-md-3">
                        	<div class="row">
                            	<div class="col-md-12">
                                	<div class="form-group">
                                       <label class="form-label">Education  </label>
                                       <?php
                                            $value = (isset($distric['demographics_education']) ) ? trim($distric['demographics_education']) : '';
                                        ?>
                                       <select name="demographics_education" class="form-control">
                                       </select>
                                     </div>
                                </div>
                                <div class="col-md-12">
                                	Of Hispanic Origin? (Y,N,U-Unk) 
                                </div>
                                <div class="col-md-12">
                                	<div class="form-group">
                                        <?php
                                            $value = (isset($distric['demographics_hispanic']) ) ? trim($distric['demographics_hispanic']) : '';
                                        ?>
                                       <input name="demographics_hispanic" class="form-control" value="<?php echo $value ?>" style="width: 50px; background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAYdJREFUOBGVVLuKwkAUPTErioVgY5WF2AhpFKz8AC0W0vgTK9injvkMt7HyB6zWSuy1s1WRXUJQ0cJCxSLOnSSzcYmaDGTmPs45M3fuEMmyrA/XdXvse0eMIUnSD4N9drvdb4KnkpCJ4G/0RTYNEoi1swf35jAnFU68snO5HMrl8h0skYCqqmg0GtEC2WxWJDKZDNhlCT+cE0HfeKNV13XUajUMBgPs93t0Oh3Yto1+v3+X+08mP1EJUQKSaZouJeiY5/OZY6iEy+UShRcxVuIvc9riBAGZEK/IhGGtVNjS43dAgWej2WyiUqlAlmWs12sMh0OcTicuIk7wTOBwOGA+n2O5XELTNJRKJQFP+W9bBKKM6XSK4/GIfD4Px3G4UIAjgXYckXq9DkVRsN1ukU6nAz7+XosIeUbQHfKIcL1eUa1W0Wq1MB6PMZlMODDWJRqGgd1uh0KhwEmbzYavND0UoD77rcJoNEKxWOS1LxYLrFYrLkCYhwIMQXdDPxplNptxQngiMmFuABiQmENn7wkAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;" autocomplete="off">
                                     </div> 
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="row">
                            	<div class="col-md-12 text-center">
                                    <?php
                                        $value = (isset($distric['demographics_mexian']) ) ? trim($distric['demographics_mexian']) : '';
                                    ?>
                                	<input type="checkbox" name="demographics_mexian" value="Y" <?php $checked = $value ? "checked" : ""; echo $checked ?>>
                                </div>
                                <div class="col-md-12 text-center">
                                	Mexican, Mexican Am. or Chicano?
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="row">
                            	<div class="col-md-12 text-center">
                                    <?php
                                        $value = (isset($distric['demographics_puerto']) ) ? trim($distric['demographics_puerto']) : '';
                                    ?>
                                	<input type="checkbox" name="demographics_puerto" value="Y" <?php $checked = $value ? "checked" : ""; echo $checked ?>>
                                </div>
                                <div class="col-md-12 text-center">
                                	Puerto Rican?
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="row">
                            	<div class="col-md-12 text-center">
                                    <?php
                                        $value = (isset($distric['demographics_cuban']) ) ? trim($distric['demographics_cuban']) : '';
                                    ?>
                                	<input type="checkbox" name="demographics_cuban" value="Y" <?php $checked = $value ? "checked" : ""; echo $checked ?>>
                                </div>
                                <div class="col-md-12 text-center">
                                	Cuban?
                                </div>
                                <div class="col-md-12">
                                	<label class="form-label">Other Specify </label>
                                    <?php
                                        $value = (isset($distric['demographics_specify']) ) ? trim($distric['demographics_specify']) : '';
                                    ?>
                                	<input type="text" class="form-control" name="demographics_specify">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                        	<div class="row">
                            	<div class="col-md-12 text-center">
                                    <?php
                                        $value = (isset($distric['demographics_other']) ) ? trim($distric['demographics_other']) : '';
                                    ?>
                                	<input type="checkbox" name="demographics_other" value="Y" <?php $checked = $value ? "checked" : ""; echo $checked ?>>
                                </div>
                                <div class="col-md-12 text-center">
                                	Other 
                                </div>
                            </div>
                        </div>
                    
                    </div>
                </fieldset>
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Race</h5></legend>
                    <div class="col-md-3">
                        <?php
                            $value = (isset($distric['race_white']) ) ? trim($distric['race_white']) : '';
                        ?>
                    	<div><input type="checkbox" value="Y" name="race_white" <?php $checked = $value ? "checked" : ""; echo $checked ?>> White </div>
                        <?php
                            $value = (isset($distric['race_black']) ) ? trim($distric['race_black']) : '';
                        ?>
                        <div><input type="checkbox" value="Y" name="race_black" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Black/African American </div>
                        <?php
                            $value = (isset($distric['race_asian']) ) ? trim($distric['race_asian']) : '';
                        ?>
                        <div><input type="checkbox" value="Y" name="race_asian" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Asian Indian </div>
                        <?php
                            $value = (isset($distric['race_chinese']) ) ? trim($distric['race_chinese']) : '';
                        ?>
                        <div><input type="checkbox" value="Y" name="race_chinese" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Chinese  </div>
                        <?php
                            $value = (isset($distric['race_filipino']) ) ? trim($distric['race_filipino']) : '';
                        ?>
                        <div><input type="checkbox" value="Y" name="race_filipino" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Filipino  </div>
                        <?php
                            $value = (isset($distric['race_vietnamese']) ) ? trim($distric['race_vietnamese']) : '';
                        ?>
                        <div><input type="checkbox" value="Y" name="race_vietnamese" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Vietnamese </div>
                        <?php
                            $value = (isset($distric['race_japanese']) ) ? trim($distric['race_japanese']) : '';
                        ?>
                        <div><input type="checkbox" value="Y" name="race_japanese" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Japanese  </div>
                        <?php
                            $value = (isset($distric['race_korean']) ) ? trim($distric['race_korean']) : '';
                        ?>
                        <div><input type="checkbox" value="Y" name="race_korean" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Korean</div>
                        <?php
                            $value = (isset($distric['race_hawaiian']) ) ? trim($distric['race_hawaiian']) : '';
                        ?>
                        <div><input type="checkbox" value="Y" name="race_hawaiian" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Native Hawaiian</div>
                        <?php
                            $value = (isset($distric['race_samoan']) ) ? trim($distric['race_samoan']) : '';
                        ?>
                        <div><input type="checkbox" value="Y" name="race_samoan" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Samoan</div>
                    </div>
                    <div class="col-md-3">
                        <?php
                            $value = (isset($distric['race_guamanian']) ) ? trim($distric['race_guamanian']) : '';
                        ?>
                    	<div><input type="checkbox" value="Y" name="race_guamanian" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Guamanian or Chamorro</div>
                    </div>
                    
                    <div class="col-md-6">
                        <?php
                            $value = (isset($distric['race_american']) ) ? trim($distric['race_american']) : '';
                        ?>
                    	<div><input type="checkbox" value="Y" name="race_american" <?php $checked = $value ? "checked" : ""; echo $checked ?>> American Indian or Alaska Native</div>
                        
                        <div class="col-md-6">
                          <div class="form-group">
                          	<label class="form-label">Native Desc. 1</label>
                            <?php
                                $value = (isset($distric['race_native_desc']) ) ? trim($distric['race_native_desc']) : '';
                            ?>
                            <input type="text" class="form-control" name="race_native_desc" value="<?php echo $value ?>">
                            <?php
                                $value = (isset($distric['race_native_chk']) ) ? trim($distric['race_native_chk']) : '';
                            ?>
                            <div><input type="checkbox" value="Y" name="race_native_chk" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Other Asian</div>
                          </div>
                          <div class="form-group">
                          	<label class="form-label">Other Asian Desc. 1 </label>
                            <?php
                                $value = (isset($distric['race_other_asian_desc']) ) ? trim($distric['race_other_asian_desc']) : '';
                            ?>
                            <input type="text" class="form-control" name="race_other_asian_desc" value="<?php echo $value ?>">
                            <?php
                                $value = (isset($distric['race_other_asian_chk']) ) ? trim($distric['race_other_asian_chk']) : '';
                            ?>
                            <div><input type="checkbox" value="Y" name="race_other_asian_chk" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Other Pacific Islander</div>
                          </div>
                          <div class="form-group">
                          	<label class="form-label">Other Pacific Islander Desc. 1 </label>
                            <?php
                                $value = (isset($distric['race_other_pacific_desc']) ) ? trim($distric['race_other_pacific_desc']) : '';
                            ?>
                            <input type="text" class="form-control" name="race_other_pacific_desc" value="<?php echo $value ?>">
                            <?php
                                $value = (isset($distric['race_other_pacific_chk']) ) ? trim($distric['race_other_pacific_chk']) : '';
                            ?>
                            <div><input type="checkbox" value="Y" name="race_other_pacific_chk" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Unknown?</div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                          	<label class="form-label">Native Desc. 2</label>
                            <?php
                                $value = (isset($distric['race_native_desc2']) ) ? trim($distric['race_native_desc2']) : '';
                            ?>
                            <input type="text" class="form-control" name="race_native_desc2" value="<?php echo $value ?>">
                            <?php
                                $value = (isset($distric['race_other_asian_chk2']) ) ? trim($distric['race_other_asian_chk2']) : '';
                            ?>
                            <div><input type="checkbox" value="Y" name="race_other_asian_chk2" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Other Asian</div>
                          </div>
                          <div class="form-group">
                          	<label class="form-label">Other Asian Desc. 2 </label>
                            <?php
                                $value = (isset($distric['race_other_asian_desc2']) ) ? trim($distric['race_other_asian_desc2']) : '';
                            ?>
                            <input type="text" class="form-control" name="race_other_asian_desc2" value="<?php echo $value ?>">
                            <?php
                                $value = (isset($distric['race_other_pacific_chk2']) ) ? trim($distric['race_other_pacific_chk2']) : '';
                            ?>
                            <div><input type="checkbox" value="Y" name="race_other_pacific_chk2" <?php $checked = $value ? "checked" : ""; echo $checked ?>> Other Pacific Islander</div>
                          </div>
                          <div class="form-group">
                          	<label class="form-label">Other Pacific Islander Desc. 2 </label>
                            <?php
                                $value = (isset($distric['race_other_pacific_desc2']) ) ? trim($distric['race_other_pacific_desc2']) : '';
                            ?>
                            <input type="text" class="form-control" name="race_other_pacific_desc2" value="<?php echo $value ?>">
                          </div>
                        </div>
                    
                    </div>
                </fieldset> 
                <fieldset>
                	<legend><h5 class="statistics_form_sub_title">Demographics</h5></legend>
                    <div class="col-md-3">
                    	<div class="form-group">
                          	<label class="form-label">Occupation </label>
                            <?php
                                $value = (isset($distric['demographics_occupation']) ) ? trim($distric['demographics_occupation']) : '';
                            ?>
                            <input type="text" class="form-control" name="demographics_occupation" value="<?php echo $value ?>">
                         </div>
                    </div>
                    <div class="col-md-3">
                    	<div class="form-group">
                          	<label class="form-label">Industry/Business Type  </label>
                            <?php
                                $value = (isset($distric['demographics_industry']) ) ? trim($distric['demographics_industry']) : '';
                            ?>
                            <input type="text" class="form-control" name="demographics_industry" value="<?php echo $value ?>">
                         </div>
                    </div>			
                </fieldset>                                                                        
            </div>
         </div>
         
        
        

        <!-- page mm end-->
        
        </div>
    </div>