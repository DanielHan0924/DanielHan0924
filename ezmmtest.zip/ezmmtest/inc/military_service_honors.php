<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">

            <input type="hidden" name="recurrings_table" id="recurrings_table_militaryservice" value="final_arrange_military_service">

            <label class="control-label">Military honors</label>
            <?php
            $sql = "SELECT * FROM dropdown_militaryservicehonors";
            $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="MSH_honors" id="MSH_honors" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label">Contacted</label>
            <input type="text" name="MSH_Contacted" id="MSH_Contacted"class="form-control" placeholder="">
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <div class="mt-checkbox-inline">
                <label class="mt-checkbox mt-checkbox-outline">
                    <input type="checkbox" id="MSH_Flag" name="MSH_Flag"> Flag
                    <span></span>
                </label>
                <label class="mt-checkbox mt-checkbox-outline">
                    <input type="checkbox" id="MSH_HonorGuard" name="MSH_HonorGuard"> Color Guard
                    <span></span>
                </label>
                <label class="mt-checkbox mt-checkbox-outline">
                    <input type="checkbox" id="MSH_DD214" name="MSH_DD214"> Caisson
                    <span></span>
                </label>
                <label class="mt-checkbox mt-checkbox-outline">
                    <input type="checkbox" id="MSH_Gravemarker" name="MSH_Gravemarker"> Military grave marker
                    <span></span>
                </label>
            </div>
        </div>
    </div>
    <div class="col-md-4" id="subform_DrapedAndFolded" hidden>
        <div class="form-group">
            <div class="mt-checkbox-inline">
                <label class="mt-checkbox mt-checkbox-outline">
                    <input type="checkbox" id="MSH_Draped" name="MSH_Draped"> Draped 
                    <span></span>
                </label>
                <label class="mt-checkbox mt-checkbox-outline">
                    <input type="checkbox" id="MSH_Folded" name="MSH_Folded"> Folded 
                    <span></span>
                </label>
            </div>
        </div>
    </div>
</div>
<!-- Additional for for graver marker -->
<div class="container" id="subform_gravemarker" style="display:none">
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">Name</label>
                <input type="text" name="MSH_FullName" ID="MSH_FullName" class="form-control" placeholder="">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">Rank </label>
                <?php
                    $value = (isset($military_service['Rank']) ) ? trim($military_service['Rank']) : '';
                    $sql = "SELECT * FROM dropdown_rank";
                    $result = $conn->query($sql);
                ?>
                <?php if (mysqli_num_rows($result) > 0) { ?>
                    <select name="MSH_rank" id="MSH_rank" class="form-control required" required>
                        <option value="0" hidden>select...</option>

                        <?php 
                        while($dropdown_relationship_cld = mysqli_fetch_assoc($result)) {                 
                            ?>
                            <option value="<?php echo ($dropdown_relationship_cld['id']); ?>" <?php if ($value == $dropdown_relationship_cld['id']) {echo "selected";}?>><?php echo ($dropdown_relationship_cld['name']); ?></option>
                        <?php }?>
                    </select>
                <?php } else{echo ('no option to be selected');}?>
            </div>
        </div>   
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">War / Campaign </label>
                <?php
                    $value = (isset($military_service['WarCampaignID']) ) ? trim($military_service['WarCampaignID']) : '';
                    $sql = "SELECT * FROM dropdown_warcampaign";
                    $result = $conn->query($sql);
                ?>
                <?php if (mysqli_num_rows($result) > 0) { ?>
                    <select name="MSH_warcampaign" id="MSH_warcampaign" class="form-control required" required>
                        <option value="0" hidden>select...</option>
                        <?php 
                        while($dropdown_relationship_cld = mysqli_fetch_assoc($result)) {                 
                            ?>
                            <option value="<?php echo ($dropdown_relationship_cld['id']); ?>" <?php if ($value == $dropdown_relationship_cld['id']) {echo "selected";}?>><?php echo ($dropdown_relationship_cld['name']); ?></option>
                        <?php }?>
                    </select>
                <?php } else{echo ('no option to be selected');}?>
            </div>
        </div>   
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">Military Awards </label>
                <?php
                    $value = (isset($military_service['HonorId']) ) ? trim($military_service['HonorId']) : '';
                    $sql = "SELECT * FROM dropdown_militaryservicehonors";
                    $result = $conn->query($sql);
                ?>
                <?php if (mysqli_num_rows($result) > 0) { ?>
                    <select name="MSH_Awards" id="MSH_Awards" class="form-control required" required>
                        <option value="0" hidden>select...</option>
                        <?php 
                        while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                            ?>
                            <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                        <?php }?>
                    </select>
                <?php } else{echo ('no option to be selected');}?>
            </div>
        </div> 
        
    </div>
    <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label class="control-label"> Date of Birth</label>
                <?php
                    $value = (isset($military_service['dateofbirth']) ) ? trim($military_service['dateofbirth']) : '';
                ?>
                <input type="date" name="MSH_DateOfBirth" id="MSH_DateOfBirth" value="<?php echo $value ?>" class="form-control " placeholder="">
                <div class="valid-feedback">
                </div>
                <div class="invalid-feedback">
                </div>
            </div>
        </div> 
        <div class="col-md-3">
            <div class="form-group">
                <label class="control-label"> Date of Death</label>
                <?php
                    $value = (isset($military_service['dateofdeath']) ) ? trim($military_service['dateofdeath']) : '';
                ?>
                <input type="date" name="MSH_DateOfDeath" id="MSH_DateOfDeath" value="<?php echo $value ?>" class="form-control " placeholder="">
                <div class="valid-feedback">
                </div>
                <div class="invalid-feedback">
                </div>
            </div>
        </div> 
    </div>
    <div class="row">
        <div class="col-md-11">
            <div class="form-group">
                <label class="control-label">Inscription</label>
                <textarea id="MSH_Inscription" name="MSH_Inscription" rows="4" style="width: 100%">
                </textarea>
            </div>
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php }?>
</form>



