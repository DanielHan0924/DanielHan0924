<?php 
    //session has already been started.
    $currentpage = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);    
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php
        echo ucwords(str_replace("_"," ",str_replace(".php","",$currentpage)));?> :: EZM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <link rel="icon" href="assets/images/ezm-logo.png" />

    <!-- <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"> -->
    <!-- <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"> -->
    
    <link href="./main.css" rel="stylesheet">
    <link href="./custom.css" rel="stylesheet">

    <!-- Bootstrap Core CSS -->
    <!-- <link href="assets/css/bootstrap.min.css" rel="stylesheet"> -->
    <!-- Custom CSS -->
    <!-- <link href="assets/css/styles.css" rel="stylesheet">	 -->
	<!-- DateTimePicker CSS -->
	<link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">	
	<!-- DataTables CSS -->
    <link href="assets/css/dataTables.bootstrap.css" rel="stylesheet">	
	<!-- FullCalendar CSS -->
	<link href="assets/css/fullcalendar.css" rel="stylesheet" />
	<link href="assets/css/fullcalendar.print.css" rel="stylesheet" media="print" />	
	<!-- jQuery -->
    <script src="assets/js/jquery.js"></script>	
	<!-- SweetAlert CSS -->
	<script src="assets/js/sweetalert.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="assets/css/sweetalert.css">
    <!-- Custom Fonts -->
    <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css"> -->
	<!-- ColorPicker CSS -->
	<link href="assets/css/bootstrap-colorpicker.css" rel="stylesheet">
    
    <script src="./assets/scripts/main.js"></script>
    <script src="./assets/js/jquery-2.2.4.min.js"></script>
    <script src="./assets/scripts/input_mask.js"></script>
    
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>
            <div class="app-header__content">
                <div class="app-header-right">
                    <div class="header-btn-lg pr-0">
                        <div class="widget-content p-0">
                            <div class="widget-content-wrapper">
                                <div class="widget-content-left header-user-info mr-3">

                                    <a href="admin.php" class="mr-2">
                                        <img width="30" class="" src="assets/images/icons/settings.png" alt="">
                                    </a>
                                    <a href="managedropdowns.php" class="mr-2">
                                        <img width="30" class="" src="assets/images/icons/edit.png" alt="">
                                    </a>
                                    <a href="calendar.php" class="mr-2">
                                        <img width="26" class="" src="assets/images/icons/calendar.png" alt="">
                                    </a>
                                    <a href="toDoList.php" class="mr-2">
                                        <img width="30" class="" src="assets/images/icons/todo.png" alt="">
                                    </a>
                                </div>
                                <div class="widget-content-left">
                                    <div class="btn-group">
                                        <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="p-0 btn">
                                            <img width="42" class="rounded-circle testimageview_staff" src="uploads/userphotos/<?php echo $_SESSION['photo']; ?>" alt="">
                                            <i class="fa fa-angle-down ml-2 opacity-8"></i>
                                        </a>
                                        <div tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu dropdown-menu-right">
                                            <button type="button" tabindex="0" class="dropdown-item" onclick="logout()">Log Out</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content-left  ml-3 header-user-info">
                                    <div class="widget-heading">
                                       <?php echo $_SESSION['username']; ?>
                                    </div>
                                    <div class="widget-subheading">
                                        <?php echo $_SESSION['userrole']; ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="app-main">
            <div class="app-sidebar sidebar-shadow">
                <div class="app-header__logo">
                    <div class="logo-src"></div>
                    <div class="header__pane ml-auto">
                        <div>
                            <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="app-header__mobile-menu">
                    <div>
                        <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
                <div class="app-header__menu">
                    <span>
                        <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                            <span class="btn-icon-wrapper">
                                <i class="fa fa-ellipsis-v fa-w-6"></i>
                            </span>
                        </button>
                    </span>
                </div>
                <div class="scrollbar-sidebar">
                    <div class="app-sidebar__inner">
                        <ul class="vertical-nav-menu">
                            <li class="app-sidebar__heading">Menu</li>
                            <li>
                                <a href="welcome.php" <?php if($currentpage == "welcome.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-home"></i>
                                    Dashboard
                                </a>
                            </li>
                            <?php if (isset($_SESSION['selectedcaseID']) || $_SESSION['userrole'] == 'superadmin') { ?>
                            <li>
                                <a href="pre_need.php" <?php if($currentpage == "pre_need.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-rocket"></i>
                                    Pre Need
                                </a>
                            </li>
                            <li>
                                <a href="at_need.php" <?php if($currentpage == "at_need.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-diamond"></i>
                                    At Need
                                </a>
                            </li>
                            <li>
                                <a href="contractor.php" <?php if($currentpage == "contractor.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-leaf"></i>
                                   Contractor
                                </a>
                            </li>
                            <li>
                                <a href="first_call.php" <?php if($currentpage == "first_call.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-leaf"></i>
                                    First Call
                                </a>
                            </li>

                            <li>
                                <a href="case_bio.php" <?php if($currentpage == "case_bio.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Case Bio
                                </a>
                            </li>
                            <li>
                                <a href="vital_statistics.php" <?php if($currentpage == "vital_statistics.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Vital Statistics
                                </a>
                            </li>
                            <li>
                                <a href="surviving_relatives.php" <?php if($currentpage == "surviving_relatives.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Surviving Relatives
                                </a>
                            </li>
                            <li>
                                <a href="final_arrangements.php" <?php if($currentpage == "final_arrangements.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Final Arrangements
                                </a>
                            </li>
                            <!-- <li>
                                <a href="support.php" <?php if($currentpage == "support.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Final Arrangements Support
                                </a>
                            </li> -->
                            <li>
                                <a href="statement_of_goods.php" <?php if($currentpage == "statement_of_goods.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Statement of Goods &amp; Services
                                </a>
                            </li>
                            <li>
                                <a href="memberships.php" <?php if($currentpage == "memberships_bio.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Memberships
                                </a>
                            </li>
                            <li>
                                <a href="organizations.php" <?php if($currentpage == "organizations.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Organizations
                                </a>
                            </li>
                            <li>
                                <a href="media.php" <?php if($currentpage == "media.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Media Sources
                                </a>
                            </li>
                            <li>
                                <a href="visitors.php" <?php if($currentpage == "vistors.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Vistors
                                </a>
                            </li>
                            <!-- <li>
                                <a href="staff.php" <?php if($currentpage == "staff.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Staff
                                </a>
                            </li> -->
                            <li>
                                <a href="documents_images.php" <?php if($currentpage == "documents_images.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Documents &amp; Images
                                </a>
                            </li>
                            <li>
                                <a href="managedropdowns.php" <?php if($currentpage == "managedropdowns.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-pen" style ="color: red;" aria-hidden="true"></i>
                                    Dropdowns
                                </a>
                            </li>
                            <li>
                                <a href="recurring.php" <?php if($currentpage == "recurring.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-pen" style ="color: red;" aria-hidden="true"></i>
                                    Recurring
                                </a>
                            </li>
                            <!-- <li>
                                <a href="reports.php" <?php if($currentpage == "reports.php") { echo 'class="mm-active"'; } ?>>
                                    <i class="metismenu-icon pe-7s-magic-wand"></i>
                                    Reports
                                </a>
                            </li> -->
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Content Area Start -->
            <div class="app-main__outer">
                <div class="app-main__inner">

                    <div class="app-page-title">
                        <div class="page-title-wrapper">
