<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">

            <input type="hidden" name="recurrings_table" id="recurrings_table_ggchildren" value="case_bio_great_grand_children">
            <label class="control-label">Full Name</label>
            <?php
                $value = (isset($great_grandChildren['fullname']) ) ? trim($great_grandChildren['fullname']) : '';
            ?>
            <input type="text" name="GGCLD_FullName" id="GGCLD_FullName" value="<?php echo $value ?>" class="form-control  " placeholder="" required>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>

</div>
<div class="row">
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 1</label>
            <?php
                $value = (isset($great_grandChildren['address1']) ) ? trim($great_grandChildren['address1']) : '';
            ?>
            <input type="text" name="GGCLD_Address1" value="<?php echo $value ?>" id="GGCLD_Address1" class="form-control  " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 2</label>
            <?php
                $value = (isset($great_grandChildren['address2']) ) ? trim($great_grandChildren['address2']) : '';
            ?>
            <input type="text" name="GGCLD_Address2" value="<?php echo $value ?>" id="GGCLD_Address2" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">City</label>
            
            <?php
                $value = (isset($great_grandChildren['city']) ) ? trim($great_grandChildren['city']) : 1;
                $sql = "SELECT * FROM dropdown_city";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="GGCLD_City" id="GGCLD_City" class="form-control required" required>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">State</label>
           
            <?php
                $value = (isset($great_grandChildren['states']) ) ? trim($great_grandChildren['states']) : 1;
                $sql = "SELECT * FROM dropdown_state";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="GGCLD_State" id="GGCLD_State" class="form-control" required>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Zip</label>
            
            <?php
                $value = (isset($great_grandChildren['zip']) ) ? trim($great_grandChildren['zip']) : 1;
                $sql = "SELECT * FROM dropdown_zip";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="GCLD_Zip"  id="GCLD_Zip" class="form-control" required>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Date Of Birth</label>
            <?php
                $value = (isset($great_grandChildren['dob']) ) ? trim($great_grandChildren['dob']) : '';
            ?>
            <input type="date" name="GGCLD_DOB[]" value="<?php echo $value ?>" id="DOB" class="form-control datepicker">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Relationship</label>
           
            <?php
                $value = (isset($great_grandChildren['relationship']) ) ? trim($great_grandChildren['relationship']) : 1;
                $sql = "SELECT * FROM dropdown_relationship";
                $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="GGCLD_relationship" id="GGCLD_relationship" class="form-control required" required>
                    <?php 
                    while($dropdown_city_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" <?php if ($value == $dropdown_city_cld['id']) {echo "selected";}?>><?php echo ($dropdown_city_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Email</label>
            <?php
                $value = (isset($great_grandChildren['email']) ) ? trim($great_grandChildren['email']) : '';
            ?>
            <input type="email" name="GGCLD_Email" value="<?php echo $value ?>" id="GGCLD_Email" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Primary Phone</label>
            <?php
                $value = (isset($great_grandChildren['phone']) ) ? trim($great_grandChildren['phone']) : '';
            ?>
            <input type="text" name="GGCLD_phone" value="<?php echo $value ?>" id="GGCLD_phone" class="form-control mask_phone" placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Secondary Phone</label>
            <?php
                $value = (isset($great_grandChildren['phone2']) ) ? trim($great_grandChildren['phone2']) : '';
            ?>
            <input type="text" name="GGCLD_phone2" value="<?php echo $value ?>" id="GGCLD_phone2" class="form-control mask_phone2" placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>






<!-- Form One Ends -->
