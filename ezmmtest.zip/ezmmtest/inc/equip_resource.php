<!-- Form One Content Starts -->
<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">

            <input type="hidden" name="recurrings_table" id="recurrings_table_equipment" value="final_arrange_equipment">

            <label class="control-label">Equipment / Resource</label>
            <?php
                $value = (isset($equip_resource['equip_resource']) ) ? trim($equip_resource['equip_resource']) : '';
            ?>
            <input type="text" name="EQU_resource" id="EQU_resource" value="<?php echo $value ?>" class="form-control  " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Name</label>
            <?php
                $value = (isset($equip_resource['ClergyName']) ) ? trim($equip_resource['ClergyName']) : '';
            ?>
            <input type="text" name="EQU_Name" id="EQU_Name" value="<?php echo $value ?>" class="form-control  " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label">Make</label>
            <?php
                $value = (isset($equip_resource['Make']) ) ? trim($equip_resource['Make']) : '';
            ?>
            <input type="text" name="EQU_Make" value="<?php echo $value ?>" id="EQU_Make" class="form-control  " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label">Model</label>
            <?php
                $value = (isset($equip_resource['Model']) ) ? trim($equip_resource['Model']) : '';
            ?>
            <input type="text" name="EQU_Model" value="<?php echo $value ?>" id="EQU_Model" class="form-control " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Year Purchase</label>
            <?php
                $value = (isset($equip_resource['pur_date']) ) ? trim($equip_resource['pur_date']) : '';
            ?>
            <input type="text" name="EQU_purdate" value="<?php echo $value ?>" id="EQU_purdate" class="form-control  " placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">    
            <label class="control-label">Quantity</label>
            <?php
                $value = (isset($equip_resource['quantity']) ) ? trim($equip_resource['quantity']) : '';
            ?>
            <input type="text" name="EQU_Qty" value="<?php echo $value ?>" id="EQU_Qty" class="form-control " placeholder="">
            
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Primary Phone</label>
            <?php
                $value = (isset($equip_resource['phone']) ) ? trim($equip_resource['phone']) : '';
            ?>
            <input type="text" name="EQU_phone" value="<?php echo $value ?>" id="EQU_phone" class="form-control mask_phone" placeholder="">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>
<!-- Form One Ends -->
