<!-- Form One Content Starts -->
<form class="forms_hasphoto" action="savehasphoto.php" method="POST" enctype="multipart/form-data">
<div class="row">
    <div class="col-md-8">
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                <?php if(isset($flag_setting) && $flag_setting == true) {
                    $tbl_name =  'users';
                } else if(isset($flag_final) && $flag_final == true){
                    $tbl_name =  'final_arrange_funeral_home';
                }   
                ?>
                    <input type="hidden" name="recurrings_table" id="hasphoto_table_funhomcre" value="<?php echo $tbl_name; ?>">
                    <label class="control-label">Funeral Home / Crematory</label>
                    <?php
                        $value = (isset($user_info['crematory']) ) ? trim($user_info['crematory']) : '';
                    ?>
                    <input type="text" name="FUNHOMCRE_FullName" id="FUNHOMCRE_FullName" value="<?php echo $value ?>" class="form-control"  required <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label class="control-label">Admistrative Contact</label>
                    <?php
                        $value = (isset($user_info['contact']) ) ? trim($user_info['contact']) : '';
                    ?>
                    <input type="text" name="FUNHOMCRE_Contact" id="FUNHOMCRE_Contact" value="<?php echo $value ?>" class="form-control" required <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label class="control-label">Email</label>
                    <?php
                        $value = (isset($user_info['contactemail']) ) ? trim($user_info['contactemail']) : '';
                    ?>
                    <input type="email" name="FUNHOMCRE_Email" value="<?php echo $value ?>" id="FUNHOMCRE_Email" class="form-control"  required <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="control-label">Address 1</label>
                    <?php
                        $value = (isset($user_info['address1']) ) ? trim($user_info['address1']) : '';
                    ?>
                    <input type="text" name="FUNHOMCRE_Address1" value="<?php echo $value ?>" id="FUNHOMCRE_Address1" class="form-control" required <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label class="control-label">Address 2</label>
                    <?php
                        $value = (isset($user_info['address2']) ) ? trim($user_info['address2']) : '';
                    ?>
                    <input type="text" name="FUNHOMCRE_Address2" value="<?php echo $value ?>" id="FUNHOMCRE_Address2" class="form-control" <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>>
                    <div class="valid-feedback">
                    </div>
                    <div class="invalid-feedback">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="row mt-2">
            <div class="col-sm-12 imgUp">
                <?php
                    $value = (isset($user_info['companylogo']) ) ? trim($user_info['companylogo']) : '';
                ?>
                
                <div class="imagePreview uploadedFile_companylogo" ></div>
                <label class="btn btn-primary">
                    Upload Your Company Logo<input type="file" name="uploadedFile" id="uploadedFile_companylogo" class="uploadedFile_companylogo uploadFile img " style="width: 0px;height: 0px;overflow: hidden;" required>
                </label>
                <script>
                    $(".uploadedFile_companylogo").css("background", "url(uploads/companylogs/<?php echo $value ?>) no-repeat center center");
                    $(".uploadedFile_companylogo").css("background-size", "auto 100%");
                </script>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">City</label>
            <?php
            $sql = "SELECT * FROM dropdown_city";
            $result = $conn->query($sql);
            $value = (isset($user_info['city']) ) ? trim($user_info['city']) : '';
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="FUNHOMCRE_City" id="FUNHOMCRE_City" class="form-control" required <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>>
                    <option value="0" hidden>select...</option>
                    <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($value == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">State</label>
            <?php
            $sql = "SELECT * FROM dropdown_state";
            $result = $conn->query($sql);
            $value = (isset($user_info['states']) ) ? trim($user_info['states']) : '';

            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="FUNHOMCRE_State" id="FUNHOMCRE_State" class="form-control" required <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>> 
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($value == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Zip</label>
            <?php
            $sql = "SELECT * FROM dropdown_zip";
            $result = $conn->query($sql);
            $value = (isset($user_info['zip']) ) ? trim($user_info['zip']) : '';

            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="FUNHOMCRE_Zip" id="FUNHOMCRE_Zip" class="form-control" required <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($value == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>

    </div>

    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">Phone</label>
            <?php
                $value = (isset($user_info['phone']) ) ? trim($user_info['phone']) : '';
            ?>
            <input type="text" name="FUNHOMCRE_phone" value="<?php echo $value ?>" id="FUNHOMCRE_phone" class="form-control mask_phone" required <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">State License No.</label>
            <?php
                $value = (isset($user_info['license']) ) ? trim($user_info['license']) : '';
            ?>
            <input type="text" name="FUNHOMCRE_l" value="<?php echo $value ?>" id="FUNHOMCRE_l" class="form-control" required <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>>
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label class="control-label">State License</label>
            <?php
            $sql = "SELECT * FROM dropdown_state";
            $result = $conn->query($sql);
            $value = (isset($user_info['states']) ) ? trim($user_info['states']) : '';

            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="FUNHOMCRE_Statel" id="FUNHOMCRE_Statel" class="form-control" required <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" <?php if ($value == $dropdown_zip_cld['id']) {echo "selected";}?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-6">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-success btn-sm" value="subm_savenewuserinfo" <?php if($user_info['funstatus']=='Paid') echo 'disabled'; ?>>
            <?php if (isset($user_info['crematory']) && $user_info['crematory']!='') {echo "Update";}else{echo "Create";}?>
        </button>
    </div>
    <div class="col-md-3">
        <?php if($user_info['funstatus']=='Paid') echo ' * Forbidden to update as your Funeral Home has already activated by SuperAdmin.'; ?>
    </div>

</div>
<?php } ?>
</form>

<!-- Form One Ends -->
