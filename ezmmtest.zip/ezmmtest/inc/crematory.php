<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <input type="hidden" name="recurrings_table" id="recurrings_table_finaldisposition" value="final_arrange_final_disposition">
            <label class="control-label">Responsible Party/ Informant</label>
            <?php
                $value = (isset($final_crematory['PartyOfInformant']) ) ? trim($final_crematory['PartyOfInformant']) : '';
            ?>
            <input type="text" name="CRM_PartyOfInformant" value="<?php echo $value ?>" id="CRM_PartyOfInformant" class="form-control">
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Date of Cremation</label>
            <?php
                $value = (isset($final_crematory['DateOfCremation']) ) ? trim($final_crematory['DateOfCremation']) : '';
            ?>
            <input type="date" name="CRM_DateOfCremation" value="<?php echo $value ?>" id="CRM_DateOfCremation" class="form-control">
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Time of Cremation</label>
            <?php
                $value = (isset($final_crematory['TimeOfCremation']) ) ? trim($final_crematory['TimeOfCremation']) : '';
            ?>
            <input type="time" name="CRM_TimeOfCremation" value="<?php echo $value ?>" id="CRM_TimeOfCremation" class="form-control timepicker timepicker-default">
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label" for="FuneralHomeCrematoryWaitTimeMet">Wait Time Met</label><br>
            <?php
                $value = (isset($final_crematory['WaitTimeMet']) ) ? trim($final_crematory['WaitTimeMet']) : '';
            ?>
            <input type="checkbox" value="<?php echo $value ?>" name="CRM_WaitTimeMet" id="CRM_WaitTimeMet" <?php if ($value == "Y") {echo "checked";}?>>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label class="control-label">Funeral Director Notes</label>
            <?php
                $value = (isset($final_crematory['DirectorNote']) ) ? trim($final_crematory['DirectorNote']) : '';
            ?>
            <input type="text" name="CRM_FuneralDirectorNote" value="<?php echo $value ?>" id="CRM_FuneralDirectorNote" class="form-control" >
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>