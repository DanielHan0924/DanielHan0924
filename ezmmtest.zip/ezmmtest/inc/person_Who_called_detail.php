<!-- Form One Content Starts -->

<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <input type="hidden" name="recurrings_table" id="recurrings_table_personwhocalled" value="first_call_person_call">
            <label class="control-label">Full Name:</label>
            <input type="text" name="PWC_FullName" id="PWC_FullName" value="" class="form-control" required>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 1</label>
            <input type="text" name="PWC_Address1" id="PWC_Address1" value="" class="form-control" required>
        </div>
    </div>
    <div class="col-md-8">
        <div class="form-group">
            <label class="control-label">Address 2</label>
            <input type="text" name="PWC_Address2" id="PWC_Address2" value="" class="form-control">
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">City</label>
            <?php
            $sql = "SELECT * FROM dropdown_city";
            $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="PWC_City" id="PWC_City" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">States</label>
            <?php
            $sql = "SELECT * FROM dropdown_state";
            $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="PWC_State" id="PWC_State" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Zip</label>
            <?php
            $sql = "SELECT * FROM dropdown_zip";
            $result = $conn->query($sql);
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <select name="PWC_Zip" id="PWC_Zip" class="form-control required" required>
                    <option value="0" hidden>select...</option>
                    <?php 
                    while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                        ?>
                        <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                    <?php }?>
                </select>
            <?php } else{echo ('no option to be selected');}?>
        </div>
    </div>
</div>
<div class="row">

    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Email</label>
            <input type="text" name="PWC_Email" id="PWC_Email" value="" class="form-control" required>
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Day Phone</label>
            <input type="text" name="PWC_dayphone" id="PWC_dayphone" value="" class="form-control mask_phone" required>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label class="control-label">Evening Phone</label>
            <input type="text" name="PWC_evephone" id="PWC_evephone" value="" class="form-control mask_phone" >
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>

   

<!-- Form One Ends -->
