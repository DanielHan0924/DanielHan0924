<form class="forms_recurring" action="saveRecurrings.php" method="POST">

<div class="row">
    <div class="col-md-3">
        <div class="form-group">
        <?php if(isset($flag_final) && $flag_final == true) {
            $tbl_name = 'final_arrange_parents';
        } else { $tbl_name = 'pre_need_parents';}     
        ?>

            <input type="hidden" name="recurrings_table" id="recurrings_table_parentdeceased" value="<?php echo $tbl_name; ?>">
            <input type="hidden" name="PAT_radio_to" value="final_arrange_parents">

            <label class="control-label">Father's date of birth</label>
            <?php
                $value = (isset($parents['ParentDeceasedFathersDOB']) ) ? trim($parents['ParentDeceasedFathersDOB']) : '';
            ?>
            <input type="date" name="PAT_ParentDeceasedFathersDOB" id="PAT_ParentDeceasedFathersDOB" value="<?php echo $value ?>" class="form-control datepicker">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label">Father's date of death</label>
            <?php
                $value = (isset($parents['ParentsDeceasedFathersDOD']) ) ? trim($parents['ParentsDeceasedFathersDOD']) : '';
            ?>
            <input type="date" name="PAT_ParentsDeceasedFathersDOD" id="PAT_ParentsDeceasedFathersDOD" value="<?php echo $value ?>" class="form-control datepicker">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label">Mother's date of birth</label>
           
            <?php
                $value = (isset($parents['ParentsDeceasedMothersDOB']) ) ? trim($parents['ParentsDeceasedMothersDOB']) : '';
            ?>
            <input type="date" name="PAT_ParentsDeceasedMothersDOB" id="PAT_ParentsDeceasedMothersDOB" value="<?php echo $value ?>" class="form-control datepicker">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label">Mother's date of death</label>
            
            <?php
                $value = (isset($parents['ParentsDeceasedMothersDOD']) ) ? trim($parents['ParentsDeceasedMothersDOD']) : '';
            ?>
            <input type="date" name="PAT_ParentsDeceasedMothersDOD" id="PAT_ParentsDeceasedMothersDOD" value="<?php echo $value ?>" class="form-control datepicker">
            <div class="valid-feedback">
            </div>
            <div class="invalid-feedback">
            </div>
        </div>
    </div>
</div>
<?php if (isset($flag_addBtn) && $flag_addBtn === true) { ?>
<div class="row">
    <div class="col-md-6">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;">Add <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_editrecurring">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_delrecurring">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
    <?php if (isset($flag_convert) && $flag_convert === true) { ?>
        <div class="col-md-1">
            <div class="mt-checkbox-inline">
                <label class="mt-checkbox mt-checkbox-outline">
                <input type="checkbox" class="convert_checkEnable"> Convert to Final Arrangement
                </label>
            </div>
        </div>
        <div class="col-md-1">
            <button type="submit" class="btn btn-success btn-sm subm_convert" value="subm_convert" disabled>
                <h5 class="m-0 p-0" style="color: black;">Convert<i class="fa fa-return" style="color: black;"></i></h5>
            </button>
        </div>
    <?php } ?>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-9">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-outline-success btn-sm" value="subm_saverecurring">
            <h5 class="m-0 p-0" style="color: green;"> Add  <i class="fa fa-plus" style="color: green;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>
