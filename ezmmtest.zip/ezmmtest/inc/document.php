<!-- Form One Content Starts -->
<form id="form_document" class="forms_hasphoto" action="savehasphoto.php" method="POST" enctype="multipart/form-data">
<input type="hidden" name="recurrings_table" id="hasphoto_table_document" value="documents">
<div class = "row">
    <div class = "col-md-3">
        <div class="file-field">
            <a class="btn-floating peach-gradient mt-0 float-left">
                <i class="fas fa-paperclip" aria-hidden="true"></i>
                <input type="file" name="uploadedFile" id="uploadPDF" onchange="PreviewFile();">
            </a> 
        </div>
    </div>
    <div class = "col-md-9">
        <div id="docpreview">
        </div>
        <div id="div_pdfviewer" hidden>
            <iframe id="pdfviewer" frameborder="0" scrolling="no" width="400" height="500"></iframe>
        </div>
        
    </div>
</div>
<!-- / -->
<?php if (isset($flag_addbtn) && $flag_addbtn === true) { ?>
<div class="row">
    <div class="col-md-8">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-outline-info btn-sm" value="subm_edit">
            <h5 class="m-0 p-0" style="color: blue;">Edit <i class="fa fa-edit" style="color: blue;"></i></h5>
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_del">
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } else { ?>
<div class="row">
    <div class="col-md-7">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-success btn-sm" value="subm_savedoc" id="subm_savedoc" disabled>
           Upload Document
        </button>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-outline-danger btn-sm" value="subm_deldoc" id="subm_deldoc" disabled>
            <h5 class="m-0 p-0" style="color: black;">Delete <i class="fa fa-trash" style="color: black;"></i></h5>
        </button>
    </div>
</div>
<?php } ?>
</form>
<!-- Form One Ends -->
<script type="text/javascript">
    function PreviewFile() {
        $('#subm_savedoc').prop('disabled',false);
        
        pdffile=document.getElementById("uploadPDF").files[0];
        pdffile_url=URL.createObjectURL(pdffile);
        console.log(event.target.files[0]);
        switch (event.target.files[0].type) {
            case 'application/pdf':
                $('#div_pdfviewer').prop('hidden',false);
                $('#pdfviewer').attr('src',pdffile_url);   
                $('#docpreview').html('<a href="' + pdffile_url + '" target="_blank">' + event.target.files[0].name + '</a>');
                break;
            case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
                $('#div_pdfviewer').prop('hidden',true);
                $('#docpreview').html('<a href="' + pdffile_url + '" target="_blank">' + event.target.files[0].name + '</a>');
                break;
            case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
                $('#div_pdfviewer').prop('hidden',true);
                $('#docpreview').html('<a href="' + pdffile_url + '" target="_blank">' + event.target.files[0].name + '</a>');
                break;
            case 'text/plain':
                $('#div_pdfviewer').prop('hidden',false);
                $('#pdfviewer').attr('src',pdffile_url); 
                $('#docpreview').html('<a href="' + pdffile_url + '" target="_blank">' + event.target.files[0].name + '</a>');
                break;
            default:
                $('#docpreview').html('<a href="' + pdffile_url + '" target="_blank">' + event.target.files[0].name + '</a>');
                break;
        }
    }
</script>

