<?php 
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';

        $flag_addBtn = true;
        $flag_surv = true; // it is used in 'next_of_kin.php' CRUD submit table name

        $sql = "SELECT * FROM surviving_relative WHERE staffID='".$_SESSION['userid']."' GROUP BY caseID;";
        $survivingresult = $conn->query($sql);
        $survivingresultCount = mysqli_num_rows($survivingresult);

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
            <div class="page-title-heading">
                <div><h3>SURVIVING RELATIVES</h3></div>    
            </div>
                </div>
    </div>    
    
    <div class="row">
        <div class="col-md-12">
            <!-- <form class="longforms" id="surviving-form"> -->
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                        
                        <h5 class="card-title custom-head">Surviving Relatives</h5>
                        </div>
                        
                    </div>
                    
                </div>
                <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                    <div class="card">
                        <div id="headingOne" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">SURVIVING RELATIVES</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                            <div class="card-body">
                            
                            <?php if ($survivingresultCount > 0) { ?>
                                <select name="SUREL_case_select" id="SUREL_case_select" class="form-control" required>
                                    <option hidden>Select any Relative suviving:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($survivingresult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" >CaseID: <?php echo ($dropdown_city_cld['caseID']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <div class="row multi-select-custom"></div> 
                            <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/surviving_relative.php'); ?>
                            </div>
                        </div>
                    </div>
            </div>
            <!-- </form> -->
        </div>
    </div>
    </div>
</div>
<?php include('inc/footer.php'); ?>
