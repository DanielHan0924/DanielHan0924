<?php 
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';

        $flag_addBtn = true;
        $flag_organization = true;

        $sql = "SELECT * FROM organization WHERE staffID='".$_SESSION['userid']."';";
        $orgresult = $conn->query($sql);
        $orgresultCount = mysqli_num_rows($orgresult);

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
            <div class="page-title-heading">
                <div><h3>ORGANIZATIONS</h3></div>    
            </div>
        </div>
    </div>    
    
<div class="row">
    <div class="col-md-12">
        <!-- <form class="longforms" id="organization-form"> -->
        <div class="main-card mb-3 card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <h5 class="card-title custom-head">ORGANIZATIONS</h5>
                    </div>
                </div>
            </div>
            <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                <div class="card">
                    <div id="headingOne" class="card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">ORGANIZATION</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                        <div class="card-body">
                            <?php if ($orgresultCount > 0) { ?>
                                <select name="ORGAN_select" id="ORGAN_select" class="form-control" required>
                                    <option hidden>Select any organization:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($orgresult)) { ?>
                                        
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld["Name"]); ?></option>
                                    <?php } ?>
                                </select>
                                <br>
                            <?php } else{echo ('No Organizations until now.');} ?>
                            <?php include('inc/organizations.php'); ?> 
                        </div>
                    </div>
                </div>                                    
            </div>
            
        </div>
        <!-- </form> -->
    </div>
</div>
</div>
<?php include('inc/footer.php'); ?>
