<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v4.12.3, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.12.3, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/landingpage/images/ezm-logo-122x71.png" type="image/x-icon">
  <meta name="description" content="report_tyrants">
  
  <title>Home</title>
  <link rel="stylesheet" href="assets/landingpage/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/landingpage/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/landingpage/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/landingpage/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/landingpage/tether/tether.min.css">
  <link rel="stylesheet" href="assets/landingpage/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/landingpage/theme/css/style.css">
  <link rel="stylesheet" href="assets/landingpage/wowslider-init/style.css">
  <link rel="preload" as="style" href="assets/landingpage/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/landingpage/mobirise/css/mbr-additional.css" type="text/css">
  
<link rel="stylesheet" href="assets/landingpage/wowslider-init/boundary/style.css">
</head>
<body>
  <section class="menu cid-qTkzRZLJNu" once="menu" id="menu1-0">

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="https://www.ezmortuarymanagement.com">
                         <img src="assets/landingpage/images/ezm-logo-122x71.png" alt="Mortuary Management" title="Mortuary Management" style="height: 3.8rem;">
                    </a>
                </span>
                
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item">
                    <a class="nav-link link text-white display-4" href="https://www.ezmortuarymanagement.com/register.php">
                        <span class="mbri-home mbr-iconfont mbr-iconfont-btn"></span>
                        Signup</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link link text-white display-4" href="https://www.ezmortuarymanagement.com/"><span class="mbri-user mbr-iconfont mbr-iconfont-btn"></span>
                        
                        Login</a>
                </li></ul>
            <!-- <div class="navbar-buttons mbr-section-btn">
                <a class="btn btn-sm btn-primary display-4" href="https://mobirise.com">
                    <span class="mbri-save mbr-iconfont mbr-iconfont-btn "></span>
                    Try It Now!
                </a>
            </div> -->
        </div>
    </nav>
</section>

<section class="engine"><a href="https://mobirise.info/j">website templates</a></section>
<section class="cid-qTkA127IK8 mbr-fullscreen mbr-parallax-background" id="header2-1">

    <div class="container align-center">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">Welcome to EZ Mortuary Management 2021</h1>
                <h3 class="mbr-section-subtitle align-center mbr-light pb-3 mbr-fonts-style display-2">
                    Pre-Need to Final Arrangements</h3>
                <p class="mbr-text pb-3 mbr-fonts-style display-5">This is a complete funeral home management software that will allow you do everything from your Pre-Need contracts, to a First Call, body pick-up to the<br>Final Arrangements of cremation, burial, entombment plus all the details of&nbsp;<br>the services, and visitation to allow you to market your products and services<br>to family and loved ones of the deceased.</p>
                
            </div>
        </div>
    </div>
    <div class="mbr-arrow hidden-sm-down" aria-hidden="true">
        <a href="#next">
            <i class="mbri-down mbr-iconfont"></i>
        </a>
    </div>
</section>

<section class="extAccordion cid-sbkXmtgTRn" id="extAccordion3-a">

    <div class="container">
        <h2 class="mbr-fonts-style mbr-section-title align-center display-2">Accordion FAQ</h2>
        <h3 class="mbr-fonts-style mbr-section-subtitle align-center display-5">The website is setup utilizing an accordion layout. This allows you to store a massive amount a data but only display your current work space.</h3>
        <div class="row justify-content-center pt-4">
            <div class="col-md-10 col-lg-8 content-block">
            <div class="accordion-content">
                <div id="bootstrap-accordion_4" class="panel-group accordionStyles accordion " role="tablist" aria-multiselectable="true">
					<div class="card">
						<div class="card-header" role="tab" id="headingOne">
							<a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse1_4" aria-expanded="false" aria-controls="collapse1">
								<h4 class="mbr-fonts-style header-text display-5">Tutorials</h4>
							</a>
						</div>
						<div id="collapse1_4" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#bootstrap-accordion_4">
							<div class="panel-body p-4">
								<p class="mbr-fonts-style panel-text mbr-text display-7">
									There are going to tutorials to walk even the most challenged computer person to be able to use this software confidently, and effectively.</p>
							</div>
						</div>
					</div>
			
					<div class="card">
						<div class="card-header" role="tab" id="headingTwo">
							<a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse2_4" aria-expanded="false" aria-controls="collapse2">
								<h4 class="mbr-fonts-style header-text display-5">Screen Shots</h4>
							</a>
							
						</div>
						<div id="collapse2_4" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingTwo" data-parent="#bootstrap-accordion_4">
							<div class="panel-body p-4">
								<p class="mbr-fonts-style panel-text mbr-text display-7">The screen shots are of the actual web forms with the exact fields that you will be using in your Funeral Home or Crematory business.</p>
							</div>
						</div>
					</div>
			
					<div class="card">
						<div class="card-header" role="tab" id="headingThree">
							<a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse3_4" aria-expanded="false" aria-controls="collapse3">
								<h4 class="mbr-fonts-style header-text display-5">Documentation</h4>

							</a>
						</div>
						<div id="collapse3_4" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#bootstrap-accordion_4">
							<div class="panel-body p-4">
								<p class="mbr-fonts-style panel-text mbr-text display-7">
									Documentation of the in's and outs of how the software was designed and the collaborative effort between the developer and Funeral Directors in muliple States to get where we are today.</p>
							</div>
						</div>
					</div>
			
					<div class="card">
						<div class="card-header" role="tab" id="headingFour">
							<a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse4_4" aria-expanded="false" aria-controls="collapse4">
								<h4 class="mbr-fonts-style header-text display-5">Support</h4>

							</a>
						</div>
						<div id="collapse4_4" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingFour" data-parent="#bootstrap-accordion_4">
							<div class="panel-body p-4">
								<p class="mbr-fonts-style panel-text mbr-text display-7">American English speaking support when you are needing support or just have questions, and suggestions for improving the software is just a phone call away for even demo users</p>
							</div>
						</div>
					</div>       
                </div>
            </div>
        </div>
    </div>
    </div>         
</section>

<section class="mbr-wowslider-container mbr-section mbr-section__container carousel slide mbr-section-nopadding mbr-wowslider-container--boundary" data-ride="carousel" data-keyboard="false" data-wrap="true" data-interval="false" id="wowslider-b" data-rv-view="14" style="background-color: rgb(255, 255, 255);">
    <div class="mbr-wowslider">
        <div class="ws_images">
            <ul>
                <li>
                    
                    <img src="assets/landingpage/images/login-screen-1920x937.jpg" alt="title 3" title="title 3"> text 3
                </li><li>
                    
                    <img src="assets/landingpage/images/signup-1920x937.jpg" alt="title 3" title="title 3"> text 3
                </li><li>
                    
                    <img src="assets/landingpage/images/dashboard-1-1920x937.jpg" alt="title 3" title="title 3"> text 3
                </li><li>
                    
                    <img src="assets/landingpage/images/dashboard-navigation-1920x937.jpg" alt="title 3" title="title 3"> text 3
                </li><li>
                    
                    <img src="assets/landingpage/images/pre-need-1920x937.jpg" alt="title 3" title="title 3"> text 3
                </li><li>
                    
                    <img src="assets/landingpage/images/first-call-1920x937.jpg" alt="title 3" title="title 3"> text 3
                </li><li>
                    
                    <img src="assets/landingpage/images/case-bio-1920x1049.jpg" alt="title 3" title="title 3"> text 3
                </li>
            </ul>
        </div>
        <div class="ws_bullets">
            <div>
                <a href="#" title="">
                    <span><img alt="slide1" src="assets/landingpage/images/tooltip1.jpg"></span>
                </a><a href="#" title="">
                    <span><img alt="slide1" src="assets/landingpage/images/tooltip1.jpg"></span>
                </a><a href="#" title="">
                    <span><img alt="slide1" src="assets/landingpage/images/tooltip1.jpg"></span>
                </a><a href="#" title="">
                    <span><img alt="slide1" src="assets/landingpage/images/tooltip1.jpg"></span>
                </a><a href="#" title="">
                    <span><img alt="slide1" src="assets/landingpage/images/tooltip1.jpg"></span>
                </a><a href="#" title="">
                    <span><img alt="slide1" src="assets/landingpage/images/tooltip1.jpg"></span>
                </a><a href="#" title="">
                    <span><img alt="slide1" src="assets/landingpage/images/tooltip1.jpg"></span>
                </a>
            </div>
        </div>
        <div class="ws_shadow"></div>
        <div class="mbr-wowslider-options">
            <div class="params" data-paddingbottom="0" data-anim-type="basic" data-theme="boundary" data-autoplay="true" data-paddingtop="0" data-fullscreen="true" data-showbullets="false" data-timeout="2" data-duration="2" data-height="576" data-width="1024" data-responsive="1" data-showcaptions="false" data-captionseffect="slide" data-hidecontrols="false"></div>
        </div>
</div></section>


  <script src="assets/landingpage/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/landingpage/popper/popper.min.js"></script>
  <script src="assets/landingpage/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/landingpage/tether/tether.min.js"></script>
  <script src="assets/landingpage/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/landingpage/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/landingpage/parallax/jarallax.min.js"></script>
  <script src="assets/landingpage/wowslider-plugin/wowslider.js"></script>
  <script src="assets/landingpage/dropdown/js/nav-dropdown.js"></script>
  <script src="assets/landingpage/dropdown/js/navbar-dropdown.js"></script>
  <script src="assets/landingpage/theme/js/script.js"></script>
  <script src="assets/landingpage/wowslider-init/script.js"></script>
  
  
<script async src="assets/landingpage/wowslider-effect/basic/script.js"></script>
</body>
</html>