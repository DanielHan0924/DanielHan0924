<?php 
    session_start();
    if (isset($_SESSION['userid'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';

        $flag_addBtn = true;
        $flag_firstcall = true; //it is used in 'personalF_info' CRUD submit table name.
        $flag_convert_casebio = true; // it is used to convert FirstCall to CaseBio

        $sql = "SELECT * FROM first_call_pi WHERE staffID='".$_SESSION['userid']."';";
        $deceasedResult = $conn->query($sql);
        $deceasedResultCount = mysqli_num_rows($deceasedResult);
        
        $sql = "SELECT * FROM case_bio_deceased_info WHERE staffID='".$_SESSION['userid']."';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $deceased_info = mysqli_fetch_assoc($result);
        }

        $sql = "SELECT * FROM first_call_person_call WHERE staffID='".$_SESSION['userid']."';";
        $result111 = $conn->query($sql);
        $resultCount = mysqli_num_rows($result111);

        $sql = "SELECT * FROM first_call_place_of_death WHERE staffID='".$_SESSION['userid']."';";
        $place_of_death_Result = $conn->query($sql);
        $place_of_death_ResultCount = mysqli_num_rows($place_of_death_Result);

        $sql = "SELECT * FROM first_call_location WHERE staffID='".$_SESSION['userid']."';";
        $locationResult = $conn->query($sql);
        $locationResultCount = mysqli_num_rows($locationResult);

        $sql = "SELECT * FROM first_call_physician WHERE staffID='".$_SESSION['userid']."';";
        $physicianResult = $conn->query($sql);
        $physicianResultCount = mysqli_num_rows($physicianResult);

        $sql = "SELECT * FROM first_call_permission WHERE staffID='".$_SESSION['userid']."';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $permission = mysqli_fetch_assoc($result);
        }

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
        <div class="page-title-heading">
            <div><h3>FIRST CALL</h3></div>    
        </div>
            </div>
</div>    

<div class="row">
    <div class="col-md-12">
        <!-- <form class="longforms" id="firstcall-form"> -->
        <div class="main-card mb-3 card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                    <nav class="" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item greyHeaderInformations" aria-current="page">***If you select any 'Personal Information' row, you will see his/her age at death.</li>
                        </ol>
                    </nav>
                    <h5 class="card-title custom-head">FIRST CALL </h5>
                    </div>
                    <!-- <div class="col-lg-2">
                        <div class="image-holder">
                            <img src="assets/images/oldman.jpeg" />
                            <div class="d-block text-center card-footer">
                            <button class="btn-sm btn-block btn btn-success" onclick="saveFirstCallForm()">Save</button>
                        </div>
                        </div>
                    </div> -->
                </div>
            </div>
            <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                <div class="card">
                    <div id="headingOne" class="card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">PERSONAL INFORMATION</h5>
                        </button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                        <div class="card-body">
                            <?php if ($deceasedResultCount > 0) { ?>
                                <select name="PF_select" id="PF_select" class="form-control" required>
                                    <option hidden>Select any person deceased information:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($deceasedResult)) { ?>
                                        <?php  
                                            $sql = "SELECT name FROM dropdown_honorific WHERE id='".$dropdown_city_cld['honorific']."';";
                                            $result = mysqli_fetch_array($conn->query($sql));
                                            $sql1 = "SELECT name FROM dropdown_lastname WHERE id='".$dropdown_city_cld['lastName']."';";
                                            $result1 = mysqli_fetch_array($conn->query($sql1));
                                            $sql2 = "SELECT name FROM dropdown_suffix WHERE id='".$dropdown_city_cld['suffix']."';";
                                            $result2 = mysqli_fetch_array($conn->query($sql2));
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" ><?php echo ($result["name"]); ?>, <?php echo ($dropdown_city_cld['firstName'] ); ?> <?php echo ($dropdown_city_cld['middleName'] ); ?>, <?php echo ($result1['name'] ); ?>, <?php echo ($result2['name'] ); ?> </option>
                                    <?php } ?>
                                </select>
                                <br>
                            <?php } else{echo ('no person deceased information');} ?>
                                <?php include('inc/personalF_info.php'); ?>  
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapse_peoplewhocalled" aria-expanded="false" aria-controls="collapseTwo" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">PERSON WHO CALLED</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapse_peoplewhocalled" class="collapse">
                        <div class="card-body">
                            <?php if ($resultCount > 0) { ?>
                                <select name="PWC_select" id="PWC_select" class="form-control required" required>
                                    <option hidden>Select any person who called:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($result111)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['WhoCalled']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                            <?php } else{echo ('no person called');}?>
                                <?php include('inc/person_Who_called_detail.php'); ?> 
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne3" aria-expanded="false" aria-controls="collapseThree" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">PLACE OF DEATH</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne3" class="collapse">
                        <div class="card-body">
                            <?php if ($place_of_death_ResultCount > 0) { ?>
                                <select name="POD_select" id="POD_select" class="form-control" required>
                                    <option hidden>Select any Place of Death:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($place_of_death_Result)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['Physician']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/place_of_death.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne4" aria-expanded="false" aria-controls="collapseFour" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">LOCATION OF THE BODY</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne4" class="collapse">
                        <div class="card-body">
                            <?php if ($locationResultCount > 0) { ?>
                                <select name="LOC_select" id="LOC_select" class="form-control" required>
                                    <option hidden>Select any Location:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($locationResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>">caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['location']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/location_of_the_body.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne10" aria-expanded="false" aria-controls="collapseFour" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">PHYSICIAN</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne10" class="collapse">
                        <div class="card-body">
                            
                            <?php if ($physicianResultCount > 0) { ?>
                                <select name="PHY_select" id="PHY_select" class="form-control" required>
                                    <option hidden>Select any Physician:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($physicianResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>">caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['Physician']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                            <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/physician.php'); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div id="headingTwo" class="b-radius-0 card-header">
                        <button type="button" data-toggle="collapse" data-target="#collapseOne5" aria-expanded="false" aria-controls="collapseFiv" class="text-left m-0 p-0 btn btn-link btn-block">
                            <h5 class="m-0 p-0">PERMISSIONS</h5></button>
                    </div>
                    <div data-parent="#accordion" id="collapseOne5" class="collapse">
                        <div class="card-body">
                            <?php include('inc/permissions.php'); ?>
                        </div>
                    </div>
                </div>   
            </div>
            <!-- <div class="d-block text-center card-footer">
                <button type="button" class="btn-wide btn btn-primary pull-left">Back to Home</button>
                <button class="btn-wide btn btn-success pull-right" onclick="saveFirstCallForm()">Save</button>
            </div> -->
            
        </div>
        <!-- </form> -->
    </div>
</div>
</div>
<?php include('inc/footer.php'); ?>
