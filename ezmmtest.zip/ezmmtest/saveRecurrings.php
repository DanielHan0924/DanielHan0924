<?php 
session_start();
require 'database/connectDatabase.php';
$reTable = $_POST['recurrings_table'];
if (isset($_SESSION['selectedcaseID'])) { // return nocaseid-Error if there is no selected caseID & it is first attempt to create new caseID via PersonalInformation subsection.
    $selcaseID = $_SESSION['selectedcaseID'];
}else if($reTable!='pre_need_pi' && $reTable != 'at_need_pi' && $reTable!='first_call_pi' && $reTable!='case_bio_deceased_info'){
    $response = array('status' => 'nocaseid','table'=>$reTable);
    echo json_encode($response); return;
}

if( isset($_SESSION['userid'])){
    if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_saverecurring'){       // create new recurring sub-sections
        if($reTable!='pre_need_nok' && $reTable != 'at_need_nok' && $reTable!='pre_need_marital' && $reTable!='case_bio_marital'&& $reTable!='final_arrange_marital'&& $reTable!='surviving_relative'&& $reTable!='final_arrange_military_service'&& $reTable!='final_arrange_pallbearer'&& $reTable!='final_arrange_honorarypallbearer'){
            $sql = "SELECT * FROM ".$reTable." WHERE caseID='".$selcaseID."';";
            $result = $conn->query($sql);
            if (mysqli_num_rows($result) > 0) {   //there is already same caseID as selectedCaseID in the non-mulit table.
                $response = array('status' => 'existcase','existcaseID'=>$selcaseID);
                echo json_encode($response); return;
            }  
        }
        switch ($reTable) {
            case 'recurring_donation':
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, fullname, contact, amount, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['DON_OrgName']."','".$_POST['DON_OrgContact']."','".$_POST['DON_Amount']."','".$_POST['DON_Address1']."','".$_POST['DON_Address2']."','".$_POST['DON_City']."','".$_POST['DON_State']."','".$_POST['DON_Zip']."','".$_POST['DON_Email']."','".$_POST['DON_phone']."')";
                break;
            case 'statement_informants':
                $selcaseID = isset($_SESSION['selectedcaseID']) ? $_SESSION['selectedcaseID'] : 0;
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, InformantName, Address1, Address2, City, States, Zip, SSN, Email, Phone, InvoiceDate, DueDate, note) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['INF_InformantName']."','".$_POST['INF_Address1']."','".$_POST['INF_Address2']."','".$_POST['INF_City']."','".$_POST['INF_State']."','".$_POST['INF_Zip']."','".$_POST['INF_SSN']."','".$_POST['INF_Email']."','".$_POST['INF_phone']."','".$_POST['INF_InvoiceDate']."','".$_POST['INF_DueDate']."','".$_POST['INF_note']."')";
                break;
            case 'membership':
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, Name, Contact, Address1, Address2, City, States, Zip, phone, URL) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['MSP_name']."','".$_POST['MSP_contact']."','".$_POST['MSP_address1']."','".$_POST['MSP_address2']."','".$_POST['MSP_city']."','".$_POST['MSP_state']."','".$_POST['MSP_zip']."','".$_POST['MSP_phone']."','".$_POST['MSP_url']."')";
                break;
            case 'organization':
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, Name, Contact, Address1, Address2, City, States, Zip, phone, URL) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['ORGAN_name']."','".$_POST['ORGAN_contact']."','".$_POST['ORGAN_address1']."','".$_POST['ORGAN_address2']."','".$_POST['ORGAN_city']."','".$_POST['ORGAN_state']."','".$_POST['ORGAN_zip']."','".$_POST['ORGAN_phone']."','".$_POST['ORGAN_url']."')";
                break;
            case 'visitor':
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, Name, Email, Address1, Address2, City, States, Zip, phone, gift) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['VISITOR_name']."','".$_POST['VISITOR_email']."','".$_POST['VISITOR_address1']."','".$_POST['VISITOR_address2']."','".$_POST['VISITOR_city']."','".$_POST['VISITOR_state']."','".$_POST['VISITOR_zip']."','".$_POST['VISITOR_phone']."','".$_POST['VISITOR_gift']."')";
                break;
            //user signup with his/her funeral home&crematory information
            case 'users':
                $role = $_SESSION['userrole'] == 'adminstaff'? $_SESSION['userrole']:'staff';
                $sql = "UPDATE ".$reTable." SET crematory='".$_POST['FUNHOMCRE_FullName']."', address1='".$_POST['FUNHOMCRE_Address1']."', address2='".$_POST['FUNHOMCRE_Address2']."', city='".$_POST['FUNHOMCRE_City']."', states='".$_POST['FUNHOMCRE_State']."', zip='".$_POST['FUNHOMCRE_Zip']."', contactemail='".$_POST['FUNHOMCRE_Email']."', phone='".$_POST['FUNHOMCRE_phone']."', contact='".$_POST['FUNHOMCRE_Contact']."', license='".$_POST['FUNHOMCRE_l']."', role='".$role."', StateLicensed='".$_POST['FUNHOMCRE_State']."' WHERE id='".$_SESSION['userid']."'";           
                break;
            //caseID creating/converting section
            case 'pre_need_pi':
                $sql = "INSERT INTO cases (caseID, staffID, status, createddate) VALUES ('".$selcaseID."','".$_SESSION['userid']."','Pre-Need',curdate())"; //creation of caseID
                if ($conn->query($sql) === TRUE) {
                    $caseID = $conn->insert_id;  //get created caseID and save/update Session_caseID.
                    $_SESSION['selectedcaseID'] = $caseID; //save session_caseID.
                    $sql = "INSERT INTO ".$reTable." (caseID, staffID, honorific, firstName, middleName, lastName, suffix, address1, address2, township, city, states, zipCode, country, nickName, gender, SSN, email, phone, dateOfBirth) VALUES ('".$caseID."','".$_SESSION['userid']."','".$_POST['PI_honorificID']."','".$_POST['PI_firstname']."','".$_POST['PI_middlename']."','".$_POST['PI_lastname']."','".$_POST['PI_suffix']."','".$_POST['PI_address1']."','".$_POST['PI_address2']."','".$_POST['PI_township']."','".$_POST['PI_city']."','".$_POST['PI_state']."','".$_POST['PI_zip']."','".$_POST['PI_county']."','".$_POST['PI_nickname']."','".$_POST['PI_gender']."','".$_POST['PI_ssn']."','".$_POST['PI_email']."','".$_POST['PI_phone']."','".$_POST['PI_dob']."')";
                    if ($conn->query($sql) === TRUE) {    
                        $response = array('status' => 'created');
                        echo json_encode($response); return;
                    } else {
                        $response = array('status' => 'error');
                        echo json_encode($response); return;
                    } 
                } else {
                    $response = array('status' => 'error');
                    echo json_encode($response); return;
                } 
                break;
            case 'pre_need_nok':
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, fullname, address1, address2, city, states, zip, relationship, phone, phone2, email) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['NOK_fullname']."','".$_POST['NOK_address1']."','".$_POST['NOK_address2']."','".$_POST['NOK_city']."','".$_POST['NOK_state']."','".$_POST['NOK_zip']."','".$_POST['NOK_relationship']."','".$_POST['NOK_phone']."','".$_POST['NOK_phone2']."','".$_POST['NOK_email']."')";
                break;
            case 'pre_need_children':
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, childgeneration, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CLD_childdepth']."','".$_POST['CLD_FullName']."','".$_POST['CLD_Address1']."','".$_POST['CLD_Address2']."','".$_POST['CLD_City']."','".$_POST['CLD_State']."','".$_POST['CLD_Zip']."','".$_POST['CLD_DOB']."','".$_POST['CLD_relationship']."','".$_POST['CLD_Email']."','".$_POST['CLD_phone']."','".$_POST['CLD_phone2']."')";
                break;
            case 'pre_need_marital':
                $MS_SpouseDeceased = (isset($_POST['MS_SpouseDeceased']) ) ? 'Y': 'N';
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, maritalstatus, placeofmarriage, dateofmarriage, spousesname, Spousedeceased, dateofdeath, spousesplaceofdeath) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['MS_MaritalStatus']."','".$_POST['MS_PlaceOfMarriage']."','".$_POST['MS_DateOfMarriage']."','".$_POST['MS_SpousesName']."','".$MS_SpouseDeceased."','".$_POST['MS_SDateOfDeath']."','".$_POST['MS_SpousesPlaceOfDeath']."')";
                break;
            case 'pre_need_military_service':
                $MLT_DD214 = (isset($_POST['MLT_DD214']) ) ? 'Y': 'N';
                $MLT_Headstone = (isset($_POST['MLT_Headstone']) ) ?'Y': 'N';
                $MLT_ApplicationForBurial = (isset($_POST['MLT_ApplicationForBurial']) ) ? 'Y': 'N';
                $MLT_ApplicationForFlag = (isset($_POST['MLT_ApplicationForFlag']) ) ?'Y': 'N';
                $MLT_HonorGuard = (isset($_POST['MLT_HonorGuard']) ) ? 'Y': 'N';

                $sql = "INSERT INTO ".$reTable." (caseID, staffID, BranchID, WarCampaignID, SerialNumber, Rank, EnlistmentDate, DischargeDate, TypeOfDischargeID, DD214, Headstone, ApplicationForBurial, ApplicationForFlag, HonorGuard) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['MLT_BranchID']."','".$_POST['MLT_warcampaign']."','".$_POST['MLT_SerialNumber']."','".$_POST['MLT_rank']."','".$_POST['MLT_EnlistmentDate']."','".$_POST['MLT_DischargeDate']."','".$_POST['MLT_typeofdischarge']."','".$MLT_DD214."','".$MLT_Headstone."','".$MLT_ApplicationForBurial."','".$MLT_ApplicationForFlag."','".$MLT_HonorGuard."')";
                break;
            case 'pre_need_church':
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, Church, ClergyName, Address1, Address2, city, states, zip, Email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CHU_Church']."','".$_POST['CHU_ClergyName']."','".$_POST['CHU_Address1']."','".$_POST['CHU_Address2']."','".$_POST['CHU_City']."','".$_POST['CHU_State']."','".$_POST['CHU_Zip']."','".$_POST['CHU_Email']."','".$_POST['CHU_phone']."','".$_POST['CHU_phone2']."')";
                break;
            case 'pre_need_place_of_worship':
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, PlaceOfWorship, ClergyName, Address1, Address2, City, States, Zip, Email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['POW_PlaceOfWorship']."','".$_POST['POW_ClergyName']."','".$_POST['POW_Address1']."','".$_POST['POW_Address2']."','".$_POST['POW_City']."','".$_POST['POW_State']."','".$_POST['POW_Zip']."','".$_POST['POW_Email']."','".$_POST['POW_phone']."','".$_POST['POW_phone2']."')";
                break;
            case 'pre_need_education':
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, EduHighSchool, EduHSGraduated, undergraducate, undergraducatedegree, undergraducatedegreecheck, graduate, graducatedegree, graducatedegreecheck) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['EDU_highschool']."','".$_POST['EDU_EduHSGraduated']."','".$_POST['EDU_undergraduatename']."','".$_POST['EDU_undergraducatedegree']."','".$_POST['EDU_undergraducatedegreecheck']."','".$_POST['EDU_graduatename']."','".$_POST['EDU_graducatedegree']."','".$_POST['EDU_graducatedegreecheck']."')";
                break;
            case 'pre_need_parents':
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, ParentDeceasedFathersDOB, ParentsDeceasedFathersDOD, ParentsDeceasedMothersDOB, ParentsDeceasedMothersDOD) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['PAT_ParentDeceasedFathersDOB']."','".$_POST['PAT_ParentsDeceasedFathersDOD']."','".$_POST['PAT_ParentsDeceasedMothersDOB']."','".$_POST['PAT_ParentsDeceasedMothersDOD']."')";
                break;
            case 'pre_need_final_disposition':
                $FDP_Burial = (isset($_POST['FDP_Burial']) ) ? 'Y': 'N';
                $FDP_Entombment = (isset($_POST['FDP_Entombment']) ) ?'Y': 'N';
                $FDP_Cremation = (isset($_POST['FDP_Cremation']) ) ? 'Y': 'N';
                $FDP_BurialAtSea = (isset($_POST['FDP_BurialAtSea']) ) ?'Y': 'N';
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, Burial, Entombment, Cremation, BurialAtSea, DateOfFinalDisposition, FinalDisposition, CemeteryID, Location, Section, FuneralOrMemorialServiceAtID, NameLotRegisteredTo, WhereInLotIsGraveToBeOpened, LotNo, GraveNo) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$FDP_Burial."','".$FDP_Entombment."','".$FDP_Cremation."','".$FDP_BurialAtSea."','".$_POST['FDP_DateOfFinalDisposition']."','".$_POST['FDP_FinalDisposition']."','".$_POST['FDP_cemetery']."','".$_POST['FDP_Location']."','".$_POST['FDP_Section']."','".$_POST['FDP_FuneralOrMemorialServiceAtID']."','".$_POST['FDP_NameLotRegisteredTo']."','".$_POST['FDP_WhereInLotIsGraveToBeOpened']."','".$_POST['FDP_LotNo']."','".$_POST['FDP_GraveNo']."')";
                break;
            case 'pre_need_final_crematory':
                $CRM_WaitTimeMet = (isset($_POST['CRM_WaitTimeMet']) ) ? 'Y': 'N';
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, PartyOfInformant, DateOfCremation, TimeOfCremation, WaitTimeMet, DirectorNote) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CRM_PartyOfInformant']."','".$_POST['CRM_DateOfCremation']."','".$_POST['CRM_TimeOfCremation']."','".$CRM_WaitTimeMet."','".$_POST['CRM_FuneralDirectorNote']."')";
                break;

            case 'at_need_pi':
                $sql = "INSERT INTO cases (caseID, staffID, status, createddate) VALUES ('".$selcaseID."','".$_SESSION['userid']."','At-Need',curdate())";
                if ($conn->query($sql) === TRUE) {
                    $caseID = $conn->insert_id;
                    $sql = "INSERT INTO ".$reTable." (caseID, staffID, honorific, firstName, middleName, lastName, suffix, address1, address2, township, city, states, zipCode, country, nickName, gender, SSN, email, phone, dateOfDeath, timeOfDeath, dateOfBirth) VALUES ('".$caseID."','".$_SESSION['userid']."','".$_POST['PF_honorific']."','".$_POST['PF_firstname']."','".$_POST['PF_middlename']."','".$_POST['PF_lastName']."','".$_POST['PF_suffix']."','".$_POST['PF_address1']."','".$_POST['PF_address2']."','".$_POST['PF_township']."','".$_POST['PF_city']."','".$_POST['PF_state']."','".$_POST['PF_zip']."','".$_POST['PF_county']."','".$_POST['PF_nickname']."','".$_POST['PF_gender']."','".$_POST['PF_ssn']."','".$_POST['PF_email']."','".$_POST['PF_phone']."','".$_POST['PF_dod']."','".$_POST['PF_tode']."','".$_POST['PF_dob']."')";
                    if ($conn->query($sql) === TRUE) {    
                        $response = array('status' => 'created');
                        echo json_encode($response); return;
                    } else {
                        $response = array('status' => 'error');
                        echo json_encode($response); return;
                    } 
                } else {
                    $response = array('status' => 'error');
                    echo json_encode($response); return;
                } 
                break;
            case 'at_need_nok':
                $sql = "INSERT INTO ".$reTable." (caseID, staffID, fullname, address1, address2, city, states, zip, relationship, phone, phone2, email) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['NOK_fullname']."','".$_POST['NOK_address1']."','".$_POST['NOK_address2']."','".$_POST['NOK_city']."','".$_POST['NOK_state']."','".$_POST['NOK_zip']."','".$_POST['NOK_relationship']."','".$_POST['NOK_phone']."','".$_POST['NOK_phone2']."','".$_POST['NOK_email']."')";
                break;

            //recurring 
            case 'contractor':
                $CNTR_bodypickkup = (isset($_POST['CNTR_bodypickkup']) ) ? 'Y': 'N';
                $CNTR_embalm = (isset($_POST['CNTR_embalm']) ) ?'Y': 'N';
                $sql = "INSERT INTO contractor (caseID, staffID, funeralhome, fullname, address1, address2, city, states, zip, statelicense, stateissued, email, phone, phone2, bodypickkup, embalm) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CNTR_funeralhome']."','".$_POST['CNTR_fullname']."','".$_POST['CNTR_address1']."','".$_POST['CNTR_address2']."','".$_POST['CNTR_city']."','".$_POST['CNTR_state']."','".$_POST['CNTR_zip']."','".$_POST['CNTR_statelicense']."','".$_POST['CNTR_stateissued']."','".$_POST['CNTR_email']."','".$_POST['CNTR_phone']."','".$_POST['CNTR_phone2']."','".$CNTR_bodypickkup."','".$CNTR_embalm."')";
                break;
            case 'final_arrange_vocalist':
                $sql = "INSERT INTO final_arrange_vocalist (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['VOC_FullName']."','".$_POST['VOC_Address1']."','".$_POST['VOC_Address2']."','".$_POST['VOC_City']."','".$_POST['VOC_State']."','".$_POST['VOC_Zip']."','".$_POST['VOC_Email']."','".$_POST['VOC_phone']."')";
                break;
            case 'final_arrange_organist':
                $sql = "INSERT INTO final_arrange_organist (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['ORG_FullName']."','".$_POST['ORG_Address1']."','".$_POST['ORG_Address2']."','".$_POST['ORG_City']."','".$_POST['ORG_State']."','".$_POST['ORG_Zip']."','".$_POST['ORG_Email']."','".$_POST['ORG_phone']."')";
                break;
            case 'final_arrange_cosmetologist':
                $sql = "INSERT INTO final_arrange_cosmetologist (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['COS_FullName']."','".$_POST['COS_Address1']."','".$_POST['COS_Address2']."','".$_POST['COS_City']."','".$_POST['COS_State']."','".$_POST['COS_Zip']."','".$_POST['COS_Email']."','".$_POST['COS_phone']."')";
                break;
            case 'final_arrange_beauticianbarber':
                $sql = "INSERT INTO final_arrange_beauticianbarber (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, gender) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['BB_FullName']."','".$_POST['BB_Address1']."','".$_POST['BB_Address2']."','".$_POST['BB_City']."','".$_POST['BB_State']."','".$_POST['BB_Zip']."','".$_POST['BB_Email']."','".$_POST['BB_phone']."','".$_POST['BB_gender']."')";
                break;
            case 'final_arrange_pallbearer':
                $sql = "INSERT INTO final_arrange_pallbearer (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['PB_FullName']."','".$_POST['PB_Address1']."','".$_POST['PB_Address2']."','".$_POST['PB_City']."','".$_POST['PB_State']."','".$_POST['PB_Zip']."','".$_POST['PB_Email']."','".$_POST['PB_phone']."')";
                break;
            case 'final_arrange_honorarypallbearer':
                $sql = "INSERT INTO final_arrange_honorarypallbearer (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['HPB_FullName']."','".$_POST['HPB_Address1']."','".$_POST['HPB_Address2']."','".$_POST['HPB_City']."','".$_POST['HPB_State']."','".$_POST['HPB_Zip']."','".$_POST['HPB_Email']."','".$_POST['HPB_phone']."')";
                break;
            case 'final_arrange_clergy':
                
                $sql = "INSERT INTO final_arrange_clergy (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CHUR_FullName']."','".$_POST['CHUR_Address1']."','".$_POST['CHUR_Address2']."','".$_POST['CHUR_City']."','".$_POST['CHUR_State']."','".$_POST['CHUR_Zip']."','".$_POST['CHUR_Email']."','".$_POST['CHUR_phone']."')";
                break;
            case 'final_arrange_driver':
                
                $sql = "INSERT INTO final_arrange_driver (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['DRV_FullName']."','".$_POST['DRV_Address1']."','".$_POST['DRV_Address2']."','".$_POST['DRV_City']."','".$_POST['DRV_State']."','".$_POST['DRV_Zip']."','".$_POST['DRV_Email']."','".$_POST['DRV_phone']."')";
                break;
            case 'final_arrange_escort':
                
                $sql = "INSERT INTO final_arrange_escort (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['ESC_FullName']."','".$_POST['ESC_Address1']."','".$_POST['ESC_Address2']."','".$_POST['ESC_City']."','".$_POST['ESC_State']."','".$_POST['ESC_Zip']."','".$_POST['ESC_Email']."','".$_POST['ESC_phone']."')";
                break;
            case 'final_arrange_florist':
                
                $sql = "INSERT INTO final_arrange_florist (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['FLOR_FullName']."','".$_POST['FLOR_Address1']."','".$_POST['FLOR_Address2']."','".$_POST['FLOR_City']."','".$_POST['FLOR_State']."','".$_POST['FLOR_Zip']."','".$_POST['FLOR_Email']."','".$_POST['FLOR_phone']."')";
                break;
            case 'final_arrange_sexton':
                
                $sql = "INSERT INTO final_arrange_sexton (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['SEX_FullName']."','".$_POST['SEX_Address1']."','".$_POST['SEX_Address2']."','".$_POST['SEX_City']."','".$_POST['SEX_State']."','".$_POST['SEX_Zip']."','".$_POST['SEX_Email']."','".$_POST['SEX_phone']."')";
                break;
            case 'final_arrange_service':
                
                $sql = "INSERT INTO final_arrange_service (caseID, staffID, StartDate, StartTime, EndDate, EndTime, ServiceName, ServiceAddress, city, states, Telephone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['SER_StartDate']."','".$_POST['SER_StartTime']."','".$_POST['SER_EndDate']."','".$_POST['SER_EndTime']."','".$_POST['SER_Service']."','".$_POST['SER_Address']."','".$_POST['SER_City']."','".$_POST['SER_State']."','".$_POST['SER_Telephone']."')";
                break;
            case 'final_arrange_visitation':
                
                $sql = "INSERT INTO final_arrange_visitation (caseID, staffID, StartDate, StartTime, EndDate, EndTime, VisitationName, VisitationAddress, city, states, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['VIS_StartDate']."','".$_POST['VIS_StartTime']."','".$_POST['VIS_EndDate']."','".$_POST['VIS_EndTime']."','".$_POST['VIS_Visitation']."','".$_POST['VIS_Address']."','".$_POST['VIS_City']."','".$_POST['VIS_State']."','".$_POST['VIS_Telephone']."')";
                break;
            case 'final_arrange_funeral_home':
                
                $sql = "INSERT INTO final_arrange_funeral_home (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone,contact,license) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['FUNHOMCRE_FullName']."','".$_POST['FUNHOMCRE_Address1']."','".$_POST['FUNHOMCRE_Address2']."','".$_POST['FUNHOMCRE_City']."','".$_POST['FUNHOMCRE_State']."','".$_POST['FUNHOMCRE_Zip']."','".$_POST['FUNHOMCRE_Email']."','".$_POST['FUNHOMCRE_phone']."','".$_POST['FUNHOMCRE_Contact']."','".$_POST['FUNHOMCRE_l']."')";
                break;
            //not used in the Final Arrangement section yet
            case 'final_arrange_cemetery':
                
                $sql = "INSERT INTO final_arrange_cemetery (caseID, staffID, fullname, contact, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CEM_Name']."','".$_POST['CEM_Contact']."','".$_POST['CEM_Address1']."','".$_POST['CEM_Address2']."','".$_POST['CEM_City']."','".$_POST['CEM_State']."','".$_POST['CEM_Zip']."','".$_POST['CEM_Email']."','".$_POST['CEM_phone']."','".$_POST['CEM_phone2']."')";
                break;
            case 'final_arrange_colorguard':
                
                $sql = "INSERT INTO final_arrange_colorguard (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CG_Name']."','".$_POST['CG_Address1']."','".$_POST['CG_Address2']."','".$_POST['CG_City']."','".$_POST['CG_State']."','".$_POST['CG_Zip']."','".$_POST['CG_Email']."','".$_POST['CG_phone']."','".$_POST['CG_phone2']."')";
                break;
            case 'final_arrange_distributor':
                
                $sql = "INSERT INTO final_arrange_distributor (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['DTB_Name']."','".$_POST['DTB_Address1']."','".$_POST['DTB_Address2']."','".$_POST['DTB_City']."','".$_POST['DTB_State']."','".$_POST['DTB_Zip']."','".$_POST['DTB_Email']."','".$_POST['DTB_phone']."',,'".$_POST['DTB_phone2']."')";
                break;
            case 'final_arrange_equipment':
                
                $sql = "INSERT INTO final_arrange_equipment (caseID, staffID, resource, name, make, model, yearpurchase, quantity, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['EQU_resource']."','".$_POST['EQU_Name']."','".$_POST['EQU_Make']."','".$_POST['EQU_Model']."','".$_POST['EQU_purdate']."','".$_POST['EQU_Qty']."','".$_POST['EQU_phone']."')";
                break;
            case 'final_arrange_manufacturer':
                
                $sql = "INSERT INTO final_arrange_manufacturer (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['MANU_Name']."','".$_POST['MANU_Address1']."','".$_POST['MANU_Address2']."','".$_POST['MANU_City']."','".$_POST['MANU_State']."','".$_POST['MANU_Zip']."','".$_POST['MANU_Email']."','".$_POST['MANU_phone']."','".$_POST['MANU_phone2']."')";
                break;
            case 'final_arrange_salesperson':
                
                $sql = "INSERT INTO final_arrange_salesperson (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['SALER_Name']."','".$_POST['SALER_Address1']."','".$_POST['SALER_Address2']."','".$_POST['SALER_City']."','".$_POST['SALER_State']."','".$_POST['SALER_Zip']."','".$_POST['SALER_Email']."','".$_POST['SALER_phone']."','".$_POST['SALER_phone2']."')";
                break;
            
            case 'final_arrange_volunteer':
                
                $sql = "INSERT INTO final_arrange_volunteer (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['VOLN_FullName']."','".$_POST['VOLN_Address1']."','".$_POST['VOLN_Address2']."','".$_POST['VOLN_City']."','".$_POST['VOLN_State']."','".$_POST['VOLN_Zip']."','".$_POST['VOLN_Email']."','".$_POST['VOLN_phone']."','".$_POST['VOLN_phone2']."')";
                break;

            case 'final_arrange_church':
                
                $sql = "INSERT INTO final_arrange_church (caseID, staffID, Church, ClergyName, Address1, Address2, city, states, zip, Email,phone,phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CHU_Church']."','".$_POST['CHU_ClergyName']."','".$_POST['CHU_Address1']."','".$_POST['CHU_Address2']."','".$_POST['CHU_City']."','".$_POST['CHU_State']."','".$_POST['CHU_Zip']."','".$_POST['CHU_Email']."','".$_POST['CHU_phone']."','".$_POST['CHU_phone2']."')";
                break;
            case 'final_arrange_education':
                
                $sql = "INSERT INTO final_arrange_education (caseID, staffID, EduHighSchool, EduHSGraduated, undergraducate, undergraducatedegree, undergraducatedegreecheck, graduate, graducatedegree, graducatedegreecheck) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['EDU_highschool']."','".$_POST['EDU_EduHSGraduated']."','".$_POST['EDU_undergraduatename']."','".$_POST['EDU_undergraducatedegree']."','".$_POST['EDU_undergraducatedegreecheck']."','".$_POST['EDU_graduatename']."','".$_POST['EDU_graducatedegree']."','".$_POST['EDU_graducatedegreecheck']."')";
                break;
            case 'final_arrange_final_crematory':
                
                $sql = "INSERT INTO final_arrange_final_crematory (caseID, staffID, PartyOfInformant, DateOfCremation, TimeOfCremation, WaitTimeMet, DirectorNote) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CRM_PartyOfInformant']."','".$_POST['CRM_DateOfCremation']."','".$_POST['CRM_TimeOfCremation']."','".$_POST['CRM_WaitTimeMet']."','".$_POST['CRM_FuneralDirectorNote']."')";
                break;
            case 'final_arrange_final_disposition':
                $FDP_Burial = (isset($_POST['FDP_Burial']) ) ? 'Y': 'N';
                $FDP_Entombment = (isset($_POST['FDP_Entombment']) ) ?'Y': 'N';
                $FDP_Cremation = (isset($_POST['FDP_Cremation']) ) ? 'Y': 'N';
                $FDP_BurialAtSea = (isset($_POST['FDP_BurialAtSea']) ) ? 'Y': 'N';
                
                $sql = "INSERT INTO final_arrange_final_disposition (caseID, staffID, Burial, Entombment, Cremation, BurialAtSea, DateOfFinalDisposition, FinalDisposition, CemeteryID, Location, Section, FuneralOrMemorialServiceAtID, NameLotRegisteredTo, WhereInLotIsGraveToBeOpened, LotNo, GraveNo) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$FDP_Burial."','".$FDP_Entombment."','".$FDP_Cremation."','".$FDP_BurialAtSea."','".$_POST['FDP_DateOfFinalDisposition']."','".$_POST['FDP_FinalDisposition']."','".$_POST['FDP_cemetery']."','".$_POST['FDP_Location']."','".$_POST['FDP_Section']."','".$_POST['FDP_FuneralOrMemorialServiceAtID']."','".$_POST['FDP_NameLotRegisteredTo']."','".$_POST['FDP_WhereInLotIsGraveToBeOpened']."','".$_POST['FDP_LotNo']."','".$_POST['FDP_GraveNo']."')";
                break;
            case 'final_arrange_children':
                
                $sql = "INSERT INTO final_arrange_children (caseID, staffID, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CLD_FullName']."','".$_POST['CLD_Address1']."','".$_POST['CLD_Address2']."','".$_POST['CLD_City']."','".$_POST['CLD_State']."','".$_POST['CLD_Zip']."','".$_POST['CLD_DOB']."','".$_POST['CLD_relationship']."','".$_POST['CLD_Email']."','".$_POST['CLD_phone']."','".$_POST['CLD_phone2']."')";
                break;
            case 'final_arrange_grand_children':
                
                $sql = "INSERT INTO final_arrange_grand_children (caseID, staffID, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['GCLD_FullName']."','".$_POST['GCLD_Address1']."','".$_POST['GCLD_Address2']."','".$_POST['GCLD_City']."','".$_POST['GCLD_State']."','".$_POST['GCLD_Zip']."','".$_POST['GCLD_DOB']."','".$_POST['GCLD_relationship']."','".$_POST['GCLD_Email']."','".$_POST['GCLD_phone']."','".$_POST['GCLD_phone2']."')";
                break;
            case 'final_arrange_marital':
                $MS_SpouseDeceased = (isset($_POST['MS_SpouseDeceased']) ) ? 'Y': 'N';
                
                $sql = "INSERT INTO final_arrange_marital (caseID, staffID, maritalstatus, placeofmarriage, dateofmarriage, spousesname, Spousedeceased, dateofdeath, spousesplaceofdeath) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['MS_MaritalStatus']."','".$_POST['MS_PlaceOfMarriage']."','".$_POST['MS_DateOfMarriage']."','".$_POST['MS_SpousesName']."','".$MS_SpouseDeceased."','".$_POST['MS_SDateOfDeath']."','".$_POST['MS_SpousesPlaceOfDeath']."')";
                break;
            case 'final_arrange_military_service':  //?????
                
                $flag = (isset($_POST['MSH_Flag']) ) ? 'Y': 'N';
                $honorguard = (isset($_POST['MSH_HonorGuard']) ) ?'Y': 'N';
                $dd = (isset($_POST['MSH_DD214']) ) ? 'Y': 'N';
                $gravemarker = (isset($_POST['MSH_Gravemarker']) ) ? 'Y': 'N';
                if ($flag=='Y') {
                    $draped = (isset($_POST['MSH_Draped']) ) ? 'Y': 'N';
                    $folded = (isset($_POST['MSH_Folded']) ) ? 'Y': 'N';
                }else{
                    $draped = 'N';
                    $folded = 'N';
                }
                $sql = "INSERT INTO final_arrange_military_service (caseID, staffID, honor1, WarCampaignID, contacted, fullname, rank, honor2, dob, dod, inscription, flag, cologuard, caission, gravemarker, draped, folded) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['MSH_honors']."','".$_POST['MSH_warcampaign']."','".$_POST['MSH_Contacted']."','".$_POST['MSH_FullName']."','".$_POST['MSH_rank']."','".$_POST['MSH_Awards']."','".$_POST['MSH_DateOfBirth']."','".$_POST['MSH_DateOfDeath']."','".$_POST['MSH_Inscription']."','".$flag."','".$honorguard."','".$dd."','".$gravemarker."','".$draped."','".$folded."')";
                break;
            case 'final_arrange_parents':
                
                $sql = "INSERT INTO final_arrange_parents (caseID, staffID, ParentDeceasedFathersDOB, ParentsDeceasedFathersDOD, ParentsDeceasedMothersDOB, ParentsDeceasedMothersDOD) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['PAT_ParentDeceasedFathersDOB']."','".$_POST['PAT_ParentsDeceasedFathersDOD']."','".$_POST['PAT_ParentsDeceasedMothersDOB']."','".$_POST['PAT_ParentsDeceasedMothersDOD']."')";
                break;
            case 'final_arrange_place_of_worship':
                
                $sql = "INSERT INTO final_arrange_place_of_worship (caseID, staffID, PlaceOfWorship, ClergyName, Address1, Address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['POW_PlaceOfWorship']."','".$_POST['POW_ClergyName']."','".$_POST['POW_Address1']."','".$_POST['POW_Address2']."','".$_POST['POW_City']."','".$_POST['POW_State']."','".$_POST['POW_Zip']."','".$_POST['POW_Email']."','".$_POST['POW_phone']."','".$_POST['POW_phone2']."')";
                break;
    
            case 'first_call_pi':
                $sql = "INSERT INTO cases (caseID, staffID, status, createddate) VALUES ('".$selcaseID."','".$_SESSION['userid']."','First-Call', curdate())";
                if ($conn->query($sql) === TRUE) {
                    $caseID = $conn->insert_id;
                    $_SESSION['selectedcaseID'] = $caseID; //save session_caseID.

                    $sql = "INSERT INTO ".$reTable." (caseID, staffID, honorific, firstName, middleName, lastName, suffix, address1, address2, township, city, states, zipCode, country, nickName, gender, SSN, email, phone, dateOfDeath, timeOfDeath, dateOfBirth) VALUES ('".$caseID."','".$_SESSION['userid']."','".$_POST['PF_honorific']."','".$_POST['PF_firstname']."','".$_POST['PF_middlename']."','".$_POST['PF_lastName']."','".$_POST['PF_suffix']."','".$_POST['PF_address1']."','".$_POST['PF_address2']."','".$_POST['PF_township']."','".$_POST['PF_city']."','".$_POST['PF_state']."','".$_POST['PF_zip']."','".$_POST['PF_county']."','".$_POST['PF_nickname']."','".$_POST['PF_gender']."','".$_POST['PF_ssn']."','".$_POST['PF_email']."','".$_POST['PF_phone']."','".$_POST['PF_dod']."','".$_POST['PF_tode']."','".$_POST['PF_dob']."')";
                    if ($conn->query($sql) === TRUE) {    
                        $response = array('status' => 'created');
                        echo json_encode($response); return;
                    } else {
                        $response = array('status' => 'error');
                        echo json_encode($response); return;
                    } 
                } else {
                    $response = array('status' => 'error');
                    echo json_encode($response); return;
                } 
                break;
            case 'first_call_location':
                
                $sql = "INSERT INTO first_call_location (caseID, staffID, location, contact, Address1, Address2, City, States, Zip, Email, phone, dod, tode) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['LOC_Location']."','".$_POST['LOC_Contact']."','".$_POST['LOC_Address1']."','".$_POST['LOC_Address2']."','".$_POST['LOC_city']."','".$_POST['LOC_state']."','".$_POST['LOC_zip']."','".$_POST['LOC_Email']."','".$_POST['LOC_phone']."','".$_POST['LOC_dod']."','".$_POST['LOC_tode']."')";
                break;      
                case 'first_call_physician':
                    
                    $sql = "INSERT INTO first_call_physician (caseID, staffID, Physician, ContactName, Address1, Address2, City, States, Zip, Email, officephone,cellphone, pager) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['PHY_Physician']."','".$_POST['PHY_Contact']."','".$_POST['PHY_Address1']."','".$_POST['PHY_Address2']."','".$_POST['PHY_city']."','".$_POST['PHY_state']."','".$_POST['PHY_zip']."','".$_POST['PHY_Email']."','".$_POST['PHY_officephone']."','".$_POST['PHY_cellphone']."','".$_POST['PHY_pager']."')";
                    break;       
                    case 'first_call_place_of_death':
                        
                        $sql = "INSERT INTO first_call_place_of_death (caseID, staffID, Physician, ContactName, Address1, Address2, City, States, Zip, Email, officephone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['POD_Physician']."','".$_POST['POD_Contact']."','".$_POST['POD_Address1']."','".$_POST['POD_Address2']."','".$_POST['POD_city']."','".$_POST['POD_state']."','".$_POST['POD_zip']."','".$_POST['POD_Email']."','".$_POST['POD_officephone']."')";
                        break;       
                        case 'first_call_person_call':
                            
                            $sql = "INSERT INTO first_call_person_call (caseID, staffID, WhoCalled, Address1, Address2, City, States, Zip, Email, dayphone, eveningphone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['PWC_FullName']."','".$_POST['PWC_Address1']."','".$_POST['PWC_Address2']."','".$_POST['PWC_City']."','".$_POST['PWC_State']."','".$_POST['PWC_Zip']."','".$_POST['PWC_Email']."','".$_POST['PWC_dayphone']."','".$_POST['PWC_evephone']."')";
                            break;    

            case 'surviving_relative':
                
                $sql = "INSERT INTO surviving_relative (caseID, staffID, fullname, address1, city, states, zip, phone, email, relationship) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['SUREL_Name']."','".$_POST['SUREL_Address1']."','".$_POST['SUREL_City']."','".$_POST['SUREL_State']."','".$_POST['SUREL_Zip']."','".$_POST['SUREL_phone']."','".$_POST['SUREL_Email']."','".$_POST['SUREL_relationship']."')";
                break;
            //case_bio 
            case 'case_bio_parents':
                
                $sql = "INSERT INTO case_bio_parents (caseID, staffID, FathersName, FDOB, FPlaceOfBirth, MothersName, MothersMaidenName, MDOB, MPlaceOfBirth) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['PAI_fatherName']."','".$_POST['PAI_FDOB']."','".$_POST['PAI_FPlaceOfBirth']."','".$_POST['PAI_motherName']."','".$_POST['PAI_maidenName']."','".$_POST['PAI_MDOB']."','".$_POST['PAI_MPlaceOfBirth']."')";
                break;
            case 'case_bio_children':
                
                $sql = "INSERT INTO case_bio_children (caseID, staffID, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CLD_FullName']."','".$_POST['CLD_Address1']."','".$_POST['CLD_Address2']."','".$_POST['CLD_City']."','".$_POST['CLD_State']."','".$_POST['CLD_Zip']."','".$_POST['CLD_DOB']."','".$_POST['CLD_relationship']."','".$_POST['CLD_Email']."','".$_POST['CLD_phone']."','".$_POST['CLD_phone2']."')";
                break;
                case 'case_bio_grand_children':
                    
                    $sql = "INSERT INTO case_bio_grand_children (caseID, staffID, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['GCLD_FullName']."','".$_POST['GCLD_Address1']."','".$_POST['GCLD_Address2']."','".$_POST['GCLD_City']."','".$_POST['GCLD_State']."','".$_POST['GCLD_Zip']."','".$_POST['GCLD_DOB']."','".$_POST['GCLD_relationship']."','".$_POST['GCLD_Email']."','".$_POST['GCLD_phone']."','".$_POST['GCLD_phone2']."')";
                    break;
                    case 'case_bio_great_grand_children':
                        
                        $sql = "INSERT INTO case_bio_great_grand_children (caseID, staffID, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['GGCLD_FullName']."','".$_POST['GGCLD_Address1']."','".$_POST['GGCLD_Address2']."','".$_POST['GGCLD_City']."','".$_POST['GGCLD_State']."','".$_POST['GGCLD_Zip']."','".$_POST['GGCLD_DOB']."','".$_POST['GGCLD_relationship']."','".$_POST['GGCLD_Email']."','".$_POST['GGCLD_phone']."','".$_POST['GGCLD_phone2']."')";
                        break;
                        case 'case_bio_marital':
                            $MS_SpouseDeceased = (isset($_POST['MS_SpouseDeceased']) ) ? 'Y': 'N';
                            $sql = "INSERT INTO ".$reTable." (caseID, staffID, maritalstatus, placeofmarriage, dateofmarriage, spousesname, Spousedeceased, dateofdeath, spousesplaceofdeath) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['MS_MaritalStatus']."','".$_POST['MS_PlaceOfMarriage']."','".$_POST['MS_DateOfMarriage']."','".$_POST['MS_SpousesName']."','".$MS_SpouseDeceased."','".$_POST['MS_SDateOfDeath']."','".$_POST['MS_SpousesPlaceOfDeath']."')";
                            break;
                        case 'case_bio_military_service':
                            $MLT_DD214 = (isset($_POST['MLT_DD214']) ) ? 'Y': 'N';
                            $MLT_Headstone = (isset($_POST['MLT_Headstone']) ) ?'Y': 'N';
                            $MLT_ApplicationForBurial = (isset($_POST['MLT_ApplicationForBurial']) ) ? 'Y': 'N';
                            $MLT_ApplicationForFlag = (isset($_POST['MLT_ApplicationForFlag']) ) ?'Y': 'N';
                            $MLT_HonorGuard = (isset($_POST['MLT_HonorGuard']) ) ? 'Y': 'N';
                            
                            $sql = "INSERT INTO ".$reTable." (caseID, staffID, BranchID, WarCampaignID, SerialNumber, Rank, EnlistmentDate, DischargeDate, TypeOfDischargeID, DD214, Headstone, ApplicationForBurial, ApplicationForFlag, HonorGuard) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['MLT_BranchID']."','".$_POST['MLT_warcampaign']."','".$_POST['MLT_SerialNumber']."','".$_POST['MLT_rank']."','".$_POST['MLT_EnlistmentDate']."','".$_POST['MLT_DischargeDate']."','".$_POST['MLT_typeofdischarge']."','".$MLT_DD214."','".$MLT_Headstone."','".$MLT_ApplicationForBurial."','".$MLT_ApplicationForFlag."','".$MLT_HonorGuard."')";
                            break;     
                            case 'case_bio_church':
                                $sql = "INSERT INTO ".$reTable." (caseID, staffID, Church, ClergyName, Address1, Address2, city, states, zip, Email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CHU_Church']."','".$_POST['CHU_ClergyName']."','".$_POST['CHU_Address1']."','".$_POST['CHU_Address2']."','".$_POST['CHU_City']."','".$_POST['CHU_State']."','".$_POST['CHU_Zip']."','".$_POST['CHU_Email']."','".$_POST['CHU_phone']."','".$_POST['CHU_phone2']."')";
                                break;    
                                case 'case_bio_place_of_worship':
                                    $sql = "INSERT INTO ".$reTable." (caseID, staffID, PlaceOfWorship, ClergyName, Address1, Address2, City, States, Zip, Email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['POW_PlaceOfWorship']."','".$_POST['POW_ClergyName']."','".$_POST['POW_Address1']."','".$_POST['POW_Address2']."','".$_POST['POW_City']."','".$_POST['POW_State']."','".$_POST['POW_Zip']."','".$_POST['POW_Email']."','".$_POST['POW_phone']."','".$_POST['POW_phone2']."')";
                                    break;
                                    case 'case_bio_education':
                                        $sql = "INSERT INTO ".$reTable." (caseID, staffID, EduHighSchool, EduHSGraduated, undergraducate, undergraducatedegree, undergraducatedegreecheck, graduate, graducatedegree, graducatedegreecheck) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['EDU_highschool']."','".$_POST['EDU_EduHSGraduated']."','".$_POST['EDU_undergraduatename']."','".$_POST['EDU_undergraducatedegree']."','".$_POST['EDU_undergraducatedegreecheck']."','".$_POST['EDU_graduatename']."','".$_POST['EDU_graducatedegree']."','".$_POST['EDU_graducatedegreecheck']."')";
                                        break;
                                    case 'case_bio_final_disposition':
                                        $FDP_Burial = (isset($_POST['FDP_Burial']) ) ? 'Y': 'N';
                                        $FDP_Entombment = (isset($_POST['FDP_Entombment']) ) ?'Y': 'N';
                                        $FDP_Cremation = (isset($_POST['FDP_Cremation']) ) ? 'Y': 'N';
                                        $FDP_BurialAtSea = (isset($_POST['FDP_BurialAtSea']) ) ?'Y': 'N';
                                        $sql = "INSERT INTO ".$reTable." (caseID, staffID, Burial, Entombment, Cremation, BurialAtSea, DateOfFinalDisposition, FinalDisposition, CemeteryID, Location, Section, FuneralOrMemorialServiceAtID, NameLotRegisteredTo, WhereInLotIsGraveToBeOpened, LotNo, GraveNo) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$FDP_Burial."','".$FDP_Entombment."','".$FDP_Cremation."','".$FDP_BurialAtSea."','".$_POST['FDP_DateOfFinalDisposition']."','".$_POST['FDP_FinalDisposition']."','".$_POST['FDP_cemetery']."','".$_POST['FDP_Location']."','".$_POST['FDP_Section']."','".$_POST['FDP_FuneralOrMemorialServiceAtID']."','".$_POST['FDP_NameLotRegisteredTo']."','".$_POST['FDP_WhereInLotIsGraveToBeOpened']."','".$_POST['FDP_LotNo']."','".$_POST['FDP_GraveNo']."')";
                                        break;
                                    case 'case_bio_final_crematory':
                                        $CRM_WaitTimeMet = (isset($_POST['CRM_WaitTimeMet']) ) ? 'Y': 'N';
                                        $sql = "INSERT INTO ".$reTable." (caseID, staffID, PartyOfInformant, DateOfCremation, TimeOfCremation, WaitTimeMet, DirectorNote) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CRM_PartyOfInformant']."','".$_POST['CRM_DateOfCremation']."','".$_POST['CRM_TimeOfCremation']."','".$CRM_WaitTimeMet."','".$_POST['CRM_FuneralDirectorNote']."')";
                                        break;                                                          
            default:
                break;
        }
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'created');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }  
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_editrecurring'){ // update recent sub-sections
        switch ($reTable) {
            case 'recurring_donation':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['DON_OrgName']."', contact='".$_POST['DON_OrgContact']."',amount='".$_POST['DON_OrgContact']."',address1='".$_POST['DON_Address1']."', address2='".$_POST['DON_Address2']."', city='".$_POST['DON_City']."', states='".$_POST['DON_State']."', zip='".$_POST['DON_Zip']."', email='".$_POST['DON_Email']."', phone='".$_POST['DON_phone']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'statement_informants':
                $selcaseID = isset($_SESSION['selectedcaseID']) ? $_SESSION['selectedcaseID'] : 0;
                // $sql = "INSERT INTO ".$reTable."  ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['INF_InformantName']."','".$_POST['INF_Address1']."','".$_POST['INF_Address2']."','".$_POST['INF_City']."','".$_POST['INF_State']."','".$_POST['INF_Zip']."','".$_POST['INF_SSN']."','".$_POST['INF_Email']."','".$_POST['INF_phone']."','".$_POST['INF_InvoiceDate']."','".$_POST['INF_DueDate']."','".$_POST['INF_note']."')";
                $sql = "UPDATE ".$reTable." SET InformantName='".$_POST['INF_InformantName']."', Address1='".$_POST['INF_Address1']."', Address2='".$_POST['INF_Address2']."', City='".$_POST['INF_City']."', States='".$_POST['INF_State']."', Zip='".$_POST['INF_Zip']."', SSN='".$_POST['INF_SSN']."', Email='".$_POST['INF_Email']."', Phone='".$_POST['INF_phone']."', InvoiceDate='".$_POST['INF_InvoiceDate']."', DueDate='".$_POST['INF_DueDate']."', note='".$_POST['INF_note']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'membership':
                $sql = "UPDATE ".$reTable." SET Name='".$_POST['MSP_name']."', Contact='".$_POST['MSP_contact']."', Address1='".$_POST['MSP_address1']."', Address2='".$_POST['MSP_address2']."', City='".$_POST['MSP_city']."', States='".$_POST['MSP_state']."', Zip='".$_POST['MSP_zip']."', phone='".$_POST['MSP_phone']."', URL='".$_POST['MSP_url']."' WHERE id='".$_POST['rowId']."'"; 
                break;    
            case 'organization':
                $sql = "UPDATE ".$reTable." SET Name='".$_POST['ORGAN_name']."', Contact='".$_POST['ORGAN_contact']."', Address1='".$_POST['ORGAN_address1']."', Address2='".$_POST['ORGAN_address2']."', City='".$_POST['ORGAN_city']."', States='".$_POST['ORGAN_state']."', Zip='".$_POST['ORGAN_zip']."', phone='".$_POST['ORGAN_phone']."', URL='".$_POST['ORGAN_url']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'visitor':
                $sql = "UPDATE ".$reTable." SET Name='".$_POST['VISITOR_name']."', Email='".$_POST['VISITOR_email']."', Address1='".$_POST['VISITOR_address1']."', Address2='".$_POST['VISITOR_address2']."', City='".$_POST['VISITOR_city']."', States='".$_POST['VISITOR_state']."', Zip='".$_POST['VISITOR_zip']."', phone='".$_POST['VISITOR_phone']."', gift='".$_POST['VISITOR_gift']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            //converting
            case 'pre_need_pi':
                $sql = "UPDATE ".$reTable." SET honorific='".$_POST['PI_honorificID']."', firstName='".$_POST['PI_firstname']."', middleName='".$_POST['PI_middlename']."', lastName='".$_POST['PI_lastname']."', suffix='".$_POST['PI_suffix']."', address1='".$_POST['PI_address1']."', address2='".$_POST['PI_address2']."', township='".$_POST['PI_township']."', city='".$_POST['PI_city']."', states='".$_POST['PI_state']."', zipCode='".$_POST['PI_zip']."', country='".$_POST['PI_county']."', nickName='".$_POST['PI_nickname']."', gender='".$_POST['PI_gender']."', SSN='".$_POST['PI_ssn']."', email='".$_POST['PI_email']."', phone='".$_POST['PI_phone']."', dateOfBirth='".$_POST['PI_dob']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'pre_need_nok':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['NOK_fullname']."', address1='".$_POST['NOK_address1']."', address2='".$_POST['NOK_address2']."', city='".$_POST['NOK_city']."', states='".$_POST['NOK_state']."', zip='".$_POST['NOK_zip']."', relationship='".$_POST['NOK_relationship']."', phone='".$_POST['NOK_phone']."', phone2='".$_POST['NOK_phone2']."', email='".$_POST['NOK_email']."' WHERE id='".$_POST['rowId']."'"; 
                // $sql = "INSERT INTO pre_need_nok (caseID, staffID, fullname, address1, address2, city, states, zip, relationship, phone, phone2, email) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['NOK_fullname']."','".$_POST['NOK_address1']."','".$_POST['NOK_address2']."','".$_POST['NOK_city']."','".$_POST['NOK_state']."','".$_POST['NOK_zip']."','".$_POST['NOK_relationship']."','".$_POST['NOK_phone']."','".$_POST['NOK_phone2']."','".$_POST['NOK_email']."')";
                break;
            case 'pre_need_marital':
                $MS_SpouseDeceased = (isset($_POST['MS_SpouseDeceased']) ) ? 'Y': 'N';
                $sql = "UPDATE ".$reTable." SET maritalstatus='".$_POST['MS_MaritalStatus']."', placeofmarriage='".$_POST['MS_PlaceOfMarriage']."', dateofmarriage='".$_POST['MS_DateOfMarriage']."', spousesname='".$_POST['MS_SpousesName']."', Spousedeceased='".$MS_SpouseDeceased."', dateofdeath='".$_POST['MS_SDateOfDeath']."', spousesplaceofdeath='".$_POST['MS_SpousesPlaceOfDeath']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'pre_need_children':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['CLD_FullName']."', address1='".$_POST['CLD_Address1']."', address2='".$_POST['CLD_Address2']."', city='".$_POST['CLD_City']."', states='".$_POST['CLD_State']."', zip='".$_POST['CLD_Zip']."', dob='".$_POST['CLD_DOB']."', relationship='".$_POST['CLD_relationship']."', email='".$_POST['CLD_Email']."', phone='".$_POST['CLD_phone']."', phone2='".$_POST['CLD_phone2']."' WHERE id='".$_POST['rowId']."'"; 
                // $sql = "INSERT INTO ".$reTable." ('".$_POST['CLD_FullName']."','".$_POST['CLD_Address1']."','".$_POST['CLD_Address2']."','".$_POST['CLD_City']."','".$_POST['CLD_State']."','".$_POST['CLD_Zip']."','".$_POST['CLD_DOB']."','".$_POST['CLD_relationship']."','".$_POST['CLD_Email']."','".$_POST['CLD_phone']."','".$_POST['CLD_phone2']."')";
                break;
            case 'pre_need_military_service':
                $MLT_DD214 = (isset($_POST['MLT_DD214']) ) ? 'Y': 'N';
                $MLT_Headstone = (isset($_POST['MLT_Headstone']) ) ?'Y': 'N';
                $MLT_ApplicationForBurial = (isset($_POST['MLT_ApplicationForBurial']) ) ? 'Y': 'N';
                $MLT_ApplicationForFlag = (isset($_POST['MLT_ApplicationForFlag']) ) ?'Y': 'N';
                $MLT_HonorGuard = (isset($_POST['MLT_HonorGuard']) ) ? 'Y': 'N';

                $sql = "UPDATE ".$reTable." SET BranchID='".$_POST['MLT_BranchID']."', WarCampaignID='".$_POST['MLT_warcampaign']."', SerialNumber='".$_POST['MLT_SerialNumber']."', Rank='".$_POST['MLT_rank']."', EnlistmentDate='".$_POST['MLT_EnlistmentDate']."', DischargeDate='".$_POST['MLT_DischargeDate']."', TypeOfDischargeID='".$_POST['MLT_typeofdischarge']."', DD214='".$MLT_DD214."', Headstone='".$MLT_Headstone."', ApplicationForBurial='".$MLT_ApplicationForBurial."', ApplicationForFlag='".$MLT_ApplicationForFlag."', MLT_HonorGuard='".$MLT_HonorGuard."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'pre_need_church':
                $sql = "UPDATE ".$reTable." SET Church='".$_POST['CHU_Church']."', ClergyName='".$_POST['CHU_ClergyName']."', Address1='".$_POST['CHU_Address1']."', Address2='".$_POST['CHU_Address2']."', city='".$_POST['CHU_City']."', states='".$_POST['CHU_State']."', zip='".$_POST['CHU_Zip']."', Email='".$_POST['CHU_Email']."', phone='".$_POST['CHU_phone']."', phone2='".$_POST['CHU_phone2']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'pre_need_place_of_worship':
                $sql = "UPDATE ".$reTable." SET PlaceOfWorship='".$_POST['POW_PlaceOfWorship']."', ClergyName='".$_POST['POW_ClergyName']."', Address1='".$_POST['POW_Address1']."', Address2='".$_POST['POW_Address2']."', City='".$_POST['POW_City']."', States='".$_POST['POW_State']."', Zip='".$_POST['POW_Zip']."', Email='".$_POST['POW_Email']."', phone='".$_POST['POW_phone']."', phone2='".$_POST['POW_phone2']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'pre_need_education':
                $EDU_EduHSGraduated = (isset($_POST['EDU_EduHSGraduated']) ) ? 'Y': 'N';
                $EDU_undergraducatedegreecheck = (isset($_POST['EDU_undergraducatedegreecheck']) ) ?'Y': 'N';
                $EDU_graducatedegreecheck = (isset($_POST['EDU_graducatedegreecheck']) ) ? 'Y': 'N';
                $sql = "UPDATE ".$reTable." SET EduHighSchool='".$_POST['EDU_highschool']."',EduHSGraduated='".$EDU_EduHSGraduated."', undergraducate='".$_POST['EDU_undergraduatename']."', undergraducatedegree='".$_POST['EDU_undergraducatedegree']."', undergraducatedegreecheck='".$EDU_undergraducatedegreecheck."', graduate='".$_POST['EDU_graduatename']."', graducatedegree='".$_POST['EDU_graducatedegree']."', graducatedegreecheck='".$EDU_graducatedegreecheck."' WHERE id='".$_POST['rowId']."'";                           
                break;
            case 'pre_need_parents':
                $sql = "UPDATE ".$reTable." SET ParentDeceasedFathersDOB='".$_POST['PAT_ParentDeceasedFathersDOB']."', ParentsDeceasedFathersDOD='".$_POST['PAT_ParentsDeceasedFathersDOD']."', ParentsDeceasedMothersDOB='".$_POST['PAT_ParentsDeceasedMothersDOB']."', ParentsDeceasedMothersDOD='".$_POST['PAT_ParentsDeceasedMothersDOD']."'"; 
                break;
            case 'pre_need_final_disposition':
                $FDP_Burial = (isset($_POST['FDP_Burial']) ) ? 'Y': 'N';
                $FDP_Entombment = (isset($_POST['FDP_Entombment']) ) ?'Y': 'N';
                $FDP_Cremation = (isset($_POST['FDP_Cremation']) ) ? 'Y': 'N';
                $FDP_BurialAtSea = (isset($_POST['FDP_BurialAtSea']) ) ?'Y': 'N';
                $sql = "UPDATE ".$reTable." SET Burial='".$FDP_Burial."',Entombment='".$FDP_Entombment."', Cremation='".$FDP_Cremation."', BurialAtSea='".$FDP_BurialAtSea."', DateOfFinalDisposition='".$_POST['FDP_DateOfFinalDisposition']."', FinalDisposition='".$_POST['FDP_FinalDisposition']."', CemeteryID='".$_POST['FDP_cemetery']."', Location='".$_POST['FDP_Location']."', Section='".$_POST['FDP_Section']."', FuneralOrMemorialServiceAtID='".$_POST['FDP_FuneralOrMemorialServiceAtID']."', NameLotRegisteredTo='".$_POST['FDP_NameLotRegisteredTo']."', WhereInLotIsGraveToBeOpened='".$_POST['FDP_WhereInLotIsGraveToBeOpened']."', LotNo='".$_POST['FDP_LotNo']."', GraveNo='".$_POST['FDP_GraveNo']."' WHERE id='".$_POST['rowId']."'";                           
                break;
            case 'pre_need_final_crematory':
                $CRM_WaitTimeMet = (isset($_POST['CRM_WaitTimeMet']) ) ? 'Y': 'N';
                $sql = "UPDATE ".$reTable." SET PartyOfInformant='".$_POST['CRM_PartyOfInformant']."', DateOfCremation='".$_POST['CRM_DateOfCremation']."', TimeOfCremation='".$_POST['CRM_TimeOfCremation']."', WaitTimeMet='".$CRM_WaitTimeMet."', DirectorNote='".$_POST['CRM_FuneralDirectorNote']."' WHERE id='".$_POST['rowId']."'"; 
                break;

            case 'case_bio_marital':
                $MS_SpouseDeceased = (isset($_POST['MS_SpouseDeceased']) ) ? 'Y': 'N';
                $sql = "UPDATE ".$reTable." SET maritalstatus='".$_POST['MS_MaritalStatus']."', placeofmarriage='".$_POST['MS_PlaceOfMarriage']."', dateofmarriage='".$_POST['MS_DateOfMarriage']."', spousesname='".$_POST['MS_SpousesName']."', Spousedeceased='".$MS_SpouseDeceased."', dateofdeath='".$_POST['MS_SDateOfDeath']."', spousesplaceofdeath='".$_POST['MS_SpousesPlaceOfDeath']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'case_bio_military_service':
                $MLT_DD214 = (isset($_POST['MLT_DD214']) ) ? 'Y': 'N';
                $MLT_Headstone = (isset($_POST['MLT_Headstone']) ) ?'Y': 'N';
                $MLT_ApplicationForBurial = (isset($_POST['MLT_ApplicationForBurial']) ) ? 'Y': 'N';
                $MLT_ApplicationForFlag = (isset($_POST['MLT_ApplicationForFlag']) ) ?'Y': 'N';
                $MLT_HonorGuard = (isset($_POST['MLT_HonorGuard']) ) ? 'Y': 'N';

                $sql = "UPDATE ".$reTable." SET BranchID='".$_POST['MLT_BranchID']."', WarCampaignID='".$_POST['MLT_warcampaign']."', SerialNumber='".$_POST['MLT_SerialNumber']."', Rank='".$_POST['MLT_rank']."', EnlistmentDate='".$_POST['MLT_EnlistmentDate']."', DischargeDate='".$_POST['MLT_DischargeDate']."', TypeOfDischargeID='".$_POST['MLT_typeofdischarge']."', DD214='".$MLT_DD214."', Headstone='".$MLT_Headstone."', ApplicationForBurial='".$MLT_ApplicationForBurial."', ApplicationForFlag='".$MLT_ApplicationForFlag."', MLT_HonorGuard='".$MLT_HonorGuard."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'case_bio_church':
                $sql = "UPDATE ".$reTable." SET Church='".$_POST['CHU_Church']."', ClergyName='".$_POST['CHU_ClergyName']."', Address1='".$_POST['CHU_Address1']."', Address2='".$_POST['CHU_Address2']."', city='".$_POST['CHU_City']."', states='".$_POST['CHU_State']."', zip='".$_POST['CHU_Zip']."', Email='".$_POST['CHU_Email']."', phone='".$_POST['CHU_phone']."', phone2='".$_POST['CHU_phone2']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'case_bio_place_of_worship':
                $sql = "UPDATE ".$reTable." SET PlaceOfWorship='".$_POST['POW_PlaceOfWorship']."', ClergyName='".$_POST['POW_ClergyName']."', Address1='".$_POST['POW_Address1']."', Address2='".$_POST['POW_Address2']."', City='".$_POST['POW_City']."', States='".$_POST['POW_State']."', Zip='".$_POST['POW_Zip']."', Email='".$_POST['POW_Email']."', phone='".$_POST['POW_phone']."', phone2='".$_POST['POW_phone2']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'case_bio_education':
                $EDU_EduHSGraduated = (isset($_POST['EDU_EduHSGraduated']) ) ? 'Y': 'N';
                $EDU_undergraducatedegreecheck = (isset($_POST['EDU_undergraducatedegreecheck']) ) ?'Y': 'N';
                $EDU_graducatedegreecheck = (isset($_POST['EDU_graducatedegreecheck']) ) ? 'Y': 'N';
                $sql = "UPDATE ".$reTable." SET EduHighSchool='".$_POST['EDU_highschool']."',EduHSGraduated='".$EDU_EduHSGraduated."', undergraducate='".$_POST['EDU_undergraduatename']."', undergraducatedegree='".$_POST['EDU_undergraducatedegree']."', undergraducatedegreecheck='".$EDU_undergraducatedegreecheck."', graduate='".$_POST['EDU_graduatename']."', graducatedegree='".$_POST['EDU_graducatedegree']."', graducatedegreecheck='".$EDU_graducatedegreecheck."' WHERE id='".$_POST['rowId']."'";                           
                break;
            case 'case_bio_parents':
                $sql = "UPDATE ".$reTable." SET FathersName='".$_POST['PAI_fatherName']."', FDOB='".$_POST['PAI_FDOB']."', FPlaceOfBirth='".$_POST['PAI_FPlaceOfBirth']."', MothersName='".$_POST['PAI_motherName']."', MothersMaidenName='".$_POST['PAI_maidenName']."', MDOB='".$_POST['PAI_MDOB']."', MPlaceOfBirth='".$_POST['PAI_MPlaceOfBirth']."'";                   
                break;
            case 'pre_need_final_crematory':
                $CRM_WaitTimeMet = (isset($_POST['CRM_WaitTimeMet']) ) ? 'Y': 'N';
                $sql = "UPDATE ".$reTable." SET PartyOfInformant='".$_POST['CRM_PartyOfInformant']."', DateOfCremation='".$_POST['CRM_DateOfCremation']."', TimeOfCremation='".$_POST['CRM_TimeOfCremation']."', WaitTimeMet='".$CRM_WaitTimeMet."', DirectorNote='".$_POST['CRM_FuneralDirectorNote']."' WHERE id='".$_POST['rowId']."'"; 
                break;

            case 'at_need_pi':
                $sql = "UPDATE ".$reTable." SET honorific='".$_POST['PF_honorific']."', firstName='".$_POST['PF_firstname']."', middleName='".$_POST['PF_middlename']."', lastName='".$_POST['PF_lastName']."', suffix='".$_POST['PF_suffix']."', address1='".$_POST['PF_address1']."', address2='".$_POST['PF_address2']."', township='".$_POST['PF_township']."', city='".$_POST['PF_city']."', states='".$_POST['PF_state']."', zipCode='".$_POST['PF_zip']."', country='".$_POST['PF_county']."', nickName='".$_POST['PF_nickname']."', gender='".$_POST['PF_gender']."', SSN='".$_POST['PF_ssn']."', email='".$_POST['PF_email']."', phone='".$_POST['PF_phone']."', dateOfDeath='".$_POST['PF_dod']."', timeOfDeath='".$_POST['PF_tode']."', dateOfBirth='".$_POST['PF_dob']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'at_need_nok':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['NOK_fullname']."', address1='".$_POST['NOK_address1']."', address2='".$_POST['NOK_address2']."', city='".$_POST['NOK_city']."', states='".$_POST['NOK_state']."', zip='".$_POST['NOK_zip']."', relationship='".$_POST['NOK_relationship']."', phone='".$_POST['NOK_phone']."', phone2='".$_POST['NOK_phone2']."', email='".$_POST['NOK_email']."' WHERE id='".$_POST['rowId']."'"; 
                // $sql = "INSERT INTO pre_need_nok (caseID, staffID, fullname, address1, address2, city, states, zip, relationship, phone, phone2, email) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['NOK_fullname']."','".$_POST['NOK_address1']."','".$_POST['NOK_address2']."','".$_POST['NOK_city']."','".$_POST['NOK_state']."','".$_POST['NOK_zip']."','".$_POST['NOK_relationship']."','".$_POST['NOK_phone']."','".$_POST['NOK_phone2']."','".$_POST['NOK_email']."')";
                break;
            //recurring 
            case 'contractor':
                $CNTR_bodypickkup = (isset($_POST['CNTR_bodypickkup']) ) ? 'Y': 'N';
                $CNTR_embalm = (isset($_POST['CNTR_embalm']) ) ?'Y': 'N';
                $sql = "UPDATE ".$reTable." SET funeralhome='".$_POST['CNTR_funeralhome']."', fullname='".$_POST['CNTR_fullname']."', address1='".$_POST['CNTR_address1']."', address2='".$_POST['CNTR_address2']."', city='".$_POST['CNTR_city']."', states='".$_POST['CNTR_state']."', zip='".$_POST['CNTR_zip']."', statelicense='".$_POST['CNTR_statelicense']."', stateissued='".$_POST['CNTR_stateissued']."', email='".$_POST['CNTR_email']."', phone='".$_POST['CNTR_phone']."', phone2='".$_POST['CNTR_phone2']."', bodypickkup='".$CNTR_bodypickkup."', embalm='".$CNTR_embalm."' WHERE id='".$_POST['rowId']."'"; 
                // $sql = "INSERT INTO contractor (caseID, staffID, funeralhome, fullname, address1, address2, city, states, zip, statelicense, stateissued, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CNTR_funeralhome']."','".$_POST['CNTR_fullname']."','".$_POST['CNTR_address1']."','".$_POST['CNTR_address2']."','".$_POST['CNTR_city']."','".$_POST['CNTR_state']."','".$_POST['CNTR_zip']."','".$_POST['CNTR_statelicense']."','".$_POST['CNTR_stateissued']."','".$_POST['CNTR_email']."','".$_POST['CNTR_phone']."','".$_POST['CNTR_phone2']."')";
                break;
            case 'final_arrange_vocalist':  
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['VOC_FullName']."', address1='".$_POST['VOC_Address1']."', address2='".$_POST['VOC_Address2']."', city='".$_POST['VOC_City']."', states='".$_POST['VOC_State']."', zip='".$_POST['VOC_Zip']."', email='".$_POST['VOC_Email']."', phone='".$_POST['VOC_phone']."' WHERE id='".$_POST['rowId']."'"; 
                // $sql = "INSERT INTO final_arrange_vocalist (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['VOC_FullName']."','".$_POST['VOC_Address1']."','".$_POST['VOC_Address2']."','".$_POST['VOC_City']."','".$_POST['VOC_State']."','".$_POST['VOC_Zip']."','".$_POST['VOC_Email']."','".$_POST['VOC_phone']."')";
                break;
            case 'final_arrange_organist': 
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['ORG_FullName']."', address1='".$_POST['ORG_Address1']."', address2='".$_POST['ORG_Address2']."', city='".$_POST['ORG_City']."', states='".$_POST['ORG_State']."', zip='".$_POST['ORG_Zip']."', email='".$_POST['ORG_Email']."', phone='".$_POST['ORG_phone']."' WHERE id='".$_POST['rowId']."'"; 
                // $sql = "INSERT INTO final_arrange_organist (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['ORG_FullName']."','".$_POST['ORG_Address1']."','".$_POST['ORG_Address2']."','".$_POST['ORG_City']."','".$_POST['ORG_State']."','".$_POST['ORG_Zip']."','".$_POST['ORG_Email']."','".$_POST['ORG_phone']."')";
                break;
            case 'final_arrange_cosmetologist':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['COS_FullName']."', address1='".$_POST['COS_Address1']."', address2='".$_POST['COS_Address2']."', city='".$_POST['COS_City']."', states='".$_POST['COS_State']."', zip='".$_POST['COS_Zip']."', email='".$_POST['COS_Email']."', phone='".$_POST['COS_phone']."' WHERE id='".$_POST['rowId']."'"; 
                // $sql = "INSERT INTO final_arrange_cosmetologist (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['COS_FullName']."','".$_POST['COS_Address1']."','".$_POST['COS_Address2']."','".$_POST['COS_City']."','".$_POST['COS_State']."','".$_POST['COS_Zip']."','".$_POST['COS_Email']."','".$_POST['COS_phone']."')";
                break;
            case 'final_arrange_beauticianbarber':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['BB_FullName']."', address1='".$_POST['BB_Address1']."', address2='".$_POST['BB_Address2']."', city='".$_POST['BB_City']."', states='".$_POST['BB_State']."', zip='".$_POST['BB_Zip']."', email='".$_POST['BB_Email']."', phone='".$_POST['BB_phone']."', gender='".$_POST['BB_gender']."' WHERE id='".$_POST['rowId']."'"; 
                // $sql = "INSERT INTO final_arrange_beauticianbarber (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, gender) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['BB_FullName']."','".$_POST['BB_Address1']."','".$_POST['BB_Address2']."','".$_POST['BB_City']."','".$_POST['BB_State']."','".$_POST['BB_Zip']."','".$_POST['BB_Email']."','".$_POST['BB_phone']."','".$_POST['BB_gender']."')";
                break;
            case 'final_arrange_pallbearer':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['PB_FullName']."', address1='".$_POST['PB_Address1']."', address2='".$_POST['PB_Address2']."', city='".$_POST['PB_City']."', states='".$_POST['PB_State']."', zip='".$_POST['PB_Zip']."', email='".$_POST['PB_Email']."', phone='".$_POST['PB_phone']."' WHERE id='".$_POST['rowId']."'"; 
                // $sql = "INSERT INTO final_arrange_pallbearer (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['PB_FullName']."','".$_POST['PB_Address1']."','".$_POST['PB_Address2']."','".$_POST['PB_City']."','".$_POST['PB_State']."','".$_POST['PB_Zip']."','".$_POST['PB_Email']."','".$_POST['PB_phone']."')";
                break;
            case 'final_arrange_honorarypallbearer':     
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['HPB_FullName']."', address1='".$_POST['HPB_Address1']."', address2='".$_POST['HPB_Address2']."', city='".$_POST['HPB_City']."', states='".$_POST['HPB_State']."', zip='".$_POST['HPB_Zip']."', email='".$_POST['HPB_Email']."', phone='".$_POST['HPB_phone']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_honorarypallbearer (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['HPB_FullName']."','".$_POST['HPB_Address1']."','".$_POST['HPB_Address2']."','".$_POST['HPB_City']."','".$_POST['HPB_State']."','".$_POST['HPB_Zip']."','".$_POST['HPB_Email']."','".$_POST['HPB_phone']."')";
                break;

            case 'final_arrange_clergy':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['CHUR_FullName']."', address1='".$_POST['CHUR_Address1']."', address2='".$_POST['CHUR_Address2']."', city='".$_POST['CHUR_City']."', states='".$_POST['CHUR_State']."', zip='".$_POST['CHUR_Zip']."', email='".$_POST['CHUR_Email']."', phone='".$_POST['CHUR_phone']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_clergy (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CHUR_FullName']."','".$_POST['CHUR_Address1']."','".$_POST['CHUR_Address2']."','".$_POST['CHUR_City']."','".$_POST['CHUR_State']."','".$_POST['CHUR_Zip']."','".$_POST['CHUR_Email']."','".$_POST['CHUR_phone']."')";
                break;
            case 'final_arrange_driver':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['DRV_FullName']."', address1='".$_POST['DRV_Address1']."', address2='".$_POST['DRV_Address2']."', city='".$_POST['DRV_City']."', states='".$_POST['DRV_State']."', zip='".$_POST['DRV_Zip']."', email='".$_POST['DRV_Email']."', phone='".$_POST['DRV_phone']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_driver (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['DRV_FullName']."','".$_POST['DRV_Address1']."','".$_POST['DRV_Address2']."','".$_POST['DRV_City']."','".$_POST['DRV_State']."','".$_POST['DRV_Zip']."','".$_POST['DRV_Email']."','".$_POST['DRV_phone']."')";
                break;
            case 'final_arrange_escort':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['ESC_FullName']."', address1='".$_POST['ESC_Address1']."', address2='".$_POST['ESC_Address2']."', city='".$_POST['ESC_City']."', states='".$_POST['ESC_State']."', zip='".$_POST['ESC_Zip']."', email='".$_POST['ESC_Email']."', phone='".$_POST['ESC_phone']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_escort (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['ESC_FullName']."','".$_POST['ESC_Address1']."','".$_POST['ESC_Address2']."','".$_POST['ESC_City']."','".$_POST['ESC_State']."','".$_POST['ESC_Zip']."','".$_POST['ESC_Email']."','".$_POST['ESC_phone']."')";
                break;
            case 'final_arrange_florist':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['FLOR_FullName']."', address1='".$_POST['FLOR_Address1']."', address2='".$_POST['FLOR_Address2']."', city='".$_POST['FLOR_City']."', states='".$_POST['FLOR_State']."', zip='".$_POST['FLOR_Zip']."', email='".$_POST['FLOR_Email']."', phone='".$_POST['FLOR_phone']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_florist (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['FLOR_FullName']."','".$_POST['FLOR_Address1']."','".$_POST['FLOR_Address2']."','".$_POST['FLOR_City']."','".$_POST['FLOR_State']."','".$_POST['FLOR_Zip']."','".$_POST['FLOR_Email']."','".$_POST['FLOR_phone']."')";
                break;
            case 'final_arrange_sexton':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['SEX_FullName']."', address1='".$_POST['SEX_Address1']."', address2='".$_POST['SEX_Address2']."', city='".$_POST['SEX_City']."', states='".$_POST['SEX_State']."', zip='".$_POST['SEX_Zip']."', email='".$_POST['SEX_Email']."', phone='".$_POST['SEX_phone']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_sexton (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['SEX_FullName']."','".$_POST['SEX_Address1']."','".$_POST['SEX_Address2']."','".$_POST['SEX_City']."','".$_POST['SEX_State']."','".$_POST['SEX_Zip']."','".$_POST['SEX_Email']."','".$_POST['SEX_phone']."')";
                break;
            case 'final_arrange_service':
                $sql = "UPDATE ".$reTable." SET StartDate='".$_POST['SER_StartDate']."', StartTime='".$_POST['SER_StartTime']."', EndDate='".$_POST['SER_EndDate']."', EndTime='".$_POST['SER_EndTime']."', ServiceName='".$_POST['SER_Service']."', ServiceAddress='".$_POST['SER_Address']."', city='".$_POST['SER_City']."', states='".$_POST['SER_State']."', Telephone='".$_POST['SER_Telephone']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_service (caseID, staffID, StartDate, StartTime, EndDate, EndTime, ServiceName, ServiceAddress, city, states, Telephone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['SER_StartDate']."','".$_POST['SER_StartTime']."','".$_POST['SER_EndDate']."','".$_POST['SER_EndTime']."','".$_POST['SER_Service']."','".$_POST['SER_Address']."','".$_POST['SER_City']."','".$_POST['SER_State']."','".$_POST['SER_Telephone']."')";
                break;
            case 'final_arrange_visitation':     
                $sql = "UPDATE ".$reTable." SET StartDate='".$_POST['VIS_StartDate']."', StartTime='".$_POST['VIS_StartTime']."', EndDate='".$_POST['VIS_EndDate']."', EndTime='".$_POST['VIS_EndTime']."', VisitationName='".$_POST['VIS_Visitation']."', VisitationAddress='".$_POST['VIS_Address']."', city='".$_POST['VIS_City']."', states='".$_POST['VIS_State']."', phone='".$_POST['VIS_Telephone']."' WHERE id='".$_POST['rowId']."'"; 
                break;
            case 'final_arrange_funeral_home':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['FUNHOMCRE_FullName']."', address1='".$_POST['FUNHOMCRE_Address1']."', address2='".$_POST['FUNHOMCRE_Address2']."', city='".$_POST['FUNHOMCRE_City']."', states='".$_POST['FUNHOMCRE_State']."', zip='".$_POST['FUNHOMCRE_Zip']."', email='".$_POST['FUNHOMCRE_Email']."', phone='".$_POST['FUNHOMCRE_phone']."', contact='".$_POST['FUNHOMCRE_Contact']."', license='".$_POST['FUNHOMCRE_l']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_funeral_home (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone,contact,license) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['FUNHOMCRE_FullName']."','".$_POST['FUNHOMCRE_Address1']."','".$_POST['FUNHOMCRE_Address2']."','".$_POST['FUNHOMCRE_City']."','".$_POST['FUNHOMCRE_State']."','".$_POST['FUNHOMCRE_Zip']."','".$_POST['FUNHOMCRE_Email']."','".$_POST['FUNHOMCRE_phone']."','".$_POST['FUNHOMCRE_Contact']."','".$_POST['FUNHOMCRE_l']."')";
                break;
            //not used in the Final Arrangement section yet
            case 'final_arrange_cemetery':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['CEM_Name']."', contact='".$_POST['CEM_Contact']."', address1='".$_POST['CEM_Address1']."', address2='".$_POST['CEM_Address2']."', city='".$_POST['CEM_City']."', states='".$_POST['CEM_State']."', zip='".$_POST['CEM_Zip']."', email='".$_POST['CEM_Email']."', phone='".$_POST['CEM_phone']."', phone2='".$_POST['CEM_phone2']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_cemetery (caseID, staffID, fullname, contact, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CEM_Name']."','".$_POST['CEM_Contact']."','".$_POST['CEM_Address1']."','".$_POST['CEM_Address2']."','".$_POST['CEM_City']."','".$_POST['CEM_State']."','".$_POST['CEM_Zip']."','".$_POST['CEM_Email']."','".$_POST['CEM_phone']."','".$_POST['CEM_phone2']."')";
                break;
            case 'final_arrange_colorguard':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['CG_Name']."', address1='".$_POST['CG_Address1']."', address2='".$_POST['CG_Address2']."', city='".$_POST['CG_City']."', states='".$_POST['CG_State']."', zip='".$_POST['CG_Zip']."', email='".$_POST['CG_Email']."', phone='".$_POST['CG_phone']."', phone2='".$_POST['CG_phone2']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_colorguard (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CG_Name']."','".$_POST['CG_Address1']."','".$_POST['CG_Address2']."','".$_POST['CG_City']."','".$_POST['CG_State']."','".$_POST['CG_Zip']."','".$_POST['CG_Email']."','".$_POST['CG_phone']."','".$_POST['CG_phone2']."')";
                break;
            case 'final_arrange_distributor':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['DTB_Name']."', address1='".$_POST['DTB_Address1']."', address2='".$_POST['DTB_Address2']."', city='".$_POST['DTB_City']."', states='".$_POST['DTB_State']."', zip='".$_POST['DTB_Zip']."', email='".$_POST['DTB_Email']."', phone='".$_POST['DTB_phone']."', phone2='".$_POST['DTB_phone2']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_distributor (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['DTB_Name']."','".$_POST['DTB_Address1']."','".$_POST['DTB_Address2']."','".$_POST['DTB_City']."','".$_POST['DTB_State']."','".$_POST['DTB_Zip']."','".$_POST['DTB_Email']."','".$_POST['DTB_phone']."',,'".$_POST['DTB_phone2']."')";
                break;
            case 'final_arrange_equipment':
                $sql = "UPDATE ".$reTable." SET resource='".$_POST['EQU_resource']."', name='".$_POST['EQU_Name']."', make='".$_POST['EQU_Make']."', model='".$_POST['EQU_Model']."', yearpurchase='".$_POST['EQU_purdate']."', quantity='".$_POST['EQU_Qty']."', phone='".$_POST['EQU_phone']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_equipment (caseID, staffID, resource, name, make, model, yearpurchase, quantity, phone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['EQU_resource']."','".$_POST['EQU_Name']."','".$_POST['EQU_Make']."','".$_POST['EQU_Model']."','".$_POST['EQU_purdate']."','".$_POST['EQU_Qty']."','".$_POST['EQU_phone']."')";
                break;
            case 'final_arrange_manufacturer':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['MANU_Name']."', address1='".$_POST['MANU_Address1']."', address2='".$_POST['MANU_Address2']."', city='".$_POST['MANU_City']."', states='".$_POST['MANU_State']."', zip='".$_POST['MANU_Zip']."', email='".$_POST['MANU_Email']."', phone='".$_POST['MANU_phone']."', phone2='".$_POST['MANU_phone2']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_manufacturer (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['MANU_Name']."','".$_POST['MANU_Address1']."','".$_POST['MANU_Address2']."','".$_POST['MANU_City']."','".$_POST['MANU_State']."','".$_POST['MANU_Zip']."','".$_POST['MANU_Email']."','".$_POST['MANU_phone']."','".$_POST['MANU_phone2']."')";
                break;
            case 'final_arrange_salesperson':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['SALER_Name']."', address1='".$_POST['SALER_Address1']."', address2='".$_POST['SALER_Address2']."', city='".$_POST['SALER_City']."', states='".$_POST['SALER_State']."', zip='".$_POST['SALER_Zip']."', email='".$_POST['SALER_Email']."', phone='".$_POST['SALER_phone']."', phone2='".$_POST['SALER_phone2']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_salesperson (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['SALER_Name']."','".$_POST['SALER_Address1']."','".$_POST['SALER_Address2']."','".$_POST['SALER_City']."','".$_POST['SALER_State']."','".$_POST['SALER_Zip']."','".$_POST['SALER_Email']."','".$_POST['SALER_phone']."','".$_POST['SALER_phone2']."')";
                break;
            case 'final_arrange_volunteer':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['VOLN_FullName']."', address1='".$_POST['VOLN_Address1']."', address2='".$_POST['VOLN_Address1']."', city='".$_POST['VOLN_City']."', states='".$_POST['VOLN_State']."', zip='".$_POST['VOLN_Zip']."', email='".$_POST['VOLN_Email']."', phone='".$_POST['VOLN_phone']."', phone2='".$_POST['VOLN_phone2']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_volunteer (caseID, staffID, fullname, address1, address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['VOLN_FullName']."','".$_POST['VOLN_Address1']."','".$_POST['VOLN_Address2']."','".$_POST['VOLN_City']."','".$_POST['VOLN_State']."','".$_POST['VOLN_Zip']."','".$_POST['VOLN_Email']."','".$_POST['VOLN_phone']."','".$_POST['VOLN_phone2']."')";
                break;
            case 'final_arrange_church':
                $sql = "UPDATE ".$reTable." SET Church='".$_POST['CHU_Church']."',ClergyName='".$_POST['CHU_ClergyName']."', Address1='".$_POST['CHU_Address1']."', Address2='".$_POST['CHU_Address2']."', city='".$_POST['CHU_City']."', states='".$_POST['CHU_State']."', zip='".$_POST['CHU_Zip']."', Email='".$_POST['CHU_Email']."', phone='".$_POST['CHU_phone']."', phone2='".$_POST['CHU_phone2']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_church (caseID, staffID, Church, ClergyName, Address1, Address2, city, states, zip, Email,phone,phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CHU_Church']."','".$_POST['CHU_ClergyName']."','".$_POST['CHU_Address1']."','".$_POST['CHU_Address2']."','".$_POST['CHU_City']."','".$_POST['CHU_State']."','".$_POST['CHU_Zip']."','".$_POST['CHU_Email']."','".$_POST['CHU_phone']."','".$_POST['CHU_phone2']."')";
                break;
            case 'final_arrange_education':
                $EDU_EduHSGraduated = (isset($_POST['EDU_EduHSGraduated']) ) ? 'Y': 'N';
                $EDU_undergraducatedegreecheck = (isset($_POST['EDU_undergraducatedegreecheck']) ) ?'Y': 'N';
                $EDU_graducatedegreecheck = (isset($_POST['EDU_graducatedegreecheck']) ) ? 'Y': 'N';
                $sql = "UPDATE ".$reTable." SET EduHighSchool='".$_POST['EDU_highschool']."',EduHSGraduated='".$EDU_EduHSGraduated."', undergraducate='".$_POST['EDU_undergraduatename']."', undergraducatedegree='".$_POST['EDU_undergraducatedegree']."', undergraducatedegreecheck='".$EDU_undergraducatedegreecheck."', graduate='".$_POST['EDU_graduatename']."', graducatedegree='".$_POST['EDU_graducatedegree']."', graducatedegreecheck='".$EDU_graducatedegreecheck."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_education (caseID, staffID, EduHighSchool, EduHSGraduated, undergraducate, undergraducatedegree, undergraducatedegreecheck, graduate, graducatedegree, graducatedegreecheck) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['EDU_highschool']."','".$_POST['EDU_EduHSGraduated']."','".$_POST['EDU_undergraduatename']."','".$_POST['EDU_undergraducatedegree']."','".$_POST['EDU_undergraducatedegreecheck']."','".$_POST['EDU_graduatename']."','".$_POST['EDU_graducatedegree']."','".$_POST['EDU_graducatedegreecheck']."')";
                break;
            case 'final_arrange_final_crematory':
                $sql = "UPDATE ".$reTable." SET PartyOfInformant='".$_POST['CRM_PartyOfInformant']."',DateOfCremation='".$_POST['CRM_DateOfCremation']."', TimeOfCremation='".$_POST['CRM_TimeOfCremation']."', WaitTimeMet='".$_POST['CRM_WaitTimeMet']."', DirectorNote='".$_POST['CRM_FuneralDirectorNote']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_final_crematory (caseID, staffID, PartyOfInformant, DateOfCremation, TimeOfCremation, WaitTimeMet, DirectorNote) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CRM_PartyOfInformant']."','".$_POST['CRM_DateOfCremation']."','".$_POST['CRM_TimeOfCremation']."','".$_POST['CRM_WaitTimeMet']."','".$_POST['CRM_FuneralDirectorNote']."')";
                break;
            case 'final_arrange_final_disposition':
                $FDP_Burial = (isset($_POST['FDP_Burial']) ) ? 'Y': 'N';
                $FDP_Entombment = (isset($_POST['FDP_Entombment']) ) ?'Y': 'N';
                $FDP_Cremation = (isset($_POST['FDP_Cremation']) ) ? 'Y': 'N';
                $FDP_BurialAtSea = (isset($_POST['FDP_BurialAtSea']) ) ? 'Y': 'N';
                $sql = "UPDATE ".$reTable." SET Burial='".$FDP_Burial."',Entombment='".$FDP_Entombment."', Cremation='".$FDP_Cremation."', BurialAtSea='".$FDP_BurialAtSea."', DateOfFinalDisposition='".$_POST['FDP_DateOfFinalDisposition']."', FinalDisposition='".$_POST['FDP_FinalDisposition']."', CemeteryID='".$_POST['FDP_cemetery']."', Location='".$_POST['FDP_Location']."', Section='".$_POST['FDP_Section']."', FuneralOrMemorialServiceAtID='".$_POST['FDP_FuneralOrMemorialServiceAtID']."', NameLotRegisteredTo='".$_POST['FDP_NameLotRegisteredTo']."', WhereInLotIsGraveToBeOpened='".$_POST['FDP_WhereInLotIsGraveToBeOpened']."', LotNo='".$_POST['FDP_LotNo']."', GraveNo='".$_POST['FDP_GraveNo']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_final_disposition (caseID, staffID, Burial, Entombment, Cremation, BurialAtSea, DateOfFinalDisposition, FinalDisposition, CemeteryID, Location, Section, FuneralOrMemorialServiceAtID, NameLotRegisteredTo, WhereInLotIsGraveToBeOpened, LotNo, GraveNo) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['FDP_Burial']."','".$_POST['FDP_Entombment']."','".$_POST['FDP_Cremation']."','".$_POST['FDP_BurialAtSea']."','".$_POST['FDP_DateOfFinalDisposition']."','".$_POST['FDP_FinalDisposition']."','".$_POST['FDP_cemetery']."','".$_POST['FDP_Location']."','".$_POST['FDP_Section']."','".$_POST['FDP_FuneralOrMemorialServiceAtID']."','".$_POST['FDP_NameLotRegisteredTo']."','".$_POST['FDP_WhereInLotIsGraveToBeOpened']."','".$_POST['FDP_LotNo']."','".$_POST['FDP_GraveNo']."')";
                break;
            case 'final_arrange_children':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['CLD_FullName']."', address1='".$_POST['CLD_Address1']."', address2='".$_POST['CLD_Address2']."', city='".$_POST['CLD_City']."', states='".$_POST['CLD_State']."', zip='".$_POST['CLD_Zip']."',dob='".$_POST['CLD_DOB']."',relationship='".$_POST['CLD_relationship']."', email='".$_POST['CLD_Email']."', phone='".$_POST['CLD_phone']."', phone2='".$_POST['CLD_phone2']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_children (caseID, staffID, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CLD_FullName']."','".$_POST['CLD_Address1']."','".$_POST['CLD_Address2']."','".$_POST['CLD_City']."','".$_POST['CLD_State']."','".$_POST['CLD_Zip']."','".$_POST['CLD_DOB']."','".$_POST['CLD_relationship']."','".$_POST['CLD_Email']."','".$_POST['CLD_phone']."','".$_POST['CLD_phone2']."')";
                break;
            case 'final_arrange_grand_children':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['GCLD_FullName']."', address1='".$_POST['GCLD_Address1']."', address2='".$_POST['GCLD_Address2']."', city='".$_POST['GCLD_City']."', states='".$_POST['GCLD_State']."', zip='".$_POST['GCLD_Zip']."',dob='".$_POST['GCLD_DOB']."',relationship='".$_POST['GCLD_relationship']."', email='".$_POST['GCLD_Email']."', phone='".$_POST['GCLD_phone']."', phone2='".$_POST['GCLD_phone2']."' WHERE id='".$_POST['rowId']."'";                
                // $sql = "INSERT INTO final_arrange_grand_children (caseID, staffID, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['GCLD_FullName']."','".$_POST['GCLD_Address1']."','".$_POST['GCLD_Address2']."','".$_POST['GCLD_City']."','".$_POST['GCLD_State']."','".$_POST['GCLD_Zip']."','".$_POST['GCLD_DOB']."','".$_POST['GCLD_relationship']."','".$_POST['GCLD_Email']."','".$_POST['GCLD_phone']."','".$_POST['GCLD_phone2']."')";
                break;
            case 'final_arrange_marital':
                $MS_SpouseDeceased = (isset($_POST['MS_SpouseDeceased']) ) ? 'Y': 'N';
                $sql = "UPDATE ".$reTable." SET maritalstatus='".$_POST['MS_MaritalStatus']."', placeofmarriage='".$_POST['MS_PlaceOfMarriage']."', dateofmarriage='".$_POST['MS_DateOfMarriage']."', spousesname='".$_POST['MS_SpousesName']."', Spousedeceased='".$MS_SpouseDeceased."', dateofdeath='".$_POST['MS_SDateOfDeath']."',spousesplaceofdeath='".$_POST['MS_SpousesPlaceOfDeath']."' WHERE id='".$_POST['rowId']."'";                
                // $sql = "INSERT INTO final_arrange_marital (caseID, staffID, maritalstatus, placeofmarriage, dateofmarriage, spousesname, Spousedeceased, dateofdeath, spousesplaceofdeath) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['MS_MaritalStatus']."','".$_POST['MS_PlaceOfMarriage']."','".$_POST['MS_DateOfMarriage']."','".$_POST['MS_SpousesName']."','".$_POST['MS_SpouseDeceased']."','".$_POST['MS_SDateOfDeath']."','".$_POST['MS_SpousesPlaceOfDeath']."')";
                break;
            case 'final_arrange_military_service':  //?????
                $flag = (isset($_POST['MSH_Flag']) ) ? 'Y': 'N';
                $honorguard = (isset($_POST['MSH_HonorGuard']) ) ?'Y': 'N';
                $dd = (isset($_POST['MSH_DD214']) ) ? 'Y': 'N';
                $gravemarker = (isset($_POST['MSH_Gravemarker']) ) ? 'Y': 'N';
                if ($flag=='Y') {
                    $draped = (isset($_POST['MSH_Draped']) ) ? 'Y': 'N';
                    $folded = (isset($_POST['MSH_Folded']) ) ? 'Y': 'N';
                }else{
                    $draped = 'N';
                    $folded = 'N';
                }

                $sql = "UPDATE ".$reTable." SET honor1='".$_POST['MSH_honors']."', WarCampaignID='".$_POST['MSH_warcampaign']."', contacted='".$_POST['MSH_Contacted']."', fullname='".$_POST['MSH_FullName']."', rank='".$_POST['MSH_rank']."', honor2='".$_POST['MSH_Awards']."', dob='".$_POST['MSH_DateOfBirth']."', dod='".$_POST['MSH_DateOfDeath']."', inscription='".$_POST['MSH_Inscription']."', flag='".$flag."', cologuard='".$honorguard."', caission='".$dd."', gravemarker='".$gravemarker."', draped='".$draped."', folded='".$folded."' WHERE id='".$_POST['rowId']."'";                
                // $sql = "INSERT INTO final_arrange_military_service (caseID, staffID, honor1, WarCampaignID, contacted, fullname, rank, honor2, dob, dod, inscription, flag, cologuard, caission, gravemarker, draped, folded) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['MSH_honors']."','".$_POST['MSH_warcampaign']."','".$_POST['MSH_Contacted']."','".$_POST['MSH_FullName']."','".$_POST['MSH_rank']."','".$_POST['MSH_Awards']."','".$_POST['MSH_DateOfBirth']."','".$_POST['MSH_DateOfDeath']."','".$_POST['MSH_Inscription']."','".$flag."','".$honorguard."','".$dd."','".$gravemarker."','".$draped."','".$folded."')";
                break;
            case 'final_arrange_parents':
                $sql = "UPDATE ".$reTable." SET ParentDeceasedFathersDOB='".$_POST['PAT_ParentDeceasedFathersDOB']."', ParentsDeceasedFathersDOD='".$_POST['PAT_ParentsDeceasedFathersDOD']."', ParentsDeceasedMothersDOB='".$_POST['PAT_ParentsDeceasedMothersDOB']."', ParentsDeceasedMothersDOD='".$_POST['PAT_ParentsDeceasedMothersDOD']."' WHERE id='".$_POST['rowId']."'";                
                // $sql = "INSERT INTO final_arrange_parents (caseID, staffID, ParentDeceasedFathersDOB, ParentsDeceasedFathersDOD, ParentsDeceasedMothersDOB, ParentsDeceasedMothersDOD) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['PAT_ParentDeceasedFathersDOB']."','".$_POST['PAT_ParentsDeceasedFathersDOD']."','".$_POST['PAT_ParentsDeceasedMothersDOB']."','".$_POST['PAT_ParentsDeceasedMothersDOD']."')";
                break;
            case 'final_arrange_place_of_worship':
                $sql = "UPDATE ".$reTable." SET PlaceOfWorship='".$_POST['POW_PlaceOfWorship']."', ClergyName='".$_POST['POW_ClergyName']."',Address1='".$_POST['POW_Address1']."', Address2='".$_POST['POW_Address2']."', city='".$_POST['POW_City']."', states='".$_POST['POW_State']."', zip='".$_POST['POW_Zip']."', email='".$_POST['POW_Email']."', phone='".$_POST['POW_phone']."', phone2='".$_POST['POW_phone2']."' WHERE id='".$_POST['rowId']."'";                
                // $sql = "INSERT INTO final_arrange_place_of_worship (caseID, staffID, PlaceOfWorship, ClergyName, Address1, Address2, city, states, zip, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['POW_PlaceOfWorship']."','".$_POST['POW_ClergyName']."','".$_POST['POW_Address1']."','".$_POST['POW_Address2']."','".$_POST['POW_City']."','".$_POST['POW_State']."','".$_POST['POW_Zip']."','".$_POST['POW_Email']."','".$_POST['POW_phone']."','".$_POST['POW_phone2']."')";
                break;
            case 'pre_need_nok':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['NOK_fullname']."', address1='".$_POST['NOK_address1']."', address2='".$_POST['NOK_address2']."', city='".$_POST['NOK_city']."', states='".$_POST['NOK_state']."', zip='".$_POST['NOK_zip']."',relationship='".$_POST['NOK_relationship']."',  phone='".$_POST['NOK_phone']."', phone2='".$_POST['NOK_phone2']."', email='".$_POST['NOK_email']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO pre_need_nok (caseID, staffID, fullname, address1, address2, city, states, zip,relationship, phone, phone2, email) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['NOK_fullname']."','".$_POST['NOK_address1']."','".$_POST['NOK_address2']."','".$_POST['NOK_city']."','".$_POST['NOK_state']."','".$_POST['NOK_zip']."','".$_POST['NOK_relationship']."','".$_POST['NOK_phone']."','".$_POST['NOK_phone2']."','".$_POST['NOK_email']."')";
                break;
            case 'first_call_pi':
                // $sql = "UPDATE ".$reTable." SET honorific='".$_POST['PI_honorificID']."', firstName='".$_POST['PI_firstname']."', middleName='".$_POST['PI_middlename']."', lastName='".$_POST['PI_lastname']."', suffix='".$_POST['PI_suffix']."', address1='".$_POST['PI_address1']."', address2='".$_POST['PI_address2']."', township='".$_POST['PI_township']."', city='".$_POST['PI_city']."', states='".$_POST['PI_state']."', zipCode='".$_POST['PI_zip']."', country='".$_POST['PI_county']."', nickName='".$_POST['PI_nickname']."', gender='".$_POST['PI_gender']."', SSN='".$_POST['PI_ssn']."', email='".$_POST['PI_email']."', phone='".$_POST['PI_phone']."' WHERE id='".$_POST['rowId']."'"; 
                $sql = "UPDATE ".$reTable." SET honorific='".$_POST['PF_honorific']."', firstName='".$_POST['PF_firstname']."', middleName='".$_POST['PF_middlename']."', lastName='".$_POST['PF_lastName']."', suffix='".$_POST['PF_suffix']."', address1='".$_POST['PF_address1']."', address2='".$_POST['PF_address2']."', township='".$_POST['PF_township']."', city='".$_POST['PF_city']."', states='".$_POST['PF_state']."', zipCode='".$_POST['PF_zip']."', country='".$_POST['PF_county']."', nickName='".$_POST['PF_nickname']."', gender='".$_POST['PF_gender']."', SSN='".$_POST['PF_ssn']."', email='".$_POST['PF_email']."', phone='".$_POST['PF_phone']."', dateOfDeath='".$_POST['PF_dod']."', timeOfDeath='".$_POST['PF_tode']."', dateOfBirth='".$_POST['PF_dob']."' WHERE id='".$_POST['rowId']."'"; 
                
                // $sql = "INSERT INTO first_call_pi (caseID, staffID, honorific, firstName, middleName, lastName, suffix, address1, address2, township, city, states, zipCode, country, nickName, gender, SSN, email, phone, dateOfDeath, timeOfDeath) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['PF_honorific']."','".$_POST['PF_firstname']."','".$_POST['PF_middlename']."','".$_POST['PF_lastName']."','".$_POST['PF_suffix']."','".$_POST['PF_address1']."','".$_POST['PF_address2']."','".$_POST['PF_township']."','".$_POST['PF_city']."','".$_POST['PF_state']."','".$_POST['PF_zip']."','".$_POST['PF_county']."','".$_POST['PF_nickname']."','".$_POST['PF_gender']."','".$_POST['PF_ssn']."','".$_POST['PF_email']."','".$_POST['PF_phone']."','".$_POST['PF_dod']."','".$_POST['PF_tode']."')";
                break;
            case 'first_call_location':
                $sql = "UPDATE ".$reTable." SET location='".$_POST['LOC_Location']."', contact='".$_POST['LOC_Contact']."', Address1='".$_POST['LOC_Address1']."', Address2='".$_POST['LOC_Address2']."', City='".$_POST['LOC_city']."', States='".$_POST['LOC_state']."', Zip='".$_POST['LOC_zip']."',Email='".$_POST['LOC_Email']."',  phone='".$_POST['LOC_phone']."', dod='".$_POST['LOC_dod']."', tode='".$_POST['LOC_tode']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO first_call_location (caseID, staffID, location, contact, Address1, Address2, City, States, Zip, Email, phone, dod, tode) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['LOC_Location']."','".$_POST['LOC_Contact']."','".$_POST['LOC_Address1']."','".$_POST['LOC_Address2']."','".$_POST['LOC_city']."','".$_POST['LOC_state']."','".$_POST['LOC_zip']."','".$_POST['LOC_Email']."','".$_POST['LOC_phone']."','".$_POST['LOC_dod']."','".$_POST['LOC_tode']."')";
                break;      
            case 'first_call_physician':
                $sql = "UPDATE ".$reTable." SET Physician='".$_POST['PHY_Physician']."', ContactName='".$_POST['PHY_Contact']."', Address1='".$_POST['PHY_Address1']."', Address2='".$_POST['PHY_Address2']."', City='".$_POST['PHY_city']."', States='".$_POST['PHY_state']."', Zip='".$_POST['PHY_zip']."',Email='".$_POST['PHY_Email']."',  officephone='".$_POST['PHY_officephone']."', cellphone='".$_POST['PHY_cellphone']."', pager='".$_POST['PHY_pager']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO first_call_physician (caseID, staffID, Physician, ContactName, Address1, Address2, City, States, Zip, Email, officephone,cellphone, pager) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['PHY_Physician']."','".$_POST['PHY_Contact']."','".$_POST['PHY_Address1']."','".$_POST['PHY_Address2']."','".$_POST['PHY_city']."','".$_POST['PHY_state']."','".$_POST['PHY_zip']."','".$_POST['PHY_Email']."','".$_POST['PHY_officephone']."','".$_POST['PHY_cellphone']."','".$_POST['PHY_pager']."')";
                break;       
            case 'first_call_place_of_death':
                $sql = "UPDATE ".$reTable." SET Physician='".$_POST['POD_Physician']."', ContactName='".$_POST['POD_Contact']."', Address1='".$_POST['POD_Address1']."', Address2='".$_POST['POD_Address2']."', City='".$_POST['POD_city']."', States='".$_POST['POD_state']."', Zip='".$_POST['POD_zip']."',Email='".$_POST['POD_Email']."',  officephone='".$_POST['POD_officephone']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO first_call_place_of_death (caseID, staffID, Physician, ContactName, Address1, Address2, City, States, Zip, Email, officephone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['POD_Physician']."','".$_POST['POD_ContactName']."','".$_POST['POD_Address1']."','".$_POST['POD_Address2']."','".$_POST['POD_city']."','".$_POST['POD_state']."','".$_POST['POD_zip']."','".$_POST['POD_Email']."','".$_POST['POD_officephone']."')";
                break;       
            case 'first_call_person_call':
                $sql = "UPDATE ".$reTable." SET WhoCalled='".$_POST['PWC_FullName']."', Address1='".$_POST['PWC_Address1']."', Address2='".$_POST['PWC_Address2']."', City='".$_POST['PWC_City']."', States='".$_POST['PWC_State']."', Zip='".$_POST['PWC_Zip']."',Email='".$_POST['PWC_Email']."',  dayphone='".$_POST['PWC_dayphone']."', eveningphone='".$_POST['PWC_evephone']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO first_call_person_call (caseID, staffID, WhoCalled, Address1, Address2, City, States, Zip, Email, dayphone, eveningphone) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['PWC_FullName']."','".$_POST['PWC_Address1']."','".$_POST['PWC_Address2']."','".$_POST['PWC_City']."','".$_POST['PWC_State']."','".$_POST['PWC_Zip']."','".$_POST['PWC_Email']."','".$_POST['PWC_dayphone']."','".$_POST['PWC_evephone']."')";
                break;    

            case 'surviving_relative':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['SUREL_Name']."', address1='".$_POST['SUREL_Address1']."', city='".$_POST['SUREL_City']."', states='".$_POST['SUREL_State']."', zip='".$_POST['SUREL_Zip']."', phone='".$_POST['SUREL_phone']."', email='".$_POST['SUREL_Email']."', relationship='".$_POST['SUREL_relationship']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO final_arrange_survivingrelative (caseID, staffID, fullname, address1, city, states, zip, phone, email, relationship) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['SUREL_Name']."','".$_POST['SUREL_Address1']."','".$_POST['SUREL_City']."','".$_POST['SUREL_State']."','".$_POST['SUREL_Zip']."','".$_POST['SUREL_phone']."','".$_POST['SUREL_Email']."','".$_POST['SUREL_relationship']."')";
                break;
            //case_bio 
            case 'case_bio_children':
                $sql = "UPDATE ".$reTable." SET fullname='".$_POST['CLD_FullName']."', address1='".$_POST['CLD_Address1']."', address2='".$_POST['CLD_Address2']."', city='".$_POST['CLD_City']."', states='".$_POST['CLD_State']."', zip='".$_POST['CLD_Zip']."',dob='".$_POST['CLD_DOB']."',relationship='".$_POST['CLD_relationship']."', email='".$_POST['CLD_Email']."', phone='".$_POST['CLD_phone']."', phone2='".$_POST['CLD_phone2']."' WHERE id='".$_POST['rowId']."'";           
                // $sql = "INSERT INTO case_bio_children (caseID, staffID, fullname, address1, address2, city, states, zip, dob, relationship, email, phone, phone2) VALUES ('".$selcaseID."','".$_SESSION['userid']."','".$_POST['CLD_FullName']."','".$_POST['CLD_Address1']."','".$_POST['CLD_Address2']."','".$_POST['CLD_City']."','".$_POST['CLD_State']."','".$_POST['CLD_Zip']."','".$_POST['CLD_DOB']."','".$_POST['CLD_relationship']."','".$_POST['CLD_Email']."','".$_POST['CLD_phone']."','".$_POST['CLD_phone2']."')";
                break;
                                                                            
            default:
                
                break;
        }
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'updated');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_convert'){       // for personal information; convert from Pre-Need to either At-Need or First Call
        if (isset($_POST['PI_radio_to'])) {
            # code...
            $sql = "DELETE FROM ".$reTable." WHERE caseID='".$_POST['caseID']."'"; // delete origin status
        
            if ($conn->query($sql) === TRUE) { //insert new status after deleting former status
                $sql = "INSERT INTO ".$_POST['PI_radio_to']." (caseID, staffID, honorific, firstName, middleName, lastName, suffix, address1, address2, township, city, states, zipCode, country, nickName, gender, SSN, email, phone, dateOfDeath, timeOfDeath, dateOfBirth) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['PI_honorificID']."','".$_POST['PI_firstname']."','".$_POST['PI_middlename']."','".$_POST['PI_lastname']."','".$_POST['PI_suffix']."','".$_POST['PI_address1']."','".$_POST['PI_address2']."','".$_POST['PI_township']."','".$_POST['PI_city']."','".$_POST['PI_state']."','".$_POST['PI_zip']."','".$_POST['PI_county']."','".$_POST['PI_nickname']."','".$_POST['PI_gender']."','".$_POST['PI_ssn']."','".$_POST['PI_email']."','".$_POST['PI_phone']."','".$_POST['PI_dod']."','".$_POST['PI_tode']."','".$_POST['PI_dob']."')";
                if ($conn->query($sql) === TRUE) { // update cases tables's status where caseID = Post_caseID
                    $new_status = ($_POST['PI_radio_to'] == 'at_need_pi') ? 'At-Need' : 'First-Call';
                    $sql = "UPDATE cases SET status='".$new_status."' WHERE id='".$_POST['caseID']."'"; 
                } else { 
                    $response = array('status' => 'error');
                    echo json_encode($response); return;
                }
            } else {
                $response = array('status' => 'error');
                echo json_encode($response); return;
            }
        }else if (isset($_POST['PF_radio_to'])) {
            # code...
            $sql = "DELETE FROM ".$reTable." WHERE caseID='".$_POST['caseID']."'"; // delete origin status
            
            if ($conn->query($sql) === TRUE) { //insert new status
                $sql = "INSERT INTO ".$_POST['PF_radio_to']." (caseID, staffID, firstName, lastName, dateOfBirth, dateOfDeath) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['PF_firstname']."','".$_POST['PF_lastName']."','".$_POST['PF_dob']."','".$_POST['PF_dod']."')";
                if ($conn->query($sql) === TRUE) { // update cases tables's status where caseID = Post_caseID
                    $new_status = ($_POST['PF_radio_to'] == 'case_bio_deceased_info') ? 'Case-Bio' : 'Final-Arrangements';
                    $sql = "UPDATE cases SET status='".$new_status."' WHERE id='".$_POST['caseID']."'"; 
                } else { 
                    $response = array('status' => 'error');
                    echo json_encode($response); return;
                }
            } else {
                $response = array('status' => 'error');
                echo json_encode($response); return;
            }
        }else if(isset($_POST['NOK_radio_to'])) { // for next-of-kin; convert from Pre-Need to either At-Need or Surviving-Relative
            switch ($_POST['NOK_radio_to']) {
                case 'at_need_nok':
                    # code...
                    $sql = "INSERT INTO ".$_POST['NOK_radio_to']." (caseID, staffID, fullname, address1, address2, city, states, zip, relationship, phone, phone2, email) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['NOK_fullname']."','".$_POST['NOK_address1']."','".$_POST['NOK_address2']."','".$_POST['NOK_city']."','".$_POST['NOK_state']."','".$_POST['NOK_zip']."','".$_POST['NOK_relationship']."','".$_POST['NOK_phone']."','".$_POST['NOK_phone2']."','".$_POST['NOK_email']."')";
                    break;
                case 'surviving_relative':
                    # code...
                    $sql = "INSERT INTO ".$_POST['NOK_radio_to']." (caseID, staffID, fullname, address1, city, states, zip, phone, email, relationship) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['NOK_fullname']."','".$_POST['NOK_address1']."','".$_POST['NOK_city']."','".$_POST['NOK_state']."','".$_POST['NOK_zip']."','".$_POST['NOK_phone']."','".$_POST['NOK_email']."','".$_POST['NOK_relationship']."')";  
                    break;
                default:
                    # code...
                    break;
            }
        }else if(isset($_POST['MS_radio_to'])) { // for MARITAL STATUS; convert from Pre-Need to either CASE-BIO or Final arrangement
            $MS_SpouseDeceased = (isset($_POST['MS_SpouseDeceased']) ) ? 'Y': 'N';
            $sql = "INSERT INTO ".$_POST['MS_radio_to']." (caseID, staffID, maritalstatus, placeofmarriage, dateofmarriage, spousesname, Spousedeceased, dateofdeath, spousesplaceofdeath) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['MS_MaritalStatus']."','".$_POST['MS_PlaceOfMarriage']."','".$_POST['MS_DateOfMarriage']."','".$_POST['MS_SpousesName']."','".$MS_SpouseDeceased."','".$_POST['MS_SDateOfDeath']."','".$_POST['MS_SpousesPlaceOfDeath']."')";
        }else if(isset($_POST['MLT_radio_to'])) { // for Military service; convert from Pre-Need to only CASE-BIO 
            $MLT_DD214 = (isset($_POST['MLT_DD214']) ) ? 'Y': 'N';
            $MLT_Headstone = (isset($_POST['MLT_Headstone']) ) ?'Y': 'N';
            $MLT_ApplicationForBurial = (isset($_POST['MLT_ApplicationForBurial']) ) ? 'Y': 'N';
            $MLT_ApplicationForFlag = (isset($_POST['MLT_ApplicationForFlag']) ) ?'Y': 'N';
            $MLT_HonorGuard = (isset($_POST['MLT_HonorGuard']) ) ? 'Y': 'N';

            $sql = "INSERT INTO ".$_POST['MLT_radio_to']." (caseID, staffID, BranchID, WarCampaignID, SerialNumber, Rank, EnlistmentDate, DischargeDate, TypeOfDischargeID, DD214, Headstone, ApplicationForBurial, ApplicationForFlag, HonorGuard) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['MLT_BranchID']."','".$_POST['MLT_warcampaign']."','".$_POST['MLT_SerialNumber']."','".$_POST['MLT_rank']."','".$_POST['MLT_EnlistmentDate']."','".$_POST['MLT_DischargeDate']."','".$_POST['MLT_typeofdischarge']."','".$MLT_DD214."','".$MLT_Headstone."','".$MLT_ApplicationForBurial."','".$MLT_ApplicationForFlag."','".$MLT_HonorGuard."')";
        }else if(isset($_POST['CHU_radio_to'])) { // for church; convert from Pre-Need to either CASE-BIO or Final arrangement
            $sql = "INSERT INTO ".$_POST['CHU_radio_to']." (caseID, staffID, Church, ClergyName, Address1, Address2, city, states, zip, Email, phone, phone2) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['CHU_Church']."','".$_POST['CHU_ClergyName']."','".$_POST['CHU_Address1']."','".$_POST['CHU_Address2']."','".$_POST['CHU_City']."','".$_POST['CHU_State']."','".$_POST['CHU_Zip']."','".$_POST['CHU_Email']."','".$_POST['CHU_phone']."','".$_POST['CHU_phone2']."')";
        }else if(isset($_POST['POW_radio_to'])) { // for place of worship; convert from Pre-Need to either CASE-BIO or Final arrangement
            $sql = "INSERT INTO ".$_POST['POW_radio_to']." (caseID, staffID, PlaceOfWorship, ClergyName, Address1, Address2, City, States, Zip, Email, phone, phone2) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['POW_PlaceOfWorship']."','".$_POST['POW_ClergyName']."','".$_POST['POW_Address1']."','".$_POST['POW_Address2']."','".$_POST['POW_City']."','".$_POST['POW_State']."','".$_POST['POW_Zip']."','".$_POST['POW_Email']."','".$_POST['POW_phone']."','".$_POST['POW_phone2']."')";
        }else if(isset($_POST['EDU_radio_to'])) { // for education; convert from Pre-Need to either CASE-BIO or Final arrangement
            $EDU_EduHSGraduated = (isset($_POST['EDU_EduHSGraduated']) ) ? 'Y': 'N';
            $EDU_undergraducatedegreecheck = (isset($_POST['EDU_undergraducatedegreecheck']) ) ?'Y': 'N';
            $EDU_graducatedegreecheck = (isset($_POST['EDU_graducatedegreecheck']) ) ? 'Y': 'N';
            $sql = "INSERT INTO ".$_POST['EDU_radio_to']." (caseID, staffID, EduHighSchool, EduHSGraduated, undergraducate, undergraducatedegree, undergraducatedegreecheck, graduate, graducatedegree, graducatedegreecheck) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['EDU_highschool']."','".$EDU_EduHSGraduated."','".$_POST['EDU_undergraduatename']."','".$_POST['EDU_undergraducatedegree']."','".$EDU_undergraducatedegreecheck."','".$_POST['EDU_graduatename']."','".$_POST['EDU_graducatedegree']."','".$EDU_graducatedegreecheck."')";
        }else if(isset($_POST['PAT_radio_to'])) { // for parents deceased; convert from Pre-Need to either CASE-BIO or Final arrangement
            $sql = "INSERT INTO ".$_POST['PAT_radio_to']." (caseID, staffID, ParentDeceasedFathersDOB, ParentsDeceasedFathersDOD, ParentsDeceasedMothersDOB, ParentsDeceasedMothersDOD) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['PAT_ParentDeceasedFathersDOB']."','".$_POST['PAT_ParentsDeceasedFathersDOD']."','".$_POST['PAT_ParentsDeceasedMothersDOB']."','".$_POST['PAT_ParentsDeceasedMothersDOD']."')";
        }else if(isset($_POST['FDP_radio_to'])) { // for final disposition; convert from Pre-Need to either CASE-BIO or Final arrangement
            $FDP_Burial = (isset($_POST['FDP_Burial']) ) ? 'Y': 'N';
            $FDP_Entombment = (isset($_POST['FDP_Entombment']) ) ?'Y': 'N';
            $FDP_Cremation = (isset($_POST['FDP_Cremation']) ) ? 'Y': 'N';
            $FDP_BurialAtSea = (isset($_POST['FDP_BurialAtSea']) ) ? 'Y': 'N';
            
            $sql = "INSERT INTO ".$_POST['FDP_radio_to']." (caseID, staffID, Burial, Entombment, Cremation, BurialAtSea, DateOfFinalDisposition, FinalDisposition, CemeteryID, Location, Section, FuneralOrMemorialServiceAtID, NameLotRegisteredTo, WhereInLotIsGraveToBeOpened, LotNo, GraveNo) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$FDP_Burial."','".$FDP_Entombment."','".$FDP_Cremation."','".$FDP_BurialAtSea."','".$_POST['FDP_DateOfFinalDisposition']."','".$_POST['FDP_FinalDisposition']."','".$_POST['FDP_cemetery']."','".$_POST['FDP_Location']."','".$_POST['FDP_Section']."','".$_POST['FDP_FuneralOrMemorialServiceAtID']."','".$_POST['FDP_NameLotRegisteredTo']."','".$_POST['FDP_WhereInLotIsGraveToBeOpened']."','".$_POST['FDP_LotNo']."','".$_POST['FDP_GraveNo']."')";
        }
        
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'converted');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_convert_firstcall'){  // convert from At-Need to First Call
        $sql = "DELETE FROM ".$reTable." WHERE caseID='".$_POST['caseID']."'";     // first of all, delete origin status
        if ($conn->query($sql) === TRUE) { //and then, insert new status
            $sql = "INSERT INTO first_call_pi (caseID, staffID, honorific, firstName, middleName, lastName, suffix, address1, address2, township, city, states, zipCode, country, nickName, gender, SSN, email, phone, dateOfDeath, timeOfDeath, dateOfBirth) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['PF_honorific']."','".$_POST['PF_firstname']."','".$_POST['PF_middlename']."','".$_POST['PF_lastName']."','".$_POST['PF_suffix']."','".$_POST['PF_address1']."','".$_POST['PF_address2']."','".$_POST['PF_township']."','".$_POST['PF_city']."','".$_POST['PF_state']."','".$_POST['PF_zip']."','".$_POST['PF_county']."','".$_POST['PF_nickname']."','".$_POST['PF_gender']."','".$_POST['PF_ssn']."','".$_POST['PF_email']."','".$_POST['PF_phone']."','".$_POST['PF_dod']."','".$_POST['PF_tode']."','".$_POST['PF_dob']."')";
            if ($conn->query($sql) === TRUE) { // finally, update cases tables's status where caseID = Post_caseID
                $sql = "UPDATE cases SET status='First-Call' WHERE id='".$_POST['caseID']."'"; 
                if ($conn->query($sql) === TRUE) {
                    $response = array('status' => 'converted');
                    echo json_encode($response); return;
                } else {
                    $response = array('status' => 'error');
                    echo json_encode($response); return;
                }
            } else { 
                $response = array('status' => 'error');
                echo json_encode($response); return;
            }
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_convert_surv'){       // convert from At-Need to Surviving Relative
        $sql = "INSERT INTO surviving_relative (caseID, staffID, fullname, address1, city, states, zip, phone, email, relationship) VALUES ('".$_POST['caseID']."','".$_SESSION['userid']."','".$_POST['NOK_fullname']."','".$_POST['NOK_address1']."','".$_POST['NOK_city']."','".$_POST['NOK_state']."','".$_POST['NOK_zip']."','".$_POST['NOK_phone']."','".$_POST['NOK_email']."','".$_POST['NOK_relationship']."')";  

        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'converted');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }  
    else { //delete recent one
        $sql = "DELETE FROM ".$reTable." WHERE id='".$_POST['rowId']."'"; 
        
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'deleted');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }
}
else{ // session expired
    $response = array('status' => 'sessionExpired');
    echo json_encode($response); return;
}
?>