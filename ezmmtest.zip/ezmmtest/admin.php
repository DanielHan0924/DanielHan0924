<?php
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';

        $flag_setting = true;
        $flag_useradmin = true;

        $sql = "SELECT * FROM users WHERE id='".$_SESSION['userid']."';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $user_info = mysqli_fetch_assoc($result);
        }

        switch ($_SESSION['userrole']) {
            case 'adminstaff':
                $sql = "SELECT * FROM users WHERE role ='staff';";
                break;
            case 'superadmin':
                $sql = "SELECT * FROM users WHERE role ='staff' OR role ='adminstaff';";
                break;
            default:
                break;
        }
        $usersResult = $conn->query($sql);
        $usersResultCount = mysqli_num_rows($usersResult);
    }else {
        header('Location: login.php');
    }
?>
<style>
    body
    {
    background-color:#f5f5f5;
    }
    .imagePreview {
        width: 100%;
        height: 180px;
        background-position: center center;
    background:url(http://cliquecities.com/assets/no-image-e3699ae23f866f6cbdf8ba2443ee5c4e.jpg);
    background-color:#fff;
        background-size: cover;
    background-repeat:no-repeat;
        display: inline-block;
    box-shadow:0px -3px 6px 2px rgba(0,0,0,0.2);
    }
    .btn-primary
    {
    display:block;
    border-radius:0px;
    box-shadow:0px 4px 6px 2px rgba(0,0,0,0.2);
    margin-top:-5px;
    }
    .imgUp
    {
    margin-bottom:15px;
    }
    .del
    {
    position:absolute;
    top:0px;
    right:15px;
    width:30px;
    height:30px;
    text-align:center;
    line-height:30px;
    background-color:rgba(255,255,255,0.6);
    cursor:pointer;
    }
    .imgAdd
    {
    width:30px;
    height:30px;
    border-radius:50%;
    background-color:#4bd7ef;
    color:#fff;
    box-shadow:0px 0px 2px 1px rgba(0,0,0,0.2);
    text-align:center;
    line-height:30px;
    margin-top:0px;
    cursor:pointer;
    font-size:15px;
    }
    /* Add a hover effect (blue shadow) */
    img:hover {
    box-shadow: 0 0 2px 1px rgba(0, 140, 186, 0.5);
    }
</style>
<div class="page-title-heading">
    <div><h3>PRE NEED STATUS</h3></div>    
    </div>
    </div>
</div>   
<div class="row">
    <div class="col-md-12">
        <div class="accordion-wrapper mb-3 custom-accordian" id="accordionExample">
            <div class="card">
                <div class="b-radius-0 card-header">
                    <button type="button" data-toggle="collapse" data-target="#collapseOne21" aria-expanded="false" aria-controls="collapseNine" class="text-left m-0 p-0 btn btn-link btn-block">
                        <h5 class="m-0 p-0">FUNERAL HOME / CREMATORY</h5>
                    </button>
                </div>
                <div data-parent="#accordionExample" id="collapseOne21" class="collapse show">
                    <div class="card-body">
                        <?php include('inc/funeral_home_crematory_registration.php'); ?>
                    </div>
                </div>
            </div>
            <?php if(isset($_SESSION['userrole']) && ($_SESSION['userrole'] == 'adminstaff' || $_SESSION['userrole'] == 'superadmin')) { ?>

            <div class="card">
                <div class="card-header" id="headingThree">   
                    <button type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                        <h5 class="m-0 p-0">STAFF</h5>
                    </button>
                </div>
                <div id="collapseThree" class="collapse show" aria-labelledby="headingThree" data-parent="#accordionExample">
                    <div class="card-body">
                        <?php if ($usersResultCount > 0) { ?>
                        <select name="STFF_select" id="STFF_select" class="form-control" required>
                            <option hidden>Select any User to control his/her permission etc:</option>
                            <?php 
                            while($dropdown_city_cld = mysqli_fetch_assoc($usersResult)) {                 
                                ?>
                                <option value="<?php echo ($dropdown_city_cld['id']); ?>" ><?php echo ($dropdown_city_cld['username']); ?></option>
                            <?php }?>
                        </select>
                        <br>
                        <br>
                        <?php } else{echo ('no option to be selected');}?>
                        <?php include('inc/adminstaff.php'); ?>              
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
</div>
<?php include('inc/footer.php'); ?>                      