<?php 
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';
        //get superadmin's ID
        $sql = "SELECT * FROM users WHERE role='superadmin';";
        $result = mysqli_fetch_array($conn->query($sql));
        $superadminID = $result['id'];

        switch ($_SESSION['userrole']) {
            case 'superadmin':
                $sql = "SELECT * FROM todolist WHERE caseID = '".$_SESSION['selectedcaseID']."' ORDER BY id DESC;";
                break;
            case 'adminstaff':
                $sql = "SELECT * FROM todolist WHERE caseID = '".$_SESSION['selectedcaseID']."' AND staffID != '".$superadminID."' ORDER BY id DESC;";
                break;
            case 'staff':
                $sql = "SELECT * FROM todolist WHERE caseID = '".$_SESSION['selectedcaseID']."' AND staffID = '".$_SESSION['userid']."' ORDER BY id DESC;";
                break;
            
            default:
                break;
        }
        $todoResult = $conn->query($sql);
        $todoResultCount = mysqli_num_rows($todoResult);

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
<style>
    .custom-col{
        padding-right:0px!important; padding-left:0px!important;
    }
    .casket-form-input {
        outline: 0;
        border-width: 0 0 2px;
        border-color: blue
    }
    .casket-form-input:focus {
        border-color: green
    }
    .hidden-form-wrapper{
        padding-left:30px;
        padding-right:30px;
    }
    .imagePreview {
        width: 100%;
        height: 180px;
        background-position: center center;
    background:url(http://cliquecities.com/assets/no-image-e3699ae23f866f6cbdf8ba2443ee5c4e.jpg);
    background-color:#fff;
        background-size: cover;
    background-repeat:no-repeat;
        display: inline-block;
    box-shadow:0px -3px 6px 2px rgba(0,0,0,0.2);
    }
    .btn-primary
    {
    display:block;
    border-radius:0px;
    box-shadow:0px 4px 6px 2px rgba(0,0,0,0.2);
    margin-top:-5px;
    }
    .imgUp
    {
    margin-bottom:15px;
    }
    .del
    {
    position:absolute;
    top:0px;
    right:15px;
    width:30px;
    height:30px;
    text-align:center;
    line-height:30px;
    background-color:rgba(255,255,255,0.6);
    cursor:pointer;
    }
    .imgAdd
    {
    width:30px;
    height:30px;
    border-radius:50%;
    background-color:#4bd7ef;
    color:#fff;
    box-shadow:0px 0px 2px 1px rgba(0,0,0,0.2);
    text-align:center;
    line-height:30px;
    margin-top:0px;
    cursor:pointer;
    font-size:15px;
    }
    /* Add a hover effect (blue shadow) */
    img:hover {
    box-shadow: 0 0 2px 1px rgba(0, 140, 186, 0.5);
    }
    .modal-backdrop.show {
        opacity: 0;
    }
    .modal-backdrop {
        z-index: unset;
    }
    .modal.show {
        background: #000000a3;
    }
    .modal-content {
        margin-top: 40%;
    }
    .modal .modal-body img {
        max-width: -webkit-fill-available;
        width: 100%;
    }
    .modal-dialog{
        max-width: 700px;
    }
</style>
<div class="page-title-heading">
    <div>
        <h3 style="background: #16aaff;">ToDo list </h3>
    </div>
</div>
</div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="main-card mb-3 card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <button class=" btn-block btn btn-info" data-toggle="modal" data-target="#modal_addtask"><i class="fa fa-plus" style="color: white;"></i>Add a new task...</button> 
                    </div>   
                </div>
            </div>
            <div id="accordion_todo" class="accordion-wrapper mb-3 custom-accordian">
                <div class="table-responsive">
                <?php if ($todoResultCount > 0) { ?>
                    <table class="align-middle mb-0 table table-borderless table-striped table-hover">
                        <thead>
                        <tr>
                            <th class="text-center">Description</th>
                            <th class="text-center">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php while($todo_row = mysqli_fetch_assoc($todoResult)) { ?>
                        <form class="form_todolist" action="saveNewtask.php" method="POST">
                        <tr>
                        <?php
                            $id = (isset($todo_row['id']) ) ? trim($todo_row['id']) :1;
                            $decription = (isset($todo_row['description']) ) ? trim($todo_row['description']) : '';
                            $cdate = (isset($todo_row['cDate']) ) ? trim($todo_row['cDate']) : '';
                            $rdate = (isset($todo_row['rDate']) ) ? trim($todo_row['rDate']) : '';
                            $isperm = (isset($todo_row['isPerm']) ) ? trim($todo_row['isPerm']) : '';
                            $iscompleted = (isset($todo_row['completed']) ) ? trim($todo_row['completed']) : '';
                        ?>
                        <input type="hidden" name="TODO_table" id="" value="todolist">
                        <input type="hidden" name="TODO_id" id="TODO_id" value="<?php echo $id; ?>">

                            <td class="text-center text-muted"><?php echo $decription; ?></td>
                            <td class="text-center">
                                <button type="submit" data-placement="bottom" class="btn-shadow mr-1 btn btn-info btn-sm btn-completetask" value="sbm_completetask_<?php echo $iscompleted; ?>" >
                                    <i class="fa fa-<?php if ($iscompleted == "Y") { echo 'check'; }else{echo 'circle';} ?> fa-1x"></i>
                                </button>
                                <button type="button" data-placement="bottom" class="btn-shadow mr-1 btn btn-success btn-sm" data-toggle="modal" data-target="#modal_edittask<?php echo $id; ?>">
                                    <i class="fa fa-pencil fa-1x"></i>
                                </button>
                                <button type="submit" data-placement="bottom" class="btn-shadow mr-1 btn btn-danger btn-sm" value="sbm_deltask">
                                    <i class="fa fa-trash fa-1x"></i>
                                </button>
                            </td>
                        </tr>
                        </form>

                        <!-- modal_edittask -->
                        <div class="modal fade modal_todolist" id="modal_edittask<?php echo $id; ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Edit selected task here.</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                <form class="form_todolist" action="saveNewtask.php" method="POST">
                                    <div class="modal-body">
                                    <input type="hidden" name="TODO_table" id="" value="todolist">
                                    <input type="hidden" name="TODO_id" id="TODO_id" value="<?php echo $id; ?>">
                                    
                                    <div class="form-group row">
                                        <div class="col-md-2 d-flex"><label class="control-label justify-content-center align-self-center">Description of Task: </label></div>
                                        <div class="col-md-10"><input type="text" class="form-control" name="TODO_description" value="<?php echo $decription; ?>" required/></div> 
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-2 d-flex"><label class="control-label justify-content-center align-self-center">Created Date: </label></div>
                                        <div class="col-md-4"><input type="date" name="TODO_cdate" id="TODO_cdate" class="form-control" value="<?php echo $cdate; ?>"></div> 
                                        <div class="col-md-2 d-flex"><label class="control-label justify-content-center align-self-center">Required Date: </label></div>
                                        <div class="col-md-4"><input type="date" name="TODO_rdate" id="TODO_rdate" class="form-control" value="<?php echo $rdate; ?>"></div> 
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-2 d-flex"><label class="control-label justify-content-center align-self-center">IsPerm: </label></div>
                                        <div class="col-md-1"><input type="checkbox" name="TODO_isperm" id="TODO_isperm" class="form-control" <?php if ($isperm == 'Y') { echo 'checked';} ?>></div> 
                                        <div class="col-md-2 d-flex"><label class="control-label justify-content-center align-self-center">Completed: </label></div>
                                        <div class="col-md-1"><input type="checkbox" name="TODO_completed" id="TODO_completed" class="form-control" <?php if ($iscompleted == 'Y') { echo 'checked';} ?>></div> 
                                    </div>
                                    
                                    </div>
                                    <div class="modal-footer">
                                    <div class="col-md-8 d-flex"></div>
                                    <div class="col-md-2"><button type="submit" class="btn btn-info" value="sbm_edittask" >Update</button></div> 
                                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                                    </div>
                                </form>
                                </div>
                            </div>
                        </div> 
                        <?php }?>
                        </tbody>
                    </table>
                    <?php } else{echo ('no ToDolist to show');}?>
                    <!-- modal_addtask -->
                    <div class="modal fade modal_todolist" id="modal_addtask">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Input new task here.</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                            <form class="form_todolist" action="saveNewtask.php" method="POST">
                                <div class="modal-body">
                                <input type="hidden" name="TODO_table" id="" value="todolist">
                                
                                <div class="form-group row">
                                    <div class="col-md-2 d-flex"><label class="control-label justify-content-center align-self-center">Description of Task: </label></div>
                                    <div class="col-md-10"><input type="text" class="form-control" name="TODO_description"  required/></div> 
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-2 d-flex"><label class="control-label justify-content-center align-self-center">Created Date: </label></div>
                                    <div class="col-md-4"><input type="date" name="TODO_cdate" id="TODO_cdate" class="form-control"></div> 
                                    <div class="col-md-2 d-flex"><label class="control-label justify-content-center align-self-center">Required Date: </label></div>
                                    <div class="col-md-4"><input type="date" name="TODO_rdate" id="TODO_rdate" class="form-control"></div> 
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-2 d-flex"><label class="control-label justify-content-center align-self-center">IsPerm: </label></div>
                                    <div class="col-md-1"><input type="checkbox" name="TODO_isperm" id="TODO_isperm" class="form-control"></div> 
                                    <div class="col-md-2 d-flex"><label class="control-label justify-content-center align-self-center">Completed: </label></div>
                                    <div class="col-md-1"><input type="checkbox" name="TODO_completed" id="TODO_completed" class="form-control"></div> 
                                </div>
                                
                                </div>
                                <div class="modal-footer">
                                <div class="col-md-8 d-flex"></div>
                                <div class="col-md-2"><button type="submit" class="btn btn-info" value="sbm_addtask">Add</button></div> 
                                <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </div>
    
</div>                                   
</div>                                   
<?php include('inc/footer.php'); ?>
<script>
  
</script>
