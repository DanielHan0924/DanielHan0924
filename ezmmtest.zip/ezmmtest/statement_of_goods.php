<?php 
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';

        $flag_addBtn = true;// for informant recurring sub-section

        $sql = "SELECT * FROM statement_informants WHERE staffID='".$_SESSION['userid']."';";
        $infoResult = $conn->query($sql);
        $infoCount = mysqli_num_rows($infoResult);

        $sql = "SELECT * FROM statement_professional WHERE staffID='".$_SESSION['userid']."' OR staffID='0';";
        $professionalResult = $conn->query($sql);
        $professionalCount = mysqli_num_rows($professionalResult);

        $sql = "SELECT * FROM statement_facilities WHERE staffID='".$_SESSION['userid']."' OR staffID='0';";
        $facilitiesResult = $conn->query($sql);
        $facilitiesCount = mysqli_num_rows($facilitiesResult);

        $sql = "SELECT * FROM statement_automotive WHERE staffID='".$_SESSION['userid']."' OR staffID='0';";
        $automotiveResult = $conn->query($sql);
        $automotiveCount = mysqli_num_rows($automotiveResult);
        
        $sql = "SELECT * FROM statement_chargesofmerchandise WHERE staffID='".$_SESSION['userid']."' OR staffID='0' LIMIT 100 OFFSET 2;";
        $chargesResult = $conn->query($sql);
        $chargesCount = mysqli_num_rows($chargesResult);
        $sql = "SELECT Price FROM statement_chargesofmerchandise  WHERE Service='Casket' AND (staffID='".$_SESSION['userid']."' OR staffID='0');";
        $casketresult = mysqli_fetch_array($conn->query($sql));
        $sql = "SELECT Price FROM statement_chargesofmerchandise  WHERE Service='Outer Burial Container' AND (staffID='".$_SESSION['userid']."' OR staffID='0');";
        $obcresult = mysqli_fetch_array($conn->query($sql));

        $sql = "SELECT * FROM statement_changesforservices WHERE staffID='".$_SESSION['userid']."' OR staffID='0';";
        $chargeSelectResult = $conn->query($sql);
        $chargeSelectCount = mysqli_num_rows($chargeSelectResult);
        
        $sql = "SELECT * FROM statement_totalspecialcharges WHERE staffID='".$_SESSION['userid']."' OR staffID='0';";
        $specialChargeResult = $conn->query($sql);
        $specialChargeCount = mysqli_num_rows($specialChargeResult);

        $sql = "SELECT * FROM statement_cashadvanced WHERE staffID='".$_SESSION['userid']."' OR staffID='0' LIMIT 8 OFFSET 0;";
        $cashAdvanceResult = $conn->query($sql);
        $cashAdvanceCount = mysqli_num_rows($cashAdvanceResult);
        $sql = "SELECT * FROM statement_cashadvanced WHERE staffID='".$_SESSION['userid']."' OR staffID='0' LIMIT 100 OFFSET 8;";
        $cashAdvance_2Result = $conn->query($sql);
        $cashAdvance_2Count = mysqli_num_rows($cashAdvance_2Result);
        
        $sql = "SELECT * FROM statement_summaryofcharges WHERE staffID='".$_SESSION['userid']."' OR staffID='0';";
        $summaryResult = $conn->query($sql);
        $summaryCount = mysqli_num_rows($summaryResult);

        $sql = "SELECT * FROM statement_totalamountdue WHERE staffID='".$_SESSION['userid']."' OR staffID='0';";
        $amountResult = $conn->query($sql);
        $amountCount = mysqli_num_rows($amountResult);

        $sql = "SELECT * FROM statement_reasonsfor WHERE staffID='".$_SESSION['userid']."' OR staffID='0';";
        $reasonResult = $conn->query($sql);
        $reasonCount = mysqli_num_rows($reasonResult);

        $sql = "SELECT * FROM statement_terms_of_agreement WHERE staffID='".$_SESSION['userid']."' OR staffID='0';";
        $result = $conn->query($sql);
        if (mysqli_num_rows($result) > 0) {
            $terms = mysqli_fetch_assoc($result);
        }

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
<style>
    .custom-col{
        padding-right:0px!important; padding-left:0px!important;
    }
    .casket-form-input {
        outline: 0;
        border-width: 0 0 2px;
        border-color: blue
    }
    .casket-form-input:focus {
        border-color: green
    }
    .hidden-form-wrapper{
        padding-left:30px;
        padding-right:30px;
    }
    .imagePreview {
        width: 100%;
        height: 180px;
        background-position: center center;
    background:url(http://cliquecities.com/assets/no-image-e3699ae23f866f6cbdf8ba2443ee5c4e.jpg);
    background-color:#fff;
        background-size: cover;
    background-repeat:no-repeat;
        display: inline-block;
    box-shadow:0px -3px 6px 2px rgba(0,0,0,0.2);
    }
    .btn-primary
    {
    display:block;
    border-radius:0px;
    box-shadow:0px 4px 6px 2px rgba(0,0,0,0.2);
    margin-top:-5px;
    }
    .imgUp
    {
    margin-bottom:15px;
    }
    .del
    {
    position:absolute;
    top:0px;
    right:15px;
    width:30px;
    height:30px;
    text-align:center;
    line-height:30px;
    background-color:rgba(255,255,255,0.6);
    cursor:pointer;
    }
    .imgAdd
    {
    width:30px;
    height:30px;
    border-radius:50%;
    background-color:#4bd7ef;
    color:#fff;
    box-shadow:0px 0px 2px 1px rgba(0,0,0,0.2);
    text-align:center;
    line-height:30px;
    margin-top:0px;
    cursor:pointer;
    font-size:15px;
    }
    /* Add a hover effect (blue shadow) */
    img:hover {
    box-shadow: 0 0 2px 1px rgba(0, 140, 186, 0.5);
    }
    .modal-backdrop.show {
        opacity: 0;
    }
    .modal-backdrop {
        z-index: unset;
    }
    .modal.show {
        background: #000000a3;
    }
    .modal-content {
        margin-top: 50%;
    }
    .modal .modal-body img {
        max-width: -webkit-fill-available;
        width: 100%;
    }
</style>
<div class="page-title-heading">
    <div>
        <h3 style="background: #16aaff;">Statement of Goods & Services</h3>
    </div>
</div>
</div>
</div>
<div class="row">
    <div class="col-md-12">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-11">
                            <h5 class="card-title custom-head" style="background: #16aaff;">STATEMENT OF GOODS &AMP; SERVICES </h5>
                        </div>
                        <div class="col-md-1">
                            <button id="btn_statementreport" class="btn btn-block btn btn-danger">Report</button>
                        </div>
                    </div>
                </div>
                <div id="accordion_INF" class="accordion-wrapper mb-3 custom-accordian">
                    <div class="card">
                        <div  class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne2" aria-expanded="false" aria-controls="collapseTwo" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Informants</h5></button>
                        </div>
                        <div data-parent="#accordion_INF" id="collapseOne2" class="collapse">
                            <div class="card-body">
                                <?php if ($infoCount > 0) { ?>
                                <select name="INF_select" id="INF_select" class="form-control" required>
                                    <option hidden>Select any informant:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($infoResult)) { ?>
                                        
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" ><?php echo ($dropdown_city_cld["InformantName"]); ?></option>
                                    <?php } ?>
                                </select>
                                <br>
                                <?php } else{echo ('no informants assigned');} ?>
                                <?php include('inc/informant.php'); ?> 
                            </div>
                        </div>
                    </div>
                   <br>
                    <div class="row">
                        <div class="col-md-4">
                        <div class="sub-form">
                            <p class="card-title custom-head" style="background: white; color: black;">Professional Services</p>
                            <?php if ($professionalCount > 0) {
                                    while($great_grandChildren = mysqli_fetch_assoc($professionalResult)) { ?>
                                        <div class="form-group row">
                                            <div class="col-md-8 d-flex">
                                            <label class="control-label justify-content-center align-self-center"><?php echo $great_grandChildren['Service']; ?></label>
                                            </div>
                                            <div class="col-md-4 form-groups">
                                                <input type="number" class="form-control currency" name="SOGS_proser_<?php echo $great_grandChildren['id']; ?>" id="SOGS_proser_<?php echo $great_grandChildren['id']; ?>" value="<?php echo $great_grandChildren['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                            </div> 
                                        </div>
                            <?php }}else{ echo ('There is no item until now.');} ?>
                            
                            <div class="form-group row">
                            <div class="col-md-3">
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_proserv"><i class="fa fa-plus p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Add New...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_proserv_edit"><i class="fa fa-edit p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Edit...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_proserv_del"><i class="fa fa-trash p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Delete...</a>
                            </div> 
                            </div>

                        </div>
                        <div class="sub-form">
                            <p class="card-title custom-head" style="background: white; color: black;">Facilities & Equipment</p>
                            <?php if ($facilitiesCount > 0) {
                                    while($great_grandChildren = mysqli_fetch_assoc($facilitiesResult)) { ?>
                                        <div class="form-group row">
                                            <div class="col-md-8 d-flex">
                                            <label class="control-label justify-content-center align-self-center"><?php echo $great_grandChildren['Service']; ?></label>
                                            </div>
                                            <div class="col-md-4 form-groups">
                                                <input type="number" class="form-control currency" name="SOGS_fac_<?php echo $great_grandChildren['id']; ?>" id="SOGS_fac_<?php echo $great_grandChildren['id']; ?>" value="<?php echo $great_grandChildren['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                            </div> 
                                        </div>
                            <?php }}else{ echo ('There is no item until now.');} ?>
                            
                            <div class="form-group row">
                            <div class="col-md-3">
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_facilities"><i class="fa fa-plus p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Add New...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_facilities_edit"><i class="fa fa-edit p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Edit...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_facilities_del"><i class="fa fa-trash p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Delete...</a>
                            </div> 
                            </div>
                        </div>
                        <div class="sub-form">
                            <p class="card-title custom-head" style="background: white; color: black;">Automotive & Equipment</p>
                            <?php if ($automotiveCount > 0) {
                                    while($great_grandChildren = mysqli_fetch_assoc($automotiveResult)) { ?>
                                        <div class="form-group row">
                                            <div class="col-md-8 d-flex">
                                            <label class="control-label justify-content-center align-self-center"><?php echo $great_grandChildren['Service']; ?></label>
                                            </div>
                                            <div class="col-md-4 form-groups">
                                                <input type="number" class="form-control currency" name="SOGS_auto_<?php echo $great_grandChildren['id']; ?>" id="SOGS_auto_<?php echo $great_grandChildren['id']; ?>" value="<?php echo $great_grandChildren['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                            </div> 
                                        </div>
                            <?php }}else{ echo ('There is no item until now.');} ?>
                            
                            <div class="form-group row">
                            <div class="col-md-3">
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_automotive"><i class="fa fa-plus p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Add New...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_automotive_edit"><i class="fa fa-edit p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Edit...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_automotive_del"><i class="fa fa-trash p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Delete...</a>
                            </div> 
                            </div>
                        </div>
                        <div class="sub-form">
                            <p class="card-title custom-head" style="background: white; color: black;">Charges of Merchandise Selected</p>
                            <div class="form-group row">
                                <div class="col-md-8 d-flex">
                                    <label class="control-label justify-content-center align-self-center">Casket</label>
                                </div>
                                <div class="col-md-4 form-groups">
                                    <input type="number" class="form-control currency SOGS_merchandise" name="SOGS_merchandise_casket" id="SOGS_merchandise_casket" value="<?php echo $casketresult['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                </div>
                            </div>
                            <div class="form-group casket-form" id="casket-form" hidden>
                                <div class="hidden-form-wrapper">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="control-label justify-content-center align-self-center">Casket................................................................</label>
                                        </div>
                                        <div class="col-md-1">
                                            <input type="number" class="currency casket-form-input" name="SOGS_casket_totalprice" id="SOGS_casket_totalprice" value="<?php echo $casketresult['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" name="MLT_DD214" id="MLT_DD214" class="">Wood&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Type:&nbsp;
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-1">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="text"  name=""  class="casket-form-input" maxlength="15" size="15" >
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-2 col-2 ">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox">Steel: 
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"> 16ga
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" > 18ga
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  > 20ga
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  >
                                                <input type="text"  name=""  class="casket-form-input" maxlength="2" size="2" > &nbsp;ga
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  name="MLT_HonorGuard" id="MLT_HonorGuard" class="" >Stainless
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3 col-3">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox">Bronze: 
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"> 32oz
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" > 48oz
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3 col-3">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox">Copper: 
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"> 32oz
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" > 48oz
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" name="MLT_DD214" id="MLT_DD214" class="">Other:&nbsp;&nbsp;
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-1 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="text"  name=""  class="casket-form-input" maxlength="" size="" >
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-2 col-2 ">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox">Seal 
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"> Unseal
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" > Gasketed
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-3 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  > Nongasketed
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  name="MLT_HonorGuard" id="MLT_HonorGuard" class="" >N / A
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-4">
                                            <div class="form-group">
                                                <label class="control-label">
                                                Interior Lining: 
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"> Crepe
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" > Velvet
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  > Satin
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  >
                                                <input type="text"  name=""  class="casket-form-input"  size="5" placeholder="Other...">
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-2 col-2">
                                            <div class="form-group">
                                                <label class="control-label">
                                                Sell: 
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"> Square
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" > Round
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-4 custom-col">
                                            <!-- <div class="form-group"> -->
                                                <label class="">
                                                Exterior Color: (opt)
                                                </label>
                                            <!-- </div> -->
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <input type="text"  name=""  class="casket-form-input"  size="5" placeholder="">  
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-8 d-flex">
                                        </div>
                                        <div class="col-md-4 form-groups">
                                            <button type="button" class="btn btn-outline-success btn-sm" id="btn_casket_form" value="">Hide</button>
                                        </div>
                                    </div>
                                </div>          
                            </div>
                            <div class="form-group row">
                                <div class="col-md-8 d-flex">
                                    <label class="control-label justify-content-center align-self-center">Outer Burial Container</label>
                                </div>
                                <div class="col-md-4 form-groups">
                                    <input type="number" class="form-control currency SOGS_merchandise" name="SOGS_merchandise_obc" id="SOGS_merchandise_obc" value="<?php echo $obcresult['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                </div>
                            </div>
                            <div class="form-group outer-form" id="outer-form" hidden>
                                <div class="hidden-form-wrapper">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="control-label justify-content-center align-self-center">Outer Burial Container</label>
                                        </div>
                                        <div class="col-md-1">
                                            <input type="number" class="currency casket-form-input" name="SOGS_outer_totalprice" id="SOGS_outer_totalprice" value="<?php echo $obcresult['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-2 col-2 ">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox">Liner
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"> Vault
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" > Box
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-4 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  > Other&nbsp;(description):
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-10 col-10">
                                            <div class="form-group">
                                                <input type="text"  name=""  class="casket-form-input" maxlength="" size="" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-4 ">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox">Concrete
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" name="MLT_DD214" id="MLT_DD214" class="">Wood
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-1">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="text"  name=""  class="casket-form-input" maxlength="" size="15" placeholder="type:">
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-2 col-2 ">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox">Steel: 
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"> 7ga
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" > 10ga
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  > 12ga
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  >
                                                <input type="text"  name=""  class="casket-form-input" maxlength="2" size="2" > &nbsp;ga
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  name="MLT_HonorGuard" id="MLT_HonorGuard" class="" >Stainless
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3 col-3">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox">Bronze: 
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  >
                                                <input type="text"  name=""  class="casket-form-input" maxlength="2" size="2" > &nbsp;oz
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-1 custom-col">    
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" > Copper:
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  >
                                                <input type="text"  name=""  class="casket-form-input" maxlength="2" size="2" > &nbsp;oz
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox" name="MLT_DD214" id="MLT_DD214" class="">Other:&nbsp;&nbsp;
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-1 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="text"  name=""  class="casket-form-input" maxlength="" size="" >
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-2 col-2 ">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox">Seal 
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"> Unseal
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-2 custom-col">
                                            <div class="form-group">
                                                <label class="control-label">
                                                <input type="checkbox"  name="MLT_HonorGuard" id="MLT_HonorGuard" class="" >N / A
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-8 d-flex">
                                        </div>
                                        <div class="col-md-4 form-groups">
                                            <button type="button" class="btn btn-outline-success btn-sm" id="btn_obc_form" value="">Hide</button>
                                        </div>
                                    </div>
                                </div>          
                            </div>

                            <?php if ($chargesCount > 0) {
                                    while($great_grandChildren = mysqli_fetch_assoc($chargesResult)) { ?>
                                        <div class="form-group row">
                                            <div class="col-md-8 d-flex">
                                            <label class="control-label justify-content-center align-self-center"><?php echo $great_grandChildren['Service']; ?></label>
                                            </div>
                                            <div class="col-md-4 form-groups">
                                                <input type="number" class="form-control currency SOGS_merchandise" name="SOGS_merchandise_<?php echo $great_grandChildren['id']; ?>" id="SOGS_merchandise_<?php echo $great_grandChildren['id']; ?>" value="<?php echo $great_grandChildren['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                            </div>
                                        </div>
                            <?php }}else{ echo ('There is no item until now.');} ?>
                            
                            <div class="form-group row">
                            <div class="col-md-3">
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_merchandise"><i class="fa fa-plus p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Add New...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_merchandise_edit"><i class="fa fa-edit p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Edit...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_merchandise_del"><i class="fa fa-trash p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Delete...</a>
                            </div> 
                            </div>
                        </div>
                        </div>
                        <div class="col-md-4">
                        <div class="sub-form">
                            <p class="card-title custom-head" style="background: white; color: black;">Charges for Services Selected</p>
                            <?php if ($chargeSelectCount > 0) {
                                    while($great_grandChildren = mysqli_fetch_assoc($chargeSelectResult)) { ?>
                                        <div class="form-group row">
                                            <div class="col-md-8 d-flex">
                                            <label class="control-label justify-content-center align-self-center"><?php echo $great_grandChildren['Service']; ?></label>
                                            </div>
                                            <div class="col-md-4 form-groups">
                                                <input type="number" class="form-control currency" name="SOGS_service_<?php echo $great_grandChildren['id']; ?>" id="SOGS_service_<?php echo $great_grandChildren['id']; ?>" value="<?php echo $great_grandChildren['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                            </div> 
                                        </div>
                            <?php }}else{ echo ('There is no item until now.');} ?>
                            
                            <div class="form-group row">
                            <div class="col-md-3">
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_services"><i class="fa fa-plus p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Add New...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_services_edit"><i class="fa fa-edit p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Edit...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_services_del"><i class="fa fa-trash p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Delete...</a>
                            </div> 
                            </div>
                        </div>
                        <div class="sub-form">
                            <p class="card-title custom-head" style="background: white; color: black;">Total Special Charges</p>
                            <?php if ($specialChargeCount > 0) {
                                    while($great_grandChildren = mysqli_fetch_assoc($specialChargeResult)) { ?>
                                        <div class="form-group row">
                                            <div class="col-md-8 d-flex">
                                            <label class="control-label justify-content-center align-self-center"><?php echo $great_grandChildren['Service']; ?></label>
                                            </div>
                                            <div class="col-md-4 form-groups">
                                                <input type="number" class="form-control currency" name="SOGS_totalspecial_<?php echo $great_grandChildren['id']; ?>" id="SOGS_totalspecial_<?php echo $great_grandChildren['id']; ?>" value="<?php echo $great_grandChildren['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                            </div> 
                                        </div>
                            <?php }}else{ echo ('There is no item until now.');} ?>
                            
                            <div class="form-group row">
                            <div class="col-md-3">
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_totalspecial"><i class="fa fa-plus p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Add New...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_totalspecial_edit"><i class="fa fa-edit p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Edit...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_totalspecial_del"><i class="fa fa-trash p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Delete...</a>
                            </div> 
                            </div>
                        </div>
                        <div class="sub-form">
                            <p class="card-title custom-head" style="background: white; color: black;">Cash Advances</p>
                            <?php if ($cashAdvanceCount > 0 && $cashAdvanceCount < 8) {
                                    while($great_grandChildren = mysqli_fetch_assoc($cashAdvanceResult)) { ?>
                                        <div class="form-group row">
                                            <div class="col-md-8 d-flex">
                                            <label class="control-label justify-content-center align-self-center"><?php echo $great_grandChildren['Service']; ?></label>
                                            </div>
                                            <div class="col-md-4 form-groups">
                                                <input type="number" class="form-control currency" name="SOGS_cash_<?php echo $great_grandChildren['id']; ?>" id="SOGS_cash_<?php echo $great_grandChildren['id']; ?>" value="<?php echo $great_grandChildren['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                            </div> 
                                        </div>
                                    <?php } ?>
                            
                            <div class="form-group row">
                            <div class="col-md-3">
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_cashadvanced"><i class="fa fa-plus p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Add New...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_cashadvanced_edit"><i class="fa fa-edit p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Edit...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_cashadvanced_del"><i class="fa fa-trash p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Delete...</a>
                            </div> 
                            </div>
                            <?php } else { 
                                    while($great_grandChildren = mysqli_fetch_assoc($cashAdvanceResult)) { ?>
                                        <div class="form-group row">
                                            <div class="col-md-8 d-flex">
                                            <label class="control-label justify-content-center align-self-center"><?php echo $great_grandChildren['Service']; ?></label>
                                            </div>
                                            <div class="col-md-4 form-groups">
                                                <input type="number" class="form-control currency" name="SOGS_cash_<?php echo $great_grandChildren['id']; ?>" id="SOGS_cash_<?php echo $great_grandChildren['id']; ?>" value="<?php echo $great_grandChildren['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                            </div> 
                                        </div>
                                    <?php } } ?>

                        </div>
                        </div>
                        <div class="col-md-4">
                        <div class="sub-form">
                            <?php if ($cashAdvance_2Count > 0) {
                                    while($great_grandChildren = mysqli_fetch_assoc($cashAdvance_2Result)) { ?>
                                        <div class="form-group row">
                                            <div class="col-md-8 d-flex">
                                                <label class="control-label justify-content-center align-self-center"><?php echo $great_grandChildren['Service']; ?></label>
                                            </div>
                                            <div class="col-md-4 form-groups">
                                                <input type="number" class="form-control currency" name="SOGS_cash_<?php echo $great_grandChildren['id']; ?>" id="SOGS_cash_<?php echo $great_grandChildren['id']; ?>" value="<?php echo $great_grandChildren['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                            </div> 
                                        </div>
                                <?php } ?>
                            <div class="form-group row">
                            <div class="col-md-3">
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_cashadvanced"><i class="fa fa-plus p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Add New...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_cashadvanced_edit"><i class="fa fa-edit p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Edit...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_cashadvanced_del"><i class="fa fa-trash p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Delete...</a>
                            </div> 
                            </div>
                            <?php } ?>  
                        </div>
                        <div class="sub-form">
                            <p class="card-title custom-head" style="background: white; color: black;">Summary Of Charges</p>
                            <?php if ($summaryCount > 0) {
                                    while($great_grandChildren = mysqli_fetch_assoc($summaryResult)) { ?>
                                        <div class="form-group row">
                                            <div class="col-md-8 d-flex">
                                            <label class="control-label justify-content-center align-self-center"><?php echo $great_grandChildren['Service']; ?></label>
                                            </div>
                                            <div class="col-md-4 form-groups">
                                                <input type="number" class="form-control currency" name="SOGS_summarycharges_<?php echo $great_grandChildren['id']; ?>" id="SOGS_summarycharges_<?php echo $great_grandChildren['id']; ?>" value="<?php echo $great_grandChildren['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                            </div> 
                                        </div>
                            <?php }}else{ echo ('There is no item until now.');} ?>
                            
                            <div class="form-group row">
                            <div class="col-md-3">
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_summaryofcharges"><i class="fa fa-plus p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Add New...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_summaryofcharges_edit"><i class="fa fa-edit p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Edit...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_summaryofcharges_del"><i class="fa fa-trash p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Delete...</a>
                            </div> 
                            </div>
                        </div>
                        <div class="sub-form">
                            <p class="card-title custom-head" style="background: white; color: black;">Total Amount Due</p>
                            <?php if ($amountCount > 0) {
                                    while($great_grandChildren = mysqli_fetch_assoc($amountResult)) { ?>
                                        <div class="form-group row">
                                            <div class="col-md-8 d-flex">
                                            <label class="control-label justify-content-center align-self-center"><?php echo $great_grandChildren['Service']; ?></label>
                                            </div>
                                            <div class="col-md-4 form-groups">
                                                <input type="number" class="form-control currency" name="SOGS_totalamountdue_<?php echo $great_grandChildren['id']; ?>" id="SOGS_totalamountdue_<?php echo $great_grandChildren['id']; ?>" value="<?php echo $great_grandChildren['Price']; ?>" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" />
                                            </div> 
                                        </div>
                            <?php }}else{ echo ('There is no item until now.');} ?>
                            
                            <div class="form-group row">
                            <div class="col-md-3">
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_totalamountdue"><i class="fa fa-plus p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Add New...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_totalamountdue_edit"><i class="fa fa-edit p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Edit...</a>
                            </div>
                            <div class="col-md-3">
                                <a href="" data-toggle="modal" data-target="#modal_totalamountdue_del"><i class="fa fa-trash p-1 m-2" style="color: white; background: black; font-size: 10px;"></i>Delete...</a>
                            </div> 
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2 d-flex">
                            <label class="control-label justify-content-center align-self-center">Reason For </label>
                        </div>
                        <div class="col-md-2 d-flex">
                            <input type="text" name="SOGS_Reasonfortext"   class="form-control required " required>
                        </div>
                        <div class="col-md-8 form-groups">
                        <?php
                            $sql = "SELECT * FROM dropdown_reasonfor";
                            $result = $conn->query($sql);
                        ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_reasonfor" id="SOGS_reasonfor" class="form-control" required>
                                <option value="0" hidden>select...</option>
                                <?php 
                                while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                    ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>" ><?php echo ($dropdown_zip_cld['name']); ?></option>
                                <?php }?>
                            </select>
                        <?php } else{echo ('no option to be selected');}?>
                        </div> 
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-2 d-flex">
                            <label class="control-label justify-content-center align-self-center">Items Listed </label>
                        </div>
                        <div class="col-md-2 d-flex">
                            <input type="text" name="SOGS_Reasonfortext"   class="form-control required " required>
                        </div>
                        <div class="col-md-8 form-groups">
                            <?php
                                $value = (isset($information['States']) ) ? trim($information['States']) : '';
                            ?>
                            <select name="SOGS_Itemlisted" class="form-control required " id="SOGS_Itemlisted" required>
                                <option value="">Select</option> 
                            </select>
                        </div> 
                    </div>
                    <br>
                    <div class="row" style="margin-top: 10px">
                        <div class="col-md-12">
                            <li style="font-weight: bold;">Terms:</li> payment total is due 
                            <?php
                                $value = (isset($terms['Price1']) ) ? trim($terms['Price1']) : '';
                            ?>
                            <input name="TERM_Price1" type="text" style="width: 80px" value="<?php echo $value ?>" placeholder="$ 0.00"> days from date,
                            after which a finance charge of 
                            <?php
                                $value = (isset($terms['Price2']) ) ? trim($terms['Price2']) : '';
                            ?>
                            <input name="TERM_Price2" type="text" style="width: 80px" value="<?php echo $value ?>" name="FinanceCharge" placeholder="% "> per month,
                            annual 
                            <?php
                                $value = (isset($terms['Price3']) ) ? trim($terms['Price3']) : '';
                            ?>
                            <input name="TERM_Price3" type="text" style="width: 80px" value="<?php echo $value ?>" name="Annual" placeholder="% "> shall be added to the unpaid balance.
                            I/we the have seen the General price list, Casket and outer Burial price list, promise to pay above and have given a signed copy of the statement.

                        </div>
                    </div>
                </div>
            </div>
    </div>
<!-- //////////////////////////////////////////////for adding//////////////////////////////////////////////////////// -->

    <!-- modal_proserv -->
    <div class="modal fade" id="modal_proserv">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title">Input new Item here.</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
            <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
              <div class="modal-body">
                <input type="hidden" name="SOGS_table"  value="statement_professional">
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Category: </label></div>
                    <div class="col-md-8">
                      <?php
                      $sql = "SELECT * FROM dropdown_statementcategories";
                      $result = $conn->query($sql);
                      ?>
                      <?php if (mysqli_num_rows($result) > 0) { ?>
                          <select name="SOGS_Category"  class="form-control " required>
                              <option value="0" hidden>select...</option>
                              <?php 
                              while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                  ?>
                                  <option value="<?php echo ($dropdown_zip_cld['tablename']); ?>" <?php if(trim($dropdown_zip_cld['name'])===trim('Professional Services')){ echo ('selected');} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                              <?php }?>
                          </select>
                      <?php } else{echo ('no category to be selected');}?>
                    </div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                    <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder=""/></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Permanent: </label></div>
                    <div class="col-md-2"><input type="checkbox" class="form-control SOGS_permanent" name="SOGS_permanent"></div> 
                </div>
               
              </div>
              <div class="modal-footer">
                <div class="col-md-8 d-flex"></div>
                <div class="col-md-2"><button type="submit" class="btn btn-info" >Save</button></div> 
                <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
              </div>
            </form>
          </div>
      </div>
    </div> 
    <!-- modal_facilities -->
    <div class="modal fade" id="modal_facilities">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title">Input new Item here.</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
            <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
              <div class="modal-body">
                <input type="hidden" name="SOGS_table"  value="statement_facilities">
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Category: </label></div>
                    <div class="col-md-8">
                      <?php
                      $sql = "SELECT * FROM dropdown_statementcategories";
                      $result = $conn->query($sql);
                      ?>
                      <?php if (mysqli_num_rows($result) > 0) { ?>
                          <select name="SOGS_Category"  class="form-control " required>
                              <option value="0" hidden>select...</option>
                              <?php 
                              while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                  ?>
                                  <option value="<?php echo ($dropdown_zip_cld['tablename']); ?>" <?php if(trim($dropdown_zip_cld['name'])===trim('Facilites & Equipment')){ echo ('selected');} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                              <?php }?>
                          </select>
                      <?php } else{echo ('no category to be selected');}?>
                    </div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                    <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder="" /></div> 
                </div>
              </div>
              <div class="modal-footer">
                <div class="col-md-8 d-flex"></div>
                <div class="col-md-2"><button type="submit" class="btn btn-info" >Save</button></div> 
                <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
              </div>
            </form>
          </div>
      </div>
    </div> 
    <!-- modal_automotive -->
    <div class="modal fade" id="modal_automotive">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title">Input new Item here.</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
            <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
              <div class="modal-body">
                <input type="hidden" name="SOGS_table"  value="statement_automotive">
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Category: </label></div>
                    <div class="col-md-8">
                      <?php
                      $sql = "SELECT * FROM dropdown_statementcategories";
                      $result = $conn->query($sql);
                      ?>
                      <?php if (mysqli_num_rows($result) > 0) { ?>
                          <select name="SOGS_Category"  class="form-control " required>
                              <option value="0" hidden>select...</option>
                              <?php 
                              while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                  ?>
                                  <option value="<?php echo ($dropdown_zip_cld['tablename']); ?>" <?php if(trim($dropdown_zip_cld['name'])===trim('Automotive & Equipment')){ echo ('selected');} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                              <?php }?>
                          </select>
                      <?php } else{echo ('no category to be selected');}?>
                    </div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                    <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder="" /></div> 
                </div>
              </div>
              <div class="modal-footer">
                <div class="col-md-8 d-flex"></div>
                <div class="col-md-2"><button type="submit" class="btn btn-info" >Save</button></div> 
                <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
              </div>
            </form>
          </div>
      </div>
    </div> 
    <!-- modal_merchandise -->
    <div class="modal fade" id="modal_merchandise">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title">Input new Item here.</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
            <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
              <div class="modal-body">
                <input type="hidden" name="SOGS_table"  value="statement_chargesofmerchandise">
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Category: </label></div>
                    <div class="col-md-8">
                      <?php
                      $sql = "SELECT * FROM dropdown_statementcategories";
                      $result = $conn->query($sql);
                      ?>
                      <?php if (mysqli_num_rows($result) > 0) { ?>
                          <select name="SOGS_Category"  class="form-control " required>
                              <option value="0" hidden>select...</option>
                              <?php 
                              while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                  ?>
                                  <option value="<?php echo ($dropdown_zip_cld['tablename']); ?>" <?php if(trim($dropdown_zip_cld['name'])===trim('Charges of Merchandise Selected')){ echo ('selected');} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                              <?php }?>
                          </select>
                      <?php } else{echo ('no category to be selected');}?>
                    </div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                    <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder="" /></div> 
                </div>
              </div>
              <div class="modal-footer">
                <div class="col-md-8 d-flex"></div>
                <div class="col-md-2"><button type="submit" class="btn btn-info" >Save</button></div> 
                <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
              </div>
            </form>
          </div>
      </div>
    </div> 
    <!-- modal_services-->
    <div class="modal fade" id="modal_services">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title">Input new Item here.</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
            <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
              <div class="modal-body">
                <input type="hidden" name="SOGS_table"  value="statement_changesforservices">
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Category: </label></div>
                    <div class="col-md-8">
                      <?php
                      $sql = "SELECT * FROM dropdown_statementcategories";
                      $result = $conn->query($sql);
                      ?>
                      <?php if (mysqli_num_rows($result) > 0) { ?>
                          <select name="SOGS_Category"  class="form-control " required>
                              <option value="0" hidden>select...</option>
                              <?php 
                              while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                  ?>
                                  <option value="<?php echo ($dropdown_zip_cld['tablename']); ?>" <?php if(trim($dropdown_zip_cld['name'])===trim('Changes for Services Selected')){ echo ('selected');} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                              <?php }?>
                          </select>
                      <?php } else{echo ('no category to be selected');}?>
                    </div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                    <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder="" /></div> 
                </div>
              </div>
              <div class="modal-footer">
                <div class="col-md-8 d-flex"></div>
                <div class="col-md-2"><button type="submit" class="btn btn-info" >Save</button></div> 
                <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
              </div>
            </form>
          </div>
      </div>
    </div> 
    <!-- modal_totalspecial -->
    <div class="modal fade" id="modal_totalspecial">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title">Input new Item here.</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
            <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
              <div class="modal-body">
                <input type="hidden" name="SOGS_table"  value="statement_totalspecialcharges">
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Category: </label></div>
                    <div class="col-md-8">
                      <?php
                      $sql = "SELECT * FROM dropdown_statementcategories";
                      $result = $conn->query($sql);
                      ?>
                      <?php if (mysqli_num_rows($result) > 0) { ?>
                          <select name="SOGS_Category"  class="form-control " required>
                              <option value="0" hidden>select...</option>
                              <?php 
                              while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                  ?>
                                  <option value="<?php echo ($dropdown_zip_cld['tablename']); ?>" <?php if(trim($dropdown_zip_cld['name'])===trim('Total Special Charges')){ echo ('selected');} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                              <?php }?>
                          </select>
                      <?php } else{echo ('no category to be selected');}?>
                    </div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                    <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder="" /></div> 
                </div>
              </div>
              <div class="modal-footer">
                <div class="col-md-8 d-flex"></div>
                <div class="col-md-2"><button type="submit" class="btn btn-info" >Save</button></div> 
                <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
              </div>
            </form>
          </div>
      </div>
    </div> 
    <!-- modal_cashadvanced -->
    <div class="modal fade" id="modal_cashadvanced">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title">Input new Item here.</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
            <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
              <div class="modal-body">
                <input type="hidden" name="SOGS_table"  value="statement_cashadvanced">
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Category: </label></div>
                    <div class="col-md-8">
                      <?php
                      $sql = "SELECT * FROM dropdown_statementcategories";
                      $result = $conn->query($sql);
                      ?>
                      <?php if (mysqli_num_rows($result) > 0) { ?>
                          <select name="SOGS_Category"  class="form-control " required>
                              <option value="0" hidden>select...</option>
                              <?php 
                              while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                  ?>
                                  <option value="<?php echo ($dropdown_zip_cld['tablename']); ?>" <?php if(trim($dropdown_zip_cld['name'])===trim('Cash Advanced')){ echo ('selected');} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                              <?php }?>
                          </select>
                      <?php } else{echo ('no category to be selected');}?>
                    </div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                    <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder="" /></div> 
                </div>
              </div>
              <div class="modal-footer">
                <div class="col-md-8 d-flex"></div>
                <div class="col-md-2"><button type="submit" class="btn btn-info" >Save</button></div> 
                <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
              </div>
            </form>
          </div>
      </div>
    </div> 
    <!-- modal_summaryofcharges -->
    <div class="modal fade" id="modal_summaryofcharges">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title">Input new Item here.</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
            <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
              <div class="modal-body">
                <input type="hidden" name="SOGS_table"  value="statement_summaryofcharges">
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Category: </label></div>
                    <div class="col-md-8">
                      <?php
                      $sql = "SELECT * FROM dropdown_statementcategories";
                      $result = $conn->query($sql);
                      ?>
                      <?php if (mysqli_num_rows($result) > 0) { ?>
                          <select name="SOGS_Category"  class="form-control " required>
                              <option value="0" hidden>select...</option>
                              <?php 
                              while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                  ?>
                                  <option value="<?php echo ($dropdown_zip_cld['tablename']); ?>" <?php if(trim($dropdown_zip_cld['name'])===trim('Summary of Charges')){ echo ('selected');} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                              <?php }?>
                          </select>
                      <?php } else{echo ('no category to be selected');}?>
                    </div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                    <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder="" /></div> 
                </div>
              </div>
              <div class="modal-footer">
                <div class="col-md-8 d-flex"></div>
                <div class="col-md-2"><button type="submit" class="btn btn-info" >Save</button></div> 
                <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
              </div>
            </form>
          </div>
      </div>
    </div> 
    <!-- modal_totalamountdue -->
    <div class="modal fade" id="modal_totalamountdue">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title">Input new Item here.</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
            <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
              <div class="modal-body">
                <input type="hidden" name="SOGS_table"  value="statement_totalamountdue">
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Category: </label></div>
                    <div class="col-md-8">
                      <?php
                      $sql = "SELECT * FROM dropdown_statementcategories";
                      $result = $conn->query($sql);
                      ?>
                      <?php if (mysqli_num_rows($result) > 0) { ?>
                          <select name="SOGS_Category"  class="form-control " required>
                              <option value="0" hidden>select...</option>
                              <?php 
                              while($dropdown_zip_cld = mysqli_fetch_assoc($result)) {                 
                                  ?>
                                  <option value="<?php echo ($dropdown_zip_cld['tablename']); ?>" <?php if(trim($dropdown_zip_cld['name'])===trim('Total Amount Due')){ echo ('selected');} ?>><?php echo ($dropdown_zip_cld['name']); ?></option>
                              <?php }?>
                          </select>
                      <?php } else{echo ('no category to be selected');}?>
                    </div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                    <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                </div>
                <div class="form-group row">
                    <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                    <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder="" /></div> 
                </div>
              </div>
              <div class="modal-footer">
                <div class="col-md-8 d-flex"></div>
                <div class="col-md-2"><button type="submit" class="btn btn-info" >Save</button></div> 
                <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
              </div>
            </form>
          </div>
      </div>
    </div> 
<!-- //////////////////////////////////////////////for editing//////////////////////////////////////////////////////// -->

    <!-- modal_proserv_edit -->
    <div class="modal fade" id="modal_proserv_edit">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_edit" value="statement_professional">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php $sql = "SELECT * FROM statement_professional"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                        <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder=""/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Permanent: </label></div>
                        <div class="col-md-2"><input type="checkbox" class="form-control SOGS_permanent" name="SOGS_permanent"></div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Edit</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- modal_facilities_edit -->
    <div class="modal fade" id="modal_facilities_edit">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_edit"  value="statement_facilities">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php $sql = "SELECT * FROM statement_facilities"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                        <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder=""/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Permanent: </label></div>
                        <div class="col-md-2"><input type="checkbox" class="form-control SOGS_permanent" name="SOGS_permanent"></div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Edit</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- modal_automotive_edit -->
    <div class="modal fade" id="modal_automotive_edit">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_edit"  value="statement_automotive">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php $sql = "SELECT * FROM statement_automotive"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                        <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder=""/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Permanent: </label></div>
                        <div class="col-md-2"><input type="checkbox" class="form-control SOGS_permanent" name="SOGS_permanent"></div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Edit</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- modal_merchandise_edit -->
    <div class="modal fade" id="modal_merchandise_edit">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_edit"  value="statement_chargesofmerchandise">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php $sql = "SELECT * FROM statement_chargesofmerchandise"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                        <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder=""/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Permanent: </label></div>
                        <div class="col-md-2"><input type="checkbox" class="form-control SOGS_permanent" name="SOGS_permanent"></div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Edit</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- modal_services_edit -->
    <div class="modal fade" id="modal_services_edit">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_edit"  value="statement_changesforservices">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php $sql = "SELECT * FROM statement_changesforservices"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                        <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder=""/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Permanent: </label></div>
                        <div class="col-md-2"><input type="checkbox" class="form-control SOGS_permanent" name="SOGS_permanent"></div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Edit</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- modal_totalspecial_edit -->
    <div class="modal fade" id="modal_totalspecial_edit">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_edit"  value="statement_totalspecialcharges">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php $sql = "SELECT * FROM statement_totalspecialcharges"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                        <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder=""/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Permanent: </label></div>
                        <div class="col-md-2"><input type="checkbox" class="form-control SOGS_permanent" name="SOGS_permanent"></div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Edit</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- modal_cashadvanced_edit -->
    <div class="modal fade" id="modal_cashadvanced_edit">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_edit"  value="statement_cashadvanced">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php $sql = "SELECT * FROM statement_cashadvanced"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                        <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder=""/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Permanent: </label></div>
                        <div class="col-md-2"><input type="checkbox" class="form-control SOGS_permanent" name="SOGS_permanent"></div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Edit</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- modal_summaryofcharges_edit -->
    <div class="modal fade" id="modal_summaryofcharges_edit">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_edit"  value="statement_summaryofcharges">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php $sql = "SELECT * FROM statement_summaryofcharges"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                        <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder=""/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Permanent: </label></div>
                        <div class="col-md-2"><input type="checkbox" class="form-control SOGS_permanent" name="SOGS_permanent"></div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Edit</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- modal_totalamountdue_edit -->
    <div class="modal fade" id="modal_totalamountdue_edit">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_edit"  value="statement_totalamountdue">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php $sql = "SELECT * FROM statement_totalamountdue"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Item: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newitem" placeholder="" required/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Fee: </label></div>
                        <div class="col-md-8"><input type="number" class="form-control currency" name="SOGS_newfee" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100"  placeholder="$ 0.00" /></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Reason For: </label></div>
                        <div class="col-md-8"><input type="text" class="form-control" name="SOGS_newreason" placeholder=""/></div> 
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Permanent: </label></div>
                        <div class="col-md-2"><input type="checkbox" class="form-control SOGS_permanent" name="SOGS_permanent"></div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Edit</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
<!-- //////////////////////////////////////////////for deleting//////////////////////////////////////////////////////// -->
    
    <!-- modal_proserv_del -->
    <div class="modal fade" id="modal_proserv_del">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_del" value="statement_professional">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php  $sql = "SELECT * FROM statement_professional"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Delete</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>   
    </div>
    <!-- modal_facilities_del -->
    <div class="modal fade" id="modal_facilities_del">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_del" value="statement_facilities">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php  $sql = "SELECT * FROM statement_facilities"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Delete</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>   
    </div>
    <!-- modal_automotive_del -->
    <div class="modal fade" id="modal_automotive_del">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_del" value="statement_automotive">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php  $sql = "SELECT * FROM statement_automotive"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Delete</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>   
    </div> 
    <!-- modal_merchandise_del -->
    <div class="modal fade" id="modal_merchandise_del">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_del" value="statement_chargesofmerchandise">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php  $sql = "SELECT * FROM statement_chargesofmerchandise"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Delete</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>   
    </div> 
    <!-- modal_services_del -->
    <div class="modal fade" id="modal_services_del">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_del" value="statement_changesforservices">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php  $sql = "SELECT * FROM statement_changesforservices"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Delete</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>   
    </div> 
    <!-- modal_totalspecial_del -->
    <div class="modal fade" id="modal_totalspecial_del">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_del" value="statement_totalspecialcharges">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php  $sql = "SELECT * FROM statement_totalspecialcharges"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Delete</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>   
    </div> 
    <!-- modal_cashadvanced_del -->
    <div class="modal fade" id="modal_cashadvanced_del">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_del" value="statement_cashadvanced">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php  $sql = "SELECT * FROM statement_cashadvanced"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Delete</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>   
    </div> 
    <!-- modal_summaryofcharges_del -->
    <div class="modal fade" id="modal_summaryofcharges_del">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_del" value="statement_summaryofcharges">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php  $sql = "SELECT * FROM statement_summaryofcharges"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Delete</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>   
    </div> 
    <!-- modal_totalamountdue_del -->
    <div class="modal fade" id="modal_totalamountdue_del">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete current Item here.</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form class="forms_newStatementItem" action="saveNewStatementItem.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="SOGS_table_del" value="statement_totalamountdue">
                    <div class="form-group row">
                        <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Current Item: </label></div>
                        <div class="col-md-8">
                        <?php  $sql = "SELECT * FROM statement_totalamountdue"; $result = $conn->query($sql); ?>
                        <?php if (mysqli_num_rows($result) > 0) { ?>
                            <select name="SOGS_currentItem" class="form-control" required>
                                <?php while($dropdown_zip_cld = mysqli_fetch_assoc($result)) { ?>
                                    <option value="<?php echo ($dropdown_zip_cld['id']); ?>"><?php echo ($dropdown_zip_cld['Service']); ?></option>
                                <?php } ?>
                            </select>
                        <?php } else{echo ('no category to be selected');} ?>
                        </div> 
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-8 d-flex"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-info" >Delete</button></div> 
                    <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
                </div>
                </form>
            </div>
        </div>   
    </div> 
</div>
                                    
<?php include('inc/footer.php'); ?>
<script>
  $('.forms_newStatementItem').submit(function(e){
    e.preventDefault();
    var actionurl = e.currentTarget.action;
    var btn_submit_SOGS = $(this).find(':input[type=submit]');
    $(this).find(':input[type=submit]').prop('disabled', true);
    var formserial = $(this).serialize();
    // $(this).find(':input[type=submit]').html('Processing …');
    $.ajax({
        type: "POST",
        url: actionurl,
        dataType: 'json',
        data: formserial,
        success: function(result) {
            console.log(result);
            if(result.status == 'exist'){
                btn_submit_SOGS.prop('disabled', false);
                $("#modal-newStatementItem").hide();
                alert('There is already same option. Please create others.');
            }else if(result.status == 'created'){
               btn_submit_SOGS.prop('disabled', false);
                // $("#modal-newStatementItem").hide();
                alert('Successfully saved !');
                location.reload();
            }else if(result.status == 'updated'){
                btn_submit_SOGS.prop('disabled', false);
                $("#modal-newStatementItem").hide();
                alert('Successfully updated !');
                location.reload();

            }else if(result.status == 'deleted'){
                alert('Successfully deleted !');
                location.reload();
            }
            // $("#modal-newStatementItem").modal('toggle');

        },
        error: function(result) {
            alert(result.status);
            console.log(result);
        }
    })
  })
</script>
