<?php 
    session_start();
    if (isset($_SESSION['userid'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';
        require 'database/managedropdown.php';

        $flag_addBtn = true;
        $flag_casebio = true;

        $sql = "SELECT * FROM case_bio_deceased_info WHERE caseID='".$_SESSION['selectedcaseID']."' AND staffID='".$_SESSION['userid']."';";
        $deceased = $conn->query($sql);
        $result = $conn->query($sql);
        if (mysqli_num_rows($deceased) > 0) {
            $deceasedResult = mysqli_fetch_assoc($result);
        }

        $sql = "SELECT * FROM case_bio_parents WHERE staffID='".$_SESSION['userid']."';";
        $parentsResult = $conn->query($sql);
        $parentsResultCount = mysqli_num_rows($parentsResult);

        $sql = "SELECT * FROM case_bio_children WHERE staffID='".$_SESSION['userid']."';";
        $childResult = $conn->query($sql);
        $childResultCount = mysqli_num_rows($childResult);

        $sql = "SELECT * FROM case_bio_marital WHERE staffID='".$_SESSION['userid']."';";
        $maritalResult = $conn->query($sql);
        $maritalResultCount = mysqli_num_rows($maritalResult);

        $sql = "SELECT * FROM case_bio_military_service WHERE staffID='".$_SESSION['userid']."';";
        $mltResult = $conn->query($sql);
        $mltResultCount = mysqli_num_rows($mltResult);

        $sql = "SELECT * FROM case_bio_church WHERE staffID='".$_SESSION['userid']."';";
        $churchResult = $conn->query($sql);
        $churchResultCount = mysqli_num_rows($churchResult);

        $sql = "SELECT * FROM case_bio_place_of_worship WHERE staffID='".$_SESSION['userid']."';";
        $powResult = $conn->query($sql);
        $powResultCount = mysqli_num_rows($powResult);

        $sql = "SELECT * FROM case_bio_education WHERE staffID='".$_SESSION['userid']."';";
        $educationResult = $conn->query($sql);
        $educationResultCount = mysqli_num_rows($educationResult);

        // $conn->close();
    } else {
        header('Location: login.php');
    }
?>
<style>
    .btn-primary
    {
    display:block;
    border-radius:0px;
    box-shadow:0px 4px 6px 2px rgba(0,0,0,0.2);
    margin-top:-5px;
    }
    .modal-backdrop.show {
        opacity: 0;
    }
    .modal-backdrop {
        z-index: unset;
    }
    .modal.show {
        background: #000000a3;
    }
    .modal-content {
        margin-top: 50%;
    }
    .modal .modal-body img {
        max-width: -webkit-fill-available;
        width: 100%;
    }
</style>

    <div class="page-title-heading">
        <div><h3>CASE BIO</h3></div>    
    </div>
</div>
</div>       
    <div class="row">
        <div class="col-md-12">
            <!-- <form class="longforms" id="casebio-form"> -->
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-10">
                        <nav class="" aria-label="breadcrumb">
                            <ol class="breadcrumb">
                            <?php
                                $FullName = (isset($deceased_info['FullName']) ) ? ($deceased_info['FullName']) : '';
                                $dateOfDeath = (isset($personal_info['dateOfDeath']) ) ? ($personal_info['dateOfDeath']) : '';
                                $dateOfBirth = (isset($deceased_info['DOB']) ) ? ($deceased_info['DOB']) : '';
                                $dateOfDeath_obj = new DateTime($dateOfDeath);
                                $dateOfBirth_obj = new DateTime($dateOfBirth);
                                $ageAtDeath = $dateOfBirth_obj->diff($dateOfDeath_obj)->format('%y years');
                            ?>
                                <li class="breadcrumb-item greyHeaderInformations" aria-current="page">***If you select any 'Deceased Information' row, you will see his/her age at death.</li>
                            </ol>
                        </nav>
                        <h5 class="card-title custom-head">CASE BIO</h5>
                        </div>
                        <div class="col-md-2">
                            <div class="image-holder">
                                <?php
                                    $sql = "SELECT * FROM case_bio_deceased_info WHERE staffID='".$_SESSION['userid']."' ORDER BY id DESC;";
                                    $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {
                                        $deceased_info = mysqli_fetch_assoc($result);
                                    }
                                    $photoURL = (isset($deceased_info['Photo']) ) ? trim($deceased_info['Photo']) : 'Member.png';
                                ?>
                                <a id="" href="" class="" data-toggle="modal" data-target="#modal-condizioni">
                                    <img class="testimageview" src="uploads/casebiophoto/<?php echo $photoURL;?>" alt="Case-Bio"/>
                                </a>
                                
                            </div>
                        </div>
                    </div> 
                    
                </div>
                <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                    <div class="card">
                        <div id="headingOne" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">DECEASED INFORMATION</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse show">
                            <div class="card-body">
                                
                                <?php include('inc/deceased_info.php'); ?>
                            
                        </div>
                    </div>
                    </div>
                    <div class="card">
                        <div id="headingTwo" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne2" aria-expanded="false" aria-controls="collapseTwo" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">PARENT INFORMATION</h5></button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne2" class="collapse">
                            <div class="card-body">
                                <?php if ($parentsResultCount > 0) { ?>
                                <select name="PAI_select" id="PAI_select" class="form-control" required>
                                    <option hidden>Select any church:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($parentsResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['FathersName']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                                <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/parent_info.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingTwo" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne3" aria-expanded="false" aria-controls="collapseThree" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">CHILDREN</h5></button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne3" class="collapse">
                            <div class="card-body">
                                <?php if ($childResultCount > 0) { ?>
                                <select name="CLD_case_select" id="CLD_case_select" class="form-control" required>
                                    <option hidden>Select any children per case.</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($childResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" >CaseID: <?php echo ($dropdown_city_cld['caseID']); ?></option>
                                    <?php } ?>
                                </select>
                                <br>
                                <div class="row multi-select-custom"></div> 
                                <?php } else{echo ('no case to be selected');} ?>
                                <?php include('inc/children.php'); ?>
                            </div>
                        </div>
                    </div>
                
                    <div class="card">
                        <div id="headingTwo" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne6" aria-expanded="false" aria-controls="collapseSix" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">MARITAL STATUS</h5></button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne6" class="collapse">
                            <div class="card-body">
                                <?php if ($maritalResultCount > 0) { ?>
                                <select name="MS_case_select" id="MS_case_select" class="form-control" required>
                                    <option hidden>Select any marital status:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($maritalResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['caseID']); ?>" >caseID: <?php echo ($dropdown_city_cld['caseID']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <div class="row multi-select-custom"></div> 
                                <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/marital.php'); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div id="headingTwo" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne11" aria-expanded="false" aria-controls="collapseEleven" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">MILITARY SERVICE</h5></button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne11" class="collapse">
                            <div class="card-body">
                                <?php if ($mltResultCount > 0) { ?>
                                <select name="MLT_select" id="MLT_select" class="form-control required" required>
                                    <option hidden>Select any military service:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($mltResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp; <?php echo ($dropdown_city_cld['SerialNumber']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                                <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/military_service.php'); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div id="headingTwo" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne7" aria-expanded="false" aria-controls="collapseSeven" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">CHURCH AFFILIATION</h5></button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne7" class="collapse">
                            <div class="card-body">
                                <?php if ($churchResultCount > 0) { ?>
                                <select name="CHU_select" id="CHU_select" class="form-control required" required>
                                    <option hidden>Select any church:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($churchResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['Church']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                                <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/church.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingTwo" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne8" aria-expanded="false" aria-controls="collapseEight" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">PLACE OF WORSHIP</h5></button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne8" class="collapse">
                            <div class="card-body">
                                <?php if ($powResultCount > 0) { ?>
                                <select name="POW_select" id="POW_select" class="form-control required" required>
                                    <option hidden>Select any place of worship:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($powResult)) {                 
                                        ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($dropdown_city_cld['PlaceOfWorship']); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                                <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/place_of_worship.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="headingTwo" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne9" aria-expanded="false" aria-controls="collapseNine" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">EDUCATION</h5></button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne9" class="collapse">
                            <div class="card-body">
                                <?php if ($educationResultCount > 0) { ?>
                                <select name="EDU_select" id="EDU_select" class="form-control" required>
                                    <option hidden>Select any education information:</option>
                                    <?php 
                                    while($dropdown_city_cld = mysqli_fetch_assoc($educationResult)) { ?>
                                            <?php  
                                                $sql = "SELECT name FROM dropdown_highschool WHERE id='".$dropdown_city_cld['EduHighSchool']."';";
                                                $result = mysqli_fetch_array($conn->query($sql));
                                                $sql1 = "SELECT name FROM dropdown_graduatename WHERE id='".$dropdown_city_cld['graduate']."';";
                                                $result1 = mysqli_fetch_array($conn->query($sql1));
                                                $sql2 = "SELECT name FROM dropdown_undergraduatename WHERE id='".$dropdown_city_cld['undergraducate']."';";
                                                $result2 = mysqli_fetch_array($conn->query($sql2));
                                            ?>
                                        <option value="<?php echo ($dropdown_city_cld['id']); ?>" >caseID = <?php echo ($dropdown_city_cld["caseID"]); ?>: &nbsp;<?php echo ($result["name"]); ?>, <?php echo ($result2["name"]); ?>, <?php echo ($result1["name"]); ?></option>
                                    <?php }?>
                                </select>
                                <br>
                                <br>
                                <?php } else{echo ('no option to be selected');}?>
                                <?php include('inc/education.php'); ?>
                            </div>
                        </div>
                    </div>
                                                            
                </div>
                <!--                 
                <div class="d-block text-center card-footer">
                    <button type="button" class="btn-wide btn btn-primary pull-left">Back to Home</button>
                    <button class="btn btn-success pull-right" onclick="saveCaseBioForm()">Save</button>
                </div>
                 -->
            </div>
            </form>
        </div>
    </div>
    <div class="modal fade" id="modal-condizioni">
        <div class="modal-dialog">
            <div class="modal-overlay"></div>
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title"></h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <?php
                        $photoURL = (isset($deceased_info['Photo']) ) ? trim($deceased_info['Photo']) : 'Member.png';
                    ?>
                    <img class="testimageview" src="uploads/casebiophoto/<?php echo $photoURL;?>" />
                </div>
            </div>
        </div>
    </div> 
</div>

<?php include('inc/footer.php'); ?>
