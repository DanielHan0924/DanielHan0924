<?php 
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        require 'database/connectDatabase.php';
        $flag_addBtn = true;
        //    $conn->close();
    } else {
        header('Location: login.php');
    }     
?>
<div class="page-title-heading">
    <div>
        <h3>RECURRING SUB-SECTIONS</h3>
    </div>
</div>
</div>
</div>

<div class="row">
    <div class="col-md-12">
        <!-- <form class="longforms" novalidate action="javascript:" method="POST"> -->
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- <nav class="" aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item" aria-current="page">John - Doe - 12/18/1997 - 02/17/2020</li>
                                </ol>
                            </nav> -->
                            <h5 class="card-title custom-head">MANAGE SUB-SECTIONS</h5>
                        </div>
                        <!-- <div class="col-lg-2">
                            <div class="image-holder">
                                <img src="assets/images/oldman.jpeg" />
                                <div class="d-block text-center card-footer">
                                    <button class="btn-sm btn-block btn btn-success">Save</button>
                                </div>
                            </div>
                        </div> -->
                    </div>

                </div>
                <div id="accordion" class="accordion-wrapper mb-3 custom-accordian">
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">PERSON WHO CALLED</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne1"  class="collapse show">
                            <div class="card-body">
                                <?php include('inc/person_Who_called_detail.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne11" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Vocalist</h5>
                            </button>
                        </div>
                        
                        <div data-parent="#accordion" id="collapseOne11"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/vocalist.php'); ?>
                            </div>
                        </div>
                        
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne12" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Organist</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne12"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/organist.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne13" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Florist</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne13"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/florist.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne14" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Contractor</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne14"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/contractors.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne15" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Clergy</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne15"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/clergy.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne16" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Sexton</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne16"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/sexton.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne17" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Cemetery</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne17"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/cemetery.php'); ?>
                                
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne20" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Equipment</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne20"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/equip_resource.php'); ?>
                                
                            </div>
                        </div>
                    </div>
                  
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne18" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Crematory</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne18"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/funeral_home_crematory_registration.php'); ?>
                            </div>
                        </div>
                    </div>                    
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne22" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Newspaper</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne22"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/newspaper.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne23" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Pallbearer</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne23"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/pallbearer.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne24" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Honorary Pallbearer</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne24"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/honorary_pallbearer.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne25" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Driver</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne25"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/driver.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne26" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Volunteer</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne26"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/volunteer.php'); ?>
                                <!-- There is no volunteer.php in inc folder. -->
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne27" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Distributor</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne27"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/distributor.php'); ?>
                                <!-- There is no distributor.php in inc folder. -->
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne28" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Manufacturer</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne28"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/manufacturer.php'); ?>
                                <!-- There is no manufacturer.php in inc folder. -->
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne29" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Salesperson</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne29"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/salesperson.php'); ?>
                                <!-- There is no salesperson.php in inc folder. -->
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne30" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Funeral Home / Crematory</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne30"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/funeral_home_crematory_registration.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne31" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Color Guard</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne31"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/color_guard.php'); ?>
                                <!-- There is no color_guard.php in inc folder. -->
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne32" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Escort</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne32"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/escort.php'); ?>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne33" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Surviving Relative</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne33"  class="collapse ">
                            <div class="card-body">
                                 include('inc/surviving_relative.php');
                            </div>
                        </div>
                    </div> -->
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne34" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Children</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne34"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/children.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne35" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Grand Children</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne35"  class="collapse ">
                            <div class="card-body">
                                <?php include('inc/grand_child.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne2" aria-expanded="false" aria-controls="collapseTwo" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">NEXT OF KIN</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne2" class="collapse">
                            <div class="card-body">
                                <!--REPLACE WITH INC FORM -->
                                <?php include('inc/next_of_kin.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne3" aria-expanded="false" aria-controls="collapseThree" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">LOCATION OF THE BODY</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne3" class="collapse">
                            <div class="card-body">
                                <!--REPLACE WITH INC FORM -->
                                <?php include('inc/location_of_the_body.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne4" aria-expanded="false" aria-controls="collapseFour" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">PLACE OF WORSHIP</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne4" class="collapse">
                            <div class="card-body">
                                <!--REPLACE WITH INC FORM -->
                                <?php include('inc/place_of_worship.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne10" aria-expanded="false" aria-controls="collapseFour" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">PHYSICIAN</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne10" class="collapse">
                            <div class="card-body">
                                <!--REPLACE WITH INC FORM -->
                                <?php include('inc/physician.php'); ?>
                            </div>
                        </div>
                    </div>
            <!--CONTINUING MANAGE DROPDOWNS-->
                    <div class="card">
                        <div id="" class="card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne6" aria-expanded="true" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">CHURCH</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne6" aria-labelledby="headingOne" class="collapse">
                            <div class="card-body">
                                <!--REPLACE WITH INC FORM -->
                                <?php include('inc/church.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne7" aria-expanded="false" aria-controls="collapseTwo" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">PLACE OF DEATH</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne7" class="collapse">
                            <div class="card-body">
                                <!--REPLACE WITH INC FORM -->
                                <?php include('inc/place_of_death.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne8" aria-expanded="false" aria-controls="collapseThree" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">BEAUTICIAN / BARBER</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne8" class="collapse">
                            <div class="card-body">
                                <!--REPLACE WITH INC FORM -->
                                <?php include('inc/beautician_barber.php'); ?>
                            </div>
                        </div>
                    </div>
                   
                    <div class="card">
                        <div id="" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseOne5" aria-expanded="false" aria-controls="collapseFour" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">COSMETOLOGIST</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseOne5" class="collapse">
                            <div class="card-body">
                                <!--REPLACE WITH INC FORM -->
                                <?php include('inc/cosmetologist.php'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div id="" class="b-radius-0 card-header">
                            <button type="button" data-toggle="collapse" data-target="#collapseDonation" aria-expanded="false" aria-controls="collapseFour" class="text-left m-0 p-0 btn btn-link btn-block">
                                <h5 class="m-0 p-0">Donation In-Lieu of Flowers</h5>
                            </button>
                        </div>
                        <div data-parent="#accordion" id="collapseDonation" class="collapse">
                            <div class="card-body">
                                <!--REPLACE WITH INC FORM -->
                                <?php include('inc/donation.php'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>      
            </div>
    </div>
</div>
</div>
</div>
<?php include('inc/footer.php'); ?>

