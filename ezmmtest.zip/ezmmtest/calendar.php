<?php 
    session_start();
    if (isset($_SESSION['username'])) {
        include('inc/header.php');
        // require 'database/connectDatabase.php';
        require("calendar/assets/functions/functions.php");
        // CSRF Protection
        require 'calendar/assets/functions/CSRF_Protect.php';
        $csrf = new CSRF_Protect();

        // Error Reporting Active
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
    } else {
        header('Location: login.php');
    }
?>
<style>
    .modal-backdrop.show {
        opacity: 0;
    }
    .modal-backdrop {
        z-index: unset!important;
    }
    .modal.show {
        background: #000000a3;
    }
    .modal-content {
        margin-top: 50%;
    }
    .modal .modal-body img {
        max-width: -webkit-fill-available;
        width: 100%;
    }
</style>

    <!-- Bootstrap Core CSS -->
<link href="calendar/assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
<!-- <link href="calendar/assets/css/styles.css" rel="stylesheet">	 -->
            <div class="page-title-heading">
                <div><h3>CONTRACTOR</h3></div>    
            </div>
        </div>
    </div>     
    <div class="row">
        <div class="col-md-12">
            <div class="main-card mb-3 card">
                <div id="eventcalendar"></div>
                <div class="content-section-a">
                    
                    <!--BEGIN PLUGIN -->
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                        <div class="panel panel-default dash">
                            <h2 class="sub-header">
                                <i class="fa fa-calendar" aria-hidden="true"></i> EZMM Calendar
                            </h2>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <!-- Button trigger New Event modal -->
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#event">
                                        <i class="fa fa-calendar" aria-hidden="true"></i> New Event
                                    </button>
                                    <!-- New Event Creation Modal -->
                                    <div class="modal fade" id="event" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="close"><span aria-hidden="true">&times;</span></button>
                                                    <h4 class="modal-title" id="myModalLabel"> <i class="fa fa-calendar" aria-hidden="true"></i>
                                                        New Event
                                                    </h4>
                                                </div>
                                                <div class="modal-body">
                                                        <!-- New Event Creation Form -->
                                                    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data" class="form-horizontal" name="novoevento">
                                                        <fieldset>
                                                            <!-- CSRF PROTECTION -->
                                                            <?php $csrf->echoInputField(); ?>
                                                            <!-- Text input-->
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label" for="title">Title</label>
                                                                <div class="col-md-6">
                                                                    <select name='title' class="form-control input-md">
                                                                        
                                                                        <?php 
                                                                        
                                                                        $query = mysqli_query($conection, "select * from type ORDER BY id DESC");
                                                                        
                                                                            echo "<option value='No type Selected' required>Select Type</option>";
                                                                            
                                                                        while ($row = mysqli_fetch_assoc($query)) {
                                                                                
                                                                            echo "
                                                                            
                                                                            <option value='".$row['title']."'>".$row['title']."</option>
                                                                            
                                                                            ";
                                                                                                
                                                                            }
                                                                    
                                                                        ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            
                                                            <!-- Text input-->
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label" for="color">Color</label>
                                                                <div class="col-md-4">
                                                                    <div id="cp1" class="input-group colorpicker-component">
                                                                        <input id="cp1" type="text" class="form-control" name="color" value="#5367ce" required/>
                                                                        <span class="input-group-addon"><i></i></span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label" for="start">Start Date</label>
                                                                <div class="input-group date form_date col-md-6" data-date="" data-date-format="yyyy-mm-dd hh:ii" data-link-field="start" data-link-format="yyyy-mm-dd hh:ii">
                                                                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span><input class="form-control" size="16" type="text" value="" readonly>
                                                                </div>
                                                                <input id="start" name="start" type="hidden" value="" required>

                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label" for="end">End Date</label>
                                                                <div class="input-group date form_date col-md-6" data-date="" data-date-format="yyyy-mm-dd hh:ii" data-link-field="end" data-link-format="yyyy-mm-dd hh:ii">
                                                                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span><input class="form-control" size="16" type="text" value="" readonly>
                                                                </div>
                                                                <input id="end" name="end" type="hidden" value="" required>

                                                            </div>
                                                            
                                                            <!-- Image input-->
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label" for="image">Upload Image</label>
                                                                <div class="col-md-9">
                                                                    <input type="file" name="image" id="image">
                                                                </div>
                                                            </div>
                                                            
                                                            <!-- Text input-->
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label" for="url">Link</label>
                                                                <div class="col-md-9">
                                                                    <input id="url" name="url" type="text" class="form-control input-md" required>

                                                                </div>
                                                            </div>

                                                            <!-- Text input-->
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label" for="description">Description</label>
                                                                <div class="col-md-9">
                                                                    <textarea class="form-control" rows="5" name="description" id="description"></textarea>
                                                                </div>
                                                            </div>


                                                            <!-- Button -->
                                                            <div class="form-group">
                                                                <label class="col-md-12 control-label" for="singlebutton"></label>
                                                                <div class="col-md-4">
                                                                    <input type="submit" name="novoevento" class="btn btn-success" value="New Event" />
                                                                </div>
                                                            </div>

                                                        </fieldset>
                                                    </form>  
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-primary" data-dismiss="modal">close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Button trigger New Type modal -->
                                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#type">
                                        <i class="fa fa-globe" aria-hidden="true"></i> New Type
                                    </button>
                                        <!-- New Type Creation Form -->
                                    <div class="modal fade" id="type" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="close"><span aria-hidden="true">&times;</span></button>
                                                    <h4 class="modal-title" id="myModalLabel"> <i class="fa fa-calendar" aria-hidden="true"></i>
                                                        New Type
                                                    </h4>
                                                </div>
                                                <div class="modal-body">                               
                                                    <!-- New Event Creation Form -->
                                                    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data" class="form-horizontal" name="novotipo">
                                                        <fieldset>
                                                            <!-- CSRF PROTECTION -->
                                                            <?php $csrf->echoInputField(); ?>
                                                            <!-- Text input-->
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label" for="title">Title</label>
                                                                <div class="col-md-9">
                                                                    <input id="title" name="title" type="text" class="form-control input-md" required>

                                                                </div>
                                                            </div>
                                                            
                                                            <!-- Button -->
                                                            <div class="form-group">
                                                                <label class="col-md-12 control-label" for="singlebutton"></label>
                                                                <div class="col-md-4">
                                                                    <input type="submit" name="novotipo" class="btn btn-success" value="New Type" />
                                                                </div>
                                                            </div>

                                                        </fieldset>
                                                    </form>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-primary" data-dismiss="modal">close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Button trigger Delete Event modal -->
                                    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#editevent">
                                        <i class="fa fa-edit" aria-hidden="true"></i> Edit Events
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="editevent" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="close"><span aria-hidden="true">&times;</span></button>
                                                    <h4 class="modal-title" id="myModalLabel"> <i class="fa fa-calendar" aria-hidden="true"></i>
                                                        Edit Events
                                                    </h4>
                                                </div>
                                                <div class="modal-body">
                                                    <!-- Modal featuring all events saved on database -->
                                                    <?php echo listAllEventsEdit(); ?>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-primary" data-dismiss="modal">close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Button trigger Delete Event modal -->
                                    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#delevent">
                                        <i class="fa fa-close" aria-hidden="true"></i> Delete Events
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="delevent" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="close"><span aria-hidden="true">&times;</span></button>
                                                    <h4 class="modal-title" id="myModalLabel"> <i class="fa fa-calendar" aria-hidden="true"></i>
                                                        Delete Events
                                                    </h4>
                                                </div>
                                                <div class="modal-body">
                                                    <!-- Modal featuring all events saved on database -->
                                                    <?php echo listAllEventsDelete(); ?>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-primary" data-dismiss="modal">close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deltype">
                                        <i class="fa fa-close" aria-hidden="true"></i> Delete Types
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="deltype" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="close"><span aria-hidden="true">&times;</span></button>
                                                    <h4 class="modal-title" id="myModalLabel3"> <i class="fa fa-calendar" aria-hidden="true"></i>
                                                        Delete Types
                                                    </h4>
                                                </div>
                                                <div class="modal-body">
                                                    <!-- Modal featuring all types saved on database -->
                                                    <?php echo listAllTypes(); ?>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-primary" data-dismiss="modal">close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
                                    <div class="table-responsive">

                                        <div class="col-lg-12">
                                            <div id="events"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php

                        // If user clicked on the new event button
                        if (!empty($_POST['novoevento'])) {
                            
                            // Variables from form
                                    $title = $_POST['title'];
                                    $image = $_FILES['image'];
                                    $description = trim(preg_replace('/\s+/', ' ',nl2br(str_replace( "'", "´", $_POST['description']))));		
                                    $url = antiSQLInjection($_POST['url']);
                                    $start = $_POST['start'];
                                    $end = $_POST['end'];
                                    $color = $_POST['color'];
                                    
                            if (empty($start) || empty($end)) {
                                echo "<script type='text/javascript'>swal('Ooops...!', 'You need to fill in the date options!', 'error');</script>";	
                                echo '<meta http-equiv="refresh" content="1; index.php">'; 
                                return false;
                            }
                                    
                            if (!empty($start) || !empty($end) || !empty($image)) {
                            
                                // If photos has been slected
                                if (!empty($image["name"]) && isset($_FILES['image'])) {
                                
                                    // Max width (px)
                                    $largura = 10000;
                                    // Max high (px)
                                    $altura = 10000;
                                    // Max size (pixels)
                                    $tamanho = 5000000000;
                                
                                    // Verifies if this is an image format
                                    if(!preg_match("/image\/(pjpeg|jpeg|png|gif|bmp)/", $image["type"])){
                                        $error[1] = "Sorry but this is not an image.";
                                    } 
                                
                                    // Select image size
                                    $dimensoes = getimagesize($image["tmp_name"]);
                                
                                    // check if the width size is allowed
                                    if($dimensoes[0] > $largura) {
                                        $error[2] = "Image width should be max ".$largura." pixels";
                                    }
                                
                                    // check if the height size is allowed
                                    if($dimensoes[1] > $altura) {
                                        $error[3] = "Image height should be max ".$altura." pixels";
                                    }
                                
                                    // check if the total size is allowed
                                    if($image["size"] > $tamanho) {
                                        $error[4] = "Image Should have max ".$tamanho." bytes";
                                    }
                                    
                                        // Get image extension
                                        preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $image["name"], $ext);
                                
                                        // Creates unique name (md5)
                                        $nome_imagem = md5(uniqid(time())) . "." . $ext[1];
                                
                                        // Path for uploading the image
                                        $caminho_imagem = "calendar/assets/uploads/" . $nome_imagem;
                                
                                        // upload the image to the folder
                                        move_uploaded_file($image["tmp_name"], $caminho_imagem);

                                        // Saves informationon the database
                                        $sql = mysqli_query($conection, "INSERT INTO events VALUES ('', '".$title."', '".$nome_imagem."','".str_replace( "'", "´", $description)."','".$start."','".$end."','".$url."', '".$color."')");

                                        // If information is correctly saved		
                                        if (!$sql) {
                                        echo ("Can't insert into database: " . mysqli_error());
                                        return false;
                                        } else {
                                                echo "<script type='text/javascript'>swal('Good job!', 'New Event Created!', 'success');</script>";
                                                echo '<meta http-equiv="refresh" content="1; index.php">'; 
                                                die();
                                        }		
                                        return true;
                                    
                                    // Displays any error on database saving
                                    if (count($error) != 0) {
                                        foreach ($error as $erro) {
                                            echo $erro . "<br />";
                                        }
                                    }
                                }
                            } if (empty($image["name"])) {
                                // Saves informationon the database
                                    $sql = mysqli_query($conection, "INSERT INTO events VALUES ('', '".$title."', '','".str_replace( "'", "´", $description)."','".$start."','".$end."','".$url."', '".$color."')");

                                    // If information is correctly saved		
                                    if (!$sql) {
                                    echo ("Can't insert into database: " . mysqli_error());
                                    return false;
                                    } else {
                                            echo "<script type='text/javascript'>swal('Good job!', 'New Event Created!', 'success');</script>";
                                            echo '<meta http-equiv="refresh" content="1; index.php">'; 
                                            die();
                                    }		
                                    return true;
                            }

                        }


                        // If user clicked on the new event button
                        if (!empty($_POST['novotipo'])) {
                            
                            // Variables from form
                            $title = $_POST['title'];
                            
                            // Saves informationon the database
                            $sql = mysqli_query($conection, "INSERT INTO type VALUES ('', '".$title."')");
                    
                            // If information is correctly saved			
                            if (!$sql) {
                            echo ("Can't insert into database: " . mysqli_error());
                            return false;
                            } else {
                                    echo "<script type='text/javascript'>swal('Good job!', 'New Type Created!', 'success');</script>";
                                    echo '<meta http-equiv="refresh" content="1; index.php">'; 
                                    die();
                            }		
                            return true;
                        }

                    ?>
                    <!-- Modal with events description -->
                    <?php echo modalEvents(); ?>
                        </div>

                    </div>
                    <!-- /.container -->

                </div>
            </div>
        </div>
    </div>
</div>
<?php include('inc/footer.php'); ?>

<!-- Bootstrap Core JavaScript -->
<script src="calendar/assets/js/bootstrap.min.js"></script>
	<!-- DataTables JavaScript -->
	<script src="calendar/assets/js/jquery.dataTables.js"></script>
	<script src="calendar/assets/js/dataTables.bootstrap.js"></script>
	<!-- Listings JavaScript delete options-->
	<script src="calendar/assets/js/listings.js"></script>
	<!-- Metis Menu Plugin JavaScript -->
	<script src="calendar/assets/js/metisMenu.min.js"></script>
	<!-- Moment JavaScript -->
	<script src="calendar/assets/js/moment.min.js"></script>
	<!-- FullCalendar JavaScript -->
	<script src="calendar/assets/js/fullcalendar.js"></script>
	<!-- FullCalendar Language JavaScript Selector -->
	<script src='calendar/assets/lang/en-gb.js'></script>
	<!-- DateTimePicker JavaScript -->
	<script type="text/javascript" src="calendar/assets/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
	<!-- Datetime picker initialization -->
	<script type="text/javascript">
		$('.form_date').datetimepicker({
			language:  'en',
			weekStart: 1,
			todayBtn:  0,
			autoclose: 1,
			todayHighlight: 1,
			startView: 2,
			forceParse: 0
		});
	</script>	
	<!-- ColorPicker JavaScript -->
	<script src="calendar/assets/js/bootstrap-colorpicker.js"></script>
	<!-- Plugin Script Initialization for DataTables -->
	<script>
		$(document).ready(function() {
			$('.dataTables-example').dataTable();
		});
	</script>
	<!-- ColorPicker Initialization -->
	<script>
		$(function() {
			$('#cp1').colorpicker();
		});
	
	</script>
	<!-- JS array created from database -->
	<?php echo listEvents(); ?>
