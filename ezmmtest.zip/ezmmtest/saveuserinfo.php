<?php
/** This file is used to manage users & cases according to submit button's value*/ 
session_start();
require 'database/connectDatabase.php';

if( isset($_SESSION['username'])){
    
    if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_updateuser' ){ // Control new staff with its role etc by Superadmin
        
        $SUPER_useradmincheck = (isset($_POST['SUPER_useradmincheck']) ) ? 'adminstaff': 'staff';
        switch ($SUPER_useradmincheck) {
            case 'adminstaff':
                $sql = "UPDATE users SET role='".$SUPER_useradmincheck."',cancreate='Y',canread='Y',canupdate='Y',candelete='Y', funstatus='".$_POST['SUPER_funstatus']."', plan='".$_POST['SUPER_plan']."', StateLicensed='".$_POST['SUPER_statelicensed']."' WHERE id='".$_POST['SUPER_funid']."'";           
                break;
            case 'staff':
                $sql = "UPDATE users SET role='".$SUPER_useradmincheck."',cancreate='N',canread='Y',canupdate='N',candelete='N', funstatus='".$_POST['SUPER_funstatus']."', plan='".$_POST['SUPER_plan']."', StateLicensed='".$_POST['SUPER_statelicensed']."' WHERE id='".$_POST['SUPER_funid']."'";           
                break;
            default:
                break;
        }
        
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'updated');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_deluser' ){ // Delete selected staff
        $sql = "DELETE FROM users WHERE id='".$_POST['SUPER_funid']."'"; 
        
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'deleted');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'subm_delcase' ){ // Delete selected case and its information
        $sql = "DELETE FROM ".$_POST['caseinfo_table']." WHERE caseID='".$_POST['DASH_caseid']."'"; 
        
        if ($conn->query($sql) === TRUE) {
            $sql = "DELETE FROM cases WHERE id='".$_POST['DASH_caseid']."'";
            if ($conn->query($sql) === TRUE) {
                $response = array('status' => 'deleted');
                echo json_encode($response); return;
            } else {
                $response = array('status' => 'error');
                echo json_encode($response); return;
            } 
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else{ // set caseID and let a user redirect to corresponding status section
        $_SESSION['selectedcaseID'] = $_POST['DASH_caseid'];
        $response = array('status' => 'setcaseid', 'caseid'=>$_SESSION['selectedcaseID'], 'casestatus'=>$_POST['postaction']);
        echo json_encode($response); return;
    }
}
else{ 
    $response = array('status' => 'sessionexpired');
    echo json_encode($response); return;
}
?>