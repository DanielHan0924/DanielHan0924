<?php 
session_start();
require 'database/connectDatabase.php';

if( isset($_SESSION['username'])){
    $permanent = isset($_POST['TODO_isperm'])? 'Y': 'N';
    $completed = isset($_POST['TODO_completed'])? 'Y':'N';
    
    if(isset($_POST['postaction']) && $_POST['postaction'] == 'sbm_addtask'){ // save new one
        //insert new item to statement and new Reason to Reason table
        $sql = "INSERT INTO ".$_POST['TODO_table']." (caseID, staffID, cDate, rDate, description, isPerm, completed) VALUES ('".$_POST['caseId']."','".$_SESSION['userid']."','".$_POST['TODO_cdate']."','".$_POST['TODO_rdate']."','".$_POST['TODO_description']."','".$permanent."','".$completed."')";
    
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'created');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
        
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'sbm_edittask'){ // update recent one
        $TODO_isperm = (isset($_POST['TODO_isperm']) ) ? 'Y': 'N';
        $TODO_completed = (isset($_POST['TODO_completed']) ) ?'Y': 'N';
        $sql = "UPDATE ".$_POST['TODO_table']." SET cDate='".$_POST['TODO_cdate']."', rDate='".$_POST['TODO_rdate']."', description='".$_POST['TODO_description']."' ,isPerm='".$TODO_isperm."', completed='".$TODO_completed."' WHERE id='".$_POST['TODO_id']."'";

        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'updated');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'sbm_completetask_N'){ // complete clicked task
        $sql = "UPDATE ".$_POST['TODO_table']." SET completed='Y' WHERE id='".$_POST['TODO_id']."'";

        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'completed');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }else if(isset($_POST['postaction']) && $_POST['postaction'] == 'setcaseID'){ // save clicked caseID
        $_SESSION['selectedcaseID'] = $_POST['selectedcaseID'];

        $response = array('status' => 'setcaseid', 'caseid'=>$_SESSION['selectedcaseID']);
        echo json_encode($response); return;
    }else { //delete recent one
        $sql = "DELETE FROM ".$_POST['TODO_table']." WHERE id='".$_POST['TODO_id']."'";
        if ($conn->query($sql) === TRUE) {
            $response = array('status' => 'deleted');
            echo json_encode($response); return;
        } else {
            $response = array('status' => 'error');
            echo json_encode($response); return;
        }
    }
} else{ 
    $response = array('status' => 'failed');
    echo json_encode($response); return;
}
?>