<?php 
session_start();
require 'database/connectDatabase.php';
if( isset($_SESSION['userid']) && isset($_POST['recurrings_table'])){
    $sql = "SELECT * FROM ".$_POST['recurrings_table']." WHERE caseID='".$_POST['optionID']."';";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $id_array = array();
        while($row = mysqli_fetch_assoc($result)) {
            array_push($id_array, $row);
        }
        $response = array('status' => 'selected', 'numrow'=> mysqli_num_rows($result), 'data' => $id_array, 'signinRole' => $_SESSION['userrole']);
        echo json_encode($response); return;
    } else {
        $response = array('status' => 'error');
        echo json_encode($response); return;
    }  
}
else{ 
    $response = array('status' => 'failed');
    echo json_encode($response); return;
}
?>