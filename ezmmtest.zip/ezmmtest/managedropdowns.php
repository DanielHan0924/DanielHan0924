<?php
 session_start();
 if (isset($_SESSION['username'])) {
     include('inc/header.php');
     require 'database/connectDatabase.php';
     require 'database/managedropdown.php';
    //  $conn->close();
 } else {
     header('Location: login.php');
 }
?>
<div class="page-title-heading">
            <div><h3>MANAGE DROPDOWNS</h3></div>    
        </div>
    </div>
</div>    
<div class="row">
    <div class="col-md-12">
        <div class="accordion-wrapper mb-3 custom-accordian" id="accordionExample">
            <div class="card">
                <div class="card-header" id="headingOne">   
                    <h2 class="mb-0">
                        <button type="button" class="btn btn-link" data-toggle="collapse" data-target="#collapseOne">MANAGE DROPDOWNS</button>									
                    </h2>
                </div>
                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                    <div class="card-body">
                        <div class="card">
                            <div class="card-header" id="headingTwo">
                                <h2 class="mb-0">
                                    <button class="text-left m-0 p-0 btn btn-link btn-block" type="button" data-toggle="collapse" data-target="#collapseTwo">HONORIFIC</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform" class="switchsubform" id="switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" id="btn_addsubform">&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" id="btn_editsubform">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Honorific</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_honorific">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    
                                    <?php if ($resultCount > 0) {?>
                                    <div class="row editsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Honorific</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_honorific">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_honorific = mysqli_fetch_assoc($result_dropdownhonorific)) { ?>
                                                    <option value="<?php echo ($dropdown_honorific['name']); ?>"><?php echo ($dropdown_honorific['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    
                                    <?php } ?>
                                    </form>

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_honorific";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_honorific">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading4">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block"  data-toggle="collapse" data-target="#collapse4">SUFFIX</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse4" class="collapse" aria-labelledby="heading4" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform" id="switchsubform_4">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" id="btn_addsubform_4">&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" id="btn_editsubform_4">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Suffix</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_suffix">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_suffix > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Suffix</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_suffix">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_suffix = mysqli_fetch_assoc($result_dropdownsuffix)) { ?>
                                                    <option value="<?php echo ($dropdown_suffix['name']); ?>"><?php echo ($dropdown_suffix['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_suffix";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_suffix">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>                                    

                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading5">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse5">LAST NAME</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse5" class="collapse" aria-labelledby="heading5" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Last Name</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_lastname">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_lastname > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Last Name</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_lastname">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_lastname = mysqli_fetch_assoc($result_dropdownlastname)) { ?>
                                                    <option value="<?php echo ($dropdown_lastname['name']); ?>"><?php echo ($dropdown_lastname['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_lastname";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_lastname">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading6">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse6">CITY</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse6" class="collapse" aria-labelledby="heading6" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">City</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_city">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_city > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">City</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_city">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_city = mysqli_fetch_assoc($result_dropdowncity)) { ?>
                                                    <option value="<?php echo ($dropdown_city['name']); ?>"><?php echo ($dropdown_city['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_city";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_city">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading88">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse88">State</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse88" class="collapse" aria-labelledby="heading88" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">State</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_state">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_state > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">State</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_state">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_state = mysqli_fetch_assoc($result_dropdownstate)) { ?>
                                                    <option value="<?php echo ($dropdown_state['name']); ?>"><?php echo ($dropdown_state['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_state";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_state">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading888">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse888">Zip</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse888" class="collapse" aria-labelledby="heading888" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Zip</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_zip">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_zip > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Zip</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_zip">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_zip = mysqli_fetch_assoc($result_dropdownzip)) { ?>
                                                    <option value="<?php echo ($dropdown_zip['name']); ?>"><?php echo ($dropdown_zip['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_zip";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_zip">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading7">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse7">TOWNSHIP</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse7" class="collapse" aria-labelledby="heading7" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Township</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_township">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_township > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Township</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_township">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_township = mysqli_fetch_assoc($result_dropdowntownship)) { ?>
                                                    <option value="<?php echo ($dropdown_township['name']); ?>"><?php echo ($dropdown_township['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                       
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_township";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_township">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading8">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse8">COUNTY</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse8" class="collapse" aria-labelledby="heading8" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">County</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_county">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_county > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">County</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_county">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_county = mysqli_fetch_assoc($result_dropdowncounty)) { ?>
                                                    <option value="<?php echo ($dropdown_county['name']); ?>"><?php echo ($dropdown_county['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_county";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_county">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading9">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse9">MILITARY BRANCH</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse9" class="collapse" aria-labelledby="heading9" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Military Branch</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_militarybranch">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_militarybranch > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Military Branch</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_militarybranch">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_militarybranch = mysqli_fetch_assoc($result_dropdownmilitarybranch)) { ?>
                                                    <option value="<?php echo ($dropdown_militarybranch['name']); ?>"><?php echo ($dropdown_militarybranch['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                    
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_militarybranch";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_militarybranch">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="headingMSH">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapseMSH">MILITARY SERVICE HONORS</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapseMSH" class="collapse" aria-labelledby="headingMSH" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Military Service Honor</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_militaryservicehonors">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_militaryservicehonors > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Military Service Honor</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_militaryservicehonors">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_militarybranch = mysqli_fetch_assoc($result_dropdownmilitaryservicehonors)) { ?>
                                                    <option value="<?php echo ($dropdown_militarybranch['name']); ?>"><?php echo ($dropdown_militarybranch['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                    
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_militaryservicehonors";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_militaryservicehonors">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading10">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse10">WAR / CAMPAIGN</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse10" class="collapse" aria-labelledby="heading10" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">War / Campaign</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_warcampaign">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_warcampaign > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">War / Campaign</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_warcampaign">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_warcampaign = mysqli_fetch_assoc($result_dropdownwarcampaign)) { ?>
                                                    <option value="<?php echo ($dropdown_warcampaign['name']); ?>"><?php echo ($dropdown_warcampaign['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                       
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                    
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_warcampaign";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_warcampaign">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading11">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse11">TYPE OF DISCHARGE</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse11" class="collapse" aria-labelledby="heading11" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Type of Discharge</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_typeofdischarge">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_typeofdischarge > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Type of Discharge</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_typeofdischarge">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_typeofdischarge = mysqli_fetch_assoc($result_dropdowntypeofdischarge)) { ?>
                                                    <option value="<?php echo ($dropdown_typeofdischarge['name']); ?>"><?php echo ($dropdown_typeofdischarge['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                       
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_typeofdischarge";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_typeofdischarge">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading12">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse12">RANK</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse12" class="collapse" aria-labelledby="heading12" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Rank</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_rank">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_rank > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Rank</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_rank">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_rank = mysqli_fetch_assoc($result_dropdownrank)) { ?>
                                                    <option value="<?php echo ($dropdown_rank['name']); ?>"><?php echo ($dropdown_rank['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                       
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_rank";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_rank">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading13">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse13">HIGH SCHOOL</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse13" class="collapse" aria-labelledby="heading13" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">High School</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_highschool">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_highschool > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">High School</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_highschool">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_highschool = mysqli_fetch_assoc($result_dropdownhighschool)) { ?>
                                                    <option value="<?php echo ($dropdown_highschool['name']); ?>"><?php echo ($dropdown_highschool['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                      
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_highschool";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_highschool">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="headingUndergraduateName">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapseUndergraduateName">Undergraduate Name</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapseUndergraduateName" class="collapse" aria-labelledby="headingUndergraduateName" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Undergraduate Name</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_undergraduatename">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_undergraduatename > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Undergraduate Name</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_undergraduatename">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_highschool = mysqli_fetch_assoc($result_dropdownundergraduatename)) { ?>
                                                    <option value="<?php echo ($dropdown_highschool['name']); ?>"><?php echo ($dropdown_highschool['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                      
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                    
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_undergraduatename";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_undergraduatename">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="headinggraduatename">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapsegraduatename">Graduate Name</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapsegraduatename" class="collapse" aria-labelledby="headinggraduatename" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Graduate Name</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_graduatename">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_graduatename > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Graduate Name</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_graduatename">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_highschool = mysqli_fetch_assoc($result_dropdowngraduatename)) { ?>
                                                    <option value="<?php echo ($dropdown_highschool['name']); ?>"><?php echo ($dropdown_highschool['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                      
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_graduatename";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_graduatename">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading14">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse14">COLLEGE</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse14" class="collapse" aria-labelledby="heading14" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">College</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_college">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_college > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">College</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_college">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_college = mysqli_fetch_assoc($result_dropdowncollege)) { ?>
                                                    <option value="<?php echo ($dropdown_college['name']); ?>"><?php echo ($dropdown_college['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_college";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_college">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading15">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse15">CEMETERY</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse15" class="collapse" aria-labelledby="heading15" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Cemetery</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_cemetery">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_cemetery > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Cemetery</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_cemetery">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_cemetery = mysqli_fetch_assoc($result_dropdowncemetery)) { ?>
                                                    <option value="<?php echo ($dropdown_cemetery['name']); ?>"><?php echo ($dropdown_cemetery['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_cemetery";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_cemetery">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading16">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse16">FUNERAL / MEMORIAL</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse16" class="collapse" aria-labelledby="heading16" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Funeral / MEMORIAL</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_funeralmemorial">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_funeralmemorial > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Funeral / MEMORIAL</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_funeralmemorial">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_funeralmemorial = mysqli_fetch_assoc($result_dropdownfuneralmemorial)) { ?>
                                                    <option value="<?php echo ($dropdown_funeralmemorial['name']); ?>"><?php echo ($dropdown_funeralmemorial['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_funeralmemorial";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_funeralmemorial">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading17">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse17">RELATIONSHIP</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse17" class="collapse" aria-labelledby="heading17" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Relationship</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_relationship">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_relationship > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Relationship</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_relationship">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_relationship = mysqli_fetch_assoc($result_dropdownrelationship)) { ?>
                                                    <option value="<?php echo ($dropdown_relationship['name']); ?>"><?php echo ($dropdown_relationship['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                       
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                    
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_relationship";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_relationship">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading18">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse18">RACE</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse18" class="collapse" aria-labelledby="heading18" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Race</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_race">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_race > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Race</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_race">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_race = mysqli_fetch_assoc($result_dropdownrace)) { ?>
                                                    <option value="<?php echo ($dropdown_race['name']); ?>"><?php echo ($dropdown_race['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_race";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_race">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading19">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse19">RELIGION</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse19" class="collapse" aria-labelledby="heading19" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Religion</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_religion">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_religion > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Religion</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_religion">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_religion = mysqli_fetch_assoc($result_dropdownreligion)) { ?>
                                                    <option value="<?php echo ($dropdown_religion['name']); ?>"><?php echo ($dropdown_religion['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                       
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_religion";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_religion">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading20">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse20">CITIZENSHIP</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse20" class="collapse" aria-labelledby="heading20" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Citizenship</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_citizenship">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_citizenship > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Citizenship</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_citizenship">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_citizenship = mysqli_fetch_assoc($result_dropdowncitizenship)) { ?>
                                                    <option value="<?php echo ($dropdown_citizenship['name']); ?>"><?php echo ($dropdown_citizenship['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 

                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_citizenship";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_citizenship">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading21">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse21">ANCESTRY</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse21" class="collapse" aria-labelledby="heading21" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">ANCESTRY</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_ancestry">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_ancestry > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">ANCESTRY</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_ancestry">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="" id="jgj">
                                                <?php while($dropdown_ancestry = mysqli_fetch_assoc($result_dropdownancestry)) { ?>
                                                    <option value="<?php echo ($dropdown_ancestry['name']); ?>"><?php echo ($dropdown_ancestry['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                    
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_ancestry";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_ancestry">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading22">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse22">OCCUPATION</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse22" class="collapse" aria-labelledby="heading22" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">OCCUPATION</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_occupation">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_occupation > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">OCCUPATION</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_occupation">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_occupation = mysqli_fetch_assoc($result_dropdownoccupation)) { ?>
                                                    <option value="<?php echo ($dropdown_occupation['name']); ?>"><?php echo ($dropdown_occupation['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                    
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_occupation";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_occupation">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading23">
                                <h2 class="mb-0">
                                    <button type="button" class="text-left m-0 p-0 btn btn-link btn-block" data-toggle="collapse" data-target="#collapse23">Reason For</button>
                                </h2>
                            </div>
                            <!-- <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#collapseOne">   -->
                            <div id="collapse23" class="collapse" aria-labelledby="heading23" data-parent="#collapseOne">  
                                <div class="card-body">
                                    <div class="row switchsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                        <div class="col-md-4 col-lg-4 col-sm-4">
                                            <button type="button" class="btn btn-success btn-switchsubform-add" >&nbsp;&nbsp;Add&nbsp;&nbsp;</button>
                                            <button type="button" class="btn btn-info btn-switchsubform-edit" >&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        <button type="button" class="btn btn-danger btn-switchsubform-delete" >&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-4 col-lg-4 col-sm-4"></div>
                                    </div> 
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <div class="row addsubform">
                                        <div class="col-md-4 col-lg-4 col-sm-4 row">
                                            <label class=" col-md-6 mt-1 text-center">Reason For</label>
                                            <input type="text" class="form-control col-md-6 " name="MD_dropdown_add" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_reasonfor">
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Create&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back ">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    </form>
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php if ($resultCount_reasonfor > 0) {?>
                                    <div class="row editsubform" >
                                        <div class="col-md-4 col-sm-4 col-lg-4 row">
                                            <label class="col-md-6 mt-1 text-center">Reason For</label>
                                            <input type="text" class="form-control col-md-6" name="MD_dropdown_edit" required>
                                            <input type="hidden" name="MD_dropdown_table" value="dropdown_reasonfor">
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <select class="form-control" name="MD_dropdown_org" value="">
                                                <?php while($dropdown_occupation = mysqli_fetch_assoc($result_dropdownreasonfor)) { ?>
                                                    <option value="<?php echo ($dropdown_occupation['name']); ?>"><?php echo ($dropdown_occupation['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-success btn_managedropdowns">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                        </div>
                                        
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row editsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option to edit.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form>
                                    
                                    <form class="form_managedropdowns" action="saveDropdownHonorific.php" method="POST" enctype="multipart/form-data">
                                    <?php
                                        $sql = "SELECT * FROM dropdown_reasonfor";
                                        $result = $conn->query($sql);
                                    if (mysqli_num_rows($result) > 0) {?>
                                    <div class="row delsubform">
                                        <div class="col-md-4 col-sm-4 col-lg-4">
                                            <div class="form-group">    
                                                <input type="hidden" name="MD_dropdown_table" value="dropdown_reasonfor">
                                                <select class="form-control" name="MD_dropdown_del" value="">
                                                <?php while($dropdown_del = mysqli_fetch_assoc($result)) { ?>
                                                    <option value="<?php echo ($dropdown_del['name']); ?>"><?php echo ($dropdown_del['name']); ?></option>
                                                <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                            <button type="submit" class="btn btn-danger btn_managedropdowns">&nbsp;&nbsp;Delete&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div> 
                                    <?php } else{?>
                                    <div class="row delsubform">
                                        <div class="col-md-1 col-lg-1 col-sm-1">
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <p>There is no option.</p>    
                                        </div>
                                        <div class="col-md-2 col-lg-2 col-sm-2">
                                            <button type="button" class="btn btn-link btn-link-back">&nbsp;&nbsp;Back&nbsp;&nbsp;</button>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    </form> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<?php include('inc/footer.php'); ?>
<script>
    
    $(".form_managedropdowns").submit(function(e) {
        e.preventDefault();
        var actionurl = e.currentTarget.action;
        $(this).find(':input[type=submit]').prop('disabled', true);
        var formData = new FormData($(this)[0]);
        $.ajax({
            type: "POST",
            url: actionurl,
            dataType: 'json',
            data: formData,
            processData: false,
            contentType: false,
            enctype: 'multipart/form-data',
            success: function(result) {
                console.log(result);
                if(result.status == 'exist'){
                    alert('There is already same option. Please create others.');
                }else if(result.status == 'created'){
                    alert('Successfully saved !');
                }else if(result.status == 'updated'){
                    alert('Successfully updated !');
                }else if(result.status == 'deleted'){
                    alert('Successfully deleted !');
                }
                // $(".btn_managedropdowns").prop('disabled', false);
                location.reload();
                // var explode = function () {};
                // setTimeout (explode, 1000);
                // $("#collapseTwo").addClass("show");
            },
            error: function(result) {
                alert(result.status);
                console.log(result);
            }
        })
    
    });
</script>    
