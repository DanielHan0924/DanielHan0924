<?php
    include("./landingpage.php");
    exit;
?>