import 'package:flutter/widgets.dart';
import 'package:sports_bettings_picks/src/freeHomePage/homePage.dart';
import 'package:sports_bettings_picks/src/loginPage.dart';
import 'package:sports_bettings_picks/src/welcomePage.dart';
import 'package:sports_bettings_picks/src/signup.dart';
import 'package:sports_bettings_picks/src/googlePage.dart';
import 'package:sports_bettings_picks/src/paymentPage.dart';

final Map<String, WidgetBuilder> routes = <String, WidgetBuilder>{
  // '/': (BuildContext context) => SplashScreen(),
  '/homePage': (BuildContext context) => new HomePage(),
  '/loginPage': (BuildContext context) => new LoginPage(),
  '/welcomePage': (BuildContext context) => new WelcomePage(),
  '/signupPage': (BuildContext context) => new SignUpPage(),
  '/googlePage': (BuildContext context) => new GooglePage(),
  '/paymentPage': (BuildContext context) => new PaymentPage(),
};
