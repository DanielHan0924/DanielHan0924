import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:global_configuration/global_configuration.dart';
import 'package:sports_bettings_picks/routes.dart';

import 'src/welcomePage.dart';

// void main() => runApp(MyApp());
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await GlobalConfiguration().loadFromAsset('app_settings');
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return MaterialApp(
      title: 'Sports Bettings Picks',
      theme: ThemeData(
        // primarySwatch: Colors.blue,
        // textTheme: GoogleFonts.latoTextTheme(textTheme).copyWith(
        //   bodyText1: GoogleFonts.montserrat(textStyle: textTheme.bodyText1),
        // ),
        brightness: Brightness.light,
        primarySwatch: Colors.orange,
      ),
      // themeMode: ThemeMode.dark,
      // darkTheme: ThemeData(
      //   brightness: Brightness.dark,
      //   /* dark theme settings */
      // ),
      // themeMode: ThemeMode.dark,
      // darkTheme: ThemeData.dark(),
      debugShowCheckedModeBanner: true,
      home: WelcomePage(),
      routes: routes,
    );
  }
}
