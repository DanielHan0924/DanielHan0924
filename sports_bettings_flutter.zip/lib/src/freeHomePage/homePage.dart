import 'package:flutter/material.dart';
import 'package:sports_bettings_picks/src/loginPage.dart';
import 'package:sports_bettings_picks/src/signup.dart';
import 'package:sports_bettings_picks/src/homePage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'widget/homeWidget.dart';
import 'widget/helpWidget.dart';
import 'widget/profileWidget.dart';

class HomePage extends StatefulWidget {
  HomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;

    return Scaffold(
      resizeToAvoidBottomPadding: false,
      body: DefaultTabController(
        length: choices.length,
        child: Scaffold(
          // resizeToAvoidBottomPadding: false,
          appBar: AppBar(
            title: const Text('Home'),
          ),
          bottomNavigationBar: BottomAppBar(
            // title: Text('Home Page13'),
            child: TabBar(
              isScrollable: false,
              tabs: choices.map((Choice choice) {
                return Tab(
                  // text: choice.title,
                  icon: Icon(choice.icon),
                );
              }).toList(),
            ),
          ),
          body: TabBarView(
            children: choices.map((Choice choice) {
              return Padding(
                padding: EdgeInsets.all(0.0),
                child: ChoiceCard(choice: choice),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}

class Choice {
  const Choice({this.title, this.icon});
  final String title;
  final IconData icon;
}

const List<Choice> choices = const <Choice>[
  const Choice(title: 'home', icon: Icons.home),
  const Choice(title: 'help', icon: Icons.help),
  const Choice(title: 'profile', icon: Icons.person),
];

class ChoiceCard extends StatelessWidget {
  const ChoiceCard({Key key, this.choice}) : super(key: key);

  final Choice choice;

  @override
  Widget build(BuildContext context) {
    final TextStyle textStyle = Theme.of(context).textTheme.display1;
    switch (this.choice.title) {
      case "home":
        return HomeWidget();
        break;
      case "help":
        return HelpWidget();
        break;
      case "profile":
        return ProfileWidget();
        break;
      default:
    }

    // if (this.choice.title == "home") {
    //   return Container(
    //     color: Colors.white,
    //     child: Center(child: HomeWidget()),
    //   );
    // } else {
    //   return Card(
    //     color: Colors.white,
    //     child: Center(
    //       child: Column(
    //         mainAxisSize: MainAxisSize.min,
    //         crossAxisAlignment: CrossAxisAlignment.center,
    //         children: <Widget>[
    //           Icon(choice.icon, size: 128.0, color: textStyle.color),
    //           Text(choice.title, style: textStyle),
    //         ],
    //       ),
    //     ),
    //   );
    // }
  }
}
