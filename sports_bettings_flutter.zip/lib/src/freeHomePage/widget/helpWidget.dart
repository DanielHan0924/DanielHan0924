import 'package:flutter/material.dart';
import 'package:chewie/chewie.dart';
import 'package:video_player/video_player.dart';

class HelpWidget extends StatefulWidget {
  const HelpWidget({Key key, this.title}) : super(key: key);
  final String title;

  _HelpwidgetState createState() => _HelpwidgetState();
}

class _HelpwidgetState extends State<HelpWidget> {
  TargetPlatform _platform;
  VideoPlayerController _videoPlayerController1;
  VideoPlayerController _videoPlayerController2;
  ChewieController _chewieController;

  @override
  void initState() {
    super.initState();
    _videoPlayerController1 = VideoPlayerController.network(
        'https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4');
    _videoPlayerController2 = VideoPlayerController.network(
        'https://www.sample-videos.com/video123/mp4/480/asdasdas.mp4');
    _chewieController = ChewieController(
      videoPlayerController: _videoPlayerController1,
      aspectRatio: 3 / 2,
      autoPlay: true,
      looping: true,
      // Try playing around with some of these other options:

      // showControls: false,
      // materialProgressColors: ChewieProgressColors(
      //   playedColor: Colors.red,
      //   handleColor: Colors.blue,
      //   backgroundColor: Colors.grey,
      //   bufferedColor: Colors.lightGreen,
      // ),
      // placeholder: Container(
      //   color: Colors.grey,
      // ),
      // autoInitialize: true,
    );
  }

  @override
  void dispose() {
    _videoPlayerController1.dispose();
    _videoPlayerController2.dispose();
    _chewieController.dispose();
    super.dispose();
  }

  void displayBottomSheet(BuildContext context) {
    showModalBottomSheet(
        context: context,
        builder: (ctx) {
          return Container(
            padding: EdgeInsets.only(top: 30, bottom: 10, left: 10, right: 10),
            height: MediaQuery.of(context).size.height,
            child: Container(
              child: helpView(),
            ),
          );
        });
  }

  Widget helpView() {
    // return Padding(
    //   child: Text("ee"),
    // );
    return new Container(
        child: new SingleChildScrollView(
            child: new Column(children: <Widget>[
      _showChild(),
    ])));
  }

  Widget _showChild() {
    return Container(
        child: Column(
      children: <Widget>[
        Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "Step One:",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.blue,
              ),
            )),
        Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "  See the pitching matchup, if the matchup is super lopsided (someone with large ERA versus small ERA, worth really taking a look at.\n  See how opposing teams do against that side hand pitching (left hand pitchers tend to be harder to hit against)",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                color: Colors.grey,
              ),
            )),
        SizedBox(
          height: 10,
        ),
        Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "Step Two:",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.blue,
              ),
            )),
        Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "  See Vegas odds\n  Too lopsided of odds= not worth it unless you parlay with another bet on another super lopsided odds. \n  If not doing a double parlay bet, take the matchups that offer underdogs, with +160 or +(fill in a number here) options. Bet on these after compiling stats/probabilities from step one. \n  Sometimes, its better to wait as money flows in, so that way can see who the clear underdog/ favorite to win is, can affect the odds posted (moneyflow) ",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                color: Colors.grey,
              ),
            )),
        SizedBox(
          height: 10,
        ),
        Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "Step Three:",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.blue,
              ),
            )),
        Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "  Compare team stats (team avg ERA, Batting avg, home runs, etc) \n Record weather being played in, games team has won/lost in similar weather conditions.\n  Record umpire (still learning how to utilize them for predictions) \n  Compare Team win/loss record AND how many games in a row they have won/lost (momentum) \n  Factor in injuries. Last piece of the puzzle that can greatly affect how well or not well a team will do in comparison to past performance during the season.",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                color: Colors.grey,
              ),
            )),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      // title: "widget.title",
      // theme: ThemeData.light().copyWith(
      //   platform: _platform ?? Theme.of(context).platform,
      // ),
      child: Scaffold(
        resizeToAvoidBottomPadding: true,
        // appBar: AppBar(
        //   title: Text("Help"),
        // ),
        body: Column(
          children: <Widget>[
            SizedBox(
              height: MediaQuery.of(context).viewInsets.bottom,
            ),
            Expanded(
              child: Center(
                child: Chewie(
                  controller: _chewieController,
                ),
              ),
            ),
            FlatButton(
              onPressed: () {
                // _chewieController.enterFullScreen();
                displayBottomSheet(context);
              },
              child: Text('How to do Sports Betting'),
              color: Color(0xfff7892b),
            ),
            // Row(
            //   children: <Widget>[
            //     Expanded(
            //       child: FlatButton(
            //         onPressed: () {
            //           setState(() {
            //             _chewieController.dispose();
            //             _videoPlayerController2.pause();
            //             _videoPlayerController2.seekTo(Duration(seconds: 0));
            //             _chewieController = ChewieController(
            //               videoPlayerController: _videoPlayerController1,
            //               aspectRatio: 3 / 2,
            //               autoPlay: true,
            //               looping: true,
            //             );
            //           });
            //         },
            //         child: Padding(
            //           child: Text("Video 1"),
            //           padding: EdgeInsets.symmetric(vertical: 16.0),
            //         ),
            //       ),
            //     ),
            //     Expanded(
            //       child: FlatButton(
            //         onPressed: () {
            //           setState(() {
            //             _chewieController.dispose();
            //             _videoPlayerController1.pause();
            //             _videoPlayerController1.seekTo(Duration(seconds: 0));
            //             _chewieController = ChewieController(
            //               videoPlayerController: _videoPlayerController2,
            //               aspectRatio: 3 / 2,
            //               autoPlay: true,
            //               looping: true,
            //             );
            //           });
            //         },
            //         child: Padding(
            //           padding: EdgeInsets.symmetric(vertical: 16.0),
            //           child: Text("Error Video"),
            //         ),
            //       ),
            //     )
            //   ],
            // ),
            // Row(
            //   children: <Widget>[
            //     Expanded(
            //       child: FlatButton(
            //         onPressed: () {
            //           setState(() {
            //             _platform = TargetPlatform.android;
            //           });
            //         },
            //         child: Padding(
            //           child: Text("Android controls"),
            //           padding: EdgeInsets.symmetric(vertical: 16.0),
            //         ),
            //       ),
            //     ),
            //     Expanded(
            //       child: FlatButton(
            //         onPressed: () {
            //           setState(() {
            //             _platform = TargetPlatform.iOS;
            //           });
            //         },
            //         child: Padding(
            //           padding: EdgeInsets.symmetric(vertical: 16.0),
            //           child: Text("iOS controls"),
            //         ),
            //       ),
            //     )
            //   ],
            // )
            SizedBox(
              height: 50,
            ),
          ],
        ),
      ),
    );
  }
}
