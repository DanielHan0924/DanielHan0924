import 'package:flutter/material.dart';
import 'package:global_configuration/global_configuration.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileWidget extends StatelessWidget {
  _logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool("isLogin", false);
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      resizeToAvoidBottomPadding: false,
      body: SingleChildScrollView(
        child: Container(
          height: height,
          child: Center(
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 20,
                ),
                Expanded(flex: 1, child: _avatarShow()),
                SizedBox(
                  height: 20,
                ),
                Expanded(
                  flex: 2,
                  child: _favorShow(context),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _avatarShow() {
    return Stack(
      alignment: const Alignment(0.5, 0.5),
      children: [
        CircleAvatar(
          backgroundImage: AssetImage('assets/images/avatar.png'),
          radius: 70,
        ),
        // Container(
        //     decoration: BoxDecoration(
        //         // color: Colors.black45,
        //         ),
        //     child: Icon(
        //       Icons.edit,
        //       size: 30,
        //     )),
      ],
    );
  }

  Widget _favorShow(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(10)),
          boxShadow: <BoxShadow>[
            BoxShadow(
                color: Colors.grey.shade200,
                offset: Offset(2, 4),
                blurRadius: 5,
                spreadRadius: 12)
          ]),
      padding: EdgeInsets.all(10),
      child: Column(
        children: <Widget>[
          SizedBox(
            height: 10,
          ),
          _inputField("Favor Teams"),
          SizedBox(
            height: 10,
          ),
          _inputField("Favor Players"),
          SizedBox(
            height: 30,
          ),
          FlatButton(
            onPressed: () {
              Navigator.of(context).pushReplacementNamed("/paymentPage");
            },
            child: Text('Subscribe'),
            color: Color(0xfff7892b),
          ),
          SizedBox(
            height: 30,
          ),
          FlatButton(
            onPressed: () {
              _logout();
              Navigator.pop(context);
            },
            child: Text('Sign Out'),
            color: Color(0xfff7892b),
          ),
        ],
      ),
    );
  }

  Widget _inputField(String level) {
    return Column(
      children: <Widget>[
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            level,
            style: TextStyle(
                fontSize: 15,
                color: Color(0xffe46b10),
                fontWeight: FontWeight.bold),
          ),
        ),
        SizedBox(
          height: 5,
        ),
        TextField(
            obscureText: false,
            decoration: InputDecoration(
                border: InputBorder.none,
                fillColor: Color(0xfff3f3f4),
                filled: true)),
      ],
    );
  }
}
