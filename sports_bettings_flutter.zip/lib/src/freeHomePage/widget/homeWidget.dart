import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:global_configuration/global_configuration.dart';
import 'dart:async';

class HomeWidget extends StatefulWidget {
  final String serverIP;

  const HomeWidget({Key key, this.serverIP}) : super(key: key);

  @override
  _HomeWidgetState createState() => _HomeWidgetState();
}

class _HomeWidgetState extends State<HomeWidget> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;

    return Container(
      height: height,
      child: DefaultTabController(
        length: choices.length,
        child: Scaffold(
          // resizeToAvoidBottomPadding: false,
          appBar: TabBar(
            isScrollable: false,
            tabs: choices.map((Choice choice) {
              return Tab(
                text: choice.title,
                // icon: Icon(choice.icon),
              );
            }).toList(),
          ),
          body: TabBarView(
            children: choices.map((Choice choice) {
              return Padding(
                padding: EdgeInsets.all(0.0),
                child: ChoiceCard(choice: choice),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}

class Choice {
  const Choice({this.title, this.icon});
  final String title;
  final IconData icon;
}

const List<Choice> choices = const <Choice>[
  const Choice(title: 'NFL', icon: Icons.directions_car),
  const Choice(title: 'NBA', icon: Icons.directions_bike),
  const Choice(title: 'MLB', icon: Icons.directions_boat),
  const Choice(title: 'UFC', icon: Icons.directions_bus),
];

class ChoiceCard extends StatefulWidget {
  final Choice choice;
  const ChoiceCard({Key key, this.choice}) : super(key: key);
  @override
  _ChoiceCardState createState() => _ChoiceCardState();
}

class _ChoiceCardState extends State<ChoiceCard> {
  List<Odd> odds = [];
  int length = 0;

  @override
  void initState() {
    super.initState();

    String sort = widget.choice.title.toLowerCase();
    _loadData(sort);
  }

  Future<void> _loadData(String sort) async {
    List<Odd> oddss = [];
    final String baseUrl = '${GlobalConfiguration().getString('api_base_url')}';
    final String url = baseUrl + 'getodds/' + sort;

    final client = new http.Client();
    final response = await client.get(url);
    if (response.statusCode == 200) {
      var res = json.decode(response.body)['data'];
      if (res == null || res == "") {
        if (mounted) {
          setState(() {
            odds = [];
            length = 0;
          });
        }
        return;
      }
      for (var item in res) {
        oddss.add(Odd(
            t1: item["team1"],
            t2: item["team2"],
            m1: item["money1"],
            m2: item["money2"],
            time: item["date"]));
      }
      if (mounted) {
        setState(() {
          odds = oddss;
          length = oddss.length;
        });
      }
    } else {
      if (mounted) {
        setState(() {
          odds = [];
          length = 0;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (length < 1) {
      return Center(
        child: Text("No Match!"),
      );
    } else
      return ListView.builder(
        physics: new BouncingScrollPhysics(),
        itemCount: length,
        itemBuilder: (context, position) {
          return Card(
            child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: oddItem(odds[position])),
          );
        },
      );
    // return Card(
    //   color: Colors.white,
    //   child: Center(
    //     child: Column(
    //       mainAxisSize: MainAxisSize.min,
    //       crossAxisAlignment: CrossAxisAlignment.center,
    //       children: <Widget>[
    //         Icon(choice.icon, size: 128.0, color: textStyle.color),
    //         Text(choice.title, style: textStyle),
    //       ],
    //     ),
    //   ),
    // );
  }

  Widget oddItem(Odd odd) {
    return Container(
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 7,
            child: Container(
              decoration: BoxDecoration(
                // color: Color(0xff1959a9),
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(5),
                    topLeft: Radius.circular(5)),
              ),
              alignment: Alignment.centerLeft,
              child: Column(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(odd.t1,
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 18,
                                fontWeight: FontWeight.w400)),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(odd.t2,
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 18,
                                fontWeight: FontWeight.w400)),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(odd.time,
                        style: TextStyle(
                            color: Colors.grey[800],
                            fontSize: 15,
                            fontWeight: FontWeight.w400)),
                  ),
                ],
              ),
              // Text('f',
              //     style: TextStyle(
              //         color: Colors.white,
              //         fontSize: 25,
              //         fontWeight: FontWeight.w400)),
            ),
          ),
          Expanded(
              flex: 2,
              child: InkWell(
                onTap: () {},
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xfffbb448),
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                          color: Colors.grey.shade500,
                          offset: Offset(2, 4),
                          blurRadius: 5,
                          spreadRadius: 2)
                    ],
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(5),
                        bottomLeft: Radius.circular(5),
                        topRight: Radius.circular(5),
                        topLeft: Radius.circular(5)),
                  ),
                  alignment: Alignment.center,
                  padding: EdgeInsets.only(top: 10, bottom: 10),
                  child: Column(
                    children: <Widget>[
                      oddNumberShow(odd.m1),
                      SizedBox(
                        height: 5,
                      ),
                      oddNumberShow(odd.m2),
                    ],
                  ),
                ),
              )),
        ],
      ),
    );
  }

  Widget oddNumberShow(String str) {
    int number = int.parse(str);
    var dd = TextStyle(
        fontWeight: FontWeight.w700, // light
        color: Colors.blue // italic
        );
    if (number > 0) {
      dd = TextStyle(
          fontWeight: FontWeight.w700, // light
          color: Colors.red // italic
          );
    }

    return Text(str, style: dd);
  }
}

class Odd {
  const Odd({this.t1, this.t2, this.m1, this.m2, this.time});
  final String t1;
  final String t2;
  final String m1;
  final String m2;
  final String time;
}

// const List<Odd> odds = const <Odd>[
//   const Odd(
//       t1: "Atlana Falcons",
//       t2: "Minnesota Vikings",
//       m1: "+162",
//       m2: "-194",
//       time: "10/18/2020 1:00PM"),
//   const Odd(
//       t1: "Atlana Falcons",
//       t2: "Minnesota Vikings",
//       m1: "+162",
//       m2: "-194",
//       time: "10/18/2020 1:00PM"),
//   const Odd(
//       t1: "Atlana Falcons",
//       t2: "Minnesota Vikings",
//       m1: "+162",
//       m2: "-194",
//       time: "10/18/2020 1:00PM"),
//   const Odd(
//       t1: "Atlana Falcons",
//       t2: "Minnesota Vikings",
//       m1: "+162",
//       m2: "-194",
//       time: "10/18/2020 1:00PM"),
//   const Odd(
//       t1: "Atlana Falcons",
//       t2: "Minnesota Vikings",
//       m1: "+162",
//       m2: "-194",
//       time: "10/18/2020 1:00PM"),
//   const Odd(
//       t1: "Atlana Falcons",
//       t2: "Minnesota Vikings",
//       m1: "+162",
//       m2: "-194",
//       time: "10/18/2020 1:00PM"),
//   const Odd(
//       t1: "Atlana Falcons",
//       t2: "Minnesota Vikings",
//       m1: "+162",
//       m2: "-194",
//       time: "10/18/2020 1:00PM"),
//   const Odd(
//       t1: "Atlana Falcons",
//       t2: "Minnesota Vikings",
//       m1: "+162",
//       m2: "-194",
//       time: "10/18/2020 1:00PM"),
//   const Odd(
//       t1: "Atlana Falcons",
//       t2: "Minnesota Vikings",
//       m1: "+162",
//       m2: "-194",
//       time: "10/18/2020 1:00PM"),
//   const Odd(
//       t1: "Atlana Falcons",
//       t2: "Minnesota Vikings",
//       m1: "+162",
//       m2: "-194",
//       time: "10/18/2020 1:00PM"),
//   const Odd(
//       t1: "Atlana Falcons",
//       t2: "Minnesota Vikings",
//       m1: "+162",
//       m2: "-194",
//       time: "10/18/2020 1:00PM"),
// ];
