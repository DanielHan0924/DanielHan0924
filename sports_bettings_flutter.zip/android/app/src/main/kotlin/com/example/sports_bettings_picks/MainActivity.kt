package com.example.sports_bettings_picks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
