<?php
    require 'database/connectDatabase.php';

    require __DIR__ . '/vendor/autoload.php';
    $mpdf = new \Mpdf\Mpdf();

    $reportdate = date("d/m/y");
    $reporttime = date("h:i:sa");

    $sql = "SELECT * FROM loc_test ORDER BY id ASC";
    $locResult = $conn->query($sql);
    $locResultCount = mysqli_num_rows($locResult);

    $rowIndex = 0;
    $pageRowAmount = 10;
    $pageCount = $locResultCount % $pageRowAmount == 0 ? intdiv($locResultCount, $pageRowAmount) : intdiv($locResultCount, $pageRowAmount) + 1;

    for ($i=0; $i < $pageCount ; $i++) { 
        $mpdf->AddPage('L', // L - landscape, P - portrait 
            '', '', '', '',
            5, // margin_left
            5, // margin right
            5, // margin top
            5, // margin bottom
            0, // margin header
            0); // margin footer

        if (count($mpdf->pages)) {
            $pageNum = count($mpdf->pages);
        }else{
            $pageNum = 1;
        }

        $startRow = $i * $pageRowAmount; 

        $header = '<div>

        <div style="padding-top:25px; margin-top: 1em; margin-bottom: 0.5cm;margin-left: 0cm;margin-right: 0cm;">
            <table width="100%" style=" font-family: sans-serif;">
                <tr>
                    <td width="80%">
                    </td>
                    <td width="20%" style="text-align: left; ">
                        <span style="font-size: 1em;font-family: "UVDLMD+CourierNewPSMT";color: #000000;line-height: 1.132813em;">KC#121900-'.$pageNum.'</span><br>
                        <span style="font-size: 0.83em;font-family: "UDMQOH+ArialMT";color: #000000;line-height: 1.121674em;letter-spacing: 0em;">9 Zodic, 5743 &nbsp;</span><br>
                        <span style="font-size: 0.83em;font-family: "UDMQOH+ArialMT";color: #000000;line-height: 1.121674em;letter-spacing: 0em;">May 1, 2020 &nbsp;</span> 
                    </td>
                </tr>
            </table>   
        </div>
        <div style="margin-top: 0.1em;margin-bottom: 0.5cm;margin-left: 1cm;margin-right: 1cm;">
            <table width="100%" style=" font-family: sans-serif;">
                <tr>
                    <td width="33%"> 
                    </td>
                    <td width="34%" style="text-align: left; vertical-align: middle;">
                        <span style="font-size: 0.83em;font-family: "UDMQOH+ArialMT";color: #000000;line-height: 1.121674em;letter-spacing: 0em;">Ace Foods</span><br>
                        <span style="font-size: 0.83em;font-family: "UDMQOH+ArialMT";color: #000000;line-height: 1.121674em;letter-spacing: 0em;">123 Main Street &nbsp;</span><br>
                        <span style="font-size: 0.83em;font-family: "UDMQOH+ArialMT";color: #000000;line-height: 1.121674em;letter-spacing: 0em;">New York, NY 12345 &nbsp;</span>
                    </td>
                    <td width="33%"> 
                    </td>
                </tr>
            </table>   
        </div>
        <div style="margin-top: 1em;margin-bottom: 0.5cm;margin-left: 1cm;margin-right: 1cm;">
            <table width="100%" style=" font-family: sans-serif;">
                <tr>
                    <td width="100%" style="text-align: left; vertical-align: middle;"> 
                        <span style="font-size: 1em;font-family: "UDMQOH+ArialMT";color: #000000;line-height: 1.117188em;letter-spacing: -0.01em;word-spacing:0.07em;" >
                            The following products sold by Ace Foods are certified Vegan with the listed restrictions. &nbsp;
                        </span>
                    </td>
                </tr>
            </table>   
        </div>

        <div style="margin-top: 0.5em;margin-bottom: 0.25cm;margin-left: 1cm;margin-right: 1cm;">
            <table width="100%" style="border-top: 2px solid black;border-bottom: 2px solid black;">
                <tr >
               
                    <td  width="4%"  style="border-bottom: 2px solid black;text-align: left;font-size: 1em;color: #0000FF;font-family: "KFCRTU+Arial-BoldMT";">No</td>
                    <td  width="33%" style="border-bottom: 2px solid black;text-align: left;font-size: 1em;color: #0000FF;font-family: "KFCRTU+Arial-BoldMT";">Name</td>
                    <td  width="10%" style="border-bottom: 2px solid black;text-align: left;font-size: 1em;color: #0000FF;font-family: "KFCRTU+Arial-BoldMT";">ID</td>
                    <td  width="20%" style="border-bottom: 2px solid black;text-align: left;font-size: 1em;color: #0000FF;font-family: "KFCRTU+Arial-BoldMT";">Status</td>
                    <td  width="24%" style="border-bottom: 2px solid black;text-align: left;font-size: 1em;color: #0000FF;font-family: "KFCRTU+Arial-BoldMT";">Restriction</td>
                    <td  width="9%"  style="border-bottom: 2px solid black;text-align: left;font-size: 1em;color: #0000FF;font-family: "KFCRTU+Arial-BoldMT";">Size</td> 
              
                </tr>';

        $body = '';

        $sql = "SELECT * FROM loc_test  ORDER BY id ASC LIMIT ".$startRow.", ".$pageRowAmount."" ;
        $locResult = $conn->query($sql);
        $locResultCount = mysqli_num_rows($locResult);
        if ($locResultCount !=0 ) {
        
            while($loc_row = mysqli_fetch_assoc($locResult))
            {
                $rowIndex += 1;
                $body .= '
                <tr>
                    <td width="4%" style="text-align: left; vertical-align: middle;">
                        <span style="font-size: 0.83em;;color: #000000;letter-spacing: 0em;font-family: "UDMQOH+ArialMT"">'.$rowIndex.'</span>
                    </td>
                    <td width="33%" style="text-align: left; vertical-align: middle;">
                        <span style="font-size: 0.83em;color: #000000;letter-spacing: 0em;font-family: "UDMQOH+ArialMT";">'.$loc_row['name'].'</span><br>
                        <span style="font-size: 0.55em;color: #000000;letter-spacing: 0em;font-family: "UDMQOH+ArialMT";">Note:&nbsp; '.$loc_row['note'].'</span>
                    </td>
                    <td width="10%" style="text-align: left; vertical-align: middle;">
                        <span style="font-size: 0.83em;color: #000000;letter-spacing: 0em;font-family: "UDMQOH+ArialMT";">'.$loc_row['index'].'</span>
                    </td>
                    <td width="20%" style="text-align: left; vertical-align: middle;">
                        <span style="font-size: 0.83em;color: #000000;letter-spacing: 0em;font-family: "UDMQOH+ArialMT";">'.$loc_row['status'].'</span>
                    </td>
                    <td width="24%" style="text-align: left; vertical-align: middle;">
                        <span style="font-size: 0.83em;color: #000000;letter-spacing: 0em;font-family: "UDMQOH+ArialMT";">'.$loc_row['restriction'].'</span>
                    </td>
                    <td width="9%" style="text-align: left; vertical-align: middle;">
                        <span style="font-size: 0.83em;color: #000000;letter-spacing: 0em;font-family: "UDMQOH+ArialMT";">'.$loc_row['size'].'</span>
                    </td>
                </tr>';
            }    
        } else {
            $body = 'There is no data to export.';
        }

        $footer = '
            </table>
        </div>
            <div style="margin-bottom: 0.5cm;margin-left: 1cm;margin-right: 1cm;">
                <table width="100%" style=" font-family: sans-serif;">
                    <tr>
                        <td width="38%"> 
                        </td>
                        <td width="35%" style="text-align: left; vertical-align: middle;"> 
                            <span style="font-size: 0.83em;font-family: "UDMQOH+ArialMT";color: #000000;line-height: 1.121674em;letter-spacing: 0em;" >
                                This certificate is VALID UNTIL June 18, 2021 &nbsp;
                            </span>
                        </td>
                        <td width="20%"> 
                        </td>
                    </tr>
                </table>   
            </div>
            <div style="margin-top: 3em;margin-bottom: 0.1cm;margin-left:7em;margin-right: 7em;">
            
                <table width="100%" style="border-bottom: 2px solid black;">
                    <tr>
                        <td width="40%" style="padding-left:10px;"> 
                            <div style="margin-bottom:5px;">
                                <span style="font-size: 1em;color: blue;font-family: "KFCRTU+Arial-BoldMT";">Verify authenticity by entering ID at &nbsp;</span><br>
                            </div>
                            <div>
                                <a href="http://www.example.com" target="_blank" style="padding-bottom=-20px;">
                                    <span style="font-size: 1em;color: #0000FF;font-family: "KFCRTU+Arial-BoldMT";">www.example.com/verify &nbsp;</span>
                                </a>
                            </div>
                        </td>
                        <td width="5%" style="text-align: left; vertical-align: bottom;"> 
                        </td>
                        <td width="30%" style="text-align: left; vertical-align: bottom;"> 
                            <img width="240" height="75" src="sanitized-signature.png" alt="Signature"/>
                        </td>
                        
                        <td width="20%" style="padding-right:0px;"> 
                            <img width="140" height="70" src="sanitized-dk_seal.png" alt="Signature"/>
                        </td>
                    </tr>
                </table>  
                
            </div>
            <div style="margin-top: 0em;margin-bottom: 0.5cm;margin-left: 1cm;margin-right: 1cm;">
                <table width="100%" style=" font-family: sans-serif;">
                    <tr>
                        <td width="40%"> 
                        </td>
                        <td width="35%" style="text-align: left; vertical-align: middle;"> 
                            <span style="font-size: 1em;font-family: "ACSFJU+TimesNewRomanPSMT";color: ##000000;" >
                                    Steve Madden, Certification Administrator  &nbsp;
                            </span>
                        </td>
                        <td width="20%"> 
                        </td>
                    </tr>
                </table>   
            </div>
        </div>';

        $total_page = $header.$body.$footer;
        
        $mpdf->SetDefaultBodyCSS('background', "url('sanitized-background.png') no-repeat center center");
        $mpdf->SetDefaultBodyCSS('background-size', "cover");
        // $mpdf->SetHTMLHeader('<img src="close.svg"/>');
        // $mpdf->SetHTMLFooter('<img src="close.svg"/>');

        $mpdf->WriteHTML($total_page);
        $mpdf->setFooter('| Page {PAGENO} of {nbpg}|');
    }
    
    $mpdf->Output();
?>

    