# GymPlus App

## To run locally

In client/ directory, run:

```
$ yarn start
```

This starts webpack development server running at: `http://localhost:3000`. Changes will be watched.

## To run static version

```
$ yarn build
$ yarn start
```

This starts Express.js server running at: `http://localhost:3000`.

## To deploy

```
$ yarn build
$ git commit -am "Deploy"
$ eb deploy
```
