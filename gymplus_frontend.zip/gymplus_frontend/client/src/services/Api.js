import axios from 'axios';

export default class ApiMiddleware {
  constructor(rawData) {
    this.baseUrl = 'https://bubvn4vsm7.execute-api.eu-west-1.amazonaws.com/prod';
  }

  setToken(token) {
    this.token = token;
    this.defaultOptions = {
      headers: {
        Authorization: token ? `Bearer ${this.token}` : '',
      },
    };
  }

  get(url, options = {}) {
    return axios.get(this.baseUrl + url, { ...this.defaultOptions, ...options });
  }

  post(url, data, options = {}) {
    return axios.post(this.baseUrl + url, data, { ...this.defaultOptions, ...options });
  }

  put(url, data, options = {}) {
    return axios.put(this.baseUrl + url, data, { ...this.defaultOptions, ...options });
  }

  delete(url, options = {}) {
    return axios.delete(this.baseUrl + url, { ...this.defaultOptions, ...options });
  }
}
