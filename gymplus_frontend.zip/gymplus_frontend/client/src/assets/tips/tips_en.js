const loadingTips = [
  {
    text: ["To see all your equipment click on \"Equipment\"."]
  },
  {
    text: ["Select the dates using Date Range under Filters option."]
  },
  {
    text: ["As default the time frame is set to the previous week."]
  },
  {
    text: ["To change your password, click \"Don't remember your password?\" on the login screen and follow the instructions."]
  },
  {
    text: ["Select the language from top of the page."]
  },
  {
    text: ["Always click Apply filters to save changes you've made under Filters."]
  },
  {
    text: ["Under \"Equipment\" change from Equipment to Day of week to see daily utilization."]
  },
  {
    text: ["Explore the temporal behaviour of your customers by selecting morning or evening hours using Time under the \"Equipment\"."]
  },
  {
    text: ["Discover differences between weekdays and weekend by selecting accordingly using Time under \"Equipment\"."]
  },
  {
    text: ["To focus on a single group of equipment select it from Categories under \"Equipment\"."]
  }
];


export default loadingTips;
