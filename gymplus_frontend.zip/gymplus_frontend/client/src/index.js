import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import WebFont from 'webfontloader';

import 'materialize-css';
import 'materialize-css/dist/css/materialize.css';
import 'font-awesome/css/font-awesome.min.css'; 

import GymPlus from './components/GymPlus';
import registerServiceWorker from './registerServiceWorker';

import './index.css';


// Load fonts
WebFont.load({
  google: {
    families: ['Barlow:200,300,400,600', 'Material+Icons'],
  },
});

ReactDOM.render(
    <BrowserRouter>
      <GymPlus  />
    </BrowserRouter>,
  document.getElementById('root')
);
registerServiceWorker();
