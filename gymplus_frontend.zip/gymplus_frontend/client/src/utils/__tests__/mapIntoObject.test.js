import mapIntoObject from '../mapIntoObject.js';

const mockData = [ { name: 'mockData1', id: 1 }, { name: 'mockData2', id: 5 }];
const mockDataWithCustomIdName = [ { name: 'mockData1', customId: 1 }, { name: 'mockData2', customId: 5 }];

describe('Map Into Object', () => {
    it('should expose array mockData as an object', () => {
      const objectData = mapIntoObject(mockData);
      const id = mockData[0].id;
      const name = mockData[0].name;
      expect(objectData[id].name).toEqual(name);
    });
    it('should expose array mockData as an object when passed a custom id name', () => {
      const idName = 'customId';
      const objectData = mapIntoObject(mockDataWithCustomIdName, idName);
      const id = mockDataWithCustomIdName[1].customId;
      const name = mockDataWithCustomIdName[1].name;
      expect(objectData[id].name).toEqual(name);
    });
});
