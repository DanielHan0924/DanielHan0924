import getAmountOfSelectedItems from '../getAmountOfSelectedItems.js';
import { getSelectedItemsValues } from '../getAmountOfSelectedItems.js';

const selectedItems = {
  1: false,
  2: true,
  3: false,
  4: true
};

describe('Get Amount Of Selected Items', () => {
  it('should return amount of true values in selectedItems', () => {
    const actual = getAmountOfSelectedItems(selectedItems);
    const expected = 2;
    expect(actual).toEqual(expected);
  });
});

describe('Get Selected Items Values', () => {
  it('should return values of selectedItems object', () => {
    const actual = getSelectedItemsValues(selectedItems);
    const expected = [false, true, false, true];
    expect(actual).toEqual(expected);
  });
});
