import getRoundedPercentages from '../getRoundedPercentages.js';

describe('getRoundedPercentages', () => {
  it('should round percentage values by one decimal', () => {
    const roundedPercentage = getRoundedPercentages(35.967);
    expect(roundedPercentage).toEqual(35.97);
  });
});
