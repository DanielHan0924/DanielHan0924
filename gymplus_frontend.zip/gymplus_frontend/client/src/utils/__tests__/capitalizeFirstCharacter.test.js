import capitalizeFirstCharacter from '../capitalizeFirstCharacter';

describe('Capitalize First Character', () => {
  it('should capitalize the first character of a string', () => {
    const actual = capitalizeFirstCharacter('testString');
    const expected = 'TestString';
    expect(actual).toEqual(expected);
  });
});
