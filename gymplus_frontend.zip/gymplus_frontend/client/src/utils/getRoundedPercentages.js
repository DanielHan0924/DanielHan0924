export default function getRoundedPercentages(valueToRound){
  const roundedValue = Math.round(valueToRound * 100) / 100;
  return roundedValue;
}
