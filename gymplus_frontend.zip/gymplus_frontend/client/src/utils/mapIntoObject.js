const mapIntoObject = function(array, idName = 'id'){
  return array.reduce((accumulator, currentElement) => {
    accumulator[currentElement[idName]] = currentElement;
    return accumulator;
  }, {});
}

export default mapIntoObject;
