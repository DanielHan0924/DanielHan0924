export default function getAmountOfSelectedItems(selectedItems) {
  const selectedItemsValues = getSelectedItemsValues(selectedItems);
  const trueValues = selectedItemsValues.filter(value => value);
  const amountOfSelectedItems = trueValues.length;
  return amountOfSelectedItems;
}

export const getSelectedItemsValues = function(selectedItems){
  const selectedItemsValues = Object.values(selectedItems);
  return selectedItemsValues;
}
