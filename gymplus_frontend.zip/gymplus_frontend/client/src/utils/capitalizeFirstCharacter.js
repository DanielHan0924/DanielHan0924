const capitalizeFirstCharacter = function (stringToCapitalize){
  const capitalizedString = stringToCapitalize.substring(0, 1).toUpperCase() + stringToCapitalize.substring(1);
  return capitalizedString;
}

export default capitalizeFirstCharacter;
