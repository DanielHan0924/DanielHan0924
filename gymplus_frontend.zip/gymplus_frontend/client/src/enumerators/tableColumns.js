export default [
  { id: 0, name: "id", hasMultipleValues: false, showByDefault: false },
  { id: 1, name: "name", hasMultipleValues: false, showByDefault: true },
  { id: 2, name: "ab_active", hasMultipleValues: false, showByDefault: false },
  { id: 3, name: "description", hasMultipleValues: false, showByDefault: false },
  { id: 4, name: "timestamp_activated", hasMultipleValues: false, showByDefault: true },
  { id: 5, name: "premise_id", hasMultipleValues: true, showByDefault: false },
  { id: 6, name: "device_id", hasMultipleValues: true, showByDefault: false },
  { id: 7, name: "category_id", hasMultipleValues: true, showByDefault: true },
  { id: 8, name: "equipment_id", hasMultipleValues: true, showByDefault: true },
  { id: 9, name: "ttd_reldiff", hasMultipleValues: false, showByDefault: false },
  { id: 10, name: "d7_reldiff", hasMultipleValues: false, showByDefault: false },
  { id: 11, name: "d14_reldiff", hasMultipleValues: false, showByDefault: false },
  { id: 12, name: "d30_reldiff", hasMultipleValues: false, showByDefault: true },
  { id: 13, name: "monetary_estimate", hasMultipleValues: false, showByDefault: false }
];
