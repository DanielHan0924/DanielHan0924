export default Object.freeze({
  PREMISE: 'premise',
  DEVICE: 'device',
  CATEGORY: 'category',
  EQUIPMENT: 'equipment'
});
