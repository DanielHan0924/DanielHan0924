export default Object.freeze({
  TAG_TO_DATE: 'tagToDate',
  ONE_WEEK: 'oneWeek',
  TWO_WEEK: 'twoWeek',
  ONE_MONTH: 'oneMonth'
});
