import React, { Component } from 'react';
import { observer } from 'mobx-react';
import _ from 'lodash';
import { injectIntl } from 'react-intl';

import TagSelectionStore from '../../../models/TagSelectionStore.js';
import timespanTypes from '../../../enumerators/timeSpanTypes.js';

import config from './TagAbChart.config.js';
const ReactHighcharts = require('react-highcharts');
require('highcharts-data')(ReactHighcharts.Highcharts);

const TabAbChart = observer(
  class TabAbChart extends Component{
    configureChart = (chartToConfigure) => {
      const chartConfig = _.cloneDeep(chartToConfigure);
      if (!this.checkIsTimespanSelected()){
        return chartConfig
      }
      this.setYAxisTitle(chartConfig);
      this.setXAxisTitle(chartConfig);
      this.setChartData(chartConfig);
      this.setToolTip(chartConfig);
      return chartConfig;
    }

    checkIsTimespanSelected(){
      const { timeSpanSelections } = TagSelectionStore;
      const values = Object.values(timeSpanSelections);
      return values.includes(true);
    }

    setYAxisTitle = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      const titleText = formatMessage({ id: 'tags.abChart.yAxis.title' });
      chartConfig.yAxis.title.text = titleText;
    }

    setXAxisTitle(chartConfig){
      const { formatMessage } = this.props.intl;
      const titleText = formatMessage({ id: 'tags.abChart.xAxis.title' });
      _.extend(chartConfig, {
        xAxis: {
          title: {
            text: titleText,
            align: 'low'
          }
        }
      })
      chartConfig.xAxis.title.text = titleText;
    }

    setChartData = (chartConfig) => {
      const { selectedTag } = TagSelectionStore;
      const selectedTimespan = this.getSelectedTimespan();
      const histogramData = selectedTag[selectedTimespan];
      let series;
      if(histogramData){
        series = this.buildChartSeries(histogramData);
      }
      _.extend(chartConfig, {
        series
      });
    }

    getSelectedTimespan(){
      const timespanName = this.getTimespanName();
      switch(timespanName){
        case timespanTypes.TAG_TO_DATE:
          return 'ttd_hist';
        case timespanTypes.ONE_WEEK:
          return 'd7_hist';
          case timespanTypes.TWO_WEEK:
            return 'd14_hist';
        case timespanTypes.ONE_MONTH:
          return 'd30_hist';
        default:
          return;
      }
    }

    getTimespanName(){
      const { timeSpanSelections } = TagSelectionStore;
      const keys = Object.keys(timeSpanSelections);
      const timespanName = keys.find(key => timeSpanSelections[key] === true);
      return timespanName;
    }

    buildChartSeries(histogramData){
      const builtData = this.buildChartData(histogramData);

      const series = [{
        name: 'before',
        data: builtData,
        color: '#3c73c8'
      }];
      return series;
    }

    buildChartData(histogramData){
      /*
        x values are multiplied by 100 because apparently
        Highcharts doens't know how to scale charts with tiny values
      */
      const oneHundredPercents = 100;
      const xCoordinates = histogramData[0].map(data => data * oneHundredPercents);
      const yCoordinates = histogramData[1];

      const buildData = [];
      const amountOfCoordinateValues = xCoordinates.length;
      for (let i = 0; i < amountOfCoordinateValues; i++){
        buildData.push( [xCoordinates[i], yCoordinates[i]] );
      }
      return buildData;
    }

    setToolTip = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      chartConfig.tooltip.formatter = function(){
        const yRounded = Math.round(this.y * 100 * 10) / 10;
        const xRounded = Math.round(this.x * 10) / 10;
        const utilizationRate = formatMessage({ id: 'tags.abChart.utilizationRate' });
        const frequency = formatMessage({ id: 'tags.abChart.frequency' });
        return (
          `${utilizationRate}: ${xRounded}% <br/>
          ${frequency}: ${yRounded} <br/>`
        );
      }
    }

    render(){
      const chartConfig = this.configureChart(config);
      return(
        <div className="TagAbChart">
          <ReactHighcharts config={chartConfig} ref='chart' />
        </div>
      );
    }
  }
);


export default injectIntl(TabAbChart);
