const chartGray = "#eef0f2";
const labelGray = "#656668";
const blueDark = "#3c73c8";
const black = "#000000";
const white = "#FFFFFF";

export default {
  chart: {
    height: 200,
    type: "spline",
  },
  title: {
    text: "",
  },
  subtitle: {
    text: ""
  },
  xAxis: {
    className: "highcharts-color-0",
    title: {
      text: null
    },
    categories: [],
    labels: {
      style: {
        color: labelGray,
        fontSize: "16px"
      }
    },
    gridLineColor: chartGray
  },
  yAxis: {
    min: 0,
    title: {
      text: "Utilization-%", // Will be overwritten by translation
      align: "high"
    },
    labels: {
      enabled: false
    },
    gridLineColor: chartGray,
    lineColor: chartGray,
    tickColor: chartGray
  },
  tooltip: {
    valueSuffix: "%",
    followPointer: true,
    shadow: false,
    borderRadius: 0,
    backgroundColor: blueDark,
    borderColor: black,
    borderWidth: 1,
    style: {
      color: white,
      fontSize: "14px",
      letterSpacing: "1px"
    },
    formatter: function(){
      return '';
    }
  },
  plotOptions: {
    series: {
      marker: {
        enabled: false
      },
      dataLabels: {
        enabled: false,
        align: "right",
        shadow: false,
        borderWidth: 0,
        padding: 0,
        y: -1,
        x: -3,
        style: {
          color: labelGray,
          textOutline: false,
          fontSize: "13px"
        },
        formatter() {
          return `${(this.y * 100).toFixed(2)} %`;
        }
      }
    }
  },
  legend: {
    enabled: false
  },
  /* Highcharts.com - label */
  credits: {
    enabled: false
  },
  series: [
    {
      name: "Selected period", // Will be overwritten by translation
      data: [], // Will be populated by the widget
      dataLabels: {
        formatter() {
          return `${(this.y * 100).toFixed(2)} %`;
        }
      }
    }
  ]
};

/* joel.salminen@indoorinformatics.com */
