import React from 'react';
import { shallow } from 'enzyme';

import TagAddingView from './TagAddingView.js';
import TagEditing from '../TagEditing/TagEditing.js';

describe('TagAddingView', () => {
  let wrapper;
  beforeEach(() => {
    wrapper = shallow(<TagAddingView />);
  });
  it('should render without crashing', () => {
    const wrapper = shallow(<TagAddingView />);
  });
  it('should render TagEditing', () => {
    const tagEditingComponents = wrapper.find(TagEditing);
    expect(tagEditingComponents.length).toEqual(1);
  });
});
