import React, { Component } from 'react';
import { ExpansionPanel } from 'react-md';

import Localize from '../../Localize/Localize.js';
import TagEditing from '../TagEditing/TagEditing.js';
import './TagAddingView.scss';

class TagAddingView extends Component {
  render(){
    const { columnWidths } = this.props;
    const labelText = <Localize id="tags.addTag.title" />

    return(
      <ExpansionPanel
        className="TagAddingView"
        label={labelText}
        focused={false}
        columnWidths={columnWidths}
        footer={null}
      >
        <div className="TagAddingView__gutter"></div>
        <TagEditing />
      </ExpansionPanel>
    );
  }
}

export default TagAddingView;

/* joel.salminen@indoorinformatics.com */
