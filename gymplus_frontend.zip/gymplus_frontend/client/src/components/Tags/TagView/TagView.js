import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { ExpansionPanel } from 'react-md';
import { injectIntl } from 'react-intl';
import moment from 'moment';

import Localize from '../../Localize/Localize.js';
import TagViewOptions from '../TagViewOptions/TagViewOptions.js';
import TagTable from '../TagTable/TagTable.js';
import TagStore from '../../../models/TagStore.js';
import TagSelectionStore from '../../../models/TagSelectionStore.js';
import TagTableColumnStore from '../../../models/TagTableColumnStore.js';
import './TagView.scss';

const TagView = observer(
  class TagView extends Component {
    state = {
      filterText: '',
      ignoreColumnVisibility: false
    }

    getFilteredTags = (unfilteredTags) => {
      const tagsClone = unfilteredTags.map(tag => Object.assign({}, tag));
      const filteredTags = this.filterTags(tagsClone);
      return filteredTags;
    }

    filterTags = (unfilteredTags) => {
      const filterInputFieldIsEmpty = this.checkIsFilterInputFieldIsEmpty();
      if (filterInputFieldIsEmpty){
        return unfilteredTags;
      }

      const filteredTags = unfilteredTags.filter(tag => {
        const { filterText } = this.state;
        const tagPropertiesString = this.getTagPropertiesString(tag);
        const isFilterTextIncludedInTagProperties = this.checkIsTextIncludedInProperties(tagPropertiesString, filterText);
        return isFilterTextIncludedInTagProperties;
      });
      return filteredTags;
    }

    checkIsFilterInputFieldIsEmpty(){
      const { filterText } = this.state;
      return filterText === '';
    }

    checkIsTextIncludedInProperties(tagPropertiesString, filterText){
      return tagPropertiesString.toLowerCase().indexOf(filterText.toLowerCase()) !== -1
    }

    getTagPropertiesString(tag){
      let tagPropertiesString = '';

      tagPropertiesString += this.getTagIdString(tag);
      tagPropertiesString += this.getTagNameString(tag);
      tagPropertiesString += this.getIsActiveString(tag);
      tagPropertiesString += this.getTagDateString(tag);
      tagPropertiesString += this.getDescriptionString(tag);
      tagPropertiesString += this.getSelectedPropertyStrings(tag, 'premise');
      tagPropertiesString += this.getSelectedPropertyStrings(tag, 'device');
      tagPropertiesString += this.getSelectedPropertyStrings(tag, 'category');
      tagPropertiesString += this.getSelectedPropertyStrings(tag, 'equipment');
      return tagPropertiesString;
    }

    checkShouldPropertyValueBeFiltered(columnName){
      const { ignoreColumnVisibility } = this.state;
      const isColumnSelected = this.checkIsColumnSelected(columnName);
      return isColumnSelected || ignoreColumnVisibility;
    }

    checkIsColumnSelected(columnName){
      const { tableColumns, selectedColumns } = TagTableColumnStore;
      const foundColumn = tableColumns.find(column => column.name === columnName);
      const { id } = foundColumn;
      return selectedColumns[id];
    }

    getTagIdString(tag){
      const shouldValueBeFiltered = this.checkShouldPropertyValueBeFiltered('id');
      return shouldValueBeFiltered ? tag.id.toString() : '';
    }

    getTagNameString(tag){
      const shouldValueBeFiltered = this.checkShouldPropertyValueBeFiltered('name');
      return shouldValueBeFiltered ? tag.name : '';
    }

    getDescriptionString(tag){
      const shouldValueBeFiltered = this.checkShouldPropertyValueBeFiltered('description');
      return shouldValueBeFiltered ? tag.description : '';
    }

    getTagDateString(tag){
      const shouldValueBeFiltered = this.checkShouldPropertyValueBeFiltered('timestamp_activated');
      const formattedDate = this.formatDate(tag);
      return shouldValueBeFiltered ? formattedDate : '';
    }

    getIsActiveString(tag){
      const shouldValueBeFiltered = this.checkShouldPropertyValueBeFiltered('ab_active');
      const formattedIsActiveValue = this.formatIsActiveValue(tag);
      return shouldValueBeFiltered ? formattedIsActiveValue : '';
    }

    formatIsActiveValue(tag){
      if (tag.ab_active){
        return <Localize id="tags.table.body.monitoring.enabled" />;
      }
      return <Localize id="tags.table.body.monitoring.disabled" />;
    }

    formatDate(tag){
      const { formatMessage } = this.props.intl;
      const date = moment(tag.timestamp_activated);
      const formattedDate = date.format(formatMessage({ id: 'date.format' }));
      return formattedDate;
    }

    getSelectedPropertyStrings(tag, columnName){
      const selectedPropertyArray = this.getSelectedPropertiesArray(tag, columnName);
      const shouldValueBeFiltered = this.checkShouldPropertyValueBeFiltered(columnName + '_id');
      return shouldValueBeFiltered ? selectedPropertyArray.join('') : '';
    }

    getSelectedPropertiesArray = (tag, columnName) => {
      const selectedProperties = this.getSelectedProperties(tag, columnName);
      const selectedPropertyArray = selectedProperties.map(property => property.id + property.name);
      return selectedPropertyArray;
    }

    getSelectedProperties = (tag, columnName) => {
      const selectedProperties = TagStore[columnName].filter(property => {
        const idType = columnName + '_id';
        const propertyIsSelected = tag[idType].includes(property.id);
        return propertyIsSelected;
      });
      return selectedProperties;
    }

    handleClearFiltersClick = () => {
      this.setState({
        filterText: ''
      });
    }

    handleFilterTextChange = (filterText) => {
      TagSelectionStore.resetTagSelections();
      this.setState({ filterText });
    }

    handleVisibilityChange = () => {
      this.setState(previousState => ({
        ignoreColumnVisibility: !previousState.ignoreColumnVisibility
      }));
    }

    componentDidMount(){
      TagTableColumnStore.initializeTableColumns();
      TagTableColumnStore.setSelectedColumns();
      TagStore.fetchTags();
      TagStore.fetchAllTagProperties();
    }

    render (){
      const panelLabel = <Localize id="tags.management.title" />;
      const filteredTags = this.getFilteredTags(TagStore.tags);

      return(
        <ExpansionPanel
          label={panelLabel}
          className="TagView"
          focused={true}
          defaultExpanded
          columnWidths={this.props.columnWidths}
          footer={false}
        >
          <div className="TagView__contentWrapper">
            <TagViewOptions
              handleFilterTextChange={this.handleFilterTextChange}
              handleClearFiltersClick={this.handleClearFiltersClick}
              filterText={this.state.filterText}
              ignoreColumnVisibility={this.state.ignoreColumnVisibility}
              handleVisibilityChange={this.handleVisibilityChange}
            />
            <TagTable
              tags={filteredTags}
            />
          </div>

        </ExpansionPanel>
      );
    }

  }
);


export default injectIntl(TagView);

/* joel.salminen@indoorinformatics.com */
