import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { TableHeader, TableRow } from 'react-md';

import TagTableHeaderColumn from '../TagTableHeaderColumn/TagTableHeaderColumn.js';
import TagTableColumnStore from '../../../../models/TagTableColumnStore.js';

const TagTableHeader = observer(
  class TagTableHeader extends Component {
    state = {
      previouslySelected: null,
      sortingIcon: null,
    }

    handleHeaderColumnClick = (column) => {
      const didUserClickOnSameColumnTwice = this.checkPrevioslyClickedColumn(column);
      if(didUserClickOnSameColumnTwice){
        this.reverseSortColumns(column);
        this.setSortingIcon(column);
        return;
      }
      this.updatePreviouslySelectedColumn(column);
      this.sortColumns(column.name);
      this.setSortingIcon(column);
    }

    checkPrevioslyClickedColumn = (column) => {
      const { previouslySelected } = this.state;
      return previouslySelected && previouslySelected.name === column.name;
    }

    updatePreviouslySelectedColumn = (column) => {
      this.setState({ previouslySelected: column });
    }

    setSortingIcon = (column) => {

      const isSortingIconSet = this.checkIsSortingIconSet(column);
      if (isSortingIconSet){
        this.setState({ sortingIcon: { [column.id]: '▲' } });
        return;
      }

      const { sortingIcon } = this.state;
      const newSortingIcon = sortingIcon[column.id] === '▼' ? '▲' : '▼';
      this.setState({ sortingIcon: { [column.id]: newSortingIcon } });
    }

    checkIsSortingIconSet = (column) => {
      const { sortingIcon } = this.state;
      return ( !sortingIcon || !sortingIcon[column.id] );
    }

    reverseSortColumns(column){

      const isReversed = true;
      TagTableColumnStore.handleTagSorting(column.name, isReversed);
    }

    sortColumns(columnName){
      const isReversed = false;
      TagTableColumnStore.handleTagSorting(columnName, isReversed);
    }

    render(){
      const { tableColumns, isVisible } = this.props;
      const visibility = isVisible ? 'visible' : 'hidden';

      return(
        <TableHeader style={{ visibility: visibility }}>
          <TableRow>
            {tableColumns.map(column =>
              <TagTableHeaderColumn
                key={column.id}
                column={column}
                sortColumns={this.handleHeaderColumnClick}
                sortingIcon={this.state.sortingIcon}
              />
            )}
          </TableRow>
        </TableHeader>
      );
    }


  }
);

export default TagTableHeader;

/* joel.salminen@indoorinformatics.com */
