import React from 'react';

const ColumnValue = (props) => {
  const { value } = props;
  return (
    <div>{value}</div>
  );
}

export default ColumnValue;
