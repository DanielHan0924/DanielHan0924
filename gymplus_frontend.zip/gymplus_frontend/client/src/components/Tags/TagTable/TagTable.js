import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { DataTable } from 'react-md';

import TagTableHeader from './TagTableHeader/TagTableHeader.js';
import TagTableBody from './TagTableBody/TagTableBody.js';
import SingleTagView from '../../Tags/SingleTagView/SingleTagView.js';
import LoadingAnimation from '../../LoadingAnimation/LoadingAnimation.js';
import Localize from '../../Localize/Localize.js';
import TagStore from '../../../models/TagStore.js';
import TagSelectionStore from '../../../models/TagSelectionStore.js';
import TagTableColumnStore from '../../../models/TagTableColumnStore.js';

import './TagTable.scss';

const TagTable = observer(
  class TagTable extends Component {
    filterColumns = () => {
      const { tableColumns, selectedColumns } = TagTableColumnStore;
      const filteredColumns = tableColumns.filter(
        column => selectedColumns[column.id]
      );
      return filteredColumns;
    }

    getTagsBeforeSelectedTag = () => {
      const { selectedTag } = TagSelectionStore;
      const { tags } = this.props;
      const clonedTags = tags.map(tag => Object.assign({}, tag));
      if (!selectedTag){
        return clonedTags;
      }
      const indexOfSelectedTag = clonedTags.findIndex(tag => tag.id === selectedTag.id);
      const selectedTagAndAllTagsBeforeIt = clonedTags.slice(0, indexOfSelectedTag + 1);
      return selectedTagAndAllTagsBeforeIt;
    }
    getTagsAfterSelectedTag = () => {
      const { selectedTag } = TagSelectionStore;
      const { tags } = this.props;
      const clonedTags = tags.map(tag => Object.assign({}, tag));
      if (!selectedTag){
        return [];
      }
      const indexOfSelectedTag = clonedTags.findIndex(tag => tag.id === selectedTag.id);
      const tagsAfterSelectedTag = clonedTags.slice(indexOfSelectedTag + 1);
      return tagsAfterSelectedTag;
    }

    checkIsLoading(){
      return !TagStore.loaded.tags;
    }

    checkAreNoTagsCreated(){
      return TagStore.loaded.tags && TagStore.tags.length === 0;
    }

    render(){
      const { selectedTag } = TagSelectionStore;
      const isTagSelected = selectedTag;
      const tagsBeforeSelectedTag = this.getTagsBeforeSelectedTag();
      const tagsAfterSelectedTag = this.getTagsAfterSelectedTag();
      const isHeaderVisible = true;
      const isLoading = this.checkIsLoading();
      const noTagsCreated = this.checkAreNoTagsCreated();

      return (
        <div className="TagTable__container">
          {this.renderDataTable(tagsBeforeSelectedTag, isHeaderVisible)}
          {isLoading && !TagStore.error.tag && <LoadingAnimation /> }
          {TagStore.error.tag  && <p style={{textAlign: 'center'}}>{<Localize id="tags.error.tag" />}</p>}
          {noTagsCreated &&
            <p style={{ textAlign: 'center', marginTop: '1rem', fontSize: '1.1rem' }}><Localize id="tags.table.noTags" /></p>
          }
          {isTagSelected &&
            <SingleTagView />
          }
          {this.renderDataTable(tagsAfterSelectedTag, !isHeaderVisible)}
        </div>
      );
    }

    renderDataTable(tags, isHeaderVisible){
      return (
        <DataTable
          baseId="tags"
          className="TagTable"
        >
          {this.renderHeader(isHeaderVisible)}
          {this.renderBody(tags)}
        </DataTable>
      );
    }

    renderHeader(isHeaderVisible){
      const filteredColumns = this.filterColumns();

      return (
        <TagTableHeader
          tableColumns={filteredColumns}
          isVisible={isHeaderVisible}
        />
      );
    }

    renderBody(tags) {
      const filteredColumns = this.filterColumns();
      return (
        <TagTableBody
          tags={tags}
          tableColumns={filteredColumns}
        />
      );
    }
  }
);


export default TagTable;

/* joel.salminen@indoorinformatics.com */
