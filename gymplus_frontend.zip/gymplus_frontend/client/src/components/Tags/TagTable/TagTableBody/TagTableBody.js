import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { TableBody } from 'react-md';

import TagRow from '../TagTableBodyRow/TagTableBodyRow.js';
import TagSelectionStore from '../../../../models/TagSelectionStore.js';
import './TagTableBody.scss';

const TagTableBody = observer(
  class TagTableBody extends Component {

    render(){
      const { tags, tableColumns } = this.props
      const { rowSelections } = TagSelectionStore;
      return(
        <TableBody className="TagTableBody">
          {tags.map((tag, index) => (
            <TagRow
              key={tag.id}
              tag={tag}
              tableColumns={tableColumns}
              isSelected={rowSelections[tag.id]}
            />
          ))}
        </TableBody>
      );
    }
  }
);


export default TagTableBody;

/* joel.salminen@indoorinformatics.com */
