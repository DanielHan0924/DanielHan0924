import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { injectIntl } from 'react-intl';
import { TableColumn } from 'react-md';
import moment from 'moment';

import Localize from '../../../Localize/Localize.js';
import ColumnValue from '../ColumnValue/ColumnValue.js';
import ColumnValueList from '../ColumnValueList/ColumnValueList.js';
import Currency from '../../../Currency/Currency.js';
import TagStore from '../../../../models/TagStore.js';
import TagSelectionStore from '../../../../models/TagSelectionStore.js';

import columnTypes from '../../../../enumerators/columnTypes.js';
import './TagTableBodyColumn.scss';

const TagTableBodyColumn = observer(
  class TagTableBodyColumn extends Component {

    formatColumnValue(unformattedValue, propertyName){
      if (propertyName === columnTypes.NAME || propertyName === columnTypes.DESCRIPTION){
        return this.formatString(unformattedValue);
      }
      if (propertyName === columnTypes.MONITORING){
        return this.formatMonitoring(unformattedValue);
      }
      if (propertyName === columnTypes.DATE){
        return this.formatDate(unformattedValue);
      }
      if (this.columnIsAboutDifference(propertyName)){
        return this.formatDifference(unformattedValue);
      }
      if(propertyName === columnTypes.MONETARY_ESTIMATE){
        return this.formatMonetaryEstimate(unformattedValue);
      }
      return <p>{unformattedValue}</p>;
    }

    formatString(string){
      const maxCharacterLimit = 50;
      if(string.length > maxCharacterLimit){
        return <p>{string.substring(0, maxCharacterLimit) + '...'}</p>;
      }
      return <p>{string}</p>;
    }

    formatMonitoring(monitoring){
      if (monitoring){
        return <p><Localize id="tags.table.body.monitoring.enabled" /></p>;
      }
      return <p><Localize id="tags.table.body.monitoring.disabled" /></p>;
    }

    formatDate(date){
      const { formatMessage } = this.props.intl;
      const dateToFormat = moment(date);
      const formattedDate = dateToFormat.format(formatMessage({ id: 'date.format' }));
      return <p>{formattedDate}</p>;
    }

    formatDifference(differences){
      const differenceToDisplay = differences[1];
      const signSymbol = this.getSignSymbol(differenceToDisplay);
      const differenceClassName = this.getDifferenceClassName(differenceToDisplay);
      const roundedDifference = this.getRoundedPercentages(differenceToDisplay);
      return (
        <p className={differenceClassName}>
          {`${signSymbol} ${roundedDifference}%`}
        </p>
      );
    }

    getRoundedPercentages(valueToRound){
      const roundedValue = Math.round(valueToRound * 100) / 100;
      return roundedValue;
    }

    getSignSymbol(value){
      if (value === 0){
        return '';
      }
      else if (value < 0){
        return '▼'; // noot noot
      }
      else{
        return '▲';
      }
    }

    getDifferenceClassName(difference){
      if (difference > 0){
        return 'TagTableBodyColumn__difference--positive';
      }
      else{
        return 'TagTableBodyColumn__difference--negative';
      }
    }

    formatMonetaryEstimate(estimateList){
      if(!estimateList) return <p>-</p>
      const monetaryEstimate = estimateList[1];
      const roundedEstimate = Math.round(monetaryEstimate);
      return <p><Currency amount={roundedEstimate} /></p>;
    }

    columnIsAboutDifference(value){
      return (
        value === columnTypes.TAG_TO_DATE_DIFFERENCE ||
        value === columnTypes.D7_DIFFERENCE ||
        value === columnTypes.D30_DIFFERENCE
      );
    }

    columnHasOnlyOneValue(){
      const { column } = this.props;
      return !column.hasMultipleValues;
    }

    getOneValue(){
      const { tag, column } = this.props;
      const columnType = column.name;
      const columnValue = tag[columnType];
      const formattedColumnValue = this.formatColumnValue(columnValue, columnType);
      return formattedColumnValue;
    }

    getObjectsBasedOnId(){
      const { tag, column } = this.props;

      const columnType = column.name;
      const propertyObjects = this.getPropertyObjects(columnType);

      const columnIds = tag[columnType];
      const foundValues = propertyObjects.filter(object => columnIds.includes(object.id));
      return foundValues;
    }

    getPropertyObjects(columnType){
      switch(columnType){
        case columnTypes.PREMISE_ID:
          const { premise } = TagStore;
          return premise;
        case columnTypes.DEVICE_ID:
          const { device } = TagStore;
          return device;
        case columnTypes.CATEGORY_ID:
          const { category } = TagStore;
          return category;
        case columnTypes.EQUIPMENT_ID:
          const { equipment } = TagStore;
          return equipment;
        default:
          return [];
      }
    }

    getClassName(multipleValues){
      const shouldFadeOut = this.checkShouldFadeOut(multipleValues);
      const selectedTagEqualsPropsTag = this.checkSelectedTagEqualsPropsTag();
      const className = shouldFadeOut && !selectedTagEqualsPropsTag ? 'ColumnValueList__fadeOut': undefined;
      return className;
    }

    checkShouldFadeOut(multipleValues){
      const amountOfValues = multipleValues.length;
      const isMoreThanFiveValues = amountOfValues > 4;
      return (isMoreThanFiveValues);
    }

    checkSelectedTagEqualsPropsTag(){
      const { selectedTag } = TagSelectionStore;
      const propsTag = this.props.tag;
      return selectedTag && selectedTag.id === propsTag.id;
    }

    getMultipleValuesToDisplay(){
      const multipleValues = this.getObjectsBasedOnId();
      const firstFiveValues = multipleValues.slice(0, 5);
      const selectedTagEqualsPropsTag = this.checkSelectedTagEqualsPropsTag();
      const multipleValuesToDisplay = selectedTagEqualsPropsTag ? multipleValues : firstFiveValues;
      return multipleValuesToDisplay;
    }

    render(){
      const onlyOneColumnValue = this.columnHasOnlyOneValue();
      const oneValue = this.getOneValue();
      const multipleValuesToDisplay = this.getMultipleValuesToDisplay();
      const listClassName = this.getClassName(multipleValuesToDisplay);

      return(
        <TableColumn>
          {onlyOneColumnValue ? (
            <ColumnValue
              value={oneValue}
            />
          ) : (
            <ColumnValueList
              values={multipleValuesToDisplay}
              listClassName={listClassName}
            />
          )}
        </TableColumn>
      );
    }
  }
);

export default injectIntl(TagTableBodyColumn);
