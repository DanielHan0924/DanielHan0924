import React, {Component} from 'react';
import { observer } from 'mobx-react';
import { TableRow } from 'react-md';

import TagColumn from '../TagTableBodyColumn/TagTableBodyColumn.js';
import TagSelectionStore from '../../../../models/TagSelectionStore.js';

import './TagTableBodyRow.scss';

const TagTableBodyRow = observer(
  class TagTableBodyRow extends Component {

    handleRowClick = () => {
      const { tag } = this.props;
      const { selectedTag } = TagSelectionStore;
      if(this.userClickOnCurrentlySelectedTag(selectedTag, tag)){
        TagSelectionStore.resetTagSelections();
      }
      else{
        TagSelectionStore.handleRowSelection(tag);
      }
    }
    userClickOnCurrentlySelectedTag = (selectedTag, tag) => {
      if (selectedTag && selectedTag.id === tag.id){
        return true;
      }
      return false;
    }

    render(){
      const { tag, tableColumns, isSelected } = this.props;
      return (
        <TableRow
          className={isSelected ? 'TagTableBodyRow__selected' : 'TagTableBodyRow__unselected'}
          onClick={this.handleRowClick}
        >
          {tableColumns.map(column =>
            <TagColumn
              key={column.id}
              tag={tag}
              column={column}
            />
          )}
        </TableRow>
      );
    }
  }
);

export default TagTableBodyRow;
