import React from 'react';
import { shallow } from 'enzyme';

import ColumnValueList from './ColumnValueList.js';

function setup(values = []){
  const props = {
    values
  };
  return shallow(<ColumnValueList {...props}/>);
}

describe('ColumnValueList', () => {
  it('renders without crashing', () => {
    const mountedList = setup();
  });
  it('renders an unordered list', () => {
    const mountedList = setup();
    const unorderedLists = mountedList.find('ul');
    expect(unorderedLists.length).toBe(1);
  });
});

describe('When list of items is passed to SelectedPropertyList', () => {
  let mountedList;
  let lengthOfItems;
  beforeEach(() => {
    const items = [
      {name: 'item 1', id: 1},
      {name: 'item 2', id: 2},
      {name: 'item 3', id: 3}
    ];
    mountedList = setup(items);
    lengthOfItems = items.length;
  });
  it('renders items passed to it as props', () => {
    const items = mountedList.find('li');
    expect(items.length).toBe(lengthOfItems);
  });
});
