import React from 'react';
import PropTypes from 'prop-types';

const ColumnValueList = ({ values, listClassName }) => {
  return(
    <ul className={listClassName}>
      {values.map(object =>
        <li key={object.id}><p>{object.id}: {object.name}</p></li>
      )}
    </ul>
  );
}

ColumnValueList.propTypes = {
  values: PropTypes.array.isRequired,
  listClassName: PropTypes.string
};

export default ColumnValueList;
