import React, { Component } from 'react';
import { TableColumn } from 'react-md';

import Localize from '../../../Localize/Localize.js';
import './TagTableHeaderColumn.scss';

class TagTableHeaderColumn extends Component {
  handleColumnClick = () => {
    const { column } = this.props;
    this.props.sortColumns(column);
  }

  render(){
    const { column, sortingIcon } = this.props;
    const icon = sortingIcon && sortingIcon[column.id];
    const title = <Localize id={`tags.table.header.${column.name}`} />;
    return(
      <TableColumn onClick={this.handleColumnClick}>
        <p className="TagTableHeader__title">{title}</p>
        <p className="TagTableHeader__sortingIcon">{icon}</p>
      </TableColumn>
    );
  }
}


export default TagTableHeaderColumn;

/* joel.salminen@indoorinformatics.com */
