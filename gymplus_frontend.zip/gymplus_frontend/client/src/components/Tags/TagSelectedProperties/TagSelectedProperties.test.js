import React from 'react';
import { shallow } from 'enzyme';

import TagSelectedProperties from './TagSelectedProperties.js';
import SelectedPropertyList from './SelectedPropertyList.js';

const mockSelectedItems = {
  selectedPremises: {},
  selectedDevices: {},
  selectedCategories: {},
  selectedEquipment: {}
};

function setup(
  premise,
  device,
  category,
  equipment,
  showInstructions,
  selectedItems = mockSelectedItems
){
  const props = {
    premise,
    device,
    category,
    equipment,
    showInstructions,
    selectedItems
  };
  return shallow(<TagSelectedProperties {...props} />)
}

describe('TagSelectedProperties', () => {
  it('should render without crashing', () => {
    const wrapper = setup();
  });
});

describe('When none of premise, device, category or equipment are passed to TagSelectedProperties', () => {
  it('should not render SelectedPropertyList', () => {
    const wrapper = setup();
    const lists = wrapper.find(SelectedPropertyList);
    expect(lists.length).toEqual(0);
  });
});

describe('When premise is passed to TagSelectedProperties', () => {
  it('should render SelectedPropertyList', () => {
    const premise = [];
    const wrapper = setup(premise);
    const lists = wrapper.find(SelectedPropertyList);
    expect(lists.length).toEqual(1);
  });
});

describe('When premise and device are passed to TagSelectedProperties', () => {
  it('should render SelectedPropertyList', () => {
    const premise = [];
    const device = [];
    const wrapper = setup(premise, device);
    const lists = wrapper.find(SelectedPropertyList);
    expect(lists.length).toEqual(2);
  });
});

describe('When category and equipment are passed to TagSelectedProperties', () => {
  it('should render SelectedPropertyList', () => {
    const category = [];
    const equipment = [];
    const wrapper = setup(undefined, undefined, category, equipment);
    const lists = wrapper.find(SelectedPropertyList);
    expect(lists.length).toEqual(2);
  });
});
