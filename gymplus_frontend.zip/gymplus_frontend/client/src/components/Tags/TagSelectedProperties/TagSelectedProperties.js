import React, { Component } from 'react';
import PropTypes from 'prop-types';

import getAmountOfSelectedItems from '../../../utils/getAmountOfSelectedItems.js';
import Localize from '../../Localize/Localize.js';
import SelectedPropertyList from './SelectedPropertyList.js';
import './TagSelectedProperties.scss';

class TagSelectedProperties extends Component{
  state = {
    isItemsListExpanded: false
  };

  toggleIsItemsListExpanded = () => {
    this.setState(previousState => ({
      isItemsListExpanded: !previousState.isItemsListExpanded
    }));
  }

  checkIsInstructionVisible(){
    const isAnythingSelected = this.checkIsAnythingSelected();
    const { showInstructions } = this.props;
    return !isAnythingSelected && showInstructions;
  }

  checkIsAnythingSelected(){
    const propertyValues = this.getPropertyValues();
    const isAnythingSelected = propertyValues.includes(true);
    return isAnythingSelected;
  }

  getPropertyValues(){
    const {
      selectedPremises,
      selectedDevices,
      selectedCategories,
      selectedEquipment,
    } = this.props.selectedItems;
    const premiseValues = Object.values(selectedPremises);
    const deviceValues = Object.values(selectedDevices);
    const categoryValues = Object.values(selectedCategories);
    const equipmentValues = Object.values(selectedEquipment);
    const propertyValues = premiseValues.concat(deviceValues, categoryValues, equipmentValues);
    return propertyValues;
  }

  render(){
    const {
      selectedPremises,
      selectedDevices,
      selectedCategories,
      selectedEquipment,
    } = this.props.selectedItems;

    const isInstructionVisible = this.checkIsInstructionVisible();
    const { premise, device, category, equipment } = this.props;
    return(
      <div  className="TagSelectedProperties">
        {premise &&
          <div className="TagSelectedProperties__items">
            {this.renderSelectedItems(premise, selectedPremises)}
          </div>
        }
        {device &&
          <div className="TagSelectedProperties__items">
            {this.renderSelectedItems(device, selectedDevices)}
          </div>
        }

        {category &&
          <div className="TagSelectedProperties__items">
            {this.renderSelectedItems(category, selectedCategories)}
          </div>
        }

        {equipment &&
          <div className="TagSelectedProperties__items">
            {this.renderSelectedItems(equipment, selectedEquipment)}
          </div>
        }
        {isInstructionVisible &&
          <p className="TagSelectedProperties__instructions">
            <Localize id="tags.addTag.properties.instructions" />
          </p>
        }

      </div>
    );
  }

  getItemsToDisplay(allItems, selectedItems){
    const filteredItems = this.getFilteredItems(allItems, selectedItems);
    const firstFiveItems = this.getFirstFiveItems(filteredItems);
    const { isItemsListExpanded } = this.state;
    const itemsToDisplay = isItemsListExpanded ? filteredItems : firstFiveItems;
    return itemsToDisplay;
  }

  getFilteredItems(allItems, selectedItems){
    return allItems.filter(item => selectedItems[item.id]);
  }

  getFirstFiveItems(items){
    const firstFiveItems = items.slice(0, 6);
    return firstFiveItems;
  }

  getClassName(selectedItems){
    const shouldFadeOut = this.checkShouldFadeOut(selectedItems);
    const className = shouldFadeOut ? 'TagSelectedProperties__fadeOut': undefined;
    return className;
  }

  checkShouldFadeOut(selectedItems){
    const amountOfSelectedItems = getAmountOfSelectedItems(selectedItems);
    const isMoreThanFiveItemsSelected = amountOfSelectedItems > 5;
    const { isItemsListExpanded } = this.state;
    return (isMoreThanFiveItemsSelected && !isItemsListExpanded);
  }

  renderSelectedItems = (allItems, selectedItems) => {
    const itemsToDisplay = this.getItemsToDisplay(allItems, selectedItems);
    const listClassName = this.getClassName(selectedItems);
    return(
      <SelectedPropertyList
        items={itemsToDisplay}
        handleClick={this.toggleIsItemsListExpanded}
        listClassName={listClassName}
      />
    );
  }
}

TagSelectedProperties.propTypes = {
  selectedItems: PropTypes.object.isRequired,
  premise: PropTypes.array,
  device: PropTypes.array,
  category: PropTypes.array,
  equipment: PropTypes.array,
  showInstructions: PropTypes.bool
}

export default TagSelectedProperties;
