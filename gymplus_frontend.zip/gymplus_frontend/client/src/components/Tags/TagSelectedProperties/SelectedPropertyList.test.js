import React from 'react';
import { shallow } from 'enzyme';

import List from './SelectedPropertyList.js';

function setup(
  items = [],
  handleClick = () => {}
){
  const props = {
    items,
    handleClick
  };
  return shallow(<List {...props} />);
}

describe('SelectedPropertyList', () => {
  let mountedList;
  beforeEach(() => {
    mountedList = setup();
  });
  it('renders without crashing', () => {
    const mountedList = setup();
  });
  it('renders unordered list', () => {
    const unorderedLists = mountedList.find('ul');
    expect(unorderedLists.length).toBe(1);
  });
  it('calls a function passed to it', () => {
    const mockCallback = jest.fn();
    const mountedListWithCallback = setup([], mockCallback);
    mountedListWithCallback.find('ul').simulate('click');
    expect(mockCallback.mock.calls.length).toEqual(1);
  });
});

describe('When list of items is passed to SelectedPropertyList', () => {
  let mountedList;
  let lengthOfItems;
  beforeEach(() => {
    const items = [
      {name: 'item 1', id: 1},
      {name: 'item 2', id: 2},
      {name: 'item 3', id: 3}
    ];
    mountedList = setup(items);
    lengthOfItems = items.length;
  });
  it('renders items passed to it as props', () => {
    const items = mountedList.find('li');
    expect(items.length).toBe(lengthOfItems);
  });

});

describe('When props is not defined', () => {
  let mountedList;
  let lengthOfItems;
  beforeEach(() => {
    mountedList = setup();
    lengthOfItems = 0;
  });
  it('renders items passed to it as props', () => {
    const items = mountedList.find('li');
    expect(items.length).toBe(lengthOfItems);
  });
});
