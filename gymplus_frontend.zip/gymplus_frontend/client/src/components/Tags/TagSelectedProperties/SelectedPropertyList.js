import React from 'react';
import PropTypes from 'prop-types';

const SelectedPropertyList = ({ items, handleClick, listClassName }) => {
  return(
    <ul
      className={listClassName}
      onClick={handleClick}
    >
      {items.map(item => <li key={item.id}>{item.name}</li>)}
    </ul>
  );
}

SelectedPropertyList.propTypes = {
  items: PropTypes.array.isRequired,
  handleClick: PropTypes.func.isRequired,
  listClassName: PropTypes.string
};

/*
  className
*/

export default SelectedPropertyList;
