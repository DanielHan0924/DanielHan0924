import React, { Component } from 'react';
import { observer } from 'mobx-react';
import moment from "moment";
import propertyTypes from '../../../enumerators/propertyTypes.js';

import MultiSelectorGroup from '../TagMultiSelectorGroup/TagMultiSelectorGroup.js';
import InputFields from '../TagEditingInputFields/TagEditingInputFields.js';
import ControlButtons from '../TagEditingControlButtons/TagEditingControlButtons.js';
import DatePicker from '../../DatePicker/DatePicker.js'
import Localize from '../../Localize/Localize.js';
import IsActiveSwitch from '../TagEditingIsActiveSwitch/TagEditingIsActiveSwitch.js';
import TagStore from '../../../models/TagStore.js';
import TagSelectionStore from '../../../models/TagSelectionStore.js';
import './TagEditing.scss';

import ApiMiddleware from "../../../services/Api";
import Auth from "../../../services/Auth";
const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const TagEditing = observer(
  class TagEditing extends Component{
    state = {
      name: '',
      description: '',
      date: moment(),
      isActive: false,
      focused: false,
      errorMessage: '',
      premise: [],
      device: [],
      category: [],
      equipment: [],
      selectedPremises: {},
      selectedDevices: {},
      selectedCategories: {},
      selectedEquipment: {}
    }

    initializeSelectedItems = (data, type) => {
      const selectedProperties = {};
      data.map(object => selectedProperties[object.id] = false);
      const selectedPropertyType = this.getSelectedPropertyType(type);
      this.setState({ [selectedPropertyType]: selectedProperties });
    }

    getSelectedPropertyType(type){
      switch (type){
        case propertyTypes.PREMISE:
          return 'selectedPremises'
        case propertyTypes.DEVICE:
          return 'selectedDevices'
        case propertyTypes.CATEGORY:
          return 'selectedCategories'
        case propertyTypes.EQUIPMENT:
          return 'selectedEquipment'
        default:
          return null;
      }
    }

    updateSelectedProperties = (id, type) => {
      return(previousState => {
        const selectedProperties = Object.assign({}, previousState[type]);
        selectedProperties[id] = !selectedProperties[id];
        return { [type]: selectedProperties };
      });
    }

    toggleSelectedItem = (id, type) => {
      this.setState(this.updateSelectedProperties(id, type));
    }

    handleClearInputClick = () => {
      this.resetInputFields();
    }

    handleUpdateTagClick = () => {
      const isInputValid = this.validateInput();
      if (isInputValid){
        this.setState({ errorMessage: isInputValid });
        return;
      }
      const selectedItems = {
        selectedPremises: this.state.selectedPremises,
        selectedDevices: this.state.selectedDevices,
        selectedCategories: this.state.selectedCategories,
        selectedEquipment: this.state.selectedEquipment
      };

      const updatedTag = TagStore.generateUpdatedTag(
        this.state.name,
        this.state.description,
        this.state.date,
        this.state.isActive,
        selectedItems
      );
      TagStore.putTag(updatedTag);
      TagSelectionStore.resetTagSelections();
      TagStore.toggleIsEditing();
    }

    handleAddTagClick = () => {
      const isInputValid = this.validateInput();
      if (isInputValid){
        this.setState({ errorMessage: isInputValid });
        return;
      }

      const selectedItems = {
        selectedPremises: this.state.selectedPremises,
        selectedDevices: this.state.selectedDevices,
        selectedCategories: this.state.selectedCategories,
        selectedEquipment: this.state.selectedEquipment
      };
      const formattedDate = this.state.date.format('YYYY-MM-DD');
      const newTag = TagStore.generateNewTag(
        this.state.name,
        this.state.description,
        formattedDate,
        this.state.isActive,
        selectedItems
      );
      TagStore.postTag(newTag);
      this.resetInputFields();
    }

    validateInput = () => {
      const {
        name,
        description,
      } = this.state;

      if (name === ''){
        return <Localize id="tags.addTag.nameError" />;
      }
      if (description === ''){
        return <Localize id="tags.addTag.descriptionError" />;
      }
      if (!this.checkIsAnyPremiseSelected()){
        return <Localize id="tags.addTag.premiseError" />;
      }
      return null;
    }

    checkIsAnyPremiseSelected(){
      const { selectedPremises } = this.state;
      return Object.values(selectedPremises).includes(true);
    }

    resetInputFields = () => {
      this.setState({
        name: '',
        description: '',
        date: moment(),
        errorMessage: '',
        isActive: false
      });
      this.resetAllSelectedItems();
    };

    resetAllSelectedItems = () => {
      const { premise, device, category, equipment } = this.state;
      this.initializeSelectedItems(premise, 'premise');
      this.initializeSelectedItems(device, 'device');
      this.initializeSelectedItems(category, 'category');
      this.initializeSelectedItems(equipment, 'equipment');
    }

    handleNameChange = (evt) => {
      this.setState({ name: evt.target.value });
    }
    handleDescriptionChange = (evt) => {
      this.setState({ description: evt.target.value });
    }
    handleDateChange = (date) => {
      this.setState({ date });
    }
    handleFocusChange = ({ focused }) => {
      this.setState({ focused });
    }

    toggleIsActive = (isActive) => {
      this.setState(prevState => ({
        isActive: !prevState.isActive
      }));
    }

    componentDidMount(){
      this.fetchProperties('premise');
      this.fetchProperties('device');
      this.fetchProperties('category');
      this.fetchProperties('equipment');
      this.setSelectedTagValuesToEditingView();
    }

    setSelectedTagValuesToEditingView(){
      const { isEditing } = this.props;
      if(!isEditing){
        return;
      }
      this.setDataFromSelectedTag();
      this.setSelectedItemsFromSelectedTag();
    }

    setDataFromSelectedTag = () => {
      const {
        name,
        description,
        timestamp_activated,
        ab_active,
      } = TagSelectionStore.selectedTag;

      const date = moment(timestamp_activated);
      this.setState({
        name,
        description,
        date,
        isActive: ab_active
      });
    }

    setSelectedItemsFromSelectedTag(){
      const {
        premise_id,
        device_id,
        category_id,
        equipment_id
      } = TagSelectionStore.selectedTag;

      this.setSelectedItems(premise_id, 'selectedPremises');
      this.setSelectedItems(device_id, 'selectedDevices');
      this.setSelectedItems(category_id, 'selectedCategories');
      this.setSelectedItems(equipment_id, 'selectedEquipment');
    }

    setSelectedItems = (ids, type) => {
      if(!ids[0]){
        return;
      }
      this.setState(this.setSelectedItemsToState(ids, type));
    }

    setSelectedItemsToState = (ids, type) => {
      return previousState => {
        const selectedItems = Object.assign({}, previousState[type]);
        ids.forEach(id => {
          selectedItems[id] = true;
        });
        return { ...previousState, [type]: selectedItems };
      }
    }

    fetchProperties = (type) => {
      const property = TagStore[type];
      if(property.length){
        this.setState({ [type]: property });
        this.initializeSelectedItems(property, type);
        return;
      }
      api
        .get(`/${type}`)
        .then(response => {
          const { data } = response;
          this.setState({ [type]: data });
          this.initializeSelectedItems(data, type);
      });
    }

    render(){
      const { isEditing } = this.props;
      const selectedItems = {
        selectedPremises: this.state.selectedPremises,
        selectedDevices: this.state.selectedDevices,
        selectedCategories: this.state.selectedCategories,
        selectedEquipment: this.state.selectedEquipment
      };

      return(
        <div className="TagEditing">
          <InputFields
            name={this.state.name}
            description={this.state.description}
            handleNameChange={this.handleNameChange}
            handleDescriptionChange={this.handleDescriptionChange}
          />
          <DatePicker
            date={this.state.date}
            focused={this.state.focused}
            onDateChange={this.handleDateChange}
            onFocusChange={this.handleFocusChange}
          />

          <IsActiveSwitch
            isActive={this.state.isActive}
            toggleIsActive={this.toggleIsActive}
          />

          <MultiSelectorGroup
            toggleSelectedItem={this.toggleSelectedItem}
            initializeSelectedItems={this.initializeSelectedItems}
            selectedItems={selectedItems}
            premise={this.state.premise}
            device={this.state.device}
            category={this.state.category}
            equipment={this.state.equipment}
          />
          <ControlButtons
            handleAddTag={this.handleAddTagClick}
            handleClearInput={this.handleClearInputClick}
            handleCancel={this.props.handleCancel}
            handleTagUpdate={this.handleUpdateTagClick}
            isEditing={isEditing}
          />
          <p className="TagAddingView__errorMessage">{this.state.errorMessage}</p>

        </div>
      );
    }
  }
);

export default TagEditing;
