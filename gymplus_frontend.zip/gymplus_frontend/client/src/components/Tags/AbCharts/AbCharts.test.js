import React from 'react';
import { shallow } from 'enzyme';

import AbCharts from './AbCharts.js';
import TagAbChart from '../TagAbChart/TagAbChart.js';

describe('AbCharts', () => {
  let mountedAbCharts;
  beforeEach(() => {
    mountedAbCharts = shallow(<AbCharts />);
  });
  it('should render without crashing', () => {
    shallow(<AbCharts />);
  });
  it('should render a h3 header', () => {
    const headers = mountedAbCharts.find('h3');
    expect(headers.length).toEqual(1);
  });
  it('should render TagAbChart', () => {
    const headers = mountedAbCharts.find(TagAbChart);
    expect(headers.length).toEqual(1);
  });
});
