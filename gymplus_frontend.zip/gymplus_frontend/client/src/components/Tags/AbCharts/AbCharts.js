import React from 'react';

import Localize from '../../Localize/Localize.js';
import TagAbChart from '../TagAbChart/TagAbChart.js';

const AbCharts = ({ props }) => {
  const title = <Localize id="tags.abChart.title" />;

  return(
    <div className="AbCharts">
      <h3>{title}</h3>
      <div className="SingleTagView__TagAbChart">
        <TagAbChart />
      </div>
    </div>
  );
}

export default AbCharts;
