import React, { Component } from 'react';
import { injectIntl } from 'react-intl';
import PropTypes from 'prop-types';

import Button from '../../Button/Button.js';

class SingleTagViewControls extends Component {
  render(){
    const { formatMessage } = this.props.intl;
    const editButtonText = formatMessage({ id: 'tags.singleTag.button.editTag' });
    const editIcon = <i className="fa fa-edit fa-lg"></i>;
    const deleteButtonText = formatMessage({ id: 'tags.singleTag.button.deleteTag' });
    const deleteIcon = <i className="fa fa-trash-o fa-lg"></i>;

    return(
      <div className="SingleTagViewControls">
        <Button
          value={editButtonText}
          onClick={this.props.handleEditClick}
          icon={editIcon}
        />
        <Button
          value={deleteButtonText}
          onClick={this.props.handleDeleteClick}
          icon={deleteIcon}
        />
      </div>
    );
  }
}

SingleTagViewControls.propTypes = {
  handleEditClick: PropTypes.func.isRequired
}


export default injectIntl(SingleTagViewControls);
