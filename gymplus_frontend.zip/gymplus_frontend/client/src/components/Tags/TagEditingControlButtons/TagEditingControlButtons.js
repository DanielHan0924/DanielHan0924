import React from 'react';
import PropTypes from 'prop-types';
import { FontIcon } from "react-md";

import Localize from '../../Localize/Localize.js';
import Button from '../../Button/Button.js';
import './TagEditingControlButtons.scss';

const TagEditingControlButtons = ({ isEditing, handleClearInput, handleTagUpdate, handleCancel, handleAddTag }) => {
  const clearButtonText = <Localize id="tags.addTag.button.clear" />;
  const clearIcon = <i className="fa fa-times fa-lg"></i>;

  if(isEditing){
    const saveButtonText = <Localize id="tags.addTag.button.saveChanges" />;
    const saveIcon = <i className="fa fa-save fa-lg"></i>;
    const cancelButtonText = <Localize id="tags.addTag.button.cancelEditing" />;
    const cancelIcon = <i className="fa fa-ban fa-lg"></i>;

    return (
      <div className="TagEditingControlButtons">
        <Button
          onClick={handleTagUpdate}
          value={saveButtonText}
          icon={saveIcon}
        />
        <Button
          onClick={handleClearInput}
          value={clearButtonText}
          icon={clearIcon}
        />
        <Button
          onClick={handleCancel}
          value={cancelButtonText}
          icon={cancelIcon}
        />
      </div>
    );
  }
  const addTagButtonText = <Localize id="tags.addTag.button.addTag" />;
  const addIcon = <FontIcon className="icon">add_circle</FontIcon>;

  return(
    <div className="TagEditingControlButtons">
      <Button
        onClick={handleAddTag}
        value={addTagButtonText}
        icon={addIcon}
      />
      <Button
        onClick={handleClearInput}
        value={clearButtonText}
        icon={clearIcon}
      />
    </div>
  );
}

TagEditingControlButtons.propTypes = {
  handleClearInput: PropTypes.func.isRequired,
  isEditing: PropTypes.bool,
  handleTagUpdate: PropTypes.func,
  handleCancel: PropTypes.func,
  handleAddTag: PropTypes.func
}

export default TagEditingControlButtons;
