import React from 'react';
import { shallow } from 'enzyme';

import TagEditingControlButtons from './TagEditingControlButtons.js';
import Button from '../../Button/Button.js';

function setup(
  isEditing = false,
  handleClearInput = () => {},
  handleTagUpdate = () => {},
  handleCancel = () => {},
  handleAddTag = () => {}
){
  const props = {
    isEditing,
    handleClearInput,
    handleTagUpdate,
    handleCancel,
    handleAddTag
  };
  return shallow(<TagEditingControlButtons {...props} />);
}

describe('TagEditingControlButtons', () => {
  let wrapper;
  beforeEach(() => {
    wrapper = setup();
  });
  it('should render without crashing', () => {
    const wrapper = setup();
  });
});

describe('When isEditing props is true', () => {
  it('should render three Buttons', () => {
    const isEditing = true;
    const wrapper = setup(isEditing);
    const buttons = wrapper.find(Button);
    expect(buttons.length).toEqual(3);
  });
});

describe('When isEditing props is false', () => {
  it('should render three Buttons', () => {
    const isEditing = false;
    const wrapper = setup(isEditing);
    const buttons = wrapper.find(Button);
    expect(buttons.length).toEqual(2);
  });
});
