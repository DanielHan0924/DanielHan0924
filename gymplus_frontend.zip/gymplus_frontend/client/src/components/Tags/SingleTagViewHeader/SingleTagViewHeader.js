import React from 'react';
import PropTypes from 'prop-types';

const SingleTagViewHeader = ({ tag }) => {
  return(
    <div className="SingleTagViewHeader">
      <h2 className="SingleTagViewHeader__name">{tag.name}</h2>
      <h3 className="SingleTagViewHeader__description">{tag.description}</h3>
    </div>
  );
}

SingleTagViewHeader.propTypes = {
  tag: PropTypes.object.isRequired
};

export default SingleTagViewHeader;
