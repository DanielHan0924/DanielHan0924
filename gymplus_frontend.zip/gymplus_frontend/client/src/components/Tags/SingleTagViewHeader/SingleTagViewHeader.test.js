import React from 'react';
import { shallow } from 'enzyme';

import SingleTagViewHeader from './SingleTagViewHeader.js';

function setup(name = '', description = ''){
  const props = {
    tag: {
      name,
      description
    }
  };
  return shallow(<SingleTagViewHeader {...props}/>);
}

describe('SingleTagViewHeader', () => {
  let mountedHeader;
  let name;
  let description;
  beforeEach(() => {
    name = 'testName';
    description = 'testDescription';
    mountedHeader = setup(name, description);
  });
  it('renders without crashing', () =>{
    const mountedHeader = setup();
  });
  it('renders a h2 header', () => {
    const h2Headers = mountedHeader.find('h2');
    expect(h2Headers.length).toBe(1);
  });
  it('renders a h3 header', () => {
    const h2Headers = mountedHeader.find('h3');
    expect(h2Headers.length).toBe(1);
  });
  it('displays tag name', () => {
    const header = mountedHeader.find('.SingleTagViewHeader__name');
    expect(header.text()).toEqual(name);
  });
  it('displays tag description', () => {
    const header = mountedHeader.find('.SingleTagViewHeader__description');
    expect(header.text()).toEqual(description);
  });
});
