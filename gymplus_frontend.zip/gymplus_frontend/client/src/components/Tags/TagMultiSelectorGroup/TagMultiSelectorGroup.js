import React, { Component } from 'react';
import { injectIntl } from 'react-intl';
import MediaQuery from 'react-responsive';

import MultiSelector from '../../MultiSelector/MultiSelector.js';
import SelectedProperties from '../TagSelectedProperties/TagSelectedProperties.js';
import './TagMultiSelectorGroup.scss';

class TagMultiSelectorGroup extends Component{

  getFilteredDevices(devicesToFilter = this.props.device){
    const { selectedPremises } = this.props.selectedItems;
    const filteredDevices = devicesToFilter.filter(device => {
      const premiseId = device.premise_id;
      return selectedPremises[premiseId];
    });
    return filteredDevices;
  }

  getFilteredEquipment = () => {
    let filteredEquipment = [];

    if(this.checkAreAnyItemsSelected('selectedCategories')){
      const equipmentToFilter = this.filterEquipmentByDevice();
      filteredEquipment = this.filterEquipmentByCategory(equipmentToFilter);
    }
    else if(this.checkAreAnyItemsSelected('selectedDevices')){
      filteredEquipment = this.filterEquipmentByDevice();
    }
    else if(this.checkAreAnyItemsSelected('selectedPremises')){
      filteredEquipment = this.filterEquipmentByPremise();
    }
    return filteredEquipment;
  }

  filterEquipmentByCategory(equipmentToFilter = this.props.equipment){
    const { selectedCategories } = this.props.selectedItems;
    const filteredEquipment = equipmentToFilter.filter(equipment => {
      const equipmentCategoryId = equipment.equipment_category_id;

      return selectedCategories[equipmentCategoryId];
    });
    return filteredEquipment;
  }

  findCategory(filteredEquipment, category){
    const foundCategory = filteredEquipment.find(equipment => {
      const equipmentCategoryId = equipment.equipment_category_id;
      return equipmentCategoryId === category.id
    });
    return foundCategory;
  }

  checkAreAnyItemsSelected(type){
    const selectedItems = this.props.selectedItems[type];
    return Object.values(selectedItems).includes(true);
  }

  filterEquipmentByPremise(equipmentToFilter = this.props.equipment){
    const { selectedPremises } = this.props.selectedItems;

    const filteredEquipment = equipmentToFilter.filter(equipment => {
      const equipmentPremiseId = equipment.premise_id;
      return selectedPremises[equipmentPremiseId];
    });
    return filteredEquipment;
  }

  filterEquipmentByDevice = (equipmentToFilter = this.props.equipment) => {
    const areAnyDevicesSelected = this.checkAreAnyItemsSelected('selectedDevices');
    if (!areAnyDevicesSelected){
      return equipmentToFilter;
    }

    let filteredEquipment = [];
    equipmentToFilter.forEach(equipment => {
      const deviceLocation = equipment.device_id_location;
      let index = 1;

      while(deviceLocation[index]){
        const device = deviceLocation[index];
        const isValid = this.shouldEquipmentBeAdded(equipment, device, filteredEquipment);
        if(isValid){
          filteredEquipment.push(equipment);
        }
        index++;
      }

    });
    return filteredEquipment;
  }

  shouldEquipmentBeAdded(equipment, device, filteredEquipment){
    const { selectedDevices } = this.props.selectedItems;
    const deviceId = device.device_id;
    const isDeviceSelected = selectedDevices[deviceId];
    const isEquipmentAlreadyAdded = filteredEquipment.find(item => item.id === equipment.id);
    return (isDeviceSelected && !isEquipmentAlreadyAdded);
  }

  handlePremiseSelectorChange = (premiseId) => {
    this.props.toggleSelectedItem(premiseId, 'selectedPremises');
    const { device, category, equipment } = this.props;
    this.props.initializeSelectedItems(device, 'device');
    this.props.initializeSelectedItems(category, 'category');
    this.props.initializeSelectedItems(equipment, 'equipment');
  }
  handleDeviceSelectorChange = (deviceId) => {
    const { category, equipment } = this.props;
    this.props.toggleSelectedItem(deviceId, 'selectedDevices');
    this.props.initializeSelectedItems(category, 'category');
    this.props.initializeSelectedItems(equipment, 'equipment');
  }
  handleCategorySelectorChange = (categoryId) => {
    const { equipment } = this.props;
    this.props.toggleSelectedItem(categoryId, 'selectedCategories');
    this.props.initializeSelectedItems(equipment, 'equipment');
  }
  handleEquipmentSelectorChange = (equipmentId) => {
    this.props.toggleSelectedItem(equipmentId, 'selectedEquipment');
  }

  checkIsAnyPremiseSelected(){
    const { selectedPremises } = this.props.selectedItems;
    return Object.values(selectedPremises).includes(true);
  }

  render(){
    const { formatMessage } = this.props.intl;
    const {
      selectedPremises,
      selectedDevices,
      selectedCategories,
      selectedEquipment,
    } = this.props.selectedItems;

    const { premise, category } = this.props;
    const filteredDevices = this.getFilteredDevices();
    const filteredEquipment = this.getFilteredEquipment();
    const valueProperty = 'name';
    const categoryValueProperty = 'name_' + localStorage.getItem('gpLanguage');
    const premiseHeader = formatMessage({ id: "tags.table.header.premise_id" });
    const deviceHeader = formatMessage({ id: "tags.table.header.device_id" });
    const categoryHeader = formatMessage({ id: "tags.table.header.category_id" });
    const equipmentHeader = formatMessage({ id: "tags.table.header.equipment_id" });
    const isMultiSelectorDisabled = !this.checkIsAnyPremiseSelected();
    return(
      <div className="TagMultiSelectorGroup">
        <MultiSelector
          type="premise"
          items={premise}
          selectedItems={selectedPremises}
          onChange={this.handlePremiseSelectorChange}
          valueProperty={valueProperty}
          header={premiseHeader}
        />

        <MediaQuery query="(max-width: 699px)" >
          <SelectedProperties
            selectedItems={this.props.selectedItems}
            premise={premise}
          />
        </MediaQuery>

        <MultiSelector
          type="device"
          items={filteredDevices}
          selectedItems={selectedDevices}
          onChange={this.handleDeviceSelectorChange}
          valueProperty={valueProperty}
          disabled={isMultiSelectorDisabled}
          header={deviceHeader}
        />

        <MediaQuery query="(max-width: 699px)" >
          <SelectedProperties
            selectedItems={this.props.selectedItems}
            device={filteredDevices}
          />
        </MediaQuery>
        <MediaQuery query="(min-width: 700px) and (max-width: 1099px)">
          <SelectedProperties
            selectedItems={this.props.selectedItems}
            premise={premise}
            device={filteredDevices}
          />
        </MediaQuery>

        <MultiSelector
          type="category"
          items={category}
          selectedItems={selectedCategories}
          onChange={this.handleCategorySelectorChange}
          valueProperty={categoryValueProperty}
          disabled={isMultiSelectorDisabled}
          header={categoryHeader}
        />

        <MediaQuery query="(max-width: 699px)" >
          <SelectedProperties
            selectedItems={this.props.selectedItems}
            category={category}
          />
        </MediaQuery>

        <MultiSelector
          type="equipment"
          items={filteredEquipment}
          selectedItems={selectedEquipment}
          onChange={this.handleEquipmentSelectorChange}
          valueProperty={valueProperty}
          disabled={isMultiSelectorDisabled}
          header={equipmentHeader}
        />

        <MediaQuery query="(max-width: 699px)" >
          <SelectedProperties
            selectedItems={this.props.selectedItems}
            equipment={filteredEquipment}
            showInstructions
          />
        </MediaQuery>

        <MediaQuery query="(min-width: 700px) and (max-width: 1099px)">
          <SelectedProperties
            selectedItems={this.props.selectedItems}
            category={category}
            equipment={filteredEquipment}
            showInstructions
          />
        </MediaQuery>

        <MediaQuery query="(min-width: 1100px)">
          <SelectedProperties
            selectedItems={this.props.selectedItems}
            premise={premise}
            device={filteredDevices}
            category={category}
            equipment={filteredEquipment}
            showInstructions
          />
        </MediaQuery>

      </div>
    );
  }

}


export default injectIntl(TagMultiSelectorGroup);

/* joel.salminen@indoorinformatics.com */
