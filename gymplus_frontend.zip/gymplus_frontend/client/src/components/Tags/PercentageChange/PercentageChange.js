import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { DataTable } from 'react-md';

import PercentageChangeHeader from './PercentageChangeHeader/PercentageChangeHeader.js';
import PercentageChangeBody from './PercentageChangeBody/PercentageChangeBody.js';
import TagSelectionStore from '../../../models/TagSelectionStore.js';
import './PercentageChange.scss'

const PercentageChange = observer(
  class PercentageChange extends Component {
    render(){
      const { selectedTag, timeSpanSelections, tagToDateTimespan } = TagSelectionStore;
      return(
        <div className="SingleTagView__PercentageChange">
          <DataTable
            baseId="PercentageChange"
            className="PercentageChange"
          >
            <PercentageChangeHeader />
            <PercentageChangeBody
              selectedTag={selectedTag}
              timeSpanSelections={timeSpanSelections}
              tagToDateTimespan={tagToDateTimespan}
            />
          </DataTable>
        </div>
      );
    }
  }
);


export default PercentageChange;
