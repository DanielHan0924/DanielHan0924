import React from 'react';
import { shallow } from 'enzyme';
import { TableRow, TableColumn } from 'react-md';

import PercentageChangeBodyRow from './PercentageChangeBodyRow.js';

function setup(
  relativeDifference = [0, 0, 0],
  isSelected = false,
  timespan = 0,
  meanA = [0, 0, 0],
  meanB = [0, 0, 0],
  tagToDateTimespan = 0
){
  const props = {
    timespan,
    meanA,
    meanB,
    relativeDifference,
    isSelected,
    tagToDateTimespan
  };
  return shallow(<PercentageChangeBodyRow {...props}/>);
}

describe('PercentageChangeBodyRow', () => {
  let handleRowClickMock;
  let mountedComponent;

  beforeEach(() => {
    handleRowClickMock = jest.spyOn(PercentageChangeBodyRow.prototype, 'handleRowClick');
    mountedComponent = setup();
  });
  it('should render without crashing', () => {
    const mountedComponent = setup();
  });
  it('should render a TableRow', () => {
    const tableRows = mountedComponent.find(TableRow);
    expect(tableRows.length).toEqual(1);
  });
  it('should render four TableColumns', () => {
    const tableColumns = mountedComponent.find(TableColumn);
    expect(tableColumns.length).toEqual(4);
  });
  it('should render four paragraphs', () => {
    const paragraphs = mountedComponent.find('p');
    expect(paragraphs.length).toEqual(4);
  });
  it('should call handleRowClick when clicked', () => {
    expect(handleRowClickMock).not.toHaveBeenCalled();
    mountedComponent.find(TableRow).simulate('click');
    expect(handleRowClickMock).toHaveBeenCalled();
  });
});

describe('PercentageChangeBodyRow getSignCharacter()', () => {
  it('should return a plus sign when the second value of relativeDifference is greater than 0', () => {
    const relativeDifference = [0, 500, 0];
    const mountedComponent = setup(relativeDifference);
    const sign = mountedComponent.instance().getSignCharacter();
    expect(sign).toEqual('+');
  });
  it('should return an empty string when the second value of relativeDifference is less than 0', () => {
    const relativeDifference = [0, -200, 0];
    const mountedComponent = setup(relativeDifference);
    const sign = mountedComponent.instance().getSignCharacter();
    expect(sign).toEqual('');
  });
});

describe('PercentageChangeBodyRow getRelativeDifferenceClass()', () => {
  it('should return positive class when the second value of relativeDifference is greater than 0', () => {
    const relativeDifference = [0, 500, 0];
    const mountedComponent = setup(relativeDifference);
    const className = mountedComponent.instance().getRelativeDifferenceClass();
    expect(className).toEqual('PercentageChangeBodyRow__relativeDifference--positive');
  });
  it('should return negative class when the second value of relativeDifference is less than 0', () => {
    const relativeDifference = [0, -0.01, 0];
    const mountedComponent = setup(relativeDifference);
    const className = mountedComponent.instance().getRelativeDifferenceClass();
    expect(className).toEqual('PercentageChangeBodyRow__relativeDifference--negative');
  });
});

describe('PercentageChangeBodyRow getTableRowClass()', () => {
  it('should return "PercentageChangeBodyRow__selected" when isSelected is true', () => {
    const isSelected = true;
    const mountedComponent = setup(undefined, isSelected);
    const tableRowClass = mountedComponent.instance().getTableRowClass();
    expect(tableRowClass).toEqual('PercentageChangeBodyRow__selected');
  });
  it('should return "PercentageChangeBodyRow__selected" when isSelected is false', () => {
    const isSelected = false;
    const mountedComponent = setup(undefined, isSelected);
    const tableRowClass = mountedComponent.instance().getTableRowClass();
    expect(tableRowClass).toEqual('PercentageChangeBodyRow__unselected');
  });
});
