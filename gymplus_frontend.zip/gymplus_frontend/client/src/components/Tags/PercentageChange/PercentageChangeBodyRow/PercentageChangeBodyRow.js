import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { TableRow, TableColumn } from 'react-md';

import getRoundedPercentages from '../../../../utils/getRoundedPercentages.js';
import Localize from '../../../Localize/Localize.js';
import TagSelectionStore from '../../../../models/TagSelectionStore.js';

import './PercentageChangeBodyRow.scss';

const PercentageChangeBodyRow = observer(
  class PercentageChangeBodyRow extends Component{
    constructor(props){
      super(props);
      this.handleRowClick = this.handleRowClick.bind(this);
    }
    handleRowClick(){
      const { timespan } = this.props;
      TagSelectionStore.handleTimeSpanSelection(timespan);
    }

    getSignCharacter(){
      const { relativeDifference } = this.props;
      if (relativeDifference[1] > 0){
        return '+';
      }
      return '';
    }

    getRelativeDifferenceClass(){
      const { relativeDifference } = this.props;
      if (relativeDifference[1] > 0){
        return 'PercentageChangeBodyRow__relativeDifference--positive';
      }
      return 'PercentageChangeBodyRow__relativeDifference--negative';
    }

    getTableRowClass(){
      const { isSelected } = this.props;
      return (
        isSelected ? 'PercentageChangeBodyRow__selected'
        : 'PercentageChangeBodyRow__unselected'
      );
    }

    render(){
      const {
        timespan,
        meanA,
        meanB,
        relativeDifference,
      } = this.props;
      const roundedMeanA = getRoundedPercentages(meanA);
      const roundedMeanB = getRoundedPercentages(meanB);
      const roundedRelativeDifference = getRoundedPercentages(relativeDifference[1]);

      const signRelativeDifference = this.getSignCharacter();
      const relativeDifferenceClass = this.getRelativeDifferenceClass();
      const tableRowClass = this.getTableRowClass();
      const formattedTimespan = <Localize id={`tags.percengateChange.timespan.${timespan}`} />;

      return(
        <TableRow
          className={tableRowClass}
          onClick={this.handleRowClick}
        >
          <TableColumn>
            <p>{this.props.tagToDateTimespan} {formattedTimespan}</p>
          </TableColumn>
          <TableColumn>
            <p>{`${roundedMeanA}%`}</p>
          </TableColumn>
          <TableColumn>
            <p>{`${roundedMeanB}%`}</p>
          </TableColumn>
          <TableColumn>
            <p className={relativeDifferenceClass}>
              {`${signRelativeDifference}${roundedRelativeDifference}%`}
            </p>
          </TableColumn>
        </TableRow>
      );
    }
  }
);

export default PercentageChangeBodyRow;
