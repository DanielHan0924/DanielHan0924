import React from 'react';
import { TableBody } from 'react-md';

import Row from '../PercentageChangeBodyRow/PercentageChangeBodyRow.js';

const PercentageChangeBody = (props) => {
  const { selectedTag, timeSpanSelections, tagToDateTimespan } = props;

  return(
    <TableBody key={selectedTag.id}
      selectableRows={false}
    >
      <Row
        timespan="oneWeek"
        meanA={selectedTag.d7_mean_a}
        meanB={selectedTag.d7_mean_b}
        relativeDifference={selectedTag.d7_reldiff}
        isSelected={timeSpanSelections.oneWeek}
      />
      <Row
        timespan="twoWeek"
        meanA={selectedTag.d14_mean_a}
        meanB={selectedTag.d14_mean_b}
        relativeDifference={selectedTag.d14_reldiff}
        isSelected={timeSpanSelections.twoWeek}
      />
      <Row
        timespan="oneMonth"
        meanA={selectedTag.d30_mean_a}
        meanB={selectedTag.d30_mean_b}
        relativeDifference={selectedTag.d30_reldiff}
        isSelected={timeSpanSelections.oneMonth}
      />
    </TableBody>
  );
}

export default PercentageChangeBody;
