import React from 'react';
import renderer from 'react-test-renderer';
import { shallow } from 'enzyme';
import PercentageChangeBody from './PercentageChangeBody.js';

const selectedTag = {
  ttd_mean_a: 1.1,
  ttd_mean_b: 1.2,
  ttd_reldiff: [0, 1, 2],
  d7_mean_a: 2.1,
  d7_mean_b: 2.2,
  d7_reldiff: [1, 2, 3],
  d30_mean_a: 3.1,
  d30_mean_b: 3.2,
  d30_reldiff: [3, 4, 5]
};

const timeSpanSelections = { oneWeek: false, oneMonth: false , tagToDate: false };
const tagToDateTimespan = 15;

function setup(){
  const props = {
    selectedTag,
    timeSpanSelections,
    tagToDateTimespan
  };
  return shallow(<PercentageChangeBody {...props} />)
}

describe.skip('PercentageChangeBody', () => {
  it('should render without crashing', () => {
    setup();
  });
  it('should render as expected', () => {
    const tree = renderer.create(setup()).toJSON();
    // expect(tree).toMatchSnapshot();
  });
});
