import React from 'react';
import { shallow } from 'enzyme';

import PercentageChange from './PercentageChange.js';
import PercentageChangeHeader from './PercentageChangeHeader/PercentageChangeHeader.js';
import PercentageChangeBody from './PercentageChangeBody/PercentageChangeBody.js';

describe('PercentageChange', () => {
  let mountedComponent;
  beforeEach(() => {
    mountedComponent = shallow(<PercentageChange />);
  });
  it('should render without crashing', () => {
    shallow(<PercentageChange />);
  });
  it('should render PercentageChangeHeader', () => {
    const headers = mountedComponent.find(PercentageChangeHeader);
    expect(headers.length).toEqual(1);
  });
  it('should render PercentageChangeBody', () => {
    const bodies = mountedComponent.find(PercentageChangeBody);
    expect(bodies.length).toEqual(1);
  });
});
