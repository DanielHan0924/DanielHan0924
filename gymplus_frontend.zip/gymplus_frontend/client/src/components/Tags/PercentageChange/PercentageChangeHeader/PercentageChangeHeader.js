import React from 'react';
import { injectIntl } from 'react-intl';

import { TableHeader, TableColumn, TableRow } from 'react-md';

const PercentageChangeHeader = (props) => {
  const { formatMessage } = props.intl;
  const columnTimespan = formatMessage({ id: 'tags.percengateChange.header.timespan' });
  const columnBefore = formatMessage({ id: 'tags.percengateChange.header.before' });
  const columnAfter = formatMessage({ id: 'tags.percengateChange.header.after' });
  const columnRelativeDifference = formatMessage({ id: 'tags.percengateChange.header.relativeDifference' });
  return(
    <TableHeader>
      <TableRow>
        <TableColumn>
          <p>{columnTimespan}</p>
        </TableColumn>
        <TableColumn>
          <p>{columnBefore}</p>
        </TableColumn>
        <TableColumn>
          <p>{columnAfter}</p>
        </TableColumn>
        <TableColumn>
          <p>{columnRelativeDifference}</p>
        </TableColumn>
      </TableRow>
    </TableHeader>
  );
}

export default injectIntl(PercentageChangeHeader);
