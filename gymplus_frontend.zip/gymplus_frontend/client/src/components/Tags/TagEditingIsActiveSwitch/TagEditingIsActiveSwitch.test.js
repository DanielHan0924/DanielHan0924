import React from 'react';
import { shallow } from 'enzyme';
import { SelectionControl } from 'react-md';

import TagEditingIsActiveSwitch from './TagEditingIsActiveSwitch.js';

function setup(isActive = false, toggleIsActive = () => {}){
  const props = {
    isActive,
    toggleIsActive
  };
  return shallow(<TagEditingIsActiveSwitch {...props} />)
}

describe('TagEditingIsActiveSwitch', () => {
  let wrapper;
  beforeEach(() => {
    wrapper = setup();
  });
  it('should render without crashing', () => {
    const wrapper = setup();
  });
  it('should render a label', () => {
    const labels = wrapper.find('label');
    expect(labels.length).toEqual(1);
  });
  it('should render SelectionControl', () => {
    const selectionControls = wrapper.find(SelectionControl);
    expect(selectionControls.length).toEqual(1);
  });

});
