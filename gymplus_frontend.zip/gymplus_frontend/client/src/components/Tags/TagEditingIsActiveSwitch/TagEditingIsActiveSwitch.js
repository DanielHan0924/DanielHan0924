import React from 'react';
import PropTypes from 'prop-types';
import { SelectionControl } from 'react-md';

import Localize from '../../Localize/Localize.js';
import './TagEditingIsActiveSwitch.scss';

const TagEditingIsActiveSwitch = ({ isActive, toggleIsActive }) => {
  const titleText = <Localize id="tags.table.header.ab_active" />;
  const enabledText = <Localize id="tags.table.body.monitoring.enabled" />;
  const disabledText = <Localize id="tags.table.body.monitoring.disabled" />;
  const labelText = isActive ? enabledText: disabledText;

  return(
    <div className="TagEditingIsActiveSwitch__container">
      <label><p>{titleText}:</p></label>
      <div className="TagEditingIsActiveSwitch">
        <SelectionControl
          id="switchActive"
          type="switch"
          name="active"
          label={labelText}
          checked={isActive}
          onChange={toggleIsActive}
        />
      </div>

    </div>
  );
}

TagEditingIsActiveSwitch.propTypes = {
  isActive: PropTypes.bool.isRequired,
  toggleIsActive: PropTypes.func.isRequired
}

export default TagEditingIsActiveSwitch;
