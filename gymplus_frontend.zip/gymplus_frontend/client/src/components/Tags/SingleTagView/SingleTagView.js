import React, { Component } from 'react';
import { observer } from 'mobx-react';

import CloseButton from '../../CloseButton/CloseButton.js';
import TagEditing from '../TagEditing/TagEditing.js';
import SingleTagViewHeader from '../SingleTagViewHeader/SingleTagViewHeader.js';
import SingleTagViewContent from '../SingleTagViewContent/SingleTagViewContent.js';
import TagStore from '../../../models/TagStore.js';
import TagSelectionStore from '../../../models/TagSelectionStore.js';
import LoadingAnimation from '../../LoadingAnimation/LoadingAnimation.js';
import Localize from '../../Localize/Localize.js';

import './SingleTagView.scss';

const SingleTagView = observer(
  class SingleTagView extends Component{
    handleEditClick = () => {
      TagStore.toggleIsEditing();
    }

    checkIsAllUtilizationDataLoaded(){
      if (
        TagSelectionStore.selectedUtilizationData.length &&
        TagSelectionStore.tagToDateUtilizationData.length &&
        TagSelectionStore.oneWeekUtilizationData.length &&
        TagSelectionStore.oneMonthUtilizationData.length
      ){
        return true;
      }
      return false;
    }

    checkIfErrorsOccured(){
      const { error } = TagSelectionStore;
      return error.utilization || error.ab;
    }

    render(){
      const { isEditing } = TagStore;
      const { selectedTag } = TagSelectionStore;
      const isLoaded = this.checkIsAllUtilizationDataLoaded();

      return (
        <div className="SingleTagView__container">
          {isEditing ? (
            <div className="SingleTagView">
              <CloseButton closeWindow={TagSelectionStore.resetTagSelections} />
              <TagEditing
                isEditing={true}
                handleCancel={this.handleEditClick}
              />
            </div>
          ) : (
            <div className="SingleTagView">
              <CloseButton closeWindow={TagSelectionStore.resetTagSelections} />
              <SingleTagViewHeader tag={selectedTag}/>

              {TagSelectionStore.error.utilization && <Localize id="tags.error.utilization" />}
              {TagSelectionStore.error.ab && <Localize id="tags.error.ab" />}

              {!isLoaded && !this.checkIfErrorsOccured() && <LoadingAnimation /> }
              <SingleTagViewContent visible={isLoaded && !this.checkIfErrorsOccured()}/>
            </div>
          )}

        </div>
      );
    }
  }
);


export default SingleTagView;
