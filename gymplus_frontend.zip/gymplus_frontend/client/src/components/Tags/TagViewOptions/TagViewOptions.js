import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { injectIntl } from 'react-intl';

import ToggleButton from '../../ToggleButton/ToggleButton.js';
import FilterInputField from '../../FilterInputField/FilterInputField.js';
import MultiSelector from '../../MultiSelector/MultiSelector.js';
import TagTableColumnStore from '../../../models/TagTableColumnStore.js';
import './TagViewOptions.scss';

export const TagViewOptions = observer(
  class TagViewOptions extends Component{
    formatColumns(){
      const { tableColumns } = TagTableColumnStore;
      const { formatMessage } = this.props.intl;
      const formattedColumns = tableColumns.map(column => Object.assign({}, column));
      formattedColumns.map(column =>
        column.name = formatMessage({ id: `tags.table.header.${column.name}`})
      );
      return formattedColumns;
    }

    render(){
      const { formatMessage } = this.props.intl;
      const toggleButtonSelectedText = formatMessage({ id: 'tags.options.toggleButton.selected' });
      const toggleButtonUnelectedText = formatMessage({ id: 'tags.options.toggleButton.unselected' });

      const { ignoreColumnVisibility } = this.props;

      const { selectedColumns } = TagTableColumnStore;
      const formattedColumns = this.formatColumns();
      const columnSelectorHeaderText = formatMessage({ id: "tags.options.displayColumns" });


      return(
        <div className="TagViewOptions">
          <FilterInputField
            value={this.props.filterText}
            handleFilterTextChange={this.props.handleFilterTextChange}
            handleClearClick={this.props.handleClearFiltersClick}
          />
          <ToggleButton
            onClick={this.props.handleVisibilityChange}
            toggled={ignoreColumnVisibility}
            valueSelected={toggleButtonSelectedText}
            valueUnselected={toggleButtonUnelectedText}
          />
          <MultiSelector
            type="tagAttributes"
            selectedItems={selectedColumns}
            items={formattedColumns}
            onChange={TagTableColumnStore.toggleColumn}
            header={columnSelectorHeaderText}
          />
        </div>
      );
    }
  }
);

export default injectIntl(TagViewOptions);
