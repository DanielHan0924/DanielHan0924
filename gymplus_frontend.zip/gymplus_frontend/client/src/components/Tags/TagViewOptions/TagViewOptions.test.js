import React from 'react';
import { shallow } from 'enzyme';

import { TagViewOptions } from './TagViewOptions.js';
import ToggleButton from '../../ToggleButton/ToggleButton.js';
import FilterInputField from '../../FilterInputField/FilterInputField.js';
import MultiSelector from '../../MultiSelector/MultiSelector.js';

const intlMock = {
  formatMessage: () => {
    return 'outputMock'
  }
};

function setup(
  ignoreColumnVisibility = false,
  handleVisibilityChange = () => {},
  filterText,
  handleFilterTextChange,
  handleClearFiltersClick,
){
  const props = {
    ignoreColumnVisibility,
    filterText,
    handleFilterTextChange,
    handleClearFiltersClick,
    handleVisibilityChange,
    intl: intlMock
  };
  return shallow(<TagViewOptions {...props} />)
}

describe('TagViewOptions', () => {
  let wrapper;
  beforeEach(() => {
    wrapper = setup();
  });
  it('should render without crashing', () => {
    setup();
  });
  it('should render ToggleButton', () => {
    const toggleButtons = wrapper.find(ToggleButton);
    expect(toggleButtons.length).toEqual(1);
  });
  it('should render FilterInputField', () => {
    const filterInputFields = wrapper.find(FilterInputField);
    expect(filterInputFields.length).toEqual(1);
  });
  it('should render MultiSelector', () => {
    const multiSelectors = wrapper.find(MultiSelector);
    expect(multiSelectors.length).toEqual(1);
  });
});
