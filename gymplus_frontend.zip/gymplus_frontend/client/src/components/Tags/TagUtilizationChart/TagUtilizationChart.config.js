const chartGray = "#eef0f2";
const labelGray = "#656668";
const blueDark = "#3c73c8";
const black = "#000000";
const white = "#FFFFFF";

export default {
  chart: {
    height: 200,
    marginBottom: 50,
    marginTop: 25,
    type: "area",
  },
  title: {
    text: "",
  },
  subtitle: {
    text: ""
  },
  xAxis: {
    className: "highcharts-color-0",
    title: {
      text: null
    },
    categories: [],
    labels: {
      style: {
        color: "#656668",
        fontSize: "16px"
      }
    },
    gridLineColor: chartGray
  },
  yAxis: {
    min: 0,
    title: {
      text: "Utilization-%", // Will be overwritten by translation
      align: "high"

    },
    labels: {
      overflow: "justify",
      style: {
        color: labelGray,
        fontSize: "16px"
      },
      formatter() {
        return `${Math.round(this.value * 100 * 10) / 10}%`;
      }
    },
    gridLineColor: chartGray,
    lineColor: chartGray,
    tickColor: chartGray
  },
  tooltip: {
    valueSuffix: "%",
    followPointer: true,
    shadow: false,
    borderRadius: 0,
    backgroundColor: blueDark,
    borderColor: black,
    borderWidth: 1,
    style: {
      color: white,
      fontSize: "14px",
      letterSpacing: "1px"
    },
    formatter() {
      return `<b>${this.x}:</b> ${(this.y * 100).toFixed(2)} %`;
    }
  },
  plotOptions: {
    area:{
      marker: {
        enabled: false
      },
      events: {
        legendItemClick: function(){
          return false;
        }
      }
    }
  },
  /* The part that shows Series 1 at the bottom of the graph*/
  legend: {
    enabled: false
  },
  /* Highcharts.com - label */
  credits: {
    enabled: false
  },
  series: [
    {
      name: "Selected period", // Will be overwritten by translation
      data: [], // Will be populated by the widget
      dataLabels: {
        formatter() {
          return `${(this.y * 100).toFixed(2)} %`;
        }
      }
    }
  ]
};

/* joel.salminen@indoorinformatics.com */
