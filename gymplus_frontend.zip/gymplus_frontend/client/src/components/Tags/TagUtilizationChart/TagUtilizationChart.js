import React, { Component } from 'react';
import { observer } from 'mobx-react';
import _ from 'lodash';
import moment from 'moment';
import { injectIntl } from 'react-intl';

import TagSelectionStore from '../../../models/TagSelectionStore.js';

import config from './TagUtilizationChart.config.js';
const ReactHighcharts = require('react-highcharts');
require('highcharts-data')(ReactHighcharts.Highcharts);

const TagChart = observer(
  class TagChart extends Component{

    configureChart = (chartToConfigure) => {
      const chartConfig = _.cloneDeep(chartToConfigure);

      if (!this.isDataLoaded()){
        return chartConfig;
      }
      this.setYAxisTitle(chartConfig);
      this.setLabels(chartConfig);
      this.setTagLine(chartConfig);
      this.setChartTitle(chartConfig);
      this.setChartData(chartConfig);
      this.setLegend(chartConfig);
      return chartConfig;
    }

    isDataLoaded(){
      const { selectedUtilizationData } = TagSelectionStore;
      return selectedUtilizationData.length > 0;
    }

    setYAxisTitle(chartConfig){
      const { formatMessage } = this.props.intl;
      const titleText = formatMessage({ id: "widget.equipment.utilization" });
      chartConfig.yAxis.title.text = titleText;
    }

    setLabels(chartConfig){
      const { selectedLabels } = TagSelectionStore;
      const chartLabels = _.map(selectedLabels, timeRound => {
        return moment(timeRound).format('DD.MM');
      });
      _.extend(chartConfig, {
        xAxis: { categories: chartLabels }
      });
    }

    setTagLine = (chartConfig) => {
      const tagLineIndex = this.findTagLineIndex();
      chartConfig.xAxis.plotLines = [{
        color: 'black',
        dashStyle: 'dash',
        value: tagLineIndex,
        width: 2,
        zIndex: 5
      }];
    }

    findTagLineIndex(){
      const { selectedLabels } = TagSelectionStore;
      const selectedTagTimeStamp = TagSelectionStore.selectedTag.timestamp_activated;
      return selectedLabels.findIndex(label => {
        const labelDate = moment(label).format('YYYY-MM-DD');
        const selectedTagDate = moment(selectedTagTimeStamp).format('YYYY-MM-DD');
        return labelDate === selectedTagDate;
      });
    }

    setChartTitle(chartConfig){
      const title = TagSelectionStore.selectedTimeSpanName;
      _.extend(chartConfig, {
        title: {
          text: title,
          align: "left"
        }
      });
    }

    setChartData = (chartConfig) => {

      const colorChangingSeries = this.getColorChangingSeriesObject();
      /* emptySeries is used when displaying legend values */
      const emptySeries = this.getEmptySeries();
      _.extend(chartConfig, {
        series: [ colorChangingSeries, emptySeries ]
      });
    }

    getColorChangingSeriesObject = () => {
      const { selectedUtilizationData } = TagSelectionStore;
      const tagLineIndex = this.findTagLineIndex();
      return {
        name: 'before',
        data: selectedUtilizationData,
        zoneAxis: 'x',
        color: '#4a5056',
        zones: [{
          value: tagLineIndex,
          color: '#4a5056'
        },{
          color: '#3c73c8'
        }]
      }
    }

    getEmptySeries(){
      return {
        name: 'after',
        data: [],
        color: '#3c73c8'
      }
    }

    setLegend(chartConfig){
      const { formatMessage } = this.props.intl;

      _.extend(chartConfig, {
        legend: {
          enabled: true,
          floating: true,
          verticalAlign: 'top',
          align:'right',
          y: -10,
          labelFormatter: function(){
            return formatMessage({ id: `tags.abChart.series.name.${this.name}` });
          }
        }
      });
    }


    render(){
      const chartConfig = this.configureChart(config);
      return(
        <div className="SingleTagView__TagChart">
          <ReactHighcharts config={chartConfig} ref='chart' />
        </div>
      );
    }
  }
);

export default injectIntl(TagChart);
