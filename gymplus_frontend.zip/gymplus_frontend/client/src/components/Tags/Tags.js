import React from 'react';
import { ExpansionList } from 'react-md';

import Header from '../Header/Header.js';
import TagView from './TagView/TagView.js';
import TagAddingView from './TagAddingView/TagAddingView.js';
import './Tags.scss';

const Tags = (props) => {
  return(
    <div className="Tags">
      <Header {...props} setLanguage={props.setLanguage} />

      <ExpansionList>
        <TagView />
        <TagAddingView />
      </ExpansionList>
    </div>
  );
}

export default Tags;

/* joel.salminen@indoorinformatics.com */
