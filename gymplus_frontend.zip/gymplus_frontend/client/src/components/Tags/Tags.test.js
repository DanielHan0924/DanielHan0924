import React from 'react';
import { shallow } from 'enzyme';

import Tags from './Tags.js';
import Header from '../Header/Header.js';
import TagView from './TagView/TagView.js';
import TagAddingView from './TagAddingView/TagAddingView.js';

describe('Tags', () => {
  let wrapper;
  beforeEach(() => {
    wrapper = shallow(<Tags />);
  });
  it('should render without crashing', () => {
    const wrapper = shallow(<Tags />);
  });
  it('should render Header component', () => {
    const headers = wrapper.find(Header);
    expect(headers.length).toEqual(1);
  });
  it('should render TagView component', () => {
    const tagViews = wrapper.find(TagView);
    expect(tagViews.length).toEqual(1);
  });
  it('should render TagAddingView component', () => {
    const tagAddingViews = wrapper.find(TagAddingView);
    expect(tagAddingViews.length).toEqual(1);
  });
});
