import React from 'react';
import PropTypes from 'prop-types';
import { injectIntl } from 'react-intl';

import InputField from '../../InputField/InputField.js';
import './TagEditingInputFields.scss';

export const TagEditingInputFields = ({ name, description, handleNameChange, handleDescriptionChange, intl }) => {
  const { formatMessage } = intl;
  const nameTitle = formatMessage({ id: "tags.table.header.name" });
  const descriptionTitle = formatMessage({ id: "tags.table.header.description" });
  return(
    <div className="TagEditingInputFields">
      <InputField
        labelText={nameTitle}
        onChange={handleNameChange}
        value={name}
        placeholder={nameTitle}
        required
      />
      <InputField
        labelText={descriptionTitle}
        onChange={handleDescriptionChange}
        value={description}
        placeholder={descriptionTitle}
        required
      />
    </div>
  );
}

TagEditingInputFields.propTypes = {
  name: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  handleNameChange: PropTypes.func.isRequired,
  handleDescriptionChange: PropTypes.func.isRequired
};

export default injectIntl(TagEditingInputFields);
