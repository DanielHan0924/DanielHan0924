import React from 'react';
import { shallow } from 'enzyme';

import { TagEditingInputFields } from './TagEditingInputFields.js';
import InputField from '../../InputField/InputField.js';

const intlMock = {
  formatMessage: () => {
    return 'outputMock'
  }
}

function setup(name = '', description = '', handleNameChange = () => {}, handleDescriptionChange = () => {}){
  const props = {
    name,
    description,
    handleNameChange,
    handleDescriptionChange,
    intl: intlMock
  };
  return shallow(<TagEditingInputFields {...props} />)
}

describe('TagEditingInputFields', () => {
  let wrapper;
  beforeEach(() => {
    wrapper = setup();
  });
  it('should render without crashing', () => {
    const wrapper = setup();
  });
  it('should render two InputFields', () => {
    const inputFields = wrapper.find(InputField);
    expect(inputFields.length).toEqual(2);
  });
});
