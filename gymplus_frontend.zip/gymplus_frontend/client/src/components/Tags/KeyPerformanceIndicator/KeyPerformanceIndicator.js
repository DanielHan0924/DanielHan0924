import React from 'react';
import PropTypes from 'prop-types';

import Localize from '../../Localize/Localize.js';
import './KeyPerformanceIndicator.scss';

export const KeyPerformanceIndicator = ({ change, interval }) => {
  const titleText = <Localize id="tags.keyPerformanceIndicator.title" />;
  const changeText = <Localize id="tags.keyPerformanceIndicator.change" />;
  const intervalText = <Localize id="tags.keyPerformanceIndicator.interval" />;
  return (
    <div className="KeyPerformanceIndicator">
      <h3>{titleText}</h3>
      <p>{changeText}: {change}</p>
      <p>{intervalText}: {interval}</p>
    </div>
  );
}

KeyPerformanceIndicator.propTypes = {
  change: PropTypes.number.isRequired,
  interval: PropTypes.string.isRequired,
}


export default KeyPerformanceIndicator;
