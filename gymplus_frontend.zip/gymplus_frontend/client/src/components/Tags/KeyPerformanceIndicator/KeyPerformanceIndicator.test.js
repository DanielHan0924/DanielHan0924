import React from 'react';
import { shallow } from 'enzyme';

import { KeyPerformanceIndicator } from './KeyPerformanceIndicator.js';

function setup(change = 0, interval = '', intl = {}){
  const props = {
    change,
    interval
  }
  return shallow(<KeyPerformanceIndicator {...props}/>);
}

describe('KeyPerformanceIndicator', () => {
  let mountedComponent;
  beforeEach(() => {
    mountedComponent = setup();
  });
  it('renders without crashing', () => {
    const mountedComponent = setup();
  });
  it('renders two paragraphs', () => {
    const paragraphs = mountedComponent.find('p');
    expect(paragraphs.length).toEqual(2);
  });
  it('renders a header', () => {
    const headers = mountedComponent.find('h3');
    expect(headers.length).toEqual(1);
  });
});

describe('When KeyPerformanceIndicator is passed props', () => {
  let mountedComponent;
  let change;
  let interval;
  beforeEach(() => {
    change = 0.8;
    interval = '-1.1 - 2.1';
    mountedComponent = setup(change, interval);
  });
  it('displays change', () => {
    const firstParagraph = mountedComponent.find('p').first();
    expect(firstParagraph.text()).toEqual('<InjectIntl(Localize) />: ' + change);
  });
  it('displays interval', () => {
    const secondParagraph = mountedComponent.find('p').at(1);
    expect(secondParagraph.text()).toEqual('<InjectIntl(Localize) />: ' + interval);
  });
});
