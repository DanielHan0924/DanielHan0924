import React from 'react';
import { shallow } from 'enzyme';

import { MonetaryEstimation } from './MonetaryEstimation.js';

function setup(monetaryEstimate = 0, numberOfEquipment = 0, intl={}){
  const props = {
    monetaryEstimate,
    numberOfEquipment,
    intl
  }
  return shallow(<MonetaryEstimation {...props}/>);
}

describe('MonetaryEstimation', () => {
  let mountedComponent;
  beforeEach(() => {
    mountedComponent = setup();
  });
  it('renders without crashing', () => {
    setup();
  });
  it('displays two paragraphs', () => {
    const paragraphs = mountedComponent.find('p');
    expect(paragraphs.length).toEqual(2);
  });
});
