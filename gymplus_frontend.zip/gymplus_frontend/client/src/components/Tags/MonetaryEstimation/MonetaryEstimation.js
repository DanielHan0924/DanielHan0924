import React from 'react';
import PropTypes from 'prop-types';

import Localize from '../../Localize/Localize.js';
import Currency from '../../Currency/Currency.js';
import './MonetaryEstimation.scss';

export const MonetaryEstimation = ({ monetaryEstimate, numberOfEquipment }) => {
  const expectedValueOfEvent = <Localize id="tags.singleTag.expectedValueOfEvent" />;
  const explanation = <Localize id="tags.singleTag.expectedValueExplanation" />;
  return(
    <div className="MonetaryEstimation">
      <p>{expectedValueOfEvent}: <Currency amount={monetaryEstimate} /> {`(${numberOfEquipment} laitetta)`}</p>
      <p className="MonetaryEstimation__explanation">*{explanation}</p>
    </div>
  );
}

MonetaryEstimation.propTypes = {
  monetaryEstimate: PropTypes.number.isRequired,
  numberOfEquipment: PropTypes.number.isRequired,
}

export default MonetaryEstimation;
