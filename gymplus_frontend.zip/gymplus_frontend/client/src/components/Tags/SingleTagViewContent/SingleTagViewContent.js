import React, { Component } from 'react';
import { observer } from 'mobx-react';
import PropTypes from 'prop-types';
import { injectIntl } from 'react-intl';

import DeleteConfirmationContainer from '../../DeleteConfirmationContainer/DeleteConfirmationContainer.js';
import PercentageChange from '../PercentageChange/PercentageChange.js';
import TagUtilizationChart from '../TagUtilizationChart/TagUtilizationChart.js';
import MonetaryEstimation from '../MonetaryEstimation/MonetaryEstimation.js';
import KeyPerformanceIndicator from '../KeyPerformanceIndicator/KeyPerformanceIndicator.js';
import AbCharts from '../AbCharts/AbCharts.js';
import SingleTagViewControls from '../SingleTagViewControls/SingleTagViewControls.js';

import TagStore from '../../../models/TagStore.js';
import TagSelectionStore from '../../../models/TagSelectionStore.js';

const SingleTagViewContent = observer(
  class SingleTagViewContent extends Component{
    state = {
      isConfirmationVisible: false
    };

    handleEditClick = () => {
      TagStore.toggleIsEditing();
    }

    handleDeleteClick = () => {
      this.setState({ isConfirmationVisible: true });
    }

    handleOnHide = () => {
      this.setState({ isConfirmationVisible: false });
    }

    getMonetaryEstimate(){
      const unEditedEstimateList = TagSelectionStore.selectedTag.monetary_estimate;
      if (!unEditedEstimateList){
        return 0;
      }
      const rounedEstimate = Math.round(unEditedEstimateList[1]);
      return rounedEstimate;
    }

    getChange(){
      const { selectedTag } = TagSelectionStore;
      return Math.round(selectedTag.d14_reldiff[1] * 100) / 100;
    }

    getInterval(){
      const { selectedTag } = TagSelectionStore;
      const firstNumber = Math.round(selectedTag.d14_reldiff[0] * 100) / 100;
      const secondNumber = Math.round(selectedTag.d14_reldiff[2] * 100) / 100;
      return `${firstNumber} - ${secondNumber}`;
    }

    render(){
      const { formatMessage } = this.props.intl;
      const { selectedTag } = TagSelectionStore;
      const monetaryEstimate = this.getMonetaryEstimate();
      const numberOfEquipment = selectedTag.num_eq ? selectedTag.num_eq : 0;
      const change = this.getChange();
      const interval = this.getInterval();
      return(
        <div className="SingleTagViewContent">
          <div style={{ visibility: this.props.visible ? 'visible' : 'hidden' }}>
            <DeleteConfirmationContainer
              handleDelete={TagStore.deleteTag}
              handleOnHide={this.handleOnHide}
              visible={this.state.isConfirmationVisible}
            />
            <MonetaryEstimation
              monetaryEstimate={monetaryEstimate}
              numberOfEquipment={numberOfEquipment}
            />
            <div className="TableWrapper">
              <h3>{formatMessage({ id: 'tags.percengateChange.title' })}: </h3>
              <PercentageChange />
              <TagUtilizationChart />
            </div>
            <div className="PerformanceWrapper">
              <KeyPerformanceIndicator
                change={change}
                interval={interval}
              />
              <AbCharts />
            </div>
          </div>

          <SingleTagViewControls
            handleDeleteClick={this.handleDeleteClick}
            handleEditClick={this.handleEditClick}
          />
        </div>
      );
    }
  }

);
SingleTagViewContent.propTypes = {
  visible: PropTypes.bool.isRequired
}
export default injectIntl(SingleTagViewContent);
