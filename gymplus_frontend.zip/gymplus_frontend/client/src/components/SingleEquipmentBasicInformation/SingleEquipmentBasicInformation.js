import React, {Component} from 'react';
import { observer } from 'mobx-react';
import { injectIntl } from 'react-intl';
import moment from 'moment';

import SingleEquipmentStore from '../../models/SingleEquipmentStore.js';
import InformationTable from '../InformationTable/InformationTable.js';

const SingleEquipmentBasicInformation = observer (
  class SingleEquipmentBasicInformation extends Component {

    /* Get the name of the category */
    getCategoryName = () => {
      const foundCategory = this.findCategory();
      const localizedCategory = this.localizeCategoryName(foundCategory);
      return localizedCategory;
    }

    findCategory = () => {
      const { categories } = SingleEquipmentStore;
      const isLoadedInSingleEquipmentStore = categories.length >0;
      if (!isLoadedInSingleEquipmentStore){
        SingleEquipmentStore.fetchCategories();
      }

      const { equipment } = this.props;
      const foundCategory = categories.find(category => {
        return equipment.equipment_category_id_parent === category.id;
      });
      return foundCategory;
    }

    localizeCategoryName = (category) => {
      const languageType = Object.freeze({ FI: 'fi', EN: 'en' });
      if (localStorage.getItem('gpLanguage') === languageType.FI && category) {
        return category.name_fi;
      }
      else if (localStorage.getItem('gpLanguage') === languageType.EN && category){
        return category.name_de;
      }
      else {
        return null;
      }
    }


    render(){
      const { formatMessage } = this.props.intl;
      const categoryLabel = formatMessage({id: "infoView.header.category"});
      const brandLabel = formatMessage({id: "infoView.header.brand"});
      const purchaseDateLabel = formatMessage({id: "infoView.header.purchase_date"});
      const purchasePriceLabel = formatMessage({id: "infoView.header.purchase_price"});

      const categoryName = this.getCategoryName();
      const category = categoryName ? categoryName : '...';

      const {
        purchase_date,
        purchase_price,
        model
       } = this.props.equipment;
      const brand = model.brand.name;
      const date = moment(purchase_date.substring(0, 10)).format(formatMessage({ id: "date.format"}));
      const price = `${Math.round(purchase_price)}€`;



      return (
          <InformationTable
            value1={category}
            value2={brand}
            value3={date}
            value4={price}
            column1={categoryLabel}
            column2={brandLabel}
            column3={purchaseDateLabel}
            column4={purchasePriceLabel}
          />
      );
    }
  }
);


export default injectIntl(SingleEquipmentBasicInformation);

/* joel.salminen@indoorinformatics.com */
