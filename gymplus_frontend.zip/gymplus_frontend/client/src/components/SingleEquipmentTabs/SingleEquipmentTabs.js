import React from 'react';
import { injectIntl } from 'react-intl';
import { TabsContainer, Tabs, Tab  } from 'react-md';

import SingleAverageUtilization from '../Widgets/SingleAverageUtilization/SingleAverageUtilization.js';
import SingleDowUtilization from '../Widgets/SingleDowUtilization/SingleDowUtilization.js';

const SingleEquipmentTabs = (props) => {
  const { formatMessage } = props.intl;
  const timeSerieslabel = formatMessage({ id: "singleEquipmentView.tab.timeSeries"});
  const profileLabel = formatMessage({ id: "singleEquipmentView.tab.profile"});

  const { equipment } = props;
  return(
    <TabsContainer >
      <Tabs tabId="chartTab">
        <Tab label={timeSerieslabel}>

          <div className="SingleEquipmentView__chart">
            <SingleAverageUtilization equipment={equipment}/>
          </div>

        </Tab>
        <Tab label={profileLabel}>

          <div className="SingleEquipmentView__profile">
            <SingleDowUtilization equipment={equipment} />
          </div>

        </Tab>
      </Tabs>
    </TabsContainer>
  );
}

export default injectIntl(SingleEquipmentTabs);

/* joel.salminen@indoorinformatics.com */
