import React from 'react';
import ReactDOM from 'react-dom';
// import GymPlus from './GymPlus';

it('renders without crashing', () => {
  // const div = document.createElement('div');
  // ReactDOM.render(<GymPlus />, div);
  // ReactDOM.unmountComponentAtNode(div);
});
