import React from 'react';
import PropTypes from 'prop-types';
import { injectIntl } from 'react-intl';
import { SingleDatePicker } from "react-dates";
import moment from "moment";

import './DatePicker.scss';

const DatePicker = ({
    date,
    focused,
    onDateChange,
    onFocusChange,
    id,
    isOutsideRange = (date) => date >= moment().endOf("day"),
    intl,
    props
  }) => {
  const { formatMessage } = intl;
  const labelText = formatMessage({ id: "tags.table.header.timestamp_activated"});
  const displayFormat = `dd ${formatMessage({ id: 'date.format' })}`;
  return(
    <div className="DatePicker">
      <label><p>{labelText}: </p></label>
      <SingleDatePicker
        date={date}
        onDateChange={onDateChange}
        displayFormat={displayFormat}
        focused={focused}
        onFocusChange={onFocusChange}
        id={id}
        numberOfMonths={1}
        isOutsideRange={isOutsideRange}
        {...props}
      />
    </div>
  );
}

DatePicker.propTypes = {
  date: PropTypes.object.isRequired,
  focused: PropTypes.bool.isRequired,
  onDateChange: PropTypes.func.isRequired,
  onFocusChange: PropTypes.func.isRequired,
  id: PropTypes.string,
  isOutsideRange: PropTypes.func,
}

export default injectIntl(DatePicker);
