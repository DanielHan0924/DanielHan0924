import React from "react";

import { injectIntl } from "react-intl";
import { ExpansionList} from "react-md";
import { observer } from "mobx-react";
import "react-md/dist/react-md.green-blue.min.css";

import Header from "../Header/Header";
import Filter from "../Filter/Filter";

import HomeStore from "../../models/HomeStore";

import HotAndCold from "../Widgets/HotAndCold/HotAndCold";
import AverageUtilization from "../Widgets/AverageUtilization/AverageUtilization";
import BiggestChange from "../Widgets/BiggestChange/BiggestChange";
import BrandUtilization from "../Widgets/BrandUtilization/BrandUtilization";
import CategoryUtilization from "../Widgets/CategoryUtilization/CategoryUtilization";
import LoadingTipView from '../LoadingTipView/LoadingTipView';

const Home = observer(
  class Home extends React.Component {
    handleDimensionChange(groupBy, timePart, filterData) {
      HomeStore.reloadAvgWidget(timePart);
    }

    render() {
      const { formatMessage } = this.props.intl;

      HomeStore.fetchEquipmentData();
      HomeStore.fetchCategoryData();
      HomeStore.fetchBrandData();
      return (
        <div>
          <Header {...this.props} setLanguage={this.props.setLanguage} />
          <ExpansionList>
            <Filter basic={true} />

            <LoadingTipView intl={this.props.intl}/>

            <HotAndCold
              title={formatMessage({ id: "widget.hotAndCold.title" })}
              loading={HomeStore.loading}
              topData={HomeStore.hottestData}
              topLabels={HomeStore.hottestLabels}
              bottomData={HomeStore.coldestData}
              bottomLabels={HomeStore.coldestLabels}
            />
            <BiggestChange
              title={formatMessage({ id: "widget.biggestChange.title" })}
              loading={HomeStore.loading}
              equipmentData={HomeStore.equipmentData}
              compareEquipmentData={HomeStore.compareEquipmentData}
              equipments={HomeStore.equipments}
            />
            <AverageUtilization
              title={formatMessage({ id: "widget.averageUtilization.title" })}
              loading={HomeStore.avgChartDataLoading}
              chartData={HomeStore.avgChartData}
              chartLabels={HomeStore.avgChartLabels}
              avgGroupBy={HomeStore.avgGroupBy}
            />
            <BrandUtilization
              title={formatMessage({ id: "widget.brandUtilization.title" })}
              loading={HomeStore.loadingBrands}
              chartData={HomeStore.brandChartData}
              chartLabels={HomeStore.brandChartLabels}
            />
            <CategoryUtilization
              title={formatMessage({ id: "widget.categoryUtilization.title" })}
              loading={HomeStore.loadingCategories}
              chartData={HomeStore.categoryChartData}
              chartLabels={HomeStore.categoryChartLabels}
            />
          </ExpansionList>
        </div>
      );
    }
  }
);

export default injectIntl(Home);
