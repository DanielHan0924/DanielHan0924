import React, {Component} from 'react';
import { observer } from 'mobx-react';
import { DialogContainer } from 'react-md';

import LoadingTip from '../LoadingTip/LoadingTip';
import HomeStore from '../../models/HomeStore';
import LoadingTipStore from '../../models/LoadingTipStore';

import './LoadingTipView.scss';

const LoadingTipView = observer (
  class LoadingTipView extends Component {
    hideDialog = () => {
      LoadingTipStore.setIsVisible(false);
    }

    componentWillMount(){
      LoadingTipStore.setLanguage(this.props.intl.locale);
    }

    render(){
      const { isVisible, height, width } = LoadingTipStore;

      return (
        <div className="LoadingTipView">
          <DialogContainer
            id='loading-tips'
            visible={isVisible}
            title=''
            onHide={this.hideDialog}
            autosizeContent={true}
            focusOnMount={false}
            width={width}
            height={height}
          >
            <LoadingTip
              hideDialog={this.hideDialog}
              loaded={HomeStore.loaded}
              intl={this.props.intl}
            />

          </DialogContainer>
        </div>

      );
    }

  }
);



export default LoadingTipView;

/* joel.salminen@indoorinformatics.com */
