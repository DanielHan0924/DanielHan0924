import React from 'react';
import { shallow } from 'enzyme';

import Button from './Button.js';

function setup(value = '', onClick=()=>{}){
  const props = {
    value,
    icon: undefined,
    onClick
  };
  return shallow(<Button {...props}/>);
}

describe('Button', () => {
  let mountedButton;
  beforeEach(() => {
    mountedButton = setup();
  });
  it('renders without crashing', () => {
    setup();
  });
  it('renders a button', () => {
    const buttons = mountedButton.find('button');
    expect(buttons.length).toBe(1);
  });
  it('calls a function passed to it', () => {
    const mockCallback = jest.fn();
    const mountedButtonWithCallback = setup(undefined, mockCallback);
    mountedButtonWithCallback.find('button').simulate('click');
    expect(mockCallback.mock.calls.length).toBe(1);
  });
});

describe('When value is passed to Button', () => {
  let mountedButton;
  let value;
  beforeEach(() => {
    value = `testText`;
    mountedButton = setup(value);
  });
  it('displays buttonText', () => {
    const buttonName = mountedButton.find('button');
    expect(buttonName.text()).toBe(value);
  });
});
