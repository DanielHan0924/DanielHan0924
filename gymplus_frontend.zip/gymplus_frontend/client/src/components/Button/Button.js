import React from 'react';
import PropTypes from 'prop-types';

import './Button.scss';

const Button = ({ value, onClick, icon }) => {
  return(
    <button
      onClick={onClick}
      className="Button"
    >
      {value}{icon}
    </button>
  );
}

Button.propTypes = {
  value: PropTypes.oneOfType([
    PropTypes.object.isRequired,
    PropTypes.string.isRequired
  ]),
  onClick: PropTypes.func.isRequired,
  icon: PropTypes.object
};

export default Button;
