import React, { Component } from 'react';
import PropTypes from 'prop-types';

class Currency extends Component {
  getFormattedAmount(){
    const { amount } = this.props;
    return amount.toLocaleString() + '€';
  }

  render(){
    const formattedAmount = this.getFormattedAmount();
    return(
      <span>{formattedAmount}</span>
    );
  }
}

Currency.propTypes = {
  amount: PropTypes.number.isRequired
};

export default Currency;
