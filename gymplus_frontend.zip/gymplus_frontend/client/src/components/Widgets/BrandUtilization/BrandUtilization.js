import React from "react";

import { injectIntl, FormattedMessage } from "react-intl";
import { ExpansionPanel } from "react-md";
import _ from "lodash";

import FilterStore from "../../../models/FilterStore";

import loadingIcon from "../../../assets/images/loading.svg";
import starIcon from "../../../assets/images/star.svg";

import "./BrandUtilization.scss";

import config from "./BrandUtilization.config";

// 3rd party libs
const ReactHighcharts = require("react-highcharts");
require("highcharts-data")(ReactHighcharts.Highcharts);

const BrandUtilization = props => {
  const { formatMessage } = props.intl;

  const { startDate, endDate } = FilterStore;
  const period = `${startDate.format(
    formatMessage({ id: "date.format" })
  )} - ${endDate.format(formatMessage({ id: "date.format" }))}`;

  const chartConfig = _.clone(config);
  chartConfig.yAxis.title.text = formatMessage({
    id: "widget.equipment.utilization"
  });
  _.extend(chartConfig, {
    xAxis: { categories: props.chartLabels }
  });
  _.extend(chartConfig, {
    series: [{ data: props.chartData, color: "#3c73c8" }]
  });

  if (props.loading) {
    return (
      <ExpansionPanel
        label={props.title}
        secondaryLabel={period}
        className="Widget Widget--no-footer HotAndCold"
        columnWidths={props.columnWidths}
        focused={props.focused}
        defaultExpanded
      >
        <img
          src={loadingIcon}
          alt="Loading..."
          style={{
            position: "absolute",
            left: "50%",
            transform: "translateX(-50%)"
          }}
        />
      </ExpansionPanel>
    );
  }

  return (
    <ExpansionPanel
      label={props.title}
      secondaryLabel={period}
      className="Widget Widget--no-footer"
      columnWidths={props.columnWidths}
      focused={props.focused}
      defaultExpanded
    >
      <div className="BrandUtilization__title">
        <img src={starIcon} alt="" className="BrandUtilization__title-icon" />
        <FormattedMessage id="widget.brandUtilization.mostUsedBrands" />
      </div>
      <div className="BrandUtilization__chart">
        <ReactHighcharts config={chartConfig} neverReflow={true} id="chart1" />
      </div>
    </ExpansionPanel>
  );
};

export default injectIntl(BrandUtilization);
