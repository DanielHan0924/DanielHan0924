import React from "react";

import { FormattedMessage, injectIntl } from "react-intl";
import { ExpansionPanel } from "react-md";
import { observer } from "mobx-react";
import moment from "moment";
import _ from "lodash";

import Percentage from '../../Percentage/Percentage.js';
import FilterStore from "../../../models/FilterStore";

// Widget configuration
import config from "../EquipmentDetails/EquipmentDetails.config";

import "./BiggestChange.scss";
import IncreaseIcon from "../../../assets/images/increase.svg";
import DecreaseIcon from "../../../assets/images/decrease.svg";

import loadingIcon from "../../../assets/images/loading.svg";

const getPercentageChange = (oldNumber, newNumber) => {
  // Increase = New Number - Original Number
  var decreaseValue = newNumber - oldNumber;
  return Math.round(decreaseValue / oldNumber * 10 * 100) / 10;
};

const getOutputData = (equipmentData, compareData, equipments) => {
  const outputData = _.map(equipmentData, row => {
    let utilization = row.utilization;
    let compareUtilization = _.filter(compareData, {
      equipment_id: row.equipment_id
    });

    if (utilization === null || utilization === undefined) {
      utilization = "-";
    } else {
      utilization = Math.round(utilization * 100 * 10) / 10;
    }

    if (compareUtilization.length === 1) {
      compareUtilization = compareUtilization[0].utilization;
      compareUtilization = Math.round(compareUtilization * 100 * 10) / 10;
    } else {
      compareUtilization = "-";
    }

    let difference;
    if (compareUtilization === 0 && utilization) {
      difference = "1";
    } else if (compareUtilization === "-") {
      difference = "0";
    } else if (compareUtilization && utilization === 0) {
      difference = "1";
    } else if (compareUtilization && utilization === "-") {
      difference = "0";
    } else {
      difference = getPercentageChange(compareUtilization, utilization);
    }

    let equipmentName = _.filter(equipments, { id: row.equipment_id });
    if (equipmentName.length === 1) {
      equipmentName = equipmentName[0];
    }

    return {
      id: row.equipment_id,
      name: equipmentName.name,
      utilization,
      compareUtilization,
      utilizationChange: difference
    };
  });
  return outputData;
};

const getComparePeriod = (periodStart, periodEnd) => {
  const length = periodEnd.diff(periodStart, "days");

  return {
    startDate: moment(periodStart).subtract(length + 1, "days"),
    endDate: moment(periodEnd).subtract(length + 1, "days")
  };
};

const BiggestChange = props => {
  const { formatMessage } = props.intl;

  const { startDate, endDate } = FilterStore;
  const comparePeriod = getComparePeriod(startDate, endDate);

  const period = `${startDate.format(
    formatMessage({ id: "date.format" })
  )} - ${endDate.format(
    formatMessage({ id: "date.format" })
  )} vs ${comparePeriod.startDate.format(
    formatMessage({ id: "date.format" })
  )} - ${comparePeriod.endDate.format(formatMessage({ id: "date.format" }))}`;

  if (props.loading === true) {
    return (
      <ExpansionPanel
        label={props.title}
        secondaryLabel={period}
        className="Widget Widget--no-footer BiggestChange"
        columnWidths={props.columnWidths}
        focused={props.focused}
        defaultExpanded
      >
        <img
          src={loadingIcon}
          alt="Biggest change"
          style={{
            position: "absolute",
            left: "50%",
            transform: "translateX(-50%)"
          }}
        />
      </ExpansionPanel>
    );
  }

  // todo: requires 2 data ranges
  if (
    props.equipments.length > 0 &&
    props.equipmentData.length > 0 &&
    props.compareEquipmentData.length > 0
  ) {
    config.yAxis.title.text = formatMessage({
      id: "widget.equipment.utilization"
    });

    const { activeFilters } = FilterStore;
    const { startDate, endDate } = activeFilters;

    const length = endDate.diff(startDate, "days");
    const compareStartDate = moment(startDate).subtract(length + 1, "days");
    const compareEndDate = moment(endDate).subtract(length + 1, "days");

    const showableData = getOutputData(
      props.equipmentData,
      props.compareEquipmentData,
      props.equipments
    );

    let biggestIncrease = _.clone(showableData).sort(
      (s1, s2) => s2.utilizationChange - s1.utilizationChange
    );
    biggestIncrease = biggestIncrease.splice(0, 5);

    let biggestDecrease = _.clone(showableData).sort(
      (s1, s2) => s2.utilizationChange - s1.utilizationChange
    );
    biggestDecrease = biggestDecrease.reverse().splice(0, 5);

    return (
      <ExpansionPanel
        label={props.title}
        secondaryLabel={period}
        className="Widget Widget--no-footer BiggestChange"
        columnWidths={props.columnWidths}
        focused={props.focused}
        defaultExpanded
      >
        <div className="row">
          <div className="col">
            <div className="BiggestChange__title BiggestChange__title--increase">
              <img
                src={IncreaseIcon}
                className="BiggestChange__title-icon"
                alt="Biggest increase"
              />
              <FormattedMessage id="widget.biggestChange.increase" />
            </div>
            <div className="BiggestChange__table">
              <table cellPadding="0" cellSpacing="0" border="0">
                <thead>
                  <tr>
                    <th>&nbsp;</th>
                    <th className="center">
                      {compareStartDate.format("DD.M.")} -{" "}
                      {compareEndDate.format("DD.M.YYYY")}
                    </th>
                    <th className="center">
                      {startDate.format("DD.M.")} -{" "}
                      {endDate.format("DD.M.YYYY")}
                    </th>
                    <th className="center">
                      <FormattedMessage id="widget.biggestChange.change" />
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {biggestIncrease.map(row => {
                    const difference = row.utilization - row.compareUtilization;
                    return (
                      <tr key={row.id}>
                        <td>{row.name}</td>
                        <td className="center">
                          {row.compareUtilization !== "-"
                            ? <Percentage value={row.compareUtilization} />
                            : "-"}
                        </td>
                        <td className="center">
                          {row.utilization !== "-"
                            ? <Percentage value={row.utilization} />
                            : "-"}
                        </td>
                        <td
                          className={`center ${
                            difference > 0 ? "positive" : null
                          } ${difference < 0 ? "negative" : null}`}
                        >
                          {difference === 0
                            ? "-"
                            : <Percentage value={difference} showSign/>
                          }
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
          <div className="col">
            <div className="BiggestChange__title BiggestChange__title--decrease">
              <img
                src={DecreaseIcon}
                className="BiggestChange__title-icon"
                alt="Biggest decrease"
              />
              <FormattedMessage id="widget.biggestChange.decrease" />
            </div>
            <div className="BiggestChange__table">
              <table cellPadding="0" cellSpacing="0" border="0">
                <thead>
                  <tr>
                    <th>&nbsp;</th>
                    <th className="center">
                      {compareStartDate.format("DD.M.")} -{" "}
                      {compareEndDate.format("DD.M.YYYY")}
                    </th>
                    <th className="center">
                      {startDate.format("DD.M.")} -{" "}
                      {endDate.format("DD.M.YYYY")}
                    </th>
                    <th className="center">
                      <FormattedMessage id="widget.biggestChange.change" />
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {biggestDecrease.map(row => {
                    const difference = row.utilization - row.compareUtilization;
                    return (
                      <tr key={row.id}>
                        <td>{row.name}</td>
                        <td className="center">
                          {row.compareUtilization !== "-"
                            ? <Percentage value={row.compareUtilization} showSign/>
                            : "-"}
                        </td>
                        <td className="center">
                          {row.utilization !== "-"
                            ? <Percentage value={row.utilization} showSign/>
                            : "-"}
                        </td>
                        <td
                          className={`center ${
                            row.utilizationChange > 0 ? "positive" : null
                          } ${row.utilizationChange < 0 ? "negative" : null}`}
                        >
                          {difference === "-" ||
                            difference === "-"
                            ? "-"
                            : <Percentage value={difference} showSign/>
                          }
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </ExpansionPanel>
    );
  }
  return null;
};

export default observer(injectIntl(BiggestChange));
