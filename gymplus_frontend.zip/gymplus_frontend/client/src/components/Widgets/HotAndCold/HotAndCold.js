import React from "react";

import { FormattedMessage, injectIntl } from "react-intl";
import { ExpansionPanel } from "react-md";
import { Link } from "react-router-dom";
import _ from "lodash";
import { observer } from "mobx-react";

import FilterStore from "../../../models/FilterStore";

// Widget configuration
import config from "./HotAndCold.config";

import "./HotAndCold.scss";

import HotIcon from "../../../assets/images/hottest.svg";
import ColdIcon from "../../../assets/images/coldest.svg";

import loadingIcon from "../../../assets/images/loading.svg";

// 3rd party libs
const ReactHighcharts = require("react-highcharts");
require("highcharts-data")(ReactHighcharts.Highcharts);

const HotAndCold = props => {
  const { formatMessage } = props.intl;

  const { startDate, endDate } = FilterStore;
  const period = `${startDate.format(
    formatMessage({ id: "date.format" })
  )} - ${endDate.format(formatMessage({ id: "date.format" }))}`;

  if (props.loading) {
    return (
      <ExpansionPanel
        label={props.title}
        secondaryLabel={period}
        className="Widget Widget--no-footer HotAndCold"
        columnWidths={props.columnWidths}
        focused={props.focused}
        defaultExpanded
      >
        <img
          src={loadingIcon}
          alt="Loading..."
          style={{
            position: "absolute",
            left: "50%",
            transform: "translateX(-50%)"
          }}
        />
      </ExpansionPanel>
    );
  }

  const chartConfig = _.clone(config);
  const chartConfig2 = _.clone(config);

  const maxScale = _.max(props.topData) + 0.025;

  _.extend(chartConfig, {
    xAxis: { categories: props.topLabels },
    yAxis: {
      max: maxScale,
      title: {
        text: formatMessage({
          id: "widget.equipment.utilization"
        }),
        align: "high"
      },
      labels: {
        overflow: "justify",
        style: {
          color: "#656668"
        },
        formatter() {
          return `${Math.round(this.value * 100 * 10) / 10}%`;
        }
      }
    }
  });
  _.extend(chartConfig, {
    series: [{ data: props.topData, color: "#ff4600" }]
  });

  _.extend(chartConfig2, {
    xAxis: { categories: props.bottomLabels },
    yAxis: {
      max: maxScale,
      title: {
        text: formatMessage({
          id: "widget.equipment.utilization"
        }),
        align: "high"
      },
      labels: {
        overflow: "justify",
        style: {
          color: "#656668"
        },
        formatter() {
          return `${Math.round(this.value * 100 * 10) / 10}%`;
        }
      }
    }
  });
  _.extend(chartConfig2, {
    series: [{ data: props.bottomData, color: "#4cc7e6" }]
  });

  return (
    <ExpansionPanel
      label={props.title}
      secondaryLabel={period}
      className="Widget Widget--no-footer HotAndCold"
      columnWidths={props.columnWidths}
      focused={props.focused}
      defaultExpanded
    >
      <div className="row">
        <div className="col">
          <div className="HotAndCold__title HotAndCold__title--hot">
            <img src={HotIcon} alt="" className="HotAndCold__title-icon" />
            <FormattedMessage id="widget.hotAndCold.hottest" />
          </div>
          <div className="HotAndCold__chart">
            <ReactHighcharts
              config={chartConfig}
              neverReflow={true}
              id="chart1"
            />
          </div>
          <Link to="/equipment">
            <FormattedMessage id="widget.hotAndCold.viewAllEquipment" />
          </Link>
        </div>
        <div className="col">
          <div className="HotAndCold__title HotAndCold__title--cold">
            <img src={ColdIcon} alt="" className="HotAndCold__title-icon" />
            <FormattedMessage id="widget.hotAndCold.coldest" />
          </div>
          <div className="HotAndCold__chart">
            <ReactHighcharts
              config={chartConfig2}
              neverReflow={true}
              id="chart2"
            />
          </div>
        </div>
      </div>
    </ExpansionPanel>
  );
};

export default observer(injectIntl(HotAndCold));
