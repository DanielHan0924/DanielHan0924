const chartGray = "#eef0f2";

export default {
  chart: {
    type: "bar",
    height: "350px"
  },
  title: {
    text: ""
  },
  subtitle: {
    text: ""
  },
  xAxis: {
    className: "highcharts-color-0",
    categories: [], // Will be populated by the widget
    title: {
      text: null
    },
    labels: {
      style: {
        color: "#656668"
      }
    },
    gridLineColor: chartGray
  },
  yAxis: {
    min: 0,
    max: 0.25,
    title: {
      text: "Utilization-%", // Will be overwritten by translation
      align: "high"
    },
    labels: {
      overflow: "justify",
      style: {
        color: "#656668"
      },
      formatter() {
        return `${Math.round(this.value * 100 * 10) / 10}%`;
      }
    },
    gridLineColor: chartGray,
    lineColor: chartGray,
    tickColor: chartGray
  },
  tooltip: {
    valueSuffix: "%",
    followPointer: true,
    shadow: false,
    borderRadius: 0,
    borderWidth: 0,
    backgroundColor: "#eef0f2",
    borderColor: "#eef0f2",
    style: {
      fontSize: "13px",
      letterSpacing: "0.5px"
    },
    formatter() {
      return `<b>${this.x}:</b> ${(this.y * 100).toFixed(2)} %`;
    }
  },
  plotOptions: {
    bar: {
      animation: {
        duration: 1000
      }
    },
    series: {
      pointWidth: 28,
      dataLabels: {
        enabled: true,
        align: "right",
        shadow: false,
        borderWidth: 0,
        padding: 0,
        y: -1,
        x: -3,
        style: {
          color: "#ffffff",
          textOutline: false,
          fontSize: "13px"
        },
        formatter() {
          return `${(this.y * 100).toFixed(2)} %`;
        }
      }
    }
  },
  legend: {
    enabled: false
  },
  credits: {
    enabled: false
  },
  series: [
    {
      name: "Selected period", // Will be overwritten by translation
      data: [] // Will be populated by the widget
    }
  ]
};
