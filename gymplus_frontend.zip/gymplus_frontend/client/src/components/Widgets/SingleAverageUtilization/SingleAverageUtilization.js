import React, {Component} from 'react';
import { observer } from 'mobx-react';
import { injectIntl } from "react-intl";
import moment from "moment";
import _ from 'lodash';

import SingleEquipmentStore from '../../../models/SingleEquipmentStore.js';
import LoadingAnimation from '../../LoadingAnimation/LoadingAnimation.js';
import config from './SingleAverageUtilization.config.js';

const ReactHighcharts = require('react-highcharts');
require('highcharts-data')(ReactHighcharts.Highcharts);

const groupByType = Object.freeze({ HOUR: 'hour', DAY: 'day'});

const SingleAverageUtilization = observer (
  class SingleAverageUtilization extends Component {

    configureChart = (chartToConfigure) => {
      const chartConfig = _.cloneDeep(chartToConfigure);
      const isLoaded = SingleEquipmentStore.averageUtilizationData.length > 0;
      if (!isLoaded){
        return chartConfig;
      }
      this.setYAxisTitle(chartConfig);
      this.setLabels(chartConfig);
      this.setChartDrawingType(chartConfig);
      this.setChartTitle(chartConfig);
      this.setChartData(chartConfig);
      return chartConfig;


    }

    setLabels = (chartConfig) => {
      const { avgGroupBy, averageUtilizationLabels} = SingleEquipmentStore;
      const { formatMessage } = this.props.intl;
      const dateFormat = formatMessage({ id: "date.format" });

      let chartLabels;
      if(avgGroupBy === groupByType.HOUR){
        chartLabels = _.map(averageUtilizationLabels, timeRound => {
          const dateFormatShort = formatMessage({ id: "date.formatShort" });
          return moment(timeRound).format(`${dateFormatShort} HH:mm`);
        });
      }
      else if (avgGroupBy === groupByType.DAY){
        chartLabels = _.map(averageUtilizationLabels, timeRound => {
          return moment(timeRound).format(dateFormat);
        });
      }
      else {
        chartLabels = _.map(averageUtilizationLabels, timeRound => {
          return `${formatMessage({ id: "widget.dimension.timePartWeek" })} ${moment(timeRound).format('W')}`;
        });
      }
      _.extend(chartConfig, {
        xAxis: { categories: chartLabels }
      });
    }

    setChartDrawingType = (chartConfig) => {
      const { avgGroupBy } = SingleEquipmentStore;


      let chartDrawingType;
      if(avgGroupBy === groupByType.HOUR){
        chartDrawingType = 'area';
      }
      else if (avgGroupBy === groupByType.DAY){
        chartDrawingType = 'column';
      }
      else {
        chartDrawingType = 'column';
      }
      _.extend(chartConfig, {
        chart: {
          type: chartDrawingType
        }
      });
    }

    setYAxisTitle = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      chartConfig.yAxis.title.text = formatMessage({
        id: "widget.equipment.utilization"
      });
    }

    setChartTitle = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      const dateFormat = formatMessage({ id: "date.format" });
      const { startDate, endDate } = SingleEquipmentStore;

      const startingDate = startDate.format(dateFormat);
      const endingDate = endDate ? endDate.format(dateFormat) : null;
      const chartType = formatMessage({ id: "singleEquipmentView.chartTitle.average" });

      _.extend(chartConfig, {
        title: {
          text: `${chartType} ${startingDate} - ${endingDate}`,
          align: "center"
        }
      });
    }

    setChartData = (chartConfig) => {
      const { averageUtilizationData } = SingleEquipmentStore;
      _.extend(chartConfig, {
        series: [{ data: averageUtilizationData, color: "#3c73c8" }]
      });
    }

    componentDidMount(){
      const { id } = this.props.equipment;
      SingleEquipmentStore.reloadAverageChart(id);
    }

    render (){
      const chartConfig = this.configureChart(config);
      const isLoading = SingleEquipmentStore.isLoadingAverage();

      return (
        <div>
          {isLoading
            ? <LoadingAnimation />
            : <ReactHighcharts config={chartConfig} ref='chart' />
          }
        </div>
      );
    }
  }
);

export default injectIntl(SingleAverageUtilization);
