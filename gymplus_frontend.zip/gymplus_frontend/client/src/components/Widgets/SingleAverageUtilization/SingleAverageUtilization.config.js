const chartGray = "#eef0f2";

export default {
  chart: {
    type: "column",
  },
  title: {
    text: "",
  },
  subtitle: {
    text: ""
  },
  xAxis: {
    className: "highcharts-color-0",
    title: {
      text: null
    },
    categories: [],
    labels: {
      style: {
        color: "#656668",
        fontSize: "16px"
      }
    },
    gridLineColor: chartGray
  },
  yAxis: {
    min: 0,
    title: {
      text: "Utilization-%", // Will be overwritten by translation
      align: "high"

    },
    labels: {
      overflow: "justify",
      style: {
        color: "#656668",
        fontSize: "16px"
      },
      formatter() {
        return `${Math.round(this.value * 100 * 10) / 10}%`;
      }
    },
    gridLineColor: chartGray,
    lineColor: chartGray,
    tickColor: chartGray
  },
  tooltip: {
    valueSuffix: "%",
    followPointer: true,
    shadow: false,
    borderRadius: 0,
    borderWidth: 0,
    backgroundColor: "#eef0f2",
    borderColor: "#eef0f2",
    style: {
      fontSize: "14px",
      letterSpacing: "1px"
    },
    formatter() {
      return `<b>${this.x}:</b> ${(this.y * 100).toFixed(2)} %`;
    }
  },
  plotOptions: {
    bar: {
      animation: {
        duration: 1000
      }
    },
    series: {
      states: {
        hover:{
          lineWidth: 2
        }
      },
      lineWidth: 1,
      marker: {
        enabled: false
      },
      // pointWidth: 18,
      // dataLabels: {
      //   enabled: false,
      //   align: "right",
      //   shadow: false,
      //   borderWidth: 0,
      //   padding: 0,
      //   y: -1,
      //   x: -3,
      //   style: {
      //     color: "#656668",
      //     textOutline: false,
      //     fontSize: "13px"
      //   },
        // formatter() {
        //   return `${(this.y * 100).toFixed(2)} %`;
        // }
      // }
    }
  },
  /* The part that shows 'Series 1' at the bottom of the graph*/
  legend: {
    enabled: false
  },
  /* Highcharts.com - label */
  credits: {
    enabled: false
  },
  series: [
    {
      name: "Selected period", // Will be overwritten by translation
      data: [], // Will be populated by the widget
      dataLabels: {
        formatter() {
          return `${(this.y * 100).toFixed(2)} %`;
        }
      }
    }
  ]
};

/* joel.salminen@indoorinformatics.com */
