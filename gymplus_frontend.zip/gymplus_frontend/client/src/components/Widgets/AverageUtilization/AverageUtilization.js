import React from "react";

import { injectIntl, FormattedMessage } from "react-intl";
import { ExpansionPanel } from "react-md";
import { observer } from "mobx-react";
import _ from "lodash";
import moment from "moment";

//import SingleSelector from "../../SingleSelector/SingleSelector";

import FilterStore from "../../../models/FilterStore";

import loadingIcon from "../../../assets/images/loading.svg";
import starIcon from "../../../assets/images/star.svg";

import "./AverageUtilization.scss";

import config from "./AverageUtilization.config";

// 3rd party libs
const ReactHighcharts = require("react-highcharts");
require("highcharts-data")(ReactHighcharts.Highcharts);

/*const getDimensions = formatMessage => {
  return [
    {
      id: "timePart_dow",
      timePart: "dow",
      name: formatMessage({ id: "widget.dimension.timePartDow" })
    },
    {
      id: "timePart_week",
      timePart: "week",
      name: formatMessage({ id: "widget.dimension.timePartWeek" })
    },
    {
      id: "timePart_month",
      timePart: "month",
      name: formatMessage({ id: "widget.dimension.timePartMonth" })
    },
    {
      id: "timePart_quarter",
      timePart: "quarter",
      name: formatMessage({ id: "widget.dimension.timePartQuarter" })
    }
  ];
};
*/
const AverageUtilization = props => {
  const { formatMessage } = props.intl;
  let chartLabels;

  const dateFormat = formatMessage({ id: "date.format" });
  const dateFormatShort = formatMessage({ id: "date.formatShort" });

  const { startDate, endDate } = FilterStore;
  const period = `${startDate.format(dateFormat)} - ${endDate.format(dateFormat)}`;

  if(props.avgGroupBy === 'hour') {
    chartLabels = _.map(props.chartLabels, timeRound => {
      return moment(timeRound).format(`${dateFormatShort} HH:mm`);
    });
  } else if(props.avgGroupBy === 'day') {
    chartLabels = _.map(props.chartLabels, timeRound => {
      return moment(timeRound).format(dateFormat);
    });
  } else {
    chartLabels = _.map(props.chartLabels, timeRound => {
      return `${formatMessage({ id: "widget.dimension.timePartWeek" })} ${moment(timeRound).format('W')}`;
    });
  }

  const chartConfig = _.clone(config);
  chartConfig.yAxis.title.text = formatMessage({
    id: "widget.equipment.utilization"
  });
  _.extend(chartConfig, {
    xAxis: { categories: chartLabels }
  });
  _.extend(chartConfig, {
    series: [{ data: props.chartData, color: "#3c73c8" }]
  });

  if (props.loading) {
    return (
      <ExpansionPanel
        label={props.title}
        secondaryLabel={period}
        className="Widget Widget--no-footer HotAndCold"
        columnWidths={props.columnWidths}
        focused={props.focused}
        defaultExpanded
      >
        <img
          src={loadingIcon}
          alt="Loading..."
          style={{
            position: "absolute",
            left: "50%",
            transform: "translateX(-50%)"
          }}
        />
      </ExpansionPanel>
    );
  }

  if (props.chartData.length > 0) {
    return (
      <ExpansionPanel
        label={props.title}
        secondaryLabel={period}
        className="Widget Widget--no-footer"
        columnWidths={props.columnWidths}
        focused={props.focused}
        defaultExpanded
      >
        <div className="AvgUtilization__title">
          <img src={starIcon} alt="" className="AvgUtilization__title-icon" />
          <FormattedMessage id="widget.averageUtilization.averageUtilization" />
        </div>
        <div className="AvgUtilization__chart">
          <ReactHighcharts
            config={chartConfig}
            neverReflow={true}
            id="chart1"
          />
        </div>
      </ExpansionPanel>
    );
  }
  return null;
};

export default observer(injectIntl(AverageUtilization));
