import React, {Component} from 'react';
import { observer } from 'mobx-react';
import { injectIntl } from "react-intl";
import _ from 'lodash';

import SingleEquipmentStore from '../../../models/SingleEquipmentStore.js';
import HourlyUtilization from '../SingleHourlyUtilization/SingleHourlyUtilization.js';
import LoadingAnimation from '../../LoadingAnimation/LoadingAnimation.js';

import config from './SingleDowUtilization.config.js';
const ReactHighcharts = require('react-highcharts');
require('highcharts-data')(ReactHighcharts.Highcharts);

const SingleDowUtilization = observer (
  class SingleDowUtilization extends Component {

    configureChart = (chartToConfigure) => {
      const chartConfig = _.cloneDeep(chartToConfigure);
      const isLoaded = SingleEquipmentStore.dowUtilizationData.length > 0;
      if (!isLoaded){
        return chartConfig;
      }
      this.setYAxisTitle(chartConfig);
      this.setChartTitle(chartConfig);
      this.setChartData(chartConfig);
      this.setLabels(chartConfig);
      this.addOnBackClickFunction(chartConfig);
      this.setTooltip(chartConfig)
      return chartConfig;
    }

    setYAxisTitle = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      const yAxisTitle = formatMessage({ id: "widget.equipment.utilization" });
      chartConfig.yAxis.title.text = yAxisTitle;
    }

    setChartTitle = (chartConfig) => {
      const {
        startDate,
        endDate
      } = SingleEquipmentStore;
      const { formatMessage } = this.props.intl;
      const startingDate = startDate.format(formatMessage({ id: "date.format"}));
      const endingDate = endDate ? endDate.format(formatMessage({ id: "date.format"})) : null;
      const chartType = formatMessage({ id: "singleEquipmentView.chartTitle.dow" });
      _.extend(chartConfig, {
        title: {
          text: `${chartType}   ${startingDate} - ${endingDate}`,
          align: "left"
        }
      });
    }


    setChartData = (chartConfig) => {
      const { dowUtilizationData } = SingleEquipmentStore;
      _.extend(chartConfig, {
        series: [{
          data: dowUtilizationData,
          color: "#3B3561"
        }]
      });
    }

    setLabels = (chartConfig) => {
      // const { formatMessage } = this.props.intl;
      // this has to be done here because intl doens't work inside stores
      // const labels = _.map(SingleEquipmentStore.dowLabels, label => {
      //   return formatMessage({ id: label.name });
      // });
      const labels = SingleEquipmentStore.dowLabels;
      _.extend(chartConfig, {
        xAxis: { categories: labels }
      });
    }

    addOnBackClickFunction = (chartConfig) => {
      _.extend(chartConfig, {
        plotOptions: {
          series: {
            cursor: "pointer",
            point: {
              events: {
                click: function(evt){
                  const xCoordinate = this.x;
                  SingleEquipmentStore.setOneDayStart(xCoordinate);
                  SingleEquipmentStore.toggleShowDow();
                }
              }
            }
          }
        }
      });
    }

    setTooltip = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      const infoText = formatMessage({ id: 'widget.tooltip.moreInformation'});
      chartConfig.tooltip.formatter = function (){
        return (
          `<b>${this.x}:</b> ${(this.y * 100).toFixed(2)} % <br /> ${infoText}`
        );
      }
    }

    componentDidMount(){
      const { id } = this.props.equipment;
      SingleEquipmentStore.reloadDowChart(id);

    }

    render (){
      const { equipment } = this.props;
      const { showDow } = SingleEquipmentStore;
      const isLoading = SingleEquipmentStore.isLoadingDow();
      const chartConfig = this.configureChart(config);

      if (isLoading){
        return (
          <LoadingAnimation />
        );
      }
      return (
        <div>
          { showDow
            ? <ReactHighcharts config={chartConfig} ref='chart' />
            : <HourlyUtilization equipment={equipment}/>
          }
        </div>
      );

    }
  }
);

export default injectIntl(SingleDowUtilization);

/* joel.salminen@indoorinformatics.com */
