import React, { Component } from "react";
import { observer } from "mobx-react";
import { injectIntl } from "react-intl";
import { ExpansionPanel, DialogContainer } from "react-md";
import { toJS } from "mobx";
import _ from "lodash";

// Helpers & Services
import ApiMiddleware from "../../../services/Api";
import Auth from "../../../services/Auth";

// Components
import SingleSelector from "../../SingleSelector/SingleSelector";
import SingleEquipmentView from '../../SingleEquipmentView/SingleEquipmentView';

// Widget configuration
import config from "./EquipmentDetails.config";

// Widget styles
import "./EquipmentDetails.scss";

import loadingIcon from "../../../assets/images/loading.svg";

// Stores
import FilterStore from "../../../models/FilterStore";
import EquipmentDetailsStore from "../../../models/EquipmentDetailsStore";
import SingleEquipmentStore from '../../../models/SingleEquipmentStore';

// 3rd party libs
const ReactHighcharts = require("react-highcharts");
require("highcharts-data")(ReactHighcharts.Highcharts);

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const EquipmentDetails = observer(
  class EquipmentDetails extends Component {
    componentDidUpdate() {
      if (this.refs.chart !== undefined) {
        let chart = this.refs.chart.getChart();
        chart.reflow = () => {};
      }
    }
    getDimensions() {
      const { formatMessage } = this.props.intl;

      return [
        {
          id: "equipment_id",
          timePart: null,
          name: formatMessage({ id: "widget.dimension.equipment" })
        },
        {
          id: "premise_id",
          timePart: null,
          name: formatMessage({ id: "widget.dimension.premise" })
        },
        {
          id: "category_id",
          timePart: null,
          name: formatMessage({ id: "widget.dimension.category" })
        },
        {
          id: "brand_id",
          timePart: null,
          name: formatMessage({ id: "widget.dimension.brand" })
        },
        {
          id: "timePart_dow",
          timePart: "dow",
          name: formatMessage({ id: "widget.dimension.timePartDow" })
        },
        {
          id: "timePart_week",
          timePart: "week",
          name: formatMessage({ id: "widget.dimension.timePartWeek" })
        },
        {
          id: "timePart_month",
          timePart: "month",
          name: formatMessage({ id: "widget.dimension.timePartMonth" })
        },
        {
          id: "timePart_quarter",
          timePart: "quarter",
          name: formatMessage({ id: "widget.dimension.timePartQuarter" })
        }
      ];
    }

    getSortByOptions() {
      const { formatMessage } = this.props.intl;

      return [
        {
          id: "utilization",
          name: formatMessage({ id: "widget.equipment.sortBy.utilization" })
        },
        {
          id: "name",
          name: formatMessage({ id: "widget.equipment.sortBy.name" })
        }
      ];
    }

    handleDimensionChange(groupBy, timePart, filterData) {
      EquipmentDetailsStore.reloadChart(groupBy, timePart, filterData);
    }

    handleSortChange(sortBy) {
      EquipmentDetailsStore.reOrderChartData(sortBy);
    }

    hideDialog = () => {
      SingleEquipmentStore.setIsVisible(false);
    }

    configureChart(chartToConfigure){
      const chartConfig = _.cloneDeep(chartToConfigure);
      this.setChartHeight(chartConfig);
      this.setYAxisTitle(chartConfig);
      this.setLabels(chartConfig);
      this.setChartData(chartConfig);
      this.setBarOnClickHandler(chartConfig);
      this.setTooltip(chartConfig);
      return chartConfig;
    }

    setChartHeight(chartConfig){
      let height;
      if(EquipmentDetailsStore.useCompare === true) {
        height = EquipmentDetailsStore.labels.length * 100;
      } else {
        height = EquipmentDetailsStore.labels.length * 60;
      }
      chartConfig.chart.height = `${height + 100}px`;
    }

    setYAxisTitle(chartConfig){
      const { formatMessage } = this.props.intl;
      chartConfig.yAxis.title.text = formatMessage({
        id: "widget.equipment.utilization"
      });
    }

    setLabels(chartConfig){
      let labels = [];
      const { formatMessage } = this.props.intl;

      if(EquipmentDetailsStore.groupBy === 'timePart' &&
        (EquipmentDetailsStore.timePart === 'dow' || EquipmentDetailsStore.timePart === 'month')) {
        labels = _.map(EquipmentDetailsStore.labels, label => {
          return formatMessage({ id: label });
        });
      } else if(EquipmentDetailsStore.groupBy === 'timePart' &&
        (EquipmentDetailsStore.timePart === 'week')) {
        labels = _.map(EquipmentDetailsStore.labels, label => {
          return formatMessage({ id: 'widget.dimension.timePartWeek' }) + ' ' + label;
        });
      } else {
        labels = EquipmentDetailsStore.labels;
      }

      _.extend(chartConfig, {
        xAxis: { categories: labels }
      });
    }

    setChartData(chartConfig){
      if(EquipmentDetailsStore.useCompare === true) {
        _.extend(chartConfig, {
          series: [{ data: EquipmentDetailsStore.data[0] },{ data: EquipmentDetailsStore.data[1] }]
        });
      } else {
        _.extend(chartConfig, {
          series: [{ data: EquipmentDetailsStore.data }]
        });
      }
    }

    setBarOnClickHandler(chartConfig){
      const selectedSortingCriteria = EquipmentDetailsStore.groupBy;
      if (selectedSortingCriteria !== 'equipment_id'){
        return;
      }
      _.extend(chartConfig, {
        plotOptions: {
          series: {
            cursor: "pointer",
            point:{
              events:{
                click: function(){
                  const { startDate, endDate } = FilterStore;
                  const yCoordinate = this.y;

                  const rawDataObjectWithEquipmentId = EquipmentDetailsStore.rawData.find(object => {
                    return object.utilization === yCoordinate;
                  });

                  /* Find correct equipment data based on user click */
                  const equipmentToDisplay = FilterStore.filterData.equipment.find(equipment => {
                    return equipment.id === rawDataObjectWithEquipmentId.equipment_id;
                  });
                  if (equipmentToDisplay){
                    SingleEquipmentStore.setIsVisible(true);
                  }
                  SingleEquipmentStore.setEquipment(equipmentToDisplay);
                  SingleEquipmentStore.setDates({startDate, endDate});

                }
              }
            },
            pointWidth: 28,
            dataLabels: {
              enabled: true,
              align: "right",
              shadow: false,
              borderWidth: 0,
              padding: 0,
              y: -1,
              useHTML: true,
              zIndex: 1,
              style: {
                textOutline: false,
                fontSize: "13px",
                allowOverlap: false,
              },
              formatter() {
                if (this.point.plotX > 210) {
                  return `<div style="color: #ffffff; margin-right: 3px;">${(this.y * 100).toFixed(2)} %</div>`;
                } else {
                  return `<div style="color: #262930; margin-left: 10px;">${(this.y * 100).toFixed(2)} %</div>`;
                }
              }
            }
          }
        }
      });
    }

    setTooltip(chartConfig){
      const selectedSortingCriteria = EquipmentDetailsStore.groupBy;
      if (selectedSortingCriteria !== 'equipment_id'){
        chartConfig.tooltip.formatter = function (){
          return `<b>${this.x}:</b> ${(this.y * 100).toFixed(2)} %`;
        }
        return;
      }

      const { formatMessage } = this.props.intl;
      const infoText = formatMessage({ id: 'widget.tooltip.moreInformation'});
      chartConfig.tooltip.formatter = function (){
        return (
          `<b>${this.x}:</b> ${(this.y * 100).toFixed(2)} % <br /> ${infoText}`
        );
      }
    }

    render() {
      const { formatMessage } = this.props.intl;

      const filterData = toJS(FilterStore.filterData); // eslint-disable-line
      const { equipment } = SingleEquipmentStore;

      let period = `${FilterStore.activeFilters.startDate.format(
        formatMessage({ id: "date.format" })
      )} - ${FilterStore.activeFilters.endDate.format(
        formatMessage({ id: "date.format" })
      )}`;

      if(EquipmentDetailsStore.useCompare === true) {
        period += ` vs ${FilterStore.compareFilters.startDate.format(
          formatMessage({ id: "date.format" })
        )} - ${FilterStore.compareFilters.endDate.format(
          formatMessage({ id: "date.format" })
        )}`
      }

      if (filterData.equipment.length > 0) {
        if (!EquipmentDetailsStore.loaded && !EquipmentDetailsStore.loading) {
          EquipmentDetailsStore.reloadChart(
            "equipment_id",
            null,
            toJS(filterData)
          );

        }
        if (EquipmentDetailsStore.chartData.length > 0 && EquipmentDetailsStore.chartData[0].length > 0) {
          const chartConfig = this.configureChart(config);

          return (
            <ExpansionPanel
              label={formatMessage({
                id: "widget.equipment.title"
              })}
              secondaryLabel={period}
              className="Widget Widget--no-footer DetailWidget"
              columnWidths={this.props.columnWidths}
              focused={this.props.focused}
              defaultExpanded
            >
              <div className="EquipmentDetails__dialog">
                <DialogContainer
                  id="single-equipment-view"
                  visible={SingleEquipmentStore.isVisible}
                  title=""
                  onHide={this.hideDialog}
                  focusOnMount={false}
                >
                  <SingleEquipmentView
                    equipment={equipment}
                    timePart='dow'
                    closeWindow={this.hideDialog}
                  />
                </DialogContainer>
              </div>

              {EquipmentDetailsStore.groupBy !== "timePart" ? (
                <SingleSelector
                  type="sortByDetails"
                  items={this.getSortByOptions()}
                  handleToggle={this.handleSortChange}
                  valueProperty="name"
                  noScrolling={true}
                  className="left"
                />
              ) : null}

              <SingleSelector
                type="dimensionsDetails"
                items={this.getDimensions()}
                handleToggle={this.handleDimensionChange}
                valueProperty="name"
                noScrolling={false}
                className="right"
              />
              <div className="DetailWidget__chart">
                <ReactHighcharts config={chartConfig} ref="chart" />
              </div>
            </ExpansionPanel>
          );
        } else if(!EquipmentDetailsStore.loading && !EquipmentDetailsStore.loadingCompare && (EquipmentDetailsStore.loaded && EquipmentDetailsStore.loadingCompare && EquipmentDetailsStore.useCompare === true)) {
          return (
            <ExpansionPanel
              label={formatMessage({ id: "widget.equipment.title" })}
              secondaryLabel={period}
              className="Widget Widget--no-footer DetailWidget"
              columnWidths={this.props.columnWidths}
              focused={this.props.focused}
              defaultExpanded
            >
              <div
                style={{
                  position: "absolute",
                  left: "50%",
                  top: "32%",
                  transform: "translateX(-50%)"
                }}>
                { formatMessage({ id: "widget.noData" }) }
              </div>
            </ExpansionPanel>
          );
        }
      }

      return (
        /* if FilterStore.filterData.equipment is empty */
        <ExpansionPanel
          label={formatMessage({ id: "widget.equipment.title" })}
          secondaryLabel={period}
          className="Widget Widget--no-footer DetailWidget"
          columnWidths={this.props.columnWidths}
          focused={this.props.focused}
          defaultExpanded
        >
          <img
            src={loadingIcon}
            alt="Loading..."
            style={{
              position: "absolute",
              left: "50%",
              transform: "translateX(-50%)"
            }}
          />
        </ExpansionPanel>
      );
    }
  }
);
export default injectIntl(EquipmentDetails);
