import React, {Component} from 'react';
import { observer } from 'mobx-react';
import { injectIntl } from "react-intl";
import _ from 'lodash';

import SingleEquipmentStore from '../../../models/SingleEquipmentStore.js';
import LoadingAnimation from '../../LoadingAnimation/LoadingAnimation.js';

import './SingleHourlyUtilization.scss';

import config from './SingleHourlyUtilization.config.js';
const ReactHighcharts = require('react-highcharts');
require('highcharts-data')(ReactHighcharts.Highcharts);

const SingleHourlyUtilization = observer (
  class SingleHourlyUtilization extends Component {

    configureChart = (chartToConfigure) => {
      const chartConfig = _.cloneDeep(chartToConfigure);
      const isLoaded = SingleEquipmentStore.hourUtilizationData.length > 0;
      if (!isLoaded){
        return chartConfig;
      }
      this.setYAxisTitle(chartConfig);
      this.setLabels(chartConfig);
      this.setChartTitle(chartConfig);
      this.setChartData(chartConfig);
      return chartConfig;
    }

    setYAxisTitle = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      const titleText = formatMessage({ id: "widget.equipment.utilization" });
      chartConfig.yAxis.title.text = titleText;
    }

    setLabels = (chartConfig) => {
      const { hourLabels } = SingleEquipmentStore;
      const labels = _.map(hourLabels.slice(), label => {
        return `${label}:00`;
      });
      _.extend(chartConfig, {
        xAxis: { categories: labels }
      });
    }

    setChartTitle = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      const dateFormat = formatMessage({ id: "date.format"});
      const date = SingleEquipmentStore.oneDayStart.format(`dd ${dateFormat}`);
      const title = formatMessage({ id: "singleEquipmentView.chartTitle.hourly" });
      _.extend(chartConfig, {
        title: {
          text: `${title} - ${date}`,
          align: "left"
        }
      });
    }

    setChartData = (chartConfig) => {
      _.extend(chartConfig, {
        series: [{
          data: SingleEquipmentStore.hourUtilizationData,
        }]
      });
    }

    changeView = () => {
      SingleEquipmentStore.toggleShowDow();
    }

    componentDidMount(){
      const { id } = this.props.equipment;
      SingleEquipmentStore.reloadHourChart(id);
    }

    renderBackButton = () => {
      const { formatMessage } = this.props.intl;
      const buttonText = formatMessage({ id: "singleEquipmentView.button.back" });
      return (
        <button
          onClick={this.changeView}
          className="SingleHourUtilization__btn"
        >
          {buttonText}
        </button>
      );
    }

    render (){
      const chartConfig = this.configureChart(config);
      const isLoading = SingleEquipmentStore.isLoadingHourly();

      return (
        <div>
          {this.renderBackButton()}
          { isLoading
            ? <LoadingAnimation />
            : <ReactHighcharts config={chartConfig} ref='chart' />
          }

        </div>
      );
    }
  }
);

export default injectIntl(SingleHourlyUtilization);

/* joel.salminen@indoorinformatics.com */
