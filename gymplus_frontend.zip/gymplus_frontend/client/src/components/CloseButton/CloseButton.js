import React from 'react';
import './CloseButton.scss';

const CloseButton = (props) => {
  return (
    <button
      className="CloseButton"
      onClick={props.closeWindow}
    >
      x
    </button>
  );
}

export default CloseButton;
