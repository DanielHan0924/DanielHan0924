import 'react-dates/initialize';

import React, { Component } from 'react';
import { Redirect, Switch, Route, withRouter } from 'react-router-dom';
import { observer } from 'mobx-react';
import { IntlProvider, addLocaleData } from 'react-intl';
import moment from 'moment';
import fiLocale from 'moment/locale/fi';
import enLocale from 'moment/locale/en-gb';

import fi from 'react-intl/locale-data/fi';
import en from 'react-intl/locale-data/en';

import 'react-dates/lib/css/_datepicker.css';
import Home from './Home/Home';
import Details from './Details/Details';
import Login from './Login/Login';
import Callback from './Callback/Callback';
import Admin from './Admin/Admin';
import EditDevice from './Admin/EditDevice/EditDevice';
import MapEquipment from './Admin/MapEquipment/MapEquipment';
import Tags from './Tags/Tags';
import Comparison from './Comparison';

import localeData from '../localization/strings.json';

import Auth from '../services/Auth';
import History from '../services/History';

import LocalizationStore from '../models/LocalizationStore.js';

let language;

if(localStorage.getItem('gpLanguage') == null) {
  localStorage.setItem('gpLanguage', 'fi'); // default to fi
  language = 'fi';
} else {
  language = localStorage.getItem('gpLanguage');
}

const messages = localeData[language] || localeData.fi;
addLocaleData([...fi, ...en]);
if(language === 'fi') {
  moment.updateLocale('fi', fiLocale);
} else {
  moment.updateLocale('en', enLocale);
}

const auth = new Auth();
const GymPlus = withRouter(
  observer(
    class GymPlus extends Component {
      handleAuthentication({ location }) {
        if (/access_token|id_token|error/.test(location.hash)) {
          auth.handleAuthentication();
        }
      }

      goTo(route) {
        History.replace(`/${route}`);
      }
      login() {
        auth.login();
      }
      logout() {
        auth.logout();
      }
      setLanguage(language) {
        LocalizationStore.setLanguage(language);
      }
      render() {
        const { isAuthenticated } = auth;

        return (
        <IntlProvider locale={language} key={language} messages={messages}>
          <div className="App">
            <Switch>
              <Route
                exact
                path="/"
                component={() =>
                  (!isAuthenticated() ? (
                    <Redirect to="/login" />
                  ) : (
                    <Home auth={auth} {...this.props} setLanguage={this.setLanguage} />
                  ))
                }
              />
              <Route
                exact
                path="/equipment"
                component={() =>
                  (!isAuthenticated() ? (
                    <Redirect to="/login" />
                  ) : (
                    <Details auth={auth} {...this.props} setLanguage={this.setLanguage} />
                  ))
                }
              />
              <Route
                exact
                path="/events"
                component={() =>
                  (!isAuthenticated() ? (
                    <Redirect to="/login" />
                  ) : (
                    <Tags auth={auth} {...this.props} setLanguage={this.setLanguage} />
                  ))
                }
              />
              <Route
                exact
                path="/comparison"
                component={() => {
                  if(!isAuthenticated()) {
                   return <Redirect to="/login" />
                  } else {
                   return <Comparison {...this.props} setLanguage={this.setLanguage} />
                  }
                }}
              />
              <Route
                exact
                path="/admin"
                component={() => {
                  if(!isAuthenticated()) {
                   return <Redirect to="/login" />
                  } else {
                   return <Admin {...this.props} setLanguage={this.setLanguage} />
                  }
                }} />

              <Route
                  exact
                  path="/admin/premise/:premiseId"
                  component={() =>{
                    if(!isAuthenticated()) {
                     return <Redirect to="/login" />
                    } else {
                     return <Admin {...this.props} setLanguage={this.setLanguage} />
                    }
                  }} />
              <Route
                exact
                path="/admin/:premiseId/device/:id?"
                component={() => {
                  if(!isAuthenticated()) {
                   return <Redirect to="/login" />
                  } else {
                   return <EditDevice {...this.props} setLanguage={this.setLanguage} />
                  }
                }} />
              <Route
                exact
                 path="/admin/:premiseId/mapping/:id"
                 component={() => {
                   if(!isAuthenticated()) {
                    return <Redirect to="/login" />
                   } else {
                    return <MapEquipment {...this.props} setLanguage={this.setLanguage} />
                   }
                 }
                 } />
              <Route
                exact
                path="/login"
                component={() =>
                  (isAuthenticated() ? <Redirect to="/" /> : <Login auth={auth} {...this.props} />)
                }
              />
              <Route
                path="/callback"
                render={(props) => {
                  this.handleAuthentication(props);
                  return <Callback {...props} />;
                }}
              />
              <Route exact path="/logout" component={Details} />
            </Switch>
          </div>
        </IntlProvider>
        );
      }
    }
  )
);

export default GymPlus;
