import "react-dates/initialize";

import _ from "lodash";
import moment from "moment";
import React from "react";
import { observer } from "mobx-react";
import { ExpansionPanel, FontIcon } from "react-md";
import { DateRangePicker } from "react-dates";
import { FormattedMessage, injectIntl } from "react-intl";

// Helpers & Services
import ApiMiddleware from "../../services/Api";
import Auth from "../../services/Auth";

// Stores
import FilterStore from "../../models/FilterStore";

// Styles
import "./DateRangePicker.scss";
import "./Filter.scss";

// Components
import MultiSelector from "../MultiSelector/MultiSelector";
import ButtonGroup from "../ButtonGroup/ButtonGroup";

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const Filter = observer(
  class Filter extends React.Component {
    constructor(props) {
      super(props);

      const locale = localStorage.getItem('gpLanguage');
      FilterStore.setCategoryNameKey(locale);
      FilterStore.useFilters();

      this.fetchBrands();
      this.fetchCategories();
      this.fetchTags();
      this.fetchPremises();
    }

    fetchBrands() {
      FilterStore.setLoadingStatus("brand", true);
      api.get("/brand").then(response => {
        FilterStore.setFilterData("brand", response.data);
        FilterStore.setLoadingStatus("brand", false);
      });
    }

    fetchCategories() {
      FilterStore.setLoadingStatus("category", true);
      api.get("/category").then(response => {
        FilterStore.setFilterData("category", response.data);
        FilterStore.setLoadingStatus("category", false);
      });
    }

    fetchTags() {
      FilterStore.setLoadingStatus("tag", true);
      api.get("/equipment").then(response => {
        FilterStore.setFilterData("equipment", response.data);
        const tagNames = [];
        const tags = _.map(response.data, "tag");

        _.each(tags, tag => {
          if (tag !== null) {
            tagNames.push({ id: tag, name: tag });
          }
        });

        FilterStore.setFilterData("tag", tagNames);
        FilterStore.setLoadingStatus("tag", false);
      });
    }

    fetchPremises() {
      FilterStore.setLoadingStatus("premise", true);
      api.get("/premise").then(response => {
        FilterStore.setFilterData("premise", response.data);
        FilterStore.setLoadingStatus("premise", false);
      });
    }

    handDropDownChange(id, type) {
      FilterStore.toggleItem(id, type);
    }

    getDaySelectorItems() {
      const { formatMessage } = this.props.intl;

      return [
        {
          id: "all",
          name: formatMessage({ id: "filter.daysAll" })
        },
        {
          id: "weekdays",
          name: formatMessage({ id: "filter.daysWeek" })
        },
        {
          id: "weekends",
          name: formatMessage({ id: "filter.daysWeekend" })
        }
      ];
    }

    getHourSelectorItems() {
      const { formatMessage } = this.props.intl;

      return [
        {
          id: "all",
          name: formatMessage({ id: "filter.hoursAll" })
        },
        {
          id: "6to10am",
          name: formatMessage({ id: "filter.hours6to10am" })
        },
        {
          id: "4to8pm",
          name: formatMessage({ id: "filter.hours4to8pm" })
        }
      ];
    }

    handleDaysChange(days) {
      FilterStore.toggleDays(days);
    }

    handleHoursChange(hours) {
      FilterStore.toggleHours(hours);
    }

    handleCompareDaysChange(days) {
      FilterStore.toggleDays(days, true);
    }

    handleCompareHoursChange(hours) {
      FilterStore.toggleHours(hours, true);
    }

    render() {
      const { formatMessage } = this.props.intl;

      const dateRangeSelector = (
        <div>
          <div className="Filter__label">
            <FormattedMessage id="filter.dateRange" />
          </div>
          <DateRangePicker
            startDate={FilterStore.startDate}
            startDateId="dateRange_start"
            endDate={FilterStore.endDate}
            endDateId="dateRange_end"
            onDatesChange={({ startDate, endDate }) =>
              FilterStore.setDates({ startDate, endDate })
            }
            focusedInput={FilterStore.focusedInput}
            onFocusChange={focusedInput => FilterStore.setFocus(focusedInput)}
            displayFormat="dd D.M.YYYY"
            firstDayOfWeek={1}
            isOutsideRange={date => date >= moment().startOf("day")}
          />
        </div>
      );

      const compareDateRangeSelector = (
        <div>
          <div className="Filter__label">
            <FormattedMessage id="filter.dateRange" />
          </div>
          <DateRangePicker
            startDate={FilterStore.startCompareDate}
            startDateId="dateRange_start"
            endDate={FilterStore.endCompareDate}
            endDateId="dateRange_end"
            onDatesChange={({ startDate, endDate }) =>
              FilterStore.setCompareDates({ startDate, endDate })
            }
            focusedInput={FilterStore.focusedCompareInput}
            onFocusChange={focusedInput => FilterStore.setFocus(focusedInput, true)}
            displayFormat="dd D.M.YYYY"
            firstDayOfWeek={1}
            isOutsideRange={date => date >= moment().startOf("day")}
          />
        </div>
      );

      if (this.props.basic === true) {
        return (
          <ExpansionPanel
            label={formatMessage({ id: "filter.title" })}
            secondaryLabel=""
            className="Filter"
            saveProps={{ label: formatMessage({ id: "filter.apply" }) }}
            cancelProps={{
              label: formatMessage({ id: "filter.clear" })
            }}
            columnWidths={this.props.columnWidths}
            focused={this.props.focused}
            onSave={() => {
              FilterStore.useFilters();
            }}
          >
            <div className="row">
              <div className="col">{dateRangeSelector}</div>
            </div>
          </ExpansionPanel>
        );
      }

      return (
        <ExpansionPanel
          label={formatMessage({ id: "filter.title" })}
          className="Filter"
          saveProps={{ label: formatMessage({ id: "filter.apply" }) }}
          cancelProps={{
            label: formatMessage({
              id: "filter.clear"
            })
          }}
          columnWidths={this.props.columnWidths}
          focused={this.props.focused}
          onCancel={() => {
            FilterStore.resetFilters();
            FilterStore.useFilters();
          }}
          onSave={() => {
            FilterStore.useFilters();
          }}
        >
          <div className="row row--title">
            <div className="col">
              <div className="Filter__label">
                <span className="Filter__compareId Filter__compareId--A">A</span> { formatMessage({ id: "filter.title" }) }
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col">
              {dateRangeSelector}
            </div>
            <div className="col">{this.getDropdown("category")}</div>
            <div className="col">{this.getDropdown("brand")}</div>
          </div>
          <div className="row second">
            {this.getDaySelector()}
            <div className="col">{this.getDropdown("tag")}</div>
            <div className="col">{this.getDropdown("premise")}</div>
          </div>
          { !FilterStore.compareOpen ? (
          <div className="row row--short">
            <div className="col">
              <div className="Filter__addCompare">
                <a
                  onClick={(evt) => {
                    evt.preventDefault();
                    FilterStore.toggleCompare();
                  }}
                  className="Filter__addCompareButton">
                  <FontIcon>add_circle</FontIcon> 
                  {formatMessage({id: 'filter.addCompare'})}
                </a>
              </div>
            </div>
          </div>
          ) : '' }
          
          { FilterStore.compareOpen === true ? (
          <div className="Filter__compareFilters">
            <div className="row row--title">
              <div className="col">
                <div className="Filter__label">
                  <span className="Filter__compareId Filter__compareId--B">B</span> { formatMessage({ id: "filter.title" }) }
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col">
                {compareDateRangeSelector}
              </div>
              <div className="col">{this.getCompareDropdown("category")}</div>
              <div className="col">{this.getCompareDropdown("brand")}</div>
            </div>
            <div className="row second">
              {this.getCompareDaySelector()}
              <div className="col">{this.getCompareDropdown("tag")}</div>
              <div className="col">{this.getCompareDropdown("premise")}</div>
            </div>
            <div className="row row--short">
              <div className="col">
                <div className="Filter__addCompare">
                  <a 
                    onClick={(evt) => {
                      evt.preventDefault();
                      FilterStore.toggleCompare();
                    }}
                    className="Filter__addCompareButton Filter__addCompareButton--remove">
                    <FontIcon>remove_circle</FontIcon> 
                    {formatMessage({id: 'filter.removeCompare'})}
                  </a>
                </div>
              </div>
            </div>
          </div>
          ) : '' }
        </ExpansionPanel>
      );
    }

    getDropdown(type) {
      // Data is loaded and more than 1 options are available
      if (
        FilterStore.filterData[type] !== undefined &&
        FilterStore.filterData[type].length > 1
      ) {
        return (
          <div>
            <div className="Filter__label">
              <FormattedMessage id={`filter.dropdown.${type}`} />
            </div>
            <MultiSelector
              type={type}
              items={FilterStore.filterData[type]}
              selectedItems={FilterStore.selectedItems[type]}
              onChange={this.handDropDownChange}
              valueProperty={ FilterStore.categoryNameKey && type==='category' ? FilterStore.categoryNameKey : "name" }
            />
          </div>
        );
      }
      // Data is loading or does not contain multiple items
      return "";
    }

    getCompareDropdown(type) {
      // Data is loaded and more than 1 options are available
      if (
        FilterStore.filterData[type] !== undefined &&
        FilterStore.filterData[type].length > 1
      ) {
        return (
          <div>
            <div className="Filter__label">
              <FormattedMessage id={`filter.dropdown.${type}`} />
            </div>
            <MultiSelector
              type={type}
              items={FilterStore.filterData[type]}
              selectedItems={FilterStore.selectedCompareItems[type]}
              identifier="compare"
              onChange={itemId => {
                FilterStore.toggleCompareItem(itemId, type);
              }}
              valueProperty={ FilterStore.categoryNameKey && type==='category' ? FilterStore.categoryNameKey : "name" }
            />
          </div>
        );
      }
      // Data is loading or does not contain multiple items
      return "";
    }

    getDaySelector() {
      return (
        <div className="col">
          <div className="Filter__label">
            <FormattedMessage id="filter.time" />
          </div>
          <ButtonGroup
            type="days"
            items={this.getDaySelectorItems()}
            handleToggle={this.handleDaysChange}
            valueProperty="name"
          />
          <ButtonGroup
            type="hours"
            items={this.getHourSelectorItems()}
            handleToggle={this.handleHoursChange}
            valueProperty="name"
          />
        </div>
      );
    }

    getCompareDaySelector() {
      return (
        <div className="col">
          <div className="Filter__label">
            <FormattedMessage id="filter.time" />
          </div>
          <ButtonGroup
            type="daysCompare"
            items={this.getDaySelectorItems()}
            compare="true"
            handleToggle={this.handleCompareDaysChange}
            valueProperty="name"
          />
          <ButtonGroup
            type="hoursCompare"
            items={this.getHourSelectorItems()}
            compare="true"
            handleToggle={this.handleCompareHoursChange}
            valueProperty="name"
          />
        </div>
      );
    }
  }
);

export default injectIntl(Filter);
