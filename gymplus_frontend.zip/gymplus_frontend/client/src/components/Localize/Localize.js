import React from 'react';
import PropTypes from 'prop-types';
import { injectIntl } from 'react-intl';

const Localize = ({ intl, id = 'default' }) => {
  const { formatMessage } = intl;

  return(
    <span>{formatMessage({ id })}</span>
  );
}

Localize.propTypes = {
  intl: PropTypes.object.isRequired,
  id: PropTypes.string.isRequired
}

export default injectIntl(Localize);
