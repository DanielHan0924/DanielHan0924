import React from 'react';

import './InformationTable.scss'

const InformationTable = (props) => {
  const {
    value1,
    value2,
    value3,
    value4,
    column1,
    column2,
    column3,
    column4,
  } = props;

  return (
    <div className="InformationTable__containter">
      <div className="InformationTable--left">
        <p className="InformationTable__textRow">{column1}: {value1}</p>
        <p className="InformationTable__textRow">{column2}: {value2}</p>
      </div>
      <div className="InformationTable--right">
        <p className="InformationTable__textRow">{column3}: {value3}</p>
        <p className="InformationTable__textRow">{column4}: {value4}</p>
      </div>
    </div>

  );
}

export default InformationTable;

/* joel.salminen@indoorinformatics.com */
