import React from 'react';
import PropTypes from 'prop-types';

import './ToggleButton.scss';

const ToggleButton = ({ toggled, valueSelected, valueUnselected, onClick, props }) => {
  const buttonText = toggled ? valueSelected : valueUnselected;
  const buttonStyle = toggled ? 'ToggleButton__selected' : 'ToggleButton__unselected';

  return(
    <button
      onClick={onClick}
      className={`ToggleButton ${buttonStyle}`}
      {...props}
    >
      {buttonText}
    </button>
  );
}

ToggleButton.propTypes = {
  toggled: PropTypes.bool.isRequired,
  valueSelected: PropTypes.string.isRequired,
  valueUnselected: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired
}

export default ToggleButton;
