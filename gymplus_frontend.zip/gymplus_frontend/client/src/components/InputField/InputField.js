import React from 'react';
import PropTypes from 'prop-types';

import './InputField.scss';

const InputField = ({ labelText, onChange, value, placeholder = labelText, type = "text", required = false, props }) => {
  return(
    <div className="InputField">
      <label>
        {labelText} {required && <span className="InputField__required">*</span>}
      </label>
      <input
        type={type}
        onChange={onChange}
        value={value}
        placeholder={placeholder}
        {...props}
      >
      </input>

    </div>
  );
}

InputField.propTypes = {
  labelText: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  value: PropTypes.string,
  placeholder: PropTypes.string,
  type: PropTypes.string,
  required: PropTypes.bool,
}

export default InputField;
