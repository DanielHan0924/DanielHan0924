import React from 'react';
import { shallow } from 'enzyme';

import InputField from './InputField.js';

function setup(required, onChange = () => {}, labelText = 'labelText', value, placeholder, type){
  const props = {
    required,
    onChange,
    labelText,
    value,
    placeholder,
    type
  };
  return shallow(<InputField {...props} />);
}

describe('InputField', () => {
  let mountedInputField;
  beforeEach(() => {
    mountedInputField = setup();
  });
  it('should render without crashing', () => {
    const mountedInputField = setup();
  });
  it('should render a label', () => {
    const labels = mountedInputField.find('label');
    expect(labels.length).toEqual(1);
  });
  it('should render an input field', () => {
    const inputFields = mountedInputField.find('input');
    expect(inputFields.length).toEqual(1);
  });
  it('should call onChange function when input changes', () => {
    const onChangeMock = jest.fn();
    const mountedInputFieldWithCallBack = setup(undefined, onChangeMock);
    mountedInputFieldWithCallBack.find('input').simulate('change');
    expect(onChangeMock.mock.calls.length).toEqual(1);
  });

});

describe('When field is not required', () => {
  let mountedInputField;
  beforeEach(() => {
    mountedInputField = setup();
  });
  it('should not render required icon by default', () => {
    const labels = mountedInputField.find('label');
    const labelText = labels.text();
    const lastCharacterOfLabelText = labelText.substring(labelText.length-1);
    expect(lastCharacterOfLabelText).not.toEqual('*');
  });
});

describe('When field is required', () => {
  let mountedInputField;
  beforeEach(() => {
    const required = true;
    mountedInputField = setup(required);
  });
  it('should render required icon by default', () => {
    const labels = mountedInputField.find('label');
    const labelText = labels.text();
    const lastCharacterOfLabelText = labelText.substring(labelText.length-1);
    expect(lastCharacterOfLabelText).toEqual('*');
  });
});
