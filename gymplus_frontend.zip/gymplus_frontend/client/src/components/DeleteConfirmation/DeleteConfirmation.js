import React from 'react';
import PropTypes from 'prop-types';

import Button from '../Button/Button.js';
import Localize from '../Localize/Localize.js';
import './DeleteConfirmation.scss';

const DeleteConfirmation = ({ handleDelete, cancelDelete }) => {
  const confirmationText = <Localize id="tags.singleTag.deleteConfirmation.confirmationText"/>;
  const confirmDeleteText = <Localize id="tags.singleTag.deleteConfirmation.confirm"/>;
  const cancelDeleteText = <Localize id="tags.singleTag.deleteConfirmation.cancel"/>;

  return(
    <div className="DeleteConfirmation">
      <p>{confirmationText}</p>
      <Button
        onClick={handleDelete}
        value={confirmDeleteText}
      />
      <Button
        onClick={cancelDelete}
        value={cancelDeleteText}
      />

    </div>
  );
}

DeleteConfirmation.propTypes = {
  handleDelete: PropTypes.func.isRequired,
  cancelDelete: PropTypes.func.isRequired,
}

export default DeleteConfirmation;
