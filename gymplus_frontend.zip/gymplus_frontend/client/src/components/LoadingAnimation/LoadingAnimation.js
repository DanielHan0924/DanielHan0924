import React from 'react';
import './LoadingAnimation.scss';

import loadingIcon from '../../assets/images/loading.svg';

const LoadingAnimation = (props) => {
  return (
    <div className="LoadingAnimation__container">
    <img
      className="LoadingAnimation__image"
      src={loadingIcon}
      alt='Loading...'
      style={{
        right: props.right,
        bottom: props.bottom,
        left: props.left,
      }}
    />
    </div>
  );
}

export default LoadingAnimation;
