import React from "react";
import { Link } from "react-router-dom";
import { observer } from "mobx-react";

import { FormattedMessage } from "react-intl";

import "./Header.scss";
import Logo from "../../assets/images/logo.svg";
import MenuIcon from "../../assets/images/menu.svg";

import Auth from "../../services/Auth";

const auth = new Auth();

const Header = observer(
  class Header extends React.Component {
    constructor(props) {
      super(props);
      this.state = { navOpen: false, profile: {} };

      this.navigationLinkData = [
        {
          id: "home",
          pathName: "/",
          defaultMessage: "Home"
        }, {
          id: "equipment",
          pathName: "/equipment",
          defaultMessage: "Equipment"
        }, {
          id: "tags",
          pathName: "/events",
          defaultMessage: "Events"
        }, {
          id: "comparison",
          pathName: "/comparison",
          defaultMessage: "Comparison"
        }, {
          id: "management",
          pathName: "/admin",
          defaultMessage: "Management",
          adminRequired: true
        }, {
          id: "logOut",
          pathName: "/logout",
          defaultMessage: "Log out",
          onClick: this.handleLogOut
        }
      ];

    }
    componentWillMount() {
      const { isAuthenticated } = auth;

      if(isAuthenticated()) {
        this.setState({ profile: {} });
        const { userProfile, getProfile } = auth;
        if (!userProfile) {
          getProfile((err, profile) => {
            this.setState({ profile });
          });
        } else {
          this.setState({ profile: userProfile });
        }
      }
    }
    isOrgAdmin() {
      if(this.state.profile && this.state.profile['https://indoorinformatics.com/claims/roles'] ) {
        const roles = this.state.profile['https://indoorinformatics.com/claims/roles'];
        return roles.indexOf('OrganizationAdmin') !== -1
      }
      return false;
    }
    handleLogOut(evt) {
      evt.preventDefault();
      auth.logout();
    }

    renderNavigationLink(linkData){
      if(!linkData.adminRequired || this.isOrgAdmin()){
        return(
          <li
            key={linkData.id}
            className={
              this.props.location.pathname === linkData.pathName ? "selected" : ""
            }
          >
            <Link to={linkData.pathName} onClick={linkData.onClick}>
              <FormattedMessage
                id={`header.${linkData.id}`}
                defaultMessage={linkData.defaultMessage} />
            </Link>
          </li>
        );
      }
      return(null);

    }

    render() {
      const navigationLinks = this.navigationLinkData.map(linkData => this.renderNavigationLink(linkData));

      let language = localStorage.getItem('gpLanguage');

      return (
        <header className="Header">
          <div className="Header__mobile-toggle">
            <a href="/" onClick={(evt) => {
              evt.preventDefault();
              this.setState({ navOpen: !this.state.navOpen });
            }}>
             <img src={MenuIcon} alt="Menu" />
            </a>
          </div>
          <div className="Header__logo">
            <a href="/">
              <img src={Logo} className="" alt="GymPlus" />
            </a>
          </div>
          <nav className={`Header__nav ${ this.state.navOpen ? 'open' : null }`}>
            <ul>
              { language === 'en' ? (
                <li style={ { marginRight: '50px' }}>
                  <a href="/" onClick={evt => this.props.setLanguage('fi')}>Suomeksi</a>
                </li>
              ) : null }
              { language === 'fi' ? (
                <li style={ { marginRight: '50px' }}>
                  <a href="/" onClick={evt => this.props.setLanguage('en')}>In English</a>
                </li>
              ) : null }

              {navigationLinks}

            </ul>
          </nav>
        </header>
      );
    }
  }
);

export default Header;
