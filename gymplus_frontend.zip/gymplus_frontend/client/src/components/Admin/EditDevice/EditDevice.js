import React from "react";
import { injectIntl } from "react-intl";
import { observer } from "mobx-react";
import _ from "lodash";
import { FormattedMessage } from "react-intl";
import { withRouter } from 'react-router';
import { Redirect, Link } from 'react-router-dom';
import { TextField, SelectionControl, Button, DialogContainer, FontIcon } from "react-md";
import { toJS } from "mobx";

import "react-md/dist/react-md.green-blue.min.css";
import "./EditDevice.scss";

import Header from "../../Header/Header";
import Sidebar from "../Sidebar/Sidebar";
import MultiSelector from "../../MultiSelector/MultiSelector";

import ApiMiddleware from "../../../services/Api";
import Auth from "../../../services/Auth";

import AdminStore from "../../../models/AdminStore";

import loadingIcon from "../../../assets/images/loading.svg";

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const EditDevice = withRouter(observer(
  class EditDevice extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            inputDirty: {
              deviceName: false,
              deviceUrl: false,
              deviceUsername: false,
              devicePassword: false,
            },
            deviceId: null,
            premiseId: this.props.match.params.premiseId,
            deviceName: '',
            deviceUsername: '',
            devicePassword: '',
            deviceUrl: '',
            deviceActive: null,
            modalOpen: false,
            calibrationImage: null,
            authInfoTouched: false,
            deviceAdded: false,
            deviceEdited: false,
            addedDeviceId: null,
            fetchingImage: false,
            profile: {},
            deleteStatus: false
        }
    }

    isOrgAdmin() {
      if(this.state.profile && this.state.profile['https://indoorinformatics.com/claims/roles'] ) {
        const roles = this.state.profile['https://indoorinformatics.com/claims/roles'];
        return roles.indexOf('OrganizationAdmin') !== -1
      } 
      return false;
    }

    componentWillMount() {
      const { isAuthenticated } = auth;

      if(isAuthenticated()) {
        this.setState({ profile: {} });
        const { userProfile, getProfile } = auth;
        if (!userProfile) {
          getProfile((err, profile) => {
            this.setState({ profile });
          });
        } else {
          this.setState({ profile: userProfile });
        }
      }
    }

    componentDidMount() {
      AdminStore.fetchPremises();
      AdminStore.fetchDevices();
      AdminStore.fetchModels();
    }

    getSelectedModel() {
        const currentDevice = this.getCurrentDevice();

        let model;
        if(AdminStore.selectedModel) {
            model = toJS(AdminStore.selectedModel);
        } else if(currentDevice && currentDevice.model.model_id) {
            model = {[currentDevice.model.model_id]: true};
        } else {
            model = {};
        }

        const selectedModelId = _.map(model, (item, key) => {
            if(item === true) {
                return parseInt(key, 10);
            }
        })[0];

        return _.find(AdminStore.models, (item) => { return item.id === selectedModelId });
    }

    getCurrentDevice() {
        let currentDevice;

        if(this.props.match.params.id) {
            const allDevices = toJS(AdminStore.devices);
            currentDevice = _.find(allDevices, (d) => {
                return `${d.id}` === `${this.props.match.params.id}`;
            });
        } else {
            currentDevice = {
                name: '',
                model: {
                    model_id: null
                },
                request_json: {
                    url: '',
                    auth: {
                        username: '',
                        password: '',
                    }
                }
            }
        }

        return currentDevice;
    }

    getActiveStatus(currentDevice) {
        let active;
        if(this.state.deviceActive === null && currentDevice) { // state untouched
            active = currentDevice.active;
        } else if(this.state.deviceActive !== null && currentDevice) {
            active = this.state.deviceActive;
        } else {
            active = true;
        }

        return active;
    }

    saveChanges() {
        const currentDevice = this.getCurrentDevice();
        const deviceName = this.getFieldValue(this.state.deviceName, currentDevice.name, 'deviceName');

        if(deviceName.length === 0) {
            return false;
        }

        if(this.props.match.params.id) { // edit device information

            const selectedModel = this.getSelectedModel();
            const active = this.getActiveStatus(currentDevice);

            let activeString; // API wants capitalized string instead of boolean
            if(active === true) {
                activeString = "True";
            } else {
                activeString = "False";
            }

            const params = {
                premise_id: this.state.premiseId,
                name: deviceName,
                model: {
                    model_id: selectedModel.id,
                    name: selectedModel.name,
                },
                request_json: {
                    url: this.getFieldValue(this.state.deviceUrl, currentDevice.request_json.url, 'deviceUrl'),
                    auth: {
                        class: "HTTPBasicAuth",
                        username: this.getFieldValue(this.state.deviceUsername, currentDevice.request_json.auth.username, 'deviceUsername'),
                        password: this.getFieldValue(this.state.devicePassword, currentDevice.request_json.auth.password, 'devicePassword')
                    },
                    method: "GET"
                },
                active: activeString
            };

            api.put(`/device/${this.props.match.params.id}`, params)
            .then(response => {
              const deviceId = this.props.match.params.id;
              api.post(`/device/${deviceId}/calibration_image`, params)
                .then(response => {
                    this.setState({deviceId: deviceId, deviceEdited: true});
                    AdminStore.updateDeviceName(deviceId, deviceName);
                })
            });
        } else { // add new device

            const selectedModel = this.getSelectedModel();

            const params = {
                premise_id: this.state.premiseId,
                name: deviceName,
                model: {
                    model_id: selectedModel.id,
                    name: selectedModel.name,
                },
                request_json: {
                    url: this.getFieldValue(this.state.deviceUrl, currentDevice.request_json.url, 'deviceUrl'),
                    auth: {
                        class: "HTTPBasicAuth",
                        username: this.getFieldValue(this.state.deviceUsername, currentDevice.request_json.auth.username, 'deviceUsername'),
                        password: this.getFieldValue(this.state.devicePassword, currentDevice.request_json.auth.password, 'devicePassword')
                    },
                    method: "GET"
                },
                active: "False"
            };

            api
            .post(`/device`, params)
            .then(response => {
                const deviceId = response.data.device_id;
                api.post(`/device/${deviceId}/calibration_image`, {})
                  .then(response => {
                      this.setState({addedDeviceId: deviceId, deviceAdded: true});
                  })
            });

        }
    }

    refreshCalibrationImage() {
        const deviceId = this.props.match.params.id;
        this.setState({fetchingImage: true});
        api.post(`/device/${deviceId}/calibration_image`, {})
          .then(response => {
            this.setState({fetchingImage: false});
          });
    }

    deleteDevice() {
        api
        .delete(`/device/${this.props.match.params.id}`)
        .then(response => {
            this.setState({ deviceDeleted: this.props.match.params.id, deleteStatus: true});
            AdminStore.fetchDevices();
        })
        .catch((error) => {
            this.setState({ deviceDeleted: this.props.match.params.id, deleteStatus: false});
        });
    }

    showModal() {
        if(this.props.match.params.id) {
            AdminStore.fetchImage(this.props.match.params.id);
        } else if(this.state.addedDeviceId) {
            AdminStore.fetchImage(this.state.addedDeviceId);
        }
    }

    getFieldValue(stateValue, responseValue, propertyKey) {
        if(this.state.inputDirty[propertyKey] && stateValue !== '') {
          return stateValue;
        } else if(responseValue && !this.state.inputDirty[propertyKey]) {
          return responseValue;
        } else {
          return '';
        }
    }

    deviceAddedContent() {
        const { formatMessage } = this.props.intl;

        if(!this.isOrgAdmin()) {
            return '';
        }

        return (
            <div className="Admin">
                <Header {...this.props} setLanguage={this.props.setLanguage} />
                <Sidebar devices={AdminStore.devices} premises={AdminStore.premises} />

                <div className="Admin__Content">
                    <div>
                        <h1 className="Admin__Title"><FormattedMessage id="admin.addDevice" /></h1>
                        <p><FormattedMessage id="admin.deviceAddedInfo" /></p>

                        { AdminStore.loadingCalibrationImage===true ? (
                            <div className="EquipmentDialog__Loading">
                                <img
                                src={loadingIcon}
                                alt="Loading..."
                                style={{position: "absolute", left: "50%", transform: "translateX(-50%)"}}
                                />
                            </div>
                        ): (
                            <img alt="Calibration" src={AdminStore.image} style={ {width: '50%'}} />
                        ) }

                        <div style={ {clear: 'both'}}>
                            <Button
                                href={`/admin/${this.props.match.params.premiseId}/mapping/${this.state.addedDeviceId}`}
                                raised
                                primary
                                className="Admin__Save">
                                { formatMessage({id: 'admin.startMapping'})}
                            </Button>
                            <Button
                                href={`/admin/${this.props.match.params.premiseId}/device/${this.state.addedDeviceId}`}
                                raised
                                className="Admin__Button">
                                { formatMessage({id: 'admin.editDeviceConfiguration'})}
                            </Button>
                        </div>

                    </div>
                </div>
            </div>
        );
    }

    deviceDeleteConsent() {
        const { formatMessage } = this.props.intl;

        if(this.state.deviceDeleted && this.state.deleteStatus === true) {
            return <Redirect to={`/admin/premise/${this.props.match.params.premiseId}/`} />
        } else if(this.state.deviceDeleted && this.state.deleteStatus === false) {
            return (
                <div className="Admin">
                <Header {...this.props} setLanguage={this.props.setLanguage} />
                <Sidebar devices={AdminStore.devices} premises={AdminStore.premises} />
    
                <div className="Admin__Content">
                    <div>
                        <h1 className="Admin__Title"><FormattedMessage id="admin.deleteDevice" /></h1>
                        <p><FormattedMessage id="admin.deleteFailed" /></p>
                        <div style={ {clear: 'both'}}>
                            <Button
                                href={`/admin/${this.props.match.params.premiseId}/device/${this.props.match.params.id}`}
                                raised
                                className="Admin__Button">
                                { formatMessage({id: 'admin.cancel'})}
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
            );
        } else {
            return (
                <div className="Admin">
                <Header {...this.props} setLanguage={this.props.setLanguage} />
                <Sidebar devices={AdminStore.devices} premises={AdminStore.premises} />
    
                <div className="Admin__Content">
                    <div>
                        <h1 className="Admin__Title"><FormattedMessage id="admin.deleteDevice" /></h1>
                        <p><FormattedMessage id="admin.areYouSureToDeleteDevice" /></p>
                        <div style={ {clear: 'both'}}>
                            <Button
                                raised
                                onClick={(e) => { e.preventDefault(); this.deleteDevice(); }}
                                className="Admin__Delete">
                                { formatMessage({id: 'admin.delete'})}
                            </Button>
                            <Button
                                href={`/admin/${this.props.match.params.premiseId}/device/${this.props.match.params.id}`}
                                raised
                                className="Admin__Button">
                                { formatMessage({id: 'admin.cancel'})}
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
            );
        }
    }

    deviceEditedContent() {
        const { formatMessage } = this.props.intl;

        return (
            <div className="Admin">
            <Header {...this.props} setLanguage={this.props.setLanguage} />
            <Sidebar devices={AdminStore.devices} premises={AdminStore.premises} />

            <div className="Admin__Content">
                <div>
                    <h1 className="Admin__Title"><FormattedMessage id="admin.editDeviceConfiguration" /></h1>
                    <p>{ formatMessage({id: 'admin.changesSaved'}) }</p>
                    <div style={ {clear: 'both'}}>
                        <Button
                            href={`/admin/premise/${this.props.match.params.premiseId}`}
                            raised
                            style={{marginLeft: 0}}
                            className="Admin__Button">
                            { formatMessage({id: 'admin.back'})}
                        </Button>
                    </div>
                </div>
            </div>
        </div>
        );
    }

    renderForm() {
        const { formatMessage } = this.props.intl;

        if(AdminStore.loadingDevices === false) {
            const currentDevice = this.getCurrentDevice();

            let model;
            if(AdminStore.selectedModel) {
                model = toJS(AdminStore.selectedModel);
            } else if(currentDevice && currentDevice.model.model_id) {
                model = {[currentDevice.model.model_id]: true};
            } else {
                model = {};
            }

            const actions = [];
            actions.push({
                 secondary: true,
                 children: formatMessage({id: 'admin.close'}),
                 onClick: () => { this.setState({modalOpen: false}); }
            });

            return (
                <div className="Admin">
                    <Header {...this.props} setLanguage={this.props.setLanguage} />
                    <Sidebar devices={AdminStore.devices} premises={AdminStore.premises} />

                    <div className="Admin__Content">

                        <Link to="/admin" className="Admin__BackLink">
                            <FontIcon>keyboard_backspace</FontIcon>{ formatMessage({id: 'admin.back'})}
                        </Link>
    
                        {this.props.match.params.id ? (
                            <h1 className="Admin__Title"><FormattedMessage id="admin.editDeviceConfiguration" /></h1>
                        ) : (
                            <h1 className="Admin__Title"><FormattedMessage id="admin.addDevice" /></h1>
                        )}

                            <TextField
                              id="floating-center-title"
                              label={ formatMessage({id: 'admin.deviceName'})}
                              lineDirection="center"
                              placeholder={ formatMessage({id: 'admin.deviceName'})}
                              className="md-cell md-cell--top"
                              value={ this.getFieldValue(this.state.deviceName, currentDevice.name, 'deviceName') }
                              onChange={(value) => {
                                this.setState({deviceName: value, inputDirty: {...this.state.inputDirty, deviceName: true}});
                              }
                            }
                            helpText={ formatMessage({id: 'admin.deviceNameHelp'})}
                            />
                            { AdminStore.brands.length > 0 || AdminStore.models.length > 0 ?
                            (
                                <div className="Admin__editDeviceSelector">
                                    <label><FormattedMessage id="admin.deviceModel" /></label>
                                    <MultiSelector
                                    type="brand"
                                    items={AdminStore.models}
                                    onChange={modelId => {
                                        AdminStore.setSelectedDeviceModel(modelId);
                                    }}
                                    selectedItems={ model }
                                    forceSingleSelection={true}
                                    valueProperty="name"
                                    />
                                </div>
                            ) : ( '' ) }
                            <TextField
                            id="floating-center-title"
                            label={ formatMessage({id: 'admin.deviceUrl'})}
                            lineDirection="center"
                            placeholder={ formatMessage({id: 'admin.devicePlaceholder'})}
                            className="md-cell md-cell--top"
                            value={ this.getFieldValue(this.state.deviceUrl, currentDevice.request_json.url, 'deviceUrl') }
                            onChange={(value) => {
                              this.setState({deviceUrl: value, authInfoTouched: true, inputDirty: {...this.state.inputDirty, deviceUrl: true}});
                            }}
                            helpText={ formatMessage({id: 'admin.deviceUrlHelp'})}
                            />
                            <TextField
                            id="floating-center-title"
                            label={ formatMessage({id: 'admin.deviceUsername'})}
                            lineDirection="center"
                            placeholder={ formatMessage({id: 'admin.deviceUsername'})}
                            className="md-cell md-cell--top"
                            helpText={ formatMessage({id: 'admin.deviceUsernameHelp'})}
                            value={ this.getFieldValue(this.state.deviceUsername, currentDevice.request_json.auth.username, 'deviceUsername') }
                            onChange={(value) => {
                              this.setState({deviceUsername: value, authInfoTouched: true, inputDirty: {...this.state.inputDirty, deviceUsername: true}});
                            }}
                            />
                            <TextField
                            id="floating-center-title"
                            label={ formatMessage({id: 'admin.devicePassword'})}
                            lineDirection="center"
                            placeholder={ formatMessage({id: 'admin.devicePassword'})}
                            className="md-cell md-cell--top"
                            helpText={ formatMessage({id: 'admin.devicePasswordHelp'})}
                            value={ this.getFieldValue(this.state.devicePassword, currentDevice.request_json.auth.password, 'devicePassword') }
                            onChange={(value) => {
                              this.setState({devicePassword: value, authInfoTouched: true, inputDirty: {...this.state.inputDirty, devicePassword: true}});
                            }}
                            />

                            { this.props.match.params.id ? (
                                <div>
                                    <SelectionControl
                                    id="is-active"
                                    type="switch"
                                    label={ formatMessage({id: 'admin.deviceActive'})}
                                    name="active"
                                    checked={ this.state.deviceActive === null ? (currentDevice.active === true ? true : false) : this.state.deviceActive }
                                    onChange={(checked) => { this.setState({deviceActive: checked ? true : false})}}
                                    defaultChecked
                                    />
                                </div>
                            ) : '' }

                            <Button raised primary className="Admin__Save" onClick={(e) => { this.saveChanges()}}>
                                { formatMessage({id: 'admin.saveChanges'})}
                            </Button>

                            { this.props.match.params.id ? (
                                <Button raised className="Admin__Delete" onClick={(e) => { this.setState({deleteDevice: true}) }}>
                                    { formatMessage({id: 'admin.delete'})}
                                </Button>
                            ) : null }

                            { this.state.authInfoTouched === false && this.props.match.params.id ? (
                                <Button raised className="Admin__Button" onClick={(e) => { this.setState({modalOpen: true}) }}>
                                    { formatMessage({id: 'admin.viewCalibrationImage'})}
                                </Button>
                            ) : null }

                            { this.state.authInfoTouched === false && this.props.match.params.id  && this.state.fetchingImage === false ? (
                                <Button raised className="Admin__Button" onClick={(e) => { this.refreshCalibrationImage(); }}>
                                    { formatMessage({id: 'admin.refreshCalibrationImage'})}
                                </Button>
                            ) : null }
    
                            <DialogContainer
                                id="speed-boost"
                                visible={this.state.modalOpen}
                                onShow={() => this.showModal()}
                                width={800}
                                height={640}
                                focusOnMount={false}
                                actions={actions}
                                className="EquipmentDialog"
                                aria-label="Calibration image"
                                modal
                            >
                            { AdminStore.loadingCalibrationImage===true ? (
                                <div className="EquipmentDialog__Loading">
                                    <img
                                    src={loadingIcon}
                                    alt="Loading..."
                                    style={{position: "absolute", left: "50%", transform: "translateX(-50%)"}}
                                    />
                                </div>
                            ): (
                                <img alt="Calibration" src={AdminStore.image} style={ {width: '100%'}} />
                            ) }
                            </DialogContainer>
                    </div>
                </div>
            );

        } else {

            return (
                <div className="Admin">
                    <Header {...this.props} setLanguage={this.props.setLanguage} />
                    <div className="Admin__Content" style={{minHeight: '600px', width:'100%'}}>
                        <img
                        src={loadingIcon}
                        alt="Loading..."
                        style={{
                            position: "absolute",
                            left: "50%",
                            transform: "translateX(-50%)"
                        }}
                        />
                    </div>
                </div>
            );

        }
    }

    render() {
        if( this.state.deviceAdded === true) {
            return this.deviceAddedContent();
        } else if( this.state.deviceEdited === true) {
            return this.deviceEditedContent();
        } else if( this.state.deleteDevice === true) {
            return this.deviceDeleteConsent();
        } else {
            return this.renderForm();
        }
    }
  }
));

export default injectIntl(EditDevice);
