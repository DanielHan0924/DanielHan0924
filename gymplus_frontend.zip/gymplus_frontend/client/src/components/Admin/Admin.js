import React from "react";

import { injectIntl } from "react-intl";
import { observer } from "mobx-react";
import { withRouter } from 'react-router';
import "react-md/dist/react-md.green-blue.min.css";

import Header from "../Header/Header";
import Sidebar from "./Sidebar/Sidebar";
import Content from "./Content/Content";

import AdminStore from "../../models/AdminStore";

import "./Admin.scss";

import Auth from "../../services/Auth";
const auth = new Auth();

const Admin = withRouter(observer(
  class Admin extends React.Component {
    componentWillMount() {
      const { isAuthenticated } = auth;

      if(isAuthenticated()) {
        this.setState({ profile: {} });
        const { userProfile, getProfile } = auth;
        if (!userProfile) {
          getProfile((err, profile) => {
            this.setState({ profile });
          });
        } else {
          this.setState({ profile: userProfile });
        }
      }
    }
    isOrgAdmin() {
      if(this.state.profile && this.state.profile['https://indoorinformatics.com/claims/roles'] ) {
        const roles = this.state.profile['https://indoorinformatics.com/claims/roles'];
        return roles.indexOf('OrganizationAdmin') !== -1
      } 
      return false;
    }
    componentDidMount() {
      AdminStore.fetchPremises();
      AdminStore.fetchDevices();
    }
    render() {
      if(!this.isOrgAdmin()) {
        return '';
      }
      return (
        <div className="Admin">
          <Header {...this.props} setLanguage={this.props.setLanguage} />
          <Sidebar devices={AdminStore.devices} premises={AdminStore.premises} />
          <Content devices={AdminStore.devices} premises={AdminStore.premises} />
        </div>
      );
    }
  }
));

export default injectIntl(Admin);
