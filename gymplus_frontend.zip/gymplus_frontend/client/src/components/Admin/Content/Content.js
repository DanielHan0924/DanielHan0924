import React from "react";
import { toJS } from "mobx";
import { injectIntl } from "react-intl";
import { observer } from "mobx-react";
import _ from "lodash";
import { FormattedMessage } from "react-intl";
import { Link } from "react-router-dom";
import { FontIcon } from "react-md";
import { withRouter } from 'react-router';

import "react-md/dist/react-md.green-blue.min.css";

import "./Content.scss";

import loadingIcon from "../../../assets/images/loading.svg";

const AdminContent = observer(
  class AdminContent extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            goToDevice: null,
        }
    }

    render() {
        const premises = toJS(this.props.premises);

        let devices = toJS(this.props.devices);
        devices = _.sortBy(devices, 'name');

        let premiseId;
        let selectedDevices;

        if(this.props.match.params.premiseId) {
            premiseId = parseInt(this.props.match.params.premiseId, 10);
            selectedDevices = _.filter(devices, { premise_id: premiseId });
        } else {
            premiseId = null;
            selectedDevices = [];
        }

        if(premises && premises.length > 0 && devices && devices.length > 0) {
            return (
            <div className="Admin__Content">

                <h1 className="Admin__Title"><FormattedMessage id="admin.deviceAndEquipmentManagement" /></h1>
                <p><FormattedMessage id="admin.indexInfo" /></p>

                <h2 className="Admin__SubTitle"><FormattedMessage id="admin.yourPremises" /></h2>

                { _.map(premises, (premise) => {
                    return (
                        <Link 
                            to={`/admin/premise/${premise.id}`}
                            key={premise.id}
                            className={ `Admin__SelectionLink ${premiseId === premise.id ? 'Admin__SelectionLink--selected' : ''} `}>
                            {premise.name}
                        </Link>
                    );
                })}

                { selectedDevices.length > 0 ? (
                    <div className="Admin__FrontButtonGroup">
                        <h2 className="Admin__SubTitle"><FormattedMessage id="admin.premiseDevices" /></h2>

                        <div className="ButtonGroup">
                            { _.map(selectedDevices, (device) => {
                                return (
                                    <Link 
                                        key={device.id}
                                        to={`/admin/${premiseId}/mapping/${device.id}`}
                                        className="Admin__SelectionLink">
                                        {device.name}
                                    </Link>
                                );
                            })}
                        </div>

                        <Link to={`/admin/${this.props.match.params.premiseId}/device`} className="Admin__AddLink" style={{clear:'both'}}>
                            <FontIcon>add_circle</FontIcon> <FormattedMessage id="admin.addDevice" />
                        </Link>
                    </div>
                ) : '' }
            </div>
            );
        } else {
            return (
            <div className="Admin__Content" style={{minHeight: '600px', width:'100%'}}>
                <img
                src={loadingIcon}
                alt="Loading..."
                style={{
                    position: "absolute",
                    left: "50%",
                    transform: "translateX(-50%)"
                }}
                />
            </div>
            );
        }
    }
  }
);

export default withRouter(injectIntl(AdminContent));
