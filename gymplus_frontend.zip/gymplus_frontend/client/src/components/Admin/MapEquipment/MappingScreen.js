import React from "react";
import { injectIntl, FormattedMessage } from "react-intl";
import { observer } from "mobx-react";
import { toJS } from "mobx";
import { DialogContainer, Button } from "react-md";
import _ from "lodash";
import { Link } from "react-router-dom";
import { withRouter } from "react-router";

import "react-md/dist/react-md.green-blue.min.css";

import ApiMiddleware from "../../../services/Api";
import Auth from "../../../services/Auth";

import AdminStore from "../../../models/AdminStore";

import BoundingBox from "./BoundingBox";
import EditEquipmentForm from "./Dialogs/EditEquipmentForm";
import AddEquipmentForm from "./Dialogs/AddEquipmentForm";

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const MappingScreen = observer(
  class MappingScreen extends React.Component {
    componentDidMount() {

        AdminStore.fetchImage(this.props.deviceId);
        AdminStore.setCurrentDevice(this.props.deviceId);

        const canvas = document.getElementById('canvas');
        var mouse = { x: 0, y: 0, startX: 0, startY: 0 };
        var element = null;
        const { setMousePosition, updateBoundingBox } = this;

        canvas.onmousemove = function (e) {
            setMousePosition(e, mouse, canvas);
            if (element !== null) {
                element.style.width = Math.abs(mouse.x - mouse.startX) + 'px';
                element.style.height = Math.abs(mouse.y - mouse.startY) + 'px';
                element.style.left = (mouse.x - mouse.startX < 0) ? mouse.x + 'px' : mouse.startX + 'px';
                element.style.top = (mouse.y - mouse.startY < 0) ? mouse.y + 'px' : mouse.startY + 'px';
            }
        }

        canvas.onclick = function (e) {
            if (element !== null) {

                // End click

                element.id = 'equipment-temporary';
                //element.addEventListener("click", test, false);
                element = null;

                // Set initial ending coordinate
                let percentY = mouse.y / canvas.offsetHeight; // coordinate y
                let percentX = mouse.x / canvas.offsetWidth; // coordinate x
                AdminStore.setDrawingEndCoordinates(percentX, percentY);
                canvas.style.cursor = "default";

                // Pop up modal to save or add equipment
                if(AdminStore.redrawing === false) {
                    AdminStore.setMappingNew(true);
                } else {
                    // Update coordinates
                    updateBoundingBox();
                }
                AdminStore.setDrawing(false);

            } else {
                if(AdminStore.drawing === true) {

                    // Start click

                    let percentY = mouse.y / canvas.offsetHeight; // coordinate y
                    let percentX = mouse.x / canvas.offsetWidth; // coordinate x

                    // Set initial starting coordinate
                    AdminStore.setDrawingStartCoordinates(percentX, percentY);

                    mouse.startX = mouse.x;
                    mouse.startY = mouse.y;

                    element = document.createElement('div');
                    element.className = 'rectangle';

                    element.style.left = mouse.x + 'px';
                    element.style.top = mouse.y + 'px';
                    canvas.appendChild(element)
                    canvas.style.cursor = "crosshair";

                }
            }
        }
    }

    updateBoundingBox() {
        const boundingCoordinates = toJS(AdminStore.drawingCoordinates);
        
        let boundingBox = [];
        if(boundingCoordinates[0].x < boundingCoordinates[1].x) {
            boundingBox[0] = boundingCoordinates[0].x;
            boundingBox[2] = boundingCoordinates[1].x;
        } else {
            boundingBox[0] = boundingCoordinates[1].x;
            boundingBox[2] = boundingCoordinates[0].x;
        }

        if(boundingCoordinates[0].y < boundingCoordinates[1].y) {
            boundingBox[1] = boundingCoordinates[0].y;
            boundingBox[3] = boundingCoordinates[1].y;
        } else {
            boundingBox[1] = boundingCoordinates[1].y;
            boundingBox[3] = boundingCoordinates[0].y;
        }

        const locationParams = {
            equipment_id: AdminStore.redrawingEquipmentId,
            device_id: AdminStore.currentDevice,
            bounding_box: boundingBox
        };

        api
        .put(`/equipment/${AdminStore.redrawingEquipmentId}/device_equipment_location/${AdminStore.redrawingBoxId}`, locationParams)
        .then(response => {
            AdminStore.fetchEquipment();
            AdminStore.setRedrawing(false, null, null);
            document.getElementById('equipment-temporary').outerHTML = "";
        });
    }

    editClick(equipmentId) {
        AdminStore.setMapping(true);
        AdminStore.setEditing(equipmentId);
    }

    redrawClick(boxId, equipmentId) {
        AdminStore.setRedrawing(true, boxId, equipmentId);
        AdminStore.setDrawing(true);
    }

    setMousePosition(e, mouse, canvas) {
        var ev = e || window.event; //Moz || IE
        var bodyRect = document.body.getBoundingClientRect();
        var elemRect = canvas.getBoundingClientRect();

        if (ev.pageX) { //Moz
            mouse.x = ev.pageX - elemRect.left + bodyRect.left;
            mouse.y = ev.pageY - elemRect.top + bodyRect.top;
        } else if (ev.clientX) { //IE
            mouse.x = ev.clientX + document.body.scrollLeft;
            mouse.y = ev.clientY + document.body.scrollTop;
        }
    }

    removeBoundingBox(boxId, equipmentId) {
        AdminStore.setRemoving(true);
        AdminStore.setRemovingBox(boxId, equipmentId);
    }

    confirmRemovingBoundingBox() {
        const equipmentId = AdminStore.removingEquipmentId;
        const boxId = AdminStore.removingBoxId;

        api
        .delete(`/equipment/${equipmentId}/device_equipment_location/${boxId}/`)
        .then(response => {
            AdminStore.fetchEquipment();
        });
    }

    getBoundingBoxesInThisCamera(allEquipment) {
        let boundingBoxes = [];

        _.each( toJS(allEquipment), (equipment) => {

            const isMappedInDevice = _.filter(equipment.device_id_location, (item) => {
                return parseInt(item.device_id, 10) === parseInt(this.props.deviceId, 10);
            });

            _.each(isMappedInDevice, (boundingBox) => {
                boundingBoxes.push({
                    id: boundingBox.id,
                    equipment_id: equipment.id,
                    name: equipment.name,
                    bounding_box: boundingBox.device_equipment_boundingbox
                });
            });

        });

        return boundingBoxes;
    }

    getCalibrationImage() {
        if(AdminStore.image) {
            return `url(${AdminStore.image})`;
        }

        return '';
    }

    getInactiveNotification() {
        if(this.props.currentDevice[0].active === false) {
            return (
                <div className="MapEquipment__CameraInactive">
                    <FormattedMessage id="admin.cameraNotActiveInfo" />
                    <Link to={`/admin/${this.props.match.params.premiseId}/device/${this.props.match.params.id}`}>
                        <FormattedMessage id="admin.editCameraSettings" />
                    </Link>
                </div>
            )
        }    
    }

    getEditEquipmentDialog() {
        const { formatMessage } = this.props.intl;
        return (
        <DialogContainer
            id="editEquipmentDialog"
            visible={AdminStore.mapping}
            onShow={this.showModal}
            aria-label="Edit equipment"
            focusOnMount={false}
            onHide={() => AdminStore.setEditing(null)}
            width={400}
            className="EquipmentDialog"
            modal>
            <EditEquipmentForm
                formatMessage={formatMessage}
                equipment={this.props.equipment}
                models={this.props.equipmentModels}
                categories={this.props.categories}
                premiseId={this.props.currentDevice[0].premise_id}
            />
        </DialogContainer>
        )
    }

    getAddEquipmentDialog() {
        const { formatMessage } = this.props.intl;
        return (                
        <DialogContainer
            id="addEquipmentDialog"
            visible={AdminStore.mappingNew}
            onShow={this.showModal}
            aria-label="Add equipment"
            focusOnMount={false}
            width={400}
            className="EquipmentDialog EquipmentDialog--Add"
            modal>
            <AddEquipmentForm
                formatMessage={formatMessage}
                equipment={this.props.equipment}
                models={this.props.equipmentModels}
                categories={this.props.categories}
                deviceId={this.props.deviceId}
                premiseId={this.props.currentDevice[0].premise_id}
            />
        </DialogContainer>
        )
    }

    getBoundingBoxRemovalDialog() {
        return (
            <DialogContainer
                id="removeBoundingBoxDialog"
                visible={AdminStore.removing}
                className="EquipmentDialog"
                aria-label="remove bounding box"
                width={400}
                onHide={ () => AdminStore.setRemoving(false) }>
                <div>
                    <p className="Admin__ConfirmRemoveInfo"><FormattedMessage id="admin.confirmEquipmentDelete" /></p>
                    <div className="Admin__addDeviceActions">
                        <Button 
                            flat 
                            primary 
                            className="Admin__addDeviceCancelButton" 
                            onClick={() => AdminStore.setRemoving(false)}>
                            <FormattedMessage id="admin.cancel" />
                        </Button> 
                        <Button 
                            flat 
                            primary 
                            className="Admin__addDeviceDeleteButton" 
                            onClick={() => {
                                AdminStore.resetEquipment();
                                this.confirmRemovingBoundingBox();
                                AdminStore.setRemoving(false);
                            }}>
                            <FormattedMessage id="admin.deleteBoundingBox" />
                        </Button>
                    </div>
                </div>
            </DialogContainer>
        )
    }

    render() {

        const boundingBoxes = this.getBoundingBoxesInThisCamera(this.props.equipment);
        const background = this.getCalibrationImage();

        return (
            <div className="MapEquipment_MappingScreen">

                { this.getInactiveNotification() }

                <div
                    className={ `MapEquipment__Camera ${AdminStore.drawing ? 'drawing' : ''}`}
                    id="canvas"
                    ref="canvas"
                    style={ { backgroundImage: background } }>

                    <div className={`MapEquipment__LoadingOverlay ${ toJS(AdminStore.equipment).length > 0 ? 'hidden' : ''}`}>
                        <div className="MapEquipment__LoadingText"><FormattedMessage id="admin.loading" /></div>
                    </div>

                    { _.map(boundingBoxes, (box) => {
                        return (
                            <BoundingBox
                                id={ `box-${box.id}` }
                                equipmentId={ box.equipment_id }
                                hovered={ AdminStore.hoveringEquipment === box.equipment_id ? true: null }
                                key={box.id}
                                onClick={() => {
                                    if(AdminStore.drawing === false && AdminStore.mappingNew === false) {
                                        this.editClick(box.equipment_id, box.id);
                                    }
                                }}
                                onEditClick={() => {
                                    this.redrawClick(box.id, box.equipment_id);
                                }}
                                onDeleteClick={() => {
                                    this.removeBoundingBox(box.id, box.equipment_id)
                                }}
                                left={box.bounding_box[0]}
                                top={box.bounding_box[1]}
                                width={box.bounding_box[2] - box.bounding_box[0]}
                                height={box.bounding_box[3] - box.bounding_box[1]} />
                        );
                    })}

                </div>

                { this.getEditEquipmentDialog() }
                { this.getAddEquipmentDialog() }
                { this.getBoundingBoxRemovalDialog() }


            </div>
        );
    }
  }
);

export default withRouter(injectIntl(MappingScreen));
