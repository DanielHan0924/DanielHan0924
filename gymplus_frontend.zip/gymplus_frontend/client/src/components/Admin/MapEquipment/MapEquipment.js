import React from "react";
import { injectIntl } from "react-intl";
import { observer } from "mobx-react";
import { FormattedMessage } from "react-intl";
import { withRouter } from 'react-router';
import { Link } from 'react-router-dom';
import _ from "lodash";
import { FontIcon } from 'react-md';

import "react-md/dist/react-md.green-blue.min.css";
import "./MapEquipment.scss";
import loadingIcon from "../../../assets/images/loading.svg";

import Header from "../../Header/Header";
import Sidebar from "../Sidebar/Sidebar";
import MappingScreen from "./MappingScreen";

import ApiMiddleware from "../../../services/Api";
import Auth from "../../../services/Auth";

import AdminStore from "../../../models/AdminStore";

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const MapEquipment = withRouter(observer(
  class MapEquipment extends React.Component {
    constructor(props) {
        super(props);

        // Use React's state to hold simple form values
        this.state = {
            deviceId: this,
            modalOpen: false,
            adding: false,
        }
    }
    isOrgAdmin() {
      if(this.state.profile && this.state.profile['https://indoorinformatics.com/claims/roles'] ) {
        const roles = this.state.profile['https://indoorinformatics.com/claims/roles'];
        return roles.indexOf('OrganizationAdmin') !== -1
      } 
      return false;
    }

    componentWillMount() {
      const { isAuthenticated } = auth;

      if(isAuthenticated()) {
        this.setState({ profile: {} });
        const { userProfile, getProfile } = auth;
        if (!userProfile) {
          getProfile((err, profile) => {
            this.setState({ profile });
          });
        } else {
          this.setState({ profile: userProfile });
        }
      }
    }
    componentDidMount() {
        AdminStore.fetchPremises();
        AdminStore.fetchDevices();
        AdminStore.fetchEquipmentModels();
        AdminStore.fetchEquipment();
        AdminStore.fetchCategories();
    }
    
    breadcrumb() {
        const premises = AdminStore.premises;
        const devices = AdminStore.devices;
        const deviceId = parseInt(this.props.match.params.id, 10);
        const currentDevice = _.find(AdminStore.devices, { id: deviceId });
        const premiseId = currentDevice.premise_id;
        const selectedDevices = _.filter(devices, { premise_id: premiseId });

        return selectedDevices.length > 0 ? (
            <div className="Admin__PremiseAndDeviceSelector">
                <div className="Admin__PremiseSelector">
                    { _.map(premises, (premise) => {
                        return (
                            <Link 
                                key={premise.id}
                                to={`/admin/premise/${premise.id}`}
                                className={` ${ premise.id === currentDevice.premise_id ? 'selected' : '' }`}>
                                {premise.name}
                            </Link>
                        );
                    })}
                </div>
                <div className="ButtonGroup" style={{overflow: 'auto'}}>
                    { _.map(selectedDevices, (device) => {
                        return (
                            <Link 
                                key={device.id}
                                to={`/admin/${premiseId}/mapping/${device.id}`}
                                className={`Admin__SelectionLink ${ device.id === currentDevice.id ? 'Admin__SelectionLink--selected' : '' }`}>
                                {device.name}
                            </Link>
                        );
                    })}
                </div>
            </div>
        ) : '';
    }

    render() {

        if(!this.isOrgAdmin()) {
            return '';
        }

        const actions = [];
        actions.push({
             secondary: true,
             children: 'Cancel',
             onClick: () => { AdminStore.setMapping(false); }
        });

        if(AdminStore.loadingDevices) {
            return (

                <div className="Admin">
                    <Header {...this.props} setLanguage={this.props.setLanguage} />
                    <div className="Admin__Content" style={{minHeight: '600px', width:'100%'}}>
                        <img
                        src={loadingIcon}
                        alt="Loading..."
                        style={{
                            position: "absolute",
                            left: "50%",
                            transform: "translateX(-50%)"
                        }}
                        />
                    </div>
                </div>
            )
        } else {
            const deviceId = parseInt(this.props.match.params.id, 10);
            const currentDevice = _.filter(AdminStore.devices, { id: deviceId });

            return (
                <div className="Admin">
                    <Header {...this.props} setLanguage={this.props.setLanguage} />
                    <Sidebar
                        devices={AdminStore.devices}
                        equipment={AdminStore.equipment}
                        currentDevice={currentDevice}
                        premises={AdminStore.premises} />

                    <div className="Admin__Content">

                        <div className="Admin__MappingTop">
                            { this.breadcrumb() }
                        </div>
                        <div className="Admin__MapDeviceAction">
                            <a href="/" className="Admin__TitleAdd" onClick={(e) => {
                                e.preventDefault();
                                AdminStore.setDrawing(!AdminStore.drawing);
                            }}>
                                <FontIcon>add_circle</FontIcon> <FormattedMessage id="admin.mapEquipment" />
                            </a>
                        </div>

                        <MappingScreen
                            equipment={AdminStore.equipment}
                            equipmentModels={AdminStore.equipmentModels}
                            categories={AdminStore.categories}
                            currentDevice={currentDevice}
                            deviceId={deviceId} />
                    </div>
                </div>
            );
        }
    }
  }
));

export default injectIntl(MapEquipment);
