import React from 'react';
import { observer } from 'mobx-react';
import { injectIntl, FormattedMessage } from 'react-intl';
import _ from 'lodash';
import { TextField, Button, SelectionControl } from "react-md";
import { SingleDatePicker } from 'react-dates';
import moment from 'moment';

import ApiMiddleware from "../../../../services/Api";
import Auth from "../../../../services/Auth";

import MultiSelector from "../../../MultiSelector/MultiSelector";

import AdminStore from "../../../../models/AdminStore";

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const EditEquipmentForm = observer(
    class EditEquipmentForm extends React.Component {
      constructor(props) {
            super(props);

            const { equipment} = this.props;
    
            const selectedEquipment = _.find(equipment, (eq) => {
                return parseInt(eq.id, 10) === AdminStore.editingEquipment;
            });
  
            this.state = {
                equipment: {
                    id: selectedEquipment.id,
                    name: selectedEquipment.name,
                    model: selectedEquipment.model.id,
                    category: selectedEquipment.equipment_category_id,
                    purchaseDate: moment(selectedEquipment.purchase_date),
                    purchasePrice: selectedEquipment.purchase_price,
                    active: selectedEquipment.active,
                },
                confirmingDelete: false,
            }
      }    
  
      handleFormSubmit() {
        const params = {
            premise_id: this.props.premiseId,
            name: this.state.equipment.name,
            model: { id: this.state.equipment.model },
            equipment_category_id: this.state.equipment.category,
            purchase_date: moment(this.state.equipment.purchaseDate).toISOString(),
            purchase_price: this.state.equipment.purchasePrice,
            tag: null,
            active: this.state.equipment.active === true ? 'True' : 'False',
        };

        const selectedCategory = _.find(this.props.categories, (c) => { 
            return `${c.id}` === `${this.state.equipment.category}`;
        });

        if(selectedCategory && selectedCategory.equipment_category_id_parent) {
            params.equipment_category_id_parent = selectedCategory.equipment_category_id_parent;
        }
        AdminStore.setMapping(false);
        AdminStore.resetEquipment();

        api
        .put(`/equipment/${this.state.equipment.id}`, params)
        .then(response => { 
            AdminStore.fetchEquipment();
        });
      }

      handleCancel() {
          AdminStore.setMapping(false);
      }

      processDelete() {
        api
        .delete(`/equipment/${this.state.equipment.id}`)
        .then(response => {
            AdminStore.setMapping(false);
            AdminStore.fetchEquipment();
        });
      }

      confirmDelete() {
          return (
            <div>
                <p className="Admin__ConfirmRemoveInfo"><FormattedMessage id="admin.confirmEquipmentDelete" /></p>
                <div className="Admin__addDeviceActions">
                    <Button flat primary className="Admin__addDeviceCancelButton" onClick={() => this.setState({confirmingDelete: false})}><FormattedMessage id="admin.cancel" /></Button> 
                    <Button flat primary className="Admin__addDeviceDeleteButton" onClick={() => this.processDelete()}><FormattedMessage id="admin.deleteEquipment" /></Button>
                </div>
            </div>
          );
      }

      render() {
        const { formatMessage, categories, models } = this.props;

        if(this.state.confirmingDelete === true) {
            return this.confirmDelete();
        }

        return (
        <div>
            <TextField
                id="floating-center-title"
                label={ formatMessage({id: 'admin.equipmentName'})}
                lineDirection="center"
                placeholder={ formatMessage({id: 'admin.equipmentName'})}
                className="md-cell md-cell--top"
                value={this.state.equipment.name}
                onChange={(value) => {
                    this.setState({
                        equipment: {
                            ...this.state.equipment,
                            name: value
                        }
                    })
                }}
            />
            { models && models.length > 0 ? (
                <div className="Admin__editDeviceSelector">
                    <label>{ formatMessage({id: 'admin.equipmentBrand'})}</label>
                    <MultiSelector
                    type="brand"
                    items={models}
                    onChange={modelId => {
                        this.setState({
                            equipment: {
                                ...this.state.equipment,
                                model: modelId,
                            }
                        })
                    }}
                    selectedItems={ this.state.equipment.model ? {[this.state.equipment.model]: true} : {} }
                    forceSingleSelection={true}
                    disableTopLevelSelection={true}
                    valueProperty="name"
                    />
                </div>
            ) : '' }
            { categories && categories.length > 0 ? (
                <div className="Admin__editDeviceSelector">
                    <label>{ formatMessage({id: 'admin.equipmentCategory'})}</label>
                    <MultiSelector
                    type="category"
                    items={categories}
                    onChange={categoryId => {
                        this.setState({
                            equipment: {
                                ...this.state.equipment,
                                category: categoryId,
                            }
                        })
                    }}
                    selectedItems={ this.state.equipment.category ? {[this.state.equipment.category]: true} : {} }
                    forceSingleSelection={true}
                    valueProperty="name"
                    />
                </div>
            ) : '' }

            <div className="Admin__editEquipmentPurchaseDate">
                <label>{ formatMessage({id: 'admin.equipmentPurchaseDate'})}</label>
                <SingleDatePicker
                    date={this.state.equipment.purchaseDate}
                    onDateChange={date => this.setState({ equipment: { ...this.state.equipment, purchaseDate: date }})}
                    focused={this.state.focused}
                    onFocusChange={({ focused }) => this.setState({ focused })}
                    id="purchaseDate"
                    noBorder={true}
                    placeholder={''}
                    small={true}
                    isOutsideRange={date => date >= moment().startOf("day")}
                    numberOfMonths={1}
                />
            </div>

            <TextField
                id="floating-center-title"
                label={ formatMessage({id: 'admin.equipmentPurchasePrice'})}
                lineDirection="center"
                placeholder={ formatMessage({id: 'admin.equipmentPurchasePrice'})}
                className="md-cell md-cell--top"
                value={this.state.equipment.purchasePrice}
                onChange={(value) => {
                    this.setState({
                        equipment: {
                            ...this.state.equipment,
                            purchasePrice: value
                        }
                    })
                }}
            />


            <div>
                <SelectionControl
                id="is-active"
                type="switch"
                label={ formatMessage({id: 'admin.deviceActive'})}
                name="active"
                checked={ this.state.equipment.active !== null ? this.state.equipment.active : false }
                onChange={(checked) => { 
                    this.setState({
                        equipment: { ...this.state.equipment, active: checked }
                    })
                }}
                />
            </div>

            <div className="Admin__addDeviceActions">
                <Button flat secondary className="Admin__addDeviceSaveButton" onClick={() => this.handleFormSubmit()}><FormattedMessage id="admin.save" /></Button>
                <Button flat primary className="Admin__addDeviceCancelButton" onClick={() => this.handleCancel()}><FormattedMessage id="admin.cancel" /></Button> 
                <Button flat primary className="Admin__addDeviceDeleteButton" onClick={() => this.setState({confirmingDelete: true})}><FormattedMessage id="admin.deleteEquipment" /></Button>
            </div>
        </div>
        );
    }
  }
);

export default injectIntl(EditEquipmentForm);
