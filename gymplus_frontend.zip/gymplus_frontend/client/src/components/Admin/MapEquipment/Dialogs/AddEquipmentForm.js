import React from 'react';
import { observer } from 'mobx-react';
import { injectIntl, FormattedMessage } from 'react-intl';
import { TextField, Button, SelectionControl } from "react-md";
import _ from "lodash";
import { toJS } from "mobx";
import { SingleDatePicker } from 'react-dates';
import moment from 'moment';

import ApiMiddleware from "../../../../services/Api";
import Auth from "../../../../services/Auth";

import MultiSelector from "../../../MultiSelector/MultiSelector";

import AdminStore from "../../../../models/AdminStore";

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const AddEquipmentForm = observer(
    class AddEquipmentForm extends React.Component {
      constructor(props) {
          super(props);

          this.state = {
              type: null,
              equipment: {
                  id: null,
                  name: '',
                  model: null,
                  category: null,
                  purchaseDate: moment(),
                  purchasePrice: '',
                  active: false,
              },
          }
      }

      handleFormSubmit() {
        const boundingCoordinates = toJS(AdminStore.drawingCoordinates);

          if(this.state.type === 'new') {

            const params = {
                premise_id: this.props.premiseId,
                name: this.state.equipment.name,
                model: { id: this.state.equipment.model },
                equipment_category_id: this.state.equipment.category,
                purchase_date: moment(this.state.equipment.purchaseDate).toISOString(),
                purchase_price: this.state.equipment.purchasePrice,
                tag: null,
                active: this.state.equipment.active === true ? 'True' : 'False',
            };

            const selectedCategory = _.find(this.props.categories, (c) => { 
                return `${c.id}` === `${this.state.equipment.category}`;
            });

            if(selectedCategory && selectedCategory.equipment_category_id_parent) {
                params.equipment_category_id_parent = selectedCategory.equipment_category_id_parent;
            }

            api
            .post(`/equipment`, params)
            .then(response => {
              let addedEquipmentId;

              if(typeof response.data.equipment_id === 'string' || typeof response.data.equipment_id === 'number') {
                addedEquipmentId = response.data.equipment_id;
              } else {
                addedEquipmentId = response.data.equipment_id[0];
              }

              // Logic to handle 
              let boundingBox = [];
              if(boundingCoordinates[0].x < boundingCoordinates[1].x) {
                  boundingBox[0] = boundingCoordinates[0].x;
                  boundingBox[2] = boundingCoordinates[1].x;
              } else {
                  boundingBox[0] = boundingCoordinates[1].x;
                  boundingBox[2] = boundingCoordinates[0].x;
              }
  
              if(boundingCoordinates[0].y < boundingCoordinates[1].y) {
                  boundingBox[1] = boundingCoordinates[0].y;
                  boundingBox[3] = boundingCoordinates[1].y;
              } else {
                  boundingBox[1] = boundingCoordinates[1].y;
                  boundingBox[3] = boundingCoordinates[0].y;
              }

              const locationParams = {
                equipment_id: addedEquipmentId,
                device_id: this.props.deviceId,
                bounding_box: boundingBox
              };

              document.getElementById('equipment-temporary').outerHTML = "";
              AdminStore.setMappingNew(false);
              AdminStore.resetEquipment();

              api
                .post(`/equipment/${addedEquipmentId}/device_equipment_location`, locationParams)
                .then(response => {
                    AdminStore.fetchEquipment();
                });
            });

          } else {
            const equipmentId = _.map(AdminStore.selectedEquipment, (item, key) => {
                return key;
            })[0];

            // Logic to handle 
            let boundingBox = [];
            if(boundingCoordinates[0].x < boundingCoordinates[1].x) {
                boundingBox[0] = boundingCoordinates[0].x;
                boundingBox[2] = boundingCoordinates[1].x;
            } else {
                boundingBox[0] = boundingCoordinates[1].x;
                boundingBox[2] = boundingCoordinates[0].x;
            }

            if(boundingCoordinates[0].y < boundingCoordinates[1].y) {
                boundingBox[1] = boundingCoordinates[0].y;
                boundingBox[3] = boundingCoordinates[1].y;
            } else {
                boundingBox[1] = boundingCoordinates[1].y;
                boundingBox[3] = boundingCoordinates[0].y;
            }

            const locationParams = {
                equipment_id: equipmentId,
                device_id: this.props.deviceId,
                bounding_box: boundingBox
              };

              // Close modal
              document.getElementById('equipment-temporary').outerHTML = "";
              AdminStore.setMappingNew(false);
              AdminStore.resetEquipment();

              api
                .post(`/equipment/${equipmentId}/device_equipment_location`, locationParams)
                .then(response => {
                    AdminStore.fetchEquipment();
                });

          }
      }

      render() {
        return (
        <div>

            { this.state.type === null ? (
                <div>
                    <p className="Admin__ConfirmRemoveInfo">Valitse, oletko lisäämässä uutta laitetta vai merkitsemässä olemassa olevaa.</p>
                    <div className="Admin__addDeviceActions">
                        <Button 
                            flat 
                            primary 
                            className="Admin__addDeviceSaveButton"
                            onClick={() => this.setState({type: 'new'})}>
                            <FormattedMessage id="admin.newEquipment" />
                        </Button>
                        <Button 
                            flat 
                            onClick={() => this.setState({type: 'existing'})}
                            style={{float: 'left', marginLeft: 0}}
                            className="Admin__addDeviceCancelButton">
                            <FormattedMessage id="admin.selectExistingEquipment" />
                        </Button>
                    </div>
                </div>
            ) : (
                this.state.type === 'new' ? this.addForm() : this.selectForm()
            )}
        </div>
        )
    }

    handleCancel() {
        // Close modal
        AdminStore.setMappingNew(false);

        // Remove temporary bounding box
        document.getElementById('equipment-temporary').outerHTML = "";
    }
    handleEquipmentSelection(item) {
        AdminStore.setSelectedEquipmentModel(item);
    }
    selectForm() {
        return (
            <div>
                <div className="Admin__editDeviceSelector">
                    <label><FormattedMessage id="admin.equipment" /></label>
                    <MultiSelector
                        type="equipment"
                        items={this.props.equipment}
                        valueProperty="name"
                        selectedItems={AdminStore.selectedEquipment}
                        onChange={this.handleEquipmentSelection}
                        forceSingleSelection={true}
                        ignoreHierarchy={true}
                    />
                </div>

                <div className="Admin__addDeviceActions" style={{marginTop: '10px'}}>
                    <Button 
                        flat 
                        primary 
                        className="Admin__addDeviceCancelButton" 
                        style={{float: 'left', marginLeft: 0}}
                        onClick={() => this.handleCancel()}>
                        <FormattedMessage id="admin.cancel" />
                    </Button>
                    <Button flat secondary className="Admin__addDeviceSaveButton" onClick={() => this.handleFormSubmit()}>
                        <FormattedMessage id="admin.select" />
                    </Button>
                </div>
            </div>
        );
    }
    addForm() {
        const { formatMessage, categories, models } = this.props;
        return (
        <div>
            <TextField
            id="floating-center-title"
            label={ formatMessage({id: 'admin.equipmentName'})}
            lineDirection="center"
            placeholder={ formatMessage({id: 'admin.equipmentName'})}
            className="md-cell md-cell--top"
            value={this.state.equipment.name}
            onChange={(value) => {
                this.setState({
                    equipment: {
                        ...this.state.equipment,
                        name: value
                    }
                })
            }}
        />
        { models && models.length > 0 ? (
            <div className="Admin__editDeviceSelector">
                <label>{ formatMessage({id: 'admin.equipmentBrand'})}</label>
                <MultiSelector
                    type="brand"
                    items={models}
                    onChange={modelId => {
                        this.setState({
                            equipment: {
                                ...this.state.equipment,
                                model: modelId,
                            }
                        })
                    }}
                    selectedItems={ this.state.equipment.model ? {[this.state.equipment.model]: true} : {} }
                    forceSingleSelection={true}
                    disableTopLevelSelection={true}
                    valueProperty="name"
                />
            </div>
        ) : '' }
        { categories && categories.length > 0 ? (
            <div className="Admin__editDeviceSelector">
                <label>{ formatMessage({id: 'admin.equipmentCategory'})}</label>
                <MultiSelector
                    type="category"
                    items={categories}
                    onChange={categoryId => {
                        this.setState({
                            equipment: {
                                ...this.state.equipment,
                                category: categoryId,
                            }
                        })
                    }}
                    selectedItems={ this.state.equipment.category ? {[this.state.equipment.category]: true} : {} }
                    forceSingleSelection={true}
                    valueProperty="name"
                />
                <span className="Admin__editEquipmentFormInfo"><FormattedMessage id="admin.selectMostSpecificCategory" /></span>
            </div>
        ) : '' }

        <div className="Admin__editEquipmentPurchaseDate">
            <label>{ formatMessage({id: 'admin.equipmentPurchaseDate'})}</label>
            <SingleDatePicker
                date={this.state.equipment.purchaseDate}
                onDateChange={date => this.setState({ equipment: { ...this.state.equipment, purchaseDate: date }})}
                focused={this.state.focused}
                onFocusChange={({ focused }) => this.setState({ focused })}
                id="purchaseDate"
                noBorder={true}
                placeholder={''}
                small={true}
                isOutsideRange={date => date >= moment().startOf("day")}
                numberOfMonths={1}
            />
        </div>

        <TextField
            id="floating-center-title"
            label={ formatMessage({id: 'admin.equipmentPurchasePrice'})}
            lineDirection="center"
            placeholder={ formatMessage({id: 'admin.equipmentPurchasePrice'})}
            className="md-cell md-cell--top"
            value={this.state.equipment.purchasePrice}
            onChange={(value) => {
                this.setState({
                    equipment: {
                        ...this.state.equipment,
                        purchasePrice: value
                    }
                })
            }}
        />


        <div>
            <SelectionControl
            id="is-active"
            type="switch"
            label={ formatMessage({id: 'admin.deviceActive'})}
            name="active"
            checked={ this.state.equipment.active === true ? true : false }
            onChange={(checked) => {
                console.log(checked);
                this.setState({
                    equipment: { ...this.state.equipment, active: checked }
                })
            }}
            />
        </div>

        <div className="Admin__addDeviceActions">
            <Button flat primary className="Admin__addDeviceCancelButton" onClick={() => this.handleCancel()}>
                <FormattedMessage id="admin.cancel" />
            </Button>
            <Button flat secondary className="Admin__addDeviceSaveButton" onClick={() => this.handleFormSubmit()}>
                <FormattedMessage id="admin.save" />
            </Button>
        </div>
    </div>
    );
    }
  }
);

export default injectIntl(AddEquipmentForm);
