import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { injectIntl } from 'react-intl';
import { ExpansionList, ExpansionPanel } from 'react-md';

import Header from '../Header/Header.js';
import LoadingAnimation from '../LoadingAnimation/LoadingAnimation.js';
import ComparisonTableContainer from './ComparisonTableContainer';
import ComparisonStore from '../../models/ComparisonStore.js';
import getTimespan from './utils/getTimespan';
import "react-table/react-table.css";

const Comparison = observer(
  class Comparison extends Component {
    async componentDidMount(){
      ComparisonStore.fetchProperty('premise');
      ComparisonStore.fetchProperty('category');
      await ComparisonStore.fetchProperty('equipment');
      ComparisonStore.fetchEquipmentUtilization();
      ComparisonStore.fetchCumulativeHours();
      ComparisonStore.fetchHoursUntilStartDate();
      ComparisonStore.fetchHoursUntilEndDate();
    }

    checkIsFetchingDone = () => {
      return (
        Object.values(ComparisonStore.equipment).length &&
        Object.values(ComparisonStore.premise).length &&
        Object.values(ComparisonStore.category).length &&
        Object.values(ComparisonStore.utilizationData).length &&
        Object.values(ComparisonStore.cumulativeHours).length &&
        Object.values(ComparisonStore.hoursUntilStartDate).length &&
        Object.values(ComparisonStore.hoursUntilEndDate).length
      );
    }

    render(){
      const { formatMessage } = this.props.intl;
      const isFetchingDone = this.checkIsFetchingDone();
      const store = ComparisonStore.getComparisonStoreData();
      const period = getTimespan(store.startDate, store.endDate, formatMessage);

      return (
        <div className="Comparison">
          <Header {...this.props} setLanguage={this.props.setLanguage} />
          <ExpansionList>
            <ExpansionPanel
              label={formatMessage({ id: "comparison.title" })}
              secondaryLabel={period}
              defaultExpanded
              footer={false}
              columnWidths={this.props.columnWidths}
            >
              {!isFetchingDone ? (
                <LoadingAnimation />
              ) : (
                <ComparisonTableContainer
                  store={store}
                />
              )}

            </ExpansionPanel>

          </ExpansionList>
        </div>
      );
    }
  }
);

export default injectIntl(Comparison);
