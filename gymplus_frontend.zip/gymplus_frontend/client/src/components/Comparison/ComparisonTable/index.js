export { default } from './ComparisonTable.js';
