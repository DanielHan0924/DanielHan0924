import React from 'react';
import PropTypes from 'prop-types';
import ReactTable from "react-table";

const ComparisonTable = ({ data, columns, defaultPageSize }) => {
  const pivotBy = ['premise', 'topCategory', 'middleCategory', 'bottomCategory'];

  return (
    <div className="ComparisonTable">
      <ReactTable
        data={data}
        columns={columns}
        pivotBy={pivotBy}
        defaultPageSize={defaultPageSize}
        collapseOnSortingChange={false}
        showPaginationBottom={false}
      />
    </div>
  );
};

ComparisonTable.propTypes = {
  data: PropTypes.arrayOf(PropTypes.shape({
    premise: PropTypes.string.isRequired,
    topCategory: PropTypes.string.isRequired,
    middleCategory: PropTypes.string.isRequired,
    bottomCategory: PropTypes.string.isRequired,
    equipment: PropTypes.string.isRequired,
    utilization: PropTypes.number.isRequired,
    hours: PropTypes.number.isRequired
  })).isRequired,
  columns: PropTypes.arrayOf(PropTypes.shape({
    Header: PropTypes.string.isRequired,
    accessor: PropTypes.string.isRequired,
    PivotValue: PropTypes.func,
    aggregate: PropTypes.func
  })).isRequired,
  defaultPageSize: PropTypes.number.isRequired
}

export default ComparisonTable;
