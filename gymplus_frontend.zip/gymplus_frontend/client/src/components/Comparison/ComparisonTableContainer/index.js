export { default } from './ComparisonTableContainer.js';
