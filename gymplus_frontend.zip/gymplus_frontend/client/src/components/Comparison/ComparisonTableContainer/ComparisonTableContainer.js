import React, { Component } from 'react';
import { injectIntl } from 'react-intl';
import PropTypes from 'prop-types';

import ComparisonTable from '../ComparisonTable';
import buildComparisonTableData from '../utils/buildComparisonTableData';
import getConfiguredComparisonTableColumns from '../utils/getConfiguredComparisonTableColumns';
import './ComparisonTableContainer.scss';

export class ComparisonTableContainer extends Component {
  getUpdatedData = (store) => {
    const updatedData = buildComparisonTableData(store);
    return updatedData;
  }

  getAmountOfDifferentPremiseNames(tableData){
    const premiseNames = [];
    tableData.forEach(object => {
      if(!premiseNames.includes(object.premise)){
        premiseNames.push(object.premise);
      }
    });
    return premiseNames.length;
  }

  render() {
    const { store } = this.props;
    const tableData = this.getUpdatedData(store);
    const defaultTableSize = this.getAmountOfDifferentPremiseNames(tableData);
    const configuredColumns = getConfiguredComparisonTableColumns(tableData, this.props.intl);

    return (
      <ComparisonTable
        key={'ComparisonTable'}
        data={tableData}
        columns={configuredColumns}
        defaultPageSize={defaultTableSize}
      />
    );
  }
}

ComparisonTableContainer.propTypes = {
  store: PropTypes.shape({
    premise: PropTypes.object.isRequired,
    category: PropTypes.object.isRequired,
    equipment: PropTypes.object.isRequired,
    utilizationData: PropTypes.object.isRequired,
    cumulativeHours: PropTypes.object.isRequired,
    startDate: PropTypes.object.isRequired,
    endDate: PropTypes.object.isRequired,
    hoursUntilStartDate: PropTypes.object.isRequired,
    hoursUntilEndDate: PropTypes.object.isRequired
  }).isRequired
};

export default injectIntl(ComparisonTableContainer);
