import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';

import store from '../storeMock.js';
import { ComparisonTableContainer } from './ComparisonTableContainer.js';

const intlMock = {
  formatMessage: () => {
    return 'DD.MM.YYYY'
  }
};

function setup(store){
  const props = {
    intl: intlMock,
    store
  };
  return shallow(<ComparisonTableContainer {...props} />);
}
const wrapper = setup(store);
const instance = wrapper.instance();

describe('ComparisonTableContainer', () => {
  it('should render without crashing', () => {
    setup(store);
  });
  it('should render as expected', () => {
    const tree = renderer.create(wrapper).toJSON();
    expect(tree).toMatchSnapshot();
  });
});

describe('Get Updated Data', () => {
  it('should return data to be used in comparison table', () => {
    const data = instance.getUpdatedData(store);
    const numberOfObjectValues = Object.values(data[0]).length;

    expect(data.length).toEqual(4);
    expect(numberOfObjectValues).toEqual(7);
    expect(data[0].premise).toEqual('Syke Satama');
    expect(data[0].topCategory).toEqual('Equipment')
  });
});

describe('Get Amount Of Different Premise Names', () => {
  it('should return the amount of different premises', () => {
    const data = [{ premise: 'a'}, { premise: 'b'}, { premise: 'c'}, { premise: 'c'} ];
    const amountOfDifferentPremises = instance.getAmountOfDifferentPremiseNames(data);
    expect(amountOfDifferentPremises).toEqual(3);
  });
});
