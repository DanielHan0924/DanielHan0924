import * as actions  from './getConfiguredComparisonTableColumns.js';

const intlMock = {
  formatMessage: (message) => {
    switch(message.id){
      case 'comparison.columns.header.premise':
        return 'Toimipiste';
      case 'comparison.columns.header.topCategory':
        return 'Kategoria 1';
      case 'comparison.columns.header.middleCategory':
        return 'Kategoria 2';
      case 'comparison.columns.header.bottomCategory':
        return 'Kategoria 3';
      case 'comparison.columns.header.equipment':
        return 'Laitteet';
      case 'comparison.columns.header.utilization':
        return 'Käyttöaste-% (keskiarvo)';
      case 'comparison.columns.header.hours':
        return 'Tunnit yhteensä';
      default:
        return '';
    }
  }
}

// getConfiguredColumns

describe('Set Headers', () => {
  it('should set localized header values', () => {
    const columns = [];
    for(let i = 0; i < 7; i++){
      columns.push({ Header: '' });
    }
    actions.setHeaders(columns, intlMock);
    expect(columns[0].Header).toEqual('Toimipiste');
    expect(columns[1].Header).toEqual('Kategoria 1');
    expect(columns[4].Header).toEqual('Laitteet');
  });
});

// setPremisePivotValue
// setCategoryPivotValue

describe('Get Category Index', () => {
  it('should return correct columns.js index', () => {
    const topCategoryIndex = actions.getCategoryIndex('topCategory');
    const middleCategoryIndex = actions.getCategoryIndex('middleCategory');
    const bottomCategoryIndex = actions.getCategoryIndex('bottomCategory');

    expect(topCategoryIndex).toEqual(1);
    expect(middleCategoryIndex).toEqual(2);
    expect(bottomCategoryIndex).toEqual(3);
  });
});

// setAmountOfEquipmentPerTopCategory
// getAmountOfEquipmentUnderCategory
// setAggregatedValues

describe('Check Is Premise Level', () => {
  it('should return true if input is an array 3 levels deep', () => {
    const valueToCheck = [ [ [ [ 15, 3 ] ] ] ];
    const isPremiseLevel = actions.checkIsPremiseLevel(valueToCheck);
    expect(isPremiseLevel).toEqual(true);
  });
});

describe('Check Is Top Category Level', () => {
  it('should return true if input is an array 3 levels deep', () => {
    const valueToCheck = [ [ [ 1, 2, 4 ] ] ];
    const isTopCategoryLevel = actions.checkIsTopCategoryLevel(valueToCheck);
    expect(isTopCategoryLevel).toEqual(true);
  });
});

describe('Check Is Middle Category Level', () => {
  it('should return true if input is an array 2 levels deep', () => {
    const valueToCheck = [ [ 7, 5, 4 ] ];
    const isMiddleCategoryLevel = actions.checkIsMiddleCategoryLevel(valueToCheck);
    expect(isMiddleCategoryLevel).toEqual(true);
  });
});

describe('Check Is Bottom Category Level', () => {
  it('should return true if input is an array', () => {
    const valueToCheck = [ 2, 1, 0 ];
    const isBottomCategoryLevel = actions.checkIsBottomCategoryLevel(valueToCheck);
    expect(isBottomCategoryLevel).toEqual(true);
  });
});

describe('Get Utilization Mean At Premise Level', () => {
  it('should calculate mean from values off of arrays four levels deep', () => {
    const values = [ [ [ [2, 3], [4, 5], [6] ] ] ];
    const mean = actions.getUtilizationMeanAtPremiseLevel(values);
    expect(mean).toEqual(4);
  });
});

describe('Get Utilization Mean At Top Category Level', () => {
  it('should calculate mean from values off of arrays three levels deep', () => {
    const values = [ [ [1, 2], [1, 2] ] ];
    const mean = actions.getUtilizationMeanAtTopCategoryLevel(values);
    expect(mean).toEqual(1.5);
  });
});

describe('Get Utilization Mean At Middle Category Level', () => {
  it('should calculate mean from values off of arrays two levels deep', () => {
    const values = [ [ 1, 2 ], [ 3, 4, 5 ] ];
    const mean = actions.getUtilizationMeanAtMiddleCategoryLevel(values);
    expect(mean).toEqual(3);
  });
});

describe('Get Utilization Mean At Bottom Category Level', () => {
  it('should calculate mean from array values', () => {
    const values = [ 1, 2, 3, 4, 5 ];
    const mean = actions.getUtilizationMeanAtBottomCategoryLevel(values);
    expect(mean).toEqual(3);
  });
});
