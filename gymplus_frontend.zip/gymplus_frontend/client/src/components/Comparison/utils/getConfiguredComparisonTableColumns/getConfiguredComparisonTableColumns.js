import React from 'react';
import _ from 'lodash';

import columns from './columns.js';
import categoryTypes from '../../../../enumerators/categoryTypes.js';

export const getConfiguredColumns = (tableData, intl) => {
  const configuredColumns = _.cloneDeep(columns);
  setHeaders(configuredColumns, intl);
  setPremisePivotValue(configuredColumns, tableData);
  setCategoryPivotValue(configuredColumns, tableData, 'bottomCategory');
  setCategoryPivotValue(configuredColumns, tableData, 'middleCategory');
  setCategoryPivotValue(configuredColumns, tableData, 'topCategory');
  setAggregatedValues(configuredColumns);
  return configuredColumns;
}

export const setHeaders = (columns, intl) => {
  const { formatMessage } = intl;
  columns[0].Header = formatMessage({ id: 'comparison.columns.header.premise' });
  columns[1].Header = formatMessage({ id: 'comparison.columns.header.topCategory' });
  columns[2].Header = formatMessage({ id: 'comparison.columns.header.middleCategory' });
  columns[3].Header = formatMessage({ id: 'comparison.columns.header.bottomCategory' });
  columns[4].Header = formatMessage({ id: 'comparison.columns.header.equipment' });
  columns[5].Header = formatMessage({ id: 'comparison.columns.header.utilization' });
  columns[6].Header = formatMessage({ id: 'comparison.columns.header.hours' });
}

export const setPremisePivotValue = (configuredColumns, tableData) => {
  const premiseColumnSettings = configuredColumns[0];
  premiseColumnSettings.PivotValue = (column) => {
    const { value } = column;
    const equipmentUnderPremise = tableData.filter(row => row.premise === value);
    return `${value} (${equipmentUnderPremise.length})`;
  };
}

export const setCategoryPivotValue = (configuredColumns, tableData, type) => {
  const categoryColumnSettings = configuredColumns[getCategoryIndex(type)];
  categoryColumnSettings.PivotValue = (column) => {
    const amountOfEquipment = getAmountOfEquipmentUnderCategory(column, tableData, type);
    return `${column.value} (${amountOfEquipment})`;
  }
}

export const getCategoryIndex = (type) => {
  switch(type){
    case categoryTypes.TOP_CATEGORY:
      return 1;
    case categoryTypes.MIDDLE_CATEGORY:
      return 2;
    case categoryTypes.BOTTOM_CATEGORY:
      return 3;
    default:
      return null;
  }
}

export const setAmountOfEquipmentPerTopCategory = (configuredColumns, tableData) => {
  const topCategoryColumnSettings = configuredColumns[1];
  topCategoryColumnSettings.PivotValue = (column) => {
    const amountOfEquipment = getAmountOfEquipmentUnderCategory(column, tableData, 'topCategory');
    return `${column.value} (${amountOfEquipment})`;
  }
}

export const getAmountOfEquipmentUnderCategory = (column, tableData, type) => {
  let subRows = column.subRows;
  while(subRows[0]._subRows){
    subRows = subRows[0]._subRows
  }
  const premiseValue = subRows[0].premise;
  const equipmentUnderPremise = tableData.filter(row => row.premise === premiseValue);
  const equipmentUnderMiddleCategory = equipmentUnderPremise.filter(equipment => {
    return equipment[type] === column.value;
  });
  return equipmentUnderMiddleCategory.length;
}

export const setAggregatedValues = (configuredColumns) => {
  configuredColumns[5].Aggregated = row => {
    const { value } = row;
    let aggregatedValue;
    if(checkIsPremiseLevel(value)){
      aggregatedValue = getUtilizationMeanAtPremiseLevel(value);
    }
    else if(checkIsTopCategoryLevel(value)){
      aggregatedValue = getUtilizationMeanAtTopCategoryLevel(value);
    }
    else if(checkIsMiddleCategoryLevel(value)){
      aggregatedValue = getUtilizationMeanAtMiddleCategoryLevel(value);
    }
    else if(checkIsBottomCategoryLevel(value)){
      aggregatedValue = getUtilizationMeanAtBottomCategoryLevel(value);
    }
    else {
      aggregatedValue = row.value;
    }
    return <span>{_.round(aggregatedValue, 2)}</span>;
  }
}

export const checkIsPremiseLevel = (value) => {
  // array four levels deep
  return (
    value[0] !== undefined &&
    value[0][0] !== undefined &&
    value[0][0][0] !== undefined &&
    value[0][0][0][0] !== undefined
  );
}

export const checkIsTopCategoryLevel = (value) => {
  // array three levels deep
  return (
    value[0] !== undefined &&
    value[0][0] !== undefined &&
    value[0][0][0] !== undefined
  );
}

export const checkIsMiddleCategoryLevel = (value) => {
  // array two levels deep
  return (
    value[0] !== undefined &&
    value[0][0] !== undefined
  );
}

export const checkIsBottomCategoryLevel = (value) => {
  return value[0] !== undefined;
}

export const getUtilizationMeanAtPremiseLevel = (value) => {
  let sumOfAllValues = 0;
  let amount = 0;
  value.forEach(topCategoryValues => {
    let sumOfTopCategoryValues = 0;
    topCategoryValues.forEach(middleCategoryValues => {
      let sumOfMiddleCategoryValues = 0;
      middleCategoryValues.forEach(valuesToSum => {
        sumOfMiddleCategoryValues += _.sum(valuesToSum);
        amount += valuesToSum.length;
      });
      sumOfTopCategoryValues += sumOfMiddleCategoryValues;
    });
    sumOfAllValues += sumOfTopCategoryValues;
  });
  return sumOfAllValues/amount;
}

export const getUtilizationMeanAtTopCategoryLevel = (value) => {
  let sumOfAllValues = 0;
  let amount = 0;
  value.forEach(middleCategoryValues => {
    let sumOfMiddleCategoryValues = 0;
    middleCategoryValues.forEach(valuesToSum => {
      sumOfMiddleCategoryValues += _.sum(valuesToSum);
      amount += valuesToSum.length;
    });
    sumOfAllValues += sumOfMiddleCategoryValues;
  });
  return sumOfAllValues/amount;
}

export const getUtilizationMeanAtMiddleCategoryLevel = (value) => {
  let sumOfAllValues = 0;
  let amount = 0;
  value.forEach(valuesToSum => {
    sumOfAllValues += _.sum(valuesToSum);
    amount += valuesToSum.length;
  });
  return sumOfAllValues/amount;
}

export const getUtilizationMeanAtBottomCategoryLevel = (value) => {
  const sumOfAllValues = _.sum(value);
  const amount = value.length;

  return sumOfAllValues/amount;
}

export default getConfiguredColumns;
