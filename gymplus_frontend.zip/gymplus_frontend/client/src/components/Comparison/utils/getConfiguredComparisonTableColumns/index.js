export { default } from './getConfiguredComparisonTableColumns';
