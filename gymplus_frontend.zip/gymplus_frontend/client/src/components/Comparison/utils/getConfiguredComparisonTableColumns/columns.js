import _ from 'lodash';

const columns = [
  {
    Header: "Premise",
    accessor: "premise",
    aggregate: () => ''
  },{
    Header: "Category 1",
    accessor: "topCategory",
    aggregate: () => ''
  },{
    Header: "Category2",
    accessor: "middleCategory",
    aggregate: () => ''
  },{
    Header: "Category3",
    accessor: "bottomCategory",
    aggregate: () => ''
  },{
    Header: "Equipment",
    accessor: "equipment",
    aggregate: () => ''
  },{
    Header: "Utilization (%)",
    accessor: "utilization",
    aggregate: (values) => values
  },{
    Header: "Hours",
    accessor: "hours",
    aggregate: (values) => _.sum(values)
  }
];

export default columns;
