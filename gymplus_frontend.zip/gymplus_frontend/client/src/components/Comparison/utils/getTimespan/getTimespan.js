const getTimespan = (startDate, endDate, formatMessage) => {
  const formattedStartDate = startDate.format(formatMessage({ id: 'date.format' }));
  const formattedEndDate = endDate.format(formatMessage({ id: 'date.format' }));

  return `${formattedStartDate} - ${formattedEndDate}`;
}

export default getTimespan;
