import moment from 'moment';
import getTimespan from './getTimespan.js';

const intlMock = {
  formatMessage: () => {
    return 'DD.MM.YYYY'
  }
};

describe('Get Timespan', () => {
  it('should return a string formatted like "startDate" - "endDate"', () => {
    const startDate = moment('20180815');
    const endDate = moment('20180823');
    const period = getTimespan(startDate, endDate, intlMock.formatMessage);
    expect(period).toEqual('15.08.2018 - 23.08.2018');
  });
});
