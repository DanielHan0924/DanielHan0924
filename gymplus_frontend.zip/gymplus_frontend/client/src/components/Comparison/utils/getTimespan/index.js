export { default } from './getTimespan.js';
