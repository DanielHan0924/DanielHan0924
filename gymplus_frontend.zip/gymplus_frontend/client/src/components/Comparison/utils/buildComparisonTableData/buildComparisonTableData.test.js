import * as actions from './buildComparisonTableData.js';

import store from '../../storeMock.js';

describe('Build Comparison Table Data', () => {
  it('should return a list of comparison table data objects', () => {
    const comparisonTableData = actions.buildComparisonTableData(store);
    expect(comparisonTableData.length).toEqual(4)
  });
});

describe('Get New Data Object', () => {
  it('should return an object that contains row data', () => {
    const equipment = { id: 190, name: 'Selänojennus', equipment_category_id: '14', premise_id: '5' };
    const dataObject = actions.getNewDataObject(store, equipment);
    expect(dataObject.premise).toEqual('Example Premise');
    expect(dataObject.topCategory).toEqual('Equipment');
    expect(dataObject.hours).toEqual(1);
    expect(dataObject.equipment).toEqual('190: Selänojennus');
  });
});

describe('Get Corresponding Premise', () => {
  it('should return correct premise', () => {
    const premise = { 1: { name: 'Example Premise'}, 2: { name: "LUT" }};
    const equipment = { id: 15, premise_id: 2 };
    const correspondingPremise = actions.getCorrespondingPremise(premise, equipment);
    expect(correspondingPremise.name).toEqual('LUT');
  });
});

describe('Get Categories', () => {
  describe('When equipment has three categories', () => {
    it('should return bottom, middle and top categories for equipment', () => {
      const { equipment, category } = store;
      const equipmentWithThreeCategories = equipment[190];
      const { bottomCategory, middleCategory, topCategory } = actions.getCategories(category, equipmentWithThreeCategories);
      expect(bottomCategory.name).toEqual('Selectorized');
      expect(middleCategory.name).toEqual('Strength');
      expect(topCategory.name).toEqual('Equipment');
    });
  });
  describe('When equipment has only one category', () => {
    it('should return bottom, middle and top category with same values', () => {
      const equipmentWithOneCategory = { id: 3, name: 'testName', equipment_category_id: 2 };
      const { bottomCategory, middleCategory, topCategory } = actions.getCategories(store.category, equipmentWithOneCategory);
      expect(bottomCategory.name).toEqual(middleCategory.name);
      expect(middleCategory.name).toEqual(topCategory.name);
    });
  });
  describe('When equipment has only two categories', () => {
    it('should return unique top category and bottom/middle category as same value', () => {
      const equipmentWithTwoCategories = { id: 3, name: 'testName', equipment_category_id: 4 };
      const { bottomCategory, middleCategory, topCategory } = actions.getCategories(store.category, equipmentWithTwoCategories);
      expect(bottomCategory.name).toEqual(middleCategory.name);
      expect(topCategory.name).not.toEqual(bottomCategory.name);
      expect(topCategory.name).toEqual('Equipment');
    });
  });
});

describe('Get Corresponding Bottom Category', () => {
  it('should return correct bottom category', () => {
    const lowerLevelCategory = { equipment_category_id: 14};
    const correspondingCategory = actions.getCorrespondingBottomCategory(store.category, lowerLevelCategory);
    expect(correspondingCategory.name).toEqual('Selectorized');
  });
});

describe('Is Special Case Category', () => {
  it('should return true when id is 2, 3, 4, 5 or 6', () => {
    const bottomCategoryMock = [{ id: 2 }, { id: 3 }, { id: 4 }, { id: 5 }, { id: 6 }];
    let actual;
    bottomCategoryMock.forEach((category) => {
      actual = actions.isSpecialCaseCategory(category);
      expect(actual).toEqual(true);
    });
  });
  it('should return false when id is something else', () => {
    const bottomCategoryMock = [{ id: 25 }, { id: 1 }, { id: 7 },{ id: 8 }];
    let actual;
    bottomCategoryMock.forEach((category) => {
      actual = actions.checkDoesBottomCategoryHaveTopCategoryValue(category);
      expect(actual).toEqual(false);
    });
  });
});

describe('Check Does Bottom Category Have Top Category Value', () => {
  it('should return true when id is 2', () => {
    const actual = actions.checkDoesBottomCategoryHaveTopCategoryValue({ id: 2 });
    expect(actual).toEqual(true);
  });
  it('should return false when id is anything but 2', () => {
    const bottomCategoryMock = [{ id: 3 }, { id: 4 }, { id: 5 },{ id: 6 }];
    let actual;
    bottomCategoryMock.forEach((category) => {
      actual = actions.checkDoesBottomCategoryHaveTopCategoryValue(category);
      expect(actual).toEqual(false);
    });
  });
});

describe('Check Does Bottom Category Have Middle Category Value', () => {
  it('should return true when id is 3, 4, 5 or 6', () => {
    const bottomCategoryMock = [{ id: 3 }, { id: 4 }, { id: 5 },{ id: 6 }];
    let actual;
    bottomCategoryMock.forEach((category) => {
      actual = actions.checkDoesBottomCategoryHaveMiddleCategoryValue(category);
      expect(actual).toEqual(true);
    });
  });
  it('should return false when id is anything else', () => {
    const bottomCategoryMock = [{ id: 1 }, { id: 7 }, { id: 14 },{ id: 32 }];
    let actual;
    bottomCategoryMock.forEach((category) => {
      actual = actions.checkDoesBottomCategoryHaveMiddleCategoryValue(category);
      expect(actual).toEqual(false);
    });
  });
});

describe('Get Special Case Categories', () => {
  describe('When id of bottomCategory is 2', () => {
    it('should return top and middle categories as clones of bottomCategory', () => {
      const bottomCategory = { id: 2, name: 'bottomCategoryName' };
      const { middleCategory, topCategory } = actions.getSpecialCaseCategories(store.category, bottomCategory);
      expect(middleCategory.name).toEqual('bottomCategoryName');
      expect(topCategory.name).toEqual('bottomCategoryName');
    });
  });
  describe('When id of bottomCategory is 3, 4, 5, or 6', () => {
    it('should return topCategory as is, middleCategory as a clone of bottomCategory', () => {
      const bottomCategory = { id: 3, name: 'bottomCategoryName', equipment_category_id_parent: 14 };
      const { middleCategory, topCategory } = actions.getSpecialCaseCategories(store.category, bottomCategory);
      expect(middleCategory.name).toEqual('bottomCategoryName');
      expect(topCategory.name).toEqual('Selectorized');
    });
  });
});

describe('Get Corresponding Upper Category', () => {
  it('should return correct category parent', () => {
    const lowerLevelCategory = { equipment_category_id_parent: 4 };
    const actual = actions.getCorrespondingUpperCategory(store.category, lowerLevelCategory);
    expect(actual.name).toEqual('Strength');
  });
});

describe('getCorrespondingUtilizationData', () => {
  it('should return correct utilizationData', () => {
    const utilizationData = {
      1: { equipment_id: 1, utilization: 0.52 },
      2: { equipment_id: 2, utilization: 0.34 },
      3: { equipment_id: 3, utilization: 0.11 },
    };
    const equipment = { id: 3 };
    const correspondingUtilization = actions.getCorrespondingUtilizationData(utilizationData, equipment);
    expect(correspondingUtilization.utilization).toEqual(0.11);
  });
});

describe('Build New Data Object', () => {
  const premise = { name: 'premiseName' };
  const bottomCategory = { name: 'bottomCategoryName', name_fi: 'bottomCategoryNameFi' };
  const middleCategory = { name: 'middleCategoryName', name_fi: 'middleCategoryNameFi' };
  const topCategory = { name: 'topCategoryName', name_fi: 'topCategoryNameFi' };
  const equipment = { id: 5, name: 'equipmentName' };
  const utilizationData = { utilization: 0.03459 };
  const hours = 23.4;
  const newDataObject = actions.buildNewDataObject(premise, bottomCategory, middleCategory, topCategory, equipment, utilizationData, hours);

  expect(newDataObject.premise).toEqual('premiseName');
  expect(newDataObject.equipment).toEqual('5: equipmentName');
  expect(newDataObject.utilization).toEqual(3.46);
  expect(newDataObject.hours).toEqual(23);
});

describe('Get Cumulative Hours', () => {
  let hoursUntilStartDate;
  let hoursUntilEndDate;
  beforeEach(() => {
    hoursUntilStartDate = {
      1: { cumulative_hour: 22 },
      2: { cumulative_hour: 41 },
    };
    hoursUntilEndDate = {
      1: { cumulative_hour: 23 },
      2: { cumulative_hour: 45 },
    };
  });
  it('should return cumulative hours', () => {
    const equipment = { id: 2 };
    const cumulativeHours = actions.getCumulativeHours(hoursUntilStartDate, hoursUntilEndDate, equipment);
    expect(cumulativeHours).toEqual(4);
  });
  it('should return "-" if cumulative_hour has not been calculated', () => {
    const equipment = { id: 50 };
    const notCalculatedCumulativeHours = actions.getCumulativeHours(hoursUntilStartDate, hoursUntilEndDate, equipment);
    expect(notCalculatedCumulativeHours).toEqual('-')
  });
});
