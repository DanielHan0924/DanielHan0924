export { default } from './buildComparisonTableData.js';
