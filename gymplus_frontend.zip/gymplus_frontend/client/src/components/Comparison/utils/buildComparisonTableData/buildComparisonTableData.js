import _ from 'lodash';

import getLocalizedCategoryName from '../getLocalizedCategoryName';

export const buildComparisonTableData = (store) => {
  const allEquipment = Object.values(store.equipment);
  const comparisonTableData = [];
  allEquipment.forEach((equipment) => {
    const dataObject = getNewDataObject(store, equipment);
    comparisonTableData.push(dataObject);
  });
  return comparisonTableData;
}

export const getNewDataObject = (store, equipment) => {
  const premise = getCorrespondingPremise(store.premise, equipment);
  const { middleCategory, bottomCategory, topCategory } = getCategories(store.category, equipment);
  const utilizationData = getCorrespondingUtilizationData(store.utilizationData, equipment);
  const hours = getCumulativeHours(store.hoursUntilStartDate, store.hoursUntilEndDate, equipment);
  const dataObject = buildNewDataObject(premise, bottomCategory, middleCategory, topCategory, equipment, utilizationData, hours);
  return dataObject;
}

export const getCorrespondingPremise = (premise, equipment) => {
  return premise[equipment.premise_id];
}

export const getCategories = (category, equipment) => {
  const bottomCategory = getCorrespondingBottomCategory(category, equipment);
  if(isSpecialCaseCategory(bottomCategory)){
    const { middleCategory , topCategory } = getSpecialCaseCategories(category, bottomCategory);
    return { bottomCategory, middleCategory, topCategory }
  }
  const middleCategory = getCorrespondingUpperCategory(category, bottomCategory);
  const topCategory = getCorrespondingUpperCategory(category, middleCategory);
  return { bottomCategory, middleCategory, topCategory };
}

export const getCorrespondingBottomCategory = (category, equipment) => {
  return category[equipment.equipment_category_id];
}

export const isSpecialCaseCategory = (bottomCategory) => {
  return (
    checkDoesBottomCategoryHaveTopCategoryValue(bottomCategory) ||
    checkDoesBottomCategoryHaveMiddleCategoryValue(bottomCategory)
  );
}

export const checkDoesBottomCategoryHaveTopCategoryValue = (bottomCategory) => {
  return (
    bottomCategory.id === 2
  );
}

export const checkDoesBottomCategoryHaveMiddleCategoryValue = (bottomCategory) => {
  return (
    bottomCategory.id === 3 ||
    bottomCategory.id === 4 ||
    bottomCategory.id === 5 ||
    bottomCategory.id === 6
  );
}

export const getSpecialCaseCategories = (category, bottomCategory) => {
  const bottomCategoryHasTopCategoryValue = checkDoesBottomCategoryHaveTopCategoryValue(bottomCategory);

  if(bottomCategoryHasTopCategoryValue){
    const middleCategory = Object.assign({}, bottomCategory);
    const topCategory = Object.assign({}, bottomCategory);
    return { middleCategory , topCategory }
  }
  const bottomCategoryHasMiddleCategoryValue = checkDoesBottomCategoryHaveMiddleCategoryValue(bottomCategory);
  if(bottomCategoryHasMiddleCategoryValue){
    const middleCategory = Object.assign({}, bottomCategory);
    const topCategory = getCorrespondingUpperCategory(category, bottomCategory);
    return { middleCategory , topCategory }
  }
}

export const getCorrespondingUpperCategory = (category, lowerLevelCategory) => {
  return category[lowerLevelCategory.equipment_category_id_parent];
}

export const getCorrespondingUtilizationData= (utilizationData, equipment) => {
  return utilizationData[equipment.id];
}

export const getCumulativeHours = (hoursUntilStartDate, hoursUntilEndDate, equipment) => {
  const { id } = equipment;
  if(!hoursUntilEndDate[id]){
    return '-';
  }
  const hoursUntilEnd = hoursUntilEndDate[id].cumulative_hour;
  const hoursUntilStart = hoursUntilStartDate[id].cumulative_hour;
  return hoursUntilEnd - hoursUntilStart;
}

export const buildNewDataObject = (
  premise,
  bottomCategory,
  middleCategory,
  topCategory,
  equipment,
  utilizationData,
  hours
) => {
  const oneHundredPercent = 100;

  return {
    premise: premise.name,
    topCategory: getLocalizedCategoryName(topCategory),
    middleCategory: getLocalizedCategoryName(middleCategory),
    bottomCategory: getLocalizedCategoryName(bottomCategory),
    equipment: `${equipment.id}: ${equipment.name}`,
    utilization: _.round(oneHundredPercent * utilizationData.utilization, 2),
    hours: _.round(hours)
  };
}

export default buildComparisonTableData;
