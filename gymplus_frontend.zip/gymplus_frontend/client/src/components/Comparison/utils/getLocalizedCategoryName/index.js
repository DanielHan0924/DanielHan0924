export { default } from './getLocalizedCategoryName.js';
