import getLocalizedCategoryName from './getLocalizedCategoryName.js';

describe('Get Localized Category Name', () => {
  it('should return category name based on language settings', () => {
    const categoryToLocalize = { name_fi: 'nameInFinnish', name: 'nameInEnglish' };

    localStorage.setItem('gpLanguage', 'fi');
    const nameInFinnish = getLocalizedCategoryName(categoryToLocalize);
    localStorage.setItem('gpLanguage', 'en');
    const nameInEnglish = getLocalizedCategoryName(categoryToLocalize);

    expect(nameInFinnish).toEqual('nameInFinnish');
    expect(nameInEnglish).toEqual('nameInEnglish');
  });
});
