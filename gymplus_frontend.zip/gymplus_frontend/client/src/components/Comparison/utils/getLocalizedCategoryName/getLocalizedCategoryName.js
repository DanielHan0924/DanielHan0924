const getLocalizedCategoryName = function(category){
    const language = localStorage.getItem('gpLanguage');
    return language === 'fi' ? category.name_fi : category.name;
}

export default getLocalizedCategoryName;
