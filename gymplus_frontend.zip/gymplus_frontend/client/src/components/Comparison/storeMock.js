import moment from 'moment';

const premise = {
  1: { name: 'Syke Satama' },
  5: { name: 'Example Premise' },
};

const category = {
  1: { id: 1, name: 'Equipment', name_fi: 'Equipment_fi', equipment_category_id_parent: null },
  2: { id: 2, name: 'Space', name_fi: 'Space_fi', equipment_category_id_parent: null },
  4: { id: 4, name: 'Strength', name_fi: 'Strength_fi', equipment_category_id_parent: 1 },
  14: { id: 14, name: 'Selectorized', name_fi: 'Selectorized', equipment_category_id_parent: 4 },
  18: { id: 18, name: 'Free Weights', name_fi: 'Free Weights_fi', equipment_category_id_parent: 4 },
};

const equipment = {
  12: { id: 12, name: 'Vapaan painot', equipment_category_id: '18', premise_id: '1' },
  184: { id: 184, name: 'Vatsarutistus', equipment_category_id: '14', premise_id: '5' },
  185: { id: 185, name: 'Vaakaprässi', equipment_category_id: '14', premise_id: '5' },
  190: { id: 190, name: 'Selänojennus', equipment_category_id: '14', premise_id: '5' },
};

const hoursUntilStartDate = {
  12: { cumulative_hour: 10 },
  184: { cumulative_hour: 12 },
  185: { cumulative_hour: 13 },
  190: { cumulative_hour: 15 },

};

const hoursUntilEndDate = {
  12: { cumulative_hour: 11 },
  184: { cumulative_hour: 13 },
  185: { cumulative_hour: 15 },
  190: { cumulative_hour: 16 },
};

const utilizationData = {
  12: { utilization: 0.23115 },
  184: { utilization: 0.1197 },
  185: { utilization: 0.2334 },
  190: { utilization: 0.0523 },
}

const startDate = moment('20180815');
const endDate = moment('20180823');
const cumulativeHours = {};

const store = {
  premise,
  category,
  equipment,
  utilizationData,
  cumulativeHours,
  startDate,
  endDate,
  hoursUntilStartDate,
  hoursUntilEndDate
};

export default store;
