import React, {Component} from 'react';
import { observer } from 'mobx-react';
import { injectIntl } from "react-intl";
import './LoadingTip.scss';

import CloseButton from '../CloseButton/CloseButton.js';
import LoadingAnimation from '../LoadingAnimation/LoadingAnimation.js';
import LoadingTipStore from '../../models/LoadingTipStore.js';
import Logo from '../../assets/images/logo.svg';

const LoadingTip = observer (
  class LoadingTip extends Component {
    state = {
      randomTip: LoadingTipStore.getRandomTip()
    }
    renderLoadingTipText = () => {
      const { randomTip } = this.state;

      return (
        <div className="LoadingTip__text">
          {randomTip.text.map((textLine, index) => <p key={index}>{textLine}</p>)}
        </div>
      );
    }

    render (){
      const { formatMessage } = this.props.intl;
      const { loaded } = this.props;

      const closeButton =
      <button
        onClick={this.props.hideDialog}
        className="LoadingTip__btn"
      >
        {formatMessage({ id: "loadingTip.closeButton"})}
      </button>


      return (
        <div className="LoadingTip">
          <div className="CloseButton__container">
            <CloseButton
              closeWindow={this.props.hideDialog}
            />
          </div>

          <div className="LoadingTip__logo">
            <img src={Logo} className="" alt="GymPlus" />
          </div>

          <hr className="LoadingTip__hr"/>
          <p className="LoadingTip__defaultText">{formatMessage({ id: "loadingTip.defaultText"})}</p>

          {this.renderLoadingTipText()}

          {!loaded
            ? <LoadingAnimation
              bottom="-120px"
              left="45%"
            />
            : <div >
              {closeButton}
            </div>
          }

        </div>
      );
    }

  }
);


export default injectIntl(LoadingTip);

/* joel.salminen@indoorinformatics.com */
