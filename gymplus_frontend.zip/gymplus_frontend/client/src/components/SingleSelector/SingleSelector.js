import React from "react";
import { observer } from "mobx-react";
import PerfectScrollbar from "react-perfect-scrollbar";
import _ from "lodash";
import { toJS } from "mobx";
import onClickOutside from "react-onclickoutside";

import { injectIntl } from "react-intl";

import "react-perfect-scrollbar/dist/css/styles.css";

import SelectorStore from "../../models/SelectorStore";
import FilterStore from "../../models/FilterStore";

import "./SingleSelector.scss";

const SingleSelector = observer(
  class SingleSelector extends React.Component {
    handleClickOutside() {
      SelectorStore.closeDropdown(this.props.type);
    }
    handleToggle(name, type) {
      SelectorStore.toggleItem(name, type);

      let groupBy = name;
      const selectedItem = _.find(this.props.items, item => item.id === name);

      if (
        this.props.type === "dimensionsDetails" &&
        selectedItem.timePart !== null
      ) {
        groupBy = "timePart";
      }

      this.props.handleToggle(
        groupBy,
        selectedItem.timePart,
        toJS(FilterStore.filterData)
      );
    }
    toggleDropdown() {
      SelectorStore.toggleDropdown(this.props.type);
    }
    render() {
      const dropdownIsOpen = SelectorStore.openDropdowns[this.props.type];

      return (
        <div className={`SingleSelector ${this.props.className}`}>
          <div
            onClick={() => this.toggleDropdown()}
            className={`SingleSelector__selected ${
              dropdownIsOpen ? "toggled" : ""
            }`}
          >
            {this.props.className === "right" ? (
              <i className="material-icons">keyboard_arrow_down</i>
            ) : null}
            <span>{this.getSelectedItems()}</span>
            {this.props.className !== "right" ? (
              <i className="material-icons">keyboard_arrow_down</i>
            ) : null}
          </div>
          <div
            className={`SingleSelector__dropdown ${
              dropdownIsOpen ? "open" : ""
            } ${this.props.noScrolling === true ? "no-scroll" : ""}`}
          >
            {this.props.noScrolling !== true ? (
              <PerfectScrollbar>{this.getDropdownItems()}</PerfectScrollbar>
            ) : (
              this.getDropdownItems()
            )}
          </div>
        </div>
      );
    }
    getSelectedItems() {
      if (SelectorStore.selectedItem[this.props.type] === undefined) {
        const defaultItem = this.props.items[0].name;
        return <span>{defaultItem}</span>;
      }

      const selectedItem = _.find(
        this.props.items,
        item => item.id === SelectorStore.selectedItem[this.props.type]
      );

      return <span>{selectedItem.name}</span>;
    }
    getDropdownItems() {
      let options = this.props.items;
      const selectedItem = SelectorStore.selectedItem[this.props.type];
      const filter = false; // FilterStore.filterValues[this.props.type];

      if (filter) {
        options = options.filter(
          d =>
            filter === null ||
            filter.length < 3 ||
            d.name.toLowerCase().includes(filter.toLowerCase())
        );
      }

      return options.map(item => {
        if (item === undefined || item === null) return "";
        return (
          <div
            key={item.id}
            className={`SingleSelector__row ${
              selectedItem === item.id ? "SingleSelector__row--selected" : ""
            }`}
            onClick={() => this.handleToggle(item.id, this.props.type)}
          >
            <span>{item.name}</span>
          </div>
        );
      });
    }
  }
);

export default injectIntl(onClickOutside(SingleSelector));
