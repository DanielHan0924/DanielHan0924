import React, {Component} from 'react';
import { observer } from 'mobx-react';
import moment from "moment";
import { DateRangePicker } from "react-dates";
import { injectIntl } from 'react-intl';

import SingleEquipmentStore from '../../models/SingleEquipmentStore.js';
import CloseButton from '../CloseButton/CloseButton.js';
import './SingleEquipmentHeader.scss';

const SingleEquipmentHeader = observer (
  class SingleEquipmentHeader extends Component {
    onApplyClick = () => {
      const { id } = this.props.equipment;
      SingleEquipmentStore.reloadAllCharts(id);
    }
    render(){
      const { formatMessage } = this.props.intl;
      const { name, id } = this.props.equipment;
      const applyButtonText = formatMessage({id: "filter.apply"});

      return (
        <div className="SingleEquipmentHeader">

          <CloseButton
            closeWindow={this.props.closeWindow}
          />
          <h2 className="SingleEquipmentHeader__equipmentName">
            {id}: {name}
          </h2>

          <div className="SingleEquipmentHeader__buttonContainer">
            <div className="ButtonContainer">
              <div className="SingleEquipmentHeader__btn--datePicker">
                <DateRangePicker
                  startDate={SingleEquipmentStore.startDate}
                  startDateId="dateRange_start"
                  endDate={SingleEquipmentStore.endDate}
                  endDateId="dateRange_end"
                  onDatesChange={({ startDate, endDate }) =>
                    SingleEquipmentStore.setDates({ startDate, endDate })
                  }
                  focusedInput={SingleEquipmentStore.datePickerFocusedInput}
                  onFocusChange={focusedInput => SingleEquipmentStore.setDatePickerFocus(focusedInput)}
                  displayFormat={`dd ${formatMessage({ id: "date.format"})}`}
                  firstDayOfWeek={1}
                  isOutsideRange={date => date >= moment().startOf("day")}
                  numberOfMonths={1}
                />
              </div>
            </div>
            <div className="ButtonContainer">
              <button
                onClick={this.onApplyClick}
                className="SingleEquipmentHeader__btn--apply "
              >
                {applyButtonText}
              </button>
            </div>
          </div>



          <hr className="SingleEquipmentHeader__hr" />
        </div>
      );
    }

  }

);

export default injectIntl(SingleEquipmentHeader);

/* joel.salminen@indoorinformatics.com */
