import React from 'react';
import { shallow } from 'enzyme';

import Percentage from './Percentage.js';

function setup(value = 0, showSign = false){
  const props = {
    value,
    showSign
  };
  return shallow(<Percentage {...props} />);
}

describe('Percentage', () =>{
  let mountedPercentage;
  beforeEach(() => {
    mountedPercentage = setup();
  });
  it('should render without crashing', () => {
    const mountedPercentage = setup();
  });
  it('should render a span', () => {
    const spans = mountedPercentage.find('span');
    expect(spans.length).toEqual(1);
  });
});

describe('When Percentage is given a positive value to round', () => {
  let mountedPercentage;
  let value = 36.77442;
  const showSign = true;
  beforeEach(() => {
    mountedPercentage = setup(value, showSign);
  });
  it('should render value rounded by one decimal', () => {
    const span = mountedPercentage.find('span');
    expect(span.text().substring(1)).toEqual('36.77%');
  });
  it('should render a plus sign in front of the value', () => {
    const span = mountedPercentage.find('span');
    const firstCharacterOfSpanText = span.text().substring(0, 1);
    expect(firstCharacterOfSpanText).toEqual('+');
  });
});

describe('When Percentage is given a negative valueto round', () => {
  let mountedPercentage;
  const value = -26.7736;

  beforeEach(() => {
    mountedPercentage = setup(value);
  });
  it('should render a - sign in front of the value', () => {
    const span = mountedPercentage.find('span');
    const firstCharacterOfSpanText = span.text().substring(0, 1);
    expect(firstCharacterOfSpanText).toEqual('-');
  });
});

describe('When Percentage is given 0', () => {
  let mountedPercentage;
  const value = 0.00;

  beforeEach(() => {
    mountedPercentage = setup(value);
  });
  it('should render 0%', () => {
    const span = mountedPercentage.find('span');
    expect(span.text()).toEqual('0%');
  });
});
