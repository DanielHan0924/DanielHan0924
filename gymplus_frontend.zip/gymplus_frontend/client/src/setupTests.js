import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import localStorageMock from './utils/localStorageMock.js';

configure({ adapter: new Adapter() });

Object.defineProperty(window, 'localStorage', {
     value: localStorageMock
});
