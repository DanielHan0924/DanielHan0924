import { extendObservable, action } from 'mobx';

import TagSelectionStore from './TagSelectionStore.js';

import ApiMiddleware from '../services/Api.js';
import Auth from '../services/Auth.js';
const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

class TagStore {
  constructor(){
    extendObservable(this, {
      tags: [],
      premise: [],
      device: [],
      category: [],
      equipment: [],
      loaded: {
        tags: false
      },
      error: {
        tag: false,
        property: false
      },
      isEditing: false,
      setTags: action(tags => {
        this.tags = tags;
      }),
      updateChangedTag: action(updatedTag => {
        const tags = this.tags.map(tag => Object.assign({}, tag));
        const foundTagIndex = tags.findIndex(tag => {
          return tag.id === updatedTag.id
        });
        tags[foundTagIndex] = updatedTag;
        this.setTags(tags);
      }),
      setPremise: action(data => {
        this.premise = data;
      }),
      setDevice: action(data => {
        this.device = data;
      }),
      setCategory: action(data => {
        this.category = data;
      }),
      setEquipment: action(data => {
        this.equipment = data;
      }),
      setError: action((type) => {
        const error = Object.assign({}, this.error);
        error[type] = true;
        this.error = error;
      }),
      getSelectedItemIds: action((selection, selectedItems) => {
        const ids = [];
        this[selection].forEach(item => {
          if(selectedItems[item.id]){
            ids.push(item.id);
          }
        });
        if (!ids.length){
          return [null];
        }
        return ids;
      }),
      generateNewTag: action((
        name,
        description,
        timestamp_activated,
        ab_active,
        selectedItems
      ) => {
        const premise_id = this.getSelectedItemIds('premise', selectedItems.selectedPremises);
        const device_id = this.getSelectedItemIds('device', selectedItems.selectedDevices);
        const category_id = this.getSelectedItemIds('category', selectedItems.selectedCategories);
        const equipment_id = this.getSelectedItemIds('equipment', selectedItems.selectedEquipment);

        const newTag = {
          name,
          description,
          ab_active,
          timestamp_activated,
          premise_id,
          device_id,
          category_id,
          equipment_id
        };
        return newTag;
      }),
      postTag: action(newTag => {
        console.log(newTag);
        api
          .post('/tag', newTag)
          .then(response => {
            this.fetchTags();
          });
      }),
      toggleIsEditing: action(() => {
        const { isEditing } = this;
        this.isEditing = !isEditing;
      }),
      setIsEditing: action(isEditing => {
        this.isEditing  = isEditing;
      }),
      generateUpdatedTag: action((
        name,
        description,
        timestamp_activated,
        ab_active,
        selectedItems
      ) => {
        const updatedTag = Object.assign({}, TagSelectionStore.selectedTag);
        const premise_id = this.getSelectedItemIds('premise', selectedItems.selectedPremises);
        const device_id = this.getSelectedItemIds('device', selectedItems.selectedDevices);
        const category_id = this.getSelectedItemIds('category', selectedItems.selectedCategories);
        const equipment_id = this.getSelectedItemIds('equipment', selectedItems.selectedEquipment);

        updatedTag.name = name;
        updatedTag.description = description;
        updatedTag.timestamp_activated = timestamp_activated;
        updatedTag.ab_active = ab_active;
        updatedTag.premise_id = premise_id;
        updatedTag.device_id = device_id;
        updatedTag.category_id = category_id;
        updatedTag.equipment_id = equipment_id;

        return updatedTag;
      }),
      putTag: action(updatedTag => {
        this.updateChangedTag(updatedTag);
        api
          .put('/tag/' + updatedTag.id, updatedTag)
          .then(response => {
          });
      }),
      deleteTag: action(() => {
        const { tags } = this;
        const { selectedTag } = TagSelectionStore;


        const newTags = tags.filter(tag => tag.id !== selectedTag.id);
        this.setTags(newTags);
        api
          .delete('/tag/' + selectedTag.id)
          .then(response => {
          });
        TagSelectionStore.resetTagSelections();

      }),
      fetchTags: action(() => {
        api
          .get('/tag')
          .then(response => {
            this.setTags(response.data);
            this.setLoaded('tags');
          }).catch(() => {
            this.setError('tag');
          });
      }),
      fetchAllTagProperties: action(() => {
        this.fetchPremise();
        this.fetchDevice();
        this.fetchCategory();
        this.fetchEquipment();
      }),
      fetchPremise: action(() => {
        if (this.premise.length === 0){
          api
            .get('/premise')
            .then(response => {
              this.setPremise(response.data);
            }).catch(() => {
              this.setError('property')
            });
        }
      }),
      fetchDevice: action(() => {
        api
          .get('/device')
          .then(response => {
            this.setDevice(response.data);
          }).catch(() => {
            this.setError('property');
          });
      }),
      fetchCategory: action(() => {
        api
          .get('/category')
          .then(response => {
            this.setCategory(response.data);
          }).catch(() => {
            this.setError('property');
          });
      }),
      fetchEquipment: action(() => {
        api
          .get('/equipment')
          .then(response => {
            this.setEquipment(response.data);
          }).catch(() => {
            this.setError('property');
          });
      }),
      setLoaded: action(type => {
        this.loaded[type] = true;
      })

    });
  }
}

const store = new TagStore();
export default store;

/* joel.salminen@indoorinformatics.com */
