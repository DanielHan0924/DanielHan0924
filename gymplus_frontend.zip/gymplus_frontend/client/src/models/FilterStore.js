import { extendObservable, action } from "mobx";
import moment from "moment";

import EquipmentDetailsStore from "./EquipmentDetailsStore";
import HomeStore from "../models/HomeStore";

// const _ = require('lodash');

class FilterStore {
  constructor() {
    extendObservable(this, {
      startDate: moment()
        .subtract(1, "week")
        .startOf("week"),
      endDate: moment()
        .subtract(1, "week")
        .endOf("week"),
      startCompareDate: moment()
        .subtract(1, "week")
        .startOf("week"),
      endCompareDate: moment()
        .subtract(1, "week")
        .endOf("week"),
      focusedInput: null,
      focusedCompareInput: null,
      activeFilters: {},
      compareOpen: false,
      compareFilters: {},
      categoryNameKey: 'name_fi',
      selectedItems: {
        brand: {},
        category: { },
        tag: {},
        premise: {},
        days: 'all',
        hours: 'all'
      },
      selectedCompareItems: {
        brand: {},
        category: { },
        tag: {},
        premise: {},
        days: 'all',
        hours: 'all'
      },
      lastClicked: {
        category: false,
        brand: false,
        tag: false,
        premise: false,
        categoryC: false,
        brandC: false,
        tagC: false,
        premiseC: false,
      },
      optionsLoading: {
        brand: true,
        category: true,
        premise: true,
        tag: true,
        equipment: true
      },
      filterData: {
        brand: [],
        category: [],
        premise: [],
        tag: [],
        equipment: [] // not shown in filters but will be used in views
      },
      setCategoryNameKey: action(locale => {
        if(locale === 'fi') {
          this.categoryNameKey = 'name_fi';
        } else {
          this.categoryNameKey = 'name';
        }
      }),
      setLoadingStatus: action((type, status) => {
        this.optionsLoading[type] = status;
      }),
      setCompareDates: action(dates => {
        this.startCompareDate = dates.startDate;
        this.endCompareDate = dates.endDate;
      }),
      setDates: action(dates => {
        this.startDate = dates.startDate;
        this.endDate = dates.endDate;
      }),
      setFocus: action((value, isCompare = false) => {
        if(isCompare === true) {
          this.focusedCompareInput = value;
        } else {
          this.focusedInput = value;
        }
      }),
      toggleCompare: action(() => {
        this.compareOpen = !this.compareOpen;
      }),
      setFilterData: action((type, data) => {
        this.filterData[type] = data;
      }),
      toggleItem: action((item, type) => {
        if (this.selectedItems[type][item] === undefined) {
          this.selectedItems[type][item] = true;
        } else {
          this.selectedItems[type][item] = !this.selectedItems[type][item];
        }
        this.setLastClicked(item, type, this.selectedItems[type][item]);
      }),
      toggleCompareItem: action((item, type) => {
        if (this.selectedCompareItems[type][item] === undefined) {
          this.selectedCompareItems[type][item] = true;
        } else {
          this.selectedCompareItems[type][item] = !this.selectedCompareItems[type][item];
        }
        this.setLastClicked(item, `${type}C`, this.selectedCompareItems[type][item]);
      }),
      toggleDays: action((item, isCompare = false) => {
        if(isCompare === true) {
          this.selectedCompareItems.days = item;
        } else {
          this.selectedItems.days = item;
        }
      }),
      toggleHours: action((item, isCompare = false) => {
        if(isCompare === true) {
          this.selectedCompareItems.hours = item;
        } else {
          this.selectedItems.hours = item;
        }
      }),
      setLastClicked: action((value, type, newValue = false) => {
        let c = value;
        if(newValue === true) {
          c += '+';
        } else {
          c += '-';
        }
        this.lastClicked[type] = c;
      }),
      lastFilterSaved: null,
      resetSelection: action((type) => {
        this.selectedItems[type] = {};
      }),
      resetFilters: action(() => {
        this.startDate = moment()
          .subtract(1, "week")
          .startOf("week");
        this.endDate = moment()
          .subtract(1, "week")
          .endOf("week");
        this.focusedInput = null;
        this.selectedItems = {
          brand: {},
          category: {},
          tag: {},
          premise: {},
          days: 'all',
          hours: 'all'
        };

        this.compareOpen = false;
        EquipmentDetailsStore.toggleCompare(false);

        // Compare
        this.startCompareDate = moment()
          .subtract(1, "week")
          .startOf("week");
        this.endCompareDate = moment()
          .subtract(1, "week")
          .endOf("week");
        this.focusedCompareInput = null;
        this.selectedCompareItems = {
          brand: {},
          category: {},
          tag: {},
          premise: {},
          days: 'all',
          hours: 'all'
        };
      }),
      useFilters: action(() => {
        this.activeFilters = {
          startDate: this.startDate,
          endDate: this.endDate,
          tags: this.selectedItems.tag,
          premises: this.selectedItems.premise,
          brands: this.selectedItems.brand,
          categories: this.selectedItems.category,
          includedDays: this.selectedItems.days,
          includedHours: this.selectedItems.hours
        };

        if(this.compareOpen === true) {
          this.compareFilters = {
            startDate: this.startCompareDate,
            endDate: this.endCompareDate,
            tags: this.selectedCompareItems.tag,
            premises: this.selectedCompareItems.premise,
            brands: this.selectedCompareItems.brand,
            categories: this.selectedCompareItems.category,
            includedDays: this.selectedCompareItems.days,
            includedHours: this.selectedCompareItems.hours
          }
        } else {
          this.compareFilters = {};
        }


        if (EquipmentDetailsStore.loaded === true) {
          if(this.compareOpen === true) {
            EquipmentDetailsStore.toggleCompare(true);
          } else {
            EquipmentDetailsStore.toggleCompare(false);
          }
          EquipmentDetailsStore.reloadChart(null, null, FilterStore.filterData);
        }

        if (HomeStore.loaded === true) {
          HomeStore.reloadHomeWidgets();
        }
      })
    });
  }
}

const store = new FilterStore();

export default store;
