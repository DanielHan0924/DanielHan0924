import ComparisonStore from './ComparisonStore.js';

const mockData = [{ name: 'data1', id: 1 }, { name: 'data2', id: 2 }];

function getValues(type){
    return Object.values(ComparisonStore[type]).map(a => a.name);
}

describe('ComparisonStore', () => {
  describe('Map Into Array', () => {
    it('should return object as an array of values', () => {
      const actual = ComparisonStore.mapIntoArray(mockData);
      const expected = [{ name: 'data1', id: 1 }, { name: 'data2', id: 2 }];

      expect(actual).toEqual(expected);
    });
  });
  describe('Set Property', () => {
    it('should set premise', () => {
      const valuesBeforeSetting = getValues('premise');
      ComparisonStore.setProperty(mockData, 'premise');
      const valuesAfterSetting = getValues('premise');

      expect(valuesBeforeSetting.length).toEqual(0);
      expect(valuesAfterSetting.length).toEqual(2);
    });
    it('should set category', () => {
      const valuesBeforeSetting = getValues('category');
      ComparisonStore.setProperty(mockData, 'category');
      const valuesAfterSetting = getValues('category');

      expect(valuesBeforeSetting.length).toEqual(0);
      expect(valuesAfterSetting.length).toEqual(2);
    });
  });
  describe('Set Utilization Data', () => {
    it('should set utilizationData', () => {
      const mockUtilizationData = [{ name: 'data1', equipment_id: 1 }, { name: 'data2', equipment_id: 2 }];

      const valuesBeforeSetting = getValues('utilizationData');
      ComparisonStore.setUtilizationData(mockUtilizationData);
      const valuesAfterSetting = getValues('utilizationData');

      expect(valuesBeforeSetting.length).toEqual(0);
      expect(valuesAfterSetting.length).toEqual(2);
    });
  });
  describe('Get Property Names', () => {
    it('should return premise names', () => {
      ComparisonStore.setProperty(mockData, 'premise');
      const actual = ComparisonStore.getPropertyNames('premise');
      const expected = ['data1', 'data2'];
      expect(actual).toEqual(expected);
    });

    it('should return device names', () => {
      ComparisonStore.setProperty(mockData, 'device');
      const actual = ComparisonStore.getPropertyNames('device');
      const expected = ['data1', 'data2'];
      expect(actual).toEqual(expected);
    });
  });
});
