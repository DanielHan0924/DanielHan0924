import { extendObservable, action } from "mobx";
import _ from "lodash";

import ApiMiddleware from "../services/Api";
import Auth from "../services/Auth";

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

class AdminStore {
  constructor() {
    extendObservable(this, {
      devices: [],
      premises: [],
      brands: [],
      models: [],
      equipment: [],
      equipmentModels: [],
      categories: [],
      selectedModel: null,
      selectedEquipment: {},
      image: null,
      hoveringEquipment: null,
      editingEquipment: null,
      loadingDevices: true,
      loadingPremises: true,
      loadingModels: true,
      loadingBrands: true,
      loadingCategories: true,
      loadingEquipmentModels: true,
      loadingCustomers: true,
      drawing: false,
      mapping: false,
      mappingNew: false,
      removing: false,
      redrawing: false,
      loadingCalibrationImage: false,
      filterUnmapped: true,
      removingBoxId: null,
      removingEquipmentId: null,
      redrawingBoxId: null,
      redrawingEquipmentId: null,
      currentDevice: null,
      drawingCoordinates: [{ x: null, y: null}, {x: null, y: null}],
      fetchDevices: action(() => {
          this.loadingDevices = true;
          api
            .get(`/device`)
            .then(response => {
              this.devices = _.extend([], response.data);
              this.loadingDevices = false;
            });

      }),
      fetchPremises: action(() => {
        this.loadingPremises = true;
        api
          .get(`/premise`)
          .then(response => {
            this.premises = _.extend([], response.data);
            this.loadingPremises = false;
          });
      }),
      fetchModels: action(() => {
        this.loadingModels = true;
        api
          .get(`/model`)
          .then(response => {
            const models = _.filter(response.data, {type: 'device'});
            this.models = _.extend([], models);
            this.loadingModels = false;
          });
      }),
      fetchEquipmentModels: action(() => {
        this.loadingEquipmentModels = true;
        api
          .get(`/model`)
          .then(response => {
            let models = [];
            const equipmentModels = _.filter(response.data, {type: 'equipment'});

            _.each(equipmentModels, (item) => {
              models.push({
                id: `brand_${item.brand.id}`,
                lvl: 0,
                name: item.brand.name,
              })
            });

            models = _.uniqBy(models, 'id');

            _.each(equipmentModels, (item) => {
              const parent = _.find(models, { id: `brand_${item.brand.id}` });
              models.push({
                id: item.id,
                lvl: 1,
                name: item.name,
                parent: parent.id
              })
            });

            this.equipmentModels = models;
            this.loadingEquipmentModels = false;
          });
      }),
      fetchEquipment: action(() => {
        this.loadingEquipment = true;
        this.equipment = _.extend([], []);
        api
          .get(`/equipment`)
          .then(response => {
            this.equipment = _.extend([], response.data);
            this.loadingEquipment = false;
          });
      }),
      fetchCategories: action(() => {
        this.loadingCategories = true;
        api
          .get(`/category`)
          .then(response => {
            this.categories = _.extend([], response.data);
            this.loadingCategories = false;
          });
      }),
      fetchImage: action((deviceId) => {
        this.loadingCalibrationImage = true;
        api
          .get(`/device/${deviceId}/calibration_image`)
          .then(response => {
            this.setCalibrationImage(response.data.url);
          });
      }),
      setCalibrationImage: action((image) => {
        this.image = image;
        this.loadingCalibrationImage = false;
      }),
      setSelectedDeviceModel: action((modelId) => {
        this.selectedModel = _.extend({}, {[modelId]: true});
      }),
      setSelectedEquipmentModel: action((equipmentId) => {
        this.selectedEquipment = _.extend({}, {[equipmentId]: true});
      }),
      setDrawing: action((value) => {
        this.drawing = value;
      }),
      setDrawingStartCoordinates: action((x, y) => {
        this.drawingCoordinates[0] = {x, y};
      }),
      setDrawingEndCoordinates: action((x, y) => {
        this.drawingCoordinates[1] = {x, y};
      }),
      setMapping: action((status) => {
        if(status === false) {
          this.editingEquipment = null;
        }
        this.mapping = status;
      }),
      setMappingNew: action((status) => {
        this.mappingNew = status;
      }),
      setRemoving: action((status) => {
        if(status === false) {
          this.removingBoxId = null;
          this.removingEquipmentId = null;
        }
        this.removing = status;
      }),
      setRedrawing: action((status, boxId, equipmentId) => {
        this.redrawingBoxId = boxId;
        this.redrawingEquipmentId = equipmentId;
        this.redrawing = status;
      }),
      setRemovingBox: action((boxId, equipmentId) => {
        this.removingBoxId = boxId;
        this.removingEquipmentId = equipmentId;
      }),
      setHovering: action((id) => {
        this.hoveringEquipment = id;
      }),
      setEditing: action((id) => {
        this.editingEquipment = id;
      }),
      toggleSidebarFilter: action(() => {
        this.filterUnmapped = !this.filterUnmapped;
      }),
      setCurrentDevice: action((device) => {
        this.currentDevice = device;
      }),
      resetEquipment: action((device) => {
        this.equipment = _.extend([],[]);
      }),
      updateDeviceName: action((deviceId, newName) => {
        _.each(this.devices, (device) => {
          if(parseInt(device.id,10) === parseInt(deviceId,10)) {
            device.name = newName;
          }
        })
      })
    });
  }
}

const store = new AdminStore();

export default store;
