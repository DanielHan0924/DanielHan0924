import { extendObservable, action } from 'mobx';
import moment from "moment";

import TagStore from './TagStore.js';
import timespanTypes from '../enumerators/timeSpanTypes.js';

import ApiMiddleware from '../services/Api.js';
import Auth from '../services/Auth.js';
const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

class TagSelectionStore {
  constructor(){
    extendObservable(this, {
      selectedTag: null,
      rowSelections: {},
      timeSpanSelections: {},
      selectedUtilizationData: [],
      selectedLabels: [],
      tagToDateUtilizationData: [],
      oneWeekUtilizationData: [],
      twoWeekUtilizationData: [],
      oneMonthUtilizationData: [],
      tagToDateLabels: [],
      oneWeekLabels: [],
      twoWeekLabels: [],
      oneMonthLabels: [],
      tagToDateTimespan: null,
      oneWeekTimeSpan: 7,
      twoWeekTimeSpan: 14,
      oneMonthTimeSpan: 30,
      error: {
        utilization: false,
        ab: false
      },
      setError: action((type) => {
        const error = Object.assign({}, this.error);
        error[type] = true;
        this.error = error;
      }),
      setSelectedTag: action((tag = null) => {
        this.selectedTag = tag;
      }),
      handleRowSelection: action(selectedTag => {
        this.resetTagSelections();
        this.setRowSelections(selectedTag);
        this.setSelectedTag(selectedTag);
        this.fetchAllTagUtilization(selectedTag);
        const daysSinceTagDate = this.getDaysSinceTagDate(selectedTag);
        this.setTagToDateTimespan(daysSinceTagDate);
      }),
      setRowSelections: action(tag => {
        const newRowSelections = {};
        newRowSelections[tag.id] = true;
        this.rowSelections = newRowSelections;
      }),
      handleTimeSpanSelection: action(timeSpanName => {
        this.resetTimeSpanSelections();
        this.setTimeSpanSelections(timeSpanName);
        this.setSelectedUtilizationData(timeSpanName);
        this.setSelectedLabels(timeSpanName);
      }),
      setTimeSpanSelections: action(timeSpanName => {
        this.timeSpanSelections[timeSpanName] = true;
      }),
      resetTimeSpanSelections: action(() => {
        const newSelections = {};
        const selectionsKeys = Object.keys(this.timeSpanSelections);
        selectionsKeys.forEach(key => {
          newSelections[key] = false;
        });
        this.timeSpanSelections = newSelections;
      }),
      setSelectedUtilizationData: action(timeSpanName => {
        switch(timeSpanName){
          case timespanTypes.TAG_TO_DATE:
            this.selectedUtilizationData = this.tagToDateUtilizationData;
            break;
          case timespanTypes.ONE_WEEK:
            this.selectedUtilizationData = this.oneWeekUtilizationData;
            break;
          case timespanTypes.TWO_WEEK:
            this.selectedUtilizationData = this.twoWeekUtilizationData;
            break;
          case timespanTypes.ONE_MONTH:
            this.selectedUtilizationData = this.oneMonthUtilizationData;
            break;
          default:
            this.selectedUtilizationData = [];
            break;
        }
      }),
      setSelectedLabels: action(timeSpanName => {
        switch(timeSpanName){
          case timespanTypes.TAG_TO_DATE:
            this.selectedLabels = this.tagToDateLabels;
            break;
          case timespanTypes.ONE_WEEK:
            this.selectedLabels = this.oneWeekLabels;
            break;
          case timespanTypes.TWO_WEEK:
            this.selectedLabels = this.twoWeekLabels;
            break;
          case timespanTypes.ONE_MONTH:
            this.selectedLabels = this.oneMonthLabels;
            break;
          default:
            this.selectedLabels = [];
            break;
        }
      }),
      setTagToDateTimespan: action(daysSinceTagDate => {
        this.tagToDateTimespan = daysSinceTagDate;
      }),
      resetTagSelections: action(() => {
        TagStore.setIsEditing(false);
        this.resetSelectedTag();
        this.resetRowSelections();
        this.setSelectedUtilizationData();
        this.setSelectedLabels();
        this.resetTimeSpanSelections();
      }),
      resetSelectedTag: action(() => {
        this.setSelectedTag(null);
      }),
      resetRowSelections: action(() => {
        const { rowSelections } = this;
        const selectionsKeys = Object.keys(rowSelections);
        const resetSelections = {};
        selectionsKeys.forEach(key => {
          resetSelections[key] = false;
        });
        this.setRowSelections(resetSelections);
      }),
      checkIsUtilizationDataLoaded: action(() => {
        if (
          this.selectedUtilizationData.length &&
          this.tagToDateUtilizationData.length &&
          this.oneWeekUtilizationData.length &&
          this.twoWeekUtilizationData.length &&
          this.oneMonthUtilizationData.length
        ){
          return true;
        }
        return false;
      }),
      fetchAllTagUtilization: action(tag => {
        this.resetUtilizationData();
        this.resetLabels();

        const daysSinceTagDate = this.getDaysSinceTagDate(tag);
        const daysInOneWeek = this.oneWeekTimeSpan;
        const daysInTwoWeek = this.twoWeekTimeSpan;
        const daysInOneMonth = this.oneMonthTimeSpan;

        /* parameters: tag object, timespan, label type, data type */
        this.fetchUtilization(tag, daysSinceTagDate, 'tagToDateLabels', 'tagToDateUtilizationData');
        this.fetchUtilization(tag, daysInOneWeek, 'oneWeekLabels', 'oneWeekUtilizationData');
        this.fetchUtilization(tag, daysInTwoWeek, 'twoWeekLabels', 'twoWeekUtilizationData');
        this.fetchUtilization(tag, daysInOneMonth, 'oneMonthLabels', 'oneMonthUtilizationData');
        this.fetchAbData(tag);
      }),
      resetUtilizationData: action(() => {
        this.tagToDateUtilizationData = [];
        this.oneWeekUtilizationData = [];
        this.twoWeekUtilizationData = [];
        this.oneMonthUtilizationData = [];
      }),
      resetLabels: action(() => {
        this.tagToDateLabels = [];
        this.oneWeekLabels = [];
        this.twoWeekLabels = [];
        this.oneMonthLabels = [];
      }),
      fetchUtilization: action((tag, timeSpan, labelType, dataType) => {
        const parameters = this.buildparameters(tag, timeSpan);
        if (!parameters){
          return;
        }

        api
          .get(`/utilization?${parameters}`)
          .then(response => {
            const isDataUpToDate = this.isFetchedDataUpToDate(tag);

            if(!isDataUpToDate){
              return;
            }
            const utilizationData = this.buildUtilizationData(response.data);
            const labels = this.buildLabels(response.data);
            this.setLabels(labels, labelType);
            this.setUtilizationData(utilizationData, dataType);
            this.handleTimeSpanSelection('tagToDate');
          }).catch(() => {
            this.setError('utilization');
          });
      }),
      setLabels: action((labels, type) => {
        this[type] = labels;
      }),
      setUtilizationData: action((data, type) =>{
        this[type] = data;
      }),
      fetchAbData: action(tag => {
        api
          .get(`/tag/${tag.id}`)
          .then(response => {
            const isDataUpToDate = this.isFetchedDataUpToDate(tag);
            if(isDataUpToDate){
              this.setSelectedTag(response.data[0]);
            }
          }).catch(() => {
            this.setError('ab');
          });
      }),
    });
  }

  getDaysSinceTagDate(tag){
    const dateToday = moment();
    const tagDate = tag.timestamp_activated;
    const daysSinceTagDate = dateToday.diff(tagDate, 'days');
    return daysSinceTagDate;
  }
  buildparameters(
    tag,
    timespan
  ){
    const date = tag.timestamp_activated;
    const startDate = this.getStartDate(date, timespan);
    const endDate = this.getEndDate(date, timespan);

    const parameters = {
      startDatetime: startDate.format(
        "YYYY-MM-DD 00:00:00"
      ),
      endDatetime: endDate.format(
        "YYYY-MM-DD 23:59:59"
      ),
      metric: "utilization",
      groupBy: 'timeRound,premise_id',
      timeRound: 'day',
    };

    const equipmentIds = this.getIdsSeparatedByComma(tag, 'equipment_id');
    if (equipmentIds){
      parameters.equipment_id = equipmentIds;
    }
    else{
      parameters.premise_id = this.getIdsSeparatedByComma(tag, 'premise_id');
    }
    return Object.keys(parameters)
      .map(key => `${key}=${parameters[key]}`)
      .join('&');
  }
  getStartDate(dateString, timespan){
    const date = moment(dateString);
    const startDate = date.subtract(timespan, 'days');
    return startDate;
  }
  getEndDate(dateString, timespan){
    const date = moment(dateString);
    const endDate = date.add(timespan, 'days');
    return endDate;
  }
  getIdsSeparatedByComma(tag, type){
    const ids = tag[type];
    if(!ids[0]){
      return null;
    }
    const idsSeparatedByComma = ids.join();
    return idsSeparatedByComma;
  }
  isFetchedDataUpToDate(tag){
    const { selectedTag } = this;
    return selectedTag && tag.id === selectedTag.id;
  }
  buildUtilizationData(data){
    const utilizationData = [];
    data.forEach(object => {
      utilizationData.push(object.utilization);
    });
    return utilizationData;
  }
  buildLabels(data){
    const labels = [];
    data.forEach(object => {
      labels.push(object.timeRound);
    });
    return labels;
  }

}

const store = new TagSelectionStore();
export default store;

/* joel.salminen@indoorinformatics.com */
