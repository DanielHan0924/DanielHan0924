import { extendObservable, action } from "mobx";

import tipsEn from '../assets/tips/tips_en.js';
import tipsFi from '../assets/tips/tips_fi.js';

class LoadingTipStore {
  constructor() {
    extendObservable(this, {
      isVisible: true,
      tipsEn,
      tipsFi,
      height: 500,
      width: "70%",
      language: '',
      setIsVisible: action(isVisible => {
        this.isVisible = isVisible
      }),
      getRandomTip: action(() => {
        let maxIndex;
        let randomIndex;
        switch(this.language) {
          case 'en':
            maxIndex = this.tipsEn.length-1;
            randomIndex = Math.round(Math.random() * maxIndex);
            return this.tipsEn[randomIndex];
          case 'fi':
            maxIndex = this.tipsFi.length-1;
            randomIndex = Math.round(Math.random() * maxIndex);
            return this.tipsFi[randomIndex];
          default:
            return '';
        }
      }),
      setLanguage: action (language => {
        this.language = language;
      })

    });
  }
}

const store = new LoadingTipStore();

export default store;
