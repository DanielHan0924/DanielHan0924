import { extendObservable, action } from "mobx";

class LocalizationStore {
  constructor() {
    extendObservable(this, {
      language: 'fi',
      setLanguage: action(language => {
        this.language = language;
        localStorage.setItem('gpLanguage', language);
      }),
    });
  }
}

const store = new LocalizationStore();

export default store;
