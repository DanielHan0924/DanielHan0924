import { extendObservable, action } from "mobx";

class SelectorStore {
  constructor() {
    extendObservable(this, {
      focusedInput: null,
      activeFilters: {},
      selectedItem: {},
      openDropdowns: {
        dimensionsDetails: false,
        dimensionsAvg: false,
        sortByDetails: false
      },
      filterValues: {},
      setFilterData: action((type, data) => {
        if (this.filterData[type] === undefined) {
          this.filterData[type] = [];
        }
        this.filterData[type] = data;
      }),
      toggleDropdown: action(type => {
        this.openDropdowns[type] = !this.openDropdowns[type];
      }),
      closeDropdown: action(type => {
        this.openDropdowns[type] = false;
      }),
      toggleItem: action((value, type) => {
        this.selectedItem[type] = value;
        this.openDropdowns[type] = false;
      })
    });
  }
}

const store = new SelectorStore();

export default store;
