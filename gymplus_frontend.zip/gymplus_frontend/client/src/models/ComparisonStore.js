import { extendObservable, action } from 'mobx';
import _ from 'lodash';
import moment from 'moment';

import mapIntoObject from '../utils/mapIntoObject.js';

import ApiMiddleware from '../services/Api.js';
import Auth from '../services/Auth.js';
const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

class ComparisonStore{
  constructor(){
    extendObservable(this, {
      premise: {},
      category: {},
      equipment: {},
      utilizationData: {},
      cumulativeHours: {},
      hoursUntilStartDate: {},
      hoursUntilEndDate: {},
      startDate: moment().subtract(31, "day"),
      endDate: moment().subtract(1, 'day'),
      fetchProperty: action(async (type) => {
        const propertyToFetch = this[type]
        if (!_.isEmpty(propertyToFetch)) return;
         await api
          .get(`/${type}`)
          .then(response => {
            this.setProperty(response.data, type);
          }).catch(error => {
            console.log(error);
          });
      }),
      getComparisonStoreData: action(() => {
        return {
          premise: Object.assign({}, this.premise),
          category: Object.assign({}, this.category),
          equipment: Object.assign({}, this.equipment),
          utilizationData: Object.assign({}, this.utilizationData),
          cumulativeHours: Object.assign({}, this.cumulativeHours),
          startDate: this.startDate,
          endDate: this.endDate,
          hoursUntilStartDate: Object.assign({}, this.hoursUntilStartDate),
          hoursUntilEndDate: Object.assign({}, this.hoursUntilEndDate)
        };
      }),
      setProperty: action((data, type) => {
        const responseDataInObjectForm = mapIntoObject(data);
        this[type] = responseDataInObjectForm;
      }),
      fetchEquipmentUtilization: action(() => {
        const parameters = this.buildParameters();
        api
          .get(`/utilization?${parameters}`)
          .then(response => {
            this.setUtilizationData(response.data);
          }).catch(error => {
            console.log('utilization error')
          });
      }),
      fetchCumulativeHours: action(() => {
        const metric = 'cumulative_hour';
        const parameters = this.buildParameters(metric);
        api
          .get(`/utilization?${parameters}`)
          .then(response => {
            this.setCumulativeHours(response.data);
          }).catch(error => {
            console.log('cumulative error')
          });
      }),
      fetchHoursUntilStartDate: action(() => {
        const metric = 'cumulative_hour';
        const parameters = this.buildParameters(metric, this.startDate);
        api
          .get(`/utilization?${parameters}`)
          .then(response => {
            this.setHoursUntilStartDate(response.data);
          }).catch(error => {
            console.log('cumulative error')
          });
      }),
      fetchHoursUntilEndDate: action(() => {
        const metric = 'cumulative_hour';
        const parameters = this.buildParameters(metric);
        api
          .get(`/utilization?${parameters}`)
          .then(response => {
            this.setHoursUntilEndDate(response.data);
          }).catch(error => {
            console.log('cumulative error')
          });
      }),
      setHoursUntilStartDate: action((data) => {
        const id = 'equipment_id';
        const dataMappedIntoObject = mapIntoObject(data, id);
        this.hoursUntilStartDate = dataMappedIntoObject;
      }),
      setHoursUntilEndDate: action((data) => {
        const id = 'equipment_id';
        const dataMappedIntoObject = mapIntoObject(data, id);
        this.hoursUntilEndDate = dataMappedIntoObject;
      }),
      setCumulativeHours: action((data) => {
        const id = 'equipment_id';
        const dataMappedIntoObject = mapIntoObject(data, id);
        this.cumulativeHours = dataMappedIntoObject;
      }),
      setUtilizationData: action((data) => {
        const id = 'equipment_id'
        const newUtilizationData = mapIntoObject(data, id);
        this.utilizationData = newUtilizationData;
      }),
      getPropertyNames: action((type) => {
        return this.mapIntoArray(this[type]).map(property => property.name);
      }),
      mapIntoArray: action((object) => {
        return Object.values(object);
      })
    });
  }
  buildParameters(metric = 'utilization', endDate = this.endDate){
    const startDatetime = this.startDate.format("YYYY-MM-DD 00:00:00");
    const endDatetime = endDate.format("YYYY-MM-DD 23:59:59");

    const parameters = {
      startDatetime,
      endDatetime,
      metric,
      groupBy: 'equipment_id',
    };

    if (metric === 'utilization') parameters.timeRound = 'day';

    return Object.keys(parameters)
      .map(key => `${key}=${parameters[key]}`)
      .join('&');
  }
}

const store = new ComparisonStore();
export default store;
