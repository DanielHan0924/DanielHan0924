import { extendObservable, action } from 'mobx';
import _ from 'lodash';

import TagStore from './TagStore.js';
import columnTypes from '../enumerators/columnTypes.js';
import tableColumns from '../enumerators/tableColumns.js';
import smallTableColumns from '../enumerators/smallTableColumns.js';

class TagTableColumnStore {
  constructor(){
    extendObservable(this, {
      columnTypes,
      tableColumns: [],
      selectedColumns: {},
      toggleColumn: action(id => {
        this.selectedColumns[id] = !this.selectedColumns[id];
      }),
      initializeTableColumns: action(() => {
        const isSmallDevice = this.checkIsSmallDevice();
        if(isSmallDevice) {
          this.tableColumns = smallTableColumns;
          return;
        }
        this.tableColumns = tableColumns;
      }),
      setSelectedColumns: action(() => {

        const selectedColumns = {};
        const { tableColumns } = this;
        tableColumns.forEach(column => {
          if (column.showByDefault){
            selectedColumns[column.id] = true;
          }
          else{
            selectedColumns[column.id] = false;
          }
        });
        this.selectedColumns = selectedColumns;
      }),
      handleTagSorting: action((columnType, isReversed = false) => {
        const { tags } = TagStore;
        const sortedColumnValues = this.getSortedColumnValues(tags, columnType, isReversed);
        const sortedTags = this.sortTags(sortedColumnValues, columnType);
        TagStore.setTags(sortedTags);
      })
    });
  }

  checkIsSmallDevice(){
    return window.innerWidth < 600;
  }
  getSortedColumnValues(tags, columnType, isReversed){
    const columnValues = tags.map(tag => tag[columnType]);
    if (isReversed && this.checkIsColumnTypeDiff(columnType)){
      const secondValuesOfColumnValuesArray = columnValues.map(value => value[1]);
      return secondValuesOfColumnValuesArray.reverse();
    }
    if(isReversed){
      return columnValues.reverse();
    }
    if (this.checkIsColumnTypeId(columnType)){
      return columnValues.sort((a, b) => a-b);
    }
    if (this.checkIsColumnTypeDiff(columnType)){
      const secondValuesOfColumnValuesArray = columnValues.map(value => value[1]);
      return secondValuesOfColumnValuesArray.sort((a, b) => a-b);
    }
    return columnValues.sort();
  }
  checkIsColumnTypeId(columnType){
    const { columnTypes } = this;
    return columnType === columnTypes.ID;
  }
  checkIsColumnTypeDiff(columnType){
    const { columnTypes } = this;
    return (
      columnType === columnTypes.TAG_TO_DATE_DIFFERENCE ||
      columnType === columnTypes.D7_RELDIFF ||
      columnType === columnTypes.D14_RELDIFF ||
      columnType === columnTypes.D30_RELDIFF
    );
  }
  sortTags(sortedColumnValues, columnType){
    const clonedTags = TagStore.tags.map(tag => Object.assign({}, tag));
    const sortedTags = [];
    sortedColumnValues.forEach(value => {
      const foundTag = this.findTag(clonedTags, columnType, value);
      sortedTags.push(foundTag);
      _.remove(clonedTags, tag => tag.id === foundTag.id);
    });
    return sortedTags;
  }
  findTag(tags, columnType, value){
    if(!this.checkIsColumnTypeDiff(columnType)){
      return tags.find(tag => tag[columnType] === value);
    }
    return tags.find(tag => tag[columnType][1] === value);
  }
}

const store = new TagTableColumnStore();
export default store;

/* joel.salminen@indoorinformatics.com */
