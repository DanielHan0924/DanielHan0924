import { extendObservable, action } from 'mobx';
import moment from "moment";

import ApiMiddleware from '../services/Api';
import Auth from '../services/Auth';
import dayOfWeekTypes from '../enumerators/dayOfWeekTypes.js';

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

class SingleEquipmentStore {
  constructor(){
    extendObservable(this, {
      startDate: moment()
        .subtract(1, "week")
        .startOf("week"),
      endDate: moment()
        .subtract(1, "week")
        .endOf("week"),
      equipment: {},
      oneDayStart: moment()
        .subtract(1, "week")
        .startOf("week"),
      categories: [],
      dowUtilizationData: [],
      hourUtilizationData: [],
      averageUtilizationData: [],
      dowLabels: [],
      hourLabels: [],
      averageUtilizationLabels: [],
      avgGroupBy: null,
      width: 720, /* width and height of the SingleEquipmentView */
      height: 800,
      datePickerFocusedInput: null,
      isVisible: false,
      showDow: true, /* true => dow chart is shown, false => hoursly chart is shown */
      setGroupBy: action(groupBy => {
        this.groupBy = groupBy;
      }),
      setDates: action (dates => {
        this.startDate = dates.startDate;
        this.endDate = dates.endDate;
      }),
      setEquipment: action(equipment => {
        this.equipment = equipment;
      }),
      setOneDayStart: action(day => {
        this.oneDayStart = moment(this.startDate, "YYYY-MM-DD").add(day, 'days');
      }),
      setIsVisible: action(isVisible => {
        this.isVisible = isVisible;
      }),
      setShowDow: action (value => {
        this.showDow = value;
      }),
      toggleShowDow: action (() => {
        this.showDow = !this.showDow;
      }),
      setDowLabels: action ((labels) => {
        this.dowLabels = labels;
      }),
      setHourLabels: action (labels => {
        this.hourLabels = labels.slice();
      }),
      setAverageUtilizationLabels: action (labels => {
        this.averageUtilizationLabels = labels;
      }),
      setDatePickerFocus: action(value => {
        this.datePickerFocusedInput = value;
      }),
      setDowUtilizationData: action (data => {
        this.dowUtilizationData = data.slice();
      }),
      setHourUtilizationData: action (data => {
        this.hourUtilizationData = data.slice();
      }),
      setAverageUtilizationData: action (data => {
        this.averageUtilizationData = data.slice();
      }),
      setAvgGroupBy: action(groupBy => {
        this.avgGroupBy = groupBy;
      }),
      isLoadingHourly: action(() => {
        return !(this.hourUtilizationData.length > 0);
      }),
      isLoadingAverage: action(() => {
        return !(this.averageUtilizationData.length > 0);
      }),
      isLoadingDow: action (() => {
        return !(this.dowUtilizationData.length > 0);
      }),
      reloadDowChart: action(equipmentId => {
        if (this.dowLabels.length === 0){
          this.setDowLabels();
        }
        this.setDowUtilizationData([]);
        this.fetchDowUtilizationData(equipmentId);

      }),
      reloadHourChart: action(equipmentId => {
        if (this.hourLabels.length === 0){
          this.setHourLabels([]);
        }
        this.setHourUtilizationData([]);
        this.fetchHourUtilizationData(equipmentId);
      }),
      reloadAverageChart: action(equipmentId => {
        if (this.averageUtilizationLabels.length === 0){
          this.setAverageUtilizationLabels();
        }
        this.setAverageUtilizationData([]);
        this.fetchAverageUtilizationData(equipmentId);
      }),
      reloadAllCharts: action((equipmentId) => {
        this.reloadDowChart(equipmentId);
        this.reloadHourChart(equipmentId);
        this.reloadAverageChart(equipmentId);
        this.setShowDow(true);
      }),
      formatDowLabelsAndData: action((rawData) => {
        const orderedUtilizationData = [];
        const dowLabels = [];
        let currentDate = this.startDate;

        for(let i = 0; i < rawData.length; i++){
          const foundUtilizationObject = this.findNextUtilizationObject(rawData, currentDate);
          orderedUtilizationData.push(foundUtilizationObject.utilization);
          dowLabels.push(this.getDayOfWeekName(currentDate));
          currentDate = this.getNextDay(currentDate);
        }
        this.setDowLabels(dowLabels);
        this.setDowUtilizationData(orderedUtilizationData);
      })


    });
  }

  getNextDay(date){
    return moment(date).add(1, 'days');
  }
  findNextUtilizationObject(rawData, date){
    const firstDayIndex = this.convertDayOfWeekToTimePart(date);
    return rawData.find(object => object.timePart === firstDayIndex);
  }

  getDayOfWeekName(date){
    const locationName = localStorage.getItem('gpLanguage');
    return date.locale(locationName).format('dddd')
  }
  convertDayOfWeekToTimePart(date){
    const nameOfDay = date.locale('en').format('dddd');
    switch(nameOfDay){
      case dayOfWeekTypes.MONDAY:
        return 1;
      case dayOfWeekTypes.TUESDAY:
        return 2;
      case dayOfWeekTypes.WEDNESDAY:
        return 3;
      case dayOfWeekTypes.THURSDAY:
        return 4;
      case dayOfWeekTypes.FRIDAY:
        return 5;
      case dayOfWeekTypes.SATURDAY:
        return 6;
      case dayOfWeekTypes.SUNDAY:
        return 0;
      default:
        return null;
    }
  }
  fetchCategories(){
    api
      .get('/category')
      .then(response => {
        this.categories = response.data;
        return response.data;
      });
  }
  fetchDowUtilizationData (equipmentId) {

    const params = this.buildParams(equipmentId, 'dow', 'timePart', false);
    if(params){
      api
        .get(`/utilization?${params}`)
        .then(response => {
          this.formatDowLabelsAndData(response.data);
        });
    }


  }
  fetchHourUtilizationData(equipmentId) {
    const params = this.buildParamsHourly(equipmentId, 'hour', 'timePart', false);
    if (params){
      api
        .get(`/utilization?${params}`)
        .then(response => {
          const utilizationData = [];
          const labels = [];
          response.data.forEach(object => {
            utilizationData.push(object.utilization);
            labels.push(object.timePart);
          });
          this.setHourUtilizationData(utilizationData);
          this.setHourLabels(labels);
        });
    }
  }

  fetchAverageUtilizationData(equipmentId) {
    const currentStartDate = moment(this.startDate);
    const currentEndDate = moment(this.endDate);
    const lengthDays = currentEndDate.diff(currentStartDate, "days");
    const daysInWeek = 7;
    const daysInSixMonths = 180;
    let groupBy;

    if(lengthDays <= daysInWeek) {
      groupBy = 'hour';
    } else if(lengthDays <= daysInSixMonths) { // about 6 months
      groupBy = 'day';
    } else {
      groupBy = 'week';
    }

    this.setAvgGroupBy(groupBy);
    const params = this.buildParams(equipmentId, groupBy, 'timeRound', true);
    if (params){
      this.avgGroupBy = groupBy;
      api
        .get(`/utilization?${params}`)
        .then(response => {
          const utilizationData = [];
          const labels = [];
          response.data.forEach(object => {
            utilizationData.push(object.utilization);
            labels.push(object.timeRound);
          });

          this.setAverageUtilizationData(utilizationData);
          this.setAverageUtilizationLabels(labels);
        });
    }

  }

  buildParams(
    equipmentId,
    timePart,
    groupBy,
    useTimeRound = false
  ){
    const { startDate, endDate } = this;
    if (startDate && endDate){
      const params = {
        startDatetime: startDate.format(
          "YYYY-MM-DD 00:00:00"
        ),
        endDatetime: endDate.format(
          "YYYY-MM-DD 23:59:59"
        ),
        metric: "utilization",
        groupBy,
        equipment_id: equipmentId,
      };
      if (useTimeRound) {
        params.timeRound = timePart;
      }
      else {
        params.timePart = timePart;
      }
      return Object.keys(params)
        .map(key => `${key}=${params[key]}`)
        .join('&');
    }
    return null;

  }
  buildParamsHourly(
    equipmentId,
    timePart,
    groupBy,
  ){
    const { oneDayStart } = this;
    const params = {
      startDatetime: oneDayStart.format(
        "YYYY-MM-DD 00:00:00"
      ),
      endDatetime: oneDayStart.format(
        "YYYY-MM-DD 23:59:59"
      ),
      metric: "utilization",
      groupBy,
      equipment_id: equipmentId,
      timePart,
    };
    return Object.keys(params)
      .map(key => `${key}=${params[key]}`)
      .join('&');
  }

}


const store = new SingleEquipmentStore();
export default store;

/* joel.salminen@indoorinformatics.com */
