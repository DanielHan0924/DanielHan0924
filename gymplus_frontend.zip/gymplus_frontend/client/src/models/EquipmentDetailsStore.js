import { extendObservable, action, toJS } from "mobx";
import _ from "lodash";

// Helpers & Services
import ApiMiddleware from "../services/Api";
import Auth from "../services/Auth";

import FilterStore from "./FilterStore";

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

class EquipmentDetailsStore {
  constructor() {
    extendObservable(this, {
      data: [],
      labels: [],
      chartData: [],
      rawData: [],
      rawCompareData: [],
      loading: false,
      loadingCompare: false,
      loaded: false,
      loadedCompare: false,
      useCompare: false,
      startDate: null,
      endDate: null,
      groupBy: "equipment_id",
      timePart: null,
      detailsSortBy: "utilization",
      setGroupBy: action(value => {
        this.groupBy = value;
      }),
      setTimePart: action(value => {
        this.timePart = value;
      }),
      setDates: action((startDate, endDate) => {
        this.startDate = startDate;
        this.endDate = endDate;
      }),
      initializeLoadedStatus: action(() => {
        this.loading = true;
        this.loadingCompare = true;
        this.loaded = false;
        this.loadedCompare = false;
      }),
      setRawData: action(data => {
        this.rawData = data;
      }),
      setRawCompareData: action(data => {
        this.rawCompareData = data;
      }),
      toggleCompare: action((value) => {
        this.useCompare = value;
      }),
      reloadChart: action((groupBy, timePart, filterData) => {
        this.initializeLoadedStatus();
        if (groupBy !== null) {
          this.setGroupBy(groupBy);
        }
        if (timePart !== null) {
          this.setTimePart(timePart);
        }
        this.fetchUtilizationData(this.groupBy, this.timePart, filterData);
        if(this.useCompare === true) {
          this.fetchCompareUtilizationData(this.groupBy, this.timePart, filterData);
        }
      }),

      sortData: action((groupBy, timePart, sortBy = "utilization") => {
        const tempData = this.rawData;
        const tempCompareData = this.rawCompareData;
        this.labels = [];
        this.data = [];
        this.chartData = [];

        const sortByAvailableIn = [
          "equipment_id",
          "category_id",
          "brand_id",
          "premise_id"
        ];

        const activeCategoryFilters = this.getSelectedItems(FilterStore.activeFilters.categories);
        const activeBrandFilters = this.getSelectedItems(FilterStore.activeFilters.brands);
        const activeTagFilters = this.getSelectedItems(FilterStore.activeFilters.tags);
        const activePremiseFilters = this.getSelectedItems(FilterStore.activeFilters.premises);

        let labelKeys = [];
        let labels = [];

        // If user has selected categories, only show data that's coming from the API.
        if(
          (
            activeCategoryFilters.length > 0 || activeBrandFilters.length > 0 ||
            activeTagFilters.length > 0 || activePremiseFilters.length > 0
          ) &&
          !timePart
         ) {
           let key = groupBy;
           if(groupBy === 'category_id') {
            key = 'equipment_category_id';
           }
          labelKeys = _.map(tempData, (item) => {
            if(item.utilization) {
              return item[key];
            }
          });
          _.each(tempCompareData, row => {
            labelKeys.push(row[key]);
          });
          labelKeys = _.uniq(labelKeys);
          labels = this.getLabels(groupBy, timePart);
        } else {
          labelKeys = this.getLabelKeys(groupBy, timePart);
          labels = this.getLabels(groupBy, timePart);
        }
        const header = [];
        const headerkeys = [...labelKeys];

        const data = [];
        const dataCompare = [];
        const labelMapping = [];

        // get label information
        let i = 0;
        _.each(headerkeys, item => {
          let g;

          if (groupBy === "category_id") {
            g = "equipment_category_id";
          } else {
            g = groupBy;
          }

          labelMapping[i] = _.find(labels, { id: item });

          let utilization = _.find(tempData, { [g]: item });
          if (utilization !== null && utilization !== undefined) {
            _.extend(labelMapping[i], {
              utilization: utilization.utilization,
            });
          } else {
            _.extend(labelMapping[i], { utilization: null });
          }

          if(this.useCompare === true && this.loadedCompare === true) {
            let compareUtilization = _.find(tempCompareData, { [g]: item });
            if (compareUtilization !== null && compareUtilization !== undefined) {
              _.extend(labelMapping[i], {
                compareUtilization: compareUtilization.utilization,
              });
            } else {
              _.extend(labelMapping[i], { compareUtilization: null });
            }
          }
          i++;
        });

        if (
          sortByAvailableIn.indexOf(groupBy) !== -1 &&
          sortBy === "utilization"
        ) {
          // The output should be sorted by utilization
          labelMapping.sort((s1, s2) => s2.utilization - s1.utilization);
        } else if (
          sortByAvailableIn.indexOf(groupBy) !== -1 &&
          sortBy === "name"
        ) {
          labelMapping.sort((s1, s2) => {
            const textA = s1.name.toUpperCase();
            const textB = s2.name.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          });
        } else if (
          groupBy === "timePart"
        ) {
          labelMapping.sort((s1, s2) => parseInt(s1.id,10) - parseInt(s2.id,10));
        }

        _.each(labelMapping, item => {
          if (item !== null && item !== undefined) {

            if (item.utilization === undefined) {
              data.push(null);
            } else {
              data.push(item.utilization);
            }

            if (item.compareUtilization === undefined) {
              dataCompare.push(null);
            } else {
              dataCompare.push(item.compareUtilization);
            }

            if (item.name === undefined) {
              header.push(null);
            } else {
              header.push(item.name);
            }
          }
        });

        return [header, data, dataCompare];
      }),

      reOrderChartData: action(sortBy => {
        this.loading = true;
        this.loadingCompare = true;
        const output = this.sortData(this.groupBy, this.timePart, sortBy);

        if(this.useCompare === true) {
          this.labels = output[0];
          this.data = [output[1], output[2]];
          this.chartData = [this.labels, this.data];
        } else {
          this.labels = output[0];
          this.data = output[1];
          this.chartData = output;
        }

        this.loading = false;
        this.loadingCompare = false;
      }),

      fetchUtilizationData: action(
        (
          groupBy,
          timePart = "dow",
          filterData = {},
          sortBy = "utilization"
        ) => {
          if (filterData.length === 0 || this.loaded === true) {
            return false;
          }

          this.loading = true;
          this.chartData = [];

          api
            .get(`/utilization?${this.buildParams(groupBy, timePart)}`)
            .then(response => {
              this.setRawData(response.data);

              this.loaded = true;
              this.combineData(groupBy, timePart, sortBy);
            });

          return true;
        }
      ),

      fetchCompareUtilizationData: action(
        (
          groupBy,
          timePart = "dow",
          filterData = {},
          sortBy = "utilization"
        ) => {
          if (filterData.length === 0 || this.loadedCompare === true) {
            return false;
          }

          this.loadingCompare = true;
          this.chartData = [];

          //console.log('compare params:', this.buildCompareParams(groupBy, timePart));

          api
            .get(`/utilization?${this.buildCompareParams(groupBy, timePart)}`)
            .then(response => {
              this.setRawCompareData(response.data);

              this.loadedCompare = true;
              this.combineData(groupBy, timePart, sortBy);
            });

          return true;
        }
      ),
      combineData: action((groupBy, timePart, sortBy) => {
        if(this.useCompare === true && this.loaded === true && this.loadedCompare) {
          const output = this.sortData(groupBy, timePart, sortBy);

          this.labels = output[0];
          this.data = [output[1], output[2]];
          this.chartData = [this.labels, this.data];
        } else if(this.useCompare === false && this.loaded === true) {
          const output = this.sortData(groupBy, timePart, sortBy);

          this.labels = output[0];
          this.data = output[1];
          this.chartData = output;
        }
      }),
      get activeFilters() {
        return FilterStore.activeFilters;
      }
    });
  }

  getSelectedItems(data) {
    return _.filter(data, item => {
        return item === true;
      }
    );
  }

  getLabelKeys(type, timePart) {
    if (type === "timePart" && timePart === "dow") {
      return [0, 1, 2, 3, 4, 5, 6];
    } else if (type === "timePart" && timePart === "month") {
      return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
    } else if (type === "timePart" && timePart === "week") {
      let labelKeys = _.map(this.rawData, type);
      _.each(this.rawCompareData, row => {
        labelKeys.push(row[type]);
      });
      return _.uniq(labelKeys)
    } else if (type === "timePart" && timePart === "quarter") {
      let labelKeys = _.map(this.rawData, type);
      _.each(this.rawCompareData, row => {
        labelKeys.push(row[type]);
      });
      return _.uniq(labelKeys)
    } else if (type === "timePart" && timePart === "day") {
      let labelKeys = _.map(this.rawData, type);
      _.each(this.rawCompareData, row => {
        labelKeys.push(row[type]);
      });
      return _.uniq(labelKeys)
    } else if (type === "premise_id") {
      const premiseIds = [];
      _.each(FilterStore.filterData.premise, premise => {
        premiseIds.push(premise.id);
      });
      return premiseIds;
    } else if (type === "category_id") {
      const categoryIds = [];
      _.each(FilterStore.filterData.category, category => {
        categoryIds.push(category.id);
      });
      return categoryIds;
    } else if (type === "brand_id") {
      const brandIds = [];
      _.each(FilterStore.filterData.brand, brand => {
        brandIds.push(brand.id);
      });
      return brandIds;
    } else if (type === "model_id") {
      const modelIds = [];
      _.each(FilterStore.filterData.model, model => {
        modelIds.push(model.id);
      });
      return modelIds;
    } else if (type === "equipment_id") {
      const equipmentIds = [];
      _.each(toJS(FilterStore.filterData.equipment), equipment => {
        equipmentIds.push(equipment.id);
      });
      return equipmentIds;
    }
    return [];
  }
  getLabels(type, timePart = "") {
    if (type === "timePart" && timePart === "dow") {
      return [
        { id: 0, name: "dimension.timePart.dow.monday" },
        { id: 1, name: "dimension.timePart.dow.tuesday" },
        { id: 2, name: "dimension.timePart.dow.wednesday" },
        { id: 3, name: "dimension.timePart.dow.thursday" },
        { id: 4, name: "dimension.timePart.dow.friday" },
        { id: 5, name: "dimension.timePart.dow.saturday" },
        { id: 6, name: "dimension.timePart.dow.sunday" }
      ];
    } else if (type === "timePart" && timePart === "month") {
      return [
        { id: 1, name: "dimension.timePart.month.januery" },
        { id: 2, name: "dimension.timePart.month.february" },
        { id: 3, name: "dimension.timePart.month.march" },
        { id: 4, name: "dimension.timePart.month.april" },
        { id: 5, name: "dimension.timePart.month.may" },
        { id: 6, name: "dimension.timePart.month.june" },
        { id: 7, name: "dimension.timePart.month.july" },
        { id: 8, name: "dimension.timePart.month.august" },
        { id: 9, name: "dimension.timePart.month.september" },
        { id: 10, name: "dimension.timePart.month.october" },
        { id: 11, name: "dimension.timePart.month.november" },
        { id: 12, name: "dimension.timePart.month.december" }
      ];
    } else if (type === "timePart" && timePart === "week") {
      const chartLabels = [];
      _.each(this.rawData, row => {
        chartLabels.push({ id: row[type], name: `${row[type]}` });
      });
      _.each(this.rawCompareData, row => {
        chartLabels.push({ id: row[type], name: `${row[type]}` });
      });
      return _.uniqBy(chartLabels, 'id');
    } else if (type === "timePart" && timePart === "quarter") {
      const chartLabels = [];
      _.each(this.rawData, row => {
        chartLabels.push({ id: row[type], name: `Q ${row[type]}` });
      });
      _.each(this.rawCompareData, row => {
        chartLabels.push({ id: row[type], name: `Q ${row[type]}` });
      });
      return _.uniqBy(chartLabels, 'id');
    } else if (type === "timePart" && timePart === "day") {
      const chartLabels = [];
      _.each(this.rawData, row => {
        chartLabels.push({ id: row[type], name: row[type] });
      });
      _.each(this.rawCompareData, row => {
        chartLabels.push({ id: row[type], name: row[type] });
      });
      return _.uniqBy(chartLabels, 'id');
    } else if (type === "premise_id") {
      const premises = [];
      _.each(FilterStore.filterData.premise, premise => {
        premises.push({ id: premise.id, name: premise.name });
      });
      return premises;
    } else if (type === "category_id") {
      const categories = [];
      const language = localStorage.getItem('gpLanguage');
      _.each(FilterStore.filterData.category, category => {
        let propertyName;
        if(language === 'fi') {
          propertyName = 'name_fi';
        } else {
          propertyName = 'name';
        }
        categories.push({ id: category.id, name: category[propertyName] });
      });
      return categories;
    } else if (type === "brand_id") {
      const brands = [];
      _.each(FilterStore.filterData.brand, brand => {
        brands.push({ id: brand.id, name: brand.name });
      });
      return brands;
    } else if (type === "equipment_id") {
      const equipmentIds = [];
      _.each(FilterStore.filterData.equipment, equipment => {
        equipmentIds.push({ id: equipment.id, name: equipment.name });
      });
      return equipmentIds;
    }
    return {};
  }

  buildParams(groupBy, timePart = "dow") {
    const selectedBrands = [];
    const selectedPremises = [];
    const selectedTags = [];
    const selectedCategories = [];

    _.each(FilterStore.activeFilters.premises, (item, key) => {
      if (item) {
        selectedPremises.push(key);
      }
      return null;
    });

    _.each(FilterStore.activeFilters.tags, (item, key) => {
      if (item) {
        selectedTags.push(key);
      }
      return null;
    });

    _.each(FilterStore.activeFilters.brands, (item, key) => {
      if (item) {
        selectedBrands.push(key);
      }
      return null;
    });

    _.each(FilterStore.activeFilters.categories, (item, key) => {
      if (item) {
        selectedCategories.push(key);
      }
      return null;
    });

    const params = {
      startDatetime: FilterStore.activeFilters.startDate.format(
        "YYYY-MM-DD 00:00:00"
      ),
      endDatetime: FilterStore.activeFilters.endDate.format(
        "YYYY-MM-DD 23:59:59"
      ),
      metric: "utilization",
      groupBy
    };

    if (FilterStore.selectedItems.hours !== "all") {
      params.includedHours = this.getSelectedHours();
    }

    if (FilterStore.selectedItems.days !== "all") {
      params.includedDays = this.getSelectedDays();
    }

    if (timePart !== undefined && timePart !== null) {
      params.timePart = timePart;
    }

    if (selectedPremises.length > 0) {
      params.premise_id = selectedPremises.join(",");
    }
    if (selectedTags.length > 0) {
      params.tag_id = selectedTags.join(",");
    }
    if (selectedCategories.length > 0) {
      params.category_id = selectedCategories.join(",");
    }
    if (selectedBrands.length > 0) {
      params.brand_id = selectedBrands.join(",");
    }

    return Object.keys(params)
      .map(key => `${key}=${params[key]}`)
      .join("&");
  }

  buildCompareParams(groupBy, timePart = "dow") {
    const selectedBrands = [];
    const selectedPremises = [];
    const selectedTags = [];
    const selectedCategories = [];

    _.each(FilterStore.compareFilters.premises, (item, key) => {
      if (item) {
        selectedPremises.push(key);
      }
      return null;
    });

    _.each(FilterStore.compareFilters.tags, (item, key) => {
      if (item) {
        selectedTags.push(key);
      }
      return null;
    });

    _.each(FilterStore.compareFilters.brands, (item, key) => {
      if (item) {
        selectedBrands.push(key);
      }
      return null;
    });

    _.each(FilterStore.compareFilters.categories, (item, key) => {
      if (item) {
        selectedCategories.push(key);
      }
      return null;
    });

    const params = {
      startDatetime: FilterStore.compareFilters.startDate.format(
        "YYYY-MM-DD 00:00:00"
      ),
      endDatetime: FilterStore.compareFilters.endDate.format(
        "YYYY-MM-DD 23:59:59"
      ),
      metric: "utilization",
      groupBy
    };

    if (FilterStore.selectedCompareItems.hours !== "all") {
      params.includedHours = this.getSelectedCompareHours();
    }

    if (FilterStore.selectedCompareItems.days !== "all") {
      params.includedDays = this.getSelectedCompareDays();
    }

    if (timePart !== undefined && timePart !== null) {
      params.timePart = timePart;
    }

    if (selectedPremises.length > 0) {
      params.premise_id = selectedPremises.join(",");
    }
    if (selectedTags.length > 0) {
      params.tag_id = selectedTags.join(",");
    }
    if (selectedCategories.length > 0) {
      params.category_id = selectedCategories.join(",");
    }
    if (selectedBrands.length > 0) {
      params.brand_id = selectedBrands.join(",");
    }

    return Object.keys(params)
      .map(key => `${key}=${params[key]}`)
      .join("&");
  }

  getSelectedHours() {
    const selection = FilterStore.selectedItems.hours;
    if (selection === "6to10am") {
      return "6,7,8,9";
    } else if (selection === "4to8pm") {
      return "16,17,18,19";
    }
  }
  getSelectedDays() {
    const selection = FilterStore.selectedItems.days;
    if (selection === "weekdays") {
      return "0,1,2,3,4";
    } else if (selection === "weekends") {
      return "5,6";
    }
  }
  getSelectedCompareHours() {
    const selection = FilterStore.selectedCompareItems.hours;
    if (selection === "6to10am") {
      return "6,7,8,9";
    } else if (selection === "4to8pm") {
      return "16,17,18,19";
    }
  }
  getSelectedCompareDays() {
    const selection = FilterStore.selectedCompareItems.days;
    if (selection === "weekdays") {
      return "0,1,2,3,4";
    } else if (selection === "weekends") {
      return "5,6";
    }
  }
}

const store = new EquipmentDetailsStore();

export default store;
