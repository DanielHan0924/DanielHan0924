import { extendObservable, action, toJS } from "mobx";
import _ from "lodash";
import moment from "moment";
import fiLocale from 'moment/locale/fi';
import enLocale from 'moment/locale/en-gb';

// Helpers & Services
import ApiMiddleware from "../services/Api";
import Auth from "../services/Auth";

import FilterStore from "./FilterStore";

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());


let language;

if(localStorage.getItem('gpLanguage') == null) {
  localStorage.setItem('gpLanguage', 'fi'); // default to fi
  language = 'fi';
} else {
  language = localStorage.getItem('gpLanguage');
}

if(language === 'fi') {
  moment.updateLocale('fi', fiLocale);
} else {
  moment.updateLocale('en', enLocale);
}

class HomeStore {
  constructor() {
    extendObservable(this, {
      equipments: [],
      categories: [],
      brands: [],
      equipmentData: [],
      categoryData: [],
      brandData: [],
      avgChartData: [],
      compareEquipmentData: [],
      hottestEquipment: [],
      coldestEquipment: [],
      loading: false,
      loaded: false,
      avgChartDataLoading: false,
      loadingCategories: false,
      loadedCategories: false,
      loadingBrands: false,
      loadedBrands: false,
      compareLoading: false,
      compareLoaded: false,
      startDate: null,
      endDate: null,
      avgGroupBy: "day",
      setDates: action((startDate, endDate) => {
        this.startDate = startDate;
        this.endDate = endDate;
      }),
      fetchEquipmentData: action(() => {
        if (
          this.loaded === true ||
          this.loading === true ||
          this.equipments.length > 0
        ) {
          return false;
        }

        this.loaded = false;
        this.loading = true;

        api.get("/equipment").then(response => {
          this.equipments = response.data;
          if (response.data.length > 0 && this.loaded === false) {
            this.fetchEquipmentUtilization();
            this.fetchCompareEquipmentUtilization();
            this.fetchEquipmentUtilizationByTime();
          }
        });
        return true;
      }),
      fetchCategoryData: action(() => {
        if (
          this.loadedCategories === true ||
          this.loadingCategories === true ||
          this.categories.length > 0
        ) {
          return false;
        }

        this.loadedCategories = false;
        this.loadingCategories = true;

        api.get("/category").then(response => {
          this.categories = response.data;
          if (response.data.length > 0 && this.loadedCategories === false) {
            this.fetchCategoryUtilization();
          }
        });
        return true;
      }),
      fetchBrandData: action(() => {
        if (
          this.loadedBrands === true ||
          this.loadingBrands === true ||
          this.brands.length > 0
        ) {
          return false;
        }

        this.loadedBrands = false;
        this.loadingBrands = true;

        api.get("/brand").then(response => {
          this.brands = response.data;
          if (response.data.length > 0 && this.loadedBrands === false) {
            this.fetchBrandUtilization();
          }
        });
        return true;
      }),
      reloadHomeWidgets: action(() => {
        this.loaded = false;
        this.loading = true;
        this.loadedCategories = false;
        this.loadingCategories = true;
        this.loadedBrands = false;
        this.loadingBrands = true;
        this.fetchEquipmentUtilization();
        this.fetchCompareEquipmentUtilization();
        this.fetchCategoryUtilization();
        this.fetchBrandUtilization();
        this.fetchEquipmentUtilizationByTime("");
      }),
      reloadAvgWidget: action(groupBy => {
        this.avgGroupBy = groupBy;
        this.fetchEquipmentUtilizationByTime();
      }),

      fetchEquipmentUtilization() {
        if (toJS(this.equipments).length === 0) {
          return false;
        }

        let params = this.buildParams("equipment_id");

        api.get(`/utilization?${params}`).then(response => {
          const equipmentInfo = toJS(this.equipments);

          const data = [];
          const data2 = [];

          // Store whole data as we'll use that in Biggest change widget tables
          this.equipmentData = response.data;

          const hottestEquipment = _.clone(response.data);
          const coldestEquipment = _.clone(response.data);

          _.each(hottestEquipment, row => {
            data.push({
              equipment_id: row.equipment_id,
              name: _.find(equipmentInfo, { id: row.equipment_id }).name,
              utilization: row.utilization
            });
          });
          data.sort((s1, s2) => s2.utilization - s1.utilization);

          const hotData = data.splice(0, 5);
          this.hottestData = _.map(hotData, "utilization");
          this.hottestLabels = _.map(hotData, "name");

          _.each(coldestEquipment, row => {
            data2.push({
              equipment_id: row.equipment_id,
              name: _.find(equipmentInfo, { id: row.equipment_id }).name,
              utilization: row.utilization
            });
          });
          data2.sort((s1, s2) => s2.utilization - s1.utilization);

          const coldData = data2.reverse().splice(0, 5);

          // We'll make another sort because coldest equipment should be listed in descending order
          coldData.sort((s1, s2) => s2.utilization - s1.utilization);

          this.coldestData = _.map(coldData, "utilization");
          this.coldestLabels = _.map(coldData, "name");

          this.loaded = true;
          this.loading = false;
        });

        return true;
      },

      fetchEquipmentUtilizationByTime() {
        this.avgChartDataLoading = true;

        let groupBy;
        const currentStartDate = moment(FilterStore.activeFilters.startDate);
        const currentEndDate = moment(FilterStore.activeFilters.endDate);

        const lengthDays = currentEndDate.diff(currentStartDate, "days");

        if(lengthDays <= 7) {
          groupBy = 'hour';
        } else if(lengthDays <= 180) { // about 6 months
          groupBy = 'day';
        } else {
          groupBy = 'week';
        }

        this.avgGroupBy = groupBy;

        let params = this.buildParams("timeRound", groupBy, true);

        return api.get(`/utilization?${params}`).then(response => {
          this.equipmentDataByTime = response.data;

          this.avgChartData = _.map(response.data, "utilization");
          this.avgChartLabels = _.map(response.data, "timeRound");

          this.avgChartDataLoading = false;
        });
      },
      getTimePartLabel(item, groupBy) {
        let labels = [];

        if (groupBy === "dow") {
          labels = [
            "Maanantai",
            "Tiistai",
            "Keskiviikko",
            "Torstai",
            "Perjantai",
            "Lauantai",
            "Sunnuntai"
          ];
          return labels[item];
        } else if (groupBy === "month") {
          return this.capitalizeFirstLetter(moment(item).format('MMMM'));
        } else if (groupBy === "week") {
          return "Viikko " + moment(item).isoWeek();
        } else if (groupBy === "quarter") {
          return "Q " + item;
        }
        return item;
      },
      fetchCompareEquipmentUtilization() {
        if (toJS(this.equipments).length === 0) {
          return false;
        }

        let params = this.buildCompareParams("equipment_id");

        api.get(`/utilization?${params}`).then(response => {
          this.compareEquipmentData = response.data;

          this.compareLoaded = true;
          this.compareLoading = false;
        });

        return true;
      },
      fetchCategoryUtilization() {
        if (toJS(this.categories).length === 0) {
          return false;
        }

        let params = this.buildParams("category_id");

        api.get(`/utilization?${params}`).then(response => {
          const categoryInfo = toJS(this.categories);

          let responseData = response.data;
          responseData.sort((s1, s2) => s2.utilization - s1.utilization);

          if (responseData.length > 9) {
            responseData = responseData.splice(0, 9);
          }

          this.categoryChartData = _.map(responseData, "utilization");
          this.categoryChartLabels = _.map(
            responseData,
            "equipment_category_id"
          );

          this.categoryChartLabels = _.map(this.categoryChartLabels, cat_id => {
            return _.head(_.filter(categoryInfo, { id: cat_id })).name;
          });

          this.loadedCategories = true;
          this.loadingCategories = false;
        });

        return true;
      },
      fetchBrandUtilization() {
        if (toJS(this.brands).length === 0) {
          return false;
        }

        let params = this.buildParams("brand_id");

        api.get(`/utilization?${params}`).then(response => {
          const brandInfo = toJS(this.brands);

          let responseData = response.data;
          responseData.sort((s1, s2) => s2.utilization - s1.utilization);

          if (responseData.length > 9) {
            responseData = responseData.splice(0, 9);
          }

          this.brandChartData = _.map(responseData, "utilization");
          this.brandChartLabels = _.map(responseData, "brand_id");

          this.brandChartLabels = _.map(this.brandChartLabels, brand_id => {
            return _.head(_.filter(brandInfo, { id: brand_id })).name;
          });

          this.loadedBrands = true;
          this.loadingBrands = false;
        });

        return true;
      }
    });
  }

  capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }
// let params = this.buildParams("timeRound", groupBy, true);
  buildParams(groupBy, timePart, useTimeRound=false) {
    const params = {
      startDatetime: FilterStore.activeFilters.startDate.format(
        "YYYY-MM-DD 00:00:00"
      ),
      endDatetime: FilterStore.activeFilters.endDate.format(
        "YYYY-MM-DD 23:59:59"
      ),
      metric: "utilization",
      groupBy
    };

    if(timePart !== undefined && useTimeRound === true) {
      params.timeRound = timePart;
      params.groupBy = 'timeRound';
    } else if (timePart !== undefined) {
      params.timePart = timePart;
      params.groupBy = 'timePart';
    }

    return Object.keys(params)
      .map(key => `${key}=${params[key]}`)
      .join("&");
  }

  buildCompareParams(groupBy) {
    const currentStartDate = moment(FilterStore.activeFilters.startDate);
    const currentEndDate = moment(FilterStore.activeFilters.endDate);

    const length = currentEndDate.diff(currentStartDate, "days");

    const params = {
      startDatetime: _.clone(
        currentStartDate
          .subtract(length + 1, "days")
          .format("YYYY-MM-DD 00:00:00")
      ),
      endDatetime: _.clone(
        currentEndDate
          .subtract(length + 1, "days")
          .format("YYYY-MM-DD 23:59:59")
      ),
      metric: "utilization",
      groupBy
    };

    return Object.keys(params)
      .map(key => `${key}=${params[key]}`)
      .join("&");
  }
}

const store = new HomeStore();

export default store;
