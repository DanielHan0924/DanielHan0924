import { extendObservable, action } from "mobx";

class ButtonGroupStore {
  constructor() {
    extendObservable(this, {
      focusedInput: null,
      activeFilters: {},
      selectedItem: {
        days: 'all',
        hours: 'all',
        daysCompare: 'all',
        hoursCompare: 'all'
      },
      filterValues: {},
      toggleItem: action((value, type) => {
        this.selectedItem[type] = value;
      })
    });
  }
}

const store = new ButtonGroupStore();

export default store;
