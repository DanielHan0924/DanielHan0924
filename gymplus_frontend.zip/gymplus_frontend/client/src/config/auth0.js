const url = window.location.href;
const urlParts = url.split("/");

export default {
  domain: "indoorinformatics.eu.auth0.com",
  clientId: "bIYHnIJzqlaFOAk2gqocdyzxQK9vzmMF",
  callbackUrl: urlParts[0] + "//" + urlParts[2] + "/callback"
};
