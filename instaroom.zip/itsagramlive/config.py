import pymysql

mydb = mysql.connector.connect(host='107.180.57.91',user='i7309859_wp2',password='asdasdasd',db='i7309859_wp2')

myCursor = mydb.cursor()

myCursor.execute("show databases")



