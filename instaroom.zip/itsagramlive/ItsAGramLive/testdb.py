import mysql.connector as mysql

db = mysql.connect(
    host = "localhost",
    user = "root",
    passwd = "",
    database = "instaroom"
)
print(type(db))
cursor = db.cursor()
print(type(cursor))

# cursor.execute("TRUNCATE TABLE streaminfo")
query = "INSERT INTO streaminfo (username, broadcastID, streamurl, streamkey) VALUES (%s, %s, %s, %s)"
values = ('self.username', 'self.broadcast_id', 'self.stream_server', 'self.stream_key')
cursor.execute(query, values)
db.commit()