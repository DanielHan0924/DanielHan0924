=====
Proxy: zproxy.lum-superproxy.io
Port: 22225
User: lum-customer-c_1df55f5f-zone-instagram
lum-customer-c_1df55f5f-zone-instagram-ip-45.91.89.194
Password: hfri6cw9oubj
username: johndoe.se
password: liveinstagram2
https://instafeed.me/rtmp/

====
Proxy: zproxy.lum-superproxy.io
Port: 22225
User: lum-customer-c_1df55f5f-zone-instagram
Password: hfri6cw9oubj
====
janedoe.se
liveinstagram
====
Proxy: zproxy.lum-superproxy.io
Port: 22225
User: lum-customer-c_1df55f5f-zone-instaresidential
Password: a6cfy7e744sl
=====
python live_broadcast.py -u cedfidus -p Findus789*** -proxy lum-customer-c_1df55f5f-zone-instaresidential:a6cfy7e744sl@zproxy.lum-superproxy.io:22225
python live_broadcast.py -u tedy -p rest -proxy lum-customer-c_1df55f5f-zone-instaresidential:a6cfy7e744sl@zproxy.lum-superproxy.io:22225

======
*JOHN*

Gmail
sportselitesmagazinelive1@gmail.com
liveinstagram


Insta
johndoe.se
liveinstagram
--

*JANE*

Gmail
sportselitesmagazinelive2@gmail.com
liveinstagram

Insta
janedoe.se
liveinstagram

---real account
cedfidus
Findus789***