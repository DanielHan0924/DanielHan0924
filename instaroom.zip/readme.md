https://www.figma.com/file/PUqTXNOlBgjJZpSqhCwvUR/Stream-Instagram?node-id=6%3A105
=====
Proxy: zproxy.lum-superproxy.io
Port: 22225
User: lum-customer-c_1df55f5f-zone-instagram
lum-customer-c_1df55f5f-zone-instagram-ip-45.91.89.194
Password: hfri6cw9oubj
username: johndoe.se
password: liveinstagram2
https://instafeed.me/rtmp/

====
Proxy: zproxy.lum-superproxy.io
Port: 22225
User: lum-customer-c_1df55f5f-zone-instagram
Password: hfri6cw9oubj
====
janedoe.se
liveinstagram
====
Proxy: zproxy.lum-superproxy.io
Port: 22225
User: lum-customer-c_1df55f5f-zone-instaresidential
Password: a6cfy7e744sl
=====
python live_broadcast.py -u cedfidus -p Findus789*** -proxy lum-customer-c_1df55f5f-zone-instaresidential:a6cfy7e744sl@zproxy.lum-superproxy.io:22225
python live_broadcast.py -u tedy -p rest -proxy lum-customer-c_1df55f5f-zone-instaresidential:a6cfy7e744sl@zproxy.lum-superproxy.io:22225
python live_broadcast.py -u isma_sports_elites_magazine -p Unforgivable1 -proxy lum-customer-c_1df55f5f-zone-instaresidential:a6cfy7e744sl@zproxy.lum-superproxy.io:22225

sam_sports_elites_magazine
isomerco

isma_sports_elites_magazine
Unforgivable1
======
*JOHN*

Gmail
sportselitesmagazinelive1@gmail.com
liveinstagram


Insta
johndoe.se
liveinstagram
--

*JANE*

Gmail
sportselitesmagazinelive2@gmail.com
liveinstagram

Insta
janedoe.se
liveinstagram

---real account
cedfidus
Findus789***

===
htpasswd.exe -c -B -b .htpasswd cedfidus Findus789***

AuthType Basic
AuthName "Member's Area Name"
AuthUserFile .htpasswd
Require valid-user