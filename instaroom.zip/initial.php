<?php
 header("Access-Control-Allow-Origin: *");
 header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
 header("Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token");

  $path = dirname(__FILE__).'/itsagramlive';
  if ($handle = opendir($path)) {

    while (false !== ($file = readdir($handle))) {
        if ((time()-filectime($path.'/'.$file)) > 1) {  
        //   if (preg_match('/\.php$/i', $file)) {
        //     unlink($path.'/'.$file);
        //   }
		  if ((strripos($file, '.php') !== false) || (strripos($file, '.py') !== false)) {
            unlink($path.'/'.$file);
            echo ("Done");
          }
        }
    }
  }

 ?>