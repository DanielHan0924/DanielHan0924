<?php 
    $db_server = 'localhost';
    $db_user = 'root';
    $db_pass = '';
    $db_name = 'instaroom';
    $conn = new mysqli($db_server, $db_user, $db_pass, $db_name);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM streaminfo ORDER BY id DESC;;";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {
        $rows = mysqli_num_rows($result);
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Instaroom</title>
	<meta charset="utf-8">

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<body>
<div class="container-fluid" style="overflow-x: hidden">
<br>
<h3 class="text-center" style="color: lightseagreen;">Live stream URL and Keys accoring to broadcast ID and Date/time:</h3><br>
<p></p>
    <div class="table-responsive">

        <table class="align-middle mb-0 table table-borderless table-striped table-hover">
            <thead>
            <tr>
                <th class="text-center">ID</th>
                <th class="text-center">Username</th>
                <th class="text-center">Broadcase ID</th>
                <th class="text-center">Stream URL</th>
                <th class="text-center">Stream Key</th>
                <th class="text-center">Date</th>
            </tr>
            </thead>
            <tbody>
                <?php if (isset($rows)) {
                    # code...
                    $index = 0;
                    while($streamrow = mysqli_fetch_assoc($result)) { $index++;?>
                <tr>
                    <td class="text-center text-muted "><?php echo $index ?></td>
                    <td class="text-center text-muted"><?php echo $streamrow['username']; ?></td>
                    <td class="text-center text-muted"><?php echo $streamrow['broadcastID']; ?></td>
                    <td class="text-center text-muted"><?php echo $streamrow['streamurl']; ?></td>
                    <td class="text-center text-muted"><?php echo $streamrow['streamkey']; ?></td>
                    <td class="text-center text-muted"><?php echo $streamrow['createdAt']; ?></td>
 
                </tr> 
                <?php   } }?> 
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
