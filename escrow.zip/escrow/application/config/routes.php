<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/

$route['default_controller'] = "home";
$route['404_override'] = 'home/error_404';
$route['translate_uri_dashes'] = FALSE;

/*********** WEBSITE ROUTES ************************/
$route['faqs'] = "home/faqs";
$route['terms'] = "home/terms";
$route['privacy'] = "home/privacy";
$route['contactus'] = "home/contact_us";
$route['news'] = "home/news";

$route['news/(:num)'] = 'home/news/$1';
/************* AUTH ROUTES *************/
$route['signup'] = 'auth/signup';
$route['signup/(:any)'] = 'auth/signup/$1';
$route['login'] = 'auth/loginMe';
$route['forgotPassword'] = "auth/forgotPassword";
$route['resetPasswordUser'] = "auth/resetPasswordUser";
$route['resetPassword'] = "auth/resetPasswordConfirmUser";
$route['resetPassword/(:any)'] = "auth/resetPasswordConfirmUser/$1";
$route['resetPassword/(:any)/(:any)'] = "auth/resetPasswordConfirmUser/$1/$2";
$route['createPasswordUser'] = "auth/createPasswordUser";

/*********** SETTINGS ROUTES *******************/
$route['settings'] = 'settings/settings';
$route['settings/companyInfo'] = 'settings/companyInfoUpdate';
$route['settings/emailInfo'] = 'settings/emailInfoUpdate';
$route['settings/email_templates'] = 'settings/email_templates';
$route['settings/edit_email'] = 'settings/editEmailTemplate';
$route['emailTemplate'] = "Settings/email_template"; 
$route['paymentAPIInfo'] = "settings/addons_info";
$route['paymentmethodInfo'] = "settings/paymentmethodInfo";
$route['settings/referral'] = "Settings/referralEdit"; 
$route['settings/addonAPIUpdate'] = "settings/addons_update";
$route['settings/paymentMethodUpdate'] = "settings/paymentMethodEdit";
$route['settings/seo'] = "Settings/SEO_Update"; 
$route['settings/news'] = "settings/newsindex";
$route['settings/news/new'] = "settings/newsAdd";
$route['settings/news/edit/(:any)'] = "settings/newsEdit/$1";
$route['settings/news/delete/(:any)'] = "settings/newsDelete/$1";
$route['settings/news/status/(:any)'] = "settings/newsStatus/$1";
/*********** USER DEFINED ROUTES *******************/
$route['dashboard'] = 'user';
$route['invite'] = 'referrals/invite';
$route['logout'] = 'user/logout';

$route['addNew'] = "user/addNew";
$route['addNewUser'] = "user/addNewUser";
$route['editOld'] = "user/editOld";
$route['editOld/(:num)'] = "user/editOld/$1";
$route['editUser'] = "user/editUser";
$route['deleteUser'] = "user/deleteUser";
$route['profile'] = "user/profile";
$route['profile/(:any)'] = "user/profile/$1";
$route['profileUpdate'] = "user/profileUpdate";
$route['profileUpdate/(:any)'] = "user/profileUpdate/$1";
$route['paymentInfo'] = "user/paymentAccountUpdate";

$route['loadChangePass'] = "user/loadChangePass";
$route['changePassword'] = "user/changePassword";
$route['changePassword/(:any)'] = "user/changePassword/$1";
$route['pageNotFound'] = "user/pageNotFound";
$route['checkEmailExists'] = "user/checkEmailExists";
$route['login-history'] = "user/loginHistoy";
$route['login-history/(:num)'] = "user/loginHistoy/$1";
$route['login-history/(:num)/(:num)'] = "user/loginHistoy/$1/$2";


/************ Referral **************/
$route['referrals'] = 'referrals/referrals';
$route['downline1/(:num)'] = 'referrals/downline1/$1';
$route['downline2/(:num)'] = 'referrals/downline2/$1';
$route['downline3/(:num)'] = 'referrals/downline3/$1';
$route['downline4/(:num)'] = 'referrals/downline4/$1';
$route['treeview/(:num)'] = 'referrals/treeview/$1';
$route['getItem'] = "referrals/getItem";

/*********** TEAM ROUTES *******************/
$route['team'] = 'user/team';
$route['team/(:num)'] = "user/team/$1";
$route['team/newManager'] = "user/addNewManager";
$route['team/editManager/(:num)'] = "user/editManager/$1";

/*********** CLIENTS ROUTES *******************/
$route['clients'] = 'user/clients';
$route['clients/newClient'] = "user/addNewClient";
$route['clients/viewClient/(:num)'] = "user/viewClient/$1";
$route['clients/(:num)'] = "user/clients/$1";
$route['clients/editClient/(:num)'] = "user/editClient/$1";

/*********** PLANS ROUTES *******************/
//$route['plans'] = 'plans/inPlans';
//$route['plans/(:num)'] = "plans/inPlans/$1";
//$route['plans/new'] = "plans/addNewPlan";
//$route['plans/edit/(:num)'] = "plans/editPlan/$1";
//$route['plans/delete/(:num)'] = "plans/deletePlan/$1";

/*********** TIER ROUTES *******************/
$route['incentive'] = 'tiers';
$route['incentive/showtier/(:any)'] = 'tiers/showOtherTier/$1';
$route['tiers'] = 'tiers/list';
$route['tiers/(:num)'] = "tiers/list/$1";
$route['tiers/new'] = "tiers/new";
$route['tiers/edit/(:num)'] = "tiers/edit/$1";
$route['tiers/delete/(:num)'] = "tiers/delete/$1";
$route['membercounttest']="tiers/memberTestCount";
/*********** DEPOSITS ROUTES *******************/
//removed for test
// $route['deposits'] = 'transactions/deposits';
$route['deposits/(:num)'] = "transactions/deposits/$1";
$route['deposits/new'] = "transactions/newDeposit";
$route['deposits/payment'] = "transactions/paymentPage";
$route['bitcoinPayment'] = "transactions/bitcoinDeposit";
$route['deposits/editTrans/(:num)'] = "transactions/editDeposit/$1";
$route['deposits/deleteTrans/(:num)'] = "transactions/deleteDeposit/$1";

/*********** WITHDRAWAL ROUTES *******************/
//$route['withdrawals'] = 'transactions/withdrawals';
//$route['withdrawals/(:num)'] = 'transactions/withdrawals/$1';
$route["withdrawDeposit"] = "transactions/withdrawDeposit";
$route["reinvest"] = "transactions/reInvest";
$route['approveWithdrawal/(:num)'] = "transactions/approveWithdrawal/$1";
$route['history'] = "transactions/history";
$route['history/(:any)'] = 'transactions/history/$1';
/*********** PAYMENTS ROUTES *******************/
$route['earnings'] = 'transactions/earnings';
$route['earnings/(:num)'] = 'transactions/earnings/$1';
$route['stripe-payment'] = "Stripe";
$route['paypal-payment'] = "Paypal/index";
$route['coin-payment'] = "Coinpayments";
$route['bank-transfer'] = "transactions/bankTransfer";
$route['paypal/callback'] = "Paypal/callback";
$route['stripePost']['post'] = "Stripe/stripePost";
$route['stripepaymentsuccess'] = "Stripe/success";
$route['ipncp/(:any)'] = "Coinpayments/IPN_Response/$1";
$route['checkpayment/(:any)'] = "Coinpayments/checkCoinPayments/$1";
$route['coinpayment'] = "transactions/coinpayments";
$route['coinpayment/status/(:any)'] = "transactions/coinpaymentUpdate/$1";

$route['paypal/success'] = "Paypal/success";
$route['paypal/canceled'] = "Paypal/canceled";

/************ WALLET ROUTES **************/
$route['wallet/test_deposit_amount'] = 'wallet/testdeposit';
$route['test-coin-payment'] = "Coinpaymen";

$route['addfunds'] = 'wallet/deposit';
$route['wallets/deposit_amount'] = 'wallet/deposit';
$route['wallet/transactions'] = 'wallet/transactions';
$route['wallets/transactions/(:any)'] = 'wallet/transactions/$1';
$route['wallets/deposits'] = 'wallet/deposits';
$route['wallets/deposits/(:any)'] = 'wallet/deposits/$1';
$route['wallets/view'] = 'wallet/user_wallets';
$route['wallets/view/(:num)'] = 'wallet/user_wallets/$1';
$route['wallets/edit/(:num)'] = 'wallet/editWallet/$1';
$route['updateWallet/(:num)'] = 'wallet/updateWallet/$1';
$route['approveTransaction/(:any)/(:any)'] = 'wallet/approveTransaction/$1/$2';
$route['paymentDepoInfo/(:any)'] = 'settings/paymentmethodNote/$1';
$route['withdrawals/new'] = "wallet/newWithdrawal";
$route['withdrawalfees/(:num)'] = "wallet/withdrawalfees/$1";
$route['wallets/withdrawals'] = "wallet/withdrawals";
$route['withdrawals'] = 'wallet/withdrawals';
$route['withdrawals/(:num)'] = 'wallet/withdrawals/$1';

/********** CRON JOBS ROUTES *********************/
$route['emailcronjob'] = 'home/earningsEmails';
$route['walletearnings'] = 'home/earnings';
/* End of file routes.php */
/* Location: ./application/config/routes.php */
