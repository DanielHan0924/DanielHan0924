<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Transactions_model (Transactions Model)
 * User model class to get to handle user related data 
 * @author : Irina
 * @version : 1.0
 * @since : 07 July 2020
 */
class Referral_model extends CI_Model
{
    public $memberCount = 1;
    function referrals($userId)
    {
        $this->db->select('BaseTbl.id, BaseTbl.referrerId, User.firstName,User.email, BaseTbl.referredId, BaseTbl.createdDtm');
        $this->db->from('tbl_referrals  as BaseTbl');
        $this->db->join('tbl_users as User', 'User.userId = BaseTbl.referredId');
        $this->db->where('BaseTbl.referrerId =', $userId);
        $this->db->order_by('createdDtm', 'DESC');
        $query = $this->db->get();
        //$result = $query->result();        
        return $query->result();
    }
    function upline($userId){
        $this->db->select('BaseTbl.id, BaseTbl.referrerId, User.firstName,User.email, BaseTbl.referredId, BaseTbl.createdDtm');
        $this->db->from('tbl_referrals  as BaseTbl');
        $this->db->join('tbl_users as User', 'User.userId = BaseTbl.referrerId');
        $this->db->where('BaseTbl.referredId =', $userId);
        $this->db->order_by('createdDtm', 'DESC');
        $query = $this->db->get();      
        return $query->result();
    }
    function downlineOne($userId)
    {
        $this->db->select('BaseTbl2.id, BaseTbl.referrerId, User.firstName,User.email, BaseTbl.referredId, BaseTbl.createdDtm');
        $this->db->from('tbl_referrals  as BaseTbl');
        $this->db->join('tbl_referrals  as BaseTbl2','BaseTbl2.referrerId = BaseTbl.id');
        $this->db->join('tbl_users as User', 'User.userId = BaseTbl2.referredId');
        $this->db->where('BaseTbl.referrerId =', $userId);
        $this->db->order_by('createdDtm', 'DESC');
        $query = $this->db->get();       
        return $query->result(); 
        
    }
     /* func to get downline 2th referrals in the network
    * @param = userid
    * by Anita G
    */
    function downlineTwo($userId)
    {
        $this->db->select('BaseTbl3.id, BaseTbl3.referrerId, User.firstName,User.email, BaseTbl.createdDtm');
        $this->db->from('tbl_referrals  as BaseTbl');
        $this->db->join('tbl_referrals  as BaseTbl2','BaseTbl2.referrerId = BaseTbl.id');
        $this->db->join('tbl_referrals  as BaseTbl3','BaseTbl3.referrerId = BaseTbl2.id');
        $this->db->join('tbl_users as User', 'User.userId = BaseTbl3.referredId');
        $this->db->where('BaseTbl.referrerId =', $userId);
        $this->db->order_by('createdDtm', 'DESC');
        $query = $this->db->get();       
        return $query->result(); 
        
    }
     /* func to get downline 3th referrals in the network
    * @param = userid
    * by Anita G
    */
    function downlineThree($userId)
    {
        $this->db->select('BaseTbl3.id, BaseTbl3.referrerId, User.firstName,User.email, BaseTbl.createdDtm');
        $this->db->from('tbl_referrals  as BaseTbl');
        $this->db->join('tbl_referrals  as BaseTbl2','BaseTbl2.referrerId = BaseTbl.id');
        $this->db->join('tbl_referrals  as BaseTbl3','BaseTbl3.referrerId = BaseTbl2.id');
        $this->db->join('tbl_referrals  as BaseTbl4','BaseTbl4.referrerId = BaseTbl3.id');
        $this->db->join('tbl_users as User', 'User.userId = BaseTbl4.referredId');
        $this->db->where('BaseTbl.referrerId =', $userId);
        $this->db->order_by('createdDtm', 'DESC');
        $query = $this->db->get();       
        return $query->result();    
    }
    /* func to get downline 4th referrals in the network
    * @param = userid
    * by Anita G
    */
    function downlineFour($userId)
    {
        $this->db->select('BaseTbl4.id, BaseTbl4.referrerId, User.firstName,User.email, BaseTbl.createdDtm');
        $this->db->from('tbl_referrals  as BaseTbl');
        $this->db->join('tbl_referrals  as BaseTbl2','BaseTbl2.referrerId = BaseTbl.id');
        $this->db->join('tbl_referrals  as BaseTbl3','BaseTbl3.referrerId = BaseTbl2.id');
        $this->db->join('tbl_referrals  as BaseTbl4','BaseTbl4.referrerId = BaseTbl3.id');
        $this->db->join('tbl_referrals  as BaseTbl5','BaseTbl5.referrerId = BaseTbl4.id');
        $this->db->join('tbl_users as User', 'User.userId = BaseTbl4.referredId');
        $this->db->where('BaseTbl.referrerId =', $userId);
        $this->db->order_by('createdDtm', 'DESC');
        $query = $this->db->get();       
        return $query->result();      
    }

    function referral_count($userId)
    {
        $this->db->select('*');
        $this->db->from('tbl_referrals');
        $this->db->where('referrerId =', $userId);
        $query = $this->db->get();
        // return $query->result();
        return $query->num_rows();
    }
function getNode($userId){
        $this->db->select('userId,firstName');
        $this->db->from('tbl_users');
        $this->db->where('userId =', $userId);
        
        $query = $this->db->get();      
        return $query->result();
    }
    /* func to get all members in the network
    * condition = must have deposit $100
    * by Anita G
    */
    function getMembersCount($parent){
        try{
            $member_target_aum = $this->tiers_model->getTierByName('Member')->group_capital_target;
            $row = $this->db->query('SELECT tbl4.* from ( select tb2.referredId,SUM(tb1.amount) as deposit,tb1.type from tbl_wallet_transactions as tb1 JOIN ( SELECT id, referrerId,referredId from tbl_referrals WHERE referrerId="'.$parent.'" ) tb2 on tb2.referredId=tb1.txnUserId WHERE tb1.type="deposit" GROUP BY tb2.referredId ) tbl4 where deposit>="'.$member_target_aum.'"')->result_array();
            foreach($row as $key => $value)
            {
                //echo $value[referredId].'->'.'referrer-'.$value['deposit'].'<br>';
                $nextlink = $this->getMembersCount($value['referredId']);
                $this->memberCount++;
            } 
           return $this->memberCount;
        } catch (\Exception $e)
        {
            return $this->memberCount;
        } 
    }
   
}


