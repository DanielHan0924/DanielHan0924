<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Tiers_model (Tiers Model)
 * User model class to get to handle user related data 
 * @author : Irina
 * @version : 1.0
 * @since : 07 July 2020
 */
class Tiers_model extends CI_Model
{
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function tierListingCount($searchText = '')
    {
        $this->db->select('*');
        $this->db->from('tbl_tiers');
        if(!empty($searchText)) {
            $this->db->like('name', $this->db->escape_like_str($searchText));
        }
        $query = $this->db->get();
        
        return $query->num_rows();
    }

    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function getTierById($tierId)
    {
        $this->db->select('*');
        $this->db->from('tbl_tiers');
        $this->db->where('id =', $tierId);
        $query = $this->db->get();
        
        return $query->row();
    }
    function getTierByName($tierName)
    {
        $this->db->select('*');
        $this->db->from('tbl_tiers');
        $this->db->where('name', $tierName);
        $query = $this->db->get();
        
        return $query->row();
    }

    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function getAllTiers($searchText = '', $page, $segment)
    {
        $this->db->select('*');
        $this->db->from('tbl_tiers as BaseTbl');
        if(!empty($searchText)) {
            $this->db->like('name', $this->db->escape_like_str($searchText));
        }
        $this->db->order_by('createdDtm', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new user to system
     * @return number $insert_id : This is last inserted id
     */
    function add($data)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_tiers', $data);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function edit($data, $key)
    {
        $this->db->trans_start();
        $this->db->where('id', $key);
        $this->db->update('tbl_tiers', $data);
        $this->db->trans_complete();

        if ($this->db->trans_status() === FALSE)
        {
            return FALSE;
        } else {
            return TRUE;
        }
    }

    /**
     * This function used to get user information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getTierInfo($key)
    {
        $this->db->select('*');
        $this->db->from('tbl_tiers');
        $this->db->where('id', $key);
        $query = $this->db->get();
        
        return $query->row();
    }

    /**
     * This function is used to delete the user information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function delete($key)
    {
        $this->db->where('id', $key);
        $this->db->delete('tbl_tiers');
        
        return $this->db->affected_rows();
    }
    /**
     * This function is used to get tier information based on level
     * @param number $level : This is tier lever
     * @return boolean $result : tier
     */
    function getTierByLevel($level)
    {
        $this->db->select('*');
        $this->db->from('tbl_tiers');
        $this->db->where('tier_levels =', $level);
        $query = $this->db->get();
        return $query->row();
    }

}