<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : News_model (News Model)
 * User model class to get to handle user related data 
 * @author : Irina
 * @version : 1.0
 * @since : 07 July 2020
 */
class News_model extends CI_Model
{
    /**
     * This function used to get news 
     * 
     * @return array $result :news
     */
    function getNews($searchText = '', $page, $segment)
    {
        $this->db->select('*');
        $this->db->from('tbl_news as BaseTbl');
        $this->db->where('status','1' );
        $this->db->order_by('BaseTbl.createdAt', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
    }
    function getNewsAll()
    {
        $this->db->select('*');
        $this->db->from('tbl_news as BaseTbl');
        $this->db->order_by('BaseTbl.createdAt', 'DESC');
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
    }
    function getNewsCount()
    {
        $this->db->select('*');
        $this->db->from('tbl_news as BaseTbl');
        $this->db->order_by('BaseTbl.createdAt', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
       return $query->num_rows();        
    ;
    }
      /**
     * This function used to get news information by id
     * @param number $newsId : This is user id
     * @return array $result : This is user information
     */
    function getNewsInfoById($newsId)
    {
        $this->db->select('*');
        $this->db->from('tbl_news');
        $this->db->where('id',$newsId );
        $query = $this->db->get();
        return $query->row();
    }
   
    /**
     * This function is used to update the news 
     * @param array $newsArray : This is news updated information
     * @param number $userId : This is news id
     */
    function edit($data, $key)
    {
            
        $this->db->trans_start();
        $this->db->where('id', $key);
        $this->db->update('tbl_news', $data);
        $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE)
        {
            return FALSE;
        } else {
            return TRUE;
        }
    }
    function delete($key)
    {
        $this->db->where('id', $key);
        $this->db->delete('tbl_news');
        return $this->db->affected_rows();
    }
    /**
     * This function is used to add news  to system
     * @return number $insert_id : This is last inserted id
     */
    function add($data)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_news', $data);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return $insert_id;
    }
     /**
     * This function is used to update  news status to 
     * @return number $insert_id : This is last inserted id
     */
    function updateNews($key,$status)
    {
        $data = array(  
            'status'=>$status
        );
        $this->db->trans_start();
        $this->db->where('id', $key);
        $this->db->update('tbl_news', $data);
        $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE)
        {
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
}