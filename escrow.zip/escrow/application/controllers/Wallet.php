<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Home (HomeController)
 * Home class to display the main site
 * @author : Irina
 * @version : 1.0
 * @since : 07 July 2020
 */
class wallet extends BaseController {

	public function __construct()
    {
        parent::__construct();
		$this->load->model('settings_model');
        $this->load->model('transactions_model');
        $this->load->model('wallet_model');
        $this->load->model('user_model');
		$this->load->model('email_model');
        $this->load->model('twilio_model');
        $this->load->model('payments_model');
        $this->load->model('login_model');
        $this->isLoggedIn(); 
    }

    public function deposit()
    {
        $companyInfo = $this->settings_model->getsettingsInfo();
        $data["companyInfo"] = $companyInfo ;
        $this->global['pageTitle'] = 'Wallet Deposit';
        $this->global['displayBreadcrumbs'] = true; 
        $this->global['breadcrumbs'] = 'Wallet'.' <span class="breadcrumb-arrow-right"></span> '.'Add Money';
        $data['breadcrumbs'] = "Wallet / Add Money";
        $this->load->helper('string');
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        if ($this->role == ROLE_CLIENT) 
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('amount','Amount','required');
            $this->form_validation->set_rules('payMethod','Payment Method','required');

            if($this->form_validation->run() == FALSE)
            {
                $this->session->set_flashdata('errors', validation_errors());
            }
            else
            {
                $amount = $this->input->post('amount', TRUE);
                $method = $this->input->post('payMethod', TRUE);
                $txnId = 'WD'.random_string('alnum',8);

                if($method == 'ST') 
                {
                    $paymentData = array(
                        'DepositAmount'  => $amount,
                    );
                
                    $this->session->set_userdata($paymentData);
                    // 'item' will be erased after 300 seconds
                    $this->session->mark_as_temp(array('DepositAmount'), 300);

                    redirect('/stripe-payment');
                }
                else if($method == 'PP')
                {
                    $methodData = $this->payments_model->getInfo('tbl_addons_api', 'paypal');
                    $cc_amount = $companyInfo['currency'] == 'USD' ? $amount : $amount/$companyInfo['currency_exchange_rate'];
                    $config = [
                        "clientID"=> $methodData->public_key,
                        "currency"=>"USD", //default is USD
                        "intent"=>"sale", //default is sale
                        "mode"=>$methodData->env,
                        "invoiceNumber"=>$code,
                        "clientSecret"=> $methodData->secret_key,
                        "redirectUrl"=> base_url('paypal/success'),//controller method paypal will return here after success
                        "cancelUrl"=>base_url('paypal/canceled')//localhost/paypal-integration-ci/index.php/welcome/payment/canceled"//controller method paypal will return here after cancel
                    ];
                    $this->load->library('paypal',$config);
                    $result = $this->paypal->pay($cc_amount);
                    $deposit_array = array(
                        'userid'=>$this->vendorId,
                        'invoice'=>$txnId,
                        'txn_id'=>$result["payment"]->id,
                        'local_currency'=>$amount,
                        'payment_gross'=>$cc_amount,
                        'currency_code'=>'USD',
                        'payer_email'=>'NA',
                        'payment_status'=>'0',
                        'createdDtm'=>date('Y-m-d H:i:s')

                    );
                    $this->payments_model->addPaypal($deposit_array);
                    if($result["error"] == '') { 
                        redirect($result["approval_url"]);
                    } else { 
                        $this->session->set_flashdata('error', 'There is an error depositing via Paypal');
                        redirect('/deposits/new');
                    }
                }
            }
            
            $accountBalance = abs($walletBalance - $pendingWithdrawals);
            $data['walletBalance'] = $accountBalance;
            $this->loadViews("wallets/deposit", $this->global, $data);
        } else {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('email', 'Email', 'required');
            $this->form_validation->set_rules('amount','Amount','trim|required|max_length[128]');
            if($this->form_validation->run() == FALSE)
            {
                $this->session->set_flashdata('errors', validation_errors());
            }
            else
            {
                $email = $this->input->post('email', TRUE);
                $amount = $this->input->post('amount', TRUE);
                $method = 'Manual';
                $txnId = 'WD'.random_string('alnum',8);

                //Check if email exists for client
                $emailCheck = $this->login_model->checkClientExist($email, '3');

                if($emailCheck)
                {
                    $depositArray = array(
                        'txnUserId'=>$emailCheck->userId,
                        'type'=>'deposit',
                        'txn_id'=>$txnId,
                        'amount'=>$amount,
                        'method'=>$method,
                        'status'=>1
                    );

                    $balance = $this->wallet_model->getWalletBalance($emailCheck->userId)->balance;
                    $newBalance = $balance + $amount;

                    $result = $this->wallet_model->adminAddDeposit($depositArray, $emailCheck->userId, $newBalance);

                    if($result > 0)
                    {
                        //Send Mail
                        $conditionUserMail = array('tbl_email_templates.type'=>'Notify Admin');
                        $resultEmail = $this->email_model->getEmailSettings($conditionUserMail);

                        $companyInfo = $this->settings_model->getsettingsInfo();
                        $userInfo = $this->user_model->getUserInfo($emailCheck->userId);
                    
                        if($resultEmail->num_rows() > 0)
                        {
                            $rowUserMailContent = $resultEmail->row();
                            $splVars = array(
                                "!name" => $userInfo->firstName.' '.$userInfo->lastName,
                                "!email" => $userInfo->email,
                                "!type"=> $method,
                                "!amount"=> to_currency($amount),
                                "!companyName" => $companyInfo['name'],
                                "!address" => $companyInfo['address'],
                                "!siteurl" => base_url()
                            );

                            $mailSubject = strtr($rowUserMailContent->mail_subject, $splVars);
                            $mailContent = strtr($rowUserMailContent->mail_body, $splVars); 	

                            $toEmail = $companyInfo['email'];
                            $fromEmail = $companyInfo['SMTPUser'];

                            $name = 'Support';

                            $header = "From: ". $name . " <" . $fromEmail . ">\r\n"; //optional headerfields

                            $send = $this->email_model->sendHtmlMail($toEmail,$fromEmail,$mailSubject,$mailContent,NULL);

                        }
                        $this->session->set_flashdata('error', 'Deposit has been created succesfully.');
                        redirect('/wallets/deposit_amount');
                    } else
                    {
                        $this->session->set_flashdata('error', 'There is an error making a deposit');
                        redirect('/wallets/deposit_amount');
                    }

                } else{
                    $this->session->set_flashdata('error', 'This email does not exist');
                }
            }
            $this->loadViews("wallets/deposit", $this->global, $data);
        }
    }
    function newWithdrawal()
    {
        //$data["plans"] = $this->plans_model->getPlans();
        $this->global['pageTitle'] = 'New Withdrawal';
        $this->global['displayBreadcrumbs'] = true; 
        $this->global['breadcrumbs'] = 'Withdrawals'.' <span class="breadcrumb-arrow-right"></span> '.'New';
        $data['displayBreadcrumbs'] = true;
        $data['breadcrumbs'] = "Withdrawals / New Withdrawal";
        $data['userInfo'] = $this->user_model->getUserInfo($this->vendorId);
        $this->load->helper('string');

        if ($this->role == ROLE_CLIENT OR $this->role == ROLE_ADMIN) {
            $this->loadViews("transactions/new", $this->global, $data);
        } else {
            $this->loadThis();
        }
        
    }
}