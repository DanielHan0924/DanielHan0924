<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/  
Route::post('register', 'API\RegisterController@register');
Route::post('login', 'API\RegisterController@login');
Route::post('forgotpassword', 'API\RegisterController@forgotpassword');
Route::get('test', 'API\NotificationController@test');

Route::get('token', 'API\TransactionController@getClientToken');
//for getting odds
Route::get('getodds/{name}', 'API\TransactionController@getOdds');


Route::group(['middleware' => 'auth'], function () {
    Route::get ('logout', 'API\RegisterController@logout');

    Route::get ('users', 'API\RegisterController@getUsers');
    Route::get ('users/{id}', 'API\RegisterController@getUser');
    Route::post('changeprofile', 'API\RegisterController@changeprofile');
    Route::post('contact', 'API\RegisterController@contact');

    Route::get('userresource', 'API\RegisterController@userresource');
    Route::post('token', 'API\RegisterController@token');
    Route::post('token/remove', 'API\RegisterController@remove_token');
    Route::get('role', 'API\RegisterController@role');

    Route::post('changepassword', 'API\RegisterController@changepassword');
    Route::post('changeaccount', 'API\RegisterController@changeaccount');
    Route::get('group/{id}', 'API\RegisterController@member');
    Route::post('group', 'API\RegisterController@addMember');
    Route::delete('group', 'API\RegisterController@kickMember');

    ///client
    Route::get('barber', 'API\ClientController@getMyBarber');
    Route::post('uploadprofile', 'API\ClientController@changeProfile');  //content creator for upload contents
    Route::post('searchbarber', 'API\ClientController@searchAllBarber');
    Route::post('locationinfo', 'API\ClientController@getBarberLocationInfo');
    Route::post('favourite', 'API\ClientController@manageMyBarber');
    Route::post('review', 'API\ClientController@getBarberReview');
    Route::post('reviewbarber', 'API\ClientController@reviewBarber');
    Route::post('service', 'API\ClientController@getBarberService');
    Route::post('book', 'API\ClientController@bookAppointment');
    Route::get('clientbooks', 'API\ClientController@getClientBooks');
    Route::post('statebook', 'API\ClientController@updateBookState');
    Route::post('addcut', 'API\ClientController@addCut');
    Route::post('deletecut', 'API\ClientController@deleteCut');
    Route::post('suportfeedback', 'API\ClientController@suportFeedback');
    Route::get('notification', 'API\ClientController@getAllNotifications');
    Route::get('showNotification', 'API\ClientController@showNotifications');
    Route::get('newalarm', 'API\ClientController@getNewNotifications');
    Route::post('sendcomment', 'API\ClientController@sendBookComment');
    
    ///barber
    Route::post('barberbooks', 'API\BarberController@getBarberBooks');
    Route::post('savelocation', 'API\BarberController@editLocation');
    Route::post('editinfo', 'API\BarberController@editInfo');
    Route::post('gallery', 'API\BarberController@getAllGallery');
    Route::post('addgallery', 'API\BarberController@addGallery');
    Route::post('deleteGallery', 'API\BarberController@deleteGallery');
    Route::post('createservice', 'API\BarberController@createService');
    Route::post('editservice', 'API\BarberController@editService');
    Route::get('clients', 'API\BarberController@getAllMyClients');
    Route::post('clientdetail', 'API\BarberController@getClientDetail');
    Route::post('deleteclient', 'API\BarberController@deleteClient');
    Route::post('blockclient', 'API\BarberController@blockClient');
    Route::post('broadcast', 'API\BarberController@broadcastBarber');
    Route::post('booksetting', 'API\BarberController@saveBookSetting');
    Route::get('getbooksetting', 'API\BarberController@getBookSetting');
    Route::get('requestedbook', 'API\BarberController@getRequestedBook');
    Route::post('barberbookinfo', 'API\BarberController@getBarberBookInfo');

    ///transaction
});
