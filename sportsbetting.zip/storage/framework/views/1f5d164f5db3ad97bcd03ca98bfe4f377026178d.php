<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('profile.update')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Edit Profile')); ?></h4>
                <p class="card-category"><?php echo e(__('User information')); ?></p>
              </div>
              <div class="card-body ">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <div class="col-md-4 row" style="justify-content: center; align-content: center;">
                    <div class="fileinput text-center fileinput-new" data-provides="fileinput">
                      <div class="fileinput-new thumbnail img-circle">
                        <?php if(auth()->user()->avatar != null): ?>
                        <img src="<?php echo e(auth()->user()->avatar); ?>" alt="...">
                        <?php else: ?>
                          <img src="<?php echo e(asset('material')); ?>/img/default.png" alt="...">
                        <?php endif; ?>
                      </div>
                      <div class="fileinput-preview fileinput-exists thumbnail img-circle" style=""></div>
                      <div>
                        <span class="btn btn-round btn-rose btn-file">
                          <span class="fileinput-new"> Photo</span>
                          <span class="fileinput-exists">Change</span>
                          <input type="file" name="photo_path">
                        <div class="ripple-container"></div></span>
                        <br>
                        <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove<div class="ripple-container"><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div></div></a>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-8 row">
                    <label class="col-md-2 col-form-label"><?php echo e(__('Name')); ?></label>
                    <div class="col-md-4">
                      <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="input-name" type="text" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name', auth()->user()->name)); ?>" required="true" aria-required="true"/>
                        <?php if($errors->has('name')): ?>
                          <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <label class="col-md-2 col-form-label"><?php echo e(__('SurName')); ?></label>
                    <div class="col-md-4">
                      <div class="form-group<?php echo e($errors->has('surname') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('surname') ? ' is-invalid' : ''); ?>" name="surname" id="input-surname" type="text" placeholder="<?php echo e(__('SurName')); ?>" value="<?php echo e(old('surname', auth()->user()->surname)); ?>" required="true" aria-required="true"/>
                        <?php if($errors->has('surname')): ?>
                          <span id="name-error" class="error text-danger" for="input-surname"><?php echo e($errors->first('lastName')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <label class="col-md-2 col-form-label"><?php echo e(__('Nick name')); ?></label>
                    <div class="col-md-4">
                      <div class="form-group<?php echo e($errors->has('nickname') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('nickname') ? ' is-invalid' : ''); ?>" name="nickname" id="input-nickname" type="text" placeholder="<?php echo e(__('Nick name')); ?>" value="<?php echo e(old('nickname', auth()->user()->nickname)); ?>" required="true" aria-required="true"/>
                        <?php if($errors->has('nickname')): ?>
                          <span id="name-error" class="error text-danger" for="input-nickname"><?php echo e($errors->first('lastName')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Email')); ?></label>
                    <div class="col-sm-4">
                      <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="input-email" type="email" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email', auth()->user()->email)); ?>" required />
                        <?php if($errors->has('email')): ?>
                          <span id="email-error" class="error text-danger" for="input-email"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Phone number')); ?></label>
                    <div class="col-sm-4">
                      <div class="form-group<?php echo e($errors->has('phonenumber') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('phonenumber') ? ' is-invalid' : ''); ?>" name="phonenumber" id="input-phonenumber" type="phonenumber" placeholder="<?php echo e(__('Phone number')); ?>" value="<?php echo e(old('phonenumber', auth()->user()->phonenumber)); ?>" required />
                        <?php if($errors->has('phonenumber')): ?>
                          <span id="phonenumber-error" class="error text-danger" for="input-phonenumber"><?php echo e($errors->first('phonenumber')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Age')); ?></label>
                    <div class="col-sm-4">
                      <div class="form-group<?php echo e($errors->has('age') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('age') ? ' is-invalid' : ''); ?>" name="age" id="input-age" type="number" placeholder="<?php echo e(__('Age')); ?>" value="<?php echo e(old('age', auth()->user()->age)); ?>" required />
                        <?php if($errors->has('age')): ?>
                          <span id="age-error" class="error text-danger" for="input-age"><?php echo e($errors->first('age')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <label class="col-sm-2 col-form-label" for="input-password-confirmation"><?php echo e(__('Gender')); ?></label>
                    <div class="col-sm-4">
                      <div class="form-group">
                        <select class="selectpicker" name="sex" data-style="btn btn-primary" value="0">
                          <option value="0" <?php echo (auth()->user()->sex == 0 ? 'selected' : '')?>>Male</option>
                          <option value="1" <?php echo (auth()->user()->sex == 1 ? 'selected' : '')?>>Female</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6"></div>
                    <!-- <label class="col-sm-2 col-form-label" for="input-password-confirmation"><?php echo e(__('Group')); ?></label>
                    <div class="col-sm-4">
                      <div class="form-group">
                        <select class="selectpicker" name="groupid" data-style="btn btn-primary" value="0">
                          <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->id); ?>" <?php echo (auth()->user()->groupid == $group->id ? 'selected' : '')?>><?php echo e($group->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div> -->
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Motto')); ?></label>
                    <div class="col-sm-10">
                      <div class="form-group<?php echo e($errors->has('motto') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('motto') ? ' is-invalid' : ''); ?>" name="motto" id="input-motto" type="text" placeholder="<?php echo e(__('Motto')); ?>" value="<?php echo e(old('motto', auth()->user()->motto)); ?>" required />
                        <?php if($errors->has('motto')): ?>
                          <span id="motto-error" class="error text-danger" for="input-motto"><?php echo e($errors->first('motto')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('profile.password')); ?>" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Change password')); ?></h4>
                <p class="card-category"><?php echo e(__('Password')); ?></p>
              </div>
              <div class="card-body ">
                <?php if(session('status_password')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status_password')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-current-password"><?php echo e(__('Current Password')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('old_password') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>" input type="password" name="old_password" id="input-current-password" placeholder="<?php echo e(__('Current Password')); ?>" value="" required />
                      <?php if($errors->has('old_password')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('old_password')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password"><?php echo e(__('New Password')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" id="input-password" type="password" placeholder="<?php echo e(__('New Password')); ?>" value="" required />
                      <?php if($errors->has('password')): ?>
                        <span id="password-error" class="error text-danger" for="input-password"><?php echo e($errors->first('password')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password-confirmation"><?php echo e(__('Confirm New Password')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group">
                      <input class="form-control" name="password_confirmation" id="input-password-confirmation" type="password" placeholder="<?php echo e(__('Confirm New Password')); ?>" value="" required />
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Change password')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('material')); ?>/js/plugins/jasny-bootstrap.min.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'profile', 'titlePage' => __('User Profile')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/profile/edit.blade.php ENDPATH**/ ?>