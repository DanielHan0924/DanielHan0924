
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Book')); ?></h4>
      </div>
      <div class="card-body ">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <div class="row">
        <div class="col-sm-4">
          <!-- <a href="<?php echo e(route('user.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add User')); ?></a> -->
        </div>
        <div class="col-sm-8" style="text-align:right; margin-bottom:20px">
          <!-- <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#position_modal">
          <?php echo e(__('Positions Manage')); ?>

          </button> -->
        </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> <?php echo e(__('No ')); ?> </th>
            <th> <?php echo e(__('Client')); ?> </th>
            <th> <?php echo e(__('Barber')); ?> </th>
            <th> <?php echo e(__('Date')); ?> </th>
            <th> <?php echo e(__('Time')); ?> </th>
            <th> <?php echo e(__('Payment')); ?> </th>
            <th> <?php echo e(__('Status')); ?> </th>
            <th> <?php echo e(__('Detail')); ?> </th>
            <th> <?php echo e(__('Created_at')); ?> </th>
            </tr>
          </thead>
          <tbody >
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <?php echo e($index+1); ?></td>
              <td> <?php echo e($item->client->firstname); ?> <?php echo e($item->client->lastname); ?> </td>
              <td> <?php echo e($item->barber->firstname); ?> <?php echo e($item->barber->lastname); ?> </td>
              <td> <?php echo e($item->date); ?> </td>
              <td> <?php echo e($item->time); ?> </td>
              <td> <?php echo e($item->payment); ?> </td>
              <td> 
              <?php if($item->state == 0): ?>
              <label style = "color:#ddc686 ">REQUEST</label>
              <?php elseif($item->state == 1): ?>
              <label style = "color:#db6e53 ">CANCEL</label>
              <?php elseif($item->state == 2): ?>
              <label style = "color:#0dd6f7 ">CONFIRM</label>
              <?php elseif($item->state == 3): ?>
              <label style = "color:#00b894 ">COMPLETE</label>
              <?php elseif($item->state == 4): ?>
              <label style = "color:#db6e53 ">DECLINE</label>
              <?php endif; ?>
              </td>
              <td> <a href="<?php echo e(route('book.edit', $item)); ?>" class="btn btn-primary btn-sm">
              View</span>
                </a> </td>
              <td><?php echo e(date('M d Y', strtotime($item->created_at))); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'book', 'titlePage' => __('Book Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\01_web\12_ASP.NET\barber\workspace\laravel_backend\resources\views/book/index.blade.php ENDPATH**/ ?>