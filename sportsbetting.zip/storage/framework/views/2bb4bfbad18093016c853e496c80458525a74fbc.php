<footer class="footer">
  <div class="container-fluid">
  </div>
</footer><?php /**PATH D:\Work\Laravel\scnp\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>