<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Booking')); ?></h4>
      </div>
      <div class="card-body ">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <div class="fresh-datatables">
            <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
              <thead class=" text-primary">
              <tr >
                <th> <?php echo e(__('No')); ?> </th>
                <th> <?php echo e(__('User Name')); ?> </th>
                <th> <?php echo e(__('Title')); ?> </th>
                <th> <?php echo e(__('Content')); ?> </th>
                <th> <?php echo e(__('Date')); ?> </th>
                <th> <?php echo e(__('Time')); ?> </th>
                <th> <?php echo e(__('created date')); ?> </th>
                <th> <?php echo e(__('State')); ?> </th>
                <th style="width:160px"> <?php echo e(__('Action')); ?> </th>
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr data-toggle="modal" data-target="#detail_<?php echo e($index); ?>" style="cusor:point">
                    <td><?php echo e($index+1); ?></td>
                    <td>
                      <?php if($booking->user != null): ?>
                      <?php echo e($booking->user->name); ?> <?php echo e($booking->user->surname); ?>

                      <?php endif; ?>
                    </td>
                    <td> <?php echo e($booking->title); ?> </td>
                    <td> <?php echo e($booking->content); ?> </td>
                    <td> <?php echo e($booking->date); ?> </td>
                    <td> <?php echo e($booking->time); ?> </td>
                    <td> 
                      <?php if($booking->closed == 0): ?>
                        Open
                      <?php else: ?>
                        Closed
                      <?php endif; ?>
                    </td>
                    <td><?php echo e(date('H:i d M Y', strtotime($booking->created_at))); ?></td>
                    <td>
                      <form action="<?php echo e(route('booking.destroy', $booking)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this meeting?")); ?>') ? this.parentElement.submit() : ''">
                            <i class="material-icons">close</i>
                            <div class="ripple-container"></div>
                        </button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="modal right fade" id="detail_<?php echo e($index); ?>" tabindex="-1" role="dialog" aria-labelledby="title">
            <div class="modal-dialog" role="document" style="max-width:40%">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title" id="title"><?php echo e(__('Booking Detail')); ?></h4>
                </div>

                <div class="modal-body fresh-datatables">
                  <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
                    <thead class=" text-primary">
                      <tr >
                        <th> <?php echo e(__('No')); ?> </th>
                        <th> <?php echo e(__('User Name')); ?> </th>
                        <th> <?php echo e(__('answer')); ?> </th>
                        <th> <?php echo e(__('answer text')); ?> </th>
                        <th> <?php echo e(__('created date')); ?> </th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $booking->joins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $join): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($key+1); ?></td>
                          <td>
                            <?php if($join->user): ?>
                              <?php echo e($join->user->name); ?> <?php echo e($join->user->surname); ?>

                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if($join->answer == 0): ?>
                            No answer
                            <?php elseif($join->answer == 1): ?>
                              Yes
                            <?php elseif($join->answer == 2): ?>
                              No
                            <?php elseif($join->answer == 3): ?>
                              Maybe
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php echo e($join->text); ?>

                          </td>
                          <td><?php echo e(date('H:i d M Y', strtotime($join->created_at))); ?></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'booking', 'titlePage' => __('Booking Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/booking/index.blade.php ENDPATH**/ ?>