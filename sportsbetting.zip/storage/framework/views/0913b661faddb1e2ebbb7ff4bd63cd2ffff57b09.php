<footer class="footer">
    <div class="container">
    </div>
</footer><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>