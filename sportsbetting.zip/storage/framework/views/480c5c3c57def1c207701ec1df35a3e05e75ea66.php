<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Notification History')); ?></h4>
      </div>
      <div class="card-body ">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <div class="fresh-datatables">
          <div class="row">
            <div class="col-md-4">
              <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#notification_modal"><?php echo e(__('Send Notification')); ?></button>
            </div>
            <form class="col-md-8" action="<?php echo e(route('notification.destroy', 0)); ?>" method="post"  style="text-align:right; margin-bottom:20px">
              <?php echo csrf_field(); ?>
              <?php echo method_field('delete'); ?>
              <button rel="tooltip" type="button" class="btn btn-primary btn-sm" data-original-title="Delete" title="Delete" 
              onclick="confirm('<?php echo e(__("Are you sure you want to delete checked notification history?")); ?>') ? document.getElementById(`checkbox_form`).submit() : ''">
                  Delete checked history
              </button>

              <button rel="tooltip" type="button" class="btn btn-danger btn-sm" data-original-title="Delete All" title="Delete All" onclick="confirm('<?php echo e(__("Are you sure you want to delete this all notification history?")); ?>') ? this.parentElement.submit() : ''">
                  Delete all
              </button>
            </form>
          </div>
          <form action="<?php echo e(route('notification.destroy', -1)); ?>" method="post" id="checkbox_form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
              <thead class=" text-primary">
                <tr>
                  <th style="width:80px"> 
                    <div class="form-check mr-auto">
                      <label class="form-check-label">
                        <input class="form-check-input" name='check_all' id="check_all" type="checkbox" value="checked">
                        <span class="form-check-sign">
                          <span class="check"></span>
                        </span>
                      </label>
                    </div>
                  </th>
                  <th style="width:80px"> <?php echo e(__('No')); ?> </th>
                  <th style="width:120px"> <?php echo e(__('Sender User')); ?> </th>
                  <th style="width:120px"> <?php echo e(__('Receive User')); ?> </th>
                  <th style="width:120px"> <?php echo e(__('Group')); ?> </th>
                  <th style="width:120px"> <?php echo e(__('Title')); ?> </th>
                  <th> <?php echo e(__('Content')); ?> </th>
                  <th style="width:120px"> <?php echo e(__('Image')); ?> </th>
                  <th style="width:80px"> <?php echo e(__('Answer')); ?> </th>
                  <th style="width:120px"> <?php echo e(__('Date')); ?> </th>
                  <th style="width:60px"> <?php echo e(__('Delete')); ?> </th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                      <div class="form-check mr-auto">
                        <label class="form-check-label">
                          <input class="form-check-input" name='check[]' type="checkbox" value="<?php echo e($item->id); ?>">
                          <span class="form-check-sign">
                            <span class="check"></span>
                          </span>
                        </label>
                      </div>
                    </td>
                    <td><?php echo e($index+1); ?></td>
                    <td>
                      <?php if($item->send_user): ?>
                        <?php echo e($item->send_user->name); ?> <?php echo e($item->send_user->surname); ?> 
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($item->receive_user): ?>
                        <?php echo e($item->receive_user->name); ?> <?php echo e($item->receive_user->surname); ?> 
                      <?php elseif($item->receiver_id == 0): ?>
                      All
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($item->group): ?>
                        <?php echo e($item->group->name); ?>

                      <?php endif; ?>
                    </td>
                    <td><?php echo e($item->title); ?></td>
                    <td><?php echo e($item->content); ?></td>
                    <td>
                      <img src="<?php echo e($item->image); ?>" alt="" style="max-width:120px; max-height:120px">
                    </td>
                    <td>
                      <?php if($item->answer == 1): ?>
                      Not answer
                      <?php elseif($item->answer == 2): ?>
                      YES
                      <?php elseif($item->answer == 3): ?>
                      NO
                      <?php endif; ?>
                    </td>
                    <td><?php echo e(date('H:i d M Y', strtotime($item->created_at))); ?></td>
                    <td>
                      <form action="<?php echo e(route('notification.destroy', $item)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this notification history?")); ?>') ? this.parentElement.submit() : ''">
                            <i class="material-icons">close</i>
                            <div class="ripple-container"></div>
                        </button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Theme -->
<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="send_notification" aria-hidden="true" id="notification_modal">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Send Notification</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <form method="post" action="<?php echo e(route('notification.store')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-body row">
          <div class="col-md-12">
            <div class="form-check form-check-radio form-check-inline">
              <label class="form-check-label">
                  <input class="form-check-input" type="radio" name="send_to" id="user" value="0" onchange="selectUser(value)" checked>
                  Send to User
                  <span class="circle">
                      <span class="check"></span>
                  </span>
              </label>
            </div>
            <div class="form-check form-check-radio form-check-inline">
              <label class="form-check-label">
                  <input class="form-check-input" type="radio" name="send_to" id="group" value="1" onchange="selectUser(value)" >
                  Send to Group
                  <span class="circle">
                      <span class="check"></span>
                  </span>
              </label>
            </div>
            <div class="form-check form-check-radio form-check-inline">
              <div id="send_user_id">
                <select class="selectpicker" name="send_user_id[]" multiple data-style="btn btn-primary">
                  <option value="0"><?php echo e(__('All')); ?></option>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> <?php echo e($user->surname); ?> <?php echo $user->device_token ? '' : "( Offline )"?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="hidden" id="send_group_id">
                <select class="selectpicker" name="send_group_id" data-style="btn btn-primary" value='<?php count($groups) > 0 ? $groups[0]['id'] : 0?>' required>
                  <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groups): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($groups->id); ?>"><?php echo e($groups->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="form-check form-check-radio form-check-inline ">
              <div class="togglebutton">
                <label>
                  <input type="checkbox" name="answer">
                    <span class="toggle"></span>
                    Request answer
                </label>
              </div>
            </div>
          </div>
          <div class="fileinput fileinput-new text-center col-md-4" data-provides="fileinput">
            <div class="fileinput-new thumbnail img-raised">
            <img src="\uploads\slider\default.jpg" alt="...">
            </div>
            <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
            <div>
            <span class="btn btn-raised btn-round btn-rose btn-file">
              <span class="fileinput-new">Select image</span>
              <span class="fileinput-exists">Change</span>
              <input type="file" name="photo" id="photo"/>
            </span>
                <a href="#pablo" class="btn btn-danger btn-round fileinput-exists remove-image" data-dismiss="fileinput">
                  <i class="fa fa-times"></i> Remove
                </a>
            </div>
          </div>

          <div class="col-md-8">
            <div class="form-group">
              <input class="form-control" name="title" type="text"  placeholder="<?php echo e(__('Title')); ?>" required/>
            </div>
            <div class="form-group">
            <textarea class="form-control" name="content" id="content" rows="8" placeholder="<?php echo e(__('Content')); ?>" required></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('material')); ?>/js/plugins/jasny-bootstrap.min.js"></script>
  <!-- <script src="<?php echo e(asset('material')); ?>/js/pages/matches.js"></script> -->
  <script>
  $(function () {
    $('#check_all').click(function() {
      if (this.checked) {
        $(':checkbox').each(function() {
          this.checked = true;
        });
      } else {
        $(':checkbox').each(function() {
          this.checked = false;
        });
      } 
    });
  });
  var selectUser = function(val){
    if(val == 0){
      $("#send_user_id").removeClass("hidden");
      $("#send_group_id").addClass("hidden");
    }else{
      $("#send_user_id").addClass("hidden");
      $("#send_group_id").removeClass("hidden");
    }
  }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'notification', 'titlePage' => __('Notification History Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/notification/index.blade.php ENDPATH**/ ?>