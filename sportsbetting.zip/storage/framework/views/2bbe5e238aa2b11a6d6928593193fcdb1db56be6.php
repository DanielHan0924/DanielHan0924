
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary row">
        <div class="col-sm-10">
            <h4 class="card-title" ><?php echo e(__('Book')); ?></h4>
        </div>
        <div class="col-sm-2">
            <?php if($book->state == 0): ?>
            <h5 style="padding:5px; margin-bottom:0px !important; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#ddc686,#ddc686)">REQUEST</h5>
            <?php elseif($book->state == 1): ?>
            <h5 style="padding:5px; margin-bottom:0px !important; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#db6e53,#db6e53)">CANCEL</h5>
            <?php elseif($book->state == 2): ?>
            <h5 style="padding:5px; margin-bottom:0px !important; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#0dd6f7,#0dd6f7)">CONFIRM</h5>
            <?php elseif($book->state == 3): ?>
            <h5 style="padding:5px; margin-bottom:0px !important; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#00b894,#00b894)">COMPLETE</h5>
            <?php elseif($book->state == 4): ?>
            <h5 style="padding:5px; margin-bottom:0px !important; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#db6e53,#db6e53)">DESLINE</h5>
            <?php endif; ?>
        </div>
      </div>
      <div class="card-body ">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <div class="row" style = "margin-bottom:10px">
            <div class="col-sm-3">
                <h5 style="padding:5px; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#00b894,#00b894)">Service</h5>
            </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> <?php echo e(__('No ')); ?> </th>
            <th> <?php echo e(__('Name')); ?> </th>
            <th> <?php echo e(__('Price')); ?> </th>
            <th> <?php echo e(__('Duration')); ?> </th>
            <th> <?php echo e(__('Description')); ?> </th>
            </tr>
          </thead>
          <tbody >
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <?php echo e($index+1); ?></td>
              <td> <?php echo e($item->name); ?> </td>
              <td> <?php echo e($item->price); ?>$ </td>
              <td> 
                <?php if(($item->hour)) echo $item->hour." hour ";?>
                <?php if(($item->min)) echo $item->min." minute";?> 
              </td>
              <td> <?php echo e($item->description); ?>$ </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <div class="row" style = "margin-top:20px">
            <div class="col-sm-3">
                <h5 style="padding:5px; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#00b894,#00b894)">Book Comment</h5>
            </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> <?php echo e(__('No ')); ?> </th>
            <th> <?php echo e(__('Avatar')); ?> </th>
            <th> <?php echo e(__('First Name')); ?> </th>
            <th> <?php echo e(__('Last Name')); ?> </th>
            <th> <?php echo e(__('Comment')); ?> </th>
            <th> <?php echo e(__('Created_at')); ?> </th>
            </tr>
          </thead>
          <tbody >
            <?php $__currentLoopData = $bookcomments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <?php echo e($index+1); ?></td>
              <td rel="tooltip"  data-original-title="<?php echo e($item->sender->firstname); ?>" title="<?php echo e($item->sender->lastname); ?>">
                <img src="<?php echo e($item->sender->avatar); ?>?<?php echo e(time()); ?>" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> <?php echo e($item->sender->firstname); ?> </td>
              <td> <?php echo e($item->sender->lastname); ?> </td>
              <td> <?php echo e($item->comment); ?> </td>
              <td><?php echo e(date('M d Y', strtotime($item->created_at))); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'book', 'titlePage' => __('Book Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/amzmpomy/public_html/Barber-Admin-Laravel/resources/views/book/edit.blade.php ENDPATH**/ ?>