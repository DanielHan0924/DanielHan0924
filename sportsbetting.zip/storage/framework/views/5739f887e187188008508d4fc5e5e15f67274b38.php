<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Payment')); ?></h4>
      </div>
      <div class="card-body ">
      <div class="row">
        <div class="col-sm-4">
          <a href="" class="btn btn-sm btn-primary"><?php echo e(__('Add Fee')); ?></a>
        </div>
        <div class="col-sm-8" style="text-align:right; margin-bottom:20px">
        </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> <?php echo e(__('No ')); ?> </th>
            <th> <?php echo e(__('Term')); ?> </th>
            <th> <?php echo e(__('Fee')); ?> </th>
            <th> <?php echo e(__('Etc')); ?> </th>
            <th> <?php echo e(__('Action')); ?> </th>
            </tr>
          </thead>
          <tbody >
            <?php $__currentLoopData = $paymentData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($index+1); ?></td>
              <td><?php echo e($payment->sz_key); ?> Month</td>
              <td><?php echo e($payment->sz_value); ?> USD</td>
              <td><?php echo e($payment->sz_etc); ?></td>
              <td>
                <a rel="tooltip" class="btn btn-success btn-link" data-original-title="Edit" title="Edit">
                  <i class="material-icons">edit</i>
                  <div class="ripple-container"></div>
                </a>
                <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this user?")); ?>') ? this.parentElement.submit() : ''">
                    <i class="material-icons">close</i>
                    <div class="ripple-container"></div>
                </button>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Theme -->
<div class="modal fade bd-example-modal-sm" id="fee_modal" tabindex="-1" role="dialog" aria-labelledby="fee_title" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="fee_title">Fee management</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      <div class="modal-body row">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="saveThemes()">Save changes</button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'Payment', 'titlePage' => __('Payment Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\temp\Barber-Admin-Laravel\resources\views/payment.blade.php ENDPATH**/ ?>