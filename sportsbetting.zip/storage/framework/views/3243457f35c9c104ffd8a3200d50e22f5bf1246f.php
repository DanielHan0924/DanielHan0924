<footer class="footer">
  <div class="container-fluid">
  </div>
</footer><?php /**PATH D:\temp\Barber-Admin-Laravel\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>