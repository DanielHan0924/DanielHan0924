
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e($client->firstname); ?> <?php echo e($client->lastname); ?></h4>
      </div>
      <div class="card-body ">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <div class="row">
        <div class="col-sm-4">
          <!-- <a href="<?php echo e(route('user.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add User')); ?></a> -->
        </div>
        <div class="col-sm-8" style="text-align:right; margin-bottom:20px">
          <!-- <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#position_modal">
          <?php echo e(__('Positions Manage')); ?>

          </button> -->
        </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> <?php echo e(__('No ')); ?> </th>
            <th> <?php echo e(__('Avatar')); ?> </th>
            <th> <?php echo e(__('FirstName')); ?> </th>
            <th> <?php echo e(__('LastName')); ?> </th>
            <th> <?php echo e(__('Email')); ?> </th>
            <th> <?php echo e(__('Score')); ?> </th>
            <th> <?php echo e(__('Rate')); ?> </th>
            <th> <?php echo e(__('Created_at')); ?> </th>
            </tr>
          </thead>
          <tbody >
            <?php $__currentLoopData = $barbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $barber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <?php echo e($index+1); ?></td>
              <td rel="tooltip"  data-original-title="<?php echo e($barber->barber->firstname); ?>" title="<?php echo e($barber->firstname); ?>">
                <img src="<?php echo e($barber->barber->avatar); ?>?<?php echo e(time()); ?>" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> <?php echo e($barber->barber->firstname); ?> </td>
              <td> <?php echo e($barber->barber->lastname); ?> </td>
              <td> <?php echo e($barber->barber->email); ?> </td>
              <td> <?php echo e($barber->barber->rate); ?> </td>
              <td> 
              <input class="star star-5" id="star-5" value="5" type="radio" name="star" disabled <?php echo $barber->barber->star == 5 ? "checked":"" ?>/>
                <label class="star star-5" for="star-5"></label>
                <input class="star star-4" id="star-4" value="4" type="radio" name="star" disabled <?php echo $barber->barber->star == 4 ? "checked":"" ?>/>
                <label class="star star-4" for="star-4"></label>
                <input class="star star-3" id="star-3" value="3" type="radio" name="star" disabled <?php echo $barber->barber->star == 3 ? "checked":"" ?>/>
                <label class="star star-3" for="star-3"></label>
                <input class="star star-2" id="star-2" value="2" type="radio" name="star" disabled <?php echo $barber->barber->star == 2 ? "checked":"" ?>/>
                <label class="star star-2" for="star-2"></label>
                <input class="star star-1" id="star-1" value="1" type="radio" name="star" disabled <?php echo $barber->barber->star == 1 ? "checked":"" ?>/>
                <label class="star star-1" for="star-1"></label>
              </td>
              <td><?php echo e(date('M d Y', strtotime($barber->created_at))); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'favbarber', 'titlePage' => __('Barbers Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/amzmpomy/public_html/Barber-Admin-Laravel/resources/views/favbarber/edit.blade.php ENDPATH**/ ?>