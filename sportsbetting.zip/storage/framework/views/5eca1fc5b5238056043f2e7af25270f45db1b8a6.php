

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('exercise.store')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data" id="exerciseForm">
            <?php echo csrf_field(); ?>
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Add Tactics')); ?></h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body row">
                <div class="col-md-12 text-right">
                    <a href="<?php echo e(route('exercise.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                  <div class="row">
                    <div class="col-md-4 fileinput fileinput-new text-center" style="padding:3%" data-provides="fileinput">
                      <label for="" id="star_title" style="color:black; font-size:20px">very easy</label>
                      <br>
                      <div class="stars">
                        <form action="">
                          <input class="star star-5" id="star-5" value="5" type="radio" name="star"/>
                          <label class="star star-5" for="star-5"></label>
                          <input class="star star-4" id="star-4" value="4" type="radio" name="star"/>
                          <label class="star star-4" for="star-4"></label>
                          <input class="star star-3" id="star-3" value="3" type="radio" name="star"/>
                          <label class="star star-3" for="star-3"></label>
                          <input class="star star-2" id="star-2" value="2" type="radio" name="star"/>
                          <label class="star star-2" for="star-2"></label>
                          <input class="star star-1" id="star-1" value="1" type="radio" name="star" checked/>
                          <label class="star star-1" for="star-1"></label>
                        </form>
                      </div>
                      <fieldset class="form-group">
                          <a href="javascript:void(0)" onclick="$('#pro-image').click()">Upload Image</a>
                          <input type="file" id="pro-image" name="photo[]" style="display: none;" class="form-control" multiple>
                      </fieldset>
                      <div class="progress upload_progress hidden">
                        <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 0" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" id="upload_prgress_bar"></div>
                      </div>
                      <div class="preview-images-zone"></div>
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                          <select class="selectpicker" name="themeid" data-style="btn btn-primary" value='0' required>
                            <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($theme->id); ?>"><?php echo e($theme->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <div class="form-check form-check-radio form-check-inline" style="margin-left:10%">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="state" value="0" checked> Draft
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                            </label>
                          </div>
                          <div class="form-check form-check-radio form-check-inline">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="state" value="1"> Publish
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                            </label>
                          </div>
                          <div class="form-check form-check-radio form-check-inline">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="state" value="2" > Validate
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                            </label>
                          </div>
                        </div>
                        <div class="form-group">
                          <input class="form-control" name="user_name" type="text"  placeholder="<?php echo e(__('Coach')); ?>"/>
                        </div>
                        <div class="form-group<?php echo e($errors->has('title') ? ' has-danger' : ''); ?>">
                          <input class="form-control" name="title" type="text"  placeholder="<?php echo e(__('Title')); ?>" required/>
                        </div>
                        <div class="form-group<?php echo e($errors->has('purpose') ? ' has-danger' : ''); ?>">
                          <input class="form-control" name="purpose" type="text"  placeholder="<?php echo e(__('Purpose')); ?>"/>
                        </div>
                        <div class="form-group<?php echo e($errors->has('description') ? ' has-danger' : ''); ?>">
                          <textarea id="description" name="description" placeholder="How it works" ></textarea>
                        </div>
                        <div class="form-group<?php echo e($errors->has('requirement') ? ' has-danger' : ''); ?>">
                          <input class="form-control" name="requirement" type="text"  placeholder="<?php echo e(__('Prequirements')); ?>" required/>
                        </div>
                        <div class="row">
                          <div class="col-md-6 form-group<?php echo e($errors->has('time') ? ' has-danger' : ''); ?>">
                            <input class="form-control" name="time" type="number" min="0"  placeholder="<?php echo e(__('Time(Minutes)')); ?>"  step="0.01" required/>
                          </div>
                          <div class="col-md-6 form-group<?php echo e($errors->has('players') ? ' has-danger' : ''); ?>">
                            <input class="form-control" name="players" type="number" min="1"  placeholder="<?php echo e(__('Players')); ?>" required/>
                          </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer text-right">
                <div class="mr-auto">
                </div>
                <button type="submit" class="btn btn-sm btn-primary">Register</button>
              </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('material')); ?>/js/plugins/jasny-bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
  <script>
    const SERVER_HOST = `<?php echo url('/')?>`;
    $(document).ready(function() {
      var num = 0;
      $("input[name=star]:radio").change(function (e) {
        let star = ['very easy', 'easy', 'normal', 'difficult', 'very Difficult'];
        $("#star_title").text(star[e.target.value-1]);
      });
      $("#description").Editor(
        settings={
          'insert_img':false,
          'block_quote':false,
          'ol':false,
          'ul':false
        }
      );
      $( ".preview-images-zone" ).sortable();
      $("#exerciseForm").submit(function(event) {
        $("#description").val($('#description').Editor("getText"));
      });
      $(document).on('click', '.image-cancel', function() {
        let no = $(this).data('no');
        let url = $(this).parent().find("input").val();
        console.log(url);
        $.ajax({
          url: `${SERVER_HOST}/exercise/removeImage`,
          type: 'post',
          data: {url:url},
        });
        $(".preview-image.preview-show-"+no).remove();
      });
      $('#pro-image').on('change', function() {
        if(!this.files) return;
        var form_data = new FormData();                  
        for (let i = 0; i < this.files.length; i++) {
          form_data.append('photo[]', this.files[i]);
        }
        $.ajax({
            type:'POST',
            url: `${SERVER_HOST}/exercise/images`,
            data:form_data,
            xhr: function() {
              $(".upload_progress").removeClass("hidden");
              var myXhr = $.ajaxSettings.xhr();
              if(myXhr.upload)
                  myXhr.upload.addEventListener('progress',progress, false);
              return myXhr;
            },
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
              var output = $(".preview-images-zone");
              console.log(data);
              if(!data || data.length <= 0) return;
              data.forEach(url => {
                var html =  `<div class="preview-image preview-show-${num}">
                              <div class="image-cancel" data-no="${num}">&#215;</div>
                              <div class="image-zone"><img id="pro-img-${num}" src="${url}"></div>
                              <input type="hidden" name="img_url[]" value="${url}">
                            </div>`;
                num += 1;
                output.append(html);
              });
              $("#pro-image").val('');
              // $("#pro-image").wrap('<form>').parent('form').trigger('reset');
              // $("#pro-image").unwrap();
            },
            error: function(data){
              $("#pro-image").val('');
              // $("#pro-image").wrap('<form>').parent('form').trigger('reset');
              // $("#pro-image").unwrap();
              console.log(data);
            }
        });
      });
    });
    function progress(e){
      if(e.lengthComputable){
          var max = e.total;
          var current = e.loaded;
          var Percentage = (current * 100)/max;
          $("#upload_prgress_bar").attr("style", `width: ${Percentage}%`);
          if(Percentage >= 100){
            $("#upload_prgress_bar").attr("style", `width: 0%`);
            $(".upload_progress").addClass("hidden");
          }
      }  
    }
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'exercise', 'titlePage' => __('Tactics Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/exercise/create.blade.php ENDPATH**/ ?>