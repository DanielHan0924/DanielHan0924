

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php if($errors->has('name')): ?>
            <div class="row">
              <div class="col-sm-12">
                <div class="alert alert-danger">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                  </button>
                  <span><?php echo e($errors->first('name')); ?></span>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <form method="post" action="<?php echo e(route('group.update', $group)); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Change Group')); ?></h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body row">
                <div class="col-md-12 text-right">
                    <a href="<?php echo e(route('group.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                </div>

                <div class="col-md-4" style="text-align:right">
                  <div class="fileinput text-center fileinput-new" data-provides="fileinput">
                    <div class="fileinput-new thumbnail img-circle">
                        <?php if($group->photo): ?>
                          <img src="<?php echo e($group->photo); ?>" alt="...">
                        <?php else: ?>
                          <img src="<?php echo e(asset('material')); ?>/img/Default_Thumbnail.png" alt="...">
                        <?php endif; ?>
                    </div>
                    <div class="fileinput-preview fileinput-exists thumbnail img-circle" style=""></div>
                    <div>
                      <span class="btn btn-round btn-rose btn-file">
                        <span class="fileinput-new">Add Photo</span>
                        <span class="fileinput-exists">Change</span>
                        <input type="file" name="photo_path">
                      <div class="ripple-container"></div></span>
                      <br>
                      <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove<div class="ripple-container"><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div></div></a>
                    </div>
                  </div>
                </div>

                <div class="col-md-7">
                  <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                    <input class="form-control" name="name"  type="text"  placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e($group->name); ?>"  required />
                  </div>
                  <div class="form-check mr-auto">
                    <label class="form-check-label">
                      <input class="form-check-input" name='isteam' type="checkbox" value="checked" <?php echo ($group->isteam==1 ? 'checked' : '') ?>> Don't show in list of groups only in teams.
                      <span class="form-check-sign">
                        <span class="check"></span>
                      </span>
                    </label>
                  </div>
                </div>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary">Update</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('material')); ?>/js/plugins/jasny-bootstrap.min.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'groups', 'titlePage' => __('Groups Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/group/edit.blade.php ENDPATH**/ ?>