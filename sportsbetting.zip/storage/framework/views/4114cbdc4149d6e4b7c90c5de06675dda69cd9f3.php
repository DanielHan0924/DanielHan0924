<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary row">
        <h4 class="card-title"><?php echo e(__('Championship Management')); ?></h4>
      </div>
      <div class="card-body row" style="margin:0 5% 5% 0">
        <?php if(session('status')): ?>
        <div class="col-sm-12">
          <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <i class="material-icons">close</i>
            </button>
            <span><?php echo e(session('status')); ?></span>
          </div>
        </div>
        <?php endif; ?>
        <div class="col-md-4">
        <br><br>
          <form method="post" action="<?php echo e($edit_championship != null ? route('championship.update', $edit_championship) : route('championship.store')); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php if($edit_championship != null): ?>
              <?php echo method_field('put'); ?>
            <?php endif; ?>
            <div  style="width:80%; margin-left:10%; text-align: center;">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      Championship
                  </span>
                </div>
                <input class="form-control" name="title" id="input-title" type="text" placeholder="<?php echo e(__('Championship')); ?>" value="<?php echo e($edit_championship != null ? $edit_championship->title : ''); ?>" required />
              </div>
              <div style="margin-top:20px">
                <?php if($edit_championship == null): ?>
                  <button type="submit" class="btn btn-sm btn-primary"><?php echo e(__('Add')); ?></button>
                <?php else: ?>
                  <button type="submit" class="btn btn-sm btn-primary" style="margin-right:10px"><?php echo e(__('Save')); ?></button>
                  <a href="<?php echo e(route('championship.index')); ?>"  class="btn btn-sm btn-primary"><?php echo e(__('Cancel')); ?></a>
                <?php endif; ?>
              </div>
            </div>
          </form>
        </div>
        <div class="col-md-8 fresh-datatables">
          <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
            <thead class=" text-primary">
            <tr >
              <th><?php echo e(__('No')); ?></th>
              <th><?php echo e(__('Name')); ?></th>
              <th><?php echo e(__('Edit Date')); ?></th>
              <th><?php echo e(__('Action')); ?></th>
            </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $championships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $champion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($index); ?></td>
                  <td><?php echo e($champion->title); ?></td>
                  <td><?php echo e(date('H:i  M d', strtotime($champion->updated_at))); ?></td>
                  <td>
                    <form action="<?php echo e(route('championship.destroy', $champion)); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('delete'); ?>
                      <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(route('championship.edit', $champion)); ?>" data-original-title="Edit" title="Edit">
                        <i class="material-icons">edit</i>
                        <div class="ripple-container"></div>
                      </a>
                      <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this match?")); ?>') ? this.parentElement.submit() : ''">
                          <i class="material-icons">close</i>
                          <div class="ripple-container"></div>
                      </button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
	  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'championship', 'titlePage' => __('Championship Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\scnp\resources\views/championship/index.blade.php ENDPATH**/ ?>