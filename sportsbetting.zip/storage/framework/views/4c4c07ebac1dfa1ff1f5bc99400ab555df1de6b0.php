
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Transaction Management')); ?></h4>
      </div>
      <div class="card-body row">
        <div class="col-md-2" style="text-align: center;">
          <br/><br/><br/>
          <form method="post" action="<?php echo e(route('transaction.store')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group label-floating">
              <label class="control-label">Monthly</label>
              <input type="number" min="0" class="form-control" placeholder="Monthly amount" value="<?php echo e($setting[0]->value); ?>" name="monthly_amount" style="text-align:center; font-size:18px">
              <span class="form-control-feedback">
                <?php echo e($setting[0]->key); ?>

              </span>
            </div>

            <button class="btn btn-primary btn-round" onclick="this.parentElement.submit()">
              <i class="material-icons">save</i> Save
            </button>
          </form>
        </div>
        <div class="col-md-10 fresh-datatables">
        <div class="text-right">
          <form action="<?php echo e(route('transaction.destroy', 0)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete report" title="Delete report" onclick="confirm('<?php echo e(__("Are you sure you want to delete all transaction history?")); ?>') ? this.parentElement.submit() : ''">
            </button>
          </form>
        </div>
          <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
            <thead class=" text-primary">
              <tr >
                <th style="width:5%"><?php echo e(__('No')); ?></th>
                <th style="width:5%"><?php echo e(__('Name')); ?></th>
                <th style="width:15%"><?php echo e(__('Email')); ?></th>
                <th style="width:20%"><?php echo e(__('Transaction Id')); ?></th>
                <th style="width:5%"><?php echo e(__('amount')); ?></th>
                <th style="width:5%"><?php echo e(__('Delete')); ?></th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($index+1); ?></td>
              <?php if($transaction->type === 2 && $transaction->user): ?>
                <td><?php echo e($transaction->user->firstname); ?> <?php echo e($transaction->user->lastname); ?></td>
                <td><?php echo e($transaction->user->email); ?></td>
              <?php elseif($transaction->type === 3 && $transaction->directUser): ?>
                <td><?php echo e($transaction->directUser->firstname); ?> <?php echo e($transaction->directUser->lastname); ?></td>
                <td><?php echo e($transaction->directUser->email); ?></td>
              <?php else: ?>
                <td></td>
                <td></td>
              <?php endif; ?>
              <td><?php echo e($transaction->transactionid); ?></td>
              <td><?php echo e($transaction->amount); ?> €</td>
              <td></td>
              <td><?php echo e(date('d M Y', strtotime($transaction->created_at))); ?></td>
              <td><?php echo e(date('d M Y', strtotime($transaction->toDate))); ?></td>
              <td>
                <form action="<?php echo e(route('transaction.destroy', $transaction)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete report" title="Delete report" onclick="confirm('<?php echo e(__("Are you sure you want to delete this transaction?")); ?>') ? this.parentElement.submit() : ''">
                        <i class="material-icons">close</i>
                        <div class="ripple-container"></div>
                    </button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
	  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'transaction', 'titlePage' => __('Transaction Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/amzmpomy/public_html/Barber-Admin-Laravel/resources/views/transaction/index.blade.php ENDPATH**/ ?>