<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="card registration">
                <div class="card-header card-header-primary row">
                    <h4 class="card-title"><?php echo e(__('Reports Management')); ?></h4>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo e(session('status')); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="fresh-datatables">
                        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
                            <thead class=" text-primary">
                                <tr>
                                    <th colspan="2">Message</th>
                                    <th colspan="3">Report</th>
                                    <th colspan="3">Action</th>
                                </tr>
                                <tr>
                                    <th> <?php echo e(__('User')); ?> </th>
                                    <th style="width:30%"> <?php echo e(__('Message')); ?> </th>
                                    <th> <?php echo e(__('User')); ?> </th>
                                    <th style="width:30%"> <?php echo e(__('Message')); ?> </th>
                                    <th>Date</th>
                                    <th> <?php echo e(__('Lock')); ?> </th>
                                    <th> <?php echo e(__('Message')); ?> </th>
                                    <th> <?php echo e(__('Delete')); ?> </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($report->user ? $report->user->name : ""); ?></td>
                                        <td><?php echo e($report->message); ?></td>
                                        <td><?php echo e($report->reportuser ? $report->reportuser->name : ""); ?></td>
                                        <td><?php echo e($report->report); ?></td>
                                        <td><?php echo e(date('H:i d M Y', strtotime($report->created_at))); ?></td>
                                        <td>
                                            <?php if(is_object($report->user)): ?>
                                            <div class="togglebutton">
                                                <label>
                                                    <input type="checkbox" <?php echo ($report->user->active == 0 ? "checked" : '') ?> onClick="lockUser(<?php echo e($report); ?>, this.checked)">
                                                    <span class="toggle"></span>
                                                </label>
                                            </div>
                                            <?php else: ?>
                                                Deleted user
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('report.destroy', $report)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="type" value="1">
                                                <?php echo method_field('delete'); ?>
                                                <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete Message" title="Delete Message" onclick="confirm('<?php echo e(__("Are you sure you want to delete this Message?")); ?>') ? this.parentElement.submit() : ''">
                                                    <i class="material-icons">close</i>
                                                    <div class="ripple-container"></div>
                                                </button>
                                            </form>
                                        </td>
                                        <td>
                                            <?php if($report->database): ?>
                                                <form action="<?php echo e(route('report.destroy', $report)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="type" value="0">
                                                    <?php echo method_field('delete'); ?>
                                                    <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete report" title="Delete report" onclick="confirm('<?php echo e(__("Are you sure you want to delete this report?")); ?>') ? this.parentElement.submit() : ''">
                                                        <i class="material-icons">close</i>
                                                        <div class="ripple-container"></div>
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                Deleted Message
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        var lockUser = function(report, value){
            $.ajax({
                url: `report/${report.user.id}`,
                data:{value:(value?0:1)},
                method:'put',
                success: function(result){
                },
                error:function(xhr,status,error){
                    location.reload();
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'report', 'titlePage' => __('Reports Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/report/index.blade.php ENDPATH**/ ?>