<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Users')); ?></h4>
      </div>
      <div class="card-body ">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <div class="row">
        <div class="col-sm-4">
          <a href="<?php echo e(route('user.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add User')); ?></a>
        </div>
        <div class="col-sm-8" style="text-align:right; margin-bottom:20px">
          <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#position_modal">
          <?php echo e(__('Positions Manage')); ?>

          </button>
        </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> <?php echo e(__('No ')); ?> </th>
            <th> <?php echo e(__('Avatar')); ?> </th>
            <th> <?php echo e(__('Name')); ?> </th>
            <th> <?php echo e(__('Surname')); ?> </th>
            <th> <?php echo e(__('Nickname')); ?> </th>
            <th> <?php echo e(__('Email')); ?> </th>
            <th> <?php echo e(__('Gender')); ?> </th>
            <th> <?php echo e(__('Age')); ?> </th>
            <th> <?php echo e(__('Phone number')); ?> </th>
            <th> <?php echo e(__('Role')); ?> </th>
            <th> <?php echo e(__('Group')); ?> </th>
            <th> <?php echo e(__('Create Date')); ?> </th>
            <th> <?php echo e(__('Active')); ?> </th>
            <th> <?php echo e(__('Terms')); ?> </th>
            <th> <?php echo e(__('Action')); ?> </th>
            </tr>
          </thead>
          <tbody >
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <?php echo e($index+1); ?></td>
              <td rel="tooltip"  data-original-title="<?php echo e($user->nickname); ?>" title="<?php echo e($user->nickname); ?>">
                <img src="<?php echo e($user->avatar); ?>?<?php echo e(time()); ?>" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> <?php echo e($user->name); ?> </td>
              <td> <?php echo e($user->surname); ?> </td>
              <td> <?php echo e($user->nickname); ?> </td>
              <td> <?php echo e($user->email); ?> </td>
              <td> <?php echo e($user->sex == 0 ? 'Male' : "Female"); ?> </td>
              <td> <?php echo e($user->age); ?> </td>
              <td> <?php echo e($user->phonenumber); ?></td>
              <td> <?php echo e($user->userRole->role); ?> </td>
              <td> <?php echo e(($user->group != null && $user->userRole->role != "EXTERNAL" && $user->userRole->role != "PARTNER" ? $user->group->name : "")); ?> </td>
              <td><?php echo e(date('M d Y', strtotime($user->created_at))); ?></td>
              <td>
              <?php if($user->active): ?>
                  Allowed
                <?php else: ?>
                  Blocked
                <?php endif; ?>
              </td>
              <td>
              <?php if($user->terms): ?>
                  Agree
                <?php else: ?>
                  Disagree
                <?php endif; ?>
              </td>
              <td>
                <?php if($user->role != 1): ?>
                  <form action="<?php echo e(route('user.destroy', $user)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(route('user.edit', $user)); ?>" data-original-title="Edit" title="Edit">
                      <i class="material-icons">edit</i>
                      <div class="ripple-container"></div>
                    </a>
                    <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this user?")); ?>') ? this.parentElement.submit() : ''">
                        <i class="material-icons">close</i>
                        <div class="ripple-container"></div>
                    </button>
                  </form>
                <?php else: ?>
                  <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(route('profile.edit')); ?>" data-original-title="Edit" title="Edit">
                    <i class="material-icons">edit</i>
                    <div class="ripple-container"></div>
                  </a>
                <?php endif; ?>  
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Theme -->
<div class="modal fade bd-example-modal-sm" id="position_modal" tabindex="-1" role="dialog" aria-labelledby="position_title" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="position_title">Positions management</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      <div class="modal-body row">
        <div class="col-md-8" style="text-align:left; bottom:-15px">
          Change order with Drag and Drop
        </div>
        <div class="col-md-4" style="text-align:right;">
          <button rel="tooltip" type="button" class="btn btn-danger btn-round btn-sm" data-original-title="Delete" title="Delete" onclick="addTheme()">
              <i class="material-icons">add</i>
          </button>
        </div>
        <table id="position_table" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
        <thead>
          <tr>
            <td></td>
            <td style="width:200px"></td>
          </tr>
        </thead>
          <tbody id="position_tbody">
            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr id="position_<?php echo e($index); ?>" value="<?php echo e($position->id); ?>">
                <td id="position_title_<?php echo e($index); ?>"><?php echo e($position->position); ?></td>
                <td>
                  <a rel="tooltip" class="btn btn-success btn-link btn-sm" data-original-title="Edit" title="Edit" onclick="editTheme(<?php echo e($index); ?>)">
                    <i class="material-icons">edit</i>
                    <div class="ripple-container"></div>
                  </a>
                  <button rel="tooltip" type="button" class="btn btn-danger btn-link btn-sm" data-original-title="Delete" title="Delete" onclick="deleteTheme(<?php echo e($index); ?>)">
                      <i class="material-icons">close</i>
                      <div class="ripple-container"></div>
                  </button>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="saveThemes()">Save changes</button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
  <script>
    let total_index = `<?php echo count($positions)?>`;
  </script>
  <script src="<?php echo e(asset('material')); ?>/js/pages/positions.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'user', 'titlePage' => __('Users Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/users/index.blade.php ENDPATH**/ ?>