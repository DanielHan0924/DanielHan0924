

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php if($errors->has('email')): ?>
            <div class="row">
              <div class="col-sm-12">
                <div class="alert alert-danger">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                  </button>
                  <span><?php echo e($errors->first('email')); ?></span>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <form method="post" action="<?php echo e(route('news.store')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data" id="newsForm">
            <?php echo csrf_field(); ?>
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Add News')); ?></h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body row">
                <div class="col-md-12 text-right">
                    <a href="<?php echo e(route('news.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                  <div class="row">
                    <div class="col-md-4 fileinput fileinput-new text-center" style="padding:3%" data-provides="fileinput">
                      <div class="fileinput-new thumbnail">
                        <img src="https://material-dashboard-pro-laravel.creative-tim.com/material/img/image_placeholder.jpg" alt="...">
                      </div>
                      <div class="fileinput-preview fileinput-exists thumbnail"></div>
                      <div>
                        <span class="btn btn-rose btn-round btn-file">
                          <span class="fileinput-new">Select image</span>
                          <span class="fileinput-exists">Change</span>
                          <input type="file" name="photo" id="" accept="image/*"/>
                        </span>
                        <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                      </div>
                    </div>
                    <div class="col-md-8">
                        <div class="col-md-8 form-group<?php echo e($errors->has('title') ? ' has-danger' : ''); ?>">
                          <input class="form-control" name="title" type="text"  placeholder="<?php echo e(__('Title')); ?>" value="" />
                        </div>
                        <div class="form-group">
                            <select class="selectpicker" name="type" data-style="btn btn-primary" value='0'>
                              <option selected value="0">Club</option>
                              <option  value="1">Partner</option>
                              <option  value="2">Other</option>
                            </select>
                          </div>
                        <div class="form-group<?php echo e($errors->has('content') ? ' has-danger' : ''); ?>">
                          <textarea id="content" name="content"></textarea>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer text-right">
                <div class="mr-auto">
                </div>
                <button type="submit" class="btn btn-sm btn-primary">Register</button>
              </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('material')); ?>/js/plugins/jasny-bootstrap.min.js"></script>
  <script>
    $(document).ready(function() {
      $("#content").Editor(
        settings={
          'insert_img':false,
          'block_quote':false,
          'ol':false,
          'ul':false
        }
      );
    });
    $("#newsForm").submit(function(event) {
      $("#content").val($('#content').Editor("getText"));
    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'news', 'titlePage' => __('News Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/news/create.blade.php ENDPATH**/ ?>