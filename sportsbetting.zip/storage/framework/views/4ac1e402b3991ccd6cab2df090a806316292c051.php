<footer class="footer">
  <div class="container-fluid">
  </div>
</footer><?php /**PATH /home3/amzmpomy/public_html/Barber-Admin-Laravel/resources/views/layouts/footers/auth.blade.php ENDPATH**/ ?>