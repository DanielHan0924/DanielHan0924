<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Coach')); ?></h4>
      </div>
      <div class="card-body ">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <div style="padding:3%" id="accordion" role="tablist">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="card card-collapse">
                <div class="card-header" role="tab">
                  <h5 class="mb-0">
                    <a data-toggle="collapse" href="#collapse_<?php echo e($index); ?>" aria-expanded="false" aria-controls="collapse_<?php echo e($index); ?>">
                      <?php echo e($item->name); ?> <?php echo e($item->surname); ?>

                      <i class="material-icons">keyboard_arrow_down</i>
                      <button class="btn btn-primary btn-sm" style="float:right; margin-right:50px" onClick="$('#collapse_<?php echo e($index); ?>').submit()">Save</button>
                      <br>
                      <?php echo e($item->email); ?>

                    </a>
                  </h5>
                </div>
                <form method="post" action="<?php echo e(route('coachrole.update', $item)); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data" id="collapse_<?php echo e($index); ?>" class="collapse" role="tabpanel" data-parent="#accordion">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('put'); ?>
                  <div class="card-body row">
                    <?php $__currentLoopData = $item->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_index => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" name="count" value=<?php echo e($group_index); ?>>
                    <div class="form-check col-md-2">
                      <label class="form-check-label">
                        <input class="form-check-input" type="checkbox" name="group_<?php echo e($group_index); ?>" <?php echo $group->role == 0 ? "checked" :"" ?> value="<?php echo e($group->id); ?>">
                        <?php echo e($group->name); ?>

                        <span class="form-check-sign"><span class="check"></span></span>
                      </label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </form>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'coachrole', 'titlePage' => __('Coach Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/coachrole/index.blade.php ENDPATH**/ ?>