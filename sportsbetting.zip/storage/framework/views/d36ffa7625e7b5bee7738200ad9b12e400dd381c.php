<footer class="footer">
  <div class="container-fluid">
  </div>
</footer><?php /**PATH E:\01_web\12_ASP.NET\barber\workspace\laravel_backend\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>