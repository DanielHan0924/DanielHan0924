<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php if($errors->has('content')): ?>
            <div class="alert alert-danger">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="material-icons">close</i>
              </button>
              <span><?php echo e($errors->first('content')); ?></span>
            </div>
            <br/>
          <?php endif; ?>
          <?php if(session('status')): ?>
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="material-icons">close</i>
              </button>
              <span><?php echo e(session('status')); ?></span>
            </div>
          <?php endif; ?>
          <?php if(is_object($condition)): ?>
            <form method="post" action="<?php echo e(route('conditions.update', $condition)); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data" id="newsForm">
            <?php echo method_field('put'); ?>
          <?php else: ?>
            <form method="post" action="<?php echo e(route('conditions.store')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data" id="newsForm">
          <?php endif; ?>
              <?php echo csrf_field(); ?>
              <div class="card ">
                <div class="card-header card-header-primary">
                  <h4 class="card-title"><?php echo e(__('Conditions')); ?></h4>
                  <p class="card-category"></p>
                </div>
                <div class="card-body row">
                  <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                      <div class="form-group<?php echo e($errors->has('content') ? ' has-danger' : ''); ?>">
                        <textarea id="content" name="content"></textarea>
                      </div>
                  </div>
                </div>
                <div class="card-footer text-right">
                  <div class="mr-auto">
                  </div>
                  <button type="submit" class="btn btn-sm btn-primary">Register</button>
                </div>
              </div>
            </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('material')); ?>/js/plugins/jasny-bootstrap.min.js"></script>
  <script>
    $(document).ready(function() {
      $("#content").Editor(
        settings={
          'insert_img':false,
          'block_quote':false,
          'ol':false,
          'ul':false
        }
      );
      $("#content").Editor('setText', `<?php echo is_object($condition) ? $condition->condition : "" ?>`);
    });
    $("#newsForm").submit(function(event) {
      $("#content").val($('#content').Editor("getText"));
    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'conditions', 'titlePage' => __('Conditions Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/conditions/index.blade.php ENDPATH**/ ?>