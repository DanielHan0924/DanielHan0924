<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('News')); ?></h4>
      </div>
      <div class="card-body ">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <div class="row">
          <div class="col-sm-4">
              <a href="<?php echo e(route('news.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add News')); ?></a>
          </div>
        </div>
        <div class="fresh-datatables">
          <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
            <thead class=" text-primary">
              <tr>
                <th style="width:80px"> <?php echo e(__('No')); ?> </th>
                <th> <?php echo e(__('Title')); ?> </th>
                <th style="width:120px"> <?php echo e(__('Writer')); ?> </th>
                <th style="width:300px"> <?php echo e(__('Date')); ?> </th>
                <th style="width:80px"> <?php echo e(__('Type')); ?> </th>
                <th style="width:100px"> <?php echo e(__('Like/Dislike')); ?> </th>
                <th style="width:120px"> <?php echo e(__('state')); ?> </th>
                <th style="width:180px"> <?php echo e(__('Action')); ?> </th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$newsitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($index+1); ?></td>
                  <td><?php echo e($newsitem->title); ?></td>
                  <td>
                    <?php if($newsitem->userid <= 0): ?>
                      Admin
                    <?php elseif($newsitem->user): ?>
                    <?php echo e($newsitem->user->name); ?> <?php echo e($newsitem->user->surname); ?>

                    <?php endif; ?>
                  </td>
                  <!-- <td><?php echo e(date('H:i d M Y', strtotime($newsitem->updated_at))); ?></td> -->
                  <td>
                    <div class="input-group">
                    <input type="datetime-local" name="" id="date_<?php echo e($newsitem->id); ?>" value="<?php echo e(date('Y-m-d\TH:i:00', strtotime($newsitem->date))); ?>" class="form-control" style="text-align:center; font-size:16px;">
                      <div class="input-group-append">
                        <span class="input-group-text">
                        <a rel="tooltip" data-original-title="Change Date" title="Change Date" onclick="saveDate(`<?php echo e(url('news/order')); ?>`, `<?php echo e($newsitem->id); ?>`)" style="cursor:pointer">
                          <i class="material-icons" style="font-size: 1.2rem; color:#4caf50">save</i>
                        </a>
                        </span>
                      </div>
                    </div>
                    
                  </td>
                  <td>
                    <?php if($newsitem->type == 0): ?>
                      Club
                    <?php elseif($newsitem->type == 1): ?>
                      Partner
                    <?php elseif($newsitem->type == 2): ?>
                      Other
                    <?php elseif($newsitem->type == -1): ?>
                      Draft
                    <?php endif; ?>
                  </td>
                  <td><?php echo e($newsitem->agree); ?> / <?php echo e($newsitem->disagree); ?></td>
                  <td>
                      <div class="togglebutton">
                          <label>
                              <input type="checkbox" <?php echo (intval ($newsitem->state) == 0 ? "checked" : '') ?> onClick="allowNews(<?php echo e($newsitem->id); ?>, this.checked)">
                              <span class="toggle"></span>
                          </label>
                      </div>
                  </td>
                  <td>
                    <form action="<?php echo e(route('news.destroy', $newsitem)); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('delete'); ?>
                      <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(route('news.edit', $newsitem)); ?>" data-original-title="Edit" title="Edit">
                        <i class="material-icons">edit</i>
                        <div class="ripple-container"></div>
                      </a>
                      <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this news?")); ?>') ? this.parentElement.submit() : ''">
                          <i class="material-icons">close</i>
                          <div class="ripple-container"></div>
                      </button>
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
      const allowNews = function(id, value){
        $.ajax({
            url: 'news/allow',
            data:{id:id, value:(value?0:1)},
            method:'post',
            success: function(result){
            },
            error:function(xhr,status,error){
                location.reload();
            }
        });
      }
      const saveDate = function(url, id) {
        const date_input = $(`#date_${id}`);
        const date = date_input.val();
        if (!Date.parse(date)) {
          date_input.focus();
          date_input.select();
          return;
        }

        $.ajax({
          url: url,
          data:{id:id, date:date},
          method:'post',
          success: function(result){
          },
          error:function(xhr,status,error){
            location.reload();
          }
        });
      }
      
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'news', 'titlePage' => __('News Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/news/index.blade.php ENDPATH**/ ?>