<!-- <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

 -->


<?php $__env->startSection('content'); ?>
<div class="content" style="width:90%; margin:auto; margin-top:60px">
  <div class="container-fluid">
    <div class="card registration">
        <div class="card-header card-header-primary text-right">
            <div class="btn-group" style="margin:0">
                <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php if($type == 0): ?>
                        General Chat
                    <?php elseif($type == 1): ?>
                        Team Chat
                    <?php elseif($type == 2): ?>
                        Ads Chat
                    <?php elseif($type == 3): ?>
                        Private Chat
                    <?php endif; ?>
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="<?php echo e(url('chat/0/0')); ?>">Genera`l Chat</a>
                    <a class="dropdown-item" href="<?php echo e(url('chat/1/1')); ?>">Team Chat</a>
                    <a class="dropdown-item" href="<?php echo e(url('chat/2/0')); ?>">Ads Chat</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(url('chat/3/1')); ?>">Private Chat</a>
                </div>
            </div>
        </div>
        <div class="card-body ">
            <?php if($type == 2): ?>
            <div style="width:calc(100% - 140px)">
                <input type="text" class="tagsinput form-control" data-role="tagsinput">
            </div>
            <div style="width:140px; position:absolute; top:15px; right:0 ">
                <button type="button" class="btn btn-primary btn-sm" onclick="saveTags()">
                    <i class="material-icons">save</i>&nbsp;
                    Save
                </button>
            </div>

            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        <i class="material-icons">label</i>
                    </span>
                </div>
                <input type="text" class="form-control" placeholder="Input the tag" id="tagsInput">
            </div><br/>
            <?php endif; ?>

            <div class="messaging">
                <div class="inbox_msg">
                    <div class="inbox_people">
                        <div class="headind_srch">
                            <div class="recent_heading">
                            </div>
                            <div class="srch_bar">
                                <div class="stylish-input-group" style="display:none">
                                    <input type="text" class="search-bar"  placeholder="Search" >
                                    <span class="input-group-addon">
                                        <button type="button"> <i class="fa fa-search" aria-hidden="true"></i> </button>
                                    </span> 
                                </div>
                            </div>
                        </div>
                        <div class="inbox_chat">
                            <?php $__currentLoopData = $list_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="chat_list <?php echo e($list->id == $typeid ? 'active_chat' : ''); ?>">
                                    <div class="chat_people" style="cursor: pointer;" onclick="location.href=`<?php echo e(url('chat/'.$type.'/'.$list->id)); ?>`">
                                        <?php if($type == 1): ?>
                                            <div class="chat_img">
                                                <img src="<?php echo e($list->photo); ?>" alt="<?php echo e($list->name); ?>">
                                            </div>
                                            <div class="chat_ib">
                                                <h5><?php echo e($list->name); ?> <span class="chat_date"><?php echo e(date('H:i | M d', strtotime($list->created_at))); ?></span></h5>
                                                <h5><?php echo e($list->users != null ? count($list->users) : 0); ?> Members</h5>
                                            </div>
                                            <!-- D MMM HH:mm -->
                                        <?php else: ?> 
                                            <div class="row">
                                                <div class="col">
                                                    <?php if(is_object($list->user1)): ?>
                                                        <div class="chat_img" style="width:30%">
                                                            <img src="<?php echo e($list->user1->avatar); ?>" alt="<?php echo e($list->user1->nickname); ?>">
                                                        </div>
                                                        <div class="chat_ib" style="width:70%">
                                                            <h5><?php echo e($list->user1->name); ?>, <?php echo e($list->user1->surname); ?></h5>
                                                            <h5><?php echo e($list->user1->phonenumber); ?></h5>
                                                            <h5><?php echo e($list->user1->nickname); ?></h5>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col">
                                                    <?php if(is_object($list->user2)): ?>
                                                        <div class="chat_img" style="width:30%; float:right">
                                                            <img src="<?php echo e($list->user2 && $list->user2->avatar); ?>" alt="<?php echo e($list->user2->nickname); ?>">
                                                        </div>
                                                        <div class="chat_ib" style="width:70%; padding-right:10%; text-align:right">
                                                            <h5><?php echo e($list->user2->name); ?>, <?php echo e($list->user2->surname); ?></h5>
                                                            <h5><?php echo e($list->user2->phonenumber); ?></h5>
                                                            <h5><?php echo e($list->user2->nickname); ?></h5>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-12" style="text-align:right; margin-right:10%">
                                                    <?php if($list->active == 1): ?>
                                                        <img src="<?php echo e(asset('material')); ?>/img/closed.png" class="chat_closed" alt="...">
                                                    <?php endif; ?>
                                                    <span class="chat_date"><?php echo e(date('H:i | M d', strtotime($list->created_at))); ?></span>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="mesgs">
                        <div class="msg_history">
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($type == 3 && $message['user']['id'] == $typeid): ?>
                                    <div class="outgoing_msg">
                                        <div class="sent_msg_img">
                                            <img src="<?php echo e($message['user']['avatar']); ?>" alt="photo"> 
                                        </div>
                                        <div class="sent_msg">
                                            <button rel="tooltip" onclick="deleteMsg(`<?php echo e(url('chatDelete')); ?>/<?php echo e($key); ?>`)" data-original-title="Delete" title="Delete Message" class="delete_msg_btn delete_sent_msg"> 
                                                <i class="fa fa-close" aria-hidden="true"></i> 
                                            </button>
                                            <p>
                                                <span><?php echo e($message['user']['nickname']); ?></span><br>
                                                <?php
                                                    try {
                                                        if ($message['image'] != null && $message['image'] != "")
                                                        echo '<img src="'.$message['image'].'" alt="" style="max-width:100%; max-height:100px"><br/>';
                                                    } catch (\Throwable $th) {
                                                    }
                                                ?>
                                                <?php echo e($message['text']); ?>

                                            </p>
                                            <span class="time_date"><?php echo e(date('H:i | M d', $message['createdAt']/1000)); ?></span>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="incoming_msg">
                                        <div class="incoming_msg_img">
                                            <img src="<?php echo e($message['user']['avatar']); ?>" alt="photo"> 
                                        </div>
                                        <div class="received_msg">
                                         <div class="received_withd_msg">
                                                <button rel="tooltip" onclick="deleteMsg(`<?php echo e(url('chatDelete')); ?>/<?php echo e($key); ?>`)" data-original-title="Delete" title="Delete Message" class="delete_msg_btn"> 
                                                    <i class="fa fa-close" aria-hidden="true"></i> 
                                                </button>
                                                <p>
                                                    <span><?php echo e($message['user']['nickname']); ?></span><br>
                                                    <?php
                                                        try {
                                                            if ($message['image'] != null && $message['image'] != "")
                                                                echo '<img src="'.$message['image'].'" alt="" style="max-width:100%; max-height:100px"><br/>';
                                                        } catch (\Throwable $th) {
                                                        }
                                                    ?>
                                                    <?php echo e($message['text']); ?>

                                                    <br>
                                                    <?php if(is_array($message['tags'])): ?>
                                                        <?php $__currentLoopData = $message['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span style="padding:4px 10px 4px 10px; margin:5px; color:white; border-radius:10px; font-size: .8em; background-color: #524fff;"><?php echo e($tag); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </p>
                                                <span class="time_date" style="float:right"><?php echo e(date('H:i | M d', $message['createdAt']/1000)); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    let tags = jQuery.parseJSON(`<?php  echo json_encode($tags) ?>`);
    let tag_new_id = 0;
    let tagsinput = $('.tagsinput');
    tagsinput.tagsinput({
        itemValue: 'id',
        itemText: 'name',
        trimValue: true,
        backspace:false
    });
    tags.forEach(tag => {
        tagsinput.tagsinput('add', tag);
    });

    $("#tagsInput").on("keydown", function(e){
        if(e.keyCode ===9)
            e.preventDefault();

        if(e.keyCode == 13 && this.value != "" && this.value != null && this.value != undefined) {
            let added_tags = tagsinput.tagsinput('items');
            if(!added_tags.find(x => x.name == this.value))
                tagsinput.tagsinput('add', {id:tag_new_id--, name:this.value});
            this.value = "";
        }
    });
    var saveTags = function () {
        let tags = tagsinput.tagsinput('items');
        $.ajax({
            url: '<?php echo url('chat')?>',
            data:{tags:tags},
            method:'post',
            success: function(result){
                location.reload();
            },
            error:function(xhr,status,error){
                location.reload();
            }
        });
    }
    var deleteMsg = function(url){
        showNotification('Deleting message ...');
       
        if(!confirm("Really delete?"))
            return;
        $.ajax({
            url: url,
            dataType: 'json',
            type: 'get',
            success: function (json, textStatus, jqXHR) {
                location.reload();
            },
            error: function (data, textStatus, jqXHR) {
                showNotification('Some went wrong.');
            }
        });
    }
    function showNotification(msg){
        $.notify({
            icon: "delete_sweep",
            message: msg

        },{
            type: 'success',
            timer: 3000,
            placement: {
                from: 'top',
                align: 'right'
            }
        });
        }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'chat', 'titlePage' => __('Chat Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\scnp\resources\views/chat/index.blade.php ENDPATH**/ ?>