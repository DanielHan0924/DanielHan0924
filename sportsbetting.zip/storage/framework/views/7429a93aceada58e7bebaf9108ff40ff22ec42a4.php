<div class="sidebar" data-color="purple" data-background-color="black" >
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="/home" class="simple-text logo-normal" style="text-transform: none;">
      <?php echo e(__('Intraclub | SCNP')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home.index')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Dashboard')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'slider' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('slider.index')); ?>">
          <i class="material-icons">perm_media</i>
            <p><?php echo e(__('Slider Image Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'user' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
          <i class="material-icons">account_circle</i>
            <p><?php echo e(__('User Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'role' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('role.index')); ?>">
          <i class="material-icons">account_circle</i>
            <p><?php echo e(__('Rights Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'transaction' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('transaction.index')); ?>">
          <i class="material-icons">subtitles</i>
            <p><?php echo e(__('Transaction Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'groups' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('group.index')); ?>">
          <i class="material-icons">group</i>
            <p><?php echo e(__('Group Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'news' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('news.index')); ?>">
          <i class="material-icons">chat</i>
            <p><?php echo e(__('News Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'email' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('email.index')); ?>">
          <i class="material-icons">local_post_office</i>
            <p><?php echo e(__('Email Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'championship' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('championship.index')); ?>">
          <i class="material-icons">grade</i>
            <p><?php echo e(__('Championship Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'matches' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('matches.index')); ?>">
          <i class="material-icons">sports_volleyball</i>
            <p><?php echo e(__('Matches Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'chat' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('chat/0/0')); ?>">
          <i class="material-icons">forumbee</i>
            <p><?php echo e(__('chat Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'comments' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('comments.index')); ?>">
          <i class="material-icons">more_horiz</i>
            <p><?php echo e(__('Comments Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'report' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('report.index')); ?>">
          <i class="material-icons">report_problem</i>
            <p><?php echo e(__('Report Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'conditions' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('conditions.index')); ?>">
          <i class="material-icons">article</i>
            <p><?php echo e(__('Conditions Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'exercise' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('exercise.index')); ?>">
          <i class="material-icons">shuffle</i>
            <p><?php echo e(__('Tactics Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'coachrole' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('coachrole.index')); ?>">
          <i class="material-icons">how_to_reg</i>
            <p><?php echo e(__('Call Players')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'notification' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('notification.index')); ?>">
          <i class="material-icons">access_alarm</i>
            <p><?php echo e(__('Notification History')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'services_setting' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('services-setting.index')); ?>">
          <i class="material-icons">access_alarm</i>
            <p><?php echo e(__('Services Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'services_transaction' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('services-transaction.index')); ?>">
          <i class="material-icons">subtitles</i>
            <p><?php echo e(__('Service Transaction')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'services' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('services.index')); ?>">
          <i class="material-icons">access_alarm</i>
            <p><?php echo e(__('Services')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'service_history' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('services-history.index')); ?>">
          <i class="material-icons">history_toggle_off</i>
            <p><?php echo e(__('Service History')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'booking' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('booking.index')); ?>">
          <i class="material-icons">history</i>
            <p><?php echo e(__('Booking History')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'shop' ? ' active' : ''); ?>">
        <a class="nav-link"href="<?php echo e(route('product.index')); ?>">
          <i class="material-icons">shop</i>
            <p><?php echo e(__('Scnp Shop')); ?></p>
        </a>
      </li>
    </ul>
  </div>
</div><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>