<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary row">
        <h4 class="card-title"><?php echo e(__('Matches Management')); ?></h4>
      </div>
      <div class="card-body row">
        <?php if(session('status')): ?>
        <div class="col-sm-12">
          <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <i class="material-icons">close</i>
            </button>
            <span><?php echo e(session('status')); ?></span>
          </div>
        </div>
        <?php endif; ?>
        <div class="col-md-4">
          <form method="post" action="<?php echo e($type == 'update' ? route('matches.update', $edt_matches) : route('matches.store')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data" id="matchForm">
            <?php echo csrf_field(); ?>
            <?php if($type == 'update'): ?>
              <?php echo method_field('put'); ?>
            <?php endif; ?>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <select class="selectpicker" name="teamA_id" data-style="btn btn-primary" value='0'>
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option <?php echo ($edt_matches != null && $edt_matches->teamA_id == $group->id ? "selected" : "") ?> value="<?php echo e($group->id); ?>">
                      <?php echo e($group->name); ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <select class="selectpicker" name="teamB_id" data-style="btn btn-primary" value='0'>
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option <?php echo ($edt_matches != null && $edt_matches->teamB_id == $group->id ? "selected" : "") ?> value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-check" style="text-align: right;">
                  <label class="form-check-label">
                    <input class="form-check-input" name='match_type' id='match_type' type="checkbox" value="checked" checked onChange="changeType()"> 3 Sets
                    <span class="form-check-sign">
                      <span class="check"></span>
                    </span>
                  </label>
                </div>
              </div>
              <div class="col-md-4">
                <input class="form-control" name="short_score" id="short_score" style="text-align: center; font-size:26px; font-weight:bold" readonly value="<?php echo e($edt_matches != null ? $edt_matches->short_score:'0-0'); ?>"/>
              </div>
              <div class="col-md-4">
                <span id="live_match_txt" class="hidden" name="live_match_txt" style="color:red; font-size:20px; font-weight: bold;">LIVE</span>
                <input type="hidden" name="live_match" id="live_match" value="false">
              </div>
              <div class="col-md-12 has-error" id="validate_score">
                <input class="form-control" name="score" id="score" style="text-align: center; font-size:18px" placeholder="<?php echo e(__('Match score')); ?>" value="<?php echo e($edt_matches != null ? $edt_matches->score:''); ?>" onChange="changeScore()" />
              </div>
              <div class="col-md-6">
                <input class="form-control" style="text-align:center; margin-top:20px" name="date" type="date"  placeholder="<?php echo e(__('Date')); ?>" value="<?php echo e($edt_matches != null ? $edt_matches->date : date('Y-m-d')); ?>" required/>
              </div>
              <div class="col-md-6">
              <div class="form-group">
                  <select class="selectpicker" name="championid" data-style="btn btn-primary" value='0'>
                    <option <?php echo ($edt_matches == null && "selected") ?> value="0">Select Champion</option>
                    <?php $__currentLoopData = $championships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $championship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option <?php echo ($edt_matches != null && $edt_matches->championid == $championship->id ? "selected" : "") ?> value="<?php echo e($championship->id); ?>">
                      <?php echo e($championship->title); ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </div>
            <br/>
            <div class="col-md-12" style="text-align: center;">
              <?php if($type == 'update'): ?>
                <button type="submit" class="btn btn-primary" style="margin-right:10px"><?php echo e(__('Save')); ?></button>
                <a href="<?php echo e(route('matches.index')); ?>"  class="btn btn-primary"><?php echo e(__('Cancel')); ?></a>
              <?php else: ?>
                <button type="submit" class="btn btn-primary"><?php echo e(__('Add')); ?></button>
              <?php endif; ?>
            </div>
          </form>
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Match Notification</h4>
              <h6 class="card-subtitle mb-2 text-muted" style="text-transform: none;"><span id="notify_example"></span></h6><br/>
              <ul id="sortable">
              </ul>
              <div style="width:100px; float:right; border:1px dotted gray" id="canAdd">
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-8 fresh-datatables">
          <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
            <thead class=" text-primary">
            <tr >
              <th><?php echo e(__('No')); ?></th>
              <th><?php echo e(__('A Team')); ?></th>
              <th><?php echo e(__('B Team')); ?></th>
              <th><?php echo e(__('Score')); ?></th>
              <th><?php echo e(__('Championship')); ?></th>
              <th><?php echo e(__('Date')); ?></th>
              <th><?php echo e(__('Status')); ?></th>
              <th><?php echo e(__('Action')); ?></th>
            </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($index+1); ?></td>
                  <td rel="tooltip"  data-original-title="<?php echo e($match->teamA->name); ?>" title="<?php echo e($match->teamA->name); ?>">
                    <img src="<?php echo e($match->teamA->photo); ?>" style="width:40px; height:40px; border-radius:50%" alt="">
                    <br/>
                    <?php echo e($match->teamA->name); ?>

                  </td>
                  <td rel="tooltip"  data-original-title="<?php echo e($match->teamB->name); ?>" title="<?php echo e($match->teamB->name); ?>">
                    <img src="<?php echo e($match->teamB->photo); ?>" style="width:40px; height:40px; border-radius:50%" alt="">
                    <br/>
                    <?php echo e($match->teamB->name); ?>

                  </td>
                  <td><h4><?php echo e($match->short_score); ?></h4><?php echo e($match->score); ?></td>
                  <td><?php echo e($match->championShip ? $match->championShip->title : ''); ?></td>
                  <td><?php echo e($match->date); ?></td>
                  <td>
                    <?php if($match->live == 1): ?>
                    <span style="color:red; font-size:16px; font-weight: bold;">LIVE</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <form action="<?php echo e(route('matches.destroy', $match)); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('delete'); ?>
                      <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(route('matches.edit', $match)); ?>" data-original-title="Edit" title="Edit">
                        <i class="material-icons">edit</i>
                        <div class="ripple-container"></div>
                      </a>
                      <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this match?")); ?>') ? this.parentElement.submit() : ''">
                          <i class="material-icons">close</i>
                          <div class="ripple-container"></div>
                      </button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
	  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="<?php echo e(asset('material')); ?>/js/pages/matches.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'matches', 'titlePage' => __('Matches Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\scnp\resources\views/matches/index.blade.php ENDPATH**/ ?>