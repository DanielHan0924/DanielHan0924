

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php if($errors->has('email')): ?>
            <div class="row">
              <div class="col-sm-12">
                <div class="alert alert-danger">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                  </button>
                  <span><?php echo e($errors->first('email')); ?></span>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <form method="post" action="<?php echo e(route('user.store')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Add User')); ?></h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body row">
                <div class="col-md-12 text-right">
                    <a href="<?php echo e(route('user.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="row">
                    <div class="col-md-4 row" style="justify-content: center; align-content: center;">
                      <div class="fileinput text-center fileinput-new" data-provides="fileinput">
                        <div class="fileinput-new thumbnail img-circle">
                          <img src="<?php echo e(asset('material')); ?>/img/default.png" alt="...">
                        </div>
                        <div class="fileinput-preview fileinput-exists thumbnail img-circle" style=""></div>
                        <div>
                          <span class="btn btn-round btn-rose btn-file">
                            <span class="fileinput-new"> Photo</span>
                            <span class="fileinput-exists">Change</span>
                            <input type="file" name="photo_path">
                          <div class="ripple-container"></div></span>
                          <br>
                          <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove<div class="ripple-container"><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div></div></a>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-8 row">
                      <label class="col-md-2 col-form-label"><?php echo e(__('Name')); ?></label>
                      <div class="col-md-4">
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="input-name" type="text" placeholder="<?php echo e(__('Name')); ?>" value="" required="true" aria-required="true"/>
                          <?php if($errors->has('name')): ?>
                            <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('name')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <label class="col-md-2 col-form-label"><?php echo e(__('SurName')); ?></label>
                      <div class="col-md-4">
                        <div class="form-group<?php echo e($errors->has('surname') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('surname') ? ' is-invalid' : ''); ?>" name="surname" id="input-surname" type="text" placeholder="<?php echo e(__('SurName')); ?>" value="" required="true" aria-required="true"/>
                          <?php if($errors->has('surname')): ?>
                            <span id="name-error" class="error text-danger" for="input-surname"><?php echo e($errors->first('lastName')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <label class="col-sm-2 col-form-label"><?php echo e(__('Email')); ?></label>
                      <div class="col-sm-4">
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="input-email" type="email" placeholder="<?php echo e(__('Email')); ?>" value="" required />
                          <?php if($errors->has('email')): ?>
                            <span id="email-error" class="error text-danger" for="input-email"><?php echo e($errors->first('email')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <label class="col-sm-2 col-form-label" for="input-password"><?php echo e(__('Password')); ?></label>
                      <div class="col-sm-4">
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" id="input-password" type="password" placeholder="<?php echo e(__('Password')); ?>" value="" />
                          <?php if($errors->has('password')): ?>
                            <span id="password-error" class="error text-danger" for="input-password"><?php echo e($errors->first('password')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <label class="col-md-2 col-form-label"><?php echo e(__('Nick name')); ?></label>
                      <div class="col-md-4">
                        <div class="form-group<?php echo e($errors->has('nickname') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('nickname') ? ' is-invalid' : ''); ?>" name="nickname" id="input-nickname" type="text" placeholder="<?php echo e(__('Nick name')); ?>" value="" required="true" aria-required="true"/>
                          <?php if($errors->has('nickname')): ?>
                            <span id="name-error" class="error text-danger" for="input-nickname"><?php echo e($errors->first('lastName')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <label class="col-sm-2 col-form-label"><?php echo e(__('Phone number')); ?></label>
                      <div class="col-sm-4">
                        <div class="form-group<?php echo e($errors->has('phonenumber') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('phonenumber') ? ' is-invalid' : ''); ?>" name="phonenumber" id="input-phonenumber" type="phonenumber" placeholder="<?php echo e(__('Phone number')); ?>" value="" required />
                          <?php if($errors->has('phonenumber')): ?>
                            <span id="phonenumber-error" class="error text-danger" for="input-phonenumber"><?php echo e($errors->first('phonenumber')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <label class="col-sm-2 col-form-label"><?php echo e(__('Age')); ?></label>
                      <div class="col-sm-4">
                        <div class="form-group<?php echo e($errors->has('age') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('age') ? ' is-invalid' : ''); ?>" name="age" id="input-age" type="number" placeholder="<?php echo e(__('Age')); ?>" required min='3' max="100" />
                          <?php if($errors->has('age')): ?>
                            <span id="age-error" class="error text-danger" for="input-age"><?php echo e($errors->first('age')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <label class="col-sm-2 col-form-label"><?php echo e(__('Motto')); ?></label>
                      <div class="col-sm-4">
                        <div class="form-group<?php echo e($errors->has('motto') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('motto') ? ' is-invalid' : ''); ?>" name="motto" id="input-motto" type="text" placeholder="<?php echo e(__('Motto')); ?>" value="" required />
                          <?php if($errors->has('motto')): ?>
                            <span id="motto-error" class="error text-danger" for="input-motto"><?php echo e($errors->first('motto')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <label class="col-sm-2 col-form-label" for="input-password-confirmation"><?php echo e(__('Gender')); ?></label>
                      <div class="col-sm-4">
                        <div class="form-group">
                          <select class="selectpicker" name="sex" data-style="btn btn-primary" value="0">
                            <option value="0" selected >Male</option>
                            <option value="1">Female</option>
                          </select>
                        </div>
                      </div>
                      <!-- -------------------------------------------------------------------- -->
                      <label class="col-sm-2 col-form-label group" for="input-password-confirmation"><?php echo e(__('Group')); ?></label>
                      <div class="col-sm-4 group">
                        <div class="form-group">
                          <select class="selectpicker" name="groupid" data-style="btn btn-primary" value="0">
                            <option value="0" selected >Select Group</option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <!-- -------------------------------------------------------------------- -->
                      <label class="col-sm-2 col-form-label" for="input-password-confirmation"><?php echo e(__('User Type')); ?></label>
                      <div class="col-sm-4">
                        <div class="form-group">
                        <select class="selectpicker" name="role" data-style="btn btn-primary" title="Role"  onChange="changeRole(this.value)">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($item->id); ?>" <?php echo ($index == 0 ? 'selected' : '')?>><?php echo e($item->role); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>

                      <!-- -------------------------------------------------------------------- -->
                      <label class="col-sm-2 col-form-label group" for="input-password-confirmation"><?php echo e(__('Group')); ?></label>
                      <div class="col-sm-4 group">
                        <div class="form-group">
                          <select class="selectpicker" name="group1id" id="group" data-style="btn btn-primary" value="0">
                            <option value="0" selected >Select Group</option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <!-- -------------------------------------------------------------------- -->

                      <label class="col-sm-2 col-form-label" for="input-password-confirmation"><?php echo e(__('Positions')); ?></label>
                      <div class="col-sm-4">
                        <div class="form-group">
                          <select class="selectpicker" name="position_id" data-style="btn btn-primary" value="0">
                            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($position->id); ?>"><?php echo e($position->position); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>

                       <!-- -------------------------------------------------------------------- -->
                       <label class="col-sm-2 col-form-label group" for="input-password-confirmation"><?php echo e(__('Group')); ?></label>
                      <div class="col-sm-4 group">
                        <div class="form-group">
                          <select class="selectpicker" name="group2id" id="group" data-style="btn btn-primary" value="0">
                            <option value="0" selected >Select Group</option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <!-- -------------------------------------------------------------------- -->
                      <div class="col-sm-6"></div>
                      <!-- -------------------------------------------------------------------- -->
                      <label class="col-sm-2 col-form-label group" for="input-password-confirmation"><?php echo e(__('Group')); ?></label>
                      <div class="col-sm-4 group">
                        <div class="form-group">
                          <select class="selectpicker" name="group3id" id="group" data-style="btn btn-primary" value="0">
                            <option value="0" selected >Select Group</option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <!-- -------------------------------------------------------------------- -->
                      <div class="col-sm-6"></div>
                      <!-- -------------------------------------------------------------------- -->
                      <label class="col-sm-2 col-form-label group" for="input-password-confirmation"><?php echo e(__('Group')); ?></label>
                      <div class="col-sm-4 group">
                        <div class="form-group">
                          <select class="selectpicker" name="group4id" id="group" data-style="btn btn-primary" value="0">
                            <option value="0" selected >Select Group</option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <!-- -------------------------------------------------------------------- -->
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer text-right">
                <div class="form-check mr-auto">
                  <label class="form-check-label">
                    <input class="form-check-input" name='email-sending' type="checkbox" value="checked" checked> Send password to email.
                    <span class="form-check-sign">
                      <span class="check"></span>
                    </span>
                  </label>
                </div>
                <button type="submit" class="btn btn-primary">Register</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        var changeRole = function(value){
          value = parseInt(value);
          console.log(value);
          if(value == 6 || value == 3)
            $(".group").addClass("group_select");
          else
            $(".group").removeClass("group_select");
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'user', 'titlePage' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\scnp\resources\views/users/create.blade.php ENDPATH**/ ?>