<footer class="footer">
  <div class="container-fluid">
  </div>
</footer><?php /**PATH F:\sportsbetting\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>