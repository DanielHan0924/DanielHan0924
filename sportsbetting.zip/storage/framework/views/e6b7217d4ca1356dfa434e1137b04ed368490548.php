<footer class="footer">
    <div class="container">
    </div>
</footer><?php /**PATH F:\sportsbetting\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>