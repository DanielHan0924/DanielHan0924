<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="card registration">
        <div class="card-header card-header-primary">
          <h4 class="card-title"><?php echo e(__('Groups Management')); ?></h4>
        </div>
        <div class="card-body ">
          <?php if(session('status')): ?>
            <div class="row">
              <div class="col-sm-12">
                <div class="alert alert-success">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                  </button>
                  <span><?php echo e(session('status')); ?></span>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <div class="row">
            <div class="col-sm-4">
                <a href="<?php echo e(route('group.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add Group')); ?></a>
            </div>
		  </div>
		  
		  <div class="fresh-datatables">
			<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
			  <thead class=" text-primary">
				<tr >
				  <th> <?php echo e(__('No')); ?> </th>
				  <th> <?php echo e(__('Image')); ?> </th>
				  <th> <?php echo e(__('Group Name')); ?> </th>
				  <th> <?php echo e(__('Member')); ?> </th>
				  <th> <?php echo e(__('Create Date')); ?> </th>
				  <th style="width:120px"> <?php echo e(__('Order')); ?> </th>
				  <th style="width:160px"> <?php echo e(__('Action')); ?> </th>
				</tr>
			  </thead>
			  <tbody>
          <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($index+1); ?></td>
              <td rel="tooltip"  data-original-title="<?php echo e($group->name); ?>" title="<?php echo e($group->name); ?>">
                <img src="<?php echo e($group->photo); ?>" style="max-width:120px; max-height:120px; border-radius:50%">
              </td>
              <td><?php echo e($group->name); ?></td>
              <td><?php echo e(count($group->users)); ?></td>
              <td><?php echo e($group->created_at); ?></td>
              <td>
                <?php if($group->isteam == 0): ?>
                <div class="input-group">
                  <input type="number" id="order_<?php echo e($group->id); ?>" value="<?php echo e($group->order); ?>" class="form-control" style="text-align:center; font-size:16px;" min="0">
                  <div class="input-group-append">
                    <span class="input-group-text">
                    <a rel="tooltip" data-original-title="Change Order" title="Change Order" onclick="saveOrder(`<?php echo e(url('group/order')); ?>`, `<?php echo e($group->id); ?>`)" style="cursor:pointer">
                      <i class="material-icons" style="font-size: 1.2rem; color:#4caf50">save</i>
                    </a>
                    </span>
                  </div>
                </div>
                <?php else: ?>
                  Team
                <?php endif; ?>
              </td>
              <td>
                <form class="row" action="<?php echo e(route('group.destroy', $group)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('delete'); ?>
                  <div class="col-md-6">
                    <?php if($group->isteam == 0): ?>
                      <a rel="tooltip" class="btn btn-success btn-sm btn-link" href="<?php echo e(url('group/up')); ?>/<?php echo e($group->id); ?>" data-original-title="Up" title="Up" <?php echo $index != 0 ? '' :'hidden' ?>>
                        <i class="material-icons" style="font-size: 1.8rem;">expand_less</i>
                        <div class="ripple-container"></div>
                      </a>
                      <a rel="tooltip" class="btn btn-success btn-sm btn-link" href="<?php echo e(url('group/down')); ?>/<?php echo e($group->id); ?>" data-original-title="Down" title="Down" <?php echo $index != count($groups)-1 ? '' :'hidden' ?>>
                        <i class="material-icons" style="font-size: 1.8rem;">expand_more</i>
                        <div class="ripple-container"></div>
                      </a>
                    <?php endif; ?>
                  </div>
                  <div class="col-md-6">
                    <a rel="tooltip" class="btn btn-success btn-sm btn-link" href="<?php echo e(route('group.edit', $group)); ?>" data-original-title="Edit" title="Edit">
                      <i class="material-icons">edit</i>
                      <div class="ripple-container"></div>
                    </a>
                    <button type="button" class="btn btn-danger btn-sm btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this group?")); ?>') ? this.parentElement.submit() : ''">
                        <i class="material-icons">close</i>
                        <div class="ripple-container"></div>
                    </button>
                  </div>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </tbody>
			</table>
		  </div>
        </div>
	  </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
  const saveOrder = function(url, id) {
    const order_input = $(`#order_${id}`);
    const order = parseInt(order_input.val());
    if(order <= 0) {
      order_input.focus();
      order_input.select();
    }
    $.ajax({
      url: url,
      data:{id:id, order:order},
      method:'post',
      success: function(result){
        location.reload();
      },
      error:function(xhr,status,error){
        location.reload();
      }
    });
  }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'groups', 'titlePage' => __('Groups Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\scnp\resources\views/group/index.blade.php ENDPATH**/ ?>