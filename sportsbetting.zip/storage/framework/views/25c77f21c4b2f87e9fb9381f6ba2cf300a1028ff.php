<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="card registration">
        <div class="card-header card-header-primary row">
          <h4 class="card-title col-md-6" style="margin-top:10px">
          <?php if($type == 0): ?>
              Cart History
            <?php elseif($type == 1): ?>
              Completed
            <?php elseif($type == 2): ?>
              Pending
            <?php elseif($type == 3): ?>
              Trash
            <?php endif; ?>
          </h4>
          <div class="col-md-6 text-right">
            <div class="btn-group" style="margin:0">
              <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php if($type == 0): ?>
                    All
                <?php elseif($type == 1): ?>
                  Completed
                <?php elseif($type == 2): ?>
                    Pending
                <?php elseif($type == 3): ?>
                    Trash
                <?php endif; ?>
              </button>
              <div class="dropdown-menu">
                  <a class="dropdown-item" href="<?php echo e(url('cart/0')); ?>">All</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="<?php echo e(url('cart/1')); ?>">Completed</a>
                  <a class="dropdown-item" href="<?php echo e(url('cart/2')); ?>">Pending</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="<?php echo e(url('cart/3')); ?>">Trash</a>
              </div>
            </div>
          </div>
        </div>
        <div class="card-body ">
          <?php if(session('status')): ?>
            <div class="row">
              <div class="col-sm-12">
                <div class="alert alert-success">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                  </button>
                  <span><?php echo e(session('status')); ?></span>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <div class="row">
            <div class="col-md-4">
            </div>
          </div>
          <div class="fresh-datatables">
            <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
              <thead class=" text-primary">
              <tr >
                <th> <?php echo e(__('No')); ?> </th>
                <th> <?php echo e(__('Name')); ?> </th>
                <th> <?php echo e(__('User name')); ?> </th>
                <th> <?php echo e(__('Number')); ?> </th>
                <th> <?php echo e(__('Price')); ?> </th>
                <th> <?php echo e(__('Date')); ?> </th>
                <?php if($type == 0): ?>
                  <th> <?php echo e(__('status')); ?> </th>
                <?php endif; ?>
                <th style="width:60px"> <?php echo e(__('Action')); ?> </th>
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($index+1); ?></td>
                    <td><?php echo e($cart->product->title); ?></td>
                    <td>
                      <?php if($cart->user): ?>
                        <?php echo e($cart->user->name); ?> <?php echo e($cart->user->surname); ?>

                      <?php else: ?>
                        Deleted user
                      <?php endif; ?>
                    </td>
                    <td><?php echo e($cart->number); ?></td>
                    <td><?php echo $cart->product->price*$cart->number?> €</td>
                    <td><?php echo e(date('d M Y', strtotime($cart->updated_at))); ?></td>
                    <?php if($type == 0): ?>
                      <th> 
                      <?php if($cart->state == 0): ?>
                      <?php echo e(__('Cart')); ?>

                      <?php elseif($cart->state == 1): ?>
                      <?php echo e(__('Completed')); ?>

                      <?php else: ?>
                      <?php echo e(__('Deleted')); ?>

                      <?php endif; ?>
                      </th>
                    <?php endif; ?>
                    <td>
                      <form class="row" action="<?php echo e(url('cart/delete')); ?>/<?php echo e($cart->id); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <button type="button" rel="tooltip" class="btn btn-danger btn-sm btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this cart?")); ?>') ? this.parentElement.submit() : ''">
                            <i class="material-icons">close</i>
                            <div class="ripple-container"></div>
                        </button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'shop', 'titlePage' => __('Shop Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/shop/cart.blade.php ENDPATH**/ ?>