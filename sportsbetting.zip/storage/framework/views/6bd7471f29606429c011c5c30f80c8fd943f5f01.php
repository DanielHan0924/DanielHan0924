<?php $__env->startPush('css'); ?>
  <style>
    input{
      text-align:center;
    }
    .togglebutton label .toggle_same_color{
      background-color: rgb(186, 103, 200)
    }
    .togglebutton label .toggle_same_color:after{
      border-color: #9c27b0;
    }
  </style>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Services')); ?></h4>
      </div>
      <div class="card-body">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <div class="row">
          <form method="post" action="<?php echo e(route('services-setting.update', 0)); ?>" autocomplete="off" class="form-horizontal col-md-5" enctype="multipart/form-data" id="services_form">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col" style="text-align:left;">
                <h4>Service Screen</h4>
              </div>
              <div class="col" style="text-align:right;">
                <input type="submit" value="Save" class="btn btn-primary btn-sm">
              </div>
            </div>
            <table class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center' id="services_list_table">
              <thead class=" text-primary">
              <tr>
                <th style="width:210px"> <?php echo e(__('Image')); ?> </th>
                <th> <?php echo e(__('Title (en)')); ?> </th>
                <th> <?php echo e(__('Title (fr)')); ?> </th>
                <th> <?php echo e(__('free')); ?> </th>
                <th> <?php echo e(__('Coming')); ?> </th>
                <th> <?php echo e(__('Hide')); ?> </th>
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" name="service_ids[]" id="service_<?php echo e($index); ?>" value="<?php echo e($service->id); ?>">
                <tr value="<?php echo e($service->id); ?>">
                  <td>
                    <img src="<?php echo e($service->image); ?>" alt="" style="max-width:120px; max-height:120px">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="title_en[]" id="" value="<?php echo e($service->title_en); ?>">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="title_fr[]" id="" value="<?php echo e($service->title_fr); ?>">
                  </td>
                  <td class="togglebutton">
                    <label style="margin-top:-20px">
                      <input type="checkbox" class="role_switch" value="<?php echo e($service->id); ?>" name="free[]" <?php echo ($service->free == 1 ? "checked" : '') ?>>
                      <span class="toggle"></span>
                    </label>
                  </td>
                  <td class="togglebutton">
                    <label style="margin-top:-20px">
                      <input type="checkbox" class="" value="<?php echo e($service->id); ?>" name="coming[]" <?php echo ($service->coming == 1 ? "checked" : '') ?>>
                      <span class="toggle"></span>
                    </label>
                  </td>
                  <td class="togglebutton">
                    <label style="margin-top:-20px">
                      <input type="checkbox" class="" value="<?php echo e($service->id); ?>" name="hide[]" <?php echo ($service->show == 1 ? "checked" : '') ?>>
                      <span class="toggle"></span>
                    </label>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </form>
         
          <form method="post" action="<?php echo e(route('services-setting.update', 1)); ?>" autocomplete="off" class="form-horizontal col-md-4" enctype="multipart/form-data" id="setting_form">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col" style="text-align:left;">
                <h4>Service Setting</h4>
              </div>
              <div class="col" style="text-align:right;">
                <input type="submit" value="Save" class="btn btn-primary btn-sm">
              </div>
            </div>
            <table class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
              <thead class=" text-primary">
              <tr>
                <th style="width:40px"> <?php echo e(__('No')); ?> </th>
                <th style="width:120px"> <?php echo e(__('Title')); ?> </th>
                <th style="width:60px"> <?php echo e(__('Price')); ?> </th>
                <th style="width:40px"> <?php echo e(__('Currenty')); ?> </th>
                <th> <?php echo e(__('Description')); ?> </th>
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" name="setting_ids[]" value="<?php echo e($setting->id); ?>">
                <?php if($index == 0 || $index == 3): ?>
                  <tr>
                    <td colspan="6" style="text-align:left">
                      <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(($index == 0 && $serv->id == 2) || ($index == 3 && $serv->id == 3)): ?>
                          <span><?php echo e($serv->title_en); ?></span>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                  </tr>
                <?php endif; ?>
                <tr>
                  <td>
                    <?php echo e($index+1); ?>

                  </td>
                  <td>
                    <input type="text" class="form-control" name="setting_title[]" id="" value="<?php echo e($setting->title); ?>">
                  </td>
                  <td>
                    <input type="number" class="form-control" name="setting_price[]" id="" value="<?php echo e($setting->price); ?>">
                  </td>
                  <td>
                    <input type="text" class="form-control" name="setting_currency[]" id="" value="<?php echo e($setting->currency); ?>" disabled>
                  </td>
                  <td>
                    <input type="text" class="form-control" name="setting_description[]" id="" value="<?php echo e($setting->description); ?>">
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </form>

          <form method="post" action="<?php echo e(route('services-setting.update', 2)); ?>" autocomplete="off" class="form-horizontal col-md-3" enctype="multipart/form-data" id="categories_form">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col" style="text-align:left;">
                <h4>Service Categories</h4>
              </div>
              <div class="col" style="text-align:right;">
                <input type="button" value="Create" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addModal">
                <input type="submit" value="Save" class="btn btn-primary btn-sm">
              </div>
            </div>
            <table class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center' id="services_categories_table">
              <thead class=" text-primary">
              <tr>
                <th> <?php echo e(__('No')); ?> </th>
                <th> <?php echo e(__('Title')); ?> </th>
                <th > <?php echo e(__('Nutrition/Fitness')); ?> </th>
                <th > <?php echo e(__('Delete')); ?> </th>
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" name="category_ids[]" id="category_<?php echo e($index); ?>" value="<?php echo e($category->id); ?>">
                <tr value="<?php echo e($category->id); ?>">
                  <td>
                    <?php echo e($index+1); ?>

                  </td>
                  <td>
                    <input type="text" class="form-control" name="category_title[]" id="" value="<?php echo e($category->title); ?>">
                  </td>
                  <td>
                    <div class="togglebutton">
                      <label>
                        <input type="checkbox" value="<?php echo e($category->id); ?>" name="category_type[]" <?php echo ($category->type == 1 ? "checked" : '') ?>>
                        <span class="toggle toggle_same_color"></span>
                      </label>
                    </div>
                  </td>
                  <td>
                    <form class="row" action="<?php echo e(route('services-setting.destroy', $category)); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('delete'); ?>
                        <button type="button" rel="tooltip" class="btn btn-danger btn-sm btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this category?")); ?>') ? this.parentElement.submit() : ''">
                          <i class="material-icons">close</i>
                          <div class="ripple-container"></div>
                        </button>
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </form>

        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Slider Image</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="post" action="<?php echo e(route('services-setting.store')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
        <div class="modal-body row">
          <?php echo csrf_field(); ?>
          <div class="col-md-6">
          <input type="text" class="form-control" name="title" id="" placeholder="Category" required>
          </div>
          <div class="col-md-6 togglebutton">
            <label>
            Nutrition
              <input type="checkbox" value="type" name="type">
              <span class="toggle toggle_same_color"></span>
              Fitness
            </label>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
<script>
  const sortable_option = {
    cursor: "move",
    placeholder: "sortable-placeholder",
    helper: function(e, tr)
    {
      var $originals = tr.children();
      var $helper = tr.clone();
      $helper.children().each(function(index)
      {
      $(this).width($originals.eq(index).width());
      });
      return $helper;
    },      
  };

  $("#services_list_table tbody").sortable(sortable_option);

  $("#services_form").submit(function(event) {
    $('#services_list_table tbody tr').each(function (i, el) {
      let element = $("#services_list_table tbody").find(el);
      $(`#service_${i}`).val(element.attr('value'));
      });
  });
  $("#services_categories_table tbody").sortable(sortable_option);

  $("#categories_form").submit(function(event) {
    $('#services_categories_table tbody tr').each(function (i, el) {
      let element = $("#services_categories_table tbody").find(el);
      $(`#category_${i}`).val(element.attr('value'));
      });
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'services_setting', 'titlePage' => __('Services Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/serviceSetting/index.blade.php ENDPATH**/ ?>