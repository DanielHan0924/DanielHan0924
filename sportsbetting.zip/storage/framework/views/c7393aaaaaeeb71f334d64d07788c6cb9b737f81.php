<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Tactics')); ?></h4>
      </div>
      <div class="card-body ">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <div class="row">
          <div class="col-sm-4">
              <a href="<?php echo e(route('exercise.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add Tactics')); ?></a>
          </div>
          <div class="col-sm-8" style="text-align:right; margin-bottom:20px">
            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#themes_modal">
            <?php echo e(__('Theme Manage')); ?>

            </button>
          </div>
        </div>
        <div class="fresh-datatables">
          <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
            <thead class=" text-primary">
              <tr>
                <th style="width:80px"> <?php echo e(__('No')); ?> </th>
                <th style="width:120px"> <?php echo e(__('User Name')); ?> </th>
                <th style="width:120px"> <?php echo e(__('Coach Name')); ?> </th>
                <th> <?php echo e(__('Title')); ?> </th>
                <th style="width:120px"> <?php echo e(__('Theme')); ?> </th>
                <th style="width:300px"> <?php echo e(__('Purpose')); ?> </th>
                <th style="width:80px"> <?php echo e(__('Time(Minute)')); ?> </th>
                <th style="width:100px"> <?php echo e(__('Start')); ?> </th>
                <th style="width:120px"> <?php echo e(__('Players')); ?> </th>
                <th style="width:60px"> <?php echo e(__('State')); ?> </th>
                <th style="width:30px"> <?php echo e(__('Like')); ?> </th>
                <th style="width:180px"> <?php echo e(__('Action')); ?> </th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $exercise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$exerciseitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($index+1); ?></td>
                  <td>
                    <?php if($exerciseitem->user): ?>
                      <?php echo e($exerciseitem->user->name); ?> <?php echo e($exerciseitem->user->surname); ?> 
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if($exerciseitem->username): ?>
                      <?php echo e($exerciseitem->username); ?>

                    <?php endif; ?>
                  </td>
                  <td><?php echo e($exerciseitem->title); ?></td>
                  <td>
                    <?php if($exerciseitem->theme): ?>
                      <?php echo e($exerciseitem->theme->title); ?>

                    <?php endif; ?>
                  </td>
                  <td> <?php echo e($exerciseitem->purpose); ?> </td>
                  <td> <?php echo e($exerciseitem->time); ?> </td>
                  <td> <?php echo e($exerciseitem->start); ?> </td>
                  <td> <?php echo e($exerciseitem->players); ?> </td>
                  <td> <?php echo e($exerciseitem->state); ?> </td>
                  <td> <?php echo e($exerciseitem->like); ?> </td>
                  <td>
                    <form action="<?php echo e(route('exercise.destroy', $exerciseitem)); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('delete'); ?>
                      <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(route('exercise.edit', $exerciseitem)); ?>" data-original-title="Edit" title="Edit">
                        <i class="material-icons">edit</i>
                        <div class="ripple-container"></div>
                      </a>
                      <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this exercise?")); ?>') ? this.parentElement.submit() : ''">
                          <i class="material-icons">close</i>
                          <div class="ripple-container"></div>
                      </button>
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Theme -->
<div class="modal fade bd-example-modal-sm" id="themes_modal" tabindex="-1" role="dialog" aria-labelledby="themes_title" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="themes_title">Tactics themes management</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      <div class="modal-body row">
        <div class="col-md-8" style="text-align:left; bottom:-15px">
          Change order with Drag and Drop
        </div>
        <div class="col-md-4" style="text-align:right;">
          <button rel="tooltip" type="button" class="btn btn-danger btn-round btn-sm" data-original-title="Delete" title="Delete" onclick="addTheme()">
              <i class="material-icons">add</i>
          </button>
        </div>
        <table id="themes_table" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
        <thead>
          <tr>
            <td></td>
            <td style="width:200px"></td>
          </tr>
        </thead>
          <tbody id="themes_tbody">
            <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr id="themes_<?php echo e($index); ?>" value="<?php echo e($theme->id); ?>">
                <td id="themes_title_<?php echo e($index); ?>"><?php echo e($theme->title); ?></td>
                <td>
                  <a rel="tooltip" class="btn btn-success btn-link btn-sm" data-original-title="Edit" title="Edit" onclick="editTheme(<?php echo e($index); ?>)">
                    <i class="material-icons">edit</i>
                    <div class="ripple-container"></div>
                  </a>
                  <button rel="tooltip" type="button" class="btn btn-danger btn-link btn-sm" data-original-title="Delete" title="Delete" onclick="deleteTheme(<?php echo e($index); ?>)">
                      <i class="material-icons">close</i>
                      <div class="ripple-container"></div>
                  </button>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="saveThemes()">Save changes</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
  <script>
    let total_index = `<?php echo count($themes)?>`;
  </script>
  <script src="<?php echo e(asset('material')); ?>/js/pages/exercise.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'exercise', 'titlePage' => __('Tactics Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/exercise/index.blade.php ENDPATH**/ ?>