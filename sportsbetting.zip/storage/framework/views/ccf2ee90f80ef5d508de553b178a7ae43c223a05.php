

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php if($errors->has('name')): ?>
            <div class="row">
              <div class="col-sm-12">
                <div class="alert alert-danger">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                  </button>
                  <span><?php echo e($errors->first('name')); ?></span>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <form method="post" action="<?php echo e(route('product.update', $product)); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data" id="editForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Add Product')); ?></h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body row">
                <div class="col-md-12 text-right">
                    <a href="<?php echo e(route('product.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                </div>
                <div class="col-md-4" style="text-align:right">
                  <div class="fileinput text-center fileinput-new" data-provides="fileinput">
                    <div class="fileinput-new thumbnail">
                      <img src="<?php echo e($product->image); ?>" alt="...">
                    </div>
                    <div class="fileinput-preview fileinput-exists thumbnail" style=""></div>
                    <div>
                      <span class="btn btn-round btn-rose btn-file">
                        <span class="fileinput-new">Add Photo</span>
                        <span class="fileinput-exists">Change</span>
                        <input type="file" name="photo_path"  accept="image/*">
                      <div class="ripple-container"></div></span>
                      <br>
                      <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove<div class="ripple-container"><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div><div class="ripple-decorator ripple-on ripple-out" style="left: 80.0156px; top: 18px; background-color: rgb(255, 255, 255); transform: scale(15.5098);"></div></div></a>
                    </div>
                  </div>
                </div>
                <div class="col-md-7 row">
                  <div class="form-group col-md-8 <?php echo e($errors->has('title') ? ' has-danger' : ''); ?>">
                    <input class="form-control" name="title"  type="text"  placeholder="<?php echo e(__('Name')); ?>"  value="<?php echo e($product->title); ?>"  required/>
                  </div>
                  <div class="form-group col-md-4 <?php echo e($errors->has('title') ? ' has-danger' : ''); ?>">
                    <input class="form-control" name="price"  type="number"  placeholder="<?php echo e(__('Price')); ?>" value="<?php echo e($product->price); ?>"  step="0.01" required/>
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="colorInput form-control" data-role="colorInput">
                    <div class="input-group">
                      <div class="input-group-prepend"><span class="input-group-text"><i class="material-icons">label</i></span></div>
                      <input type="text" class="form-control" placeholder="Color" id="colorInput">
                    </div>
                    <div id="color_div" class="hidden"></div>
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="sizeInput form-control" data-role="sizeInput">
                    <div class="input-group">
                      <div class="input-group-prepend"><span class="input-group-text"><i class="material-icons">label</i></span></div>
                      <input type="text" class="form-control" placeholder="Size" id="sizeInput">
                    </div>
                    <div id="size_div" class="hidden"></div>
                  </div>
                  <div class="col-md-12 form-group">
                    <textarea name="description" class="form-control" id="" cols="30" rows="10" placeholder="Description"><?php echo e($product->description); ?></textarea>
                  </div>
                </div>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary">Register</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('material')); ?>/js/plugins/jasny-bootstrap.min.js"></script>
<script>
  let tags = [];
  tags[0] = jQuery.parseJSON(`<?php  echo json_encode($product->color) ?>`);
  tags[1] = jQuery.parseJSON(`<?php  echo json_encode($product->size) ?>`);

  let tag_new_id = [];
  let tagInput = [];
  let tagInputIds = ['colorInput', 'sizeInput'];
  tagInputIds.forEach((el, index) => {
    tag_new_id[index] = 0;
    tagInput[index] = $(`.${el}`);
    tagInput[index].tagsinput({
      itemValue: 'id',
      itemText: 'name',
      trimValue: true,
      backspace:false
    });
    if(tags[index] && tags[index].length > 0){
      tags[index].forEach((tag, tagIndex) => {
        tagInput[index].tagsinput('add', {id:tagIndex, name:tag});
      });
    }
    $(`#${el}`).on("keydown", function(e){changeEvent(this, e, index)});
  });
  
  function changeEvent(_this, e, index){
    if(e.keyCode === 13) e.preventDefault();
    else return;
    if(_this.value != "" && _this.value != null && _this.value != undefined) {
      let added_tags = tagInput[index].tagsinput('items');
        if(!added_tags.find(x => x.name == _this.value))
        tagInput[index].tagsinput('add', {id:tag_new_id[index]--, name:_this.value});
      _this.value = "";
    }
  }

  $("#editForm").submit(function(event) {
    let colors = tagInput[0].tagsinput('items');
    let sizes = tagInput[1].tagsinput('items');
    const color_div = $("#color_div");
    const size_div = $("#size_div");
    color_div.empty();
    size_div.empty();
    colors.forEach(element => {
      color_div.append(`<input name='colors[]' value='${element.name}'>`);
    });
    sizes.forEach(element => {
      size_div.append(`<input name='sizes[]' value='${element.name}'>`);
    });
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'shop', 'titlePage' => __('Products Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/shop/edit.blade.php ENDPATH**/ ?>