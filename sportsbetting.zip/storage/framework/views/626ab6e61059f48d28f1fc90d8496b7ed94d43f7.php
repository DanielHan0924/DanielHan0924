<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="card registration">
                <div class="card-header card-header-primary row">
                    <h4 class="card-title"><?php echo e(__('comments Management')); ?></h4>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo e(session('status')); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="fresh-datatables">
                        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
                            <thead class=" text-primary">
                                <tr >
                                    <th style="width:30%"> <?php echo e(__('News title')); ?> </th>
                                    <th> <?php echo e(__('user name')); ?> </th>
                                    <th style="width:30%"> <?php echo e(__('Comment')); ?> </th>
                                    <th> <?php echo e(__('Date')); ?> </th>
                                    <th> <?php echo e(__('Like/Dislike')); ?> </th>
                                    <th> <?php echo e(__('Action')); ?> </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($comment->news ? $comment->news->title : "deleted"); ?></td>
                                        <td><?php echo e($comment->user ? $comment->user->name : ""); ?></td>
                                        <td><?php echo e($comment->content); ?></td>
                                        <td><?php echo e(date('H:i d M Y', strtotime($comment->created_at))); ?></td>
                                        <td><?php echo e($comment->agree); ?>/<?php echo e($comment->disagree); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('comments.destroy', $comment)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete comment" title="Delete comment" onclick="confirm('<?php echo e(__("Are you sure you want to delete this comment?")); ?>') ? this.parentElement.submit() : ''">
                                                    <i class="material-icons">close</i>
                                                    <div class="ripple-container"></div>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'comments', 'titlePage' => __('Comments Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/comments/index.blade.php ENDPATH**/ ?>