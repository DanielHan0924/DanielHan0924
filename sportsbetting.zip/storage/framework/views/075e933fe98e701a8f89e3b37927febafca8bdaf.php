<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Services')); ?></h4>
      </div>
      <div class="card-body">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr>
            <th><?php echo e(__('No')); ?></th>
            <th><?php echo e(__('Title')); ?></th>
            <th><?php echo e(__('User name')); ?></th>
            <th><?php echo e(__('Transaction id')); ?></th>
            <th><?php echo e(__('Amount')); ?></th>
            <th><?php echo e(__('Date')); ?></th>
            <th><?php echo e(__('Cancel')); ?></th>
            <th><?php echo e(__('Delete')); ?></th>
          </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $service_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php echo e($index+1); ?>

                </td>
                <td>
                  <?php if($service->settings): ?>
                    <?php echo e($service->settings->title); ?>

                    <?php if($service->settings->type == 0): ?>
                      (Nutrition)
                    <?php else: ?>
                      (Fitness)
                    <?php endif; ?>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if($service->user): ?>
                    <?php echo e($service->user->name); ?> <?php echo e($service->user->surname); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <?php echo e($service->transactionid); ?>

                </td>
                <td>
                  <?php echo e($service->amount); ?> <?php echo e($service->currenty); ?>

                </td>
                <td><?php echo e(date('H:i d M Y', strtotime($service->created_at))); ?></td>
                <td>
                  <?php if($service->closed == 0): ?>
                    <form action="<?php echo e(route('services-transaction.edit', $service)); ?>" method="get">
                      <?php echo csrf_field(); ?>
                      <a rel="tooltip" class="btn btn-danger btn-link btn-sm" data-original-title="Cncel" title="Cancel" onclick="confirm('<?php echo e(__("Are you sure you want to cancel this transaction?")); ?>') ? this.parentElement.submit() : ''">
                        <i class="material-icons">undo</i>
                        <div class="ripple-container"></div>
                      </a>
                    </form>
                  <?php else: ?>
                    Closed
                  <?php endif; ?>
                </td>
                <td>
                  <form action="<?php echo e(route('services-transaction.destroy', $service)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button rel="tooltip" type="button" class="btn btn-danger btn-link btn-sm" data-original-title="Delete" title="Delete" 
                      onclick="confirm('<?php echo e(__("Are you sure you want to delete this transaction?")); ?>') ? this.parentElement.submit() : ''">
                        <i class="material-icons">close</i>
                        <div class="ripple-container"></div>
                    </button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'services_transaction', 'titlePage' => __('Services Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/serviceTransaction/index.blade.php ENDPATH**/ ?>