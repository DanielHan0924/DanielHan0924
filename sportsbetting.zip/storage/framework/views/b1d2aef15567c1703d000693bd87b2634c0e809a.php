<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="card registration">
        <div class="card-header card-header-primary">
          <h4 class="card-title"><?php echo e(__('Shop Management')); ?></h4>
        </div>
        <div class="card-body ">
          <?php if(session('status')): ?>
            <div class="row">
              <div class="col-sm-12">
                <div class="alert alert-success">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="material-icons">close</i>
                  </button>
                  <span><?php echo e(session('status')); ?></span>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <div class="row">
            <div class="col-md-4">
                <a href="<?php echo e(route('product.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add Product')); ?></a>
            </div>
            <div class="col-md-8" style="text-align:right">
              <a href="cart/0" class="btn btn-sm btn-primary"><?php echo e(__('History')); ?></a>
            </div>
          </div>
          <div class="fresh-datatables">
            <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
              <thead class=" text-primary">
              <tr >
                <th> <?php echo e(__('No')); ?> </th>
                <th> <?php echo e(__('Image')); ?> </th>
                <th> <?php echo e(__('Name')); ?> </th>
                <th> <?php echo e(__('Description')); ?> </th>
                <th> <?php echo e(__('Price')); ?> </th>
                <th> <?php echo e(__('Color')); ?> </th>
                <th> <?php echo e(__('Size')); ?> </th>
                <th> <?php echo e(__('Create Date')); ?> </th>
                <th style="width:120px"> <?php echo e(__('Order')); ?> </th>
                <th style="width:160px"> <?php echo e(__('Action')); ?> </th>
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($index+1); ?></td>
                    <td rel="tooltip"  data-original-title="<?php echo e($product->title); ?>" title="<?php echo e($product->title); ?>">
                      <img src="<?php echo e($product->image); ?>" style="max-width:120px; max-height:120px;">
                    </td>
                    <td><?php echo e($product->title); ?></td>
                    <td><?php echo e($product->description); ?></td>
                    <td><?php echo e($product->price); ?> €</td>
                    <td><?php echo e($product->color); ?></td>
                    <td><?php echo e($product->size); ?></td>
                    <td><?php echo e(date('d M Y', strtotime($product->created_at))); ?></td>
                    <td>
                    <div class="input-group">
                        <input type="number" id="order_<?php echo e($product->id); ?>" value="<?php echo e($product->order); ?>" class="form-control" style="text-align:center; font-size:16px;" min="0">
                        <div class="input-group-append">
                          <span class="input-group-text">
                          <a rel="tooltip" data-original-title="Change Order" title="Change Order" onclick="saveOrder(`<?php echo e(url('product/order')); ?>`, `<?php echo e($product->id); ?>`)" style="cursor:pointer">
                            <i class="material-icons" style="font-size: 1.2rem; color:#4caf50">save</i>
                          </a>
                          </span>
                        </div>
                      </div>
                    </td>
                    <td>
                      <form class="row" action="<?php echo e(route('product.destroy', $product)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <div class="col-md-6">
                          <a rel="tooltip" class="btn btn-success btn-sm btn-link" href="<?php echo e(url('product/up')); ?>/<?php echo e($product->id); ?>" data-original-title="Up" title="Up" <?php echo $index != 0 ? '' :'hidden' ?>>
                            <i class="material-icons" style="font-size: 1.8rem;">expand_less</i>
                            <div class="ripple-container"></div>
                          </a>
                          <a rel="tooltip" class="btn btn-success btn-sm btn-link" href="<?php echo e(url('product/down')); ?>/<?php echo e($product->id); ?>" data-original-title="Down" title="Down" <?php echo $index != count($products)-1 ? '' :'hidden' ?>>
                            <i class="material-icons" style="font-size: 1.8rem;">expand_more</i>
                            <div class="ripple-container"></div>
                          </a>
                        </div>
                        <div class="col-md-6">
                          <a rel="tooltip" class="btn btn-success btn-sm btn-link" href="<?php echo e(route('product.edit', $product)); ?>" data-original-title="Edit" title="Edit">
                            <i class="material-icons">edit</i>
                            <div class="ripple-container"></div>
                          </a>
                          <button type="button" rel="tooltip" class="btn btn-danger btn-sm btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this product?")); ?>') ? this.parentElement.parentElement.submit() : ''">
                              <i class="material-icons">close</i>
                              <div class="ripple-container"></div>
                          </button>
                        </div>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
	    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
  const saveOrder = function(url, id) {
    const order_input = $(`#order_${id}`);
    const order = parseInt(order_input.val());
    if(!order || order <= 0) {
      order_input.focus();
      order_input.select();
      return;
    }
    $.ajax({
      url: url,
      data:{id:id, order:order},
      method:'post',
      success: function(result){
        location.reload();
      },
      error:function(xhr,status,error){
        location.reload();
      }
    });
  }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'shop', 'titlePage' => __('Shop Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/shop/index.blade.php ENDPATH**/ ?>