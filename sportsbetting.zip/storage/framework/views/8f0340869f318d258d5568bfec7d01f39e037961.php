
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Clients')); ?></h4>
      </div>
      <div class="card-body ">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <div class="row">
        <div class="col-sm-4">
          <!-- <a href="<?php echo e(route('user.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add User')); ?></a> -->
        </div>
        <div class="col-sm-8" style="text-align:right; margin-bottom:20px">
          <!-- <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#position_modal">
          <?php echo e(__('Positions Manage')); ?>

          </button> -->
        </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> <?php echo e(__('No ')); ?> </th>
            <th> <?php echo e(__('Avatar')); ?> </th>
            <th> <?php echo e(__('FirstName')); ?> </th>
            <th> <?php echo e(__('LastName')); ?> </th>
            <th> <?php echo e(__('Email')); ?> </th>
            <th> <?php echo e(__('My Barbers')); ?> </th>
            <th> <?php echo e(__('Created_at')); ?> </th>
            </tr>
          </thead>
          <tbody >
            <?php $__currentLoopData = $favbarbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $favbarber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <?php echo e($index+1); ?></td>
              <td rel="tooltip"  data-original-title="<?php echo e($favbarber->client->firstname); ?>" title="<?php echo e($favbarber->client->firstname); ?>">
                <img src="<?php echo e($favbarber->client->avatar); ?>?<?php echo e(time()); ?>" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> <?php echo e($favbarber->client->firstname); ?> </td>
              <td> <?php echo e($favbarber->client->lastname); ?> </td>
              <td> <?php echo e($favbarber->client->email); ?> </td>
              <td> <a href="<?php echo e(route('favbarber.edit', $favbarber->client)); ?>" class="btn btn-primary btn-sm">
              My Barbers <span class=""><?php echo e(count($favbarber->client->barbers)); ?></span>
                </a> </td>
              <td><?php echo e(date('M d Y', strtotime($favbarber->client->created_at))); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'favbarber', 'titlePage' => __('Users Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\sportsbetting\resources\views/favbarber/index.blade.php ENDPATH**/ ?>