<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top text-white">
  <div class="container">
  </div>
</nav>
<!-- End Navbar --><?php /**PATH /home3/amzmpomy/public_html/Barber-Admin-Laravel/resources/views/layouts/navbars/navs/guest.blade.php ENDPATH**/ ?>