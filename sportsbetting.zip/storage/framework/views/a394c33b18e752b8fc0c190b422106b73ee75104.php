<div class="sidebar" data-color="purple" data-background-color="black" >
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="/home" class="simple-text logo-normal" style="text-transform: none;">
      <?php echo e(__('BARBER')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home.index')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Dashboard')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'user' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
          <i class="material-icons">account_circle</i>
            <p><?php echo e(__('User Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'favbarber' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('favbarber.index')); ?>">
          <i class="material-icons">account_circle</i>
            <p><?php echo e(__('Favourite Management')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'book' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('book.index')); ?>">
          <i class="material-icons">account_circle</i>
            <p><?php echo e(__('Book Management')); ?></p>
        </a>
      </li>

    </ul>
  </div>
</div><?php /**PATH /home3/amzmpomy/public_html/Barber-Admin-Laravel/resources/views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>