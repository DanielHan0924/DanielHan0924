

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <?php if($user->barber == 1): ?>
        <h4 class="card-title"><?php echo e(__('barbers')); ?></h4>
        <?php else: ?>
        <h4 class="card-title"><?php echo e(__('Barbers')); ?></h4>
        <?php endif; ?>
      </div>
      <div class="card-body ">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
      
      <div class="fresh-datatables">
        <?php if($user->barber == 1): ?>
        <h5 class="card-title"><?php echo e(__('My barbers')); ?></h5>
        <?php else: ?>
        <h5 class="card-title"><?php echo e(__('My Barbers')); ?></h5>
        <?php endif; ?>
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
            <tr >
              <th style="width:80px"> <?php echo e(__('No ')); ?> </th>
              <th> <?php echo e(__('Avatar')); ?> </th>
              <th> <?php echo e(__('FirstName')); ?> </th>
              <th> <?php echo e(__('LastName')); ?> </th>
              <th> <?php echo e(__('Email')); ?> </th>
              <th> <?php echo e(__('Delete')); ?> </th>
              <th> <?php echo e(__('Created_at')); ?> </th>
            </tr>
          </thead>
          <tbody >
            <?php $__currentLoopData = $user->barbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <?php echo e($index+1); ?></td>
              <td rel="tooltip"  data-original-title="<?php echo e($item->barber->firstname); ?>" title="<?php echo e($item->barber->firstname); ?>">
                <img src="<?php echo e($item->barber->avatar); ?>" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> <?php echo e($item->barber->firstname); ?> </td>
              <td> <?php echo e($item->barber->lastname); ?> </td>
              <td> <?php echo e($item->barber->email); ?> </td>
              <td> 
              <form action="<?php echo e(route('user.update', $item->barber)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('put'); ?>
                <input type="hidden" name="key" value="delete">
                <input type="hidden" name="userid" value="<?php echo e($user->id); ?>">
                <?php if($user->barber == 0): ?>
                <button rel="tooltip" type="submit" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this user?")); ?>') ? this.parentElement.submit() : ''">
                  <i class="material-icons">close</i>
                  <div class="ripple-container"></div>
                </button>
                <?php else: ?>
                <button rel="tooltip" type="submit" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this user?")); ?>') ? this.parentElement.submit() : ''">
                  <i class="material-icons">close</i>
                  <div class="ripple-container"></div>
                </button>
                <?php endif; ?>
                </form>
              </td>
              <td><?php echo e(date('M d Y', strtotime($item->barber->created_at))); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php if($user->barber == 1): ?>
        <h5 class="card-title" style = "margin-top:30px;"><?php echo e(__('Other barbers')); ?></h5>
        <?php else: ?>
        <h5 class="card-title" style = "margin-top:30px"><?php echo e(__('Other Barbers')); ?></h5>
        <?php endif; ?>
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
            <tr >
              <th style="width:80px"> <?php echo e(__('No ')); ?> </th>
              <th> <?php echo e(__('Avatar')); ?> </th>
              <th> <?php echo e(__('FirstName')); ?> </th>
              <th> <?php echo e(__('LastName')); ?> </th>
              <th> <?php echo e(__('Email')); ?> </th>
              <th> <?php echo e(__('Add')); ?> </th>
              <th> <?php echo e(__('Created_at')); ?> </th>
            </tr>
          </thead>
          <tbody >
            <?php $__currentLoopData = $barbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $barber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <?php echo e($index+1); ?></td>
              <td rel="tooltip"  data-original-title="<?php echo e($barber->nickname); ?>" title="<?php echo e($barber->nickname); ?>">
                <img src="<?php echo e($barber->avatar); ?>" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> <?php echo e($barber->firstname); ?> </td>
              <td> <?php echo e($barber->lastname); ?> </td>
              <td> <?php echo e($barber->email); ?> </td>
              <td>
              <form action="<?php echo e(route('user.update', $barber)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('put'); ?>
                <input type="hidden" name="key" value="add">
                <input type="hidden" name="userid" value="<?php echo e($user->id); ?>">
                <button rel="tooltip" type="submit" class="btn btn-info btn-link" data-original-title="Add" title="Add" >
                  <i class="material-icons">add</i>
                  <div class="ripple-container"></div>
                </button> 
              </form>
              </td>
              <td><?php echo e(date('M d Y', strtotime($barber->created_at))); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'user', 'titlePage' => __('Users Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\temp\Barber-Admin-Laravel\resources\views/users/edit.blade.php ENDPATH**/ ?>