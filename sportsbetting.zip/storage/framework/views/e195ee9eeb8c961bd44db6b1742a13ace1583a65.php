<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="card registration">
        <div class="card-header card-header-primary">
          <h4 class="card-title"><?php echo e(__('Rights')); ?></h4>
        </div>
        <div class="card-body ">
		  <div class="fresh-datatables">
			<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
			  <thead class=" text-primary">
				<tr >
					<th style="width:80px"> <?php echo e(__('No ')); ?> </th>
					<th> <?php echo e(__('Role')); ?> </th>
					<th> <?php echo e(__('Club News')); ?> </th>
					<th> <?php echo e(__('Partner News')); ?> </th>
					<th> <?php echo e(__('Other News')); ?> </th>
					<th> <?php echo e(__('Matches')); ?> </th>
					</tr>
			  </thead>
			  <tbody >
			  	<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td> <?php echo e($index+1); ?> </td>
						<td> <?php echo e($role->role); ?> </td>
						<td>
							<div class="togglebutton">
								<label>
									<input type="checkbox" class="role_switch" id="<?php echo e($role->id); ?>" name="news_club" <?php echo ($role->news_club == 1 ? "checked" : '') ?>>
									<span class="toggle"></span>
								</label>
							</div>
						</td>
						<td>
							<div class="togglebutton">
								<label>
									<input type="checkbox" class="role_switch" id="<?php echo e($role->id); ?>" name="news_partner" <?php echo ($role->news_partner == 1 ? "checked" : '') ?>>
									<span class="toggle"></span>
								</label>
							</div>
						</td>
						<td>
							<div class="togglebutton">
								<label>
									<input type="checkbox" class="role_switch" id="<?php echo e($role->id); ?>" name="news_other" <?php echo ($role->news_other == 1 ? "checked" : '') ?>>
									<span class="toggle"></span>
								</label>
							</div>
						</td>
						<td>
							<div class="togglebutton">
								<label>
									<input type="checkbox" class="role_switch" id="<?php echo e($role->id); ?>" name="matches" <?php echo ($role->matches == 1 ? "checked" : '') ?>>
									<span class="toggle"></span>
								</label>
							</div>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </tbody>
			</table>
		  </div>
        </div>
	  </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
		$(".role_switch").change(function(){
			$.ajax({
                url: `role/${this.id}`,
                data:{state:(this.checked?1:0), type:this.name},
                method:'put',
                success: function(result){
                },
                error:function(xhr,status,error){
                    location.reload();
                }
            });
		})
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'role', 'titlePage' => __('Rights Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/role/index.blade.php ENDPATH**/ ?>