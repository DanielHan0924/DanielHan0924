

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('services.store')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data" id="servicesForm">
            <?php echo csrf_field(); ?>
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('New Service')); ?></h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body row">
                <div class="col-md-12 text-right">
                    <a href="<?php echo e(route('services.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                  <div class="row">
                    <div class="col-md-4 fileinput fileinput-new text-center" style="padding:3%" data-provides="fileinput">
                      <fieldset class="form-group">
                          <a href="javascript:void(0)" onclick="$('#pro-image').click()" >Upload attach files</a>
                          <input type="file" id="pro-image" name="photo[]" style="display: none;" class="form-control" multiple 
                          accept="video/avi, video/mp4, video/mp3, video/mpeg, image/*">
                      </fieldset>
                      <div class="upload_progress hidden">
                        <div class="progress" style="width:calc(100% - 60px)">
                          <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 0" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" id="upload_prgress_bar"></div>
                        </div> <span id="upload_percentage" style="float:right; margin-top:-34px; width:60px">0%</span>
                        <span id="upload_state"></span>
                      </div>
                      <div class="preview-images-zone"></div>
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                          <select class="selectpicker" name="categoryid" data-style="btn btn-primary" value='0' required>
                          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                       
                        <div class="form-group<?php echo e($errors->has('title') ? ' has-danger' : ''); ?>">
                          <input class="form-control" name="title" type="text"  placeholder="<?php echo e(__('Title')); ?>" required/>
                        </div>
                        <div class="form-group<?php echo e($errors->has('content') ? ' has-danger' : ''); ?>">
                          <textarea id="content" name="content" placeholder="How it works" ></textarea>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer text-right">
                <div class="mr-auto">
                </div>
                <button type="submit" class="btn btn-sm btn-primary">Register</button>
              </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('material')); ?>/js/plugins/jasny-bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
  <script>
    const SERVER_HOST = `<?php echo url('/')?>`;
    var started_at = null;
    $(document).ready(function() {
      var num = 0;
  
      $("#content").Editor(
        settings={
          'insert_img':false,
          'block_quote':false,
          'ol':false,
          'ul':false
        }
      );
      $( ".preview-images-zone" ).sortable();
      $("#servicesForm").submit(function(event) {
        $("#content").val($('#content').Editor("getText"));
      });
      $(document).on('click', '.image-cancel', function() {
        let no = $(this).data('no');
        let url = $(this).parent().find("input").val();
        console.log(url);
        $.ajax({
          url: `${SERVER_HOST}/services/remove`,
          type: 'post',
          data: {url:url},
        });
        $(".preview-image.preview-show-"+no).remove();
      });
      $('#pro-image').on('change', function() {
        if(!this.files) return;
        var form_data = new FormData();                  
        for (let i = 0; i < this.files.length; i++) {
          form_data.append('photo[]', this.files[i]);
        }
        started_at = new Date();
        $.ajax({
            type:'POST',
            url: `${SERVER_HOST}/services/upload`,
            data:form_data,
            xhr: function() {
              $(".upload_progress").removeClass("hidden");
              var myXhr = $.ajaxSettings.xhr();
              if(myXhr.upload)
                  myXhr.upload.addEventListener('progress',progress, false);
              return myXhr;
            },
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
              var output = $(".preview-images-zone");
              if(!data || data.length <= 0) return;
              data.forEach(item => {
                var type = item.type;
                var url = item.url;
                var html =` <div class="preview-image preview-show-${num}">
                              <div class="image-cancel" data-no="${num}">&#215;</div>
                              <div class="image-zone">
                                ${
                                  type[0] == "video" ?
                                  `<video width="150" height="150" controls  id="pro-img-${num}">
                                    <source src="${url}" type="${type[0]}/${type[1]}">
                                  </video>`
                                  :
                                  `<img id="pro-img-${num}" src="${url}">`
                                }
                              </div>
                              <input type="hidden" name="file_url[]" value="${url}?${type[0]}">
                            </div>`;
                num += 1;
                output.append(html);
              });
              $("#pro-image").val('');
            },
            error: function(data){
              $("#pro-image").val('');
            }
        });
      });
    });
    function second2Time(second){
      second = parseInt(second);
      if(second <= 60) return `${second}s`;
      let min = parseInt(second/60);
      let sec = parseInt(second%60);
      if(min <= 60) return `${min}m ${sec}s`;
      let hour = parseInt(min/60);
      min = parseInt(min%60);
      if(hour <= 24) return `${hour}h ${min}m ${sec}s`;
      let day = parseInt(hour/24);
      hour = parseInt(hour%24);
      return `${day}d ${hour}h ${min}m ${sec}s`;
    }
    function progress(e){
      if(e.lengthComputable){
          var max = e.total;
          var current = e.loaded;
          var Percentage = (current * 100)/max;
          $("#upload_prgress_bar").attr("style", `width: ${Percentage}%`);

          var seconds_elapsed =   ( new Date().getTime() - started_at.getTime() )/1000;
          var bytes_per_second =  seconds_elapsed ? current / seconds_elapsed : 0 ;
          var Kbytes_per_second = bytes_per_second / 1000 ;
          var remaining_bytes =   max - current;
          var seconds_remaining = seconds_elapsed ? second2Time(remaining_bytes / bytes_per_second) : 'calculating' ;

          $("#upload_percentage").text(`${(Percentage).toFixed(1)}%`);
          $("#upload_state").text(`${(Kbytes_per_second/1000).toFixed(2)}MB/s (${seconds_remaining} Remaining)`);
          if(Percentage >= 100){
            $("#upload_state").text('');
            $("#upload_percentage").text(`0%`);
            $("#upload_prgress_bar").attr("style", `width: 0%`);
            $(".upload_progress").addClass("hidden");
          }
      }  
    }
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'services', 'titlePage' => __('Services Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/services/create.blade.php ENDPATH**/ ?>