<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Services')); ?></h4>
      </div>
      <div class="card-body">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr>
            <th><?php echo e(__('No')); ?></th>
            <th><?php echo e(__('User name')); ?></th>
            <th><?php echo e(__('Title')); ?></th>
            <th><?php echo e(__('Date')); ?></th>
          </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $service_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php echo e($index+1); ?>

                </td>
                <td>
                  <?php if($service->user): ?>
                    <?php echo e($service->user->name); ?> <?php echo e($service->user->surname); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <?php if($service->service): ?>
                    <?php echo e($service->service->title); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <td><?php echo e(date('H:i d M Y', strtotime($service->created_at))); ?></td>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
<script>
  const sortable_option = {
    cursor: "move",
    placeholder: "sortable-placeholder",
    helper: function(e, tr)
    {
      var $originals = tr.children();
      var $helper = tr.clone();
      $helper.children().each(function(index)
      {
      $(this).width($originals.eq(index).width());
      });
      return $helper;
    },      
  };

  $("#services_list_table tbody").sortable(sortable_option);

  $("#services_form").submit(function(event) {
    $('#services_list_table tbody tr').each(function (i, el) {
      let element = $("#services_list_table tbody").find(el);
      $(`#service_${i}`).val(element.attr('value'));
      });
  });
  $("#services_categories_table tbody").sortable(sortable_option);

  $("#categories_form").submit(function(event) {
    $('#services_categories_table tbody tr').each(function (i, el) {
      let element = $("#services_categories_table tbody").find(el);
      $(`#category_${i}`).val(element.attr('value'));
      });
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'service_history', 'titlePage' => __('Services Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/serviceHistory/index.blade.php ENDPATH**/ ?>