<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top text-white">
  <div class="container">
  </div>
</nav>
<!-- End Navbar --><?php /**PATH E:\01_web\12_ASP.NET\barber\workspace\laravel_backend\resources\views/layouts/navbars/navs/guest.blade.php ENDPATH**/ ?>