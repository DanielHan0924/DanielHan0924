<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top text-white">
  <div class="container">
  </div>
</nav>
<!-- End Navbar --><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/layouts/navbars/navs/guest.blade.php ENDPATH**/ ?>