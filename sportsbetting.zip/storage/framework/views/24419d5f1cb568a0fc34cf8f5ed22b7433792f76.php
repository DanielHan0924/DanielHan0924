<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary row">
        <h4 class="card-title"><?php echo e(__('Slider Management')); ?></h4>
        <div class="ml-auto">
        <a data-toggle="modal" data-target="#addModal" style="cursor: pointer;">
          <i class="material-icons" style="font-size:30px; color:white">add</i>
        </a>
        </div>
      </div>
      <div class="card-body row">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-2">
          <img src="<?php echo e($slider->image); ?>" style="width:100%;">
          <div class="row" style="position:absolute; top:-5px; right:10px; border-radius:10%; background:#ffffffab; padding:10px">
            <?php if($index != 0): ?>
              <form class="col" action="<?php echo e(route('slider.update', $slider)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <input type="hidden" name="type" value="left">
                <a onclick="this.parentElement.submit()" style="cursor:pointer">
                  <i class="material-icons">chevron_left</i>
                </a>
              </form>
            <?php endif; ?>
            <?php if($index < count($sliders)-1): ?>
              <form class="col" action="<?php echo e(route('slider.update', $slider)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <input type="hidden" name="type" value="right">
                <a onclick="this.parentElement.submit()" style="cursor:pointer">
                  <i class="material-icons">chevron_right</i>
                </a>
              </form>
            <?php endif; ?>
            <form class="col" action="<?php echo e(route('slider.destroy', $slider)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('delete'); ?>
              <a rel="tooltip" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this slider image?")); ?>') ? this.parentElement.submit() : ''"  style="cursor:pointer"><i class="material-icons">close</i></a>
            </form>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
	  </div>
  </div>
</div>
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Slider Image</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="post" action="<?php echo e(route('slider.store')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
        <div class="modal-body">
          <?php echo csrf_field(); ?>
          <div class="fileinput fileinput-new text-center" data-provides="fileinput">
            <div class="fileinput-new thumbnail img-raised">
            <img src="\uploads\slider\default.jpg" alt="...">
            </div>
            <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
            <div>
            <span class="btn btn-raised btn-round btn-rose btn-file">
              <span class="fileinput-new">Select image</span>
              <span class="fileinput-exists">Change</span>
              <input type="file" name="photo" id="photo" required/>
            </span>
                <a href="#pablo" class="btn btn-danger btn-round fileinput-exists remove-image" data-dismiss="fileinput">
                  <i class="fa fa-times"></i> Remove
                </a>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('material')); ?>/js/plugins/jasny-bootstrap.min.js"></script>
<script>
  const maxSize = 1000000;
  const maxwidth = 1200;
  const maxheight = 800;
  $(document).ready(function(){
    var _URL = window.URL || window.webkitURL;
    $('#photo').change(function () {
      if(this.files.length <= 0) return;
      var file_size=(this.files[0].size);
      if(file_size > maxSize){
        $(".remove-image").click();
        return Swal.fire('Oops...', `Image max size: ${maxSize/1000000}MB`, 'error');
      }

      var file = $(this)[0].files[0];
      img = new Image();
      var imgwidth = 0;
      var imgheight = 0;

      img.src = _URL.createObjectURL(file);
      img.onload = function() {
        imgwidth = this.width;
        imgheight = this.height;
        if(imgwidth > maxwidth || imgheight > maxheight) {
          $(".remove-image").click();
          return Swal.fire('Oops...', `Image max size: ${maxwidth}×${maxheight}`, 'error');
        }
      };
      img.onerror = function() {
        alert(`not a valid file: ${file.type}`);
      }
    });
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'slider', 'titlePage' => __('Slider Image Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\scnp\resources\views/slider/index.blade.php ENDPATH**/ ?>