<!--  -->
<?php $__env->startSection('content'); ?>
  <div class="content">
    
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\01_web\12_ASP.NET\barber\workspace\laravel_backend\resources\views/dashboard.blade.php ENDPATH**/ ?>