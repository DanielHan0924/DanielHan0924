<footer class="footer">
    <div class="container">
    </div>
</footer><?php /**PATH D:\Work\Laravel\scnp\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>