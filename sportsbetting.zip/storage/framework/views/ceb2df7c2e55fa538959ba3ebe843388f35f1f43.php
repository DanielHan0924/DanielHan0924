<?php $__env->startSection('content'); ?>
  <div class="content">
    
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\temp\Barber-Admin-Laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>