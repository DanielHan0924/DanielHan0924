<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><?php echo e(__('Services')); ?></h4>
      </div>
      <div class="card-body">
        <?php if(session('status')): ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span><?php echo e(session('status')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <div style="text-align:right; margin-bottom:20px">
          <a href="<?php echo e(route('services.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('New Service')); ?></a>
        </div>
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr>
            <th style="width:60px"> <?php echo e(__('No')); ?> </th>
            <th> <?php echo e(__('User name')); ?> </th>
            <th> <?php echo e(__('Category')); ?> </th>
            <th> <?php echo e(__('Title')); ?> </th>
            <th> <?php echo e(__('Content')); ?> </th>
            <th style="width:40%"> <?php echo e(__('Media')); ?> </th>
            <th> <?php echo e(__('Date')); ?> </th>
            <th style="width:160px"> <?php echo e(__('Action')); ?> </th>
          </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($index+1); ?></td>
              <td>
                <?php if($service->user): ?>
                  <?php echo e($service->user->name); ?> <?php echo e($service->user->surname); ?>

                <?php endif; ?>
              </td>
              <td>
                <?php if($service->category): ?>
                  <?php echo e($service->category->title); ?>

                <?php endif; ?>
              </td>
              <td>
                <?php echo e($service->title); ?>

              </td>
              <td>
                <?php echo e($service->content); ?>

              </td>
              <td class="row">
                <?php $__currentLoopData = $service->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($media[1] == "video"): ?>
                  <div class="col-3" style="width:100px; height:100px; margin-top:15px; padding:5px"><video width="100" height="100" controls type="video/*"><source src="<?php echo e($media[0]); ?>"></video></div>
                  <?php else: ?>
                  <div class="col-3" style="width:100px; height:100px; margin-top:15px; padding:5px"><img style="max-width:100%; max-height:100%" src="<?php echo e($media[0]); ?>" alt=""></div>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </td>
              <td><?php echo e(date('H:i d M Y', strtotime($service->created_at))); ?></td>
              <td>
                <form action="<?php echo e(route('services.destroy', $service)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('delete'); ?>
                  <a rel="tooltip" class="btn btn-success btn-link btn-sm" href="<?php echo e(route('services.edit', $service)); ?>" data-original-title="Edit" title="Edit">
                    <i class="material-icons">edit</i>
                    <div class="ripple-container"></div>
                  </a>
                  <button rel="tooltip" type="button" class="btn btn-danger btn-link btn-sm" data-original-title="Delete" title="Delete" onclick="confirm('<?php echo e(__("Are you sure you want to delete this exercise?")); ?>') ? this.parentElement.submit() : ''">
                      <i class="material-icons">close</i>
                      <div class="ripple-container"></div>
                  </button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'services', 'titlePage' => __('Services Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Laravel\SCNPInside-admin-laravel\resources\views/services/index.blade.php ENDPATH**/ ?>