<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
 
class CreateNotificationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('notification', function (Blueprint $table) {
            $table->id();
            $table->integer("senderid");
            $table->integer("receiverid");
            $table->integer("typeid");
            $table->integer("type")->comment("0:book, 1:review, 2:announcement, 3:bookcomment");
            $table->integer("currentstate")->comment("current book state, current barber rate");
            $table->integer("show")->default(0)->comment("0:unread, 1:read");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notification');
        //
    }
}
