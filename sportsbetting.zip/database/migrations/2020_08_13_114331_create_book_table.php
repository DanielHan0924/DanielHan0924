<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBookTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('book', function (Blueprint $table) {
            $table->id();
            $table->integer("barberid");
            $table->integer("clientid");
            $table->string("serviceid")->comment("all services have to  splite <,>");
            $table->string("date");
            $table->string("time");
            $table->integer("payment");
            $table->integer("state")->comment("0:requested, 1:cancelled, 2:confirmed, 3:completed, 4:noshow");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('book');
    }
}
