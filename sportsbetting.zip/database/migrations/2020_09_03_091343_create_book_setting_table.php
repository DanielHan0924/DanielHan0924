<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
 
class CreateBookSettingTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('book_setting', function (Blueprint $table) {
            $table->id();
            $table->integer("barberid");
            $table->integer("auto_confirm")->default(0)->comment("0:disable, 1:enable");
            $table->integer("multi_service")->default(0)->comment("0:disable, 1:enable");
            $table->integer("require_phone")->default(0)->comment("0:disable, 1:enable");
            $table->text("auto_comment")->nullable();
            $table->integer("bookinterval")->default(10);
            $table->integer("last_limit_hour")->default(0);
            $table->integer("last_limit_min")->default(0);
            $table->string("future_limit")->default("12 month");
            $table->integer("requrring_limit")->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('book_setting');
        //
    }
}
