<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = "notification";

    protected $fillable = [
        'senderid', 'receiverid', 'typeid', 'type', 'currentstate', 'show'
    ];

    public function sender() {
        return $this->hasOne('App\User', 'id', 'senderid');
    }
    public function book() {
        return $this->hasOne('App\Book', 'id', 'typeid');
    }
    public function announcement() {
        return $this->hasOne('App\Announcement', 'id', 'typeid');
    }
    public function bookcomment() {
        return $this->hasOne('App\BookComment', 'id', 'typeid');
    }
}