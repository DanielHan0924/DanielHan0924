<?php

namespace App\Http\Controllers;
use App\User;
use App\Video;
use App\Video_category;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $video_cat = new Video_category;
        $cat = $video_cat->all();
        $allvideo = new Video;
        $videos = $allvideo->all();
        $videoCount = count($videos);

        return view('dashboard', ['video_cat' => $cat, 'videos' => $videos, 'videoCount' => $videoCount]);
    }
}
