<?php
   
namespace App\Http\Controllers\API;
   
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use Hash;
use Storage;
use Intervention\Image\ImageManagerStatic as Image;
use App\User;
use App\Nfl;
use App\Ufc;
use DB;
use Auth;
use Braintree;

class TransactionController extends Controller
{
    public function getClientToken()
    {
        $gateway = new Braintree\Gateway([
            'clientId' => 'AY9nLdDsjrV1XuQx4OF8vhfj-ls2QuNPWJ1DvaHA94Ktt-Mn-e-cS3aHaJTT84NRzbZLq0-mWewhf82o',
            'clientSecret' => 'EPCnd0ht9wCM1Dwwrhu7ni2Nh4M6GDEPIK3MHgZl47JGCpcLFMrIayNmf3hwEzrv2iLkib0oCmK3w7l1'
        ]);
        
        $result = $gateway->oauth()->createTokenFromCode([
            'code' => codeFromQueryString
        ]);
        
        $accessToken = $result->credentials->accessToken;
        $expiresAt = $result->credentials->expiresAt;
        $refreshToken = $result->credentials->refreshToken;

        return response(['clientToken' => $accessToken]);
    }
    public function getOdds($t_name)
    {
        $f = false;
        // dd("ss");
        switch ($t_name) {
            case 'nfl':
                $match_table = new Nfl;
                $f = true;
                break;
            case 'ufc':
                $match_table = new Ufc;
                $f = true;

                break;
            default:
                // $match_table = new Ufc;
                break;
        }
        if($f){
            $vegas_odds = $match_table->all();
            return response(['data' => $vegas_odds]);
        }
        return response(['data' => ""]);
    }
}