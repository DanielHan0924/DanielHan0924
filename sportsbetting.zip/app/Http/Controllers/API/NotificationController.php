<?php
   
namespace App\Http\Controllers\API;
   
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use Hash;
use Storage;
use Intervention\Image\ImageManagerStatic as Image;
use App\User;
use Auth;

use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;
use FCM;

class NotificationController extends Controller
{
    public function test()
    {
        return $this->sendNotification("title", "content", null);
    }

    public function sendNotification($title, $content, $users){
        if($users){
            $tokens = array_merge(
                User::whereIn('id', $users)->pluck('device_token')->toArray(),
                User::whereIn('id', $users)->pluck('iphone_device_token')->toArray()
            );
        }else{
            $tokens = array_merge(
                User::pluck('device_token')->toArray(),
                User::pluck('iphone_device_token')->toArray()
            );
        }
        $optionBuilder = new OptionsBuilder();
        $optionBuilder->setTimeToLive(60*20);
        $notificationBuilder = new PayloadNotificationBuilder($title);
        $notificationBuilder
            ->setBody($content)
            ->setSound('default')
            ->setColor('#ad0300')
            ->setIcon('ic_notification');

        $dataBuilder = new PayloadDataBuilder();

        $option = $optionBuilder->build();
        $notification = $notificationBuilder->build();
        $data = $dataBuilder->build();

        $downstreamResponse = FCM::sendTo($tokens, $option, $notification, $data);
    }
}