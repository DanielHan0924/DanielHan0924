<?php
   
namespace App\Http\Controllers\API;
   
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use Hash;
use Storage;
use Intervention\Image\ImageManagerStatic as Image;
use App\User;
use App\BookSetting;
use DB;

class RegisterController extends Controller
{
    public function register(Request $request)
    {
        // dd($request->validate(['firstname' => 'required|max:55',
        //     'lastname' => 'required|max:55',
        //     'password' => 'required',
        //     'barber' => 'required|max:55',
        //     'email' => 'email|required',
        // ]));
        // $validatedData = $request->validate([
        //     'firstname' => 'required|max:55',
        //     'lastname' => 'required|max:55',
        //     'email' => 'email|required|unique:users',
        //     'password' => 'required|confirmed',
        //     'barber' => 'required|max:55'
        // ]);

        $validatedData = $request->validate([
            // 'firstname' => 'required|max:55',
            // 'lastname' => 'required|max:55',
            'password' => 'required',
            // 'barber' => 'required|max:55',
            'email' => 'email|required',
        ]);
        // dd($request['password']);

        $request['password'] = bcrypt($request->password);

        $user = User::create($request->all());

        $accessToken = $user->createToken('authToken')->accessToken;
        
        // if($request['barber'] == 1)
        // {
        //     $booksetting = new BookSetting;
        //     $booksetting->barberid = $user->id;
        //     $booksetting->save();
        // }
        return response([ 'Message' => 'success', 'Success' => true]);
    }

    public function login(Request $request)
    {
        $loginData = $request->validate([
            'email' => 'email|required',
            'password' => 'required'
        ]);

        if (!auth()->attempt($loginData)) {
            return response(['Success' => false]);
        }

        // $accessToken = auth()->user()->createToken('authToken')->accessToken;
        
        // User::where('id', Auth::user()->id)->update(['device_token' => $request['device_token']]);

        return response(['User' => auth()->user(), 'Success' => true]);
    }
    
    public function changeaccount(Request $request)
    {
        $changeData = $request->validate([
            'email' => 'email|required',
            // 'firstname' => 'required',
            // 'lastname' => 'required',
        ]);

        User::where("id", $request['id'])->update(['email' => $request['email']]);
        
        return response(['Success' => true]);
    }

    public function changepassword(Request $request)
    {
        if(!Hash::check($request['currentPwd'], Auth::user()->password))
            return response(['Success' => false]);
        
        User::where("id", Auth::user()->id)->update(['password' => bcrypt($request['newPwd'])]);
        
        return response(['Success' => true]);
    }
}