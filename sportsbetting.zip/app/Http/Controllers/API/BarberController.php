<?php
   
namespace App\Http\Controllers\API;
   
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use Hash;
use Storage;
use Intervention\Image\ImageManagerStatic as Image;
use App\User;
use App\Barber;
use App\Review;
use App\Service;
use App\Location;
use App\Book;
use App\Gallery;
use App\Info;
use App\SupportFeedback;
use App\Notification;
use App\BookComment;
use App\BookSetting;
use App\Announcement;
use DB;
use Auth;

class BarberController extends Controller
{
    private $notification;
    public function __construct()
    {
        $this->notification = new NotificationController;
    }

    public function getMaxID($table)
    {
        $strQuery = "SELECT MAX(id) as maxId FROM ".$table;
        $result = DB::select($strQuery);
        $maxId = $result[0]->maxId;
        $maxId ++;
        return $maxId;
    }

    public function getBarberBooks(Request $request)
    {
        $books = Book::where(['barberid' => Auth::user()->id, 'date' => $request['day']])->get();
        foreach($books as $key => $item)
        {
            $item = $this->getOneFullBook($item);
        }

        return response(['Success' => true, 'Books' => $books]);
    }

    public function getOneFullBook($book)
    {
        $book->barber;
        $book->client;
        $book->bookcomments;
        $servicename = $book->serviceid;
        $lstNames = explode(",", $servicename);

        $lstServices = Service::whereIn('id', $lstNames)->get();
        $book['services'] = $lstServices;
        return $book;
    }

    public function getBarberBookInfo(Request $request)
    {
        $id = $request['id'];
        $user = new User;
        $barber = $user->where('id', $id)->first();
        $location = $barber->locationInfo;
        $expState = [];
        $expState[] = 1;
        $expState[] = 3;
        $expState[] = 4;
        $exceptTimes = Book::where(['barberid' => $id, 'date' => $request['date']])->whereNotIn('state', $expState)->pluck('time')->toArray();
        return response(['Success' => true, 'Location' => $location, 'exceptTimes' => $exceptTimes]);
    }

    public function editLocation(Request $request)
    {
        $id = $request['barberid'];
        unset($request['wholeAddress']);
        unset($request['distance']);
        unset($request['strDistance']);
        $exist = Location::where('barberid', $id)->count();
        if($exist > 0)
            Location::where('barberid', $id)->update($request->all());
        else
            Location::create($request->all());
        return response(['Success' => true]);
    }

    public function editInfo(Request $request){
        $id = Auth::user()->id;
        if($request['bio'] == null && $request['phone'] == null)
        {
            Info::where('barberid', $id)->delete();
            return response(['Success' => true]);
        }
        $exist = Info::where('barberid', $id)->count();
        if($exist > 0)
            Info::where('barberid', $id)->update($request->all());
        else
            Info::create($request->all());
        return response(['Success' => true]);
    }

    public function createService(Request $request){
        $service = new Service;
        $service->barberid = Auth::user()->id;
        $service->name = $request['name'];
        $service->price = $request['price'];
        $service->hour = $request['hour'];
        $service->min = $request['min'];
        $service->description = $request['description'];
        $service->save();
        return response(['Success' => true]);
    }

    public function editService(Request $request)
    {
        Service::where('id', $request['id'])->update(['name' => $request['name'], 'price' => $request['price'], 'hour' => $request['hour'], 'min' => $request['min'], 'description' => $request['description']]);
        return response(['Success' => true]);
    }
    
    public function getAllGallery(Request $request)
    {
        $id = $request['id'];
        return response(['Success' => true, 'Gallerys' => Gallery::where('barberid', $id)->get()]);
    }

    public function deleteGallery(Request $request)
    {
        $id = $request['id'];
        $file = Gallery::where('id', $id)->value('image');
        $file_path = public_path().$file;
        if(file_exists($file_path))
            unlink($file_path);
        Gallery::where('id', $id)->delete();
        return response(['Success' => true]);       
    }

    public function addGallery(Request $request)
    {
        if($request->hasFile('File')){
            if ($request->file('File')->isValid()) {
                $user = Auth::user();
                $image_name = date('mdYHis').uniqid().$request->file('File')->getClientOriginalName();
                $cutPath = '/uploads/gallery';
                $path = public_path().$cutPath;
                $request->file('File')->move($path,$image_name);
                $cutName = $cutPath.'/'.$image_name;
                
                $gallery = new Gallery;
                $gallery->barberid = Auth::user()->id;
                $gallery->image = $cutName;
                $gallery->save();

                return response(['Success' => true, 'Gallerys' => Auth::user()->gallerys]);
            }
            return response(['Success' => false]);
        }
        return response(['Success' => false]);
    }

    public function getAllMyClients()
    {
        $myClients = Auth::user()->clients;
        $users = [];
        foreach ($myClients as $key => $value) {
            $users[] = $value->client;
        }
        return response(['Success' => true, 'Users' => $users]);
    }

    public function getClientDetail(Request $request)
    {
        $books = Book::where(['barberid' => Auth::user()->id, 'clientid' => $request['id']])->get();
        foreach($books as $key => $item)
        {
            $item = $this->getOneFullBook($item);
        }

        $favBarber = Barber::where(['n_id_user' => $request['id'], 'n_id_user_barber' => Auth::user()->id])->first();

        return response(['Success' => true, 'Books' => $books, 'FavBarber' => $favBarber]);
    }

    public function broadcastBarber(Request $request)
    {
        $maxid = $this->getMaxID('announcement');
        $announcement = new Announcement;
        $announcement->id = $maxid;
        $announcement->barberid = Auth::user()->id;
        $announcement->content = $request['content'];
        $announcement->save();

        $receivers = [];
        foreach($request['Users'] as $key => $value)
        {
            $newNotification = new Notification;
            $newNotification->typeid = $maxid;
            $newNotification->senderid = Auth::user()->id;
            $newNotification->receiverid = $value['id'];
            $newNotification->type = 2;
            $newNotification->currentstate = -1;
            $newNotification->save();

            $receivers[] = $value['id'];
        }

        $title = "New Announcement";
        $content = "[ ".Auth::user()->firstname." ".Auth::user()->lastname." ] ".$request['content'];
        
        $this->notification->sendNotification($title, $content, $receivers);

        return response(['Success' => true]);
    }

    public function saveBookSetting(Request $request)
    {
        $exist = BookSetting::where('barberid', $request['barberid'])->count();
        if($exist == 0){
            BookSetting::create($request->all());
        }
        else{
            BookSetting::where('barberid', $request['barberid'])->update($request->all());
        }
        return response(['Success' => true]);
    }

    public function getBookSetting()
    {
        return response(['Success' => true, 'BookSetting' => Auth::user()->booksetting]);
    }

    public function getRequestedBook()
    {
        $books = Auth::user()->bookBarber;
        foreach($books as $key => $item)
        {
            $item = $this->getOneFullBook($item);
        }

        return response(['Success' => true, 'Books' => $books]);
    }

    public function deleteClient(Request $request)
    {
        Barber::where(['n_id_user' => $request['id'], 'n_id_user_barber' => Auth::user()->id])->delete();
        return response(['Success' => true]);
    }

    public function blockClient(Request $request)
    {
        Barber::where(['n_id_user' => $request['id'], 'n_id_user_barber' => Auth::user()->id])->update(['block' => $request['block']]);
        return response(['Success' => true]);
    }
}