<?php
   
namespace App\Http\Controllers\API;
   
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use Hash;
use Storage;
use Intervention\Image\ImageManagerStatic as Image;
use App\User;
use App\Barber;
use App\Review;
use App\Service;
use App\Location;
use App\Book;
use App\Cut;
use App\Info;
use App\SupportFeedback;
use App\Notification;
use App\BookComment;
use App\Announcement;
use App\BookSetting;
use DB;
use Auth;

class ClientController extends Controller
{
    private $notification;
    public function __construct()
    {
        $this->notification = new NotificationController;
    }
    
    public function getMaxID($table)
    {
        $strQuery = "SELECT MAX(id) as maxId FROM ".$table;
        $result = DB::select($strQuery);
        $maxId = $result[0]->maxId;
        $maxId ++;
        return $maxId;
    }

    public function getMyBarber(User $model)
    {
        $myBarbers = Auth::user()->barbers;
        $users = [];
        foreach ($myBarbers as $key => $value) {
            if($value->block == 1)
                continue;
            $users[] = $value->barber;
        }
        foreach ($users as $key => $value) {
            $value->booksetting;
        }
        $myCuts = Auth::user()->cuts;

        return response(['Success' => true, 'Users' => $users, 'Cuts' => $myCuts]);
    }

    public function getNewNotifications()
    {
        $unread = Notification::where(['receiverid' => Auth::user()->id, 'show' => 0])->count();
        return response(['Success' => true,'NewAlarm' => $unread]);
    }

    public function changeProfile(Request $request){
        if($request->hasFile('File')){
            if ($request->file('File')->isValid()) {
                $user = Auth::user();
                $image_name = date('mdYHis').uniqid().$request->file('File')->getClientOriginalName();
                $avatarPath = '/uploads/avatar';
                $path = public_path().$avatarPath;
                $request->file('File')->move($path,$image_name);
                $avatarName = $avatarPath.'/'.$image_name;
                $user->avatar = $avatarName;
                $user->save();
                return response(['Success' => true, 'ImageName' => $avatarName]);
            }
            return response(['Success' => false]);
        }
        return response(['Success' => false]);
    }

    public function searchAllBarber(Request $request)
    {
        $searchname = $request['name'];
        $searchlocation = $request['location'];
        $user = new User;

        $idLocations = [];
        $idUsers = [];

        if($searchlocation != ""){
            $idLocations = Location::where('streetAddress', 'like', '%'.$searchlocation.'%')
            ->orWhere('shopName', 'like', '%'.$searchlocation.'%')
            ->orWhere('city', 'like', '%'.$searchlocation.'%')
            ->orWhere('zipcode', 'like', '%'.$searchlocation.'%')
            ->orWhere('floor', 'like', '%'.$searchlocation.'%')
            ->orWhere('state', 'like', '%'.$searchlocation.'%')
            ->orWhere('country', 'like', '%'.$searchlocation.'%')
            ->pluck('barberid')->toArray();
        }
        if($searchname != ""){
            $idUsers = User::where('firstname', 'like', '%'.$searchname.'%')->pluck('id')->toArray();
        }

        if($searchname == "" && $searchlocation == "")
            $users = User::where('barber', 1)->get();
        else
            $users = User::wherein('id', array_merge($idLocations, $idUsers))
            ->where('barber', 1)
            ->get();

        foreach ($users as $key => $user) {
            $users[$key]->reviews;
            $users[$key]->location;
            $users[$key]->booksetting;

            $fav = Barber::where(['n_id_user' => Auth::user()->id, 'n_id_user_barber' => $user->id])->count();
            $user['favBarber'] = $fav;
        }
        return response(['Success' => true, 'searchBarbers' => $users]);
    }

    public function getBarberLocationInfo(Request $request)
    {
        $id = $request['id'];
        $user = new User;
        $barber = $user->where('id', $id)->first();
        $location = $barber->locationInfo;
        $info = $barber->info;
        $gallerys = $barber->gallerys;
        return response(['Success' => true, 'Gallerys' => $gallerys, 'Location' => $location, 'Info' => $info]);
    }

    public function manageMyBarber(Request $request)
    {
        $id = $request['id'];
        $barber = new Barber;
        $count = $barber->where(['n_id_user' => Auth::user()->id, 'n_id_user_barber' => $id])->count();
        if($count == 0)
        {
            $barber->n_id_user = Auth::user()->id;
            $barber->n_id_user_barber = $id;
            $barber->block = 0;
            $barber->save();

            return response(['Success' => true, 'Result' => 1]);
        }
        else 
        {
            $barber->where(['n_id_user' => Auth::user()->id, 'n_id_user_barber' => $id])->delete();
            return response(['Success' => true, 'Result' => 0]);
        }
    }

    public function getBarberReview(Request $request)
    {
        $id = $request['id'];
        $reviews = Review::where('n_rcv_user', $id)->get();
        foreach($reviews as $key => $item) {
            $reviews[$key]->Client;
        }
        return response(['Success' => true, 'Reviews' => $reviews]);
    }

    public function reviewBarber(Request $request)
    {
        $barberid = $request['barberid'];
        $rate = $request['rate'];
        $content = $request['content'];

        $review = new Review;
        $exist = $review->where(['n_rcv_user' => $barberid, 'n_snd_user' => Auth::user()->id])->count();
        if($exist == 0)
        {
            $review->n_rcv_user = $barberid;
            $review->n_snd_user = Auth::user()->id;
            $review->content = $content;
            $review->rate = $rate;
            $review->save();
        }
        else{
            Review::where(['n_rcv_user' => $barberid, 'n_snd_user' => Auth::user()->id])->update(['content' => $content, 'rate' => $rate]);
        }

        $averageRate = Review::where('n_rcv_user', $barberid)->groupBy('n_rcv_user')->avg('rate');
        if($averageRate >= 4.5)
            $stars = 5;
        else if($averageRate >= 4)
            $stars = 4;
        else if($averageRate >= 3)
            $stars = 3;
        else if($averageRate >= 2)
            $stars = 2;
        else if($averageRate >= 1)
            $stars = 1;

        User::where('id', $barberid)->update(['rate' => $averageRate, 'star' => $stars]);
    
        $newNotification = new Notification;
        $newNotification->typeid = -1;
        $newNotification->senderid = Auth::user()->id;
        $newNotification->receiverid = $barberid;
        $newNotification->type = 1;
        $newNotification->currentstate = $rate;
        $newNotification->save();

        $title = "New Review";
        $content = Auth::user()->firstname." ".Auth::user()->lastname." reviewed your appointment.";
        $receivers = User::where('id', $barberid)->pluck('id')->toArray();
        
        $this->notification->sendNotification($title, $content, $receivers);

        return response(['Success' => true]);
    }

    public function getBarberService(Request $request)
    {
        $id = $request['id'];
        $services = Service::where('barberid', $id)->get();
        return response(['Success' => true, 'Services' => $services]);
    }

    public function bookAppointment(Request $request)
    {
        $clientid = $request['client']['id'];
        $barberid = $request['barber']['id'];
        $services = $request['services'];
        $date = $request['date'];
        $time = $request['time'];
        $payment = $request['payment'];
        $state = $request['state'];

        $servicesId = $services[0]['id'];
        for($i = 1; $i < count($services); $i ++) {
            $servicesId .= ",".$services[$i]['id'];
        }

        $bookid = $this->getMaxID('book');
        $book = new Book;
        $book->id = $bookid;
        $book->clientid = $clientid;
        $book->barberid = $barberid;
        $book->serviceid = $servicesId;
        $book->date = $date;
        $book->time = $time;
        $book->payment = $payment;
        $book->state = $state;
        $book->save();

        $title = "Book Requested";
        $content = Auth::user()->firstname." ".Auth::user()->lastname;
        $receivers = User::where('id', $barberid)->pluck('id')->toArray();
        
        $this->notification->sendNotification($title, $content, $receivers);

        $newNotification = new Notification;
        $newNotification->typeid = $bookid;
        $newNotification->senderid = $clientid;
        $newNotification->receiverid = $barberid;
        $newNotification->type = 0;
        $newNotification->currentstate = 0;
        $newNotification->save();

        $barber = new Barber;
        $count = $barber->where(['n_id_user' => Auth::user()->id, 'n_id_user_barber' => $barberid])->count();
        if($count == 0)
        {
            $barber->n_id_user = Auth::user()->id;
            $barber->n_id_user_barber = $barberid;
            $barber->save();
        }
        
        return response(['Success' => true, 'BookID' => $bookid]);
    }

    public function updateBookState(Request $request)
    {
        Book::where('id', $request['id'])->update(['state' => $request['state']]);
        $book = Book::where('id', $request['id'])->first();
        
        $newNotification = new Notification;
        $newNotification->typeid = $request['id'];
        $newNotification->senderid = $book->barberid;
        $newNotification->receiverid = $book->clientid;
        $newNotification->type = 0;
        $newNotification->currentstate = $request['state'];
        $newNotification->save();

        if($request['state'] == 1){
            $title = "Book Cancelled";
            $content = Auth::user()->firstname." ".Auth::user()->lastname." cancelled your appointment for ".$book->date." at ".$book->time;
        }
        else if($request['state'] == 2){
            $title = "Book Confirmed";
            $content = Auth::user()->firstname." ".Auth::user()->lastname." confirmed your appointment for ".$book->date." at ".$book->time;
        }
        else if($request['state'] == 3){
            $title = "Book Completed";
            $content = Auth::user()->firstname." ".Auth::user()->lastname." completed your appointment for ".$book->date." at ".$book->time;
        }
        else if($request['state'] == 3){
            $title = "Book Declined";
            $content = Auth::user()->firstname." ".Auth::user()->lastname." declined your appointment for ".$book->date." at ".$book->time;
        }
        
        $receivers = User::where('id', $book->clientid)->pluck('id')->toArray();
        
        $this->notification->sendNotification($title, $content, $receivers);

        return response(['Success' => true]);
    }

    public function getClientBooks()
    {
        $books = Auth::user()->bookClient;
        foreach($books as $key => $item)
        {
            $item = $this->getOneFullBook($item);
        }

        return response(['Success' => true, 'Books' => $books]);
    }

    public function getOneFullBook($book)
    {
        $book->barber;
        $book->client;
        $book->bookcomments;
        $servicename = $book->serviceid;
        $lstNames = explode(",", $servicename);

        $lstServices = Service::whereIn('id', $lstNames)->get();
        $book['services'] = $lstServices;
        return $book;
    }

    public function addCut(Request $request)
    {
        if($request->hasFile('File')){
            if ($request->file('File')->isValid()) {
                $user = Auth::user();
                $image_name = date('mdYHis').uniqid().$request->file('File')->getClientOriginalName();
                $cutPath = '/uploads/cut';
                $path = public_path().$cutPath;
                $request->file('File')->move($path,$image_name);
                $cutName = $cutPath.'/'.$image_name;
                
                $cut = new Cut;
                $cut->n_id_user = Auth::user()->id;
                $cut->sz_cuts = $cutName;
                $cut->save();

                return response(['Success' => true, 'Cut' => $cut]);
            }
            return response(['Success' => false]);
        }
        return response(['Success' => false]);
    }

    public function deleteCut(Request $request)
    {
        $id = $request['id'];
        $file = Cut::where('id', $id)->value('sz_cuts');
        $file_path = public_path().$file;
        if(file_exists($file_path))
            unlink($file_path);
        Cut::where('id', $id)->delete();
        return response(['Success' => true]);       
    }

    public function suportFeedback(Request $request)
    {
        SupportFeedback::create($request->all());
        return response(['Success' => true]);
    }

    public function getAllNotifications()
    {
        
        $notifications = Notification::where('receiverid', Auth::user()->id)->orderby('created_at', 'desc')->get();
        foreach($notifications as $key => $item)
        {
            $notifications[$key]->sender;
            if($item->type == 0)
            {
                $notifications[$key]->book;
                $item->book = $this->getOneFullBook($item->book);
            }
            else if($item->type == 1)
            {
                
            }
            else if($item->type == 2)
            {
                $notifications[$key]->announcement;
            }
            else if($item->type == 3)
            {
                $notifications[$key]->bookcomment;
                $item->bookcomment->book;
                $item['book'] = $this->getOneFullBook($item->bookcomment->book);
            }
        }
        return response(['Success' => true, 'Notifications' => $notifications]);        
    }

    public function showNotifications()
    {
        Notification::where(['receiverid' => Auth::user()->id, 'show' => 0])->update(['show' => 1]);
        return response(['Success' => true]);        
    }

    public function sendBookComment(Request $request)
    {
        $bookcomment = BookComment::create($request->all());

        $book = Book::where('id', $request['bookid'])->first();
        if($book->barberid == $request['senderid'])
            $rcvid = $book->clientid;
        else
            $rcvid = $book->barberid;

        $newNotification = new Notification;
        $newNotification->typeid = $bookcomment->id;
        $newNotification->senderid = $request['senderid'];
        $newNotification->receiverid = $rcvid;
        $newNotification->type = 3;
        $newNotification->currentstate = -1;
        $newNotification->save();

        $sendUser = User::where('id', $request['senderid'])->first();

        $title = "New Comment";
        $content = "[ ".$sendUser->firstname." ".$sendUser->lastname." ] ".$request['comment'];
        $receivers = User::where('id', $rcvid)->pluck('id')->toArray();
        
        $this->notification->sendNotification($title, $content, $receivers);

        return response(['Success' => true]);
    }
}