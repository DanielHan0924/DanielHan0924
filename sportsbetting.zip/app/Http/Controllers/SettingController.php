<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Setting;

class SettingController extends Controller
{
    public function getPayment()
    {
        $setting = new Setting;
        $data = $setting->where('n_type', 0)->get();
        return view('payment', ['paymentData' => $data]);
    }

    public function setPayment(Request $request)
    {
        
    }
}