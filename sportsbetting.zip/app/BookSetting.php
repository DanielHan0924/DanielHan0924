<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookSetting extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = "book_setting";

    protected $fillable = [
        'barberid', 'auto_confirm', 'multi_service','require_phone', 'auto_comment',
        'bookinterval' , 'last_limit_hour', 'last_limit_min', 'future_limit', 'requrring_limit'
    ];
}