<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookComment extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = "bookcomment";

    protected $fillable = [
        'bookid', 'senderid', 'comment'
    ];

    public function book() {
        return $this->hasOne('App\Book', 'id', 'bookid');
    }

    public function sender() {
        return $this->hasOne('App\User', 'id', 'senderid');
    }
}