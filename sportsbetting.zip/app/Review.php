<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = "review";

    protected $fillable = [
        'n_snd_user', 'n_rcv_user', 'content', 'rate'
    ];
    public function Client()
    {
        return $this->hasOne('App\User', 'id', 'n_snd_user');
    }
}