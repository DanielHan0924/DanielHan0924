<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cut extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = "cuts";

    protected $fillable = [
        'n_id_user', 'sz_cuts'
    ];
}