<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SupportFeedback extends Model
{
    //
    protected $table = "supportfeedback";
    protected $fillable = ['type', 'email', 'description'];
}
