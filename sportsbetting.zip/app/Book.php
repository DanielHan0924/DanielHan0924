<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = "book";

    protected $fillable = [
        'clientid', 'barberid', 'serviceid', 'dates', 'time', 'payment', 'state', 'comment'
    ];

    public function barber() {
        return $this->hasOne('App\User', 'id', 'barberid');
    }
    public function client() {
        return $this->hasOne('App\User', 'id', 'clientid');
    }
    public function services() {
        return $this->hasMany('App\User', 'id', 'clientid');
    }
    public function bookcomments() {
        return $this->hasMany('App\BookComment', 'bookid', 'id');
    }
}
