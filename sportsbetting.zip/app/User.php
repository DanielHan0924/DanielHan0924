<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens; // include this
class User extends Authenticatable
{
    use Notifiable, HasApiTokens;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'avatar', 'firstname', 'lastname', 'barber', 'email', 'password'
        , 'device_token', 'iphone_device_token', 'star', 'rate'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function barbers(){
        return $this->hasMany('App\Barber', 'n_id_user');
    }
    public function clients(){
        return $this->hasMany('App\Barber', 'n_id_user_barber');
    }
    public function cuts(){
        return $this->hasMany('App\Cut', 'n_id_user');
    }
    public function metas(){
        return $this->hasOne('App\UserMeta', 'n_id_user');
    }
    public function reviews(){
        return $this->hasMany('App\Review', 'n_rcv_user');
    }
    public function locationInfo(){
        return $this->hasOne('App\Location', 'barberid');
    }
    public function service(){
        return $this->hasMany('App\Service', 'barberid');
    }
    public function info(){
        return $this->hasOne('App\Info', 'barberid');
    }
    public function location() {
        return $this->hasOne('App\Location', 'barberid');
    }
    public function bookClient() {
        return $this->hasMany('App\Book', 'clientid');
    }
    public function bookBarber() {
        return $this->hasMany('App\Book', 'barberid');
    }
    public function gallerys() {
        return $this->hasMany('App\Gallery', 'barberid');
    }
    public function booksetting()
    {
        return $this->hasOne('App\BookSetting', 'barberid', 'id');
    }
}
