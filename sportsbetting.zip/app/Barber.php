<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Barber extends Model
{
    //
    protected $table = "barbers";
    protected $fillable = ['id', 'n_id_user', 'n_id_user_barber', 'etc'];
    
    public function barber() {
        return $this->hasOne('App\User', 'id', 'n_id_user_barber');
    }
    public function client() {
        return $this->hasOne('App\User', 'id', 'n_id_user');
    }
}
