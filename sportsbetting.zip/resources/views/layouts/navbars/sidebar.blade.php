<div class="sidebar" data-color="purple" data-background-color="black" >
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="/home" class="simple-text logo-normal" style="text-transform: none;">
      {{ __('Sports betting') }}<br>
      {{ __('Admin Panel') }}
    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item{{ $activePage == 'dashboard' ? ' active' : '' }}">
        <a class="nav-link" href="{{ route('home.index') }}">
          <i class="material-icons">dashboard</i>
          <p>{{ __('Videos') }}</p>
            
        </a>
      </li>
      <li class="nav-item{{ $activePage == 'user' ? ' active' : '' }}">
        <a class="nav-link" href="#">
          <i class="material-icons">account_circle</i>
            <p>{{ __('User Management') }}</p>
        </a>
      </li>
      <li class="nav-item{{ $activePage == 'favbarber' ? ' active' : '' }}">
        <a class="nav-link" href="#">
          <i class="material-icons">account_circle</i>
            <p>{{ __('Favourite Management') }}</p>
        </a>
      </li>
      <li class="nav-item{{ $activePage == 'book' ? ' active' : '' }}">
        <a class="nav-link" href="#">
          <i class="material-icons">account_circle</i>
            <p>{{ __('Payment Management') }}</p>
        </a>
      </li>

    </ul>
  </div>
</div>