<footer class="footer">
    <div class="container">
    </div>
</footer>