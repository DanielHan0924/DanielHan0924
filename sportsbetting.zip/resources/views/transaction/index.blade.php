@extends('layouts.app', ['activePage' => 'transaction', 'titlePage' => __('Transaction Management')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title">{{ __('Transaction Management') }}</h4>
      </div>
      <div class="card-body row">
        <div class="col-md-2" style="text-align: center;">
          <br/><br/><br/>
          <form method="post" action="{{ route('transaction.store') }}" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
            @csrf
            <div class="form-group label-floating">
              <label class="control-label">Monthly</label>
              <input type="number" min="0" class="form-control" placeholder="Monthly amount" value="{{$setting[0]->value}}" name="monthly_amount" style="text-align:center; font-size:18px">
              <span class="form-control-feedback">
                {{$setting[0]->key}}
              </span>
            </div>

            <button class="btn btn-primary btn-round" onclick="this.parentElement.submit()">
              <i class="material-icons">save</i> Save
            </button>
          </form>
        </div>
        <div class="col-md-10 fresh-datatables">
        <div class="text-right">
          <form action="{{ route('transaction.destroy', 0) }}" method="post">
            @csrf
            @method('delete')
            <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete report" title="Delete report" onclick="confirm('{{ __("Are you sure you want to delete all transaction history?") }}') ? this.parentElement.submit() : ''">
            </button>
          </form>
        </div>
          <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
            <thead class=" text-primary">
              <tr >
                <th style="width:5%">{{ __('No') }}</th>
                <th style="width:5%">{{ __('Name') }}</th>
                <th style="width:15%">{{ __('Email') }}</th>
                <th style="width:20%">{{ __('Transaction Id') }}</th>
                <th style="width:5%">{{ __('amount') }}</th>
                <th style="width:5%">{{ __('Delete') }}</th>
              </tr>
            </thead>
            <tbody>
            @foreach($transactions as $index => $transaction)
            <tr>
              <td>{{$index+1}}</td>
              @if($transaction->type === 2 && $transaction->user)
                <td>{{$transaction->user->firstname}} {{$transaction->user->lastname}}</td>
                <td>{{$transaction->user->email}}</td>
              @elseif($transaction->type === 3 && $transaction->directUser)
                <td>{{$transaction->directUser->firstname}} {{$transaction->directUser->lastname}}</td>
                <td>{{$transaction->directUser->email}}</td>
              @else
                <td></td>
                <td></td>
              @endif
              <td>{{$transaction->transactionid}}</td>
              <td>{{$transaction->amount}} €</td>
              <td></td>
              <td>{{date('d M Y', strtotime($transaction->created_at))}}</td>
              <td>{{date('d M Y', strtotime($transaction->toDate))}}</td>
              <td>
                <form action="{{ route('transaction.destroy', $transaction) }}" method="post">
                    @csrf
                    @method('delete')
                    <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete report" title="Delete report" onclick="confirm('{{ __("Are you sure you want to delete this transaction?") }}') ? this.parentElement.submit() : ''">
                        <i class="material-icons">close</i>
                        <div class="ripple-container"></div>
                    </button>
                </form>
              </td>
            </tr>
            @endforeach
            </tbody>
          </table>
        </div>
      </div>
	  </div>
  </div>
</div>
@endsection