@extends('layouts.app', ['activePage' => 'user', 'titlePage' => __('Users Management')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title">{{ __('Barbers') }}</h4>
      </div>
      <div class="card-body ">
        @if (session('status'))
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span>{{ session('status') }}</span>
              </div>
            </div>
          </div>
        @endif
      
      <div class="fresh-datatables">
        <h3>My Barbers</h3>
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
            <tr >
              <th style="width:80px"> {{ __('No ') }} </th>
              <th> {{ __('Avatar') }} </th>
              <th> {{ __('FirstName') }} </th>
              <th> {{ __('LastName') }} </th>
              <th> {{ __('Email') }} </th>
              <th> {{ __('Delete') }} </th>
              <th> {{ __('Created_at') }} </th>
            </tr>
          </thead>
          <tbody >
            @foreach($myusers as  $index => $user)
            <tr>
              <td> {{$index+1}}</td>
              <td rel="tooltip"  data-original-title="{{$user->nickname}}" title="{{$user->nickname}}">
                <img src="../{{$user->avatar}}?{{time()}}" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> {{ $user->firstname }} </td>
              <td> {{ $user->lastname }} </td>
              <td> {{ $user->email }} </td>
              <td> <button rel="tooltip" type="button" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('{{ __("Are you sure you want to delete this user?") }}') ? this.parentElement.submit() : ''">
                        <i class="material-icons">close</i>
                        <div class="ripple-container"></div>
                    </button></td>
              <td>{{date('M d Y', strtotime($user->created_at))}}</td>
            </tr>
          @endforeach
          </tbody>
        </table>
        <h3>All Barbers</h3>
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
            <tr >
              <th style="width:80px"> {{ __('No ') }} </th>
              <th> {{ __('Avatar') }} </th>
              <th> {{ __('FirstName') }} </th>
              <th> {{ __('LastName') }} </th>
              <th> {{ __('Email') }} </th>
              <th> {{ __('Add') }} </th>
              <th> {{ __('Created_at') }} </th>
            </tr>
          </thead>
          <tbody >
            @foreach($allusers as  $index => $user)
            <tr>
              <td> {{$index+1}}</td>
              <td rel="tooltip"  data-original-title="{{$user->nickname}}" title="{{$user->nickname}}">
                <img src="../{{$user->avatar}}?{{time()}}" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> {{ $user->firstname }} </td>
              <td> {{ $user->lastname }} </td>
              <td> {{ $user->email }} </td>
              <td> <button rel="tooltip" type="button" class="btn btn-info btn-link" data-original-title="Add" title="Add" >
                        <i class="material-icons">add</i>
                        <div class="ripple-container"></div>
                    </button> </td>
              <td>{{date('M d Y', strtotime($user->created_at))}}</td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
@endsection