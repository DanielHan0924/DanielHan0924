@extends('layouts.app', ['activePage' => 'user', 'titlePage' => __('Users Management')])

@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        @if($user->barber == 1)
        <h4 class="card-title">{{ __('barbers') }}</h4>
        @else
        <h4 class="card-title">{{ __('Barbers') }}</h4>
        @endif
      </div>
      <div class="card-body ">
        @if (session('status'))
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span>{{ session('status') }}</span>
              </div>
            </div>
          </div>
        @endif
      
      <div class="fresh-datatables">
        @if($user->barber == 1)
        <h5 class="card-title">{{ __('My barbers') }}</h5>
        @else
        <h5 class="card-title">{{ __('My Barbers') }}</h5>
        @endif
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
            <tr >
              <th style="width:80px"> {{ __('No ') }} </th>
              <th> {{ __('Avatar') }} </th>
              <th> {{ __('FirstName') }} </th>
              <th> {{ __('LastName') }} </th>
              <th> {{ __('Email') }} </th>
              <th> {{ __('Delete') }} </th>
              <th> {{ __('Created_at') }} </th>
            </tr>
          </thead>
          <tbody >
            @foreach($user->barbers as  $index => $item)
            <tr>
              <td> {{$index+1}}</td>
              <td rel="tooltip"  data-original-title="{{$item->barber->firstname}}" title="{{$item->barber->firstname}}">
                <img src="{{$item->barber->avatar}}" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> {{ $item->barber->firstname }} </td>
              <td> {{ $item->barber->lastname }} </td>
              <td> {{ $item->barber->email }} </td>
              <td> 
              <form action="{{route('user.update', $item->barber)}}" method="post">
              @csrf
              @method('put')
                <input type="hidden" name="key" value="delete">
                <input type="hidden" name="userid" value="{{$user->id}}">
                @if($user->barber == 0)
                <button rel="tooltip" type="submit" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('{{ __("Are you sure you want to delete this user?") }}') ? this.parentElement.submit() : ''">
                  <i class="material-icons">close</i>
                  <div class="ripple-container"></div>
                </button>
                @else
                <button rel="tooltip" type="submit" class="btn btn-danger btn-link" data-original-title="Delete" title="Delete" onclick="confirm('{{ __("Are you sure you want to delete this user?") }}') ? this.parentElement.submit() : ''">
                  <i class="material-icons">close</i>
                  <div class="ripple-container"></div>
                </button>
                @endif
                </form>
              </td>
              <td>{{date('M d Y', strtotime($item->barber->created_at))}}</td>
            </tr>
          @endforeach
          </tbody>
        </table>
        @if($user->barber == 1)
        <h5 class="card-title" style = "margin-top:30px;">{{ __('Other barbers') }}</h5>
        @else
        <h5 class="card-title" style = "margin-top:30px">{{ __('Other Barbers') }}</h5>
        @endif
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
            <tr >
              <th style="width:80px"> {{ __('No ') }} </th>
              <th> {{ __('Avatar') }} </th>
              <th> {{ __('FirstName') }} </th>
              <th> {{ __('LastName') }} </th>
              <th> {{ __('Email') }} </th>
              <th> {{ __('Add') }} </th>
              <th> {{ __('Created_at') }} </th>
            </tr>
          </thead>
          <tbody >
            @foreach($barbers as  $index => $barber)
            <tr>
              <td> {{$index+1}}</td>
              <td rel="tooltip"  data-original-title="{{$barber->nickname}}" title="{{$barber->nickname}}">
                <img src="{{$barber->avatar}}" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> {{ $barber->firstname }} </td>
              <td> {{ $barber->lastname }} </td>
              <td> {{ $barber->email }} </td>
              <td>
              <form action="{{route('user.update', $barber)}}" method="post">
              @csrf
              @method('put')
                <input type="hidden" name="key" value="add">
                <input type="hidden" name="userid" value="{{$user->id}}">
                <button rel="tooltip" type="submit" class="btn btn-info btn-link" data-original-title="Add" title="Add" >
                  <i class="material-icons">add</i>
                  <div class="ripple-container"></div>
                </button> 
              </form>
              </td>
              <td>{{date('M d Y', strtotime($barber->created_at))}}</td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
@endsection