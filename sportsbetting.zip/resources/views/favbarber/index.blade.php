@extends('layouts.app', ['activePage' => 'favbarber', 'titlePage' => __('Users Management')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title">{{ __('Clients') }}</h4>
      </div>
      <div class="card-body ">
        @if (session('status'))
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span>{{ session('status') }}</span>
              </div>
            </div>
          </div>
        @endif
      <div class="row">
        <div class="col-sm-4">
          <!-- <a href="{{route('user.create')}}" class="btn btn-sm btn-primary">{{ __('Add User') }}</a> -->
        </div>
        <div class="col-sm-8" style="text-align:right; margin-bottom:20px">
          <!-- <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#position_modal">
          {{ __('Positions Manage') }}
          </button> -->
        </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> {{ __('No ') }} </th>
            <th> {{ __('Avatar') }} </th>
            <th> {{ __('FirstName') }} </th>
            <th> {{ __('LastName') }} </th>
            <th> {{ __('Email') }} </th>
            <th> {{ __('My Barbers') }} </th>
            <th> {{ __('Created_at') }} </th>
            </tr>
          </thead>
          <tbody >
            @foreach($favbarbers as  $index => $favbarber)
            <tr>
              <td> {{$index+1}}</td>
              <td rel="tooltip"  data-original-title="{{$favbarber->client->firstname}}" title="{{$favbarber->client->firstname}}">
                <img src="{{$favbarber->client->avatar}}?{{time()}}" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> {{ $favbarber->client->firstname }} </td>
              <td> {{ $favbarber->client->lastname }} </td>
              <td> {{ $favbarber->client->email }} </td>
              <td> <a href="{{route('favbarber.edit', $favbarber->client)}}" class="btn btn-primary btn-sm">
              My Barbers <span class="">{{ count($favbarber->client->barbers) }}</span>
                </a> </td>
              <td>{{date('M d Y', strtotime($favbarber->client->created_at))}}</td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
@endsection