@extends('layouts.app', ['activePage' => 'favbarber', 'titlePage' => __('Barbers Management')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title">{{$client->firstname}} {{$client->lastname}}</h4>
      </div>
      <div class="card-body ">
        @if (session('status'))
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span>{{ session('status') }}</span>
              </div>
            </div>
          </div>
        @endif
      <div class="row">
        <div class="col-sm-4">
          <!-- <a href="{{route('user.create')}}" class="btn btn-sm btn-primary">{{ __('Add User') }}</a> -->
        </div>
        <div class="col-sm-8" style="text-align:right; margin-bottom:20px">
          <!-- <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#position_modal">
          {{ __('Positions Manage') }}
          </button> -->
        </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> {{ __('No ') }} </th>
            <th> {{ __('Avatar') }} </th>
            <th> {{ __('FirstName') }} </th>
            <th> {{ __('LastName') }} </th>
            <th> {{ __('Email') }} </th>
            <th> {{ __('Score') }} </th>
            <th> {{ __('Rate') }} </th>
            <th> {{ __('Created_at') }} </th>
            </tr>
          </thead>
          <tbody >
            @foreach($barbers as  $index => $barber)
            <tr>
              <td> {{$index+1}}</td>
              <td rel="tooltip"  data-original-title="{{$barber->barber->firstname}}" title="{{$barber->firstname}}">
                <img src="{{$barber->barber->avatar}}?{{time()}}" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> {{ $barber->barber->firstname }} </td>
              <td> {{ $barber->barber->lastname }} </td>
              <td> {{ $barber->barber->email }} </td>
              <td> {{ $barber->barber->rate }} </td>
              <td> 
              <input class="star star-5" id="star-5" value="5" type="radio" name="star" disabled <?php echo $barber->barber->star == 5 ? "checked":"" ?>/>
                <label class="star star-5" for="star-5"></label>
                <input class="star star-4" id="star-4" value="4" type="radio" name="star" disabled <?php echo $barber->barber->star == 4 ? "checked":"" ?>/>
                <label class="star star-4" for="star-4"></label>
                <input class="star star-3" id="star-3" value="3" type="radio" name="star" disabled <?php echo $barber->barber->star == 3 ? "checked":"" ?>/>
                <label class="star star-3" for="star-3"></label>
                <input class="star star-2" id="star-2" value="2" type="radio" name="star" disabled <?php echo $barber->barber->star == 2 ? "checked":"" ?>/>
                <label class="star star-2" for="star-2"></label>
                <input class="star star-1" id="star-1" value="1" type="radio" name="star" disabled <?php echo $barber->barber->star == 1 ? "checked":"" ?>/>
                <label class="star star-1" for="star-1"></label>
              </td>
              <td>{{date('M d Y', strtotime($barber->created_at))}}</td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
@endsection