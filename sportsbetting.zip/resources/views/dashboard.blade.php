<!-- @extends('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')]) -->
@section('content')
  <div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        
        <div class="row">
          <div class="col-md-10">
            <h4 class="card-title">{{ __('Vimeo Videos in your Vimeo account') }}</h4>
          </div>
          <div class="col-md-2"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal_newvideo">Save new video</button></div>
        </div>
      </div>
      <div class="card-body">
      <div class="row">
        <div class="col-sm-4">
        </div>
        <div class="col-sm-8" style="text-align:right; margin-bottom:20px">
        </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr>
            <th style="width:80px"> {{ __('No') }} </th>
            <th> {{ __('Preview') }} </th>
            <th> {{ __('Category') }} </th>
            <th> {{ __('URL') }} </th>
            <th> {{ __('Created_at') }} </th>
            <th> {{ __('Updated_at') }} </th>
          </tr>
          </thead>
          <tbody >
          <?php $i = 0;?>
          @foreach($videos as  $index => $video)
          @if($videoCount != 0)
            <tr>
              <td> {{$i+1}}</td>
              <td>
                <!-- <img src="{{$video->videourl}}" style="max-width:100px; max-height:100px; border-radius:50%"> -->
                <embed type="video/webm" src="{{$video->videourl}}" width="100" height="80">
              </td>
              
              <td> {{ $video->category }} </td>
              <td> {{ $video->videourl }} </td>
              <td> {{ $video->created_at }} </td>
              <td> {{ $video->updated_at }} </td>
            </tr>
            <?php $i ++?>
          @else
          {{ __('No rows until now') }}
          @endif
          @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="modal fade" id="modal_newvideo">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title">Input new Vimeo video URL here.</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              <form class="forms_newvideo" action="video/newvideo" method="POST">
              <div class="modal-body">
              <div class="form-group row">
                  <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Category: </label></div>
                  <div class="col-md-6">
                      <select name="video_category"  class="form-control " required>
                          <!-- <option value="0" hidden>select...</option> -->
                          @foreach($video_cat as  $index => $category)
                          <option value="{{$category->category_name}}" >{{$category->category_name}}</option>
                          @endforeach
                      </select>
                  </div> 
              </div>
              <div class="form-group row">
                  <div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">New Video URL: </label></div>
                  <div class="col-md-8"><input type="text" class="form-control" name="video_url" placeholder="" required/></div> 
              </div>
              </div>
              <div class="modal-footer">
                <div class="col-md-8 d-flex"></div>
                <div class="col-md-2"><button type="submit" class="btn btn-info" >Save</button></div> 
                <div class="col-md-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button></div>
              </div>
            </form>
          </div>
      </div>
  </div> 
</div>

@endsection