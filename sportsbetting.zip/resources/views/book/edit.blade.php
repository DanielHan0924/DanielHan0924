@extends('layouts.app', ['activePage' => 'book', 'titlePage' => __('Book Management')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary row">
        <div class="col-sm-10">
            <h4 class="card-title" >{{ __('Book') }}</h4>
        </div>
        <div class="col-sm-2">
            @if($book->state == 0)
            <h5 style="padding:5px; margin-bottom:0px !important; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#ddc686,#ddc686)">REQUEST</h5>
            @elseif($book->state == 1)
            <h5 style="padding:5px; margin-bottom:0px !important; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#db6e53,#db6e53)">CANCEL</h5>
            @elseif($book->state == 2)
            <h5 style="padding:5px; margin-bottom:0px !important; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#0dd6f7,#0dd6f7)">CONFIRM</h5>
            @elseif($book->state == 3)
            <h5 style="padding:5px; margin-bottom:0px !important; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#00b894,#00b894)">COMPLETE</h5>
            @elseif($book->state == 4)
            <h5 style="padding:5px; margin-bottom:0px !important; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#db6e53,#db6e53)">DESLINE</h5>
            @endif
        </div>
      </div>
      <div class="card-body ">
        @if (session('status'))
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span>{{ session('status') }}</span>
              </div>
            </div>
          </div>
        @endif
      <div class="row" style = "margin-bottom:10px">
            <div class="col-sm-3">
                <h5 style="padding:5px; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#00b894,#00b894)">Service</h5>
            </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> {{ __('No ') }} </th>
            <th> {{ __('Name') }} </th>
            <th> {{ __('Price') }} </th>
            <th> {{ __('Duration') }} </th>
            <th> {{ __('Description') }} </th>
            </tr>
          </thead>
          <tbody >
            @foreach($services as  $index => $item)
            <tr>
              <td> {{$index+1}}</td>
              <td> {{ $item->name }} </td>
              <td> {{ $item->price }}$ </td>
              <td> 
                <?php if(($item->hour)) echo $item->hour." hour ";?>
                <?php if(($item->min)) echo $item->min." minute";?> 
              </td>
              <td> {{ $item->description }}$ </td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
      <div class="row" style = "margin-top:20px">
            <div class="col-sm-3">
                <h5 style="padding:5px; text-align:center; color:white; border-radius:3px; background:linear-gradient(60deg,#00b894,#00b894)">Book Comment</h5>
            </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> {{ __('No ') }} </th>
            <th> {{ __('Avatar') }} </th>
            <th> {{ __('First Name') }} </th>
            <th> {{ __('Last Name') }} </th>
            <th> {{ __('Comment') }} </th>
            <th> {{ __('Created_at') }} </th>
            </tr>
          </thead>
          <tbody >
            @foreach($bookcomments as  $index => $item)
            <tr>
              <td> {{$index+1}}</td>
              <td rel="tooltip"  data-original-title="{{$item->sender->firstname}}" title="{{$item->sender->lastname}}">
                <img src="{{$item->sender->avatar}}?{{time()}}" style="max-width:100px; max-height:100px; border-radius:50%">
              </td>
              <td> {{ $item->sender->firstname }} </td>
              <td> {{ $item->sender->lastname }} </td>
              <td> {{ $item->comment }} </td>
              <td>{{date('M d Y', strtotime($item->created_at))}}</td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
@endsection