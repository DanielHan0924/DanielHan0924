@extends('layouts.app', ['activePage' => 'book', 'titlePage' => __('Book Management')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="card registration">
      <div class="card-header card-header-primary">
        <h4 class="card-title">{{ __('Book') }}</h4>
      </div>
      <div class="card-body ">
        @if (session('status'))
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <i class="material-icons">close</i>
                </button>
                <span>{{ session('status') }}</span>
              </div>
            </div>
          </div>
        @endif
      <div class="row">
        <div class="col-sm-4">
          <!-- <a href="{{route('user.create')}}" class="btn btn-sm btn-primary">{{ __('Add User') }}</a> -->
        </div>
        <div class="col-sm-8" style="text-align:right; margin-bottom:20px">
          <!-- <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#position_modal">
          {{ __('Positions Manage') }}
          </button> -->
        </div>
      </div>
      <div class="fresh-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%"  style='text-align:center'>
          <thead class=" text-primary">
          <tr >
            <th style="width:80px"> {{ __('No ') }} </th>
            <th> {{ __('Client') }} </th>
            <th> {{ __('Barber') }} </th>
            <th> {{ __('Date') }} </th>
            <th> {{ __('Time') }} </th>
            <th> {{ __('Payment') }} </th>
            <th> {{ __('Status') }} </th>
            <th> {{ __('Detail') }} </th>
            <th> {{ __('Created_at') }} </th>
            </tr>
          </thead>
          <tbody >
            @foreach($books as  $index => $item)
            <tr>
              <td> {{$index+1}}</td>
              <td> {{ $item->client->firstname }} {{ $item->client->lastname }} </td>
              <td> {{ $item->barber->firstname }} {{ $item->barber->lastname }} </td>
              <td> {{ $item->date }} </td>
              <td> {{ $item->time }} </td>
              <td> {{ $item->payment }} </td>
              <td> 
              @if($item->state == 0)
              <label style = "color:#ddc686 ">REQUEST</label>
              @elseif($item->state == 1)
              <label style = "color:#db6e53 ">CANCEL</label>
              @elseif($item->state == 2)
              <label style = "color:#0dd6f7 ">CONFIRM</label>
              @elseif($item->state == 3)
              <label style = "color:#00b894 ">COMPLETE</label>
              @elseif($item->state == 4)
              <label style = "color:#db6e53 ">DECLINE</label>
              @endif
              </td>
              <td> <a href="{{route('book.edit', $item)}}" class="btn btn-primary btn-sm">
              View</span>
                </a> </td>
              <td>{{date('M d Y', strtotime($item->created_at))}}</td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
@endsection