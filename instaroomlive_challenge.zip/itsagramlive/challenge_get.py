from ItsAGramLive import ItsAGramLive

live = ItsAGramLive()

# live = ItsAGramLive(
#     username='johndoe.se',
#     password='liveinstagram'
# )

live.get_code_challenge_required_outside(1)