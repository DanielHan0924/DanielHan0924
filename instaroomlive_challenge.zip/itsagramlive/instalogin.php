<?php
    session_start();
    if (isset($_POST['instausername']) && isset($_POST['instapassword'])) {
        $_SESSION['instausername'] = $_POST['instausername'];
        $_SESSION['instapassword'] = $_POST['instapassword'];
        //invoke Python file to get the URL and key
    
        // $output = system("C:\Python37\python.exe live_broadcast.py -u ".$_POST['instausername']." -p ".$_POST['instapassword']." -proxy lum-customer-c_1df55f5f-zone-instagram:hfri6cw9oubj@zproxy.lum-superproxy.io:22225");
        // $output = shell_exec("python live_broadcast.py -u ".$_POST['instausername']." -p ".$_POST['instapassword']);
        $output = shell_exec("python live_broadcast.py -u ".$_POST['instausername']." -p ".$_POST['instapassword']." -proxy lum-customer-c_1df55f5f-zone-instaresidential:a6cfy7e744sl@zproxy.lum-superproxy.io:22225");
        if($output != null){
            //check if login error
            // contents: "{'message': 'The password you entered is incorrect. Please try again.', 'invalid_credentials': True, 'error_title': 'Incorrect password for test', 'buttons': [{'title': 'Try Again', 'action': 'dismiss'}], 'status': 'fail', 'error_type': 'bad_password'}↵2↵Enter the code: "
            $bad_pw = "bad_password";
            $get_stream = "Broadcast ID";
            $challenge_mode = "challenge_required";
                         
            if(strpos($output, $bad_pw) != false){
                // echo "Word Found!";
                $response = array('status' => 'loginfailed','contents'=>$output);

            } elseif (strpos($output, $get_stream) != false){
             
                $response = array('status' => 'success','contents'=>$output);
            } elseif (strpos($output, $challenge_mode) != false){
                $response = array('status' => 'challenge','contents'=>$output);
            }
            echo json_encode($response); return;

        }else{
            $response = array('status' => 'failed','contents'=>'noconnect');
            echo json_encode($response); return;
        }
        
    }
    elseif (isset($_POST['stop']) && $_POST['stop']=='yes' ) {
        # code...
        $output = shell_exec("python stop_broadcast.py -u ".$_SESSION['instausername']." -p ".$_SESSION['instapassword']);
        if($output != null){
            $response = array('status' => 'success','contents'=>$output);
            echo json_encode($response); return;

        }else{
            $response = array('status' => 'success','contents'=>'noconnect');
            echo json_encode($response); return;
        }
    }
    elseif (isset($_POST['getchallengemode']) && $_POST['getchallengemode'] != '' && $_POST['setchallengcode'] == ''){
        # code...
        $output = shell_exec("python challenge_get.py -u teyd -p teyd");
        if($output != null){
            $response = array('status' => 'getsuccess','contents'=>$output);
            echo json_encode($response); return;

        }else{
            $response = array('status' => 'getsuccess','contents'=>'noconnect');
            echo json_encode($response); return;
        }
    }
    elseif (isset($_POST['setchallengcode']) && $_POST['setchallengcode'] != '') {
        # code...
        $output = shell_exec("python challenge_set.py -u -u teyd -p teyd");
        if($output != null){
            $response = array('status' => 'setsuccess','contents'=>$output);
            echo json_encode($response); return;

        }else{
            $response = array('status' => 'setsuccess','contents'=>'noconnect');
            echo json_encode($response); return;
        }
    }
    else {    

        $response = array('status' => 'postfailed');
        echo json_encode($response); return;
        
    } 
?>

