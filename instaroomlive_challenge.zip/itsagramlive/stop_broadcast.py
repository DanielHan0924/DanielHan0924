from ItsAGramLive import ItsAGramLive

live = ItsAGramLive()

# live = ItsAGramLive(
#     username='johndoe.se',
#     password='liveinstagram'
# )

live.stop()
