<?php 

if( isset($_POST['a'])){

    $a = $_POST['a'];
    $b = $_POST['b'];
    $c = $_POST['c'];

    $x = $a / $b * $c;

    $d = $x + $c;
    $d = number_format($d, 2, '.', '');
    $e = $x/4 +$c;
    $e = number_format($e, 2, '.', '');
    $f = $x/5 + $c;
    $f = number_format($f, 2, '.', '');
    $g = $x + $e + $c;
    $g = number_format($g, 2, '.', '');
    $h = $x + $f + $c;
    $h = number_format($h, 2, '.', '');

    $response = array('status' => 'success', 'd'=>$d, 'e'=>$e, 'f'=>$f, 'g'=>$g, 'h'=>$h);
    echo json_encode($response); return;
    
} else{ 
    $response = array('status' => 'failed');
    echo json_encode($response); return;
}
?>