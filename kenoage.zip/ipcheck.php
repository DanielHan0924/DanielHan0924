<?php
// srand((double)microtime()*1000000);
// session_start();

function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));

    $support = array("ip","is_eu","country", "countrycode", "state", "region", "city", "location", "address");
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        
        $ipdat_coutrycode = file_get_contents('https://api.ipdata.co/country_code?api-key=92c325267c5d9e9a0b796664d0edffc27933fe34dadb367fbabf409a');
        
        if (@strlen(trim($ipdat_coutrycode)) == 2) {
            switch ($purpose) {
                case "countrycode":
                    $output['countrycode'] = $ipdat_coutrycode;
                break;
            }
        }
    }
    return $output;
}

$_SESSION['country_code'] =  ip_info("Visitor", "Country Code")['countrycode'];
//Following codes is useless right now.

    if(ip_info("Visitor", "Country Code") == "US")
    {

        $casino=rand(1,3); // How many US casinos?

        if ($casino==1)
        {echo ''; }
        if ($casino==2)
        {echo ''; }
        if ($casino==3)
        {echo ''; }
    }
    else
    {
        $casino=rand(1,3); // How many UK casinos?

        if ($casino==1)
        {echo ''; }
        if ($casino==2)
        {echo ''; }
        if ($casino==3)
        {echo ''; }

    }
?>