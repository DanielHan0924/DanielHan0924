<template>
  <div
    class="btn common"
    :class="this.buttonData.buttonType"
    @mouseover="enterCell"
    @mouseleave="leaveCell"
    @dragleave="leaveCell"
    @click="clickCell"
    @drop="dropDrag"
    @dragover="enterCell"
    @dragover.prevent
    @dragenter.prevent
  >
    <button
      v-if="this.latestChip && this.latestChip.price"
    
      v-bind:style="{ maxWidth: maxWidth }"
      v-bind:class="{ 'img-transition': maxWidth }"
      class="chip"
    >
    
    <div v-for="chip in this.getButtonsPerCell" :key="chip.price"  class="cell-container-margin" >
      <img
        :src="getImageUrlFromPrice(chip.price)"
        class="img-transition"
        v-bind:style="{ maxWidth: maxWidth }"
        alt="100"
      /> 
    </div>
    </button>
    <div
        v-if="showInfo"
        class="tooltip"
    >
      <ul>
        <li>PUNTATA: {{ getCellStake }} €</li>
        <li>{{ buttonData.stakeType }}</li>
        <li>Paga {{ buttonData.winning }} a 1</li>
        <li>MIN: €0,10</li>
        <li>MAX: €100</li>
      </ul>
    </div>
  </div>
</template>

<script>
import { chips } from "./Chips";
import { mapState } from "vuex";

export default {
  name: "CellButton",
  data() {
    return {
      chips: chips,
      maxWidth: false,
      showInfo: false,
      testflag: true
    };
  },
  computed: {
    ...mapState(["drag", "dragPrice", "placedChips"]),
    getCellStake() {
      const getChipsPacedInCell = this.placedChips.filter( c => c.place === this.buttonData.id)
      return getChipsPacedInCell.map( c => c.price ).reduce( ( a, b ) => a + b, 0)
    },
    getFirstButtonsPerCell(){
      const buttonsPerCell = this.placedChips.filter( c => c.place === this.buttonData.id)
      let arr = Array()
      arr = Object.keys(buttonsPerCell).map((index) => buttonsPerCell[index])
      console.log('type:',typeof(arr))
      return arr.slice(0, 1)
    },
    getButtonsPerCell(){
      const buttonsPerCell = this.placedChips.filter( c => c.place === this.buttonData.id)
      let arr = Array()
      arr = Object.keys(buttonsPerCell).map((index) => buttonsPerCell[index])
      console.log('type:',typeof(arr))
      return arr.slice(0, 5)
    }
  },
  watch: {
    latestChip: {
      // the callback will be called immediately after the start of the observation
      immediate: true,
      handler(val, oldval) {
        if (
          !oldval ||
          val.isLastPlaced !== oldval.isLastPlaced ||
          val.price !== oldval.price
        )
          this.getMaxWidth();
      },
    },
  },
  props: {
    buttonData: Object,
    latestChip: Object,
  },
  methods: {
    enterCell() {
      if (window.innerWidth > 1080) {
        this.showInfo = true
      }
      if (this.drag) this.$parent.enterCell(this.buttonData.cells);
    },
    leaveCell() {
      this.showInfo = false
      this.$parent.leaveCell();
    },
    clickCell() {
      if (this.drag && this.dragPrice) {
        this.$parent.clickCell(this.buttonData.id, this.dragPrice, this.buttonData.winning, this.buttonData.stakeType);
      }
    },
    dropDrag() {
      if (this.drag && this.dragPrice) {
        this.$parent.clickCell(this.buttonData.id, this.dragPrice, this.buttonData.winning, this.buttonData.stakeType);
      }
      this.$store.dispatch("dropDrag");
    },
    getImageUrlFromPrice(recentPrice) {
      const latestChip = this.chips.find(
        // (chip) => chip.price === this.latestChip.price
        (chip) => chip.price === recentPrice
      )

      return latestChip ? latestChip.src : null;
    },
    getMaxWidth() {
      if (this.latestChip.isLastPlaced) {
        this.maxWidth = true;
        setTimeout(() => {
          this.maxWidth = false;
        }, 10);
      }
    },
  },

};
</script>

<style lang="scss" scoped>
.vertical {
  width: 1vw;
  height: 6.3vw;
  transform: translateX(-50%);
  z-index: 4;
  @media screen and(max-width:1080px) {
    top: 0vw;
    height: 9.3vw;
    button{
      // margin-bottom: -2vw;
    }
  }
}
.horizontal {
  width: 6.3vw;
  height: 1vw;
  transform: translateY(-50%);
  z-index: 4;
  @media screen and(max-width:1080px) {
    width: 12.3vw;
    button{
      margin-bottom: 6vw;
    }
  }
}
.center {
  width: 2vw;
  height: 2vw;
  transform: translate(-50%, -50%);
  z-index: 5;
  @media screen and(max-width:1080px) {
    margin-top: 1.5vw;
    button{
      margin-bottom: 9vw;
    }
  }
}
.self {
  width: 6.25vw;
  height: 6.25vw;
  z-index: 3;
  @media screen and(max-width:1080px) {
    width: 12.25vw;
    height: 10.25vw;
    // margin-top: 2vw;
    .chip{
      // margin-bottom: 5vw;
    }
  }
}
.chip {
  padding: 0.2vw 0 0 0.2vw;
  transition: 0.1s all cubic-bezier(0.6, -0.28, 0.74, 0.05);
  margin-bottom: 2vw;
  @media screen and(max-width:1080px) {
      margin-bottom: 4vw;
      width:21vw;
      height:9vw;
  }
  img {
    max-width: 3vw;
    transition: 0.1s all cubic-bezier(0.6, -0.28, 0.74, 0.05);
    @media screen and(max-width:1080px) {
      max-width: 5.0vw; 
      transform: rotate(270deg);

    }
  }
}
.img-transition {
  max-width: 5vw;
  transition: none;
  img {
    transition: none;
    max-width: 5vw;
 
  }
  
}

.tooltip {
  position: absolute; /* making the .tooltip span a container for the tooltip text */
  top:20%;
  left:60%;
  //transform:translateY(-50%, -50%);
  margin-left:15px; /* and add a small left margin */

  /* basic styles */
  min-width: 130px;
  width: fit-content;
  height: auto;
  padding: 5px 10px;
  border: 3px solid #ffffff;
  border-radius: 20%;
  background: rgba(31, 30, 30, 0.8);
  color: #ffffff;
  text-align:left;
  font-size: 13px;
}
.cell-container-firstChip{
  // margin-bottom: 0vw;

  display: block;
}
.cell-container-margin{
  // margin-bottom: -60px;
  // margin-top: -69px;
  margin-bottom: -3vw;
  @media screen and(max-width:1080px) {
    margin-bottom: -6vw; 
  }

}
.cell-container-disabled{
  display: none;
}
</style>
