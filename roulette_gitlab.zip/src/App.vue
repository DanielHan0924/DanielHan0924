<template>
  <div class="roulette-game">
    <span class="history-maxwin__value" style="color: white;font-size: 11px; margin-top:6px;margin-left:30px;">MAX WIN €10.000,00</span> 
    <div class="game">
      <div class="game-left ">
        <Wheel />
        <ChipField />
      </div>
      <div class="game-center ">
        <BettingTable />
        <GameControl />
      </div>
      <div class="game-right ">
        <History />
      </div>
    </div>
    <Summary />
  </div>
</template>


<script>
import Wheel from "./components/Wheel";
import BettingTable from "./components/BettingTable";
import History from "./components/History";
import ChipField from "./components/ChipField";
import GameControl from "./components/GameControl";
import Summary from "./components/Summary";

export default {
  name: "App",
  components: {
    Wheel,
    BettingTable,
    History,
    ChipField,
    GameControl,
    Summary,
  },
};
</script>

<style lang="scss" scoped>
 .history-maxwin__value{
   display: none;
    @media screen and (max-width: 1080px){
      display: block;
    }
}
</style>
