=====20/20/2021====

Hi, Pargol

I have gone through the whole doc.
I think the doc include new logical tasks as well as recent moblie responsible issues.

Let me leave my rough opinions (!!!)/queries (???).

DEVELOPERS:

    1. Maximum Bet:

    !!! This section is really of new logical for chip limitation and we will have to go back to the drawing board: I mean it will 2~3 days work.

    2. Autostart:
        a. sometimes, after the first spin the bet on the betting table vanishes, it is no longer called.

        ??? The first spin in case autosstart? I have never seen such a issue in individual spinning.

        b. the total number of laps chosen and their decrease does not appear.
        ....  *On the last round the copy appears to fast, even when the autostart is not finished.

        ??? Could you add more details on it? I did not understand. 

    5. Audio key: Should remove from the bar on the table and replace into the setting area 

    !!! if the client want all the setting widget like audio button in Setting widet, he/she will have to provide UI at least for individual audio (background sound, play sound, chip sound etc) ON/OFF button position as well as setting buttons (I mean there is setting buttons UI ONLY on the doc.)
    8. Safari
        a. The wheel is messed up on Safari ( mobile and desktop ).
        
        !!! As you experienced, it could be due to Safari browser loading speed.

        b. the design and spacing are not followed as the original design on Xd.  

        !!! I have to give in the design for Safari if the client is upset about the recent work for Safari UI.

    ➧ MOBILE (PORTRAIT):
        6. BET TABLE : The areas where you bet ,are all staggered and in some cells you can not bet.

        !!! I will fix it by Sunday afternoon.
    
INTERNAL DEVELOPMENT/TEST:

    1. Animation of the wheel:

        a. At the end of the wheel spinning, the wheel position will change.

        !!! Now the wheel position is reset to default degree once the spinning is stopped. So we will have to link the idle rotation to recent degree instead of using separate rotation function.

        b. The golden circle of the wheel when you see the selected number doubles.

        ??? Sorry but I what is the "doubles"? 

        c. the winning wedge is lit gold, but there is a large shade on the edge and it shouldn't be there.

        ??? does it mean the thick "blue" of golden mark?

    2. Popup YOU WIN, YOU LOSE, GAME OVER:

        a. YOU WIN: We have never seen it (NEVER on Chrome) and when it is seen (very rarely) it appears too fast in a non-compliant point in fact you do not understand how much you are winning. 

        ??? Could you explain more about the winning/losing logic as long as the client is not satisfied with the recent one?
    3. Last numbers area:

        a. The section dedicated to the issued numbers changes width according to the  numbers it contains, instead it must have a fixed size.

        ??? So any number area size on the table should be flexible according to the numbers of chips on it? If so, it might be improbable with recent CSS work because the recent Vue project do not use any Vue game libraries.

For me thought, your client should think more about the mobile app development (by using hybrid mobile application development platform like Flutter to save the budget instead of spending money on unlimited responsible issues.)
I don't think that we can fix all those potential, sensitive mobile responsible issues (especially iPhone Safari issue) once and for all by relying only on Vue components.
If not, we have to consider Vue game libraries like https://madewithvuejs.com/defuse. Furthermore, the roulette game is using table/cell clicking event much so it will be required for responsible issues.

Anyway, all those suggestion will require more time/budget so I will be fully open to your final decision.

Thanks for extending your patiences during these challenging period.
Rest assured that I will be at your disposal for our honest relationship.

I will be available from Sunday to work for you.

Best regards,

Yulia

---02/22---
1. Maximum Bet: 14 hours;
2. Autostart: 6 hours;
3. Balance Management: 8 hours;
4. Table of the Bets: I will do it as free as long as you can provide a relevant Font family/ weight for the numbers;
5.Audio key: 12 hours;
6. Settings key: 14 hours
7. Tooltip: Free work;
8. Safari: Sorry but I have to give up;

➧ MOBILE (PORTRAIT):
1~5: 12 hours;
6. BET TABLE : Fixed;

INTERNAL DEVELOPMENT/TEST:

I am gonna say more once I get answers from you.

ON HOLD (except for 2 and 3): 8 hours

Total: 14+6+8+12+14+12+8 = 74 hour+
Hourly rate: 15 USD;
Total budget: 1100







