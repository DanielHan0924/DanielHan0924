import React from 'react';
import { observer } from 'mobx-react';
import {
    Button, Form,
    FormGroup, Label,
    Input, FormText,
    Row, Col,
    Card, CardBody,
    CardTitle, Container,  InputGroup, InputGroupAddon,
} from 'reactstrap';
import { injectIntl, FormattedMessage } from 'react-intl';
import { TextField, SelectionControl } from "react-md";
import DatePicker from 'react-datepicker';
import _ from "lodash";
import { toJS } from "mobx";
import { SingleDatePicker } from 'react-dates';
import moment from 'moment';

import ApiMiddleware from "../../../../../services/Api";
import Auth from "../../../../../services/Auth";

import MultiSelector from "../../../MultiSelector/MultiSelector";

import AdminStore from "../../../../../models/AdminStore";

import {
    faCalendarAlt,
    faPlusCircle,
    /*faRemoveFormat,*/
    faTrashAlt
  } from '@fortawesome/free-solid-svg-icons';
  
  import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const AddEquipmentForm = observer(
    class AddEquipmentForm extends React.Component {
      constructor(props) {
          super(props);

          this.state = {
              type: null,
              equipment: {
                  id: null,
                  name: '',
                  model: null,
                  category: null,
                  purchaseDate: moment(),
                  
                  purchasePrice: '',
                  active: false,
              },
              purchaseDate_date: new Date(),
          }
      }
      handleChangeAllDate = ({startDate, endDate}) => {
        startDate = startDate || this.state.startDate
       
  
        const startDate_moment = moment(startDate);
       
        // console.log("Date()type to moment-------",startDate_moment);
        this.setState({startDate})
       
      }
  
      handleChangeStart = (startDate) => this.handleChangeAllDate({startDate})
  
      handleChangeEnd = (endDate) => this.handleChangeAllDate({endDate})

      handleFormSubmit() {
        const boundingCoordinates = toJS(AdminStore.drawingCoordinates);

          if(this.state.type === 'new') {

            const params = {
                premise_id: this.props.premiseId,
                name: this.state.equipment.name,
                model: { id: this.state.equipment.model },
                equipment_category_id: this.state.equipment.category,
                purchase_date: moment(this.state.equipment.purchaseDate).toISOString(),
                purchase_price: this.state.equipment.purchasePrice,
                tag: null,
                active: this.state.equipment.active === true ? 'True' : 'False',
            };

            const selectedCategory = _.find(this.props.categories, (c) => { 
                return `${c.id}` === `${this.state.equipment.category}`;
            });

            if(selectedCategory && selectedCategory.equipment_category_id_parent) {
                params.equipment_category_id_parent = selectedCategory.equipment_category_id_parent;
            }

            api
            .post(`/equipment`, params)
            .then(response => {
              let addedEquipmentId;

              if(typeof response.data.equipment_id === 'string' || typeof response.data.equipment_id === 'number') {
                addedEquipmentId = response.data.equipment_id;
              } else {
                addedEquipmentId = response.data.equipment_id[0];
              }

              // Logic to handle 
              let boundingBox = [];
              if(boundingCoordinates[0].x < boundingCoordinates[1].x) {
                  boundingBox[0] = boundingCoordinates[0].x;
                  boundingBox[2] = boundingCoordinates[1].x;
              } else {
                  boundingBox[0] = boundingCoordinates[1].x;
                  boundingBox[2] = boundingCoordinates[0].x;
              }
  
              if(boundingCoordinates[0].y < boundingCoordinates[1].y) {
                  boundingBox[1] = boundingCoordinates[0].y;
                  boundingBox[3] = boundingCoordinates[1].y;
              } else {
                  boundingBox[1] = boundingCoordinates[1].y;
                  boundingBox[3] = boundingCoordinates[0].y;
              }

              const locationParams = {
                equipment_id: addedEquipmentId,
                device_id: this.props.deviceId,
                bounding_box: boundingBox
              };

              document.getElementById('equipment-temporary').outerHTML = "";
              AdminStore.setMappingNew(false);
              AdminStore.resetEquipment();

              api
                .post(`/equipment/${addedEquipmentId}/device_equipment_location`, locationParams)
                .then(response => {
                    AdminStore.fetchEquipment();
                });
            });

          } else {
            const equipmentId = _.map(AdminStore.selectedEquipment, (item, key) => {
                return key;
            })[0];

            // Logic to handle 
            let boundingBox = [];
            if(boundingCoordinates[0].x < boundingCoordinates[1].x) {
                boundingBox[0] = boundingCoordinates[0].x;
                boundingBox[2] = boundingCoordinates[1].x;
            } else {
                boundingBox[0] = boundingCoordinates[1].x;
                boundingBox[2] = boundingCoordinates[0].x;
            }

            if(boundingCoordinates[0].y < boundingCoordinates[1].y) {
                boundingBox[1] = boundingCoordinates[0].y;
                boundingBox[3] = boundingCoordinates[1].y;
            } else {
                boundingBox[1] = boundingCoordinates[1].y;
                boundingBox[3] = boundingCoordinates[0].y;
            }

            const locationParams = {
                equipment_id: equipmentId,
                device_id: this.props.deviceId,
                bounding_box: boundingBox
              };

              // Close modal
              document.getElementById('equipment-temporary').outerHTML = "";
              AdminStore.setMappingNew(false);
              AdminStore.resetEquipment();

              api
                .post(`/equipment/${equipmentId}/device_equipment_location`, locationParams)
                .then(response => {
                    AdminStore.fetchEquipment();
                });
          }
      }

      render() {
        return (
        <div>

            { this.state.type === null ? (
                <div>
                    <p className="Admin__ConfirmRemoveInfo">
Choose whether to add a new device or mark an existing one.</p>
                    <div className="Admin__addDeviceActions"> 
                        <Button 
                            raised="true" primary="true" className="btn-filter"
                            onClick={() => this.setState({type: 'new'})}>
                            <FormattedMessage id="admin.newEquipment" />
                        </Button>
                        <Button 
                            raised="true" primary="true" className="btn-danger"
                            onClick={() => this.setState({type: 'existing'})}
                            >
                            <FormattedMessage id="admin.selectExistingEquipment" />
                        </Button>
                     </div>
                    
                </div>
            ) : (
                this.state.type === 'new' ? this.addForm() : this.selectForm()
            )}
        </div>
        )
    }

    handleCancel() {
        // Close modal
        AdminStore.setMappingNew(false);

        // Remove temporary bounding box
        document.getElementById('equipment-temporary').outerHTML = "";
    }
    handleEquipmentSelection(item) {
        AdminStore.setSelectedEquipmentModel(item);
    }
    selectForm() {
        return (
            <div>
                <FormGroup>
                    <label><FormattedMessage id="admin.equipment" /></label>
                    <MultiSelector
                        type="equipment"
                        items={this.props.equipment}
                        valueProperty="name"
                        selectedItems={AdminStore.selectedEquipment}
                        onChange={this.handleEquipmentSelection}
                        forceSingleSelection={true}
                        ignoreHierarchy={true}
                    />
               </FormGroup>

                <div style={{marginTop: '10px'}}>
                    <Button 
                        raised="true" primary="true"
                        className='btn-filter'
                        style={{float: 'left', marginLeft: 0}}
                        onClick={() => this.handleCancel()}>
                        <FormattedMessage id="admin.cancel" />
                    </Button>
                    <Button raised="true" primary="true"  className='btn-danger' onClick={() => this.handleFormSubmit()}>
                        <FormattedMessage id="admin.select" />
                    </Button>
                </div>
            </div>
        );
    }
    addForm() {
        const { formatMessage, categories, models } = this.props;
        return (
        <div>
            <FormGroup>
                <Label for="deviceName">Equipment Name</Label>
                <Input type="text" name="equipmentName" id="equipmentName"
                    value={this.state.equipment.name}
                    onChange={(e) => {
                        this.setState({
                            equipment: {
                                ...this.state.equipment,
                                name: e.target.value
                            }
                        })
                        }}     
                />  
            </FormGroup>  
        { models && models.length > 0 ? (
             <FormGroup>
                <label>{ formatMessage({id: 'admin.equipmentBrand'})}</label>
                <MultiSelector
                    type="brand"
                    items={models}
                    onChange={modelId => {
                        this.setState({
                            equipment: {
                                ...this.state.equipment,
                                model: modelId,
                            }
                        })
                    }}
                    selectedItems={ this.state.equipment.model ? {[this.state.equipment.model]: true} : {} }
                    forceSingleSelection={true}
                    disableTopLevelSelection={true}
                    valueProperty="name"
                />
                    
            </FormGroup>
        ) : '' }
        { categories && categories.length > 0 ? (
            <FormGroup>
                <label>{ formatMessage({id: 'admin.equipmentCategory'})}</label>
                <MultiSelector
                    type="category"
                    items={categories}
                    onChange={categoryId => {
                        this.setState({
                            equipment: {
                                ...this.state.equipment,
                                category: categoryId,
                            }
                        })
                    }}
                    selectedItems={ this.state.equipment.category ? {[this.state.equipment.category]: true} : {} }
                    forceSingleSelection={true}
                    valueProperty="name"
                />
                <span className="Admin__editEquipmentFormInfo"><FormattedMessage id="admin.selectMostSpecificCategory" /></span>
            </FormGroup>
        ) : '' }

        {/* <div className="Admin__editEquipmentPurchaseDate">
            <label>{ formatMessage({id: 'admin.equipmentPurchaseDate'})}</label>
            <SingleDatePicker
                date={this.state.equipment.purchaseDate}
                onDateChange={date => this.setState({ equipment: { ...this.state.equipment, purchaseDate: date }})}
                focused={this.state.focused}
                onFocusChange={({ focused }) => this.setState({ focused })}
                id="purchaseDate"
                noBorder={true}
                placeholder={''}
                small={true}
                isOutsideRange={date => date >= moment().startOf("day")}
                numberOfMonths={1}
            />
        </div> */}
        <FormGroup>
            {/* <label>{ formatMessage({id: 'admin.equipmentPurchaseDate'})}</label>
            <DatePicker
                date={this.state.equipment.purchaseDate_date }
                selected={this.state.purchaseDate_date}
                onDateChange={date => this.setState({ equipment: { ...this.state.equipment, purchaseDate: date }})}
                focused={this.state.focused}
                onFocusChange={({ focused }) => this.setState({ focused })}
                id="purchaseDate"
                noBorder={true}
                placeholder={''}
                small={true}
                isOutsideRange={date => date >= moment().startOf("day")}
                numberOfMonths={1}
            /> */}
            
            <Label for="exampleEmail" className="mr-sm-2">{ formatMessage({id: 'admin.equipmentPurchaseDate'})}</Label>
            <InputGroup>
                <InputGroupAddon addonType="prepend">
                    <div className="input-group-text">
                        <FontAwesomeIcon icon={faCalendarAlt}/>
                    </div>
                </InputGroupAddon>
                <DatePicker
                    selected={this.state.purchaseDate_date}
                    selectsStart
                    className="form-control"
                    data={this.state.purchaseDate_date}
                    // onChange={this.handleChangeStart}
                    onChange={date => this.setState({ equipment: { ...this.state.equipment, purchaseDate: moment(date) },purchaseDate_date:date})}
                />
            </InputGroup>
           
        </FormGroup>

        {/* <TextField
            id="floating-center-title"
            label={ formatMessage({id: 'admin.equipmentPurchasePrice'})}
            lineDirection="center"
            placeholder={ formatMessage({id: 'admin.equipmentPurchasePrice'})}
            className="md-cell md-cell--top"
            value={this.state.equipment.purchasePrice}
            onChange={(value) => {
                this.setState({
                    equipment: {
                        ...this.state.equipment,
                        purchasePrice: value
                    }
                })
            }}
        /> */}
        <FormGroup>
            <Label for="equipmentPurchasePrice">Purchase Price</Label>
            <Input type="text" name="equipmentPurchasePrice" id="equipmentPurchasePrice"
                value={this.state.equipment.purchasePrice}
                onChange={(e) => {
                this.setState({
                    equipment: {
                        ...this.state.equipment,
                        purchasePrice: e.target.value                        }
                })
            }}
            />  
        </FormGroup>  


        <div>
            <SelectionControl
            id="is-active"
            type="switch"
            label={ formatMessage({id: 'admin.deviceActive'})}
            name="active"
            checked={ this.state.equipment.active === true ? true : false }
            onChange={(checked) => {
                // console.log(checked);
                this.setState({
                    equipment: { ...this.state.equipment, active: checked }
                })
            }}
            />
        </div>
        <Button raised="true" primary="true" className="btn-danger" onClick={() => this.handleCancel()}>
            <FormattedMessage id="admin.cancel" />
        </Button>
        <Button raised="true" primary="true" className="btn-filter"  onClick={() => this.handleFormSubmit()}>
            <FormattedMessage id="admin.save" />
        </Button>
        
    </div>
    );
    }
  }
);

export default injectIntl(AddEquipmentForm);
