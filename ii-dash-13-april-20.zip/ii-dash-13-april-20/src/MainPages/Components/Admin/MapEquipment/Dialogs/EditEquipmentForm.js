import React from 'react';
import { observer } from 'mobx-react';
import { injectIntl, FormattedMessage } from 'react-intl';
import _ from 'lodash';
import { TextField, SelectionControl } from "react-md";
import { SingleDatePicker } from 'react-dates';
import {
    InputGroup, InputGroupAddon
} from 'reactstrap';
import {
    faCalendarAlt,

} from '@fortawesome/free-solid-svg-icons';

import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import DatePicker from 'react-datepicker';
import moment from 'moment';
import {
    Button, Form,
    FormGroup, Label,
    Input, FormText,
    Row, Col,
    Card, CardBody,
    CardTitle, Container,
} from 'reactstrap';

import ApiMiddleware from "../../../../../services/Api";
import Auth from "../../../../../services/Auth";

import MultiSelector from "../../../MultiSelector/MultiSelector";

import AdminStore from "../../../../../models/AdminStore";

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const EditEquipmentForm = observer(
    class EditEquipmentForm extends React.Component {
      constructor(props) {
            super(props);

            const { equipment} = this.props;
    
            const selectedEquipment = _.find(equipment, (eq) => {
                return parseInt(eq.id, 10) === AdminStore.editingEquipment;
            });
  
            this.state = {
                equipment: {
                    id: selectedEquipment.id,
                    name: selectedEquipment.name,
                    model: selectedEquipment.model.id,
                    category: selectedEquipment.equipment_category_id,
                    purchaseDate: moment(selectedEquipment.purchase_date),
                    purchasePrice: selectedEquipment.purchase_price,
                    active: selectedEquipment.active,
                },
                confirmingDelete: false,
            }
      }    
  
      handleFormSubmit() {
        const params = {
            premise_id: this.props.premiseId,
            name: this.state.equipment.name,
            model: { id: this.state.equipment.model },
            equipment_category_id: this.state.equipment.category,
            purchase_date: moment(this.state.equipment.purchaseDate).toISOString(),
            purchase_price: this.state.equipment.purchasePrice,
            tag: null,
            active: this.state.equipment.active === true ? 'True' : 'False',
        };

        const selectedCategory = _.find(this.props.categories, (c) => { 
            return `${c.id}` === `${this.state.equipment.category}`;
        });

        if(selectedCategory && selectedCategory.equipment_category_id_parent) {
            params.equipment_category_id_parent = selectedCategory.equipment_category_id_parent;
        }
        AdminStore.setMapping(false);
        AdminStore.resetEquipment();

        api
        .put(`/equipment/${this.state.equipment.id}`, params)
        .then(response => { 
            AdminStore.fetchEquipment();
        });
      }

      handleCancel() {
          AdminStore.setMapping(false);
      }

      processDelete() {
        api
        .delete(`/equipment/${this.state.equipment.id}`)
        .then(response => {
            AdminStore.setMapping(false);
            AdminStore.fetchEquipment();
        });
      }

      confirmDelete() {
          return (
            <div>
                <p className="Admin__ConfirmRemoveInfo"><FormattedMessage id="admin.confirmEquipmentDelete" /></p>
                <div className="Admin__addDeviceActions">
                    <Button raised 
                              primary 
                              className="btn-danger" onClick={() => this.setState({confirmingDelete: false})}><FormattedMessage id="admin.cancel" /></Button> 
                    <Button raised 
                              primary 
                              className="btn-danger" onClick={() => this.processDelete()}><FormattedMessage id="admin.deleteEquipment" /></Button>
                </div>
            </div>
          );
      }

      render() {
        const { formatMessage, categories, models } = this.props;

        if(this.state.confirmingDelete === true) {
            return this.confirmDelete();
        }

        return (
        <div className="Admin__clickEquipmentActions">
            {/* <TextField
                id="floating-center-title"
                label={ formatMessage({id: 'admin.equipmentName'})}
                lineDirection="center"
                placeholder={ formatMessage({id: 'admin.equipmentName'})}
                className="md-cell md-cell--top"
                value={this.state.equipment.name}
                onChange={(value) => {
                    this.setState({
                        equipment: {
                            ...this.state.equipment,
                            name: value
                        }
                    })
                }}
            /> */}
            <FormGroup>
                <Label for="equipmentName">Equipment Name</Label>
                <Input type="text" name="equipmentName" id="equipmentName"
                    value={this.state.equipment.name}
                    onChange={(e) => {
                        this.setState({
                            equipment: {
                                ...this.state.equipment,
                                name: e.target.value
                            }
                        })
                        }}
                        
                />  
            </FormGroup>  
            { models && models.length > 0 ? (
             
                    <FormGroup>
                    <label>{ formatMessage({id: 'admin.equipmentBrand'})}</label>
                    <MultiSelector
                    type="brand"
                    items={models}
                    onChange={modelId => {
                        this.setState({
                            equipment: {
                                ...this.state.equipment,
                                model: modelId,
                            }
                        })
                    }}
                    selectedItems={ this.state.equipment.model ? {[this.state.equipment.model]: true} : {} }
                    forceSingleSelection={true}
                    disableTopLevelSelection={true}
                    valueProperty="name"
                    />
                    </FormGroup>

                    //  <FormGroup>
                    //     <Label for="equipmentBrand">{ formatMessage({id: 'admin.equipmentBrand'})}</Label>
                    //     <Input type="select" name="equipmentBrand" id="equipmentBrand"
                    //             onChange={modelId => {
                    //                 this.setState({
                    //                     equipment: {
                    //                         ...this.state.equipment,
                    //                         model: modelId,
                    //                     }
                    //                 })
                    //             }}
                    //     >
                    //         {_.map(models, (model) => {
                    //             return(
                    //                 <option>{ model.name }</option>
                    //             )
                    //         })}
                            
                    //     </Input>
                    // </FormGroup> 
           
            ) : '' }
            { categories && categories.length > 0 ? (
                <FormGroup>
                    <label>{ formatMessage({id: 'admin.equipmentCategory'})}</label>
                    <MultiSelector
                    type="category"
                    items={categories}
                    onChange={categoryId => {
                        this.setState({
                            equipment: {
                                ...this.state.equipment,
                                category: categoryId,
                            }
                        })
                    }}
                    selectedItems={ this.state.equipment.category ? {[this.state.equipment.category]: true} : {} }
                    forceSingleSelection={true}
                    valueProperty="name"
                    />
                </FormGroup>
            ) : '' }
                {/* <div className="Admin__editEquipmentPurchaseDate">
                    <label>{ formatMessage({id: 'admin.equipmentPurchaseDate'})}</label>
                    <SingleDatePicker
                        date={this.state.equipment.purchaseDate}
                        onDateChange={date => this.setState({ equipment: { ...this.state.equipment, purchaseDate: date }})}
                        focused={this.state.focused}
                        onFocusChange={({ focused }) => this.setState({ focused })}
                        id="purchaseDate"
                        noBorder={true}
                        placeholder={''}
                        small={true}
                        isOutsideRange={date => date >= moment().startOf("day")}
                        numberOfMonths={1}
                    />
                </div> */}
                <FormGroup>
                <label>{ formatMessage({id: 'admin.equipmentPurchaseDate'})}</label>
                
                <InputGroup>
                    <InputGroupAddon addonType="prepend">
                        <div className="input-group-text">
                            <FontAwesomeIcon icon={faCalendarAlt}/>
                        </div>
                    </InputGroupAddon>
                    <DatePicker
                        date={this.state.equipment.purchaseDate}
                        onDateChange={date => this.setState({ equipment: { ...this.state.equipment, purchaseDate: date }})}
                        focused={this.state.focused}
                        onFocusChange={({ focused }) => this.setState({ focused })}
                        id="purchaseDate"
                        noBorder={true}
                        placeholder={''}
                        small={true}
                        isOutsideRange={date => date >= moment().startOf("day")}
                        numberOfMonths={1}
                    />
                </InputGroup>
                </FormGroup>

            {/* <TextField
                id="floating-center-title"
                label={ formatMessage({id: 'admin.equipmentPurchasePrice'})}
                lineDirection="center"
                placeholder={ formatMessage({id: 'admin.equipmentPurchasePrice'})}
                className="md-cell md-cell--top"
                value={this.state.equipment.purchasePrice}
                onChange={(value) => {
                    this.setState({
                        equipment: {
                            ...this.state.equipment,
                            purchasePrice: value
                        }
                    })
                }}
            /> */}
            <FormGroup>
                <Label for="equipmentPurchasePrice">Purchase Price</Label>
                <Input type="text" name="equipmentPurchasePrice" id="equipmentPurchasePrice"
                   value={this.state.equipment.purchasePrice}
                   onChange={(e) => {
                    this.setState({
                        equipment: {
                            ...this.state.equipment,
                            purchasePrice: e.target.value                        }
                    })
                }}
                />  
            </FormGroup>  


            <div>
                <SelectionControl
                id="is-active"
                type="switch"
                label={ formatMessage({id: 'admin.deviceActive'})}
                name="active"
                checked={ this.state.equipment.active !== null ? this.state.equipment.active : false }
                onChange={(checked) => { 
                    this.setState({
                        equipment: { ...this.state.equipment, active: checked }
                    })
                }}
                />
            </div>
            
            <Button raised="true" primary="true" className="btn-filter" onClick={() => this.handleFormSubmit()}><FormattedMessage id="admin.save" /></Button>
            <Button raised="true" primary="true" className="btn-danger" onClick={() => this.handleCancel()}><FormattedMessage id="admin.cancel" /></Button> 
            <Button raised="true" primary="true" className='tn-primary' onClick={() => this.setState({confirmingDelete: true})}><FormattedMessage id="admin.deleteEquipment"/></Button>
        
        </div>
        );
    }
  }
);

export default EditEquipmentForm;
