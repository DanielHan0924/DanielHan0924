import React from 'react';
import { FontIcon } from 'react-md';

import AdminStore from "../../../../models/AdminStore";

const BoundingBox = ({hovered, left, top, width, height, ref, id, onClick, equipmentId, onDeleteClick, onEditClick}) => (
 <div 
    style={{
        left: `${left * 100}%`,
        top: `${top * 100}%`,
        width: `${width * 100}%`,
        height: `${height * 100}%`,
    }}
    id={id}
    onMouseEnter={() => AdminStore.setHovering(equipmentId)}
    onMouseLeave={() => AdminStore.setHovering(null)}
    className={ `rectangle ${hovered ? 'hovered' : '' }`} >
    <span onClick={onClick}>{equipmentId}</span>

    <div className="Admin__BoundingBoxDelete" onClick={onDeleteClick}>
        <FontIcon>remove</FontIcon>
    </div>

    <div className="Admin__BoundingBoxMove" onClick={onEditClick}>
        <FontIcon>select_all</FontIcon>
    </div>
 </div>
);

export default BoundingBox;