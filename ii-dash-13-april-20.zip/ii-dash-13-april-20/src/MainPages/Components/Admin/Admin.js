import React, { Fragment } from 'react';

// import { injectIntl } from "react-intl";
import { observer } from "mobx-react";
import { withRouter } from 'react-router';
import "react-md/dist/react-md.green-blue.min.css";
// import Header from "../Header/Header";
import Sidebar from "./Sidebar/Sidebar";
import Content from "./Content/Content";

import AdminStore from "../../../models/AdminStore";

import "./Admin.scss";
import Loader from 'react-loaders'

import {
	Row, Col,
	Button,
	CardHeader,
	Container,
	Card,
	 UncontrolledCollapse,
} from 'reactstrap';

import Auth from "../../../services/Auth";
const auth = new Auth();

const Admin = withRouter(observer(
  class Admin extends React.Component {
    constructor(props) {
      super(props);

      this.state = {
          
      }
    }
    componentWillMount() {
      //AdminStore.fetchEquipment();
      
      const { isAuthenticated } = auth;

      if(isAuthenticated()) {
        this.setState({ profile: {} });
        const { userProfile, getProfile } = auth;
        if (!userProfile) {
          getProfile((err, profile) => {
            this.setState({ profile });
          });
        } else {
          this.setState({ profile: userProfile });
        }
      }
    }
    isOrgAdmin() {
      if(this.state.profile && this.state.profile['https://indoorinformatics.com/claims/roles'] ) {
        const roles = this.state.profile['https://indoorinformatics.com/claims/roles'];
        return roles.indexOf('OrganizationAdmin') !== -1
      } 
      return "false";
    }
    componentDidMount() {
      AdminStore.fetchPremises();
      AdminStore.fetchDevices();
    }
    render() {
      if(!this.isOrgAdmin()) {
        return '';
      }
      if(AdminStore.premises && AdminStore.premises.length > 0 && AdminStore.devices && AdminStore.devices.length > 0){
        return (
        
          <Fragment>
            <Container fluid>
              <Row>
                <Col md="3">
                  <Card className="mb-3">
                    <CardHeader>
                      <Button  color="link" id="toggler">
                        <h6 className="mt-2 p-0 float-left">My Premises</h6>		
                      </Button>
                    </CardHeader>
                    <UncontrolledCollapse toggler="#toggler" defaultOpen={true}>
                      <Row>
                        <Col sm="12" lg="12">
                          <Sidebar  devices={AdminStore.devices} premises={AdminStore.premises} />
                        </Col>
                      </Row>
                    </UncontrolledCollapse>
                  </Card>
                </Col>
                <Col md="9">
                  <Card className="mb-3">
                    <CardHeader>
                      <Button  color="link"  id="toggler1">
                        <h6 className="mt-2 p-0 float-left">Image Section</h6>	
                      </Button>
                    </CardHeader>
                    <UncontrolledCollapse toggler="#toggler1" defaultOpen={true}>
                      <Row>
                        <Col sm="12" lg="12">
                          <Content devices={AdminStore.devices} premises={AdminStore.premises} />
                        </Col>
                      </Row>
                    </UncontrolledCollapse>
                  </Card>
                </Col>
              </Row>		
            </Container>
          </Fragment>
          // <div className="Admin">
          //   {/* <Header {...this.props} setLanguage={this.props.setLanguage} /> */}
          //   <Sidebar  devices={AdminStore.devices} premises={AdminStore.premises} />
          //   <Content devices={AdminStore.devices} premises={AdminStore.premises} />
          // </div>
        );
      }else {
        return (

            <div className="Admin">
                {/* <Header {...this.props} setLanguage={this.props.setLanguage} /> */}
                <div className="Admin__Content" style={{minHeight: '600px', width:'100%'}}>
                    {/* <img
                    src={loadingIcon}
                    alt="Loading..."
                    style={{
                        position: "absolute",
                        left: "50%",
                        transform: "translateX(-50%)"
                    }}
                    /> */}
                    <div className="loader-container" style={{  height: 400, width: '100%' }}>
                        <div className="loader-container-inner">
                            <div className="text-center">
                            <Loader type="line-scale-pulse-out" />
                            </div>
                            <h6>Loading</h6>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
      
    }
  }
));

export default Admin;
