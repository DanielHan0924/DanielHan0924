import React from "react";
import { toJS } from "mobx";
import { observer } from "mobx-react";
import { ExpansionList, ExpansionPanel, FontIcon, SelectionControl } from "react-md";
import { Link } from "react-router-dom";
// import {MainNav, ComponentsNav, FormsNav, WidgetsNav, ChartsNav} from './NavItems';
import _ from "lodash";
import PerfectScrollbar from 'react-perfect-scrollbar';
import AdminStore from "../../../../models/AdminStore";
import 'react-perfect-scrollbar/dist/css/styles.css';
import "react-md/dist/react-md.green-blue.min.css";
import "./Sidebar.scss";

const AdminSidebar = observer(
  class AdminSidebar extends React.Component {
    constructor(props) {
        super(props);
        this.state = { 
        }
      }
    render() {
        const equipment = toJS(this.props.equipment);
        if(AdminStore.devicesloading || AdminStore.premisesLoading) {
            return (
                <div className="Admin__Sidebar">
                    Loading device data...
                </div>
            );
        }
        return equipment && equipment.length > 0 ? this.equipmentSidebar() : this.deviceSidebar(); 
    }
    equipmentSidebar() {
        // alert("equipment");
        const equipment = toJS(this.props.equipment);
        const devices = toJS(this.props.devices);

        // const { formatMessage } = this.props.intl;

        if(equipment && equipment.length > 0 && devices && devices.length > 0) {
            return (
            <div className="Admin__Sidebar">
                <ExpansionList>
                    {_.map(this.props.currentDevice, (item) => {

                        let equipmentItems = _.map(equipment, (eq) => {
                            const inCurrentDevice = _.filter(eq.device_id_location, (item) => {
                                return parseInt(item.device_id, 10) === parseInt(this.props.currentDevice[0].id, 10);
                            });

                            if(AdminStore.filterUnmapped && inCurrentDevice.length === 0) {
                                return '';
                            } else {

                                return (
                                    <div 
                                        onMouseEnter={() => AdminStore.setHovering(eq.id)}
                                        onMouseLeave={() => AdminStore.setHovering(null)}
                                        className={ `Admin__SidebarDevice ${ AdminStore.hoveringEquipment === eq.id ? 'hovered': ''}` }
                                        key={eq.id}>
                                        <a href="/" onClick={(evt) => {
                                            evt.preventDefault();
                                            AdminStore.setMapping(true);
                                            // alert(eq.id);
                                            AdminStore.setEditing(eq.id);
                                        }}>
                                            <span
                                                className={ `Admin__SidebarId ${inCurrentDevice.length > 0 ? 'active' : ''}`}>
                                                {eq.id}
                                            </span> 
                                            {eq.name}
                                        </a>
                                    </div>
                                );

                            }
                        });

                        return (
                            <ExpansionPanel 
                            defaultExpanded={true}
                            label={item.name}
                            key={item.id}
                            className="Admin__SidebarPremise">
                                <div className="Admin__SidebarDevices">

                                    <PerfectScrollbar className="max-height">
                                        { equipmentItems }
                                    </PerfectScrollbar>
                            
                                    <SelectionControl
                                        id="filterNotMapped"
                                        className="Admin__SidebarFilter"
                                        type="switch"
                                        onChange={() => AdminStore.toggleSidebarFilter()}
                                        label="Only show mapped"
                                        name="filterNotMapped"
                                        checked={ AdminStore.filterUnmapped===true }
                                        defaultChecked />
                                </div>
                            </ExpansionPanel>
                        );

                    })}
                </ExpansionList>
            </div>
            );
        }
    }
    deviceSidebar() {
        const premises = toJS(this.props.premises);
        const devices = toJS(this.props.devices);

        if(premises && premises.length > 0 && devices && devices.length > 0) {
            return (
            <div className="Admin__Sidebar">
                <ExpansionList>
                    {_.map(premises, (item) => {
                            let premiseDevices = _.filter(devices, { premise_id: item.id });
                            premiseDevices = _.sortBy(premiseDevices, 'name');

                            let deviceItems = _.map(premiseDevices, (device) => {
                                return (
                                    <div className="Admin__SidebarDevice" key={device.id}>
                                        <span
                                            className={ `Admin__SidebarId ${device.active === true ? 'active' : ''}`}>
                                            {device.id}
                                        </span> 
                                        <Link to={`/dashboards/${item.id}/mapping/${device.id}`}>{device.name}</Link>
                                        <Link to={`/dashboards/${item.id}/device/${device.id}`} className="Admin_SidebarEditLink"><FontIcon className="">file_copy</FontIcon> edit</Link>
                                    </div>
                                );
                            });

                            return (
                                <ExpansionPanel
                                defaultExpanded={true}
                                label={item.name}
                            
                                key={item.id}
                                className="Admin__SidebarPremise">
                                    <div className="Admin__SidebarDevices">
                                        { deviceItems }
                                        <div className="Admin__SidebarDevice Admin__SidebarDevice--addDevice">
                                            <Link to={`/dashboards/${item.id}/device/`}><FontIcon className="icon">add_circle</FontIcon>&nbsp;&nbsp;Add Device</Link>
                                        </div>
                                    </div>
                                </ExpansionPanel>
                            );

                    })}
                </ExpansionList>
            </div>
            );
        } else {
            return '';
        }
    }
  }
);

export default AdminSidebar;
