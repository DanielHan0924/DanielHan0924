import React, { Fragment } from 'react';
import {
  Button,

  FormGroup,
  Label,
  Input,

  Row,
  Col,
  Card,

  Container,
  CardHeader,

  UncontrolledCollapse
} from 'reactstrap';
// import { injectIntl } from "react-intl";
import { observer } from 'mobx-react';
import _ from 'lodash';
import { FormattedMessage } from 'react-intl';
import { withRouter } from 'react-router';
import { Redirect, Link } from 'react-router-dom';
import {

  SelectionControl,
  DialogContainer,

} from 'react-md';
import { toJS } from 'mobx';
import Loader from 'react-loaders';

import 'react-md/dist/react-md.green-blue.min.css';
import './EditDevice.scss';
import Sidebar from '../Sidebar/Sidebar';
import MultiSelector from '../../MultiSelector/MultiSelector';

import ApiMiddleware from '../../../../services/Api';
import Auth from '../../../../services/Auth';

import AdminStore from '../../../../models/AdminStore';

import loadingIcon from '../../../assets/images/loading.svg';

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const EditDevice = withRouter(
  observer(
    class EditDevice extends React.Component {
      constructor(props) {
        super(props);

        this.state = {
          inputDirty: {
            deviceName: false,
            deviceUrl: false,
            deviceUsername: false,
            devicePassword: false
          },
          deviceId: null,
          premiseId: this.props.match.params.premiseId,
          deviceName: '',
          deviceUsername: '',
          devicePassword: '',
          deviceUrl: '',
          deviceActive: null,
          modalOpen: false,
          calibrationImage: null,
          authInfoTouched: false,
          deviceAdded: false,
          deviceEdited: false,
          addedDeviceId: null,
          fetchingImage: false,
          profile: {},
          deleteStatus: false
        };
        //AdminStore.fetchPremises();
        //AdminStore.fetchDevices();
        //AdminStore.fetchModels();
      }

      componentWillMount() {
        const { isAuthenticated } = auth;

        if (isAuthenticated()) {
          this.setState({ profile: {} });
          const { userProfile, getProfile } = auth;
          if (!userProfile) {
            getProfile((err, profile) => {
              this.setState({ profile });
            });
          } else {
            this.setState({ profile: userProfile });
          }
        }
      }

      componentDidMount() {
        
      }

      getSelectedModel() {
        const currentDevice = this.getCurrentDevice();

        let model;
        if (AdminStore.selectedModel) {
          model = toJS(AdminStore.selectedModel);
        } else if (currentDevice && currentDevice.model.model_id) {
          model = { [currentDevice.model.model_id]: true };
        } else {
          model = {};
        }

        const selectedModelId = _.map(model, (item, key) => {
          if (item === true) {
            return parseInt(key, 10);
          }
        })[0];

        return _.find(AdminStore.models, item => {
          return item.id === selectedModelId;
        });
      }

      getCurrentDevice() {
        let currentDevice;

        if (this.props.match.params.id) {
          const allDevices = toJS(AdminStore.devices);
          currentDevice = _.find(allDevices, d => {
            return `${d.id}` === `${this.props.match.params.id}`;
          });
        } else {
          currentDevice = {
            name: '',
            model: {
              model_id: null
            },
            request_json: {
              url: '',
              auth: {
                username: '',
                password: ''
              }
            }
          };
        }
        // alert("here is currentdevice function");
        // alert(currentDevice.name);
        return currentDevice;
      }

      getActiveStatus(currentDevice) {
        let active;
        if (this.state.deviceActive === null && currentDevice) {
          // state untouched
          active = currentDevice.active;
        } else if (this.state.deviceActive !== null && currentDevice) {
          active = this.state.deviceActive;
        } else {
          active = true;
        }

        return active;
      }

      saveChanges() {
        const currentDevice = this.getCurrentDevice();
        const deviceName = this.getFieldValue(
          this.state.deviceName,
          currentDevice.name,
          'deviceName'
        );
        // alert(deviceName);

        if (deviceName.length === 0) {
          return false;
        }
        // console.log(this.props.match.params);

        if (this.props.match.params.id) {
          // edit device information
          const selectedModel = this.getSelectedModel();
          const active = this.getActiveStatus(currentDevice);

          let activeString; // API wants capitalized string instead of boolean
          if (active === true) {
            activeString = 'True';
          } else {
            activeString = 'False';
          }

          const params = {
            premise_id: this.state.premiseId,
            name: deviceName,
            model: {
              model_id: selectedModel.id,
              name: selectedModel.name
            },
            request_json: {
              url: this.getFieldValue(
                this.state.deviceUrl,
                currentDevice.request_json.url,
                'deviceUrl'
              ),
              auth: {
                class: 'HTTPBasicAuth',
                username: this.getFieldValue(
                  this.state.deviceUsername,
                  currentDevice.request_json.auth.username,
                  'deviceUsername'
                ),
                password: this.getFieldValue(
                  this.state.devicePassword,
                  currentDevice.request_json.auth.password,
                  'devicePassword'
                )
              },
              method: 'GET'
            },
            active: activeString
          };

          api
            .put(`/device/${this.props.match.params.id}`, params)
            .then(response => {
              const deviceId = this.props.match.params.id;
              api
                .post(`/device/${deviceId}/calibration_image`, params)
                .then(response => {
                  this.setState({ deviceId: deviceId, deviceEdited: true });
                  AdminStore.updateDeviceName(deviceId, deviceName);
                });
            });
        } else {
          // add new device

          const selectedModel = this.getSelectedModel();

          const params = {
            premise_id: this.state.premiseId,
            name: deviceName,
            model: {
              model_id: selectedModel.id,
              name: selectedModel.name
            },
            request_json: {
              url: this.getFieldValue(
                this.state.deviceUrl,
                currentDevice.request_json.url,
                'deviceUrl'
              ),
              auth: {
                class: 'HTTPBasicAuth',
                username: this.getFieldValue(
                  this.state.deviceUsername,
                  currentDevice.request_json.auth.username,
                  'deviceUsername'
                ),
                password: this.getFieldValue(
                  this.state.devicePassword,
                  currentDevice.request_json.auth.password,
                  'devicePassword'
                )
              },
              method: 'GET'
            },
            active: 'False'
          };

          api.post(`/device`, params).then(response => {
            const deviceId = response.data.device_id;
            api
              .post(`/device/${deviceId}/calibration_image`, {})
              .then(response => {
                this.setState({ addedDeviceId: deviceId, deviceAdded: true });
              });
          });
        }
      }

      refreshCalibrationImage() {
        const deviceId = this.props.match.params.id;
        this.setState({ fetchingImage: true });
        api.post(`/device/${deviceId}/calibration_image`, {}).then(response => {
          this.setState({ fetchingImage: false });
        });
      }

      deleteDevice() {
        api
          .delete(`/device/${this.props.match.params.id}`)
          .then(response => {
            this.setState({
              deviceDeleted: this.props.match.params.id,
              deleteStatus: true
            });
            AdminStore.fetchDevices();
          })
          .catch(error => {
            this.setState({
              deviceDeleted: this.props.match.params.id,
              deleteStatus: false
            });
          });
      }

      showModal() {
        if (this.props.match.params.id) {
          AdminStore.fetchImage(this.props.match.params.id);
        } else if (this.state.addedDeviceId) {
          AdminStore.fetchImage(this.state.addedDeviceId);
        }
      }

      getFieldValue(stateValue, responseValue, propertyKey) {
        if (this.state.inputDirty[propertyKey] && stateValue !== '') {
          return stateValue;
        } else if (responseValue && !this.state.inputDirty[propertyKey]) {
          return responseValue;
        } else {
          return '';
        }
      }

      deviceAddedContent() {
        return (
          <div className="Admin">
            {/* <Header {...this.props} setLanguage={this.props.setLanguage} /> */}
            <Fragment>
              <Container fluid>
                <Row>
                  <Col md="3">
                    <Card className="mb-3">
                      <CardHeader>
                        <Button color="link" id="toggler">
                          <h6 className="mt-2 p-0 float-left">My Premises</h6>
                        </Button>
                      </CardHeader>
                      <UncontrolledCollapse
                        toggler="#toggler"
                        defaultOpen={true}
                      >
                        <Row>
                          <Col sm="12" lg="12">
                            <Sidebar
                              devices={AdminStore.devices}
                              premises={AdminStore.premises}
                            />
                          </Col>
                        </Row>
                      </UncontrolledCollapse>
                    </Card>
                  </Col>
                  <Col md="9">
                    <Card className="mb-3">
                      <CardHeader>
                        <Button color="link" id="toggler1">
                          <h6 className="mt-2 p-0 float-left">Image Section</h6>
                        </Button>
                      </CardHeader>
                      <UncontrolledCollapse
                        toggler="#toggler1"
                        defaultOpen={true}
                      >
                        <Row>
                          <Col sm="12" lg="12">
                            <div className="Admin__Content">
                              <div>
                                <h1 className="Admin__Title">Add Device</h1>
                                <p>
                                  Your device has now been added, but it's state
                                  is set to 'inactive'. It is important that the
                                  device is not activated before all the
                                  equipment have been mapped. Below you'll see
                                  the calibration image. If you can see the
                                  image, you're good to start mapping the gym
                                  equipment. If you can't see the picture,
                                  please review the device configuration.
                                </p>

                                {AdminStore.loadingCalibrationImage === true ? (
                                  <div className="EquipmentDialog__Loading">
                                    <img
                                      src={loadingIcon}
                                      alt="Loading..."
                                      style={{
                                        position: 'absolute',
                                        left: '50%',
                                        transform: 'translateX(-50%)'
                                      }}
                                    />
                                  </div>
                                ) : (
                                  '' // <img alt="Calibration" src={AdminStore.image} style={ {width: '50%'}} />
                                )}

                                <div style={{ clear: 'both' }}>
                                  {/* <Button
                                href={`/dashboards/${this.props.match.params.premiseId}/mapping/${this.state.addedDeviceId}`}
                                raised
                                primary
                                className="Admin__Save">
                                Start Mapping
                            </Button> */}
                                  <Button
                                    raised="true"
                                    primary="true"
                                    className="btn-danger"
                                    href={`/dashboards/${this.props.match.params.premiseId}/mapping/${this.state.addedDeviceId}`}
                                  >
                                    Mapping
                                  </Button>
                                  &nbsp;&nbsp;
                                  <Button
                                    raised="true"
                                    primary="true"
                                    className="btn-filter"
                                    href={`/dashboards/${this.props.match.params.premiseId}/device/${this.state.addedDeviceId}`}
                                  >
                                    Edit
                                  </Button>
                                  {/* <Button
                                href={`/dashboards/${this.props.match.params.premiseId}/device/${this.state.addedDeviceId}`}
                                raised
                                className="Admin__Button">
                                Edit Device Configuration
                            </Button> */}
                                </div>
                              </div>
                            </div>
                          </Col>
                        </Row>
                      </UncontrolledCollapse>
                    </Card>
                  </Col>
                </Row>
              </Container>
            </Fragment>
          </div>
        );
      }

      deviceDeleteConsent() {
        // const { formatMessage } = this.props.intl;

        if (this.state.deviceDeleted && this.state.deleteStatus === true) {
          return (
            <Redirect
              to={`/dashboards/premise/${this.props.match.params.premiseId}/`}
            />
          );
        } else if (
          this.state.deviceDeleted &&
          this.state.deleteStatus === false
        ) {
          return (
            <div className="Admin">
              {/* <Header {...this.props} setLanguage={this.props.setLanguage} /> */}
              <Fragment>
                <Container fluid>
                  <Row>
                    <Col md="3">
                      <Card className="mb-3">
                        <CardHeader>
                          <Button color="link" id="toggler">
                            <h6 className="mt-2 p-0 float-left">My Premises</h6>
                          </Button>
                        </CardHeader>
                        <UncontrolledCollapse
                          toggler="#toggler"
                          defaultOpen={true}
                        >
                          <Row>
                            <Col sm="12" lg="12">
                              <Sidebar
                                devices={AdminStore.devices}
                                premises={AdminStore.premises}
                              />
                            </Col>
                          </Row>
                        </UncontrolledCollapse>
                      </Card>
                    </Col>
                    <Col md="9">
                      <Card className="mb-3">
                        <CardHeader>
                          <Button color="link" id="toggler1">
                            <h6 className="mt-2 p-0 float-left">
                              Image Section
                            </h6>
                          </Button>
                        </CardHeader>
                        <UncontrolledCollapse
                          toggler="#toggler1"
                          defaultOpen={true}
                        >
                          <Row>
                            <Col sm="12" lg="12">
                              <div className="Admin__Content">
                                <div>
                                  <h1 className="Admin__Title">
                                    Delete device
                                  </h1>
                                  <p>
                                    Deleting failed. The device or equipment
                                    might have data and cannot be deleted. You
                                    can still deactivate the device or camera by
                                    editing it.
                                  </p>
                                  <div style={{ clear: 'both' }}>
                                    <Button
                                      // href={`/dashboards/${this.props.match.params.premiseId}/device/${this.props.match.params.id}`}
                                      href={`/dashboards/management`}
                                      raised="true"
                                      primary="true"
                                      className="btn btn-danger"
                                    >
                                      Cancel
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </Col>
                          </Row>
                        </UncontrolledCollapse>
                      </Card>
                    </Col>
                  </Row>
                </Container>
              </Fragment>
            </div>
          );
        } else {
          return (
            <div className="Admin">
              {/* <Header {...this.props} setLanguage={this.props.setLanguage} /> */}
              <Fragment>
                <Container fluid>
                  <Row>
                    <Col md="3">
                      <Card className="mb-3">
                        <CardHeader>
                          <Button color="link" id="toggler">
                            <h6 className="mt-2 p-0 float-left">My Premises</h6>
                          </Button>
                        </CardHeader>
                        <UncontrolledCollapse
                          toggler="#toggler"
                          defaultOpen={true}
                        >
                          <Row>
                            <Col sm="12" lg="12">
                              <Sidebar
                                devices={AdminStore.devices}
                                premises={AdminStore.premises}
                              />
                            </Col>
                          </Row>
                        </UncontrolledCollapse>
                      </Card>
                    </Col>
                    <Col md="9">
                      <Card className="mb-3">
                        <CardHeader>
                          <Button color="link" id="toggler1">
                            <h6 className="mt-2 p-0 float-left">
                              Image Section
                            </h6>
                          </Button>
                        </CardHeader>
                        <UncontrolledCollapse
                          toggler="#toggler1"
                          defaultOpen={true}
                        >
                          <Row>
                            <Col sm="12" lg="12">
                              <div className="Admin__Content">
                                <div>
                                  <h1 className="Admin__Title">
                                    Delete Device />
                                  </h1>
                                  <p>Are You Sure To Delete Device?</p>
                                  <div style={{ clear: 'both' }}>
                                    <Button
                                      raised="true"
                                      primary="true"
                                      onClick={e => {
                                        e.preventDefault();
                                        this.deleteDevice();
                                      }}
                                      className="btn-filter"
                                    >
                                      Delete
                                    </Button>
                                    <Button
                                      // href={`/dashboards/${this.props.match.params.premiseId}/device/${this.props.match.params.id}`}
                                      href={`/dashboards/management`}
                                      raised="true"
                                      primary="true"
                                      className="btn-danger"
                                    >
                                      Cancel
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </Col>
                          </Row>
                        </UncontrolledCollapse>
                      </Card>
                    </Col>
                  </Row>
                </Container>
              </Fragment>
            </div>
          );
        }
      }

      deviceEditedContent() {
        // const { formatMessage } = this.props.intl;

        return (
          <div className="Admin">
            {/* <Header {...this.props} setLanguage={this.props.setLanguage} /> */}
            <Fragment>
              <Container fluid>
                <Row>
                  <Col md="3">
                    <Card className="mb-3">
                      <CardHeader>
                        <Button color="link" id="toggler">
                          <h6 className="mt-2 p-0 float-left">My Premises</h6>
                        </Button>
                      </CardHeader>
                      <UncontrolledCollapse
                        toggler="#toggler"
                        defaultOpen={true}
                      >
                        <Row>
                          <Col sm="12" lg="12">
                            <Sidebar
                              devices={AdminStore.devices}
                              premises={AdminStore.premises}
                            />
                          </Col>
                        </Row>
                      </UncontrolledCollapse>
                    </Card>
                  </Col>
                  <Col md="9">
                    <Card className="mb-3">
                      <CardHeader>
                        <Button color="link" id="toggler1">
                          <h6 className="mt-2 p-0 float-left">Image Section</h6>
                        </Button>
                      </CardHeader>
                      <UncontrolledCollapse
                        toggler="#toggler1"
                        defaultOpen={true}
                      >
                        <Row>
                          <Col sm="12" lg="12">
                            <div className="Admin__Content">
                              <div>
                                <h1 className="Admin__Title">
                                  Edit Device Configuration
                                </h1>
                                <h3>Changes saved!</h3>
                                <div style={{ clear: 'both' }}>
                                  <Button
                                    href={`/dashboards/premise/${this.props.match.params.premiseId}`}
                                    raised="true"
                                    primary="true"
                                    style={{ marginLeft: 0 }}
                                    className="btn-filter"
                                  >
                                    Back
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </Col>
                        </Row>
                      </UncontrolledCollapse>
                    </Card>
                  </Col>
                </Row>
              </Container>
            </Fragment>
          </div>
        );
      }

      renderForm() {
        if (AdminStore.loadingDevices === false) {
          const currentDevice = this.getCurrentDevice();
          //  alert(currentDevice.name);
          let model;
          if (AdminStore.selectedModel) {
            model = toJS(AdminStore.selectedModel);
          } else if (currentDevice && currentDevice.model.model_id) {
            model = { [currentDevice.model.model_id]: true };
          } else {
            model = {};
          }

          const actions = [];
          actions.push({
            secondary: true,
            children: 'Close',
            onClick: () => {
              this.setState({ modalOpen: false });
            }
          });
          return (
            <div className="Admin">
              {/* <Header {...this.props} setLanguage={this.props.setLanguage} /> */}
              <Fragment>
                <Container fluid>
                  <Row>
                    <Col md="3">
                      <Card className="mb-3">
                        <CardHeader>
                          <Button color="link" id="toggler">
                            <h6 className="mt-2 p-0 float-left">My Premises</h6>
                          </Button>
                        </CardHeader>
                        <UncontrolledCollapse
                          toggler="#toggler"
                          defaultOpen={true}
                        >
                          <Row>
                            <Col sm="12" lg="12">
                              <Sidebar
                                devices={AdminStore.devices}
                                premises={AdminStore.premises}
                              />
                            </Col>
                          </Row>
                        </UncontrolledCollapse>
                      </Card>
                    </Col>
                    <Col md="9">
                      <Card className="mb-3">
                        <CardHeader>
                          <Button color="link" id="toggler1">
                            <h6 className="mt-2 p-0 float-left">
                              Image Section
                            </h6>
                          </Button>
                        </CardHeader>
                        <UncontrolledCollapse
                          toggler="#toggler1"
                          defaultOpen={true}
                        >
                          <Row>
                            <Col sm="12" lg="12">
                              <div className="Admin__Content">
                                {this.props.match.params.id ? (
                                  <h1 className="Admin__Title">
                                    Edit Device Configuration
                                  </h1>
                                ) : (
                                  <h1 className="Admin__Title">Add Device</h1>
                                )}

                                <FormGroup>
                                  <Label for="deviceName">Device Name</Label>
                                  <Input
                                    type="text"
                                    name="deviceName"
                                    id="deviceName"
                                    value={this.getFieldValue(
                                      this.state.deviceName,
                                      currentDevice.name,
                                      'deviceName'
                                    )}
                                    onChange={e => {
                                      this.setState({
                                        deviceName: e.target.value,
                                        inputDirty: {
                                          ...this.state.inputDirty,
                                          deviceName: true
                                        }
                                      });
                                    }}
                                  />
                                </FormGroup>
                                {AdminStore.brands.length > 0 ||
                                AdminStore.models.length > 0 ? (
                                  <div>
                                    <FormGroup>
                                      <label>
                                        <FormattedMessage id="admin.deviceModel" />
                                      </label>
                                      <MultiSelector
                                        type="brand"
                                        items={AdminStore.models}
                                        onChange={modelId => {
                                          AdminStore.setSelectedDeviceModel(
                                            modelId
                                          );
                                        }}
                                        selectedItems={model}
                                        forceSingleSelection={true}
                                        valueProperty="name"
                                      />
                                    </FormGroup>
                                    {/* <FormGroup>
                                          <Label for="exampleSelect">Device Model</Label>
                                              <Input type="select" name="select" id="exampleSelect"
                                                      onChange={e => {
                                                          AdminStore.setSelectedDeviceModel(e.target.id);
                                                      }}
                                              >
                                                  
                                                  {_.map(AdminStore.models, (model) => {
                                                      return(
                                                          <option>{ model.name }</option>
                                                      )
                                              })}
                                            
                                          </Input>
                                        </FormGroup> */}
                                  </div>
                                ) : (
                                  ''
                                )}
                                <FormGroup>
                                  <Label for="deviceUrl">Device URL</Label>
                                  <Input
                                    type="text"
                                    name="deviceUrl"
                                    id="deviceUrl"
                                    value={this.getFieldValue(
                                      this.state.deviceUrl,
                                      currentDevice.request_json.url,
                                      'deviceUrl'
                                    )}
                                    onChange={e => {
                                      this.setState({
                                        deviceUrl: e.target.value,
                                        authInfoTouched: true,
                                        inputDirty: {
                                          ...this.state.inputDirty,
                                          deviceUrl: true
                                        }
                                      });
                                    }}
                                  />
                                </FormGroup>
                                <FormGroup>
                                  <Label for="deviceUsername">
                                    Device Username
                                  </Label>
                                  <Input
                                    type="text"
                                    name="deviceUsername"
                                    id="deviceUsername"
                                    value={this.getFieldValue(
                                      this.state.deviceUsername,
                                      currentDevice.request_json.auth.username,
                                      'deviceUsername'
                                    )}
                                    onChange={e => {
                                      this.setState({
                                        deviceUsername: e.target.value,
                                        authInfoTouched: true,
                                        inputDirty: {
                                          ...this.state.inputDirty,
                                          deviceUsername: true
                                        }
                                      });
                                    }}
                                  />
                                </FormGroup>
                                <FormGroup>
                                  <Label for="devicePassword">
                                    Device Password
                                  </Label>
                                  <Input
                                    type="text"
                                    name="devicePassword"
                                    id="devicePassword"
                                    value={this.getFieldValue(
                                      this.state.devicePassword,
                                      currentDevice.request_json.auth.password,
                                      'devicePassword'
                                    )}
                                    onChange={e => {
                                      this.setState({
                                        devicePassword: e.target.value,
                                        authInfoTouched: true,
                                        inputDirty: {
                                          ...this.state.inputDirty,
                                          devicePassword: true
                                        }
                                      });
                                    }}
                                  />
                                </FormGroup>

                                {this.props.match.params.id ? (
                                  <div>
                                    <SelectionControl
                                      id="is-active"
                                      type="switch"
                                      label="ACTIVE"
                                      name="active"
                                      checked={
                                        this.state.deviceActive === null
                                          ? currentDevice.active === true
                                            ? true
                                            : false
                                          : this.state.deviceActive
                                      }
                                      onChange={checked => {
                                        this.setState({
                                          deviceActive: checked ? true : false
                                        });
                                      }}
                                      defaultChecked
                                    />
                                  </div>
                                ) : (
                                  ''
                                )}

                                <Button
                                  raised="true"
                                  primary="true"
                                  className="btn-filter"
                                  onClick={e => {
                                    this.saveChanges();
                                  }}
                                >
                                  Save
                                </Button>

                                {this.props.match.params.id ? (
                                  <Button
                                    raised="true"
                                    primary="true"
                                    className="btn-danger"
                                    onClick={e => {
                                      this.setState({ deleteDevice: true });
                                    }}
                                  >
                                    Delete
                                  </Button>
                                ) : null}

                                {this.state.authInfoTouched === false &&
                                this.props.match.params.id ? (
                                  <Button
                                    raised="true"
                                    primary="true"
                                    className="button"
                                    color="alternate"
                                    onClick={e => {
                                      this.setState({ modalOpen: true });
                                    }}
                                  >
                                    View Image
                                  </Button>
                                ) : null}

                                {this.state.authInfoTouched === false &&
                                this.props.match.params.id &&
                                this.state.fetchingImage === false ? (
                                  <Button
                                    raised="true"
                                    primary="true"
                                    className="button"
                                    color="alternate"
                                    onClick={e => {
                                      this.refreshCalibrationImage();
                                    }}
                                  >
                                    Refresh Image
                                  </Button>
                                ) : null}

                                <DialogContainer
                                  id="speed-boost"
                                  visible={this.state.modalOpen}
                                  onShow={() => this.showModal()}
                                  width={800}
                                  height={640}
                                  focusOnMount={false}
                                  actions={actions}
                                  className="EquipmentDialog"
                                  aria-label="Calibration image"
                                  modal
                                >
                                  {AdminStore.loadingCalibrationImage ===
                                  true ? (
                                    <div className="EquipmentDialog__Loading">
                                      <img
                                        src={loadingIcon}
                                        alt="Loading..."
                                        style={{
                                          position: 'absolute',
                                          left: '50%',
                                          transform: 'translateX(-50%)'
                                        }}
                                      />
                                    </div>
                                  ) : (
                                    <img
                                      alt="Calibration"
                                      src={AdminStore.image}
                                      style={{ width: '100%' }}
                                    />
                                  )}
                                </DialogContainer>
                              </div>
                            </Col>
                          </Row>
                        </UncontrolledCollapse>
                      </Card>
                    </Col>
                  </Row>
                </Container>
              </Fragment>
            </div>
          );
        } else {
          return (
            <div className="Admin">
              {/* <Header {...this.props} setLanguage={this.props.setLanguage} /> */}
              <div
                className="Admin__Content"
                style={{ minHeight: '600px', width: '100%' }}
              >
                <img
                  src={loadingIcon}
                  alt="Loading..."
                  style={{
                    position: 'absolute',
                    left: '50%',
                    transform: 'translateX(-50%)'
                  }}
                />
              </div>
            </div>
          );
        }
      }

      render() {
        if (this.state.deviceAdded === true) {
          return this.deviceAddedContent();
        } else if (this.state.deviceEdited === true) {
          return this.deviceEditedContent();
        } else if (this.state.deleteDevice === true) {
          return this.deviceDeleteConsent();
        } else {
          return this.renderForm();
        }
      }
    }
  )
);

export default EditDevice;