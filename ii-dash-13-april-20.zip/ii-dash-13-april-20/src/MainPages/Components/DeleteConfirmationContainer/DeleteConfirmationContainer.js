import React, { Component } from 'react';
import { DialogContainer } from 'react-md';
import DeleteConfirmation from '../DeleteConfirmation/DeleteConfirmation.js';


class DeleteConfirmationContainer extends Component{
  render(){
    const { visible } = this.props;
    return(
      <DialogContainer
        id="DeleteConfirmationContainer"
        aria-label="DeleteConfirmationContainer"
        visible={visible}
        onHide={this.props.handleOnHide}
        focusOnMount={false}
      >
        <DeleteConfirmation
          handleDelete={this.props.handleDelete}
          cancelDelete={this.props.handleOnHide}
        />
      </DialogContainer>
    );
  }
}

export default DeleteConfirmationContainer;
