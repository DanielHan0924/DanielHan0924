import React, { Component } from 'react';

import { injectIntl } from 'react-intl';

import 'react-md/dist/react-md.green-blue.min.css';
import './Login.scss';

import Logo from '../../assets/images/logo.svg';
import Auth from "../../../services/Auth";
const auth = new Auth();

class Login extends Component {
  login() {
    // this.props.auth.login();
    auth.logout();
  }
  render() {
    return (
      <div className="Login">
        <img src={Logo} className="Login__Logo" alt="GymPlus" />
        <br />
        {/* <a href="#" style={{ cursor: 'pointer' }} className="Login__button" onClick={this.login.bind(this)}>
          Kirjaudu sisään
        </a> */}
      </div>
    );
  }
}
export default injectIntl(Login);
