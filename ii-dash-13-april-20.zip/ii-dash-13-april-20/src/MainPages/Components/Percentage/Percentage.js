import React from 'react';
import PropTypes from 'prop-types';

import getRoundedPercentages from '../../../utils/getRoundedPercentages.js';

const Percentage = ({ value, showSign }) => {
  const plusSign = value > 0 && showSign ? '+' : '';
  return(
    <span>{plusSign}{getRoundedPercentages(value)}%</span>
  );
}

Percentage.propTypes = {
  value: PropTypes.number.isRequired,
  showSign: PropTypes.bool
};

export default Percentage;
