import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { injectIntl } from 'react-intl';

import './FilterInputField.scss';

class FilterInputField extends Component {
  inputChange = (event) => {
    const { value } = event.target;
    this.props.handleFilterTextChange(value);
  }
  render(){
    const { formatMessage } = this.props.intl;

    const placeholder = formatMessage({ id: 'tags.options.search' })
    const { value } = this.props;
    const crossIcon = <i className="fa fa-times fa-2x"></i>;
    const searchIcon = <i className="fa fa-search fa-2x"></i>;

    return(
      <div className="FilterInputField__container">
        <input
          className="FilterInputField"
          onChange={this.inputChange}
          value={value}
          placeholder={placeholder}
          autoComplete="off"
        />
        <p
          className="FilterInputField__icon"
          onClick={this.props.handleClearClick}
        >
          {value.length ? crossIcon : searchIcon}
        </p>
      </div>
    );
  }
}

FilterInputField.propTypes = {
  value: PropTypes.string.isRequired,
  handleFilterTextChange: PropTypes.func.isRequired,
  handleClearClick: PropTypes.func.isRequired
}

export default injectIntl(FilterInputField);
