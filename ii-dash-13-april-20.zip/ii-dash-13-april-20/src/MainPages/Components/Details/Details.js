import React, { Component } from 'react';
import { observer } from 'mobx-react';

import { ExpansionList } from 'react-md';
import 'react-md/dist/react-md.green-blue.min.css';

import Header from '../Header/Header';
import Filter from '../Filter/Filter';

import FilterStore from '../../../models/FilterStore';

import EquipmentDetails from '../../Widgets/EquipmentDetails/EquipmentDetails';

const Details = observer(
  class Details extends Component {
    render() {
      return (
        <div>
          {/* <Header {...this.props} setLanguage={this.props.setLanguage} /> */}
          <ExpansionList>
            <Filter />
            <EquipmentDetails
              filters={FilterStore.activeFilters}
              filterData={FilterStore.filterData}
            />
          </ExpansionList>
        </div>
      );
    }
  }
);

export default Details;
