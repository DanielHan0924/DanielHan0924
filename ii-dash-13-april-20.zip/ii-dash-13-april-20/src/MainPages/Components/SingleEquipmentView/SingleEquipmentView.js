import React from 'react';

import BasicInformation from '../SingleEquipmentBasicInformation/SingleEquipmentBasicInformation.js';
import SingleEquipmentHeader from '../SingleEquipmentHeader/SingleEquipmentHeader.js';
import SingleEquipmentTabs from '../SingleEquipmentTabs/SingleEquipmentTabs.js';

import './SingleEquipmentView.scss';

const SingleEquipmentView = (props) =>  {
  const { equipment } = props;

  return (
    <div className="SingleEquipmentView">
      <SingleEquipmentHeader
        equipment={equipment}
        closeWindow={props.closeWindow}
      />
      <BasicInformation
        equipment={equipment}
        closeWindow={props.closeWindow}
      />

      <SingleEquipmentTabs
        equipment={equipment}
      />
    </div>


  );
}


export default SingleEquipmentView;

/* joel.salminen@indoorinformatics.com */
