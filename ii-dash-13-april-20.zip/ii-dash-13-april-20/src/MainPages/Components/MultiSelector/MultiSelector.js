import React from 'react';
import { observer } from 'mobx-react';
import PerfectScrollbar from 'react-perfect-scrollbar';
import onClickOutside from 'react-onclickoutside';
import _ from 'lodash';

import { injectIntl } from 'react-intl';
//import { SelectionControl, Checkbox } from 'react-md';

import 'react-perfect-scrollbar/dist/css/styles.css';

import FilterStore from '../../../models/FilterStore';
import getAmountOfSelectedItems from '../../../utils/getAmountOfSelectedItems.js';

import { CustomInput /*, Form, FormGroup, Label*/ } from 'reactstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  /*faPlusCircle,
  faRemoveFormat,*/
  faArrowDown
} from '@fortawesome/free-solid-svg-icons';

import './MultiSelector.scss';

const MultiSelector = observer(
  class MultiSelector extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        childIsOpen: [],
        filterInput: '',
        dropdownIsOpen: false
      };
    }
    handleClickOutside() {
      if (this.state.dropdownIsOpen === true) {
        this.setState({
          filterInput: '',
          dropdownIsOpen: !this.state.dropdownIsOpen
        });
      }
    }

    getSelectedItemRatio() {
      const { selectedItems } = this.props;
      const amountOfSelectedItems = getAmountOfSelectedItems(selectedItems);
      const selectedItemsValues = this.getSelectedItemsValues(selectedItems);
      const selectedItemRatio = `(${amountOfSelectedItems}/${selectedItemsValues.length})`;
      return selectedItemRatio;
    }

    getSelectedItemsValues(selectedItems) {
      const selectedItemsValues = Object.values(selectedItems);
      return selectedItemsValues;
    }

    render() {
      const { dropdownIsOpen } = this.state;
      const { disabled, header } = this.props;
      const selectedItemRatio = this.getSelectedItemRatio();
      return (
        <div className="MultiSelector">
          {/* Disable multiselector:  */}
          <div
            className={disabled ? 'MultiSelector--disabled' : undefined}
          ></div>

          <div
            className={`MultiSelector__selected ${
              dropdownIsOpen ? 'toggled' : ''
            }`}
            onClick={() => {
              this.setState({ dropdownIsOpen: !this.state.dropdownIsOpen });
            }}
          >
            {header ? (
              <span className="labelTxt">{`${header} ${selectedItemRatio}`}</span>
            ) : (
              <span className="labelTxt">{this.getSelectedItems()}</span>
            )}
            {/* <FontAwesomeIcon icon={faArrowDown} size="sm" /> */}
          </div>
          <div
            className={`MultiSelector__dropdown ${
              dropdownIsOpen ? 'open' : ''
            }`}
          >
            {this.getFilterInput()}
            <PerfectScrollbar>{this.getDropdownItems()}</PerfectScrollbar>
          </div>
        </div>
      );
    }

    getSelectedItems() {
      let selectedItems;
      const returnProperty = this.props.valueProperty;
      const { formatMessage } = this.props.intl;

      if (_.find(this.props.selectedItems, o => o === true) === undefined) {
        selectedItems = formatMessage({ id: 'multiSelector.noItemsSelected' });
      } else {
        selectedItems = _.map(this.props.selectedItems, (item, key) => {
          const selectedItem = _.find(
            this.props.items,
            o => `${o.id}` === `${key}`
          );
          if (item === true && selectedItem !== undefined) {
            return <span key={key}>{selectedItem[returnProperty]}</span>;
          }
          return null;
        });
      }
      return selectedItems;
    }
    getFilterInput() {
      const { formatMessage } = this.props.intl;
      return (
        <input
          type="search"
          className="MultiSelector__input"
          value={this.state.filterInput}
          placeholder={formatMessage({ id: 'multiSelector.filterItems' })}
          onChange={e => {
            this.setState({ filterInput: e.target.value });
          }}
        />
      );
    }

    shouldShowHierarchy(item, filter) {
      return (
        (item.equipment_category_id_parent || item.parent) &&
        (this.props.type === 'category' || this.props.type === 'brand') &&
        filter.length < 3 &&
        this.props.ignoreHierarchy !== true
      );
    }

    getDropdownItems() {
      const filter = this.state.filterInput;

      return this.props.items
        .filter(
          d =>
            filter === null ||
            filter.length < 3 ||
            d.name.toLowerCase().includes(filter.toLowerCase())
        )
        .map(item => {
          if (
            item === undefined ||
            item === null ||
            this.shouldShowHierarchy(item, filter)
          )
            return '';

          /* If hierarchy is disabled using 'ignoreHierarchy' prop, do not waste time looking for item's children. */
          let children = [];
          if (
            this.props.ignoreHierarchy !== true &&
            this.props.type === 'category'
          ) {
            children = _.filter(
              this.props.items,
              i => i.equipment_category_id_parent === item.id
            );
          } else if (
            this.props.ignoreHierarchy !== true &&
            this.props.type === 'brand'
          ) {
            children = _.filter(this.props.items, i => i.parent === item.id);
          }

          let lastClickedType = this.props.type;
          if (this.props.identifier === 'compare') {
            lastClickedType += 'C';
          }

          let lastClickedClass = FilterStore.lastClicked[lastClickedType];
          if (this.props.identifier === 'compare') {
            lastClickedClass += 'C';
          }

          return (
            <div
              className={`MultiSelector__row last-clicked-${lastClickedClass}`}
              key={item.id}
            >
              {this.props.disableTopLevelSelection !== true ? (
                <CustomInput
                  type="checkbox"
                  id={`checkbox-${this.props.type}-${this.props.identifier}-${item.id}`}
                  name={`checkbox[${this.props.type}][${item.id}]`}
                  value="checked"
                  label={
                    item[this.props.valueProperty]
                      ? item[this.props.valueProperty]
                      : item.name
                  }
                  checked={this.props.selectedItems[item.id] === true}
                  onChange={() => {
                    /* If hierarchy is used, select all children when selecting parent item. */
                    if (children.length > 0 && this.props.type === 'category') {
                      _.each(children, ch => {
                        const grandChildren = _.filter(
                          this.props.items,
                          i => i.equipment_category_id_parent === ch.id
                        );
                        _.each(grandChildren, gch => {
                          if (this.props.onChange) {
                            this.props.onChange(gch.id, this.props.type);
                          }
                        });
                        if (this.props.onChange) {
                          this.props.onChange(ch.id, this.props.type);
                        }
                      });
                    }

                    if (typeof this.props.onChange === 'function') {
                      this.props.onChange(item.id, this.props.type);
                    }

                    if (this.props.forceSingleSelection === true) {
                      this.setState({
                        dropdownIsOpen: !this.state.dropdownIsOpen
                      });
                    }
                  }}
                />
              ) : (
                // <Checkbox
                //   id={`checkbox-${this.props.type}-${this.props.identifier}-${item.id}`}
                //   name={`checkbox[${this.props.type}][${item.id}]`}
                //   value="checked"
                //   label={item[this.props.valueProperty] ? item[this.props.valueProperty] : item.name}
                //   checked={this.props.selectedItems[item.id] === true}
                //   onChange={() => {
                //     /* If hierarchy is used, select all children when selecting parent item. */
                //     if (children.length > 0 && this.props.type === 'category') {
                //       _.each(children, (ch) => {
                //         const grandChildren = _.filter(this.props.items, (i) => i.equipment_category_id_parent === ch.id);
                //         _.each(grandChildren, (gch) => {
                //           if (this.props.onChange) {
                //             this.props.onChange(gch.id, this.props.type);
                //           }
                //         });
                //         if (this.props.onChange) {
                //           this.props.onChange(ch.id, this.props.type);
                //         }
                //       });
                //     }

                //     if (typeof this.props.onChange === 'function') {
                //       this.props.onChange(item.id, this.props.type);
                //     }

                //     if (this.props.forceSingleSelection === true) {
                //       this.setState({ dropdownIsOpen: !this.state.dropdownIsOpen });
                //     }

                //   }}
                // />
                <label className="MultiSelector__item MultiSelector__item--no-checkbox">
                  <span>
                    {item[this.props.valueProperty]
                      ? item[this.props.valueProperty]
                      : item.name}
                  </span>
                </label>
              )}

              {/* If hierarchy is used, display arrow if necessary. */}
              {children.length > 0 && filter.length < 3 ? (
                <a
                  href="/"
                  onClick={evt => {
                    evt.preventDefault();
                    let openChilds = this.state.childIsOpen;
                    if (openChilds[item.id] === undefined) {
                      openChilds[item.id] = true;
                    } else {
                      openChilds[item.id] = !openChilds[item.id];
                    }
                    this.setState({ childIsOpen: openChilds });
                  }}
                  className={`MultiSelector__child-toggle ${
                    this.state.childIsOpen[item.id] ? 'toggled' : null
                  }`}
                >
                  {/* <i className="material-icons">keyboard_arrow_down</i> */}
                  <FontAwesomeIcon icon={faArrowDown} size="sm" />
                </a>
              ) : null}

              {/* If hierarchy is used, render child items. */}
              {children.length > 0 && filter.length < 3
                ? this.getSecondLevel(children, this.state.childIsOpen[item.id])
                : ''}
            </div>
          );
        });
    }
    getSecondLevel(children, isOpen = false) {
      const filter = this.state.filterInput;

      return (
        <div>
          {/* Children */}
          {children.length > 0 ? (
            <div
              className={`MultiSelector__row-children ${
                isOpen ? 'open' : null
              }`}
            >
              {children
                .filter(
                  d =>
                    filter === null ||
                    filter.length < 3 ||
                    d.name.toLowerCase().includes(filter.toLowerCase())
                )
                .map(child => {
                  const grandChildren = _.filter(
                    this.props.items,
                    i => i.equipment_category_id_parent === child.id
                  );

                  return (
                    <div className={`MultiSelector__row`} key={child.id}>
                      {/* <SelectionControl
                          id={`checkbox-${this.props.type}-${this.props.identifier}-${child.id}`}
                          name={`checkbox[${this.props.type}][${child.id}]`}
                          type="checkbox"
                          value="checked"
                          label={child[this.props.valueProperty] ? child[this.props.valueProperty] : child.name}
                          checked={this.props.selectedItems[child.id] === true}
                          onChange={() => {
                            if (grandChildren.length > 0 && filter.length < 3) {
                              _.each(grandChildren, (gch) => {
                                if (this.props.onChange) {
                                  this.props.onChange(gch.id, this.props.type);
                                }
                              });
                            }

                            if (this.props.onChange) {
                              this.props.onChange(child.id, this.props.type);
                            }

                            if (this.props.forceSingleSelection === true) {
                              this.setState({ dropdownIsOpen: !this.state.dropdownIsOpen });
                            }
                          }}
                        /> */}

                      <CustomInput
                        type="checkbox"
                        id={`checkbox-${this.props.type}-${this.props.identifier}-${child.id}`}
                        name={`checkbox[${this.props.type}][${child.id}]`}
                        label={
                          child[this.props.valueProperty]
                            ? child[this.props.valueProperty]
                            : child.name
                        }
                        checked={this.props.selectedItems[child.id] === true}
                        onChange={() => {
                          if (grandChildren.length > 0 && filter.length < 3) {
                            _.each(grandChildren, gch => {
                              if (this.props.onChange) {
                                this.props.onChange(gch.id, this.props.type);
                              }
                            });
                          }

                          if (this.props.onChange) {
                            this.props.onChange(child.id, this.props.type);
                          }

                          if (this.props.forceSingleSelection === true) {
                            this.setState({
                              dropdownIsOpen: !this.state.dropdownIsOpen
                            });
                          }
                        }}
                      />

                      {/* Arrow */}
                      {grandChildren.length > 0 ? (
                        <a
                          href="/"
                          onClick={evt => {
                            evt.preventDefault();
                            let openChilds = this.state.childIsOpen;
                            if (openChilds[child.id] === undefined) {
                              openChilds[child.id] = true;
                            } else {
                              openChilds[child.id] = !openChilds[child.id];
                            }
                            this.setState({ childIsOpen: openChilds });
                          }}
                          className={`MultiSelector__child-toggle ${
                            this.state.childIsOpen[child.id] ? 'toggled' : null
                          }`}
                        >
                          {/* <i className="material-icons">keyboard_arrow_down</i> */}
                          <FontAwesomeIcon icon={faArrowDown} size="sm" />
                        </a>
                      ) : null}

                      {this.getThirdLevel(
                        grandChildren,
                        this.state.childIsOpen[child.id]
                      )}
                    </div>
                  );
                })}
            </div>
          ) : null}
        </div>
      );
    }
    getThirdLevel(children, isOpen) {
      const filter = this.state.filterInput;

      return (
        <div>
          {/* Children */}
          {children.length > 0 ? (
            <div
              className={`MultiSelector__row-children ${
                isOpen ? 'open' : null
              }`}
            >
              {children
                .filter(
                  d =>
                    filter === null ||
                    filter.length < 3 ||
                    d.name.toLowerCase().includes(filter.toLowerCase())
                )
                .map(child => {
                  return (
                    <div className={`MultiSelector__row 123`} key={child.id}>
                      {/* <SelectionControl
                          id={`checkbox-${this.props.type}-${this.props.identifier}-${child.id}`}
                          name={`checkbox[${this.props.type}][${child.id}]`}
                          type="checkbox"
                          value="checked"
                          label={child[this.props.valueProperty] ? child[this.props.valueProperty] : child.name}
                          checked={this.props.selectedItems[child.id] === true}
                          onChange={() => {
                            if (this.props.onChange) {
                              this.props.onChange(child.id, this.props.type);
                            }
                            if (this.props.forceSingleSelection === true) {
                              this.setState({ dropdownIsOpen: !this.state.dropdownIsOpen });
                            }
                          }}
                        /> */}

                      <CustomInput
                        id={`checkbox-${this.props.type}-${this.props.identifier}-${child.id}`}
                        name={`checkbox[${this.props.type}][${child.id}]`}
                        type="checkbox"
                        // value="checked"
                        label={
                          child[this.props.valueProperty]
                            ? child[this.props.valueProperty]
                            : child.name
                        }
                        checked={this.props.selectedItems[child.id] === true}
                        onChange={() => {
                          if (this.props.onChange) {
                            this.props.onChange(child.id, this.props.type);
                          }
                          if (this.props.forceSingleSelection === true) {
                            this.setState({
                              dropdownIsOpen: !this.state.dropdownIsOpen
                            });
                          }
                        }}
                      />
                    </div>
                  );
                })}
            </div>
          ) : null}
        </div>
      );
    }
  }
);

export default injectIntl(onClickOutside(MultiSelector));
