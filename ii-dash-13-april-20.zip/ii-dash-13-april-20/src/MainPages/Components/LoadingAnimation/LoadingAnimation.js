import React from 'react';
import './LoadingAnimation.scss';

import loadingIcon from '../../assets/images/loading.svg';
import Loader from 'react-loaders';

const LoadingAnimation = (props) => {
  return (
    // <div className="LoadingAnimation__container">
    //   <img
    //     className="LoadingAnimation__image"
    //     src={loadingIcon}
    //     alt='Loading...'
    //     style={{
    //       right: props.right,
    //       bottom: props.bottom,
    //       left: props.left,
    //     }}
    //   />
      
    // </div>
    <div className="loader-container" style={{  height: 30, width: '100%' }}>
      <div className="loader-container-inner">
        <div className="text-center">
          <Loader type="line-scale-pulse-out" />
        </div>
        <h6>Loading</h6>
      </div>
    </div>
    
  );
}

export default LoadingAnimation;
