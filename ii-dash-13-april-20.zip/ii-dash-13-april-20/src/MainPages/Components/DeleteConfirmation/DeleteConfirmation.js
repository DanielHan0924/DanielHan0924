import React from 'react';
import PropTypes from 'prop-types';

// import Button from '../Button/Button.js';
import {
  Button, Form,
  FormGroup, Label,
  Input, FormText,
  Row, Col,
  Card, CardBody,
  CardTitle, Container,
} from 'reactstrap';
import Localize from '../../Components/Localize/Localize.js';
import './DeleteConfirmation.scss';

const DeleteConfirmation = ({ handleDelete, cancelDelete }) => {
  const confirmationText = <Localize id="tags.singleTag.deleteConfirmation.confirmationText"/>;
  const confirmDeleteText = <Localize id="tags.singleTag.deleteConfirmation.confirm"/>;
  const cancelDeleteText = <Localize id="tags.singleTag.deleteConfirmation.cancel"/>;

  return(
    <div className="DeleteConfirmation">
      <p>{confirmationText}</p>
      <Button
      raised="true" primary="true" className="btn-filter" 
        onClick={handleDelete}
        value={confirmDeleteText}
        >Yes</Button>{' '}
      <Button
      raised="true" primary="true" className="btn-danger" 
        onClick={cancelDelete}
        value={cancelDeleteText}
        >No</Button>{' '}

    </div>
  );
}

DeleteConfirmation.propTypes = {
  handleDelete: PropTypes.func.isRequired,
  cancelDelete: PropTypes.func.isRequired,
}

export default DeleteConfirmation;
