import React from 'react';
import { shallow } from 'enzyme';
import DeleteConfirmation from './DeleteConfirmation.js';
import Button from '../Button/Button.js';

function setup(){
  const props = {
    handleDelete: () => {},
    cancelDelete: () => {}
  };
  return shallow(<DeleteConfirmation {...props} />);
}

describe('DeleteConfirmation', () => {
  let mountedComponent;
  beforeEach(() => {
    mountedComponent = setup();
  });
  it('should render without crashing', () => {
    const mountedComponent = setup();
  });
  it('should render two Buttons', () => {
    const buttons = mountedComponent.find(Button);
    expect(buttons.length).toEqual(2);
  });
  it('should render confirmation text', () => {
    const paragraphs = mountedComponent.find('p');
    expect(paragraphs.length).toEqual(1);
  })
});
