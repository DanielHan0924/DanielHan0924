import React from 'react';
import { observer } from 'mobx-react';

import { injectIntl } from 'react-intl';

import ButtonGroupStore from '../../../models/ButtonGroupStore';

//import { Button } from "reactstrap"
import './ButtonGroup.scss';

const ButtonGroup = observer(
  class ButtonGroup extends React.Component {
    handleToggle(name, type) {
      ButtonGroupStore.toggleItem(name, type);

      let groupBy = name;

      this.props.handleToggle(groupBy);
    }
    render() {
      return <div className="ButtonGroup">{this.getItems()}</div>;
    }
    getItems() {
      let options = this.props.items;
      const selectedItem = ButtonGroupStore.selectedItem[this.props.type];

      return options.map(item => {
        if (item === undefined || item === null) return '';
        return (
          <button
            key={item.id}
            className={`btn-pill btn ${
              selectedItem === item.id ? 'btn-info' : 'btn-light'
            }`}
            onClick={() => this.handleToggle(item.id, this.props.type)}
            style={{ marginRight: 10 }}
          >
            {item.name}
          </button>
        );
      });
    }
  }
);

export default injectIntl(ButtonGroup);
