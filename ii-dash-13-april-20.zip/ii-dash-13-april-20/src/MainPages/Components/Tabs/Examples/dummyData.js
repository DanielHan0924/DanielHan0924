/* eslint max-len: 0 */

export const presidents = [
    {
        name: 'George Washington',
        biography: 'George Washington (February 22, 1732 – December 14, 1799) was the first President of the United States...',
    },
    {
        name: 'Thomas Jefferson',
        biography: 'Thomas Jefferson (April 13 1743 – July 4, 1826) was an American lawyer',
    },
    {
        name: 'Abraham Lincoln',
        biography: 'Abraham Lincoln (February 12, 1809 – April 15, 1865) was the 16th President of the United States',
    }
];

export default presidents;