import React from 'react';
import { shallow } from 'enzyme';

import Currency from './Currency.js';

function setup(amount = 0){
  const props = {
    amount
  };
  return shallow(<Currency {...props}/>);
}

describe('Currency', () => {
  let mountedCurrency;
  let amount;
  beforeEach(() => {
    amount = 100;
    mountedCurrency = setup(amount);
  });
  it('should render without crashing', () => {
    const mountedCurrency = setup();
  });
  it('should render a span', () => {
    const spans = mountedCurrency.find('span');
    expect(spans.length).toEqual(1);
  });
  it('should render the amount of currency followed by €-sign', () => {
      const spans = mountedCurrency.find('span');
      expect(spans.text()).toEqual(`${amount}€`);
  });
});

describe('When Currency amount is more than 1000', () => {
  let mountedCurrency;
  let amount;
  beforeEach(() => {
    amount = 1500;
    mountedCurrency = setup(amount);
  });
  it('should render amount with thousands separated by a comma', () => {
    const spans = mountedCurrency.find('span');
    expect(spans.text()).toEqual('1,500€');
  });
});

describe('getFormattedAmount', () => {
  it('should separate thousands by comma and add a €-sign to the end', () => {
    const mountedCurrency = setup(3333);
    const formattedAmount = mountedCurrency.instance().getFormattedAmount();
    expect(formattedAmount).toEqual('3,333€');
  });
});
