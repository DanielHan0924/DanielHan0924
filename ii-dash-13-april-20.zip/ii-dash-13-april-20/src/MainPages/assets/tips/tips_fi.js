const loadingTips = [
  {
    text: ["Nähdäksesi kaikki kuntosalilaitteesi mene \"Laitteet\"-välilehdelle."]
  },
  {
    text: ["Vaihda havaintoväliä Suodattimet-valikosta kohdasta Päivämäärät."]
  },
  {
    text: ["Havaintovälin oletusarvo on edeltävä viikko."]
  },
  {
    text: ["Salasanan voi vaihtaa sisäänkirjautumisnäkymässä \"Etkö muista salasanaasi?\" -painikkeella ja toimimalla ohjeiden mukaisesti."]
  },
  {
    text: ["Vaihda käyttöliittymän kieli sivun ylälaidasta."]
  },
  {
    text: ["Vahvista mikä tahansa muutos Suodattimet-valikossa painamalla Vahvista valinnat -painiketta."]
  },
  {
    text: ["\"Laitteet\"-välilehdellä näet viikonpäivien käyttöasteet vaihtamalla Laite-näkymä Viikonpäivään."]
  },
  {
    text: ["Ymmärrä aamu- ja iltakuntoilijoiden tarpeita tarkentamalla tuntivalintaa Aika-valikosta \"Laitteet\"-välilehdeltä."]
  },
  {
    text: ["Ymmärrä erot arki- ja viikonloppukäytön välillä tarkentamalla valinta Aika-valikosta \"Laitteet\"-välilehdeltä."]
  },
  {
    text: ["\"Laitteet\"-välilehdeltä pystyt rajaamaan tarkastelun kohteena olevia laitteita (esim. Cardio) Kategoriat-kohdasta."]
  }

];


export default loadingTips;
