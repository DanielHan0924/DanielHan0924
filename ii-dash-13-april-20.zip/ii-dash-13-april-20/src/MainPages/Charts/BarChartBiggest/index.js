import React, {Suspense} from "react";
import Loader from 'react-loaders';
import { observer } from "mobx-react";

import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

const BarChartBiggest = (props) => {
  
  if (props.loading) {
    return (
        <div className="loader-container" style={{height: 400, width: '100%'}}>
          <div className="loader-container-inner">
            <div className="text-center">
              <Loader type="line-scale-pulse-out" />
            </div>
            <h6>Loading</h6>
          </div>
        </div>
    );
  }

  let getBarOptions = (data2, labels, type) => {
	  
	const chartGray = "#eef0f2";
    if (data2 == undefined) return;
    let barColor; 
    if(type == "cold") {
      barColor = '#4cc7e6';
    } else {
      barColor = '#ff4600';
    }
    return {
      chart: {
        type: 'column'
      },
      title: {
		text: ""
	  },
	  subtitle: {
		text: ""
	  },
      // subtitle: {
      //   text: 'Source: <a href="https://en.wikipedia.org/wiki/World_population">Wikipedia.org</a>'
      // },
      xAxis: {
        categories: labels,
        title: {
          text: null
        }
      },
      yAxis: {
		min: 0,
		title: {
		  text: "Utilization-%", // Will be overwritten by translation
		  align: "high"
		},
		labels: {
		  overflow: "justify",
		  style: {
			color: "#656668"
		  },
		  formatter() {
			return `${Math.round(this.value)}%`;
		  }
		},
		gridLineColor: chartGray,
		lineColor: chartGray,
		tickColor: chartGray
	  },
  getPlotOptions: {
    series: {
      pointWidth: 28,
      dataLabels: {
        enabled: true,
        align: "right",
        shadow: false,
        borderWidth: 0,
        padding: 0,
        y: -1,
        x: -3,
        style: {
          color: "#ffffff",
          textOutline: false,
          fontSize: "13px"
        },
        formatter() {
          return `${(this.y * 100).toFixed(2)} %`;
        }
      }
    }
  },
    tooltip: {
        valueSuffix: ' %'
      },
      plotOptions: {
    bar: {
      animation: {
        duration: 1000
      }
    },
    series: {
      pointWidth: 28,
      dataLabels: {
        enabled: true,
        align: "right",
        shadow: false,
        borderWidth: 0,
        padding: 0,
        y: -1,
        x: -3,
        style: {
          color: "#ffffff",
          textOutline: false,
          fontSize: "13px"
        },
        formatter() {
          return `${(this.y * 100).toFixed(2)} %`;
        }
      }
    }
  },
      legend: {
		enabled: false
	  },
	  credits: {
		enabled: false
	  },
      series: [{
        name: "",
        data: data2.map(function(x) {
           let t = (x * 100).toFixed(2);
           return parseFloat(t); 
          }),
        color: barColor
      }]
    }
  };

  return (
    <HighchartsReact
      highcharts={Highcharts}
      options={getBarOptions(props.data, props.labels, props.type)} />
  );
};

export default observer(BarChartBiggest);
