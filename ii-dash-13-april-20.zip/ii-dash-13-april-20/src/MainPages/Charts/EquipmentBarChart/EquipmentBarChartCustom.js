import React from 'react';
import Loader from 'react-loaders';
import { observer } from 'mobx-react';
import { injectIntl } from 'react-intl';
import { toJS } from 'mobx';
import _ from 'lodash';

import config from './config';

import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

import EquipmentDetailsStore from '../../../models/EquipmentDetailsStore';
import DetailEquipment from './DetailEquipment';

// stores
import FilterStore from '../../../models/FilterStore';
import SingleEquipmentStore from '../../../models/SingleEquipmentStore';

// Helpers & Services
import ApiMiddleware from '../../../services/Api';
import Auth from '../../../services/Auth';

const api = new ApiMiddleware();
const auth = new Auth();
api.setToken(auth.getIdToken());

const EquipmentBarChartCustom = observer(
  class EquipmentBarChartCustom extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        isOpen: false,
        equipmentDetail: null
      };
    }

    configureChart(chartToConfigure) {
      const chartConfig = _.cloneDeep(chartToConfigure);
      this.setChartHeight(chartConfig);
      this.setYAxisTitle(chartConfig);
      this.setLabels(chartConfig);
      this.setChartData(chartConfig);
      this.setBarOnClickHandler(chartConfig);
      this.setTooltip(chartConfig);
      return chartConfig;
    }

    toggleModal = () => {
      const { isOpen } = this.state;
      if (isOpen) {
        this.setState({ isOpen: false, equipmentDetail: null });
      }
    };

    setChartHeight(chartConfig) {
      let height;
      if (EquipmentDetailsStore.useCompare === true) {
        height = EquipmentDetailsStore.labels.length * 100;
      } else {
        height = EquipmentDetailsStore.labels.length * 60;
      }
      chartConfig.chart.height = `${height + 100}px`;
    }

    setYAxisTitle(chartConfig) {
      const { formatMessage } = this.props.intl;
      chartConfig.yAxis.title.text = formatMessage({
        id: 'widget.equipment.utilization'
      });
    }

    setLabels(chartConfig) {
      let labels = [];
      const { formatMessage } = this.props.intl;

      if (
        EquipmentDetailsStore.groupBy === 'timePart' &&
        (EquipmentDetailsStore.timePart === 'dow' ||
          EquipmentDetailsStore.timePart === 'month')
      ) {
        labels = _.map(EquipmentDetailsStore.labels, label => {
          return formatMessage({ id: label });
        });
      } else if (
        EquipmentDetailsStore.groupBy === 'timePart' &&
        EquipmentDetailsStore.timePart === 'week'
      ) {
        labels = _.map(EquipmentDetailsStore.labels, label => {
          return (
            formatMessage({ id: 'widget.dimension.timePartWeek' }) + ' ' + label
          );
        });
      } else {
        labels = EquipmentDetailsStore.labels;
      }

      _.extend(chartConfig, {
        xAxis: { categories: labels,
                  labels: {                     //for test
                    style: {
                      color: "#3c73c8",
                      fontFamily: "sans-serif",
                      // font:'16px sans-serif, Roboto',
                      fontSize: "13px",
                      fontWeight: 'bold'
                    },
          }, }
        });
    }

    setChartData(chartConfig) {
      if (EquipmentDetailsStore.useCompare === true) {
        _.extend(chartConfig, {
          series: [
            { data: EquipmentDetailsStore.data[0] },
            { data: EquipmentDetailsStore.data[1], color: "#ff4600" }    //for test in legend!
          ]
        });
      } else {
        _.extend(chartConfig, {
          series: [{ data: EquipmentDetailsStore.data }]
        });
      }
    }

    setBarOnClickHandler(chartConfig) {
      const selectedSortingCriteria = EquipmentDetailsStore.groupBy;
      if (selectedSortingCriteria !== 'equipment_id') {
        return;
      }

      let _self = this;
      let barColor;
      if (EquipmentDetailsStore.useCompare === true) {        //for test, but this "if" statement is useless anymore as the _extend in Line 117
        barColor = '#4cc7e6';                                

      } else {
        barColor = '#4cc7e6';

      }

      _.extend(chartConfig, {
        plotOptions: {
          bar: {
            groupPadding:0.05,
            pointPadding:0.1,
            states: {
               hover: {
                   color:'#3c73c8'                               //for test
               }
           }
        },
          series: {
            color:barColor,                                      //for test
            cursor: 'pointer',
            point: {
              events: {
                click: function() {
                  const { startDate, endDate } = FilterStore;
                  const yCoordinate = this.y;

                  const rawDataObjectWithEquipmentId = EquipmentDetailsStore.rawData.find(
                    object => {
                      return object.utilization === yCoordinate;
                    }
                  );

                  /* Find correct equipment data based on user click */
                  let equipmentToDisplay = FilterStore.filterData.equipment.find(
                    equipment => {
                      return (
                        equipment.id ===
                        toJS(rawDataObjectWithEquipmentId).equipment_id
                      );
                    }
                  );

                  equipmentToDisplay = toJS(equipmentToDisplay);
                  if (equipmentToDisplay) {
                    SingleEquipmentStore.setIsVisible(true);
                  }
                  SingleEquipmentStore.setEquipment(equipmentToDisplay);
                  SingleEquipmentStore.setDates({ startDate, endDate });

                  _self.setState({
                    isOpen: true,
                    equipmentDetail: SingleEquipmentStore.equipment
                  });
                }
              }
            },
            pointWidth: 28,
            dataLabels: {
              enabled: true,
              align: 'right',
              shadow: false,
              borderWidth: 0,
              padding: 0,
              y: -1,
              useHTML: true,
              zIndex: 1,
              style: {
                textOutline: false,
                fontSize: '13px',
                allowOverlap: false
              },
              formatter() {
                if (this.point.plotX > 210) {
                  return `<div style="color: #ffffff; margin-right: 3px;fontFamily: sans-serif">${(
                    this.y * 100
                  ).toFixed(2)} %</div>`;
                } else {
                  return `<div style="color: #262930; margin-left: 10px;fontFamily: sans-serif">${(
                    this.y * 100
                  ).toFixed(2)} %</div>`;
                }
              }
            }
          }
        }
      });
    }

    setTooltip(chartConfig) {
      const selectedSortingCriteria = EquipmentDetailsStore.groupBy;
      if (selectedSortingCriteria !== 'equipment_id') {
        chartConfig.tooltip.formatter = function() {
          return `<b>${this.x}:</b> ${(this.y * 200).toFixed(2)} %`;
        };
        return;
      }

      const { formatMessage } = this.props.intl;
      const infoText = formatMessage({ id: 'widget.tooltip.moreInformation' });
      chartConfig.tooltip.formatter = function() {
        return `<b>${this.x}:</b> ${(this.y * 100).toFixed(
          2
        )} % <br /> ${infoText}`;
      };
    }

    render() {
      const { loading } = this.props;
      const { isOpen } = this.state;

      const { formatMessage } = this.props.intl;

      // eslint-disable-next-line
      let period = `${FilterStore.activeFilters.startDate.format(
        formatMessage({ id: 'date.format' })
      )} - ${FilterStore.activeFilters.endDate.format(
        formatMessage({ id: 'date.format' })
      )}`;

      if (EquipmentDetailsStore.useCompare === true) {
        period += ` vs ${FilterStore.compareFilters.startDate.format(
          formatMessage({ id: 'date.format' })
        )} - ${FilterStore.compareFilters.endDate.format(
          formatMessage({ id: 'date.format' })
        )}`;
      }

      let chartConfig = this.configureChart(config);

      if (loading) {
        return (
          <div
            className="loader-container"
            style={{ height: 400, width: '100%' }}
          >
            <div className="loader-container-inner">
              <div className="text-center">
                <Loader type="line-scale-pulse-out" />
              </div>
              <h6>Loading</h6>
            </div>
          </div>
        );
      } else {
        return (
          <>
            <DetailEquipment isOpen={isOpen} toggleModal={this.toggleModal} />
            <HighchartsReact
              ref="chart"
              highcharts={Highcharts}
              options={chartConfig}
            />
          </>
        );
      }
    }
  }
);

export default injectIntl(EquipmentBarChartCustom);
