import React, {Suspense} from "react";
import Loader from 'react-loaders';
import { observer } from "mobx-react";

import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

const EquipmentBarChart = (props) => {
  
  if (props.loading) {
    return (
        <div className="loader-container" style={{height: 400, width: '100%'}}>
          <div className="loader-container-inner">
            <div className="text-center">
              <Loader type="line-scale-pulse-out" />
            </div>
            <h6>Loading</h6>
          </div>
        </div>
    );
  }

  let getBarOptions = (data2, labels, type) => {
    if (data2 == undefined) return;
    let barColor; 
    if(type == "cold") {
      barColor = '#4cc7e6';
    } else {
      barColor = '#ff4600';
    }
    return {
      chart: {
        type: 'bar'
      },
      title: {
        text: 'Equipment'
      },
      // subtitle: {
      //   text: 'Source: <a href="https://en.wikipedia.org/wiki/World_population">Wikipedia.org</a>'
      // },
      xAxis: {
        categories: labels,
        title: {
          text: null
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Utilization-%',
          align: 'high'
        },
        labels: {
          overflow: 'justify'
        }

      },
      tooltip: {
        valueSuffix: ' %'
      },
      plotOptions: {
        bar: {
          dataLabels: {
            enabled: true
          }
        }
      },
      legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        x: -40,
        y: 80,
        floating: true,
        borderWidth: 1,
        backgroundColor:
          // Highcharts.defaultOptions.legend.backgroundColor || '#FFFFFF',
          '#00008b',
        shadow: true
      },
      credits: {
        enabled: false
      },
      series: [{
        name: "",
        data: data2.map(function(x) {
           let t = (x * 100).toFixed(2);
           return parseFloat(t); 
          }),
        color: barColor
      }]
    }
  };

  return (
    <HighchartsReact
      highcharts={Highcharts}
      options={getBarOptions(props.data, props.labels, props.type)} />
  );
};

export default observer(EquipmentBarChart);
