import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { injectIntl } from "react-intl";
import Loader from 'react-loaders';
import _ from 'lodash';

import SingleEquipmentStore from '../../../models/SingleEquipmentStore.js';
import FilterStore from '../../../models/FilterStore';
import HourlyUtilization from './HourlyUtilization';
// import LoadingAnimation from '../../LoadingAnimation/LoadingAnimation.js';

import config from './ProfileChart.config.js';
const ReactHighcharts = require('react-highcharts');
require('highcharts-data')(ReactHighcharts.Highcharts);

const ProfileChart = observer(
  class ProfileChart extends Component {

    configureChart = (chartToConfigure) => {
      const chartConfig = _.cloneDeep(chartToConfigure);
      const isLoaded = SingleEquipmentStore.dowUtilizationData.length > 0;
      if (!isLoaded) {
        return chartConfig;
      }
      this.setYAxisTitle(chartConfig);
      this.setChartTitle(chartConfig);
      this.setChartData(chartConfig);
      this.setLabels(chartConfig);
      this.addOnBackClickFunction(chartConfig);
      this.setTooltip(chartConfig)
      return chartConfig;
    }

    setYAxisTitle = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      const yAxisTitle = formatMessage({ id: "widget.equipment.utilization" });
      chartConfig.yAxis.title.text = yAxisTitle;
    }

    setChartTitle = (chartConfig) => {
      const {
        startDate,
        endDate
      } = FilterStore;
      const { formatMessage } = this.props.intl;
      const startingDate = startDate.format(formatMessage({ id: "date.format" }));
      const endingDate = endDate ? endDate.format(formatMessage({ id: "date.format" })) : null;
      const chartType = formatMessage({ id: "singleEquipmentView.chartTitle.dow" });
      // _.extend(chartConfig, {
      //   title: {
      //     text: `${chartType}   ${startingDate} - ${endingDate}`,
      //     align: "left"
      //   }
      // });
    }


    setChartData = (chartConfig) => {
      const { dowUtilizationData } = SingleEquipmentStore;
      _.extend(chartConfig, {
        series: [{
          data: dowUtilizationData,
          color: "#4cc7e6"   //for test
        }]
      });
    }

    setLabels = (chartConfig) => {
      // const { formatMessage } = this.props.intl;
      // this has to be done here because intl doens't work inside stores
      // const labels = _.map(SingleEquipmentStore.dowLabels, label => {
      //   return formatMessage({ id: label.name });
      // });
      const labels = SingleEquipmentStore.dowLabels;
      _.extend(chartConfig, {
        xAxis: { categories: labels }
      });
    }

    addOnBackClickFunction = (chartConfig) => {
      _.extend(chartConfig, {
        plotOptions: {
          column:{
            states: {
              hover: {
                  color:'#3c73c8'                               //for test
              }
          }
          },
          series: {
            cursor: "pointer",
            point: {
              color: "#4cc7e6",
              events: {
                click: function (evt) {
                  const xCoordinate = this.x;
                  SingleEquipmentStore.setOneDayStart(xCoordinate);
                  SingleEquipmentStore.toggleShowDow();
                }
              }
            }
          }
        }
      });
    }

    setTooltip = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      const infoText = formatMessage({ id: 'widget.tooltip.moreInformation' });
      chartConfig.tooltip.formatter = function () {
        return (
          `<b>${this.x}:</b> ${(this.y * 100).toFixed(2)} % <br /> ${infoText}`
        );
      }
    }

    componentDidMount() {
      const { id } = this.props.equipment;
      SingleEquipmentStore.reloadDowChart(id);

    }

    render() {
      const { equipment } = this.props;
      const { showDow } = SingleEquipmentStore;
      const isLoading = SingleEquipmentStore.isLoadingDow();
      const chartConfig = this.configureChart(config);
      const { startDate, endDate } = FilterStore;
          const period = `${startDate.format('MM/DD/YYYY')} - ${endDate.format('MM/DD/YYYY')}`;
      // console.log("showDow: ", showDow)

      if (isLoading) {
        return (
          <div className="loader-container" style={{ height: 400, width: '100%' }}>
            <div className="loader-container-inner">
              <div className="text-center">
                <Loader type="line-scale-pulse-out" />
              </div>
              <h6>Loading</h6>
            </div>
          </div>
        );
      } else {
        return (
          <div>
            {showDow
              ?<div> <h3>Weekly Utilization{' '} {period}</h3><ReactHighcharts config={chartConfig} ref='chart' /></div>
              : <HourlyUtilization equipment={equipment} />
            }
          </div>
        );

      }
    }
  }
);

export default injectIntl(ProfileChart);

/* joel.salminen@indoorinformatics.com */
