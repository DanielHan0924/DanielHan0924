import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { injectIntl } from "react-intl";
import Loader from "react-loaders"
import _ from 'lodash';

import SingleEquipmentStore from '../../../models/SingleEquipmentStore.js';

import './hourlyUtilization.scss';

import config from './HourlyUtilization.config.js';
import {
  Button
} from 'reactstrap';
const ReactHighcharts = require('react-highcharts');
require('highcharts-data')(ReactHighcharts.Highcharts);

const HourlyUtilization = observer(
  class HourlyUtilization extends Component {

    configureChart = (chartToConfigure) => {
      const chartConfig = _.cloneDeep(chartToConfigure);
      const isLoaded = SingleEquipmentStore.hourUtilizationData.length > 0;
      if (!isLoaded) {
        return chartConfig;
      }
      this.setYAxisTitle(chartConfig);
      this.setLabels(chartConfig);
      this.setChartTitle(chartConfig);
      this.setChartData(chartConfig);
      return chartConfig;
    }

    setYAxisTitle = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      const titleText = formatMessage({ id: "widget.equipment.utilization" });
      chartConfig.yAxis.title.text = titleText;
    }

    setLabels = (chartConfig) => {
      const { hourLabels } = SingleEquipmentStore;
      const labels = _.map(hourLabels.slice(), label => {
        return `${label}:00`;
      });
      _.extend(chartConfig, {
        xAxis: { categories: labels }
      });
    }

    setChartTitle = (chartConfig) => {
      const { formatMessage } = this.props.intl;
      const dateFormat = formatMessage({ id: "date.format" });
      const date = SingleEquipmentStore.oneDayStart.format(`dd ${dateFormat}`);
      const title = formatMessage({ id: "singleEquipmentView.chartTitle.hourly" });
      _.extend(chartConfig, {
        title: {
          text: `${title} - ${date}`,
          align: "left"
        }
      });
    }

    setChartData = (chartConfig) => {
      _.extend(chartConfig, {
        series: [{
          data: SingleEquipmentStore.hourUtilizationData,
          color: '#4cc7e6',
        }]
      });
    }

    changeView = () => {
      SingleEquipmentStore.toggleShowDow();
    }

    componentDidMount() {
      const { id } = this.props.equipment;
      SingleEquipmentStore.reloadHourChart(id);
    }

    renderBackButton = () => {
      const { formatMessage } = this.props.intl;
      const buttonText = formatMessage({ id: "singleEquipmentView.button.back" });
      return (
        <Button
          raised="true"
          primary="true"
          onClick={this.changeView}
          className=" btn btn-filter"
        >
          {buttonText}
        </Button>
      );
    }

    render() {
      const chartConfig = this.configureChart(config);
      const isLoading = SingleEquipmentStore.isLoadingHourly();



      return (
        <div>
          {this.renderBackButton()}
          {isLoading
            ? (
              <div className="loader-container" style={{ height: 400, width: '100%' }}>
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="line-scale-pulse-out" />
                  </div>
                  <h6>Loading</h6>
                </div>
              </div>
            )
            : <ReactHighcharts config={chartConfig} ref='chart' />
          }

        </div>
      );
    }
  }
);

export default injectIntl(HourlyUtilization);

/* joel.salminen@indoorinformatics.com */
