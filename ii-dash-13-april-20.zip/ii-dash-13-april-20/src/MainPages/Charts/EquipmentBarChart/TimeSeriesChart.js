import React from "react";
import { observer } from "mobx-react";
// charts
import LineChart from '../LineChart';
// stores 
import HomeStore from "../../../models/HomeStore";
import SingleEquipmentStore from '../../../models/SingleEquipmentStore';
import FilterStore from '../../../models/FilterStore';

const TimeSeriesChart = observer(
  class TimeSeriesChart extends React.Component {
    constructor(props) {
      super(props);
      this.state = {}
    }
    // const { startDate, endDate } = FilterStore;
    // const period = `${startDate.format(dateFormat)} - ${endDate.format(dateFormat)}`;

    render() {
         const isLoading = SingleEquipmentStore.isLoadingAverage();
         const { averageUtilizationData, averageUtilizationLabels,avgGroupBy } = SingleEquipmentStore;
          const { startDate, endDate } = FilterStore;
          const period = `${startDate.format('MM/DD/YYYY')} - ${endDate.format('MM/DD/YYYY')}`;
      return (
        <div className="time-series-chart">
           <h3>Average Utilization{' '} {period}</h3>             
          <LineChart
            loading={isLoading}
            // loading={HomeStore.avgChartDataLoading}
            data={averageUtilizationData}
            // data={HomeStore.avgChartData}
            labels={averageUtilizationLabels}
            GroupBy={avgGroupBy}
            type="cold"
          />
        </div>
      );
    }
  }
)

export default TimeSeriesChart;