import React , {Fragment}from 'react';
import './detail-equipment-modal.scss';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faCalendarAlt,
  faPlusCircle,
  /*faRemoveFormat,*/
  faTrashAlt
} from '@fortawesome/free-solid-svg-icons';
import FilterStore from '../../../models/FilterStore';
import moment from 'moment';
import {
  Button, Row,
  Col,
  Modal,
  ModalHeader,
  ModalBody,
  /*ModalFooter,*/ TabContent,
  TabPane,
  Card,
  CardBody,
  Nav,
  NavItem,
  CardHeader,
  NavLink,InputGroup, InputGroupAddon, FormGroup, Label, Form,
} from 'reactstrap';
// import { Collapse, Card, CardBody, Button, CardHeader, CardFooter,  InputGroup, InputGroupAddon, FormGroup, Label, Form, Col, Row } from 'reactstrap';
import DatePicker from 'react-datepicker';
import classnames from 'classnames';

import SingleEquipmentStore from '../../../models/SingleEquipmentStore';
import { observer } from 'mobx-react';
import { injectIntl } from 'react-intl';
import { toJS } from 'mobx';
//import FilterHome from "../../Dashboards/Filter/FilterHome"
import TimeSeriesChart from './TimeSeriesChart';
import ProfileChart from './ProfileChart';

const DetailEquipment = observer(
  class DetailEquipment extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        activeTab: '1',
        startDate: (FilterStore.startDate).toDate(),
        endDate: (FilterStore.endDate).toDate(),
      };
    }
    onApplyClick = () => {
      const { equipment } = SingleEquipmentStore;
      const  id  = equipment.id;
      // alert(id);
      SingleEquipmentStore.reloadAllCharts(id);
    }
    handleChangeAllDate = ({startDate, endDate}) => {
      startDate = startDate || this.state.startDate
      endDate = endDate || this.state.endDate

      const startDate_moment = moment(startDate);
      const endDate_moment = moment(endDate);
      // console.log("Date()type to moment-------",startDate_moment);
      this.setState({startDate, endDate})
      FilterStore.setDates({ startDate_moment, endDate_moment })
    }
    handleChangeStart = (startDate) => this.handleChangeAllDate({startDate});
    handleChangeEnd = (endDate) => this.handleChangeAllDate({endDate});
    handleChangeTab = activeTab => {
      this.setState({ activeTab });
    };

    render() {
      const { isOpen } = this.props;

      const equipment = toJS(SingleEquipmentStore.equipment);
      const dateRangeSelector_new = (
        <div>
          <Fragment>
                <Form>
                    <Row form>
                        <Col md={4}>
                            <FormGroup>
                                <Label for="exampleEmail" className="mr-sm-2">Start Date</Label>
                                <InputGroup>
                                    <InputGroupAddon addonType="prepend">
                                        <div className="input-group-text">
                                            <FontAwesomeIcon icon={faCalendarAlt}/>
                                        </div>
                                    </InputGroupAddon>
                                    <DatePicker
                                        selected={(FilterStore.startDate).toDate()}
                                        selectsStart
                                        className="form-control"
                                        // startDate={(FilterStore.startDate).toDate()}
                                        // endDate={(FilterStore.startDate).toDate()}
                                        onChange={this.handleChangeStart}
                                    />
                                </InputGroup>
                            </FormGroup>
                        </Col>
                        <Col md={4}>
                            <FormGroup>
                                <Label for="examplePassword" className="mr-sm-2">End Date</Label>
                                <DatePicker
                                    selected={(FilterStore.endDate).toDate()}
                                    selectsEnd
                                    className="form-control"
                                    // startDate={(FilterStore.startDate).toDate()}
                                    // endDate={(FilterStore.endDate).toDate()}
                                    onChange={this.handleChangeEnd}
                                />
                            </FormGroup>
                        </Col>
                        <Col md={4}>
                            <FormGroup>
                                <div className="apply_filter col text-center my-auto">
                                  <Button
                                  // color="primary"
                                  onClick={this.onApplyClick}
                                  className="btn-filter"
                                >
                                  Apply Filter
                                </Button>
                                </div>
                            </FormGroup>
                        </Col>
                    </Row>
                </Form>
            </Fragment>
        </div>

      );

      // console.log('equipment: ', equipment);

      return (
        <Modal
          isOpen={isOpen}
          toggle={this.toggle}
          className="detail-equipment-modal"
        >
          <ModalHeader toggle={this.props.toggleModal}>
            <div className="title-custom text-center my-auto">
              <h3>
                {equipment.id} {equipment.name}
              </h3>

              {/* <FilterHome /> */}
            </div>
          </ModalHeader>
          <ModalBody>
            <div className="info">
              <Row>
                <Col sm={3}>
                  <div className="times-info">
                    <p>Category: Strength</p>
                    <p>Brand: Generic Brand</p>
                  </div>
                </Col>
                <Col sm={6}>
                  {dateRangeSelector_new}
                </Col>
                
                <Col sm={3}>
                  <div className="profile-info">
                    <p>Purchase date: 7/31/2015</p>
                    <p>Purchase price: 150€</p>
                  </div>
                </Col>
              </Row>
            </div>
            <Card tabs={true} className="">
              <CardHeader>
                <Nav justified>
                  <NavItem>
                    <NavLink
                      href="#"
                      className={classnames({
                        active: this.state.activeTab === '1'
                      })}
                      onClick={() => {
                        this.handleChangeTab('1');
                      }}
                    >
                      Time series
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      href="#"
                      className={classnames({
                        active: this.state.activeTab === '2'
                      })}
                      onClick={() => {
                        this.handleChangeTab('2');
                      }}
                    >
                      Profile
                    </NavLink>
                  </NavItem>
                </Nav>
              </CardHeader>
              <CardBody>
                <TabContent activeTab={this.state.activeTab}>
                  <TabPane tabId="1">
                    <TimeSeriesChart />
                  </TabPane>
                  <TabPane tabId="2">
                    <ProfileChart equipment={equipment} />
                  </TabPane>
                </TabContent>
              </CardBody>
            </Card>
          </ModalBody>
        </Modal>
      );
    }
  }
);

export default injectIntl(DetailEquipment);
