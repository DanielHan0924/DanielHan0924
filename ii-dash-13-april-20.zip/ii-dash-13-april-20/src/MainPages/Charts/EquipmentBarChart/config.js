const chartGray = "#eef0f2";
let barColor = '#4cc7e6';

export default {
  //  colors:'#4cc7e6',
  chart: {
    type: "bar",
    marginRight: 60                //by test for yaxis margiin
  },
  states: {
    // hover: {
    //        brightness: 1,
    //        color: '#ffffff'
    //           }
  },
  title: {
    text: "",
    style: { fontFamily: "sans-serif", fontSize: "16px" }    //for test
  },  
  subtitle: {
    text: "",
    style: { fontFamily: "sans-serif", fontSize: "16px" }    //for test
  },
  xAxis: {
    className: "highcharts-color-0",
    title: {
      text: null
    },
    categories: [],
    // labels: {
    //   style: {
    //     color: "#3c73c8",
    //     fontFamily: "sans-serif",
    //     // font:'16px sans-serif, Roboto',
    //     fontSize: "16px"
    //   },
    // },
    gridLineColor: chartGray
  },
  yAxis: {
    min: 0,
    title: {
      marginRight: 20,
      text: "Utilization-%", // Will be overwritten by translation
      // align: "high"
    },
    labels: {
      marginRight: 60,
      overflow: "justify",
      style: {
        marginRight: 60,
        color: "#3c73c8",
        fontFamily: "sans-serif",
        // font:'16px sans-serif, Roboto',
        fontSize: "16px"
      },
      formatter() {
        return `${Math.round(this.value * 100 * 10) / 10}%`;
      }
    },  
    gridLineColor: chartGray,
    lineColor: chartGray,
    tickColor: chartGray
  },
  tooltip: {
    valueSuffix: "%",
    followPointer: true,
    shadow: false,
    borderRadius: 0,
    borderWidth: 0,
    padding: 0,
    backgroundColor: "#eef0f2",
    borderColor: "#eef0f2",
    style: {
      fontSize: "14px",
    },
    useHTML: true,
    formatter() {
      return `<div class="tooltip"><b>${this.x}:</b> ${(this.y * 100).toFixed(2)} %</div>`;
    }
  },
  plotOptions: {
    bar: {
      states: {
          hover: {
              color: '#ffffff'                                                           
          }
      }

  },
    bar: {
      animation: {
        duration: 1000
      },
    //   states: {
    //     hover: {
    //         color: '#ffffff'                                                  
    //     }
    // }
    },
    
  },
  legend: {
    enabled: false
  },
  credits: {
    enabled: false
  },

  series: [
    {
      name: "Selected period", // Will be overwritten by translation
      data: [], // Will be populated by the widget
      color: '#4cc7e6'
    }
  ]
};
