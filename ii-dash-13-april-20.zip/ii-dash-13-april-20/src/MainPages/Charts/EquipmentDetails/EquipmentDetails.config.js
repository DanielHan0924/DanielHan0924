const chartGray = "#eef0f2";

export default {
  chart: {
    type: "bar",
    style: { fontFamily: "Barlow", fontSize: "16px" }
  },
  title: {
    text: ""
  },
  subtitle: {
    text: ""
  },
  xAxis: {
    className: "highcharts-color-0",
    title: {
      text: null
    },
    categories: [],
    labels: {
      style: {
        color: "#656668",
        fontSize: "16px"
      }
    },
    gridLineColor: chartGray
  },
  yAxis: {
    min: 0,
    title: {
      text: "Utilization-%", // Will be overwritten by translation
      align: "high"
    },
    labels: {
      overflow: "justify",
      style: {
        color: "#656668",
        fontSize: "16px"
      },
      formatter() {
        return `${Math.round(this.value * 100 * 10) / 10}%`;
      }
    },
    gridLineColor: chartGray,
    lineColor: chartGray,
    tickColor: chartGray
  },
  tooltip: {
    valueSuffix: "%",
    followPointer: true,
    shadow: false,
    borderRadius: 0,
    borderWidth: 0,
    padding: 0,
    backgroundColor: "#eef0f2",
    borderColor: "#eef0f2",
    style: {
      fontSize: "14px",
    },
    useHTML: true,
    formatter() {
      return `<div class="tooltip"><b>${this.x}:</b> ${(this.y * 100).toFixed(2)} %</div>`;
    }
  },
  plotOptions: {
    bar: {
      animation: {
        duration: 1000
      }
    },
    series: {
    }
  },
  legend: {
    enabled: false
  },
  credits: {
    enabled: false
  },

  series: [
    {
      name: "Selected period", // Will be overwritten by translation
      data: [], // Will be populated by the widget
    }
  ]
};
