export default Object.freeze({
  TOP_CATEGORY: 'topCategory',
  MIDDLE_CATEGORY: 'middleCategory',
  BOTTOM_CATEGORY: 'bottomCategory'
});
