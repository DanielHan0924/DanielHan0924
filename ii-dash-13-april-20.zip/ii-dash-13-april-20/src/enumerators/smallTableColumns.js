import columns from './tableColumns.js';
import columnTypes from './columnTypes.js'

const getSmallTableColumns = (columns) => {
  columns.forEach(column => {
    if(column.name === columnTypes.DATE || column.name === columnTypes.CATEGORY_ID){
      column.showByDefault = false;
    }
  });
  return columns;
}

const copiedColumns = columns.map(column => Object.assign({}, column));
const smallTableColumns = getSmallTableColumns(copiedColumns);

export default smallTableColumns;
