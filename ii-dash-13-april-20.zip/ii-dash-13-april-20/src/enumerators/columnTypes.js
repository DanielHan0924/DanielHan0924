export default Object.freeze({
  ID: 'id',
  MONITORING: 'ab_active',
  DESCRIPTION: 'description',
  DATE: 'timestamp_activated',
  NAME: 'name',
  PREMISE_ID: 'premise_id',
  DEVICE_ID: 'device_id',
  CATEGORY_ID: 'category_id',
  EQUIPMENT_ID: 'equipment_id',
  TAG_TO_DATE_DIFFERENCE: 'ttd_reldiff',
  D7_DIFFERENCE: 'd7_reldiff',
  D14_DIFFERENCE: 'd14_reldiff',
  D30_DIFFERENCE: 'd30_reldiff',
  MONETARY_ESTIMATE: 'monetary_estimate'
});
