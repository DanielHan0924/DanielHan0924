// export default [
//   { id: 0, name: "id", value: 0, label: 'ID', hasMultipleValues: false, showByDefault: false },
//   { id: 1, name: "name", value: 1, label: 'Event', hasMultipleValues: false, showByDefault: true },
//   { id: 2, name: "ab_active", value: 2, label: 'Monitoring', hasMultipleValues: false, showByDefault: false },
//   { id: 3, name: "description", value: 3, label: 'Description', hasMultipleValues: false, showByDefault: false },
//   { id: 4, name: "timestamp_activated", value: 4, label: 'Date', hasMultipleValues: false, showByDefault: true },
//   { id: 5, name: "premise_id", value: 5, label: 'Premises', hasMultipleValues: true, showByDefault: false },
//   { id: 6, name: "device_id", value: 6, label: 'Devices', hasMultipleValues: true, showByDefault: false },
//   { id: 7, name: "category_id", value: 7, label: 'Categories', hasMultipleValues: true, showByDefault: true },
//   { id: 8, name: "equipment_id", value: 8, label: 'Equipment', hasMultipleValues: true, showByDefault: true },
//   { id: 9, name: "ttd_reldiff", value: 9, label: 'Change', hasMultipleValues: false, showByDefault: false },
//   { id: 10, name: "d7_reldiff", value: 10, label: 'Change in 1 week', hasMultipleValues: false, showByDefault: false },
//   { id: 11, name: "d14_reldiff", value: 11, label: 'Change in 2 week', hasMultipleValues: false, showByDefault: false },
//   { id: 12, name: "d30_reldiff", value: 12, label: 'Change in 4 weeks', hasMultipleValues: false, showByDefault: true },
//   { id: 13, name: "monetary_estimate", value: 13, label: 'Expected value', hasMultipleValues: false, showByDefault: false }
// ];
export default [
  { id: 0, name: "id", value: 0, label: 'id', hasMultipleValues: false, showByDefault: false },
  { id: 1, name: "name", value: 1, label: 'name', hasMultipleValues: false, showByDefault: true },
  { id: 2, name: "ab_active", value: 2, label: 'ab_active', hasMultipleValues: false, showByDefault: false },
  { id: 3, name: "description", value: 3, label: 'description', hasMultipleValues: false, showByDefault: false },
  { id: 4, name: "timestamp_activated", value: 4, label: 'timestamp_activated', hasMultipleValues: false, showByDefault: true },
  { id: 5, name: "premise_id", value: 5, label: 'premise_id', hasMultipleValues: true, showByDefault: false },
  { id: 6, name: "device_id", value: 6, label: 'device_id', hasMultipleValues: true, showByDefault: false },
  { id: 7, name: "category_id", value: 7, label: 'category_id', hasMultipleValues: true, showByDefault: true },
  { id: 8, name: "equipment_id", value: 8, label: 'equipment_id', hasMultipleValues: true, showByDefault: true },
  { id: 9, name: "ttd_reldiff", value: 9, label: 'ttd_reldiff', hasMultipleValues: false, showByDefault: false },
  { id: 10, name: "d7_reldiff", value: 10, label: 'd7_reldiff', hasMultipleValues: false, showByDefault: false },
  { id: 11, name: "d14_reldiff", value: 11, label: 'd14_reldiff', hasMultipleValues: false, showByDefault: false },
  { id: 12, name: "d30_reldiff", value: 12, label: 'd30_reldiff', hasMultipleValues: false, showByDefault: true },
  { id: 13, name: "monetary_estimate", value: 13, label: 'monetary_estimate', hasMultipleValues: false, showByDefault: false }
];

