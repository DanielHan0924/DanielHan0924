import React, {Component, Fragment} from 'react';
import {connect} from 'react-redux';
import cx from 'classnames';

import Nav from '../AppNav/VerticalNavWrapper';

import ReactCSSTransitionGroup from 'react-addons-css-transition-group';

import PerfectScrollbar from 'react-perfect-scrollbar';
import HeaderLogo from '../AppLogo';

import {
    setEnableMobileMenu
} from '../../reducers/ThemeOptions';
import Auth from "../../services/Auth";

import './AppSidebar.scss';
  
const auth = new Auth();

class AppSidebar extends Component {

    state = {};

    toggleMobileSidebar = () => {
        let {enableMobileMenu, setEnableMobileMenu} = this.props;
        setEnableMobileMenu(!enableMobileMenu);
    }
    handleLogOut(evt) {
        // console.log("logout!!!", evt);
        evt.preventDefault();
        auth.logout();
    }

    render() {
        let {
            backgroundColor,
            enableBackgroundImage,
            enableSidebarShadow,
            backgroundImage,
            backgroundImageOpacity,
        } = this.props;

        return (
            <Fragment>
                <div className="sidebar-mobile-overlay" onClick={this.toggleMobileSidebar}/>
                <ReactCSSTransitionGroup
                    component="div"
                    className={cx("app-sidebar", backgroundColor, {'sidebar-shadow': enableSidebarShadow})}
                    transitionName="SidebarAnimation"
                    transitionAppear={true}
                    transitionAppearTimeout={150}
                    transitionEnter={false}
                    transitionLeave={false}>
                    <HeaderLogo/>
                    <PerfectScrollbar>
                        <div className="app-sidebar__inner">
                            <Nav/>
                            {/* <div className="btn-PC-logout-sidebar">
                                <Button
                                    className="btn-primary btn-pill btn-shadow btn-shine"
                                    onClick={e => {
                                        e.preventDefault();
                                        auth.logout();
                                    }}
                                    color="focus"
                                >
                                    Logout
                                </Button>
                            </div>
                            <div className="btn-mobile-logout-sidebar">
                                <a href="#"  onClick={e => {
                                        e.preventDefault();
                                        auth.logout();
                                    }}>
                                    <div id="wrapper">
                                        <img
                                            class="hover"
                                            src={logout}
                                            alt="Logout"
                                            width="40"
                                            height="40"
                                            // style={{ margin: '0 10px 0 0' }}
                                        />
                                        <p class="text">Logout</p>
                                    </div>
                                </a>
                            </div> */}
                            
                        </div>
                        {/* <div className="widget-content-right mr-2">
                            <Button
                                className="btn-pill btn-shadow btn-shine"
                                onClick={e => this.handleLogout(e)}
                                color="focus"
                            >
                                Logout
                            </Button>
                        </div> */}
                    </PerfectScrollbar>

                    <div
                        className={cx("app-sidebar-bg", backgroundImageOpacity)}
                        style={{
                            backgroundImage: enableBackgroundImage ? 'url(' + backgroundImage + ')' : null
                        }}>
                    </div>
                </ReactCSSTransitionGroup>
            </Fragment>
        )
    }
}

const mapStateToProps = state => ({
    enableBackgroundImage: state.ThemeOptions.enableBackgroundImage,
    enableSidebarShadow: state.ThemeOptions.enableSidebarShadow,
    enableMobileMenu: state.ThemeOptions.enableMobileMenu,
    backgroundColor: state.ThemeOptions.backgroundColor,
    backgroundImage: state.ThemeOptions.backgroundImage,
    backgroundImageOpacity: state.ThemeOptions.backgroundImageOpacity,
});

const mapDispatchToProps = dispatch => ({

    setEnableMobileMenu: enable => dispatch(setEnableMobileMenu(enable)),

});

export default connect(mapStateToProps, mapDispatchToProps)(AppSidebar);