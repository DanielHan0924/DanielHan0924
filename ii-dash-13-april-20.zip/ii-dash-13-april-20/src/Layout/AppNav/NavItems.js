import Auth from "../../services/Auth";
const auth = new Auth();
export const MainNav = [
	{
        icon: 'pe-7s-home',
        label: 'Home',
		    to: '/dashboards/analytics',
    },
	{
        icon: 'pe-7s-gym',
        label: 'Equipment',
		    to: '/dashboards/equipment',
    },
	{
        icon: 'pe-7s-edit',
        label: 'Events',
		to: '/dashboards/event',
    },
	{
        icon: 'pe-7s-shuffle',
        label: 'Comparison',
	    	to: '/dashboards/comparison',
    },
   
	{
        icon: 'pe-7s-display1',
        label: 'Management',
		    to: '/dashboards/management',
    },
    {
      icon: 'pe-7s-power',
      label: 'Logout',
      // to: {}auth.logout(),
      to:'/dashboards/signout'
  },
];
