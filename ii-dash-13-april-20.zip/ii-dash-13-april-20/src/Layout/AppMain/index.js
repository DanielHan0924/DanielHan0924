import {
  BrowserRouter as Router,
  Route
  /*Redirect,
  withRouter*/
} from 'react-router-dom';
//import { observer } from 'mobx-react';
import React, { Suspense, lazy, Fragment, Component } from 'react';
import Loader from 'react-loaders';
import Auth from '../../services/Auth';
import { ToastContainer } from 'react-toastify';

const UserPages = lazy(() => import('../../MainPages/UserPages'));
const Login = lazy(() => import('../../MainPages/UserPages/Login'));
const Applications = lazy(() => import('../../MainPages/Applications'));
const Dashboards = lazy(() => import('../../MainPages/Dashboards'));

const Widgets = lazy(() => import('../../MainPages/Widgets'));
// const Elements = lazy(() => import('../../MainPages/Elements'));
const Components = lazy(() => import('../../MainPages/Components'));
const Callback = lazy(() => import('../../MainPages/Components/Callback'));
const Charts = lazy(() => import('../../MainPages/Charts'));
// const Forms = lazy(() => import('../../MainPages/Forms'));
// const Tables = lazy(() => import('../../MainPages/Tables'));
const auth = new Auth();

class AppMain extends Component {
  handleAuthentication({ location }) {
    // console.log(location);
    //console.log(auth);
    if (/access_token|id_token|error/.test(location.hash)) {
      //console.log(location.hash);
      // auth.handleAuthentication(location.hash);
      auth.handleAuthentication();
    }
  }
  login() {
    auth.login();
  }
  render() {
    const { isAuthenticated } = auth;
    return (
      <Router>
        <Fragment>
          <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="ball-pulse-rise" />
                  </div>
                  <h6 className="mt-5">
                    Please wait while we load
                    <small>
                      Always click Apply filters to save changes you have made
                      under Filters.
                    </small>
                  </h6>
                </div>
              </div>
            }
          >
            <Route
              exact
              path="/"
              component={() =>
                !isAuthenticated() ? (
                  <Login auth={auth} {...this.props} />
                ) : (
                  <Route path="/dashboards" component={Dashboards} />
                )
              }
            />
          </Suspense>
          {/* Components */}

          <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="ball-pulse-rise" />
                  </div>
                  <h6 className="mt-5">Loading, please wait.</h6>
                </div>
              </div>
            }
          >
            <Route path="/components" component={Components} />
          </Suspense>

          <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="ball-pulse-rise" />
                  </div>
                  <h6 className="mt-5">Loading, please wait.</h6>
                </div>
              </div>
            }
          >
            <Route
              exact
              path="/login"
              component={() =>
                isAuthenticated() ? (
                  <Route path="/dashboards" component={Dashboards} />
                ) : (
                  <Login auth={auth} {...this.props} />
                )
              }
            />
          </Suspense>
          <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="ball-pulse-rise" />
                  </div>
                  <h6 className="mt-5">Loading, please wait.</h6>
                </div>
              </div>
            }
          >
            <Route
              path="/callback"
              render={props => {
                this.handleAuthentication(props);
                return <Callback {...props} />;
              }}
            />
          </Suspense>
          {/* Forms */}

          {/* <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="ball-pulse-rise" />
                  </div>
                  <h6 className="mt-5">Loading, please wait.</h6>
                </div>
              </div>
            }
          >
            <Route path="/forms" component={Forms} />
          </Suspense> */}

          {/* Charts */}

          <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="ball-rotate" />
                  </div>
                  <h6 className="mt-3">Loading, please wait.</h6>
                </div>
              </div>
            }
          >
            <Route path="/charts" component={Charts} />
          </Suspense>

          {/* Tables */}

          {/* <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="ball-pulse-rise" />
                  </div>
                  <h6 className="mt-5">Loading, please wait.</h6>
                </div>
              </div>
            }
          >
            <Route path="/tables" component={Tables} />
          </Suspense> */}

          {/* Elements */}

          {/* <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="line-scale" />
                  </div>
                  <h6 className="mt-3">Loading, please wait.</h6>
                </div>
              </div>
            }
          >
            <Route path="/elements" component={Elements} />
          </Suspense> */}

          {/* Dashboard Widgets */}

          <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="ball-pulse-sync" />
                  </div>
                  <h6 className="mt-3">Loading, please wait.</h6>
                </div>
              </div>
            }
          >
            <Route path="/widgets" component={Widgets} />
          </Suspense>

          {/* Pages */}

          <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="line-scale-party" />
                  </div>
                  <h6 className="mt-3">Loading, please wait.</h6>
                </div>
              </div>
            }
          >
            <Route path="/pages" component={UserPages} />
          </Suspense>

          {/* Applications */}

          <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="ball-pulse" />
                  </div>
                  <h6 className="mt-3">Loading, please wait.</h6>
                </div>
              </div>
            }
          >
            <Route path="/apps" component={Applications} />
          </Suspense>

          {/* Dashboards */}

          <Suspense
            fallback={
              <div className="loader-container">
                <div className="loader-container-inner">
                  <div className="text-center">
                    <Loader type="ball-grid-beat" />
                  </div>
                  <h6 className="mt-3">Loading, please wait.</h6>
                </div>
              </div>
            }
          >
            <Route path="/dashboards" auth={auth} component={Dashboards} />
          </Suspense>

          {/* <Route exact path="/" render={() => (
                    <Redirect to="/dashboards/crm"/>
                )}/> */}
          <ToastContainer />
        </Fragment>
      </Router>
    );
  }
}

export default AppMain;
