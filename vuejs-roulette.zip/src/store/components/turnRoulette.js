import { getRandomInt } from "../helpers";
import { getRouletteResult } from "../helpers";

export const TURN_ROULETTE = (state) => {
  state.is_turning = true;
  state.drag = false;
  state.dragPrice = 0;
  state.random_rotation_index = getRandomInt(1, 2)
  state.turning_deg =
    state.random_rotation_index * (360 / state.num_count) + 3 * 360;
  state.kickSound3.currentTime = 1;
  state.kickSound3.play();
  setTimeout(() => {
    state.kickSound3.pause();
  }, state.turning_duration * 1000);
};

export const turnRoulette = (context) => {
  context.commit("TURN_ROULETTE");
};

export const SET_MODE = (state, mode) => {
  state.mode = mode;
  if (mode === "autoStart-start") {
    state.turning_duration = 10;
    state.delay = 2;
  }
  if (mode === "normalSpin-start") {
    state.turning_duration = 10;
    state.delay = 2;
  }
  if (mode === "turbo-start" ) {
    state.turning_duration = 0;
    state.delay = 0;
  }
  if (mode === "auto-turbo-start") {
    state.turning_duration = 0;
    state.delay = 0;
  }
};

export const setMode = (context, { mode, count }) => {
  context.commit("SET_MODE", mode);

  if (mode === "autoStart-start") {
    context.commit("TURN_ROULETTE");
    const intervalId = setInterval(() => {
      context.commit("TURN_ROULETTE");
    }, 14500);
    setTimeout(() => {
      clearInterval(intervalId);
      context.commit("SET_MODE", "autoStart-end-ready");
    }, 14500 * (count - 1) + 500);
  }

  if (mode === "normalSpin-start") {
    context.commit("TURN_ROULETTE");
    setTimeout(() => {
      context.commit("SET_MODE", "normalSpin-end");
    }, 10000);
  }
  if (mode === "auto-turbo-start") {
    context.commit("TURN_ROULETTE");
    const intervalId = setInterval(() => {
      context.commit("TURN_ROULETTE");
    }, 1000);
    setTimeout(() => {
      clearInterval(intervalId);
      context.commit("SET_MODE", "auto-turbo-end-ready");
    }, 1000 * (count - 1) + 500);
  }
  if (mode === "turbo-start") {
    context.commit("TURN_ROULETTE");
    setTimeout(() => {
      context.commit("SET_MODE", "turbo-end");
    }, 1000);
  }
};

export const STOP_ROULETTE = (state) => {
  const rouletteResult = getRouletteResult(
      state.turning_deg,
      state.wheel_numbers
  );
  state.latest_result = rouletteResult
  state.current_result = rouletteResult
  state.is_turning = false;
  state.turning_deg = 0;
  state.historyArr[state.finished_num] = state.latest_result;
  state.historyArr = [...state.historyArr];
  state.finished_num++;

  //console.log('last res: ', state.latest_result, state.placedChips)
  // check se vince

  // cancella puntata
  // state.placedChips.splice(0, state.placedChips.length);

};

export const stopRoulette = ({ commit, state }) => {
  commit("STOP_ROULETTE");
  if (state.mode === "autoStart-end-ready") {
    commit("SET_MODE", "autoStart-end");
  }
  if (state.mode === "auto-turbo-end-ready") {
    commit("SET_MODE", "auto-turbo-end");
  }
};

export const RESET_CURRENT_RESULT = (state) => {
  state.current_result = -1
};

export const resetCurrentResult = ({ commit }) => {
  commit("RESET_CURRENT_RESULT");
};
