<template>
  <div class="wheel-wrapper">
    <div class="wheel">
      <img src="../assets/images/wheel_frame.png" class="wheel-frame" alt="" />
      <img
        src="../assets/images/wheel_numbers.png"
        ref="wheel_numbers"
        class="wheel-numbers"
        :style="[is_turning ? displayWheelNone : resetWheelStyle]"
        alt=""
      />
      <img
        src="../assets/images/wheel_numbers.png"
        ref="wheel_numbers"
        class="wheel-numbers"
        :style="[is_turning ? rotateWheelStyle : displayWheelNone]"
        alt=""
      />
      <div v-if="current_result !== -1" class="winner-number" :class="{ visible: showWinnerNumber }" :style="{ backgroundColor: getColor(this.current_result)}">{{ this.current_result }}</div>
      <div class="wheel-handle">
        <img
          src="../assets/images/handles.png"
          class="wheel-handle__handles"
          :style="[is_turning ? rotateWheelStyle : resetWheelStyle]"
          alt=""
        />
        <img
          src="../assets/images/handle_base.png"
          class="wheel-handle__base"
          alt=""
        />
        <img
          src="../assets/images/handle_top.png"
          class="wheel-handle__top"
          alt=""
        />
      </div>
    </div>


    <img
      src="../assets/images/ball.png"
      style="opacity: 0"
      class="ball"
      ref="ball"
      alt=""
    />
  </div>
</template>

<script>
import { mapState } from "vuex";
import state from "../store/initialState";


export default {
  name: "Wheel",

  data: function() {
      return {
        random_diamond: 1,
        showWinnerNumber: false
      }
  },
  computed: {
    ...mapState([
      "is_turning",
      "turning_duration",
      "delay",
      "turning_speed",
      "turning_deg",
      "latest_result",
      "current_result",
      "wheel_numbers",
      "wheel_colors"
    ]),
    rotateWheelStyle() {
      return {
        transition: `transform ${this.turning_duration + this.delay}s cubic-bezier(0,0,0.58,1)`,
        transform: "translate(-50%, -50%) rotate(" + this.turning_deg + "deg)",
      };
    },
    displayWheelNone() {
      return {
        zIndex: "-999",
      }
    },
    resetWheelStyle() {
      return {
        animation: "wheelMove 18s linear infinite",
      };
    },
    // rotateBallStyle() {
    //   return {
    //     animation: `${this.turning_duration}s linear forwards orbit2`,
    //   };
    // },
  },
  watch: {
    is_turning(newValue) {
      if (newValue) {
        this.showWinnerNumber = true

        this.random_diamond = Math.floor(Math.random() * 8) + 1 ;  //getting random diamond index from 1 to 8
        switch (this.random_diamond) {
          case 1:
          case 2:
            state.sync_offset = 0;
            break;
          case 3:
          case 4:
            state.sync_offset = 3;
            break;
          case 5:
          case 6:
            state.sync_offset = 6;
            break;
          case 7:
          case 8:
            state.sync_offset = 9;
            break;
          default:
            break;
        }
        console.log('Random wheel rotation offset: ', state.sync_offset);
        console.log('Random rotation change level: ', state.turning_deg);

        this.$refs.wheel_numbers.style.filter = "blur(1px)";
        this.$refs.ball.style.animation = `${this.turning_duration +this.delay}s linear forwards orbit${this.random_diamond}_${state.random_rotation_index}`;
        // this.$refs.ball.addEventListener('animationend', function() {
        //   console.log(this.getBoundingClientRect());
        // });
        // when roulette stops

        setTimeout(() => {
          this.$refs.wheel_numbers.style.filter = "blur(0px)";
        }, (this.turning_duration + this.delay) * 1000);
        //
        setTimeout(() => {
          this.$store.dispatch("stopRoulette");
          this.$refs.ball.style.animation = "none";
          this.$store.dispatch("clearAll");
          this.$store.dispatch("refreshAvailableMoney");
        }, (this.turning_duration + this.delay) * 1000);
      }
    },
  },
  methods: {
    getColor(number) {
      let index = -1;
      this.wheel_numbers.forEach((n, idx) => {
        if (n === number) index = idx;
      });
      return index !== -1 ? this.wheel_colors[index] : "transparent";
    },
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
@mixin wheelComponents() {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  will-change: transform;
}
.wheel-wrapper {
  position: relative;
}
.wheel {
  position: relative;
  img {
    pointer-events: none;
  }
    @media screen and (max-width: 1080px) {
    width: clamp(260px, 60vw, 270px);
  }
  &-frame {
    max-width: 100%;
        @media screen and (max-width: 1080px) {
      width: clamp(200px, 80vw, 525px);
    }
  }
  &-numbers {
    width: clamp(200px, 27.3vw, 525px);
    @include wheelComponents;
    @media screen and (max-width: 1080px) {
      width: clamp(175px, 55vw, 210px);
    }
  }
  &-handle {
    img {
      @include wheelComponents;
    }
    &__handles {
      width: clamp(90px, 12.8vw, 247px);
    }
    &__base {
      width: clamp(30px, 4vw, 80px);
    }
    &__top {
      width: clamp(15px, 2vw, 40px);
    }
  }
  .winner-number {
    visibility: hidden;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 999;
    width: clamp(50px, 14.3vw, 525px);
    /* text-align: center; */
    height: clamp(50px, 14.3vw, 525px);
    color: #ffffff;
    border-radius: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 120px;
    font-weight: bold;
    &.visible {
      visibility: visible;
    }
    @media screen and (max-width:1080px) {
      width: clamp(110px, 14.3vw, 525px);
      /* text-align: center; */
      height: clamp(110px, 14.3vw, 525px);
      font-size: 80px;
    }
  }

}
.ball {
  @include wheelComponents();
  width: clamp(15px, 1.77vw, 34px);
  height: clamp(15px, 1.77vw, 34px);
  transform-origin: top left;
}


// @media screen and (max-width: 1080px) {
//   .wheel {
//     &-numbers {
//       width: clamp(180px, 27.3vw, 525px);
//     }
//   }
// }

</style>
