This is a Roulette presentation made with Vue and Vuex.

In the project directory, please run:

### `npm install`
and
### `npm run serve`

Runs the app in the development mode.<br />

To view the working demo please visit https://timardex.github.io/vue-roulette/