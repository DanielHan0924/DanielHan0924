export const chips = [
    {
      src: require("../assets/images/0,1_chip.png"),
      alt: "0,1",
      price: 0.1,
    },
    {
      src: require("../assets/images/0,5_chip.png"),
      alt: "0,5",
      price: 0.5,
    },
    { src: require("../assets/images/1_chip.png"), alt: "1", price: 1 },
    { src: require("../assets/images/5_chip.png"), alt: "5", price: 5 },
    { src: require("../assets/images/10_chip.png"), alt: "10", price: 10 },
    { src: require("../assets/images/25_chip.png"), alt: "25", price: 25 },
    { src: require("../assets/images/50_chip.png"), alt: "50", price: 50 },
    {
      src: require("../assets/images/100_chip.png"),
      alt: "100",
      price: 100,
    },
  ];
  