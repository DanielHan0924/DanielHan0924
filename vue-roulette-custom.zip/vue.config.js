module.exports = {
  publicPath: '/vue-roulette/'
}